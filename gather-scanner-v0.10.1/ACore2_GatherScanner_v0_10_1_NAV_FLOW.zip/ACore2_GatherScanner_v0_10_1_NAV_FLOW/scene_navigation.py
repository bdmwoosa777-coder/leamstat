"""Local scene evaluation and a bounded, camera-relative navigation policy.

Models never receive a gamepad. Only the engine applies a reviewed decision.
No metric height, collision map, or global pathfinding is inferred here.
"""
from dataclasses import dataclass,replace
import math,threading,time
import cv2,numpy as np
from navigation import Drive
from minimap import angle_delta

@dataclass(frozen=True)
class Lane:
 free:float
 solid:float
 edge:float
 unknown:float

@dataclass(frozen=True)
class SceneReading:
 captured:float
 heading:float|None
 pitch:float
 sequence:int
 lanes:tuple
 elapsed_ms:float=0
 backend:str=''
 revision:int=0

@dataclass
class PilotAction:
 drive:Drive|None=None
 fly:bool=False
 abandon:bool=False
 reason:str=''


def assess(groups,raw_depth):
 """Both gradient axes matter: a lateral cliff can have no vertical step."""
 from scene import world_mask
 h,w=raw_depth.shape
 g=cv2.resize(groups,(w,h),interpolation=cv2.INTER_NEAREST)
 valid=world_mask((h,w));valid[round(h*.49):round(h*.84),round(w*.475):round(w*.525)]=False
 values=raw_depth[valid]
 if not np.isfinite(raw_depth).all() or values.size<16:raise ValueError('Invalid scene depth')
 lo,hi=np.percentile(values,[5,95]);z=np.clip((raw_depth-lo)/max(1e-5,hi-lo),0,1)
 z=cv2.GaussianBlur(z,(5,5),0);dy=max(2,round(h*.018));dx=max(2,round(w*.018))
 vertical=np.zeros_like(z);horizontal=np.zeros_like(z)
 vertical[dy:-dy]=np.maximum(0,z[2*dy:]-z[:-2*dy])
 horizontal[:,dx:-dx]=np.abs(z[:,2*dx:]-z[:,:-2*dx])
 pair=valid.copy();pair[dy:-dy]&=valid[2*dy:]&valid[:-2*dy]
 pair[:,dx:-dx]&=valid[:,2*dx:]&valid[:,:-2*dx]
 edges=(np.maximum(vertical,horizontal)>.16)&pair
 lanes=[]
 for a,b in ((.18,.40),(.40,.62),(.62,.84)):
  area=np.zeros((h,w),bool);area[round(h*.43):round(h*.81),round(w*a):round(w*b)]=True;area&=valid
  denominator=max(1,int(area.sum()))
  # Level water is a permitted surface observation, not an automatic hazard.
  free=((g==1)|(g==3))&area
  lanes.append(Lane(float(free.sum()/denominator),float(((g==2)&area).sum()/denominator),
                    float((edges&area).sum()/denominator),float(((g==0)&area).sum()/denominator)))
 return tuple(lanes)


class SceneHost:
 def __init__(self,cfg,emit=lambda message:None):
  self.cfg=cfg;self.emit=emit;self.lock=threading.Lock();self.event=threading.Event();self.stop=threading.Event()
  self.pending=None;self.latest=None;self.worker=None;self.sequence=0;self.last_offer=-1e9;self.error=None
 def start(self):
  with self.lock:
   if not self.stop.is_set() and self.worker is None:
    self.worker=threading.Thread(target=self._run,daemon=True);self.worker.start()
 def offer(self,frame,now,heading,pitch,revision=0):
  if self.stop.is_set() or now-self.last_offer<.45:return
  self.last_offer=now
  h,w=frame.shape[:2];scale=min(1,1280/w)
  image=cv2.resize(frame,(round(w*scale),round(h*scale)),interpolation=cv2.INTER_AREA) if scale<1 else frame.copy()
  with self.lock:
   if self.stop.is_set():return
   self.sequence+=1;self.pending=(image,now,heading,pitch,self.sequence,revision)
   if self.worker is None:
    self.worker=threading.Thread(target=self._run,daemon=True);self.worker.start()
  self.event.set()
 def current(self,now,heading,pitch,revision=0):
  with self.lock:r=self.latest
  if (r is None or not 0<=now-r.captured<=.9 or abs(pitch-r.pitch)>.03 or revision!=r.revision
      or heading is not None and r.heading is not None and abs(angle_delta(heading,r.heading))>12):return None
  return r
 def close(self):
  self.stop.set();self.event.set()
  with self.lock:self.pending=None;self.latest=None
 def _run(self):
  if self.stop.is_set():return
  try:
   import onnxruntime as ort
   from model_runner import SegmentationRunner
   from depth import DepthRunner
   from scene import interpret
   if not self.cfg.get('scene_allow_cpu',False) and 'DmlExecutionProvider' not in ort.get_available_providers():
    raise RuntimeError('DirectML недоступен. Запустите SETUP.bat новой сборки; ИИ отключён, прежняя навигация сохранена')
   device=self.cfg.get('scene_gpu_device')
   if device is None:
    try:
     from win_capture import adapters
     cards=adapters();device=next((c['id'] for c in cards if '4080' in c['name']),next((c['id'] for c in cards if c['vendor']==0x10de),0))
    except Exception:device=0
   self.emit('SCENE: загружаю две локальные модели; адаптер '+str(device))
   cpu=self.cfg.get('scene_force_cpu',False)
   semantic=SegmentationRunner(device,cpu,self.emit);depth=DepthRunner(device,cpu,self.emit)
   if not self.cfg.get('scene_allow_cpu',False) and (semantic.backend!='DmlExecutionProvider' or depth.backend!='DmlExecutionProvider'):
    raise RuntimeError('DirectML не подтвердился у обеих моделей; проверьте SETUP и драйвер')
   self.emit('SCENE: модели готовы, '+semantic.backend+'; управление — только в цикле бота')
   while not self.stop.is_set():
    self.event.wait(.2);self.event.clear()
    with self.lock:request=self.pending;self.pending=None
    if request is None:continue
    frame,captured,heading,pitch,seq,revision=request;start=time.monotonic()
    labels,confidence,_=semantic.predict(frame);groups=interpret(labels,confidence,semantic.id2label).groups
    raw,_=depth.predict(frame);lanes=assess(groups,raw)
    reading=SceneReading(captured,heading,pitch,seq,lanes,(time.monotonic()-start)*1000,depth.backend,revision)
    if self.stop.is_set():break
    with self.lock:
     if not self.stop.is_set():self.latest=reading
  except Exception as exc:
   self.error=str(exc);self.emit('SCENE ERROR: '+str(exc))


class ScenePilot:
 def __init__(self,yaw_sign=1):
  self.yaw_sign=1 if yaw_sign>=0 else -1
  self.missing=None;self.fallback_until=0;self.blocked=None;self.side=0;self.side_until=0;self.last_seq=None;self.confirmations=0
 def reset(self):
  self.blocked=None;self.side=0;self.confirmations=0;self.last_seq=None
 def decide(self,plan,reading,now,energy=None,unavailable=False):
  if abs(plan.pitch)>.001 or math.hypot(plan.forward,plan.strafe)<.08:return PilotAction(plan)
  # Navigator owns camera steering and its settling intervals. The scene
  # must never introduce another turn controller with a different gain.
  moving=replace(plan,lifetime=max(.65,plan.lifetime))
  desired=math.degrees(math.atan2(plan.strafe,plan.forward))
  if abs(desired)>45 or abs(plan.yaw)>.001:
   return PilotAction(moving,reason='направление и поворот ведёт основной навигатор')
  if reading is None:
   return PilotAction(moving,reason='нет свежего ИИ-кадра: движение основного навигатора без ожидания')
  self.missing=None
  left,center,right=reading.lanes
  target=left if desired< -18 else right if desired>18 else center
  danger=self.edge_danger(target)
  # Sky can have high semantic confidence. Absence of unknown pixels is not
  # evidence of a traversable surface at the edge of a platform.
  blocked=danger or target.solid>=.40 or target.free<.12
  if not blocked:
   self.reset();return PilotAction(replace(moving,forward=min(.65,plan.forward),strafe=max(-.45,min(.45,plan.strafe)),yaw=0,yaw_lifetime=None),reason='видимая поверхность впереди; продолжаю к цели')
  if self.blocked is None:self.blocked=now
  if reading.sequence!=self.last_seq:self.confirmations+=1;self.last_seq=reading.sequence
  safe=[]
  for side,lane in ((-1,left),(0,center),(1,right)):
   if lane.free>=.18 and lane.solid<.35 and not self.edge_danger(lane):
    score=lane.free-.5*lane.solid-8*lane.edge+.2*math.cos(math.radians(side*40-desired))
    if side==self.side and now<self.side_until:score+=.25
    safe.append((score,side))
  if safe:
   side=max(safe)[1]
   if side!=self.side:self.side=side;self.side_until=now+3
   if now-self.blocked>12:
    self.reset();return PilotAction(Drive(),abandon=True,reason='обход не завершился за 12 с: меняю цель вместо хождения туда-сюда')
   return PilotAction(Drive(.46 if side else .50,.32*side,0,0,lifetime=.65),reason='обход '+('слева' if side<0 else 'справа' if side>0 else 'по видимой полосе впереди')+('; возможный край впереди' if danger else '; впереди препятствие'))
  if (self.confirmations>=2 and now-self.blocked>=6 and energy is not None and energy>=50
      and target.solid>=.4 and max(l.edge for l in reading.lanes)<.012):
   self.reset();return PilotAction(Drive(),fly=True,reason='стена перекрыла видимые обходы; запас от 50%, пробую ограниченный облёт')
  if now-self.blocked>=8:
   self.reset();return PilotAction(Drive(),abandon=True,reason='выход не подтверждён: пропускаю цель и разворачиваюсь')
  return PilotAction(Drive(lifetime=.10),reason='проход не подтверждён: коротко проверяю следующий кадр, без второго рулевого')
 @staticmethod
 def edge_danger(lane):
  # Weak inverse-depth texture over an almost entirely ground-labelled lane
  # is insufficient to declare a cliff. Large discontinuities remain blocked.
  return lane.edge>=.012 and (lane.edge>=.06 or lane.free<.85 or lane.solid>.15)
