import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import cv2
import numpy as np
from app import DEFAULT
import gather_engine as ge
from flight import FlightReading,FlightBudget,read_flight
from gamepad_input import GamepadInput
from minimap import Marker,Radar,MinimapVision,angle_delta
from navigation import Navigator
from vision import Candidate,Observation,gathering_panel


class Pad:
    def __init__(self):self.buttons=0;self.axes=(0,0,0,0);self.presses=0;self.fail=False
    def reset(self):self.buttons=0;self.axes=(0,0,0,0)
    def update(self):
        if self.fail and self.buttons:raise RuntimeError('driver failed after report')
    def press_button(self,button):self.buttons=button;self.presses+=1
    def left_joystick_float(self,x_value_float,y_value_float):self.axes=(x_value_float,y_value_float,*self.axes[2:])
    def right_joystick_float(self,x_value_float,y_value_float):self.axes=(*self.axes[:2],x_value_float,y_value_float)


def obs(name=None,candidate=None,distance=None,prompt=False,gather=False):
    return Observation(candidate,name,distance,prompt,1 if prompt else 0,gather,None,'HIDDEN')


def radar(markers=None,heading=90):return Radar(markers or [],(100,100),heading,1,(0,0),False,(0,0,200,200))


class NavigationTests(unittest.TestCase):
    def test_camera_cone_gives_bisector_not_player_arrow(self):
        image=np.full((200,200,3),(70,100,120),np.uint8)
        cv2.line(image,(115,85),(170,30),(255,255,255),2)
        cv2.line(image,(115,115),(170,170),(255,255,255),2)
        heading,confidence=MinimapVision.cone_heading(image,(100,100))
        self.assertIsNotNone(heading);self.assertLess(abs(angle_delta(heading,90)),10)
        self.assertGreater(confidence,.3)

    def test_aligned_marker_produces_real_forward_motion(self):
        marker=Marker('Самоцвет',150,100,.9,50)
        nav=Navigator({});plan=nav.update(radar([marker],90),0)
        self.assertGreater(plan.forward,.5);self.assertLess(abs(plan.yaw),.1)

    def test_behind_marker_turns_before_running(self):
        marker=Marker('Эфир',50,100,.9,50,'aether')
        plan=Navigator({}).update(radar([marker],90),0)
        self.assertEqual(plan.forward,0);self.assertGreater(abs(plan.yaw),.3)

    def test_empty_map_patrol_is_not_stationary_camera_twitch(self):
        plan=Navigator({}).update(radar(),0)
        self.assertGreater(plan.forward,.4)

    def test_low_energy_chooses_ground_marker(self):
        nodes=[Marker('Эфир',120,100,.9,20,'aether'),Marker('Самоцвет',150,100,.9,50)]
        nav=Navigator({});nav.update(radar(nodes),0,allow_air=False)
        self.assertEqual(nav.goal.kind,'gem')

    def test_no_approach_progress_abandons_marker(self):
        marker=Marker('Самоцвет',150,100,.9,50)
        nav=Navigator({});nav.update(radar([marker]),0)
        plan=nav.update(radar([marker]),7)
        self.assertLess(plan.forward,0);self.assertIsNone(nav.goal);self.assertEqual(len(nav.excluded),1)

    def test_white_circular_dots_are_not_gem_icons(self):
        image=np.full((720,1280,3),(70,100,120),np.uint8)
        for x,y in [(1090,100),(1110,100),(1130,110)]:cv2.circle(image,(x,y),3,(250,250,250),-1)
        found=MinimapVision({}).observe(image).markers
        self.assertFalse(any(m.kind=='gem' for m in found),found)

    def test_builtin_coloured_diamond_and_three_lobed_gem(self):
        image=np.full((720,1280,3),(70,100,120),np.uint8)
        cv2.fillConvexPoly(image,np.array([[1220,95],[1226,104],[1220,113],[1214,104]]),(160,235,50))
        glyph=cv2.resize(MinimapVision.gem_glyph(),(9,11),interpolation=cv2.INTER_AREA)
        patch=image[100:111,1100:1109];patch[glyph>150]=(255,255,255)
        found=MinimapVision({}).observe(image).markers
        self.assertTrue(any(m.kind=='aether' and abs(m.x-1220)<4 for m in found),found)
        self.assertTrue(any(m.kind=='gem' and abs(m.x-1104)<4 for m in found),found)


class FlightTests(unittest.TestCase):
    def test_nearly_empty_real_shaped_track_reports_low_energy(self):
        image=np.full((720,1280,3),(145,155,140),np.uint8)
        y=np.arange(476,727,dtype=float);x=1047+46*((y-597)/123)**2
        points=np.column_stack((np.rint(x*.5),np.rint((y+160)*.5))).astype('int32')
        cv2.polylines(image,[points],False,(15,15,15),6)
        cv2.polylines(image,[points[-12:]],False,(240,255,50),4)
        reading=read_flight(image)
        self.assertTrue(reading.confirmed);self.assertLess(reading.energy,8)

    def test_absent_gauge_is_not_zero_energy(self):
        reading=read_flight(np.full((720,1280,3),(220,170,100),np.uint8))
        self.assertFalse(reading.confirmed);self.assertIsNone(reading.energy)

    def test_low_energy_hysteresis_recovers_on_ground(self):
        b=FlightBudget();b.update(FlightReading(3,True),0)
        self.assertFalse(b.can_start())
        b.update(FlightReading(None,False),1);b.update(FlightReading(None,False),5)
        self.assertFalse(b.can_start())
        b.update(FlightReading(None,False),40)
        self.assertTrue(b.can_start());self.assertGreaterEqual(b.energy,18)


class InputLeaseTests(unittest.TestCase):
    def test_motion_lease_expires_without_new_vision(self):
        pad=Pad();control=GamepadInput(factory=lambda:pad,a_button=0x1000)
        try:
            control.drive(.7,0,.2,0,lifetime=.05)
            self.assertNotEqual(pad.axes,(0,0,0,0))
            time.sleep(.13)
            self.assertEqual(pad.axes,(0,0,0,0))
        finally:control.close()

    def test_failed_a_update_still_releases_button_and_sticks(self):
        pad=Pad();control=GamepadInput(factory=lambda:pad,a_button=0x1000);pad.fail=True
        try:
            with self.assertRaises(RuntimeError):control.tap_a(threading.Event(),lambda:True)
            self.assertEqual(pad.buttons,0);self.assertEqual(pad.axes,(0,0,0,0))
        finally:control.close()


class GatherStateTests(unittest.TestCase):
    def setUp(self):
        self.pad=Pad();self.input=GamepadInput(factory=lambda:self.pad,a_button=0x1000)
        self.log=[];self.commands=[];self.positions=[]
        self.e=ge.GatherEngine({**DEFAULT,'debug_screenshots':False},self.log.append,self.input)
        self.e.bridge=SimpleNamespace(send=self.commands.append,cursor=lambda x,y:self.positions.append((x,y)),restore_locks=lambda:None)
        self.frame=np.zeros((720,1280,3),np.uint8)
        self.e.screen=SimpleNamespace(focused=lambda:True,frame=lambda:(self.frame,(0,0)))
        self.c=Candidate('Сапфир',700,400,95,(670,360,60,20))
        self.sky=FlightReading(None,False)

    def tearDown(self):self.input.close()

    def step(self,ob,now=100,plate=None,panel=False,reading=None):
        with patch.object(ge,'segment_count',return_value=plate),patch.object(ge,'gathering_panel',return_value=panel):
            self.e.step(self.frame,(0,0),ob,radar(),reading or self.sky,now,1)

    def test_one_a_then_alt_release_then_f(self):
        with patch.object(GamepadInput,'wait',return_value=True):
            self.assertTrue(self.e.click_candidate(self.c,(10,20),refresh=False))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.buttons,0)
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP','TAP_F'])
        self.assertTrue(self.e.target_confirmed);self.assertEqual(self.e.mode,'APPROACH')

    def test_nonresource_header_never_sends_f(self):
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(ge,'find_world_resource',return_value=self.c),patch.object(ge,'selected_target',return_value=('Страж',10)):
            self.assertFalse(self.e.click_candidate(self.c,(0,0)))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.commands[-1],'ALT_UP')
        self.assertNotIn('TAP_F',self.commands)

    def test_stop_after_a_suppresses_f(self):
        def wait(seconds,*args):
            if seconds==.20:self.e.stop_event.set();return False
            return True
        with patch.object(GamepadInput,'wait',side_effect=wait):
            self.assertFalse(self.e.click_candidate(self.c,(0,0),refresh=False))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.buttons,0)
        self.assertEqual(self.commands[-1],'ALT_UP')
        self.assertNotIn('TAP_F',self.commands)

    def test_header_corrects_an_imprecise_far_caption(self):
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(ge,'find_world_resource',return_value=self.c),patch.object(ge,'selected_target',return_value=('Рубин',25)):
            self.assertTrue(self.e.click_candidate(self.c,(0,0)))
        self.assertEqual(self.e.target,'Рубин');self.assertEqual(self.pad.presses,1)
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP','TAP_F'])

    def test_unreadable_header_does_not_send_f_even_if_world_caption_was_read(self):
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(ge,'find_world_resource',return_value=self.c),patch.object(ge,'selected_target',return_value=(None,None)):
            self.assertFalse(self.e.click_candidate(self.c,(0,0)))
        self.assertNotIn('TAP_F',self.commands);self.assertEqual(self.commands[-1],'ALT_UP')

    def test_sky_does_not_toggle_wings_when_ether_selection_failed(self):
        self.e.target='Эфир';self.e.budget.airborne=True
        self.e.return_to_search('выбор не подтвердился',reading=self.sky)
        self.assertNotIn('V',self.commands)

    def test_confirmed_near_target_starts_f_without_template_prompt(self):
        self.e.mode='APPROACH';self.e.target='Сапфир';self.e.target_confirmed=True
        self.step(obs('Сапфир',distance=1),plate=3)
        self.assertEqual(self.e.mode,'GATHER');self.assertIn('F_ON',self.commands)

    def test_depletion_needs_track_and_identity_to_disappear(self):
        self.e.mode='GATHER';self.e.target='Сапфир';self.e.target_confirmed=True;self.e.f_on=True;self.e.started=99
        self.step(obs(),100,plate=1)
        self.assertEqual(self.e.mode,'GATHER')
        self.step(obs(),101);self.step(obs(),102)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIn('F_OFF',self.commands)
        self.assertEqual(self.e.node_count,1)

    def test_ground_gather_folds_real_wings_once_and_keeps_f(self):
        self.e.mode='GATHER';self.e.target='Сапфир';self.e.f_on=True;self.e.started=99
        reading=FlightReading(60,True)
        self.step(obs('Сапфир',gather=True),100,plate=3,panel=True,reading=reading)
        self.step(obs('Сапфир',gather=True),101,plate=2,panel=True,reading=reading)
        self.assertEqual(self.commands.count('V'),1);self.assertNotIn('F_OFF',self.commands)

    def test_ether_folds_at_last_full_attempt_once(self):
        self.e.mode='GATHER';self.e.target='Эфир';self.e.f_on=True;self.e.started=99
        with patch.object(ge,'gather_result_full',return_value=True):
            self.step(obs('Эфир',gather=True),100,plate=1,panel=True,reading=FlightReading(50,True))
            self.step(obs('Эфир',gather=True),101,plate=1,panel=True,reading=FlightReading(50,True))
        self.assertEqual(self.commands.count('V'),1)

    def test_obstacle_recovery_tries_jump_before_takeoff(self):
        self.e.target='Сапфир';self.e.target_confirmed=True
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=12),self.sky,100)
        self.assertEqual(self.e.mode,'JUMP_RETRY');self.assertIn('JUMP',self.commands)
        self.assertNotIn('V',self.commands)

    def test_takeoff_timeout_does_not_toggle_v_again(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.jump_attempted=True
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=12),self.sky,100)
        self.assertEqual(self.e.mode,'TAKEOFF');self.e.started=100
        self.step(obs('Сапфир',distance=12),105,plate=3)
        self.assertEqual(self.commands.count('V'),1);self.assertEqual(self.e.mode,'SEARCH')

    def test_dry_run_never_presses_a(self):
        self.e.cfg['dry_run']=True
        self.e.click_candidate(self.c,(0,0),refresh=False)
        self.assertEqual(self.pad.presses,0);self.assertEqual(self.commands,[])

    def test_old_ocr_result_cannot_undo_new_a_selection(self):
        self.e.identity_valid_after=100
        old=self.e.current_observation(obs('Сапфир',distance=1),99)
        self.assertIsNone(old.target_name)
        fresh=self.e.current_observation(obs('Эфир',distance=20),101)
        self.assertEqual(fresh.target_name,'Эфир')

    def test_delayed_ocr_does_not_keep_f_running_after_physical_plate_disappears(self):
        self.e.mode='GATHER';self.e.target='Сапфир';self.e.f_on=True;self.e.started=99
        self.e.observation_captured_at=99
        self.step(obs('Сапфир',distance=1),100,plate=None,panel=True)
        self.step(obs('Сапфир',distance=1),101,plate=None,panel=True)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIn('F_OFF',self.commands)


if __name__=='__main__':unittest.main()
