"""Fast navigation loop with independent OCR, heartbeat and dialog watchers."""
from pathlib import Path
from dataclasses import replace
import threading
import time
import traceback
import cv2
from bridge import GHubBridge
from gamepad_input import GamepadInput
from screen_capture import ScreenCapture
from minimap import MinimapVision
from navigation import Navigator
from flight import read_flight,FlightBudget
from vision import (WorldVision,find_world_resource,selected_target,segment_count,
                    gathering_panel,gather_result_full,Observation)
from captcha_watchdog import CenterDialogDetector,AudioAlarm
from death_watchdog import DeathDialogDetector,DeathAudioAlarm

ROOT=Path(__file__).resolve().parent


class GatherEngine:
    def __init__(self,cfg,emit,gamepad=None):
        self.cfg,self.emit=cfg,emit
        self.stop_event=threading.Event();self.screen=ScreenCapture()
        self.bridge=GHubBridge(dry_run=cfg.get('dry_run',False),logger=emit)
        self.gamepad=gamepad
        self.vision=WorldVision(tuple(cfg['target_names']))
        self.minimap=MinimapVision(cfg);self.nav=Navigator(cfg)
        self.budget=FlightBudget(cfg.get('flight_low_percent',8),cfg.get('flight_resume_percent',18))
        self.cap=CenterDialogDetector(template_dir=ROOT);self.death=DeathDialogDetector(template_dir=ROOT)
        self.cap_alarm=AudioAlarm(logger=emit);self.death_alarm=DeathAudioAlarm(logger=emit)
        self.cap_alarm.device_match=self.death_alarm.device_match=cfg.get('audio_device','AG271QG4')
        self.mode='SEARCH';self.started=time.monotonic();self.target=None;self.target_confirmed=False
        self.f_on=False;self.folded=False;self.flight_attempted=False;self.jump_attempted=False;self.reselected=False
        self.last_distance=None;self.last_progress=self.started;self.missing_since=None
        self.last_segments=None;self.one_segment_armed=False;self.node_count=0
        self.candidate=None;self.candidate_since=None;self.candidate_sequence=None
        self.cooldowns=[];self.last_note=0;self.last_energy_note=0
        self.snapshot_lock=threading.Lock();self.snapshot=None;self.sequence=0
        self.observation_captured_at=0
        self.identity_valid_after=0
        self.safety_threads=[];self.release_thread=None;self.release_lock=threading.Lock()
        self.alert=None;self.alert_lock=threading.Lock();self.current_size=None
        self.screenshot_path=ROOT/'debug_gather'
        if cfg.get('debug_screenshots'):self.screenshot_path.mkdir(exist_ok=True)

    def say(self,text):self.emit('['+self.mode+'] '+text)

    def change_mode(self,mode):self.mode=mode;self.started=time.monotonic()

    def bridge_cmd(self,command):
        release=command in ('STOP','F_OFF','ALT_UP')
        if not release and (self.stop_event.is_set() or not self.screen.focused()):return False
        self.bridge.send(command);return True

    def f_enable(self):
        if not self.f_on and self.bridge_cmd('F_ON'):
            self.f_on=True;self.say('F включено: Lua-таймер 1000 мс')

    def f_disable(self):
        if self.f_on:self.bridge_cmd('F_OFF');self.f_on=False

    def save_debug(self,frame,label):
        if self.cfg.get('debug_screenshots'):
            self.screenshot_path.mkdir(exist_ok=True)
            # Preserve full resolution: the old 1280 resize damaged short Ether text.
            cv2.imwrite(str(self.screenshot_path/(time.strftime('%H%M%S')+'_'+label+'.jpg')),frame,[cv2.IMWRITE_JPEG_QUALITY,94])

    def _release_inputs(self):
        try:self.bridge.send('STOP');self.bridge.restore_locks()
        except Exception as exc:self.emit('Ошибка освобождения Lua: '+str(exc))

    def stop(self):
        self.stop_event.set()
        if self.gamepad:self.gamepad.reset()
        with self.release_lock:
            if self.release_thread is None:
                self.release_thread=threading.Thread(target=self._release_inputs,daemon=True)
                self.release_thread.start()

    def silence(self):self.cap_alarm.stop();self.death_alarm.stop()

    def trigger_alarm(self,kind,frame):
        with self.alert_lock:
            if self.alert is not None or self.stop_event.is_set():return
            self.alert=kind
        self.stop();self.save_debug(frame,kind.lower())
        self.say('ТРЕВОГА '+kind+' — остановлено, требуется ручное продолжение')
        alarm=self.cap_alarm if kind=='CAPTCHA' else self.death_alarm
        try:alarm.start(self.cfg.get('audio_device','AG271QG4'),error_cb=self.emit)
        except Exception as exc:self.emit('Ошибка звука: '+str(exc))

    def _dialog_loop(self,kind,detector,interval):
        hits=0
        while not self.stop_event.is_set():
            if self.screen.focused():
                try:
                    frame,_=self.screen.frame();present,_=detector.check(frame)
                    hits=hits+1 if present else 0
                    if hits>=2:self.trigger_alarm(kind,frame);return
                except Exception as exc:self.emit(kind+' / проверка: '+str(exc));hits=0
            else:hits=0
            if self.stop_event.wait(interval):return

    def _heartbeat_loop(self):
        while not self.stop_event.is_set():
            try:self.bridge_cmd('PING')
            except Exception as exc:self.emit('Ошибка heartbeat: '+str(exc));self.stop();return
            if self.stop_event.wait(2):return

    def _vision_loop(self):
        failures=0
        while not self.stop_event.is_set():
            if not self.screen.focused():
                if self.stop_event.wait(.15):return
                continue
            try:
                captured=time.monotonic();frame,_=self.screen.frame()
                obs=self.vision.scan(frame,candidates=self.mode!='GATHER')
                if obs.candidate and obs.candidate.name=='Эфир' and not self.budget.can_start() and self.mode in ('SEARCH','ACQUIRE_WAIT'):
                    names=tuple(n for n in self.cfg['target_names'] if n!='Эфир')
                    obs.candidate=find_world_resource(frame,names)
                with self.snapshot_lock:
                    self.sequence+=1;self.snapshot=(obs,captured,self.sequence,time.monotonic())
                failures=0
            except Exception as exc:
                failures+=1;self.emit('OCR / ошибка: '+str(exc))
                if failures>=3:self.stop();return
            if self.stop_event.wait(.08):return

    def _focus_ok(self):return not self.stop_event.is_set() and self.screen.focused()

    def _motion(self,plan):
        if self.cfg.get('dry_run'):return
        if self.gamepad and self._focus_ok():
            self.gamepad.drive(plan.forward,plan.strafe,plan.yaw,plan.pitch,lifetime=.45)

    def _neutral(self):
        if self.gamepad:self.gamepad.reset()

    def _allowed(self,candidate,now):
        if candidate.name not in self.cfg['target_names']:return False
        if self.cfg.get('only_aether') and candidate.name!='Эфир':return False
        if candidate.name=='Эфир' and not self.budget.can_start():
            if now-self.last_energy_note>4:
                self.say(f'Энергия {self.budget.energy:.1f}%: эфир отложен, ищу наземный ресурс')
                self.last_energy_note=now
            return False
        self.cooldowns=[p for p in self.cooldowns if p[3]>now]
        return not any(n==candidate.name and abs(candidate.click_x-x)<80 and abs(candidate.click_y-y)<80 for n,x,y,until in self.cooldowns)

    def click_candidate(self,candidate,origin,refresh=True,retry=False):
        if self.cfg.get('dry_run'):
            self.say(f'НАБЛЮДЕНИЕ: {candidate.name}, точка ({candidate.click_x},{candidate.click_y})');return False
        if not self.gamepad:raise RuntimeError('Виртуальный Xbox не подключён')
        self._neutral();self.f_disable()
        if not self._focus_ok():return False
        if not retry:
            self.target=candidate.name;self.target_confirmed=False;self.folded=False
            self.flight_attempted=False;self.jump_attempted=False;self.reselected=False
            self.last_distance=None;self.last_segments=None;self.one_segment_armed=False
        self.change_mode('ACQUIRE')
        self.bridge_cmd('ALT_DOWN')
        selected=False
        try:
            if not GamepadInput.wait(.16,self.stop_event,self.screen.focused):return False
            frame=None
            if refresh:
                frame,origin=self.screen.frame()
                fresh=find_world_resource(frame,(candidate.name,))
                if fresh is not None:candidate=fresh
            h=self.current_size[1] if self.current_size else 1440
            offsets=(0,round(h*.010),-round(h*.008)) if candidate.name=='Эфир' else (0,round(h*.009))
            for offset in offsets:
                if not self._focus_ok():return False
                x=origin[0]+int(candidate.click_x);y=origin[1]+int(candidate.click_y)+offset
                self.bridge.cursor(x,y)
                if not GamepadInput.wait(.12,self.stop_event,self.screen.focused):return False
                if not self.gamepad.tap_a(self.stop_event,self.screen.focused):return False
                if not GamepadInput.wait(.20,self.stop_event,self.screen.focused):return False
                if refresh:
                    frame,_=self.screen.frame();name,_=selected_target(frame,tuple(self.cfg['target_names']))
                    if name is not None:
                        if name not in self.cfg['target_names']:
                            self.say('Верхняя плашка не подтверждает разрешённый ресурс');break
                        confirmed=replace(candidate,name=name)
                        if not self._allowed(confirmed,time.monotonic()):break
                        if name!=candidate.name:
                            self.say(f'Дальняя подпись: {candidate.name}; верхняя плашка уточнила: {name}')
                        candidate=confirmed;selected=True
                else:selected=True
                if selected:break
            if not selected:
                self.say('Имя ресурса в верхней плашке не подтверждено; F не отправляю')
                return False
        finally:self.bridge_cmd('ALT_UP')
        if not self._focus_ok():return False
        # F must come AFTER Lua releases Alt, so it cannot become Alt+F.
        if not self.bridge_cmd('TAP_F'):return False
        self.target=candidate.name;self.candidate=candidate;self.target_confirmed=True;self.missing_since=None
        self.identity_valid_after=time.monotonic()
        self.last_progress=time.monotonic();self.change_mode('APPROACH')
        self.say(f'{candidate.name}: верхняя плашка подтверждена, Alt отпущен, F отправлено для автоподхода')
        return True

    def return_to_search(self,reason,frame=None,exhausted=False,reading=None):
        # Never toggle V from a sky colour or a historical "maybe in flight" flag.
        if reading is not None and reading.confirmed and self.target_confirmed and self.target=='Эфир' and not self.folded:
            self.bridge_cmd('V');self.folded=True
        self.f_disable();self._neutral();self.say(reason)
        now=time.monotonic()
        if exhausted:self.node_count+=1
        if self.candidate:
            self.cooldowns.append((self.candidate.name,self.candidate.click_x,self.candidate.click_y,now+(12 if exhausted else 30)))
        self.nav.exclude_goal(now,30)
        if frame is not None and not exhausted:self.save_debug(frame,'failed')
        self.target=None;self.candidate=None;self.target_confirmed=False
        self.missing_since=None;self.change_mode('SEARCH')

    def _recover(self,frame,origin,obs,reading,now):
        self._neutral()
        if not self.jump_attempted and self.target!='Эфир' and not reading.confirmed:
            self.jump_attempted=True;self.bridge_cmd('JUMP')
            self.change_mode('JUMP_RETRY');self.say('Подход остановился: одна попытка перепрыгнуть препятствие')
            return
        if not reading.confirmed and not self.flight_attempted and self.budget.can_start():
            self.flight_attempted=True;self.bridge_cmd('V');self.change_mode('TAKEOFF')
            self.say('Открываю крылья для обхода; жду настоящую дугу энергии перед повтором A')
            return
        if reading.confirmed and not self.reselected:
            self.reselected=True
            if obs.candidate and obs.candidate.name==self.target:
                if self.click_candidate(obs.candidate,origin,retry=True):return
            if self.target_confirmed:
                self.bridge_cmd('TAP_F');self.last_progress=now;self.change_mode('APPROACH')
                self.say('Повтор взаимодействия с подтверждённым таргетом в полёте')
                return
        self.return_to_search('Нет сближения с ресурсом: пропускаю и патрулирую дальше',frame,reading=reading)

    def step(self,frame,origin,obs,radar,reading,now,sequence=0):
        if self.stop_event.is_set():return
        self.current_size=(frame.shape[1],frame.shape[0])
        self.budget.update(reading,now)
        if not self.screen.focused():
            self._neutral();self.f_disable();self.nav.pause(now);return
        plate=segment_count(frame)
        panel=gathering_panel(frame)
        near=(obs.distance_m is not None and obs.distance_m<=3)
        gather_ready=obs.f_prompt or near or (panel and (obs.distance_m is None or near))
        if self.mode in ('SEARCH','ACQUIRE_WAIT'):
            if (self.cfg.get('assist_manual_target') and obs.target_name in self.cfg['target_names']
                and plate is not None
                and (not self.cfg.get('only_aether') or obs.target_name=='Эфир')
                and gather_ready):
                self.target=obs.target_name;self.target_confirmed=True;self.missing_since=None
                self.folded=False;self._neutral();self.f_enable();self.change_mode('GATHER');return
            candidate=obs.candidate
            if candidate and self.cfg.get('allow_click',True) and self._allowed(candidate,now):
                self._neutral();self.nav.pause(now)
                if self.mode=='SEARCH':
                    self.candidate=candidate;self.candidate_sequence=sequence
                    self.candidate_since=now;self.change_mode('ACQUIRE_WAIT')
                    self.say('Вижу '+candidate.name+'; остановил движение, уточняю координаты')
                elif sequence!=self.candidate_sequence and candidate.name==self.candidate.name:
                    if not self.click_candidate(candidate,origin):
                        self.return_to_search('Ресурс не выбран: поиск другой цели',frame,reading=reading)
                return
            if self.mode=='ACQUIRE_WAIT':
                if now-self.candidate_since<2.5:return
                self.candidate=None;self.change_mode('SEARCH')
            if not self.cfg.get('minimap_search',True):radar.markers=[]
            plan=self.nav.update(radar,now,self.budget.can_start())
            if not self.cfg.get('ground_walk',True):plan.forward=0;plan.strafe=0
            if not self.cfg.get('camera_scan',True):plan.yaw=0;plan.pitch=0
            self._motion(plan)
            if now-self.last_note>1.5:
                self.say(f'{plan.reason}; ресурсы на карте: {len(radar.markers)}, ход={plan.forward:.2f}, камера={plan.yaw:.2f}')
                self.last_note=now
            return
        if self.mode in ('APPROACH','JUMP_RETRY','TAKEOFF'):
            if obs.target_name and obs.target_name!=self.target:
                self.return_to_search('В таргете другой ресурс',frame,reading=reading);return
            if obs.distance_m is not None and obs.target_name==self.target:
                if self.last_distance is None or obs.distance_m<self.last_distance-.3:self.last_progress=now
                self.last_distance=obs.distance_m
            if self.target_confirmed and gather_ready:
                self._neutral();self.f_enable();self.missing_since=None;self.change_mode('GATHER')
                self.say('Сбор доступен; F работает независимо от OCR');return
            if self.mode=='TAKEOFF':
                if reading.confirmed:
                    if obs.candidate and obs.candidate.name==self.target:
                        if self.click_candidate(obs.candidate,origin,retry=True):return
                    self.bridge_cmd('TAP_F');self.last_progress=now;self.change_mode('APPROACH');return
                if now-self.started>3.5:
                    self.return_to_search('Крылья не подтверждены дугой; повторно V не переключаю',frame,reading=reading)
                return
            if self.mode=='JUMP_RETRY':
                if now-self.started>1.5:
                    self.bridge_cmd('TAP_F');self.last_progress=now;self.change_mode('APPROACH')
                return
            if plate is None and obs.target_name is None:
                if self.missing_since is None:self.missing_since=now
                if now-self.missing_since>2:
                    self.return_to_search('Плашка выбранного ресурса исчезла до сбора',frame,reading=reading);return
            else:self.missing_since=None
            if now-self.last_progress>self.cfg.get('approach_stall_seconds',6):
                self._recover(frame,origin,obs,reading,now)
            elif now-self.started>self.cfg.get('approach_timeout',30):
                self.return_to_search('Таймаут подхода',frame,reading=reading)
            return
        if self.mode=='GATHER':
            if obs.target_name is not None and obs.target_name!=self.target:
                self.return_to_search('Таргет сменился: выключаю F',frame,reading=reading);return
            if not self.f_on:self.f_enable()
            if plate is not None and plate!=self.last_segments:
                self.last_segments=plate;self.last_progress=now;self.say(f'Осталось попыток: {plate}/3')
            if plate==1 and panel:self.one_segment_armed=True
            if reading.confirmed and not self.folded:
                if self.target!='Эфир' or (self.one_segment_armed and gather_result_full(frame)):
                    self.bridge_cmd('V');self.folded=True
                    self.say('Складываю подтверждённые крылья; F продолжает сбор')
            # Require BOTH the resource track and its target identity to disappear.
            if plate is None:
                if self.missing_since is None:self.missing_since=now
                identity_absent=obs.target_name is None
                stale_identity=self.observation_captured_at<self.missing_since
                if (identity_absent or stale_identity) and now-self.missing_since>self.cfg.get('target_missing_seconds',.8):
                    self.return_to_search('Плашка и полоски исчезли: ресурс закончен',exhausted=True,reading=reading)
            else:self.missing_since=None
            if now-self.started>self.cfg.get('gather_timeout',55):
                self.return_to_search('Сбор не завершился за отведённое время',frame,reading=reading)

    def process(self,frame,origin,now):
        if self.stop_event.is_set():return
        obs=self.vision.scan(frame)
        self.observation_captured_at=now
        self.sequence+=1
        self.step(frame,origin,obs,self.minimap.observe(frame),read_flight(frame),now,self.sequence)

    def current_observation(self,obs,captured):
        if captured>=self.identity_valid_after:return obs
        # OCR started before A may finish later; it must not undo the new selection.
        return Observation(None,None,None,False,0,False,None,'HIDDEN')

    def run(self,offline=None):
        try:
            if offline:
                for file in offline:
                    if self.stop_event.is_set():break
                    frame=cv2.imread(str(file))
                    if frame is not None:self.process(frame,(0,0),time.monotonic())
                return
            if self.screen.pick() is None:raise RuntimeError('Окно AION2 не найдено')
            if not self.cfg.get('dry_run') and self.gamepad is None:raise RuntimeError('Нажмите «Подключить Xbox»')
            self.say('Навигация стиками; миникарта включена с готовыми цветами/формами, отдельный OCR-поток')
            self.safety_threads=[
                threading.Thread(target=self._vision_loop,daemon=True),
                threading.Thread(target=self._heartbeat_loop,daemon=True),
                threading.Thread(target=self._dialog_loop,args=('CAPTCHA',self.cap,1.0),daemon=True),
                threading.Thread(target=self._dialog_loop,args=('DEATH',self.death,3.0),daemon=True)]
            for worker in self.safety_threads:worker.start()
            while not self.stop_event.is_set():
                frame,origin=self.screen.frame();now=time.monotonic()
                if not self.screen.focused():
                    self._neutral();self.f_disable();self.nav.pause(now)
                    self.stop_event.wait(.1);continue
                with self.snapshot_lock:snapshot=self.snapshot
                if snapshot is None or now-snapshot[3]>3:
                    self._neutral();self.stop_event.wait(.08);continue
                obs,captured,sequence,completed=snapshot
                self.observation_captured_at=captured
                obs=self.current_observation(obs,captured)
                radar=self.minimap.observe(frame)
                if not self.cfg.get('minimap_search',True):radar.markers=[]
                self.step(frame,origin,obs,radar,read_flight(frame),now,sequence)
                if self.stop_event.wait(.09):break
        except Exception as exc:self.emit('ОШИБКА: '+repr(exc)+'\n'+traceback.format_exc())
        finally:
            self.stop()
            if self.release_thread:self.release_thread.join(timeout=5)
            self.emit('Сканер остановлен; A и стики сброшены')
