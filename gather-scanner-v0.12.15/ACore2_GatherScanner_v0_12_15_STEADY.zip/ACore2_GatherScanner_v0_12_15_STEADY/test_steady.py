"""Late-release pitch trim, useful-only radar matching and byte-identical panel reuse."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from collections import OrderedDict
import threading,unittest
import cv2,numpy as np
import gather_engine as ge,vision
from camera_control import PITCH_STRENGTH
from minimap import MinimapVision
from test_navigation import GatherFixture

class CalibrationTrim(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.clock=100.;self.input.motion_worker=object();self.jitter=.045;self.reports=[]
  listener=self.input.motion_listener
  def report(p,now,lease):self.reports.append((p,lease));listener(p,now,lease)
  self.input.motion_listener=report
  p=patch.object(ge.time,'monotonic',side_effect=lambda:self.clock);p.start();self.addCleanup(p.stop)
 def wait(self,seconds):
  self.clock+=seconds+self.jitter
  with self.input.lock:self.input._expire_motion(self.clock)
  return True
 def down(self,seconds=.940):
  before=self.e.pitch.offset(self.clock)
  with patch.object(self.e,'_camera_wait',side_effect=self.wait):result=self.e._hold_pitch_down(seconds)
  return result,(before-self.e.pitch.offset(self.clock))/PITCH_STRENGTH
 def test_log_like_late_release_is_trimmed_without_another_full_upward_homing(self):
  ok,actual=self.down();self.assertTrue(ok);self.assertAlmostEqual(actual,.940,delta=.021)
  self.assertTrue(any('CAMERA_TRIM' in s for s in self.log));self.assertTrue(any(p==PITCH_STRENGTH for p,_ in self.reports))
 def test_different_windows_release_delays_stay_within_the_existing_acceptance_limit(self):
  for delay in (.015,.045,.060):
   self.jitter=delay;ok,actual=self.down()
   self.assertTrue(ok,delay);self.assertAlmostEqual(actual,.940,delta=.040001)
 def test_upward_homing_does_not_trim_back_down_from_the_upper_limit(self):
  with patch.object(self.e,'_camera_wait',side_effect=self.wait):self.assertTrue(self.e._hold_pitch_up(2))
  self.assertFalse(any(p<0 for p,_ in self.reports));self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_trim_is_bounded_when_report_delivery_cannot_be_trusted(self):
  def jump(seconds):self.clock+=.5;return True
  with patch.object(self.e,'_camera_wait',side_effect=jump):ok=self.e._hold_pitch_down(.940)
  self.assertFalse(ok);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertLess(len(self.reports),50)
 def test_focus_loss_during_fine_trim_releases_the_controller(self):
  focused=[True];self.e.screen.focused=lambda:focused[0]
  def wait(seconds):
   self.wait(seconds)
   if any('CAMERA_TRIM' in s for s in self.log):focused[0]=False;return False
   return True
  with patch.object(self.e,'_camera_wait',side_effect=wait):self.assertFalse(self.e._hold_pitch_down(.940))
  self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_full_calibration_accepts_corrected_duration_and_clears_pending_alignment(self):
  self.e.camera_alignment_due='after recovery';self.e.camera_search_revision=3
  with patch.object(self.e,'_camera_wait',side_effect=self.wait),patch.object(self.e.cap,'check',return_value=(False,0)),patch.object(self.e.death,'check',return_value=(False,0)):
   self.assertTrue(self.e._calibrate_camera('log reproduction'))
  self.assertIsNone(self.e.camera_alignment_due);self.assertEqual(self.e.camera_aligned_revision,3)
  self.assertFalse(any('калибровка не принята' in s for s in self.log));self.assertFalse(self.e.stop_event.is_set())
 def test_precise_delivery_stays_at_selected_940ms(self):
  self.jitter=0;ok,actual=self.down();self.assertTrue(ok);self.assertAlmostEqual(actual,.940,delta=.006)

class UsefulRadar(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.m=MinimapVision({'minimap_character_arrow':False});self.e.minimap=self.m
  self.f=np.full((720,1280,3),(70,100,120),np.uint8)
  cv2.fillConvexPoly(self.f,np.array([[1220,95],[1226,104],[1220,113],[1214,104]]),(160,235,50))
 def test_ether_only_policy_skips_all_gem_template_matching(self):
  self.m.active_kinds={'aether'}
  with patch.object(cv2,'matchTemplate',side_effect=AssertionError('unnecessary gem/arrow match')):
   r=self.m.observe(self.f)
  self.assertTrue(any(m.kind=='aether' for m in r.markers))
 def test_disabled_character_arrow_never_launches_72_rotated_template_checks(self):
  with patch.object(self.m.arrow,'locate',side_effect=AssertionError('unused arrow')):r=self.m.observe(self.f)
  self.assertIsNone(r.character_heading)
 def test_character_arrow_remains_available_to_explicit_external_callers(self):
  m=MinimapVision({})
  with patch.object(m.arrow,'locate',return_value=(.9,100,100,30)) as locate:r=m.observe(self.f)
  locate.assert_called_once();self.assertEqual(r.character_heading,30)
 def test_engine_policy_restores_ground_matching_when_gem_fallback_is_allowed(self):
  self.e.policy=SimpleNamespace(allows=lambda name:False)
  with patch.object(self.m,'observe',return_value='r'):
   self.assertEqual(self.e._observe_minimap(self.f),'r');self.assertEqual(self.m.active_kinds,{'aether'})
   self.e.policy.allows=lambda name:True;self.e._observe_minimap(self.f)
  self.assertEqual(self.m.active_kinds,{'aether','gem'})
 def test_same_ether_positions_are_retained_when_ground_matching_is_disabled(self):
  both=self.m.observe(self.f);self.m.active_kinds={'aether'};only=self.m.observe(self.f)
  self.assertEqual([(m.x,m.y) for m in both.markers if m.kind=='aether'],[(m.x,m.y) for m in only.markers])
 def test_camera_cone_is_still_measured_when_character_arrow_is_disabled(self):
  with patch.object(self.m,'cone_geometry',return_value=(90,.9,40)):r=self.m.observe(self.f)
  self.assertEqual((r.heading,r.confidence,r.cone_half_angle),(90,.9,40))

class ExactPanelMemo(unittest.TestCase):
 def setUp(self):
  vision._panel_memo.cache=OrderedDict();self.addCleanup(lambda:setattr(vision._panel_memo,'cache',OrderedDict()))
  self.f=np.zeros((720,1280,3),np.uint8)
 def test_repeated_guards_on_identical_pixels_detect_the_panel_once(self):
  with patch.object(vision,'_gathering_panel_pair_uncached',return_value=False) as detector:
   self.assertFalse(vision.gathering_panel_pair(self.f));self.assertFalse(vision.gathering_panel_pair(self.f.copy()))
  self.assertEqual(detector.call_count,1)
 def test_changed_panel_pixels_are_rechecked_even_in_the_same_array(self):
  with patch.object(vision,'_gathering_panel_pair_uncached',side_effect=(False,True)) as detector:
   self.assertFalse(vision.gathering_panel_pair(self.f));self.f[500,700]=255
   self.assertTrue(vision.gathering_panel_pair(self.f))
  self.assertEqual(detector.call_count,2)
 def test_changed_label_template_invalidates_previous_evidence(self):
  with patch.object(vision,'_gathering_panel_pair_uncached',side_effect=(False,True)):
   self.assertFalse(vision.gathering_panel_pair(self.f))
   with patch.object(vision,'_failure_label',np.ones((5,5),np.uint8)):self.assertTrue(vision.gathering_panel_pair(self.f))
 def test_unrelated_world_pixels_do_not_repeat_identical_ui_work(self):
  with patch.object(vision,'_gathering_panel_pair_uncached',return_value=False) as detector:
   vision.gathering_panel_pair(self.f);self.f[10,10]=255;vision.gathering_panel_pair(self.f)
  self.assertEqual(detector.call_count,1)
 def test_cache_remains_bounded_and_never_keeps_full_frames(self):
  with patch.object(vision,'_gathering_panel_pair_uncached',return_value=False):
   for i in range(15):self.f[500,700]=i;vision.gathering_panel_pair(self.f)
  self.assertEqual(len(vision._panel_memo.cache),8)
  self.assertTrue(all(isinstance(v,bool) for v in vision._panel_memo.cache.values()))
 def test_actual_panel_can_disappear_and_reappear_without_stale_reuse(self):
  f=np.full((1440,2560,3),35,np.uint8);panel=cv2.imread(str(Path(__file__).parent/'testdata/current_gather_panel.png'))
  f[1014:1172,930:1630]=panel
  self.assertTrue(vision.gathering_panel_pair(f));f[1014:1172,930:1630]=35
  self.assertFalse(vision.gathering_panel_pair(f));f[1014:1172,930:1630]=panel
  self.assertTrue(vision.gathering_panel_pair(f))

if __name__=='__main__':unittest.main()
