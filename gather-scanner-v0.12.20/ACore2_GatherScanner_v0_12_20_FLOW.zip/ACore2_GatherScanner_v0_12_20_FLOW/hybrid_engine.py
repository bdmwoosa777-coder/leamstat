"""Classic resource state machine + fast minimap driver + asynchronous detours."""
from dataclasses import replace
import math,time,threading
import cv2
from gather_engine import GatherEngine,OWN_RESOURCE
from hybrid_navigation import RouteAdvisor,HybridPlanner
from navigation import Drive
from vision import gathering_panel_pair,find_resource_near,find_world_resource,fast_ether_candidates,read_world_caption,Observation
from return_exit import purple_anchor
from xbox_bridge import XboxBridge
from map_teleport import same_stamp,is_map,menu_stamp
from idle_return import map_evidence
from caption_memory import CaptionMemory
from camp_departure import CampDeparture
from resource_liveness import ResourceLiveness
from ether_neighbors import EtherNeighbors,same_caption

class HybridGatherEngine(GatherEngine):
 def _make_bridge(self,gamepad,cfg,emit):
  if cfg.get('control_transport','xbox')=='lua' or gamepad is None:return super()._make_bridge(gamepad,cfg,emit)
  return XboxBridge(gamepad,self.stop_event,lambda:self.screen.focused(),lambda:self.map_active and self.map_teleport is not None,cfg.get('dry_run',False),emit)
 def _wait_keyboard_alt_state(self,desired,seconds=.6):
  if not getattr(self.bridge,'controller_native',False):return super()._wait_keyboard_alt_state(desired,seconds)
  if self._focus_ok() and bool(self.bridge.alt_is_down())==desired:return True
  self.halt_reason='Режим курсора Xbox LB+LT не подтверждён в отчёте';self.say(self.halt_reason);self.stop();return False
 def _preflight_receiver(self):
  if not getattr(self.bridge,'controller_native',False):return super()._preflight_receiver()
  until=time.monotonic()+10
  while not self.stop_event.is_set() and not self.screen.focused():
   if time.monotonic()>=until:self.halt_reason='Окно AION2 не активно';return False
   if self.stop_event.wait(.05):return False
  if not self._focus_ok():return False
  self._neutral();self.receiver_ready=False
  try:
   if not self.bridge.send('ALT_DOWN') or not self._wait_alt_state(True):return False
   self.bridge.send('ALT_UP')
   if not self._wait_alt_state(False):return False
   self.receiver_ready=True;self.say('Xbox готов: отчёты LB+LT вниз/вверх переданы без A. Lua/G9 не нужны; реакция игры проверяется по кадру, это не игровой ACK')
   return True
  finally:self.bridge.send('ALT_UP')
 def __init__(self,cfg,*args,**kwargs):
  enabled=cfg.get('analyzer_enabled',True)
  super().__init__({**cfg,'analyzer_enabled':False},*args,**kwargs)
  self.cfg['analyzer_enabled']=enabled
  self.cfg['continuous_patrol_defense']=True
  self.cfg['defense_tab_limit']=max(3,min(8,int(cfg.get('defense_max_tabs',8))))
  self.world_process=None
  if cfg.get('isolate_vision_processes',False):
   from isolated_vision import WorldProcess
   self.world_process=WorldProcess(self.say)
  self.map_exit_failure=None
  self.native_close_after=0
  self.analyzer=RouteAdvisor(self.cfg,self.say) if enabled and self.scene_host is not None else None
  self.hybrid=HybridPlanner(cfg.get('camera_yaw_sign',1));self.hybrid_note=-1e9;self.hybrid_camp_check=-1e9;self.hybrid_identity_note=-1e9;self.hybrid_camp_pending=False;self.caption_latch=None;self.caption_after=0
  self.fast_sight_after=0;self.scan_checked_pulse=None
  self.camp_route=None;self.camp_rearm=True;self.sprint_surface_until=0;self.hybrid_goal_context=(self.nav.goal_epoch,None,False)
  self.interrupted_reacquire_key=None;self.interrupted_reacquire_until=None
  self.continuation_watch=None;self.continuation_check_after=0
  self.caption_memory=CaptionMemory()
  self.wall_escape_after=0
  self.obstacle_jump_pending=False;self.obstacle_action_until=0
  self.ether_neighbors=EtherNeighbors();self.neighbor_check_after=0
  self.ether_handoff_until=0;self.ether_handoff_candidate=None;self.ether_handoff_previous=None
  self.ether_handoff_point=None;self.ether_handoff_identity_until=0
  self.resource_liveness=ResourceLiveness();self.resource_wait_note=-1e9
  self.automatic_recovery=None;self.observers_check_after=0;self.death_wait=False;self.death_absent_since=None
  self.network_restart_after=0
  if self.gamepad is not None:self.gamepad.translation_lease_floor=float(self.cfg.get('smooth_translation_seconds',.75))
  if self.gamepad is not None:self.gamepad.sprint_repeat_seconds=max(1.,float(self.cfg.get('patrol_sprint_repeat_seconds',3.0)))
  # One progress watchdog owns detours. The legacy one stores screen-band IDs,
  # which are unsuitable for avoidance across camera changes.
  self.scene_pilot.follower.observe_progress=lambda *a:False
  self.say('HYBRID 0.12.20: курс к ресурсу, приоритет свежего эфира и ударов; выход из ошибки карты без остановки поиска')
 def change_mode(self,mode):
  previous=getattr(self,'mode',None)
  super().change_mode(mode)
  if hasattr(self,'hybrid') and mode!=previous:
   self.hybrid.reset_progress(clear_routes=mode!='SEARCH')
  if mode!=previous and mode in ('RETURN','MAP_RETURN') and hasattr(self,'camp_route'):
   self.camp_route=None;self.hybrid_camp_pending=False;self.camp_exit_until=0;self.camp_rearm=True
 def say(self,text):
  self.last_control_note=text;super().say(text)
 def stop(self,manual=False,terminal=False):
  if manual or terminal or self.alert=='CAPTCHA':return super().stop(manual=manual,terminal=terminal)
  if self.stop_event.is_set():return
  now=time.monotonic();reason=self.halt_reason or getattr(self,'last_control_note','ошибка состояния')
  if self.automatic_recovery is None:
   self.automatic_recovery={'reason':reason,'since':now,'map_sent':None}
   self.say('AUTO_RECOVER: '+reason+'; процесс, наблюдение и защита не выключаются')
  self.halt_reason=None
  try:self._stop_defense_motion();self._neutral();self._release_inputs()
  except Exception as exc:self.emit('AUTO_RECOVER: освобождение ввода: '+str(exc))
 def trigger_alarm(self,kind,frame):
  if kind=='CAPTCHA':return super().trigger_alarm(kind,frame)
  if self.stop_event.is_set() or self.death_wait:return
  self.death_wait=True;self.death_absent_since=None;self.stop()
  self.say('DEATH_RECOVER: окно смерти; сигнал и наблюдение продолжаются, после воскрешения продолжу автоматически')
  try:self.death_alarm.start(self.cfg.get('audio_device','AG271QG4'),error_cb=self.emit)
  except Exception as exc:self.emit('Ошибка звука: '+str(exc))
 def _runtime_failure(self,exc):
  if self.stop_event.is_set():return False
  self.halt_reason='Ошибка рабочего цикла: '+repr(exc);self.stop();return True
 def _retry_runtime_setup(self):
  if self.stop_event.is_set():return False
  self.stop();return True
 def _ensure_observers(self,now):
  if now<self.observers_check_after or not self.safety_threads:return
  self.observers_check_after=now+2
  specs=((self._vision_loop,()),(self._health_fast_loop,()),(self._health_numeric_loop,()),
         (self._heartbeat_loop,()),(self._input_audit_loop,()),
         (self._dialog_loop,('CAPTCHA',self.cap,1.)),(self._dialog_loop,('DEATH',self.death,3.)))
  for i,worker in enumerate(tuple(self.safety_threads)):
   if not worker.is_alive() and not self.stop_event.is_set():
    target,args=specs[i];fresh=threading.Thread(target=target,args=args,daemon=True)
    self.safety_threads[i]=fresh;fresh.start();self.say('AUTO_RECOVER: восстановлен поток '+target.__name__)
 def _automatic_recovery_tick(self,frame,now):
  if self.stop_event.is_set():return True
  self._ensure_observers(now)
  if self.death_wait:
   self._neutral()
   if self.death.check(frame)[0]:self.death_absent_since=None;return True
   if self.death_absent_since is None:self.death_absent_since=now
   if now-self.death_absent_since<1:return True
   self.death_wait=False;self.death_alarm.stop();self.say('DEATH_RECOVER: окно исчезло; восстанавливаю поиск')
  recovery=self.automatic_recovery
  if recovery is None:return False
  self._neutral();self.f_disable()
  if not self._focus_ok():return True
  view=self._net_view()
  if self.network is not None and (not view or not view['ready']):
   process=getattr(self.network,'process',None);failed=bool(view and view.get('error')) or process is not None and process.poll() is not None
   restart=getattr(self.network,'recover',None)
   if failed and callable(restart) and now>=self.network_restart_after:
    self.network_restart_after=now+5
    try:restart();self.say('AUTO_RECOVER: сетевой модуль перезапущен, жду свежие данные')
    except Exception as exc:self.say('AUTO_RECOVER: повтор сетевого подключения: '+str(exc))
   return True
  if is_map(frame):
   if recovery['map_sent'] is None or now-recovery['map_sent']>=2:
    recovery['map_sent']=now;self.map_active=True
    allowed=lambda:self._focus_ok() and is_map(self.screen.frame()[0])
    if hasattr(self.bridge,'send_guarded'):self.bridge.send_guarded('MAP',allowed)
    elif allowed():self.bridge.send('MAP')
   return True
  self.map_active=False;self.map_teleport=None;self.map_exit_failure=None;self.return_sequence=None
  self.camera_in_progress=False;self.camera_gate_busy=False;self.click_busy=False;self.view_click_pending=False
  self._resource_liveness_tick(frame,now)
  if self._live_attempt(view) or self._own_collection(view) is not None or self.caption_latch is not None:
   self.automatic_recovery=None;self._adopt_network_collection();return False
  self._stop_defense_motion();self.network_defense=None;self.defense_restore_view=None;self.defense_air_view=None
  self.defense_camera_until=None;self.hp_next_defense=now;self.attacker_retry_after.clear()
  self.target=None;self.candidate=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
  self.resume_resource_id=None;self.reacquire_until=None;self._reset_resource_watch();self._clear_view_recovery()
  self.collection_cycle.reset();self.cycle_authorized=None;self.cycle_ui_note=None
  self.probe=None;self.pending_probe=None;self.patrol_escape=None;self.terrain_recovery=None
  self.return_exit_guard=False;self.exit_route=None;self.wing_close_pending=None;self.wing_close_started=None
  self.nav.finish_goal(now);self.hybrid.problem_since=None;self.hybrid.blocked_at=None
  with self.pitch.lock:
   self.pitch.pause_depth=0;self.pitch.paused_at=None;self.pitch.failed=False;self.pitch.returning=False
  self.view_guard=type(self.view_guard)()
  if self.budget.airborne:self.camera_alignment_due=None;self.rescue_air_search_until=now+5
  else:self.camera_alignment_due='после восстановления управления';self.camera_requested_at=now
  self.automatic_recovery=None;self.identity_valid_after=now;self.change_mode('SEARCH')
  self.say('AUTO_RECOVER: поиск возобновлён, защита включена');return False
 def _camp_departure_owns_recovery(self,now):
  return bool(self.hybrid_camp_pending and self.camp_route is not None
              and 0<=now-self.camp_route.started<90 and not self.return_exit_guard)
 def _resource_options(self,now):
  sample=getattr(self,'resource_radar',None)
  if (sample is None or not 0<=now-sample[1]<=1.5 or self.return_exit_guard
      or self.hybrid_camp_pending or self.map_active):return []
  radar,_=sample
  return [m for m in self.nav.available_markers(radar,now,self.budget.can_start())
          if self.policy.allows('Эфир' if m.kind=='aether' else 'Самоцвет')]
 def _start_return(self,frame,reading,now,view):
  options=self._resource_options(now)
  if options:
   if now>=getattr(self,'resource_return_note',0):
    self.resource_return_note=now+10
    self.say('RETURN_DEFER: на свежей миникарте есть ещё '+str(len(options))+' доступных отметок; продолжаю поиск вместо телепорта')
   return False
  if self._camp_departure_owns_recovery(now):
   if now>=getattr(self,'camp_return_note',0):
    self.camp_return_note=now+15
    self.say('CAMP_RETURN_DEFER: сначала текущий выход из лагеря; старый таймер добычи не запускает повторный возврат')
   return False
  return super()._start_return(frame,reading,now,view)
 def _start_map_teleport(self,now):
  if self._resource_options(now):
   self.return_sequence=None;self.pitch.resume_return(now);self.change_mode('SEARCH')
   self.say('RETURN_DEFER: перед открытием карты появились доступные ресурсы; возвращаюсь к поиску')
   return False
  return super()._start_map_teleport(now)
 def _no_yield_rescue_allowed(self,now):
  if self._camp_departure_owns_recovery(now) or self._resource_options(now):return False
  # Ninety seconds without loot is not evidence that walking needs takeoff.
  return self.terrain_watch.due(now)
 def bridge_cmd(self,command):
  native=getattr(self.bridge,'controller_native',False)
  free_close=(command=='END_AIR' and native and self.mode in ('SEARCH','ACQUIRE_WAIT','RESCUE','PROBE','PATROL_ESCAPE') and not self.target_confirmed and not self.resource_hold)
  if free_close and time.monotonic()<getattr(self,'native_close_after',0):return False
  sent=super().bridge_cmd(command)
  if free_close and sent:
   self.native_close_after=time.monotonic()+8;self.rescue_air_search_until=max(self.rescue_air_search_until,self.native_close_after)
  return sent
 def _service_wing_close(self,reading,now):
  if not getattr(self.bridge,'controller_native',False) or self.wing_close_pending is None:return super()._service_wing_close(reading,now)
  if not reading.confirmed:return super()._service_wing_close(reading,now)
  if now-self.wing_close_pending<3:self._neutral();return True
  self.wing_close_pending=None;self.wing_close_started=None;self.wing_close_retries=0
  self.rescue_air_search_until=max(self.rescue_air_search_until,now+5);self.nav.pause(now)
  self.say('AIR_CLOSE: одна Y уже передана; исчезновение дуги не подтверждено, повтор при падении запрещён. Продолжаю поиск без новой Y')
  return False
 def _map_teleport_failed(self,observation,reason,now):
  if self.map_teleport is None or self.map_teleport.used:
   return super()._map_teleport_failed(observation,reason,now)
  self._neutral();self.map_exit_failure={'reason':reason,'since':now,'sent':False,'absent':None}
  self.say('MAP_RECOVER: телепорт не подтверждался; закрываю карту и возвращаю поиск после проверки игрового экрана: '+reason)
 def _map_failure_exit_tick(self,frame,now):
  failure=self.map_exit_failure
  if failure is None:return False
  self._neutral()
  if not self._focus_ok():return True
  if not self._map_input_ready():
   self.halt_reason='MAP_RECOVER: сеть или сбор запрещают ввод';self.say(self.halt_reason);self.stop();return True
  opened=same_stamp(frame,self.map_menu_stamp) or is_map(frame)
  evidence=map_evidence(frame,self.minimap.bounds(frame))
  if opened:
   failure['absent']=None
   if not failure['sent']:
    if self.map_menu_stamp is None:self.map_menu_stamp=menu_stamp(frame)
    failure['sent']=True # A partially delivered toggle must not be repeated.
    if hasattr(self.bridge,'send_guarded'):self.bridge.send_guarded('MAP',lambda:self._map_input_ready(menu=True))
    else:self.bridge_cmd('MAP')
  elif evidence.usable and not evidence.loading:
   if failure['absent'] is None:failure['absent']=now
   if now-failure['absent']>=.6:
    self.bridge.send('STOP');self.map_teleport=None;self.map_active=False;self.map_exit_failure=None
    self.pitch.resume_return(now);self.return_exit_guard=False;self.exit_route=None
    self.no_yield.next_return=max(self.no_yield.next_return,self.map_return_after,now+60)
    self.nav.exclude_goal(now,30);self.nav.pause(now);self.terrain_watch.attempted(now)
    self.hybrid=HybridPlanner(self.cfg.get('camera_yaw_sign',1));self.scene_camera_epoch+=1
    self.identity_valid_after=now;self.change_mode('SEARCH')
    self.say('MAP_RECOVER: игровой экран подтверждён; продолжаю поиск, телепорт успешным не считаю')
    return True
  else:failure['absent']=None
  if now-failure['since']>8:
   self.halt_reason='MAP_RECOVER: закрытие карты не подтверждено за 8 с';self.say(self.halt_reason);self.stop()
  return True
 def _network_defense_tick(self,now):
  if self.network_defense is None and self.mode!='DEFENSE' and self.defense_restore_view is None:
   if self._net_defense(now):return True
  return super()._network_defense_tick(now)
 def _net_defense(self,now):
  if self.mode in ('RESCUE','PROBE','PATROL_ESCAPE'):
   if not self._pending_network_hits(now):return False
   self._neutral();self.caption_latch=None;self.terrain_recovery=None;self.probe=None;self.pending_probe=None;self.patrol_escape=None
   self.pitch.resume_return(now);self.change_mode('SEARCH')
  return super()._net_defense(now)
 def save_debug(self,frame,label):
  if not self.cfg.get('debug_screenshots'):return
  try:
   self.screenshot_path.mkdir(exist_ok=True)
   safe=''.join(c for c in label if c.isalnum() or c=='_')[:80]
   file=self.screenshot_path/('hybrid_'+str(time.time_ns())+'_'+safe+'.jpg')
   if not cv2.imwrite(str(file),frame,[cv2.IMWRITE_JPEG_QUALITY,90]):return
   files=sorted(self.screenshot_path.glob('hybrid_*.jpg'),key=lambda p:p.name);total=sum(p.stat().st_size for p in files)
   while files and (len(files)>60 or total>64*1024*1024):
    old=files.pop(0);total-=old.stat().st_size;old.unlink()
  except (OSError,cv2.error) as exc:self.say('DEBUG_SAVE: '+str(exc)+'; управление продолжается')

 def _caption_rejected(self,candidate):
  return bool(self.caption_memory.rejected(candidate,time.monotonic()))
 def _retired_collection(self,view,node):
  return self.resource_liveness.retired(view,node)
 def _adopt_network_collection(self):
  adopted=super()._adopt_network_collection()
  if self.hybrid_camp_pending and self.target_confirmed and self._net_gather_proof():
   self.hybrid_camp_pending=False;self.camp_exit_until=0;self.camp_route=None
   self.say('CAMP_DONE: собственный сбор подтверждён; ресурс действительно доступен')
  if self.hybrid.problem_since is not None and self.target_confirmed and self._net_gather_proof():
   self.hybrid.problem_since=None;self.hybrid.blocked_at=None
  return adopted
 def _allowed(self,candidate,now):
  return not self._caption_rejected(candidate) and super()._allowed(candidate,now)
 def _acquire_miss(self,candidate,now):
  self.caption_latch=None
  super()._acquire_miss(candidate,now)
 def _acquire_caption_matches(self,frame,candidate):
  if candidate.name!='Эфир':return True
  if self._caption_rejected(candidate):return False
  x,y,w,h=candidate.box
  if candidate.emblem is not None:
   ex,ey,ew,eh=candidate.emblem;gap=y-ey-eh
   if not (-2<=gap<=max(12,h*1.7) and abs(ex+ew/2-x-w/2)<=max(10,w*.30)):
    self.say(f'ACQUIRE_REJECT: ромбик не привязан к подписи Эфир; caption={candidate.box}, emblem={candidate.emblem}')
    return False
  current,_=self.screen.frame();name,text=read_world_caption(current,candidate,self._owned_resource_names())
  self.say(f'ACQUIRE_POINT: ожидаю Эфир; локальное имя={name}, текст={text[:60]!r}, caption={candidate.box}, emblem={candidate.emblem}')
  if name is None and ''.join(c for c in text.casefold() if c.isalpha()) in ('войти','отмена','закрыть'):
   self.caption_memory.remember(candidate,'UI: '+text.strip(),time.monotonic())
   self.say('ACQUIRE_REJECT: надпись интерфейса '+repr(text.strip())+' вместо ресурса; A не отправлена')
   return False
  if name is not None and name!=candidate.name:
   self.caption_memory.remember(candidate,name,time.monotonic())
   self.say('ACQUIRE_REJECT: локальная подпись '+name+' противоречит Эфиру; A не отправлена')
   return False
  return self._focus_ok()
 def _completed_wait_proof(self,view):
  if (not view or not view['ready'] or self.network_target is None or self.mode!='GATHER' or self.map_active
      or not self.target_confirmed or not self.resource_hold or not self.real_gather_panel_seen):return None
  state=view['state'];node=self._net_node(view);result=state.last_own_result
  if (node is None or node.actor!=self.network_target[1] or not node.visible or node.gather_time is None or node.used not in (1,2)
      or state.own is None or view['flow']!=self.network_target[0]
      or self.network_owner is not None and state.own!=self.network_owner
      or state.collecting!=node.actor or state.selected not in (0,node.actor) or state.attempt_active
      or node.actor in state.npcs or node.actor in state.players
      or not result or result[0]!=node.actor or state.last_own_result_used!=node.used
      or result[1]<max(self.network_claimed_at,node.gather_time,state.started or 0)):return None
  return (self.network_target,state.own,node.gather_time,state.started,state.attempt_ordinal,node.used,result[1])
 def _completed_point_wait_tick(self,frame,now):
  if self.stop_event.is_set() or not self._focus_ok():
   self.continuation_watch=None;return False
  if self.network is None or self.click_busy or now<self.continuation_check_after:return False
  self.continuation_check_after=now+.20
  view=self._net_view();proof=self._completed_wait_proof(view)
  if proof is None or gathering_panel_pair(frame) or self._fresh_click_candidate(frame) is not None:
   self.continuation_watch=None;return False
  if self.continuation_watch is None or self.continuation_watch['proof']!=proof:
   self.continuation_watch={'proof':proof,'since':now}
   self.say('CONTINUATION_WAIT: собственная попытка окончена, свежая точка потеряна; не более 8 с на восстановление')
   return False
  if now-self.continuation_watch['since']<8:return False
  current,_=self.screen.frame();latest=self._net_view()
  if (self._completed_wait_proof(latest)!=proof or gathering_panel_pair(current)
      or self._fresh_click_candidate(current) is not None):
   self.continuation_watch=None;return False
  self._release_resource_wait(latest,now,'CONTINUATION_RELEASE: 8 с без точки после подтверждённого окончания')
  return True
 def _release_resource_wait(self,view,now,reason,retire=False,hard=False):
  node=self._net_node(view) or view['state'].nodes.get(view['state'].collecting)
  binding=self.network_target or (view['flow'],node.actor)
  if retire and node is not None:self.resource_liveness.retire(view,node,hard)
  self._neutral();self.f_disable()
  self.resource_retry_after[binding]=now+45
  if node is not None:self.abandoned_lease=(*binding,node.gather_time)
  self._clear_view_recovery();self.collection_cycle.reset();self.cycle_authorized=None;self.cycle_ui_note=None
  self.target=None;self.candidate=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
  self.resume_resource_id=None;self.reacquire_until=None;self.missing_since=None;self._reset_resource_watch()
  self.nav.exclude_goal(now,45);self.pitch.restore(now)
  self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
  self.continuation_watch=None;self.change_mode('SEARCH');self.identity_valid_after=now
  self.resource_liveness.reset()
  self.say(reason+'; цель отложена на 45 с, поиск и защита продолжаются без нового A/B/Y')
 def _resource_wait_proof(self,view):
  if not view or not view['ready'] or self.map_active:return None
  s=view['state'];node=self._net_node(view)
  private=node is None and s.started is not None and s.attempt_active and s.collecting in s.nodes
  if private:node=s.nodes[s.collecting]
  if (node is None or s.own is None
      or not node.visible or node.used==3 or node.actor in s.npcs or node.actor in s.players
      or self._retired_collection(view,node)):return None
  if not private and (not self.target_confirmed or self.mode not in ('APPROACH','TAKEOFF','GATHER','REACQUIRE')):return None
  own=s.collecting==node.actor and s.started is not None
  if not own and self._live_attempt(view):return None
  result=s.last_own_result if s.last_own_result and s.last_own_result[0]==node.actor else None
  key=(self.resource_liveness.attempt(view,node),node.used,result,self.last_distance if not own else None)
  return key,12 if own else 20,own
 def _resource_liveness_tick(self,frame,now):
  if (not self._focus_ok() or self.click_busy or self.map_active or self.camera_in_progress):
   self.resource_liveness.reset();return False
  view=self._net_view()
  if not view or not view['ready']:self.resource_liveness.reset();return False
  panel=gathering_panel_pair(frame)
  pending=view['state'].nodes.get(view['state'].collecting)
  if panel and self._retired_collection(view,pending) and not self.resource_liveness.hard(view,pending):
   self.resource_liveness.restore(view,pending);self._adopt_network_collection()
   self.say('RESOURCE_ALIVE: нижняя шкала вернулась; собственный сбор принят без клика')
  proof=self._resource_wait_proof(view)
  if not proof:self.resource_liveness.reset();return False
  key,seconds,own=proof
  node=self._net_node(view) or pending
  attempt=self.resource_liveness.attempt(view,node) if own and view['state'].attempt_active else None
  began=max(view['state'].started or 0,node.gather_time or 0) if attempt else 0
  age=(time.time()*1000-began)/1000 if began else None
  if age is not None and not 0<=age<=300:age=None
  hard=self.resource_liveness.expired_attempt(attempt,now,age)
  if not hard and not self.resource_liveness.due(key,now,panel,seconds):return False
  current,_=self.screen.frame();latest=self._net_view()
  if (not hard and gathering_panel_pair(current)) or self._resource_wait_proof(latest)!=proof:
   self.resource_liveness.reset();return False
  self._release_resource_wait(latest,now,
      'RESOURCE_ALIVE: попытка превысила предел 15 с' if hard else 'RESOURCE_ALIVE: '+str(seconds)+' с без нижней шкалы и нового состояния попытки',retire=own,hard=hard)
  return True
 def _recover_resource_wait(self,frame,reading,now,kind):
  if self.network is None:return False
  if self._resource_liveness_tick(frame,now):return True
  # Visible collection is productive waiting, not a reason to switch off
  # the entire process and its defense/network/dialog services.
  self.started=now;self.collection_activity_at=now
  if now-self.resource_wait_note>=5:
   self.resource_wait_note=now;self.say('RESOURCE_ALIVE: тайм-аут '+kind+' не выключает бот; перепроверка сбора, защита остаётся включена')
  return True
 def _resource_fast_tick(self,frame,reading,now,panel=None,slots=None):
  self._adopt_network_collection()
  if self._resource_liveness_tick(frame,now):return True
  if self._completed_point_wait_tick(frame,now):return True
  return super()._resource_fast_tick(frame,reading,now,panel,slots)
 def _needs_visual_hp(self):
  if self.network is None:return True
  if not hasattr(self.network,'confirm_own_hp'):return False
  view=self._net_view();return bool(view and view['ready'] and view['state'].own is None)
 def _health_identity_sample(self,value,captured,verified):
  if self.network is None or not hasattr(self.network,'confirm_own_hp') or not verified or value is None or value.current>=value.maximum or not self._focus_ok() or not self._needs_visual_hp():return
  self.network.confirm_own_hp(value.current,value.maximum,int((time.time()-time.monotonic()+captured)*1000))
 def _world_resource(self,frame,names):
  if self.world_process is None:return super()._world_resource(frame,names)
  with self.caption_memory.lock:entries=self.caption_memory.entries
  return self.world_process.search(frame,names,entries,self.stop_event)
 def _network_world_observation(self,frame):
  if self.mode=='RESCUE' and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE':
   return Observation(find_world_resource(frame,('Эфир',)),None,None,False,0,False,None,'HIDDEN')
  observation=super()._network_world_observation(frame)
  now=time.monotonic()
  if (self.cfg.get('ether_neighbor_handoff',False) and self.mode=='GATHER' and self.target=='Эфир'
      and not self.map_active and not self.camera_in_progress and now>=self.neighbor_check_after):
   self.neighbor_check_after=now+1
   view=self._net_view();owned=self._own_collection(view)
   previous=observation.candidate or self.candidate
   if owned is not None and previous is not None:
    choices=fast_ether_candidates(frame,('Эфир',),deadline=time.monotonic()+.18,rejected=self._caption_rejected)
    # Sightings are data only: they never replace the owned observation and
    # cannot send A or camera input while any of its attempts remain.
    if self.mode=='GATHER' and self.target=='Эфир':
     self.ether_neighbors.observe(self._neighbor_key(view),choices,previous,now)
  return observation
 def _neighbor_key(self,view):
  if not view or not view['ready'] or view['state'].own is None:return None
  s=view['state'];return view['flow'],s.own,s.map_id
 def _prepare_next_ether_view(self,frame,now):
  self.ether_handoff_until=0;self.ether_handoff_identity_until=0
  if (not self.cfg.get('ether_neighbor_handoff',False) or self.stop_event.is_set() or not self._focus_ok()
      or self.map_active or self.pitch.returning or self.pitch.failed or not self.budget.can_start()):return False
  view=self._net_view();node=self._net_node(view)
  if (not view or not view['ready'] or self._live_attempt(view) or node is None
      or not (node.used==3 or not node.visible and node.removed_reason==4)):return False
  previous=self.candidate
  if previous is None:return False
  if frame is None:frame,_=self.screen.frame()
  key=self._neighbor_key(view)
  candidates=self.ether_neighbors.current(key,now)
  if not candidates:
   choices=fast_ether_candidates(frame,('Эфир',),deadline=time.monotonic()+.18,rejected=self._caption_rejected)
   self.ether_neighbors.observe(key,choices,previous,now);candidates=self.ether_neighbors.current(key,now)
  for candidate in candidates:
   fresh=find_resource_near(frame,candidate)
   if fresh is None or same_caption(fresh,previous) or self._caption_rejected(fresh):continue
   # The final SEARCH frame will verify it again after the landing/fold.
   self.ether_handoff_candidate=fresh;self.ether_handoff_previous=previous
   self.ether_handoff_point=(previous.click_x,previous.click_y)
   self.ether_handoff_until=time.monotonic()+2.5;self.ether_handoff_identity_until=self.ether_handoff_until+2
   self.camera_alignment_due=None
   self.say('ETHER_NEIGHBOR: соседний эфир виден; после завершённых 3/3 сначала проверю его, без опускания камеры')
   return True
  return False
 def _cooldown_blocks(self,candidate,x,y):
  if (candidate.name=='Эфир' and time.monotonic()<self.ether_handoff_identity_until
      and self.ether_handoff_point==(x,y) and same_caption(candidate,self.ether_handoff_candidate)
      and not same_caption(candidate,self.ether_handoff_previous)):return False
  return super()._cooldown_blocks(candidate,x,y)
 def _handoff_frame(self,frame,obs,now):
  if not self.ether_handoff_until or self.mode not in ('SEARCH','ACQUIRE_WAIT'):return obs
  if now<self.post_gather_until:return obs
  view=self._net_view()
  if (self.stop_event.is_set() or self.map_active or not self._focus_ok()
      or not view or not view['ready'] or self._neighbor_key(view)!=self.ether_neighbors.key
      or self._live_attempt(view) or self._own_collection(view) is not None):
   self.ether_handoff_until=0;return obs
  fresh=find_resource_near(frame,self.ether_handoff_candidate) if now<self.ether_handoff_until else None
  if fresh is not None and not same_caption(fresh,self.ether_handoff_previous):
   pose,baseline=self.pitch.capture(time.monotonic())
   self._candidate_observed(fresh,time.monotonic(),pose,baseline)
   if self.caption_latch is not None:
    self.ether_handoff_until=0;return replace(obs,candidate=fresh)
  self.ether_handoff_until=0;self.ether_handoff_identity_until=0
  self.camera_alignment_due='соседний эфир больше не подтверждён';self.camera_requested_at=now
  self._restore_pitch();return obs
 def _candidate_observed(self,candidate,captured,pose,baseline=None):
  now=time.monotonic()
  if self._caption_rejected(candidate):return
  rescue=self.mode=='RESCUE' and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE'
  if (candidate.name not in self.cfg['target_names'] or self.caption_latch is not None or self.mode not in ('SEARCH','ACQUIRE_WAIT') and not (rescue and candidate.name=='Эфир')
      or self.target_confirmed or self.resource_hold or self.click_busy or self.camera_in_progress
      or self.map_active or self.return_exit_guard or self.pitch.returning or self.pitch.failed or not self.cfg.get('allow_click',True)
      or now<self.caption_after or now<self.defense_evade_until
      or not self.policy.allows(candidate.name) or candidate.name=='Эфир' and not self.budget.can_start()
      or self.nav.is_retreating(now)
      or not self._focus_ok() or not 0<=now-captured<=1.5):return
  if any(n==candidate.name and until>now and self._cooldown_blocks(candidate,x,y) for n,x,y,until in self.cooldowns):return
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None or self._live_attempt(view)):return
  if now-captured>.8:
   current,_=self.screen.frame();fresh=find_resource_near(current,candidate)
   if fresh is None:return
   candidate=fresh;pose,baseline=self.pitch.capture(time.monotonic())
  self.caption_latch={'candidate':candidate,'pose':pose,'baseline':self.pitch.baseline_revision if baseline is None else baseline,'until':time.monotonic()+2.5,'restored':False,'settle':0}
  if candidate.name=='Эфир':
   self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
   self.wing_close_pending=None;self.wing_close_started=None;self.wing_close_retries=0
  self._neutral() # Stop as soon as recognition completes, not after the next full navigation tick.
  # A caption pauses the exit through the normal acquisition state. Only
  # actual own gathering or measured departure may complete that exit.
  self.say(('ETHER_SIGHT' if candidate.name=='Эфир' else 'RESOURCE_SIGHT')+': '+candidate.name+' замечен; проверяю ромбик на свежем кадре без обязательного подхода вплотную')
 def _search_caption_priority(self,obs,now):
  # A fresh world caption over sky is actionable. A ground-view repair is
  # useful for walking, but must not turn away from a verified airborne node.
  return bool(self.caption_latch is not None and now<self.caption_latch['until']
              and obs.candidate is not None and self._allowed(obs.candidate,now))
 def _motion(self,plan):
  # A recognition callback can arrive after navigation has planned a turn.
  # Do not let that pending turn sweep a newly seen caption out of view.
  if getattr(self,'caption_latch',None) is not None and self.mode in ('SEARCH','ACQUIRE_WAIT'):
   self._neutral();return True
  result=super()._motion(plan)
  if result and self._obstacle_action_ready():self.hybrid.note_escape_motion(time.monotonic())
  jump=self.obstacle_jump_pending;self.obstacle_jump_pending=False
  if result and jump and self.gamepad is not None and hasattr(self.gamepad,'tap_moving_jump'):
   if not self.gamepad.tap_moving_jump(self.stop_event,self.screen.focused,self._obstacle_action_ready):self._neutral()
  if (result and self.gamepad is not None and hasattr(self.gamepad,'tap_sprint')
      and math.hypot(plan.forward,plan.strafe)>=.65 and abs(plan.yaw)+abs(plan.pitch)<.001):
   self.gamepad.tap_sprint(self.stop_event,self.screen.focused,self._sprint_input_ready)
  return result
 def _obstacle_action_ready(self):
  now=time.monotonic()
  if (now>=self.obstacle_action_until or self.hybrid.hazard_until>now or self.mode!='SEARCH'
      or self.stop_event.is_set() or not self._focus_ok() or self.map_active or self.click_busy
      or self.target_confirmed or self.resource_hold or self.collecting_visible or self.caption_latch is not None
      or self.budget.airborne or self.return_exit_guard or self.network_defense is not None
      or self.camera_in_progress or self.camera_alignment_due or self.pitch.returning
      or abs(self.pitch.offset(now))>.009):return False
  view=self._net_view()
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None or self._live_attempt(view)):return False
  frame,_=self.screen.frame()
  view=self._net_view()
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None or self._live_attempt(view)):return False
  return not gathering_panel_pair(frame) and self._translation_input_ready()
 def _sprint_input_ready(self):
  now=time.monotonic()
  if (not self.cfg.get('patrol_sprint',True) or not getattr(self.bridge,'controller_native',False)
      or self.mode!='SEARCH' or not self._focus_ok() or self.target_confirmed or self.resource_hold
      or self.collecting_visible or self.caption_latch is not None or self.click_busy or self.map_active
      or self.budget.airborne or self.return_exit_guard or self.hybrid_camp_pending and now>=self.obstacle_action_until or self.nav.air_since is not None
      or self.probe is not None or self.terrain_recovery is not None or self.patrol_escape is not None
      or self.network_defense is not None or self.defense_restore_view is not None
      or self.camera_in_progress or self.camera_alignment_due or self.pitch.returning
      or abs(self.pitch.offset(now))>.009 or now>=max(self.sprint_surface_until,self.obstacle_action_until) or self.nav.is_retreating(now)):
   return False
  if self.nav.goal is not None and self.nav.goal.distance<10*self.nav.last_scale:return False
  if now<self.obstacle_action_until and not self._obstacle_action_ready():return False
  if self.network is not None:
   view=self._net_view()
   if not view or not view['ready'] or self._own_collection(view) is not None or self._live_attempt(view):return False
  return self._translation_input_ready()
 def _terrain_recovery_tick(self,frame,reading,now,radar=None):
  if (self.caption_latch is not None and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE'
      and not self.target_confirmed and not self.resource_hold and self._own_collection() is None):
   self._neutral();self.terrain_recovery=None;self.pitch.resume_return(now);self.change_mode('SEARCH');self.nav.pause(now)
   self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
   self.say('ETHER_SIGHT: спасательный перелёт прерван свежей подписью; проверяю ресурс без закрытия крыльев')
   return False
  return super()._terrain_recovery_tick(frame,reading,now,radar)
 def _begin_reacquire(self,reason):
  super()._begin_reacquire(reason)
  self._bound_interrupted_reacquire(time.monotonic())
 def _bound_interrupted_reacquire(self,now):
  binding=self.defense_interrupted
  if binding is None or self.network_target!=binding[:2]:
   self.interrupted_reacquire_key=None;self.interrupted_reacquire_until=None;return
  if self.interrupted_reacquire_key!=binding:
   self.interrupted_reacquire_key=binding;self.interrupted_reacquire_until=now+8
   self.say('REACQUIRE_LIMIT: после прерывания боем до 8 с суммарно на возврат ресурса, включая камеру')
  deadline=self.interrupted_reacquire_until
  if self.reacquire_until is not None:self.reacquire_until=min(self.reacquire_until,deadline)
  if self.view_recovery is not None:self.view_recovery.until=min(self.view_recovery.until,deadline)
 def _restore_defense_camera(self):
  try:return super()._restore_defense_camera()
  finally:self._bound_interrupted_reacquire(time.monotonic())
 def _view_recovery_tick(self,frame,reading,now):
  self._bound_interrupted_reacquire(now)
  if (self.mode=='APPROACH' and self.route_f_sent and not self.real_gather_panel_seen
      and self.native_route_started_at is not None
      and (now-self.native_route_started_at<6 or now-self.last_progress<3)):
   self._clear_view_recovery();return False
  return super()._view_recovery_tick(frame,reading,now)
 def _start_terrain_recovery(self,now,reading,force_ground=False,short=False):
  fallen=self.working_area.rapid_drop(int(time.time()*1000))
  if not short and not fallen and (self._camp_departure_owns_recovery(now) or self._resource_options(now)):return False
  proven=now<self.hybrid.wall_flight_proven_until
  if short and not force_ground and not proven:return False
  ground_only=not short and not force_ground and not reading.confirmed and not fallen
  started=super()._start_terrain_recovery(now,reading,force_ground=force_ground or ground_only,short=short or ground_only)
  if started and ground_only:
   self.terrain_watch.attempted(now)
   self.say('GROUND_RESCUE: отсутствие результата не доказывает препятствие; наземный выход без открытия крыльев')
  return started
 def _caption_frame(self,frame,obs,now):
  latch=self.caption_latch
  if latch is None:return obs,False
  if (self.target_confirmed or self.resource_hold or self.mode not in ('SEARCH','ACQUIRE_WAIT')
      or self.map_active or not self._focus_ok() or self._own_collection() is not None):
   self.caption_latch=None;return obs,False
  if now>=latch['until']:
   self.caption_latch=None;self.caption_after=now+1;self.nav.air_since=None;self.nav.scan_kind=None
   return obs,False
  if not latch['restored']:
   self._neutral();error=latch['pose']-self.pitch.offset(now) if latch.get('baseline',self.pitch.baseline_revision)==self.pitch.baseline_revision else 0;latch['restored']=True
   if abs(error)>.006:
    seconds=min(.12,abs(error)/.45)
    self.gamepad.drive(0,0,0,.45 if error>0 else -.45,lifetime=seconds)
    latch['settle']=now+seconds+.2
    return obs,True
  if now<latch['settle']:return obs,True
  fresh=find_resource_near(frame,latch['candidate'])
  if fresh is not None:return replace(obs,candidate=fresh),False
  self._neutral();return obs,True
 def _camp_update(self,frame,radar,now,visible=False):
  if not self.cfg.get('hybrid_camp_exit',True) or self.return_exit_guard:return
  width=radar.bounds[2]-radar.bounds[0];scale=max(.5,width/313)
  if now-self.hybrid_camp_check>=.5:
   self.hybrid_camp_check=now
   near=self.camp_route.anchor if self.camp_route is not None else None
   if near is not None and radar.motion_valid:near=(near[0]+radar.displacement[0],near[1]+radar.displacement[1])
   anchor=purple_anchor(frame,radar.bounds,near=near)
   if anchor is not None:
    self.camp_last_seen=now
    close=math.dist(anchor,radar.center)<=26*scale
    if self.camp_route is None and close and self.camp_rearm and now>=self.camp_exit_retry_after and not visible:
     self.camp_route=CampDeparture(anchor,radar.center,width,now)
     self.camp_exit_until=self.camp_route.until;self.hybrid_camp_pending=True;self.camp_rearm=False
     self.nav.retreat_until=0;self.nav.retreat_pending=False;self.nav.escape_until=0
     self.hybrid.reset_progress(clear_routes=True)
     self.say('HYBRID_CAMP_EXIT: держу курс из лагеря; точки миникарты не отменяют выход')
    if self.camp_route is not None and self.camp_route.observe(anchor,radar.center,now):
     self.hybrid_camp_pending=False;self.camp_exit_until=0;self.camp_route=None
     self.hybrid.reset_progress(clear_routes=True)
     self.say('CAMP_DONE: удаление от кибелиска подтверждено его положением на миникарте')
   elif self.camp_route is None and now-self.camp_last_seen>=3:self.camp_rearm=True
  if self.hybrid_camp_pending and self.camp_route is not None:
   if now>=self.camp_exit_until:
    self.camp_route.replan(now);self.camp_exit_until=self.camp_route.until
    self.hybrid.reset_progress(clear_routes=True)
    self.say('CAMP_REPLAN: 35 с не подтвердили выход; меняю проход, выход из лагеря остаётся целью')

 def step(self,frame,origin,obs,radar,reading,now,sequence=0):
  if self.stop_event.is_set():return
  self.resource_radar=(radar,now)
  obs=self._handoff_frame(frame,obs,now)
  searching=self.mode in ('SEARCH','ACQUIRE_WAIT') and not self.resource_hold and not self.target_confirmed and not self.map_active and self._focus_ok()
  self.policy.observe_map(radar.markers,now,searching)
  prefer_air=self.policy.priority and self.policy.air_on_map and self.policy.allows('Эфир')
  if searching and prefer_air and not self.click_busy:
   radar=replace(radar,markers=[m for m in radar.markers if m.kind=='aether'])
   if self.nav.goal is not None and self.nav.goal.kind!='aether':self.nav.goal=None;self.nav.best_distance=None
   if self.caption_latch is not None and self.caption_latch['candidate'].name!='Эфир':self.caption_latch=None
   if self.mode=='ACQUIRE_WAIT' and self.candidate is not None and self.candidate.name!='Эфир':
    self.candidate=None;self.change_mode('SEARCH')
  goal=self.nav.goal
  looking=self.nav.air_since is not None
  near_goal=(goal is not None and goal.kind=='aether' and goal.distance<60*self.nav.last_scale)
  if (self.cfg.get('scan_frame_checks',True) and self.mode=='SEARCH' and (looking or near_goal)
      and self.caption_latch is None and not self.target_confirmed and not self.resource_hold
      and not self.map_active and self._focus_ok() and now>=self.fast_sight_after
      and now>=self.nav.scan_pulse_end and now>=self.caption_after and not self.pitch.returning
      and not self.camera_in_progress and not self.return_exit_guard and not self.nav.is_retreating(now)):
   # This frame was captured after the last pulse expired. Inspect it before
   # Navigator can send the next pulse, especially before the down bracket.
   self.fast_sight_after=now+(.18 if looking else .65)
   h,w=frame.shape[:2];pose,baseline=self.pitch.capture(time.monotonic())
   candidates=fast_ether_candidates(frame,('Эфир',),deadline=time.monotonic()+.20,
                                   bounds=(round(w*.02),round(h*.02),round(w*.98),round(h*.55)),rejected=self._caption_rejected)
   if candidates:
    self._candidate_observed(candidates[0],now,pose,baseline)
    if self.caption_latch is not None:obs=replace(obs,candidate=candidates[0])
   self.scan_checked_pulse=(self.nav.air_since,self.nav.scan_last_pulse)
  if self.caption_latch is not None:
   obs,waiting=self._caption_frame(frame,obs,now)
   if waiting:return
  if self.mode=='SEARCH' and not self.target_confirmed and not self.resource_hold and not reading.confirmed and not self.map_active:
   self._camp_update(frame,radar,now,obs.candidate is not None and self._allowed(obs.candidate,now))
   # Actual minimap progress owns its timer. A succession of visual detours
   # must not erase the fact that the destination never gets any closer.
  if self.hybrid_camp_pending and self.mode=='SEARCH' and not self.target_confirmed:
   # Policy has already observed the real markers above. Only navigation is
   # redirected: visible world captions can still enter normal acquisition.
   self.nav.goal=None;self.nav.best_distance=None;self.nav.air_since=None;self.nav.scan_kind=None
   radar=replace(radar,markers=[])
  return super().step(frame,origin,obs,radar,reading,now,sequence)
 def _scene_plan(self,frame,radar,reading,plan,now):
  self.obstacle_action_until=0;self.obstacle_jump_pending=False
  context=(self.nav.goal_epoch,self.nav.goal.kind if self.nav.goal is not None else None,now<self.camp_exit_until)
  if context!=self.hybrid_goal_context:
   self.hybrid_goal_context=context;self.hybrid.reset_progress(clear_routes=True)
  camp_ground=(now<self.camp_exit_until and self.mode=='SEARCH' and not self.return_exit_guard
               and not self.target_confirmed and not self.resource_hold and not self.map_active
               and not reading.confirmed and not self.budget.airborne)
  if camp_ground and not self.pitch.returning:
   # Empty-map patrol (including its camera/flight proposal) cannot override
   # the still-unfinished departure. Restore a real tilt before ground routing.
   plan=(Drive(restore_pitch=True,reason='возвращаю землю в обзор для выхода из лагеря')
         if abs(self.pitch.offset(now))>.015 else Drive(.6,reason='продолжаю выход из лагеря'))
  if abs(plan.pitch)>.001 or plan.restore_pitch or self.nav.air_since is not None:
   # An intentional sky scan is not eight seconds of failed walking.
   self.hybrid.reset_progress(clear_routes=True)
  if (self.scene_host is None or self.cfg.get('dry_run') or self.mode!='SEARCH' or self.target_confirmed
      or self.resource_hold or self.collecting_visible or self.caption_latch is not None or self.map_active or reading.confirmed or self.budget.airborne
      or self.camera_alignment_due or self.pitch.returning or abs(self.pitch.offset(now))>.015
      or not self._focus_ok() or abs(plan.pitch)>.001 or plan.restore_pitch or plan.flight_probe
      or math.hypot(plan.forward,plan.strafe)<.05):return plan
  if gathering_panel_pair(frame):
   live=self._net_view();pending=live['state'].nodes.get(live['state'].collecting) if live and live['ready'] else None
   if not self.resource_liveness.hard(live,pending):return plan
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None):return plan
  heading=radar.heading if radar.confidence>=.30 else None;pitch=self.pitch.offset(now)
  captured=time.monotonic()
  self.scene_host.offer(frame,captured,heading,pitch,self.scene_camera_epoch)
  result=self.scene_host.current(captured,heading,pitch,self.scene_camera_epoch)
  exit_mode=now<self.camp_exit_until
  if exit_mode:
   camp=self.camp_route
   if camp is not None:
    if result is not None and result.captured<max(camp.view_after,self.scene_settle_until):result=None
    bearing=camp.choose(heading,result.ground if result is not None else None,now)
    gate=camp.view_plan(heading,result is not None,now,self.hybrid.yaw_sign)
    if gate is None and bearing is None and result is not None and result.ground is not None and result.ground.routes and any(now<t for _,t in camp.failed):
     gate=camp.camera_pulse(now,.42*self.hybrid.yaw_sign,.16,'выход: прежний проход не подошёл; проверяю следующий ракурс')
    if gate is not None:
     self.hybrid.tracking=False;self.hybrid.last_progress=now
     self._camp_view_note(gate,radar,result,now)
     return gate
   else:bearing=None
   plan=(self.nav._move_to(bearing,heading,now,'выход из лагеря: сохраняю выбранный проход')
         if bearing is not None else Drive(.6,reason='ищу видимый наземный проход из лагеря'))
   # The camera gate owns facing. Steer the stick along this current image;
   # incidental navigation yaw must not destroy every following scene result.
   plan=replace(plan,yaw=0,yaw_lifetime=None)
  goal=self.nav.goal
  goal_bearing=math.degrees(math.atan2(goal.x-radar.center[0],radar.center[1]-goal.y))%360 if goal else None
  context={'mode':'camp_exit' if exit_mode else 'resources','kind':goal.kind if goal else None,
           'goal_bearing':round(goal_bearing) if goal_bearing is not None else None,
           'goal_relative':round((goal_bearing-heading+180)%360-180) if goal_bearing is not None and heading is not None else None,
           'failed_bearings':[round(b) for b,t in self.hybrid.avoid if now<t]}
  hint=None;warning=None
  if result is not None and result.ground is not None:
   relative=math.degrees(math.atan2(plan.strafe,plan.forward));lane=result.lanes[0 if relative< -18 else 2 if relative>18 else 1]
   wide=(not exit_mode and abs(relative)<60 and result.ground.drop_support<.04 and lane.free>=.45 and lane.solid<.12 and lane.edge<.012
         and (lane.free>=.60 or any(r.confidence>=.60 and r.clearance>=1 for r in result.ground.routes)))
   self.sprint_surface_until=min(captured+.6,result.captured+.9) if wide else 0
  if self.analyzer is not None and result is not None and result.ground is not None:
   relative=math.degrees(math.atan2(plan.strafe,plan.forward))
   lane=result.lanes[0 if relative< -18 else 2 if relative>18 else 1]
   clear=(abs(relative)<=80 and result.ground.drop_support<.04 and lane.free>=.55 and lane.solid<.18 and lane.edge<.02
          and any(r.confidence>=.60 for r in result.ground.routes))
   if exit_mode or not clear or self.hybrid.blocked_at is not None or self.hybrid.commit is not None and now<self.hybrid.commit_until:
    self.analyzer.offer(result.source if result.source is not None else frame,result.ground,result.captured,result.heading,result.pitch,context)
   hint=self.analyzer.recommend(result.ground,frame,captured,heading,pitch,context)
   warning=self.analyzer.warning(captured,heading,pitch,context)
  face_goal=bool(goal is not None and goal.kind=='aether' and not self.nav.is_retreating(now) and now>=self.nav.escape_until)
  action=self.hybrid.choose(plan,result,radar,now,hint,exit_mode,warning,face_goal=face_goal)
  if exit_mode and self.camp_route is not None:
   if action.detour:
    action.drive=replace(action.drive,yaw=0,yaw_lifetime=None)
   elif abs(action.drive.yaw)>.001:
    action.drive=self.camp_route.camera_pulse(now,action.drive.yaw,action.drive.yaw_lifetime or .12,action.reason)
  if action.escape:
   self.obstacle_action_until=time.monotonic()+.8;self.obstacle_jump_pending=action.jump
  if self.caption_latch is not None:return Drive()
  if action.recalibrate:
   if now>=self.scene_view_retry_after:
    self.scene_view_retry_after=now+3;self.scene_view_repair=True;self.nav.air_since=None;self.nav.scan_kind=None;self.view_guard.force(now)
   return Drive()
  if action.skip and exit_mode and not action.wall_escape:
   if self.camp_route is not None:self.camp_route.replan(now);self.camp_exit_until=self.camp_route.until
   self.hybrid.reset_progress(clear_routes=True)
   self.say('CAMP_REPLAN: проход не дал продвижения; выбираю другой без исключения ресурсов')
   return Drive()
  if action.skip:
   measured=(radar.motion_valid and self.hybrid.last_progress is not None
             and now-self.hybrid.last_progress>=3)
   if self.nav.goal is not None and not measured and not action.wall_escape:
    self.hybrid.reset_progress(clear_routes=True)
    self.say('GOAL_KEEP: осмотр/поворот без подтверждённого упора не отменяет ресурс на миникарте')
    # Face the same goal on the next frame; never invent a clear path here.
    return Drive(yaw=plan.yaw,lifetime=min(.35,plan.lifetime),yaw_lifetime=plan.yaw_lifetime)
   if (action.wall_escape and now>=self.wall_escape_after and self.budget.energy is not None
       and self.budget.energy>=50 and self.budget.can_start() and not self.return_exit_guard):
    self.wall_escape_after=now+45
    if self._start_terrain_recovery(now,reading,short=True):
     self.terrain_recovery.lateral_escape=True;self.terrain_recovery.side=self.hybrid.escape_side
     self.terrain_recovery.cruise_bearing=(radar.heading+90*self.hybrid.escape_side)%360 if radar.heading is not None else None
     self.say('WALL_ESCAPE: боковые шаги и прыжки не помогли; подъём до 3 с со смещением в одну сторону, затем короткий боковой перелёт')
     return None
   if exit_mode:
    if self.camp_route is not None:self.camp_route.replan(now);self.camp_exit_until=self.camp_route.until
    self.hybrid.reset_progress(clear_routes=True)
    self.say('CAMP_REPLAN: боковой выход не помог; проверяю новый проход')
    return Drive()
   self.nav.exclude_goal(now,25);self.nav.air_since=None;self.nav.scan_kind=None
   self.say('HYBRID_REPLAN: недоступная цель отложена; выбираю другой ресурс/наземный выход')
  if now-self.hybrid_note>=1.5:
   self.hybrid_note=now
   state='нет' if self.analyzer is None else 'занят' if self.analyzer.busy else 'ошибка' if self.analyzer.error else 'готов' if self.analyzer.ready else 'ожидание'
   detail=('; полосы земля/стена/край='+str(tuple(tuple(round(v,2) for v in (l.free,l.solid,l.edge)) for l in result.lanes))+'; drop='+str(round(result.ground.drop_support,3)) if result is not None and result.ground is not None else '')
   self.say('HYBRID_NAV: '+action.reason+'; Qwen='+state+'; локальному кадру '+(str(round(captured-result.captured,2))+' с' if result else 'нет данных')+detail)
  return action.drive

 def _camp_view_note(self,drive,radar,result,now):
  if now-getattr(self,'camp_view_note',-1e9)<1.5:return
  self.camp_view_note=now
  latest=getattr(self.scene_host,'latest',None)
  age=round(now-latest.captured,2) if latest is not None else None
  revision=getattr(latest,'revision',None)
  bearing=self.camp_route.bearing if self.camp_route is not None else None
  self.say('CAMP_VIEW: '+drive.reason+'; курс='+str(round(bearing) if bearing is not None else None)
           +'; камера='+str(round(radar.heading) if radar.heading is not None else None)
           +'; возраст кадра='+str(age)+'; ревизия кадра/управления='+str(revision)+'/'+str(self.scene_camera_epoch)
           +'; свежий='+str(result is not None))
