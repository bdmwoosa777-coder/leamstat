"""Persistent local stagnation and bounded terrain escape, independent of OCR."""
from dataclasses import dataclass
import math
from camera_control import PITCH_STRENGTH,pitch_pulse
from minimap import angle_delta
from navigation import Drive


class RecoveryWatch:
    def __init__(self,seconds=90):
        self.seconds=max(30,seconds);self.position=[0.,0.];self.anchor=[0.,0.]
        self.since=None;self.at=None;self.valid=0.;self.next_at=0
    def reset(self,now):
        self.since=now;self.at=now;self.anchor=list(self.position);self.valid=0
    def update(self,radar,active,now):
        if not active:self.reset(now);return False
        if self.since is None:self.reset(now)
        dt=max(0,min(.6,now-(self.at if self.at is not None else now)));self.at=now
        scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
        if radar.motion_valid:
            self.valid+=dt
            self.position[0]+=radar.displacement[0];self.position[1]+=radar.displacement[1]
            if math.dist(self.position,self.anchor)>40*scale:self.reset(now)
        elapsed=now-self.since
        return now>=self.next_at and elapsed>=self.seconds and (self.valid>=10 or elapsed>=max(120,self.seconds))
    def attempted(self,now):
        self.reset(now);self.next_at=now+30


@dataclass
class RecoveryAction:
    drive:Drive|None=None
    command:str|None=None
    done:bool=False
    failed_takeoff:bool=False
    levelled:bool=False
    reason:str=''


class TerrainRecovery:
    def __init__(self,now,energy=None,airborne=False,side=1,working_ms=940):
        self.side=side;self.working=working_ms/1000
        self.fly=energy is not None and energy>=50
        self.phase='DOWN' if self.fly else 'LEVEL'
        self.since=now;self.pitch_start=None;self.homed=False;self.level_start=None
        self.absent=None;self.closes=0;self.failed=False
    def to(self,phase,now):self.phase=phase;self.since=now;self.absent=None
    def sent(self,command,now):
        # Transmission takes time. Confirmation windows begin AFTER dispatch.
        self.since=now
    def denied(self,now):
        self.failed=True;self.to('LEVEL' if self.pitch_start is not None else 'GROUND',now)
    def step(self,now,reading,balance,heading=None,bearing=None):
        elapsed=now-self.since
        if self.phase=='DOWN':
            if self.pitch_start is None:self.pitch_start=balance
            left=2-(self.pitch_start-balance)/PITCH_STRENGTH
            if left>.005 and elapsed<6:
                return RecoveryAction(drive=Drive(pitch=-PITCH_STRENGTH,lifetime=min(.18,left)),reason='подготовка подъёма: камера полностью вниз')
            if left>.005:
                self.fly=False;self.failed=True;self.to('LEVEL',now)
            else:
                self.homed=True;self.to('WAIT' if reading.confirmed else 'OPEN',now)
        if self.phase=='OPEN':
            self.to('WAIT',now);return RecoveryAction(command='V',reason='одна попытка раскрыть крылья для спасения')
        if self.phase=='WAIT':
            if reading.confirmed:
                if reading.energy is None or reading.energy<50:
                    self.fly=False;self.to('LEVEL',now)
                else:self.to('RISE',now)
            elif now-self.since>3.5:
                self.fly=False;self.failed=True;self.to('LEVEL',now)
                return RecoveryAction(failed_takeoff=True,reason='дуга не подтвердилась: восстанавливаю обзор и продолжаю наземный выход')
            else:return RecoveryAction()
        if self.phase=='RISE':
            if not reading.confirmed:
                if self.absent is None:self.absent=now
                if now-self.absent<.7:return RecoveryAction()
                self.fly=False;self.to('LEVEL',now)
            elif reading.energy is not None and reading.energy<=20 or now-self.since>=5:
                self.to('LEVEL',now)
            else:
                self.absent=None
                # Looking down + backwards movement ascends. Never add
                # positive forward during this phase: it would descend.
                elapsed_rise=now-self.since;slot=int(elapsed_rise/1.25)
                side=-self.side if slot%2==0 else self.side
                lease=min(.22,max(.02,(slot+1)*1.25-elapsed_rise))
                return RecoveryAction(drive=Drive(-.62,.45*side,0,0,lifetime=lease,tilted_motion=True),reason='спасение: назад для подъёма, короткое смещение '+('влево' if side<0 else 'вправо'))
        if self.phase=='LEVEL':
            if self.level_start is None:self.level_start=balance
            if self.homed:
                left=self.working-(balance-self.level_start)/PITCH_STRENGTH
                pitch=PITCH_STRENGTH
            else:
                error=-balance;left=abs(error)/PITCH_STRENGTH;pitch=PITCH_STRENGTH if error>0 else -PITCH_STRENGTH
            if left>.005 and now-self.since<6:
                return RecoveryAction(drive=Drive(pitch=pitch,lifetime=min(.15,left)),reason='после подъёма возвращаю рабочий обзор')
            self.to('CRUISE' if self.fly and reading.confirmed else 'CLOSE' if reading.confirmed else 'GROUND',now)
            return RecoveryAction(levelled=left<=.005,reason='обзор восстановлен; продолжаю выход')
        if self.phase=='CRUISE':
            if not reading.confirmed or reading.energy is not None and reading.energy<=20 or elapsed>=4:
                self.to('CLOSE',now)
            else:return RecoveryAction(drive=self.travel(heading,bearing),reason='спасение: короткий перелёт к направлению ресурса/выхода')
        if self.phase=='CLOSE':
            if reading.confirmed and self.closes<2:
                self.closes+=1;self.to('WAIT_CLOSE',now)
                return RecoveryAction(command='END_AIR',reason='завершаю спасательный перелёт')
            self.to('AIR_EXIT' if reading.confirmed else 'GROUND',now)
        if self.phase=='WAIT_CLOSE':
            if not reading.confirmed:
                if self.absent is None:self.absent=now
                if now-self.absent>=.25:self.to('GROUND',now)
                else:return RecoveryAction()
            elif elapsed>2.5:
                self.to('CLOSE',now)
            else:return RecoveryAction()
        if self.phase=='AIR_EXIT':
            # No more blind V toggles. Keep trying a different position until
            # the flight HUD disappears, including natural energy exhaustion.
            if not reading.confirmed:
                if self.absent is None:self.absent=now
                if now-self.absent>=.25:self.to('GROUND',now)
                else:return RecoveryAction()
            else:
                self.absent=None
                return RecoveryAction(drive=self.travel(heading,bearing),reason='закрытие не подтвердилось: продолжаю выход без новых V')
        if self.phase=='GROUND':
            if now-self.since>=8:return RecoveryAction(done=True,reason='манёвр окончен: продолжаю поиск по новому направлению')
            leg=int((now-self.since)/2)%4
            forward,strafe=((-0.65,.35*self.side),(0,.75*self.side),(.65,.35*self.side),(0,-.75*self.side))[leg]
            return RecoveryAction(drive=Drive(forward,strafe,0,0,lifetime=.24,tilted_motion=True),reason='наземный выход: меняю направление, сканер продолжает работать')
        return RecoveryAction()
    def travel(self,heading,bearing):
        if heading is None or bearing is None:return Drive(.50,.25*self.side,0,0,lifetime=.24,tilted_motion=True)
        error=angle_delta(bearing,heading);r=math.radians(error)
        return Drive(.60*math.cos(r),.60*math.sin(r),max(-.35,min(.35,error/100)),0,lifetime=.24,tilted_motion=True)
