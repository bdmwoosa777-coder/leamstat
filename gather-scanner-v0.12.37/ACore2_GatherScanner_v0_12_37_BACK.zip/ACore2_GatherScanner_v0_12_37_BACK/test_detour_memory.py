"""Replays for a bent rock bypass and motion that never approaches its goal."""
import math,unittest
from dataclasses import replace
from unittest.mock import patch
from ground_routes import GroundRoute
from hybrid_navigation import HybridPlanner
from navigation import Drive
from minimap import Marker,angle_delta
from scene_navigation import Lane
from test_hybrid import scene
import test_hybrid as hybrid_fixture
from test_navigation import radar
from flight import FlightReading

def bent(i,near,far=.22,score=1):
 return GroundRoute(i,((.5,.72),(near,.60),(far,.45)),score,.8,2)

def obstructed(routes,t=100):
 return replace(scene(routes,t),lanes=(Lane(.12,.55,0,.1),)*3)

def bearing(d,heading=90):return (heading+math.degrees(math.atan2(d.strafe,d.forward)))%360

class StableNearPath(unittest.TestCase):
 def test_shared_far_endpoint_cannot_flip_the_near_bypass_side(self):
  for camp in (False,True):
   p=HybridPlanner();a=p.choose(Drive(.7),obstructed([bent(1,.27),bent(2,.73)]),radar(),100,hint=1,exit_mode=camp)
   b=p.choose(Drive(.7),obstructed([bent(10,.73,score=5),bent(11,.27)],100.4),radar(),100.4,exit_mode=camp)
   self.assertLess(a.drive.strafe,0);self.assertLess(b.drive.strafe,0)
   self.assertLess(abs(angle_delta(bearing(a.drive),bearing(b.drive))),1)
 def test_camera_follows_near_left_bend_even_if_the_far_path_turns_right(self):
  for camp in (False,True):
   p=HybridPlanner();a=p.choose(Drive(.7),obstructed([bent(1,.25,.8)]),radar(),100,hint=1,exit_mode=camp)
   self.assertLess(a.drive.strafe,0);self.assertLess(a.drive.yaw,0)
   self.assertAlmostEqual(p.active_bearing,bearing(a.drive))
 def test_refresh_gap_keeps_actual_left_motion_instead_of_far_right_endpoint(self):
  p=HybridPlanner();a=p.choose(Drive(.7),obstructed([bent(1,.25,.8)]),radar(),100,hint=1)
  b=p.choose(Drive(.7),None,radar(),100.4)
  self.assertGreater(b.drive.forward,0);self.assertLess(b.drive.strafe,0)
  self.assertLess(abs(angle_delta(bearing(a.drive),bearing(b.drive))),.01)
 def test_small_camera_change_reprojects_the_same_walk_direction(self):
  p=HybridPlanner();a=p.choose(Drive(.7),obstructed([bent(1,.27)]),radar(),100,hint=1)
  b=p.choose(Drive(.7),obstructed([bent(20,.73,score=5),bent(21,.23)],100.4),radar(heading=95),100.4)
  self.assertLess(b.drive.strafe,0);self.assertLess(abs(angle_delta(bearing(a.drive),bearing(b.drive,95))),8)
 def test_missing_previous_branch_revokes_commit_instead_of_reviving_it_next_frame(self):
  p=HybridPlanner();p.choose(Drive(.7),obstructed([bent(1,.27)]),radar(),100,hint=1)
  a=p.choose(Drive(.7),obstructed([bent(2,.73)],100.4),radar(),100.4)
  b=p.choose(Drive(.7),obstructed([bent(10,.27,score=5),bent(11,.73)],100.8),radar(),100.8)
  self.assertGreater(a.drive.strafe,0);self.assertGreater(b.drive.strafe,0)
 def test_new_explicit_advice_changes_the_remembered_executed_direction(self):
  p=HybridPlanner();p.choose(Drive(.7),obstructed([bent(1,.27)]),radar(),100,hint=1)
  a=p.choose(Drive(.7),obstructed([bent(2,.73)],100.4),radar(),100.4,hint=2)
  b=p.choose(Drive(.7),None,radar(),100.6)
  self.assertGreater(a.drive.strafe,0);self.assertGreater(b.drive.strafe,0)
 def test_fresh_cliff_revokes_a_remembered_path_and_missing_frame_cannot_resume_it(self):
  p=HybridPlanner();p.choose(Drive(.7),obstructed([bent(1,.27)]),radar(),100,hint=1)
  cliff=replace(scene(t=100.4),ground=replace(scene().ground,routes=(),drop_support=.2),lanes=(Lane(.01,.4,.2,.1),)*3)
  p.choose(Drive(.7),cliff,radar(),100.4)
  d=p.choose(Drive(.7),None,radar(),100.6).drive
  self.assertEqual((d.forward,d.strafe),(0,0))

class DestinationProgress(unittest.TestCase):
 def stuck_walk(self,p,key=(1,'aether'),end=6.5):
  failure=None
  for i in range(round(end*4)+1):
   t=100+i*.25
   failed=p.observe_goal(key,45,t)
   if failed is not None:failure=failed
   p.active_bearing=50;p.note_goal_motion(t)
  return failure
 def test_walking_without_getting_closer_changes_bypass_in_about_six_seconds(self):
  p=HybridPlanner();self.assertEqual(self.stuck_walk(p),50)
  self.assertEqual(p.goal_key,(1,'aether'));self.assertTrue(p.goal_avoid)
 def test_camera_time_without_delivered_walking_is_not_a_failed_bypass(self):
  p=HybridPlanner();p.active_bearing=50
  for t in (100,104,110,120):self.assertIsNone(p.observe_goal((1,'aether'),45,t))
  self.assertFalse(p.goal_avoid)
 def test_real_approach_keeps_a_working_bypass_even_after_many_seconds(self):
  p=HybridPlanner()
  for i in range(81):
   t=100+i*.25;self.assertIsNone(p.observe_goal((1,'aether'),90-i*.8,t));p.note_goal_motion(t);p.active_bearing=50
  self.assertFalse(p.goal_avoid)
 def test_lost_marker_does_not_credit_old_walking_when_it_reappears(self):
  p=HybridPlanner();self.stuck_walk(p,end=4)
  self.assertIsNone(p.observe_goal((1,'aether'),45,110,visible=False))
  self.assertIsNone(p.observe_goal((1,'aether'),45,112));self.assertFalse(p.goal_avoid)
 def test_near_node_is_left_for_caption_scan_not_blacklisted_as_a_failed_route(self):
  p=HybridPlanner()
  for i in range(41):
   t=100+i*.25;self.assertIsNone(p.observe_goal((1,'aether'),5,t));p.note_goal_motion(t);p.active_bearing=50
  self.assertFalse(p.goal_avoid)
 def test_goal_change_clears_only_the_old_goal_failure_memory(self):
  p=HybridPlanner();self.stuck_walk(p);self.assertTrue(p.goal_avoid)
  self.assertIsNone(p.observe_goal((2,'aether'),45,107));self.assertFalse(p.goal_avoid)
 def test_regular_route_reset_cannot_erase_a_failed_bypass_of_the_same_resource(self):
  p=HybridPlanner();self.stuck_walk(p);p.reset_progress(clear_routes=True)
  self.assertTrue(p.goal_avoid);p.choose(Drive(.7),scene(t=128),radar(),128);self.assertFalse(p.goal_avoid)
 def test_failed_direction_is_filtered_by_near_walk_not_shared_far_endpoint(self):
  p=HybridPlanner();self.stuck_walk(p)
  a=p.choose(Drive(.7),obstructed([bent(1,.27),bent(2,.73)],107),radar(),107)
  self.assertGreater(a.drive.strafe,0);self.assertFalse(a.skip)

class DeliveredGoalMotion(unittest.TestCase):
 def test_actual_engine_changes_detour_when_minimap_moves_but_resource_never_gets_closer(self):
  f=hybrid_fixture.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');f.setUp()
  self.addCleanup(f.doCleanups);self.addCleanup(f.tearDown);e=f.e
  goal=Marker('Самоцвет',150,100,.9,50);e.nav.goal=goal;e.nav.goal_epoch=7
  r=replace(radar([goal]),motion_valid=True,displacement=(.6,0))
  with patch.object(e.gamepad,'wait',return_value=True):
   for i in range(29):
    t=100+i*.25;e.scene_host.current=lambda *a:obstructed([bent(1,.27),bent(2,.73)],t)
    with patch('hybrid_engine.time.monotonic',return_value=t):
     d=e._scene_plan(f.frame,r,FlightReading(None,False),Drive(.78),t)
     self.assertTrue(e._motion(d))
  self.assertIs(e.nav.goal,goal);self.assertTrue(e.hybrid.goal_avoid)
  self.assertTrue(any('GOAL_DETOUR:' in x for x in f.log))
  self.assertGreater(d.strafe,0);self.assertFalse(e.stop_event.is_set())

if __name__=='__main__':unittest.main()
