"""Post-teleport backward exit owns input without calibration or a saved route."""
import unittest,json
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch,Mock
from post_tp_exit import BackExit,back_exit_seconds
from flight import FlightReading
from map_teleport import MapTeleport,MapObservation
from test_navigation import radar
import test_hybrid as fx

class DeliveredBackTime(unittest.TestCase):
 def test_default_is_thirteen_and_half_seconds(self):self.assertEqual(back_exit_seconds({}),13.5)
 def test_duration_accepts_requested_range_and_decimal_comma(self):
  for value,want in (('13',13),('13,5',13.5),('14',14)):self.assertEqual(back_exit_seconds({'post_tp_back_exit_seconds':value}),want)
 def test_bad_values_do_not_create_unbounded_walk(self):
  for value in ('bad',None,-1,200,'nan'):self.assertEqual(back_exit_seconds({'post_tp_back_exit_seconds':value}),13.5)
 def test_load_must_stay_ready_for_one_second(self):
  s=BackExit(13.5,0);self.assertFalse(s.ready(0,True));self.assertFalse(s.ready(.9,True));self.assertTrue(s.ready(1,True))
 def test_loading_frame_resets_ready_window(self):
  s=BackExit(13.5,0);s.ready(0,True);s.ready(.8,False);self.assertFalse(s.ready(1,True));self.assertTrue(s.ready(2,True))
 def test_renewed_overlapping_leases_are_not_counted_twice(self):
  s=BackExit(13.5,0);s.sent(0,.7);s.sent(.3,1);s.advance(.8);self.assertAlmostEqual(s.delivered,.8)
 def test_controller_gap_is_not_held_back_time(self):
  s=BackExit(13.5,0);s.sent(0,.7);s.advance(3);self.assertAlmostEqual(s.delivered,.7)
 def test_neutral_stops_time_credit(self):
  s=BackExit(13.5,0);s.sent(0,.7);s.stop_motion(.2);s.advance(4);self.assertAlmostEqual(s.delivered,.2)
 def test_last_lease_is_bounded_by_remaining_duration(self):
  s=BackExit(13.5,0);s.sent(0,20);s.advance(18);self.assertEqual(s.delivered,13.5);self.assertTrue(s.done)
 def test_old_timestamp_does_not_credit_time_again(self):
  s=BackExit(13.5,0);s.sent(0,.7);s.advance(.4);s.advance(.1);s.advance(.5);self.assertAlmostEqual(s.delivered,.5)

class BackwardExitEngine(unittest.TestCase):
 def setUp(self):
  self.f=fx.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.e.bridge.controller_native=True;self.e.cfg.update(post_tp_back_exit_enabled=True,post_tp_back_exit_seconds=13.5)
  self.e.gamepad.motion_worker=object();self.clock=100.;self.focus=True
  self.e.screen.focused=lambda:self.focus;self.floor=self.e.gamepad.translation_lease_floor
  self.angles=[];right=self.f.pad.right_joystick_float
  self.f.pad.right_joystick_float=lambda x_value_float,y_value_float:(self.angles.append((x_value_float,y_value_float)),right(x_value_float,y_value_float))[-1]
  for p in (patch('hybrid_engine.time.monotonic',side_effect=lambda:self.clock),patch('hybrid_engine.map_evidence',return_value=SimpleNamespace(usable=True,loading=False)),patch('hybrid_engine.is_map',return_value=False),patch('hybrid_engine.read_flight',return_value=FlightReading(None,False))):
   p.start();self.addCleanup(p.stop)
  self.trip=SimpleNamespace(used=True,destination='Рабочий лагерь стального молота')
 def arm(self):self.e._map_teleport_arrived(self.trip,self.clock)
 def tick(self,t):self.clock=t;return self.e._automatic_recovery_tick(self.f.frame,t)
 def start_motion(self):self.arm();self.tick(100);self.tick(101)
 def test_only_confirmed_arrival_arms_macro_and_never_calibrates(self):
  self.assertIsNone(self.e.post_tp_exit)
  with patch.object(self.e,'_calibrate_camera',side_effect=AssertionError('arrival pose must stay unchanged')):self.arm()
  self.assertEqual(self.e.mode,'POST_TP_EXIT');self.assertIsNotNone(self.e.post_tp_exit)
 def test_disabled_feature_retains_old_arrival_hook(self):
  self.e.cfg['post_tp_back_exit_enabled']=False
  with patch.object(self.e,'_calibrate_camera',return_value=True) as calibrate:self.arm()
  calibrate.assert_called_once();self.assertIsNone(self.e.post_tp_exit)
 def test_no_movement_during_initial_ready_window(self):
  self.arm();self.tick(100);self.tick(100.5);self.assertEqual(self.f.pad.axes,(0,0,0,0))
 def test_only_full_backward_stick_with_zero_right_stick(self):
  self.start_motion();self.assertEqual(self.f.pad.axes,(-0.,-1.,0,0));self.assertTrue(all(v==(0,0) for v in self.angles))
 def test_thirteen_and_half_delivered_seconds_finish_and_release_stick(self):
  self.arm();s=self.e.post_tp_exit
  for i in range(151):self.tick(100+i*.1)
  self.assertIsNone(self.e.post_tp_exit);self.assertEqual(self.e.mode,'SEARCH');self.assertEqual(self.f.pad.axes,(0,0,0,0))
  self.assertAlmostEqual(s.delivered,13.5,places=2);self.assertTrue(all(v==(0,0) for v in self.angles))
  self.assertEqual(self.e.gamepad.translation_lease_floor,self.floor)
 def test_no_sprint_jump_wings_or_b_are_sent(self):
  self.start_motion();self.tick(101.2)
  self.assertEqual(self.f.pad.presses,0);self.assertEqual(self.f.pad.buttons,0)
  self.assertFalse({'V','END_AIR','JUMP','TAB','TAP_F','F_ON'}&set(self.f.commands))
 def test_loading_does_not_run_backward_or_count_wait(self):
  self.arm()
  with patch('hybrid_engine.map_evidence',return_value=SimpleNamespace(usable=False,loading=True)):
   self.tick(100);self.tick(108)
  self.assertEqual(self.e.post_tp_exit.delivered,0);self.assertEqual(self.f.pad.axes,(0,0,0,0))
 def test_open_map_does_not_run_backward(self):
  self.arm()
  with patch('hybrid_engine.is_map',return_value=True):self.tick(100);self.tick(102)
  self.assertEqual(self.e.post_tp_exit.delivered,0)
 def test_focus_loss_releases_stick_and_pauses_credit(self):
  self.start_motion();self.clock=101.2;self.focus=False;self.e._neutral();self.tick(105)
  self.assertAlmostEqual(self.e.post_tp_exit.delivered,.2);self.assertEqual(self.f.pad.axes,(0,0,0,0))
 def test_network_wait_does_not_count_as_backward_time(self):
  self.start_motion();self.f.source.ready=False;self.tick(101.2);self.tick(105)
  self.assertAlmostEqual(self.e.post_tp_exit.delivered,.2);self.assertEqual(self.f.pad.axes,(0,0,0,0))
 def test_changed_character_cancels_the_known_spawn_maneuver(self):
  self.start_motion();self.f.source.state.own=8;self.tick(101.2)
  self.assertIsNone(self.e.post_tp_exit);self.assertEqual(self.f.pad.axes,(0,0,0,0));self.assertEqual(self.e.gamepad.translation_lease_floor,self.floor)
 def test_saved_route_and_camp_detection_do_not_take_over(self):
  self.e.recorded_exit=object();self.e.camp_route=object();self.e.hybrid_camp_pending=True
  self.arm();self.assertIsNone(self.e.recorded_exit);self.assertIsNone(self.e.camp_route);self.assertFalse(self.e.camp_rearm)
  self.e._finish_post_tp_exit(100,True,'test')
  with patch('hybrid_engine.purple_anchor',return_value=(100,100)):self.e._camp_update(self.f.frame,radar(),101)
  self.assertFalse(self.e.hybrid_camp_pending);self.assertIsNone(self.e.camp_route)
 def test_candidate_callback_cannot_pause_walk_or_turn_camera(self):
  self.start_motion();self.e._candidate_observed(self.f.c,101,0)
  self.assertIsNone(self.e.caption_latch);self.assertEqual(self.f.pad.axes[1],-1.)
 def test_old_pitch_return_is_discarded_without_pitch_report(self):
  self.e.pitch.apply(.45,99,1);self.e.pitch.restore(100);self.arm()
  self.assertFalse(self.e.pitch.returning);self.assertEqual(self.e.pitch.offset(100),0)
  self.assertTrue(all(v==(0,0) for v in self.angles))
 def test_camera_and_cursor_buttons_are_gated_while_macro_owns_input(self):
  self.arm();self.assertFalse(self.e._camera_input_ready());self.assertFalse(self.e._a_input_ready());self.assertFalse(self.e.bridge_cmd('V'))
 def test_manual_stop_cancels_macro_and_restores_original_lease_floor(self):
  self.start_motion();self.e.stop(manual=True)
  if self.e.release_thread:self.e.release_thread.join(1)
  self.assertIsNone(self.e.post_tp_exit);self.assertTrue(self.e.stop_event.is_set());self.assertEqual(self.f.pad.axes,(0,0,0,0))
  self.assertEqual(self.e.gamepad.translation_lease_floor,self.floor)
 def test_disabling_macro_midwalk_releases_stick(self):
  self.start_motion();self.e.cfg['post_tp_back_exit_enabled']=False;self.tick(101.2)
  self.assertIsNone(self.e.post_tp_exit);self.assertEqual(self.f.pad.axes,(0,0,0,0))
 def test_map_fsm_done_uses_back_exit_instead_of_calibration(self):
  self.e.map_teleport=MapTeleport(95,self.trip.destination,48);self.e.map_teleport.phase='WAIT_TRANSFER'
  self.e.map_teleport.used=True;self.e.map_teleport.loading_seen=True;self.e.map_active=True
  import gather_engine as ge
  with patch.object(ge,'map_evidence',return_value=SimpleNamespace(usable=True,loading=False)),patch.object(ge,'observe_map',return_value=MapObservation(usable=True,arrived=True)),patch.object(self.e,'_calibrate_camera',side_effect=AssertionError('calibration after TP')):
   self.e._map_teleport_tick(self.f.frame,FlightReading(None,False),100)
   self.clock=101;self.e._map_teleport_tick(self.f.frame,FlightReading(None,False),101)
  self.assertIsNone(self.e.map_teleport);self.assertFalse(self.e.map_active);self.assertEqual(self.e.mode,'POST_TP_EXIT')
 def test_defaults_enable_back_exit_and_disable_old_recording(self):
  from app import DEFAULT
  cfg=json.loads((Path(__file__).parent/'settings_gather.json').read_text())
  for config in (DEFAULT,cfg):
   self.assertTrue(config['post_tp_back_exit_enabled']);self.assertFalse(config['recorded_camp_exit_enabled']);self.assertEqual(config['post_tp_back_exit_seconds'],13.5)

if __name__=='__main__':unittest.main()
