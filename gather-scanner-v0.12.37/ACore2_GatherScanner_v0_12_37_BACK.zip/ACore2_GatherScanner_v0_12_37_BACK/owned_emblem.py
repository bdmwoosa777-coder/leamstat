"""Track an already-owned, camera-facing resource badge; never discover a target."""
from dataclasses import replace
from pathlib import Path
import threading
import cv2
import numpy as np

class OwnedEmblem:
 def __init__(self):
  self.lock=threading.RLock();self.key=None;self.candidate=None;self.template=None;self.at=-1e9;self.size=None
  self.canonical=cv2.imread(str(Path(__file__).parent/'assets/resource_emblem_mask.png'),0);self.reason='not seeded'
 def clear(self):
  with self.lock:self.key=None;self.candidate=None;self.template=None;self.at=-1e9;self.size=None
 def seed(self,key,candidate,frame,at):
  if candidate is None or candidate.emblem is None:return False
  x,y,w,h=map(int,candidate.emblem);H,W=frame.shape[:2]
  if min(w,h)<9 or x<0 or y<0 or x+w>W or y+h>H:return False
  template=cv2.cvtColor(frame[y:y+h,x:x+w],cv2.COLOR_BGR2GRAY)
  if np.std(template)<15:return False
  with self.lock:
   if key==self.key and at<self.at:return False
   self.key=key;self.candidate=replace(candidate,glyph=None);self.template=template.copy();self.at=at;self.size=(H,W)
  return True
 def refresh(self,key,frame,at,reacquire=False):
  with self.lock:
   if key!=self.key or self.candidate is None or self.size!=frame.shape[:2]:self.reason='binding/size';return None
   age=at-self.at
   if age<0 or age>2.5 and not reacquire:self.reason='source age';return None
   old=self.candidate;x,y,w,h=old.emblem;cx,cy=x+w/2,y+h/2
   jump=max(12,min(36,min(w,h)*.75));margin=round(jump+max(w,h)*.20)
   H,W=frame.shape[:2];x0=max(0,x-margin);y0=max(0,y-margin);x1=min(W,x+w+margin);y1=min(H,y+h+margin)
   gray=cv2.cvtColor(frame[y0:y1,x0:x1],cv2.COLOR_BGR2GRAY);matches=[]
   # Keep the first image immutable. Resizing and recropping the last match
   # compounds small alignment errors into a different-sized fragment.
   variants=[]
   if age<=2.5:variants.extend((self.template,s,.80) for s in (1.,.9,1.1,1.25))
   if reacquire and self.canonical is not None:
    reference=cv2.resize(self.canonical,(self.template.shape[1],self.template.shape[0]),interpolation=cv2.INTER_AREA)
    variants.extend((reference,s,.68) for s in (1.,.8,1.25,1.5,1.8,2.1))
   for source,scale,threshold in variants:
    tpl=cv2.resize(source,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA);th,tw=tpl.shape
    if th>gray.shape[0] or tw>gray.shape[1]:continue
    scores=cv2.matchTemplate(gray,tpl,cv2.TM_CCOEFF_NORMED)
    for _ in range(3):
     _,score,_,(xx,yy)=cv2.minMaxLoc(scores)
     if score<threshold:break
     scores[max(0,yy-th//2):yy+max(2,th//2),max(0,xx-tw//2):xx+max(2,tw//2)]=-1
     ex,ey=x0+xx,y0+yy;distance=float(np.hypot(ex+tw/2-cx,ey+th/2-cy))
     if distance<=jump:matches.append((distance,float(score),ex,ey,tw,th))
   if not matches:self.reason='no live icon';return None
   matches.sort(key=lambda v:(-v[1],v[0]));best=matches[0];distance,score,ex,ey,ew,eh=best
   for d,s,xx,yy,ww,hh in matches[1:]:
    separate=np.hypot(xx+ww/2-ex-ew/2,yy+hh/2-ey-eh/2)>max(6,min(ew,eh)*.45)
    if separate and s>=max(.68,score-.06) and d<=distance+max(8,min(ew,eh)*.4):self.reason='ambiguous icons';return None
   bx,by,bw,bh=old.box;dx=round(ex+ew/2-cx);dy=round(ey+eh/2-cy)
   fresh=replace(old,box=(bx+dx,by+dy,bw,bh),click_x=ex+ew//2,click_y=ey+eh//2,emblem=(ex,ey,ew,eh),glyph=None)
   self.candidate=fresh;self.at=at;self.reason='live icon'
   return fresh
