"""Count delivered backward-stick leases after a confirmed teleport, without yaw."""
from dataclasses import dataclass

def back_exit_seconds(cfg):
 try:value=float(str(cfg.get('post_tp_back_exit_seconds',13.5)).replace(',','.'))
 except (TypeError,ValueError):return 13.5
 if not 13<=value<=14:return 13.5
 return value

@dataclass
class BackExit:
 duration:float
 created:float
 delivered:float=0.
 at:float|None=None
 lease_until:float=0.
 ready_since:float|None=None
 note_at:float=-1e9
 def advance(self,now):
  if self.at is not None and now<self.at:return
  if self.at is not None:self.delivered=min(self.duration,self.delivered+max(0.,min(now,self.lease_until)-self.at))
  self.at=now
 def stop_motion(self,now):self.advance(now);self.lease_until=now
 def ready(self,now,usable):
  self.advance(now)
  if not usable:self.ready_since=None;return False
  if self.ready_since is None:self.ready_since=now
  return now-self.ready_since>=1.
 def sent(self,now,deadline):
  self.advance(now);self.lease_until=min(deadline,now+self.remaining)
 @property
 def remaining(self):return max(0.,self.duration-self.delivered)
 @property
 def done(self):return self.remaining<=.005
