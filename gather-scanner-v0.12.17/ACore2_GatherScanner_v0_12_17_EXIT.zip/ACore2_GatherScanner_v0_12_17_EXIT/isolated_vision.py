"""Spawned compute-only workers. No input transport, game state or UI authority.

Queues are bounded; old frames are dropped. The parent retains all freshness,
identity, collection, CAPTCHA and controller guards.
"""
import multiprocessing as mp
import queue,threading,time
import cv2
from scene_navigation import SceneHost


def _latest(q,value):
 try:q.put_nowait(value);return True
 except queue.Full:
  try:q.get_nowait()
  except queue.Empty:pass
  except (OSError,ValueError,EOFError):return False
  try:q.put_nowait(value);return True
  except (queue.Full,OSError,ValueError,EOFError):return False
 except (OSError,ValueError,EOFError):return False


def _close_process(process,stop,queues):
 if stop is not None:stop.set()
 if process is not None and process.pid is not None:
  process.join(.2)
  if process.is_alive():process.terminate();process.join(.5)
  if process.is_alive():process.kill();process.join(.2)
 for q in queues:
  try:q.cancel_join_thread();q.close()
  except (ValueError,OSError):pass


def _scene_process(cfg,inbox,outbox,events,stop):
 cv2.setNumThreads(1)
 def emit(message):_latest(events,str(message))
 host=SceneHost(cfg,emit);host.start();last=None
 try:
  while not stop.wait(.02):
   request=None
   try:
    while True:request=inbox.get_nowait()
   except queue.Empty:pass
   if request is not None:host.offer(*request)
   with host.lock:result=host.latest;error=host.error
   if result is not None and result.sequence!=last:
    last=result.sequence;_latest(outbox,result)
   if error:break
 finally:host.close()


class ProcessSceneHost(SceneHost):
 def __init__(self,cfg,emit=lambda message:None,worker_target=None):
  super().__init__(cfg,emit)
  self.context=mp.get_context('spawn');self.worker_target=worker_target or _scene_process
  self.inbox=None;self.outbox=None;self.events=None;self.process_stop=None;self.collector=None
 def start(self):
  with self.lock:
   if self.stop.is_set() or self.worker is not None:return
   self.inbox=self.context.Queue(1);self.outbox=self.context.Queue(1);self.events=self.context.Queue(16)
   self.process_stop=self.context.Event()
   self.worker=self.context.Process(target=self.worker_target,args=(self.cfg,self.inbox,self.outbox,self.events,self.process_stop),daemon=True,name='gather-scene')
   try:self.worker.start()
   except Exception as exc:
    self.error=str(exc);self.emit('SCENE PROCESS ERROR: '+self.error);return
   self.collector=threading.Thread(target=self._collect,daemon=True,name='scene-results');self.collector.start()
   self.emit('SCENE_PROCESS: анализ сцены вынесен в отдельный процесс; PID='+str(self.worker.pid))
 def offer(self,frame,now,heading,pitch,revision=0):
  if self.stop.is_set() or now-self.last_offer<.45:return
  self.start()
  if self.worker is None or not self.worker.is_alive():return
  self.last_offer=now;h,w=frame.shape[:2];scale=min(1,1280/w)
  image=cv2.resize(frame,(round(w*scale),round(h*scale)),interpolation=cv2.INTER_AREA) if scale<1 else frame.copy()
  _latest(self.inbox,(image,now,heading,pitch,revision))
 def _collect(self):
  while not self.stop.is_set():
   try:
    for _ in range(16):
     try:message=self.events.get_nowait()
     except queue.Empty:break
     if 'ERROR' in message:self.error=message
     self.emit(message)
    try:result=self.outbox.get(timeout=.05)
    except queue.Empty:
     if self.worker is not None and not self.worker.is_alive():
      if not self.error:self.error='процесс сцены завершился';self.emit('SCENE PROCESS ERROR: '+self.error)
      return
     continue
    with self.lock:
     if not self.stop.is_set():self.latest=result
   except (OSError,EOFError,ValueError):return
 def close(self):
  self.stop.set();self.event.set()
  with self.lock:self.pending=None;self.latest=None
  _close_process(self.worker,self.process_stop,[q for q in (self.inbox,self.outbox,self.events) if q is not None])


def _world_process(inbox,outbox,stop):
 cv2.setNumThreads(1)
 from caption_memory import CaptionMemory
 from vision import find_world_resource
 memory=CaptionMemory()
 while not stop.is_set():
  try:seq,frame,names,entries=inbox.get(timeout=.1)
  except queue.Empty:continue
  try:
   memory.entries=entries
   candidate=find_world_resource(frame,names,rejected=lambda c:memory.rejected(c,time.monotonic()))
   message=(seq,candidate,None)
  except Exception as exc:message=(seq,None,str(exc))
  if not stop.is_set():_latest(outbox,message)


class WorldProcess:
 def __init__(self,emit=lambda message:None,worker_target=None):
  self.emit=emit;self.worker_target=worker_target or _world_process;self.context=mp.get_context('spawn')
  self.inbox=None;self.outbox=None;self.process_stop=None;self.worker=None
  self.closed=threading.Event();self.lock=threading.Lock();self.sequence=0;self.error=None
 def start(self):
  with self.lock:
   if self.closed.is_set() or self.worker is not None:return
   self.inbox=self.context.Queue(1);self.outbox=self.context.Queue(1);self.process_stop=self.context.Event()
   self.worker=self.context.Process(target=self.worker_target,args=(self.inbox,self.outbox,self.process_stop),daemon=True,name='gather-world')
   self.worker.start();self.emit('WORLD_PROCESS: поиск подписей вынесен в отдельный процесс; PID='+str(self.worker.pid))
 def search(self,frame,names,entries,stop,timeout=3.):
  # Called only by the background observation worker, never by the input loop.
  if self.closed.is_set() or stop.is_set():return None
  self.start()
  if self.closed.is_set() or self.worker is None or not self.worker.is_alive():return None
  self.sequence+=1;seq=self.sequence
  if not _latest(self.inbox,(seq,frame,tuple(names),tuple(entries))):return None
  until=time.monotonic()+timeout
  while not self.closed.is_set() and not stop.is_set() and time.monotonic()<until:
   try:received,candidate,error=self.outbox.get(timeout=.05)
   except queue.Empty:
    if not self.worker.is_alive():self.error='процесс поиска завершился';return None
    continue
   except (OSError,EOFError,ValueError):return None
   if received!=seq:continue
   if error:
    self.error=error;self.emit('WORLD PROCESS ERROR: '+error);return None
   self.error=None;return candidate
  return None
 def close(self):
  self.closed.set()
  with self.lock:_close_process(self.worker,self.process_stop,[q for q in (self.inbox,self.outbox) if q is not None])
