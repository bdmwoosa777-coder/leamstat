"""Camp departure must survive radar resources, patrol proposals and blocked legs."""
import math,unittest
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import gather_engine as ge,hybrid_engine as he
from camp_departure import CampDeparture
from hybrid_engine import HybridGatherEngine
from hybrid_navigation import HybridPlanner
from ground_routes import GroundMap
from navigation import Drive
from test_navigation import GatherFixture,radar,obs
from test_network_control import Source
from test_hybrid import scene,route
from test_patrol import AIR,GROUND

class LandmarkCourse(unittest.TestCase):
 def test_away_bearing_is_in_map_coordinates_not_camera_coordinates(self):
  for anchor,wanted in (((90,100),90),((100,110),0),((110,100),270),((100,90),180)):
   d=CampDeparture(anchor,(100,100),313,0);self.assertAlmostEqual(d.bearing,wanted)
 def test_centered_landmark_waits_for_a_real_passage(self):
  d=CampDeparture((100,100),(100,100),313,0)
  self.assertIsNone(d.choose(90,None,0));self.assertIsNone(d.choose(None,scene().ground,0))
  self.assertIsNone(d.choose(90,GroundMap(),0))
 def test_centered_landmark_latches_visible_course_across_camera_turns(self):
  d=CampDeparture((100,100),(100,100),313,0)
  b=d.choose(90,scene().ground,0);self.assertIsNotNone(b)
  self.assertEqual(d.choose(180,scene().ground,1),b)
 def test_cliff_is_not_a_candidate_for_initial_course(self):
  d=CampDeparture((100,100),(100,100),313,0)
  self.assertIsNone(d.choose(90,replace(scene().ground,drop_support=.1),0))
 def test_low_confidence_or_narrow_route_cannot_set_course(self):
  d=CampDeparture((100,100),(100,100),313,0)
  for r in (replace(route(2,.5),confidence=.2),replace(route(2,.5),clearance=.1)):
   self.assertIsNone(d.choose(90,GroundMap((r,)),0))
 def test_camera_turns_and_near_landmark_are_not_exit_proof(self):
  d=CampDeparture((90,100),(100,100),313,0)
  for t in range(80):self.assertFalse(d.observe((90,100),(100,100),t))
  self.assertFalse(d.observe(None,(100,100),81))
 def test_exit_requires_measurable_distance_increase_scaled_to_minimap(self):
  for width in (156.5,313,626):
   scale=width/313;center=(100,100)
   d=CampDeparture((100-20*scale,100),center,width,0)
   self.assertFalse(d.observe((100-44*scale,100),center,2))
   self.assertTrue(d.observe((100-46*scale,100),center,3))
 def test_leg_timeout_excludes_failed_course_then_chooses_another(self):
  d=CampDeparture((90,100),(100,100),313,0);d.replan(35)
  self.assertEqual(d.leg,2);self.assertIsNone(d.bearing)
  b=d.choose(90,scene().ground,35)
  self.assertGreater(abs((b-90+180)%360-180),22)
 def test_failed_course_can_be_retried_after_finite_memory(self):
  d=CampDeparture((90,100),(100,100),313,0);d.replan(35)
  straight=GroundMap((route(2,.5),))
  self.assertIsNone(d.choose(90,straight,36));self.assertEqual(d.choose(90,straight,81),90)

class CampSteering(unittest.TestCase):
 def test_sharp_left_passage_gets_lateral_translation_not_wall_push(self):
  action=HybridPlanner().choose(Drive(.6),scene([route(0,.2)]),radar(),100,exit_mode=True)
  self.assertLess(action.drive.strafe,-.5)
  self.assertGreater(action.drive.forward,0);self.assertLess(action.drive.forward,abs(action.drive.strafe))
  self.assertLessEqual(math.hypot(action.drive.forward,action.drive.strafe),.71)
 def test_resource_route_keeps_existing_translation(self):
  action=HybridPlanner().choose(Drive(.6),scene([route(0,.2)]),radar(),100,hint=0)
  self.assertAlmostEqual(action.drive.forward,.55);self.assertAlmostEqual(action.drive.strafe,-.48)
 def test_opposite_camp_course_faces_first_without_blind_backwards_walk(self):
  a=HybridPlanner().choose(Drive(-.6,0,.5),scene(),radar(),100,exit_mode=True)
  self.assertEqual((a.drive.forward,a.drive.strafe),(0,0));self.assertEqual(a.drive.yaw,.5)
 def test_forward_camp_course_uses_clear_current_floor(self):
  a=HybridPlanner().choose(Drive(.6),scene(free=.95),radar(),100,exit_mode=True)
  self.assertEqual((a.drive.forward,a.drive.strafe),(.6,0))
 def test_cliff_has_no_direct_departure_even_with_forward_course(self):
  s=scene([route(2,.5)],free=.95);s=replace(s,ground=replace(s.ground,drop_support=.1))
  a=HybridPlanner().choose(Drive(.6),s,radar(),100,exit_mode=True)
  self.assertEqual((a.drive.forward,a.drive.strafe),(0,0))

class DepartureControl(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();screen=self.e.screen;bridge=self.e.bridge
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  cfg={**self.e.cfg,'hybrid_camp_exit':True,'auto_view_recovery':False,'scan_frame_checks':False}
  self.e=HybridGatherEngine(cfg,self.log.append,self.input,network=self.source)
  self.e.screen=screen;self.e.bridge=bridge;self.e.mode='SEARCH'
  self.e.scene_host=SimpleNamespace(offer=lambda *a:None,current=lambda *a:scene(free=.95),close=lambda:None)
  self.e.analyzer=None
 def start(self,anchor=(90,100)):
  with patch.object(he,'purple_anchor',return_value=anchor):self.e._camp_update(self.frame,radar([AIR]),100)
 def test_existing_map_ether_does_not_prevent_initial_departure(self):
  self.start();self.assertTrue(self.e.hybrid_camp_pending);self.assertIsNotNone(self.e.camp_route)
 def test_world_caption_is_still_offered_to_normal_acquisition_during_exit(self):
  self.start()
  with patch.object(he,'purple_anchor',return_value=(90,100)),patch.object(ge.GatherEngine,'step',autospec=True) as step:
   self.e.step(self.frame,(0,0),obs(candidate=self.c),radar([AIR]),GROUND,101,1)
  self.assertIsNotNone(step.call_args.args[3].candidate)
  self.assertEqual(step.call_args.args[4].markers,[]);self.assertTrue(self.e.hybrid_camp_pending)
 def test_resource_policy_sees_ether_even_when_exit_owns_navigation(self):
  self.start()
  with patch.object(self.e.policy,'observe_map',wraps=self.e.policy.observe_map) as observed,patch.object(ge.GatherEngine,'step',autospec=True) as step:
   self.e.step(self.frame,(0,0),obs(),radar([AIR]),GROUND,101,1)
  self.assertEqual(observed.call_args.args[0],[AIR]);self.assertEqual(step.call_args.args[4].markers,[])
 def test_departure_resumes_resource_navigation_only_after_landmark_progress(self):
  self.start()
  with patch.object(he,'purple_anchor',return_value=(65,100)),patch.object(ge.GatherEngine,'step',autospec=True) as step:
   self.e.step(self.frame,(0,0),obs(),radar([AIR]),GROUND,101,1)
  self.assertFalse(self.e.hybrid_camp_pending);self.assertEqual(step.call_args.args[4].markers,[AIR])
 def test_absent_landmark_does_not_fabricate_success(self):
  self.start()
  with patch.object(he,'purple_anchor',return_value=None):self.e._camp_update(self.frame,radar(),137)
  self.assertTrue(self.e.hybrid_camp_pending);self.assertEqual(self.e.camp_route.leg,2)
 def test_map_teleport_discards_old_camp_course(self):
  self.start();self.e.change_mode('MAP_RETURN')
  self.assertIsNone(self.e.camp_route);self.assertEqual(self.e.camp_exit_until,0)
  self.assertFalse(self.e.hybrid_camp_pending);self.assertTrue(self.e.camp_rearm)
 def test_exact_island_bridge_keeps_control(self):
  self.e.return_exit_guard=True;self.start()
  self.assertFalse(self.e.hybrid_camp_pending);self.assertIsNone(self.e.camp_route)
 def test_owned_gathering_proof_releases_exit_but_target_selection_alone_does_not(self):
  self.start();self.e.target_confirmed=True
  with patch.object(ge.GatherEngine,'_adopt_network_collection'),patch.object(self.e,'_net_gather_proof',return_value=False):self.e._adopt_network_collection()
  self.assertTrue(self.e.hybrid_camp_pending)
  with patch.object(ge.GatherEngine,'_adopt_network_collection'),patch.object(self.e,'_net_gather_proof',return_value=True):self.e._adopt_network_collection()
  self.assertFalse(self.e.hybrid_camp_pending);self.assertIsNone(self.e.camp_route)
 def test_empty_map_patrol_camera_or_flight_proposal_cannot_override_exit(self):
  self.start()
  with patch.object(he.time,'monotonic',return_value=100):
   for proposal in (Drive(),Drive(yaw=-.5),Drive(pitch=.4),Drive(flight_probe=True)):
    d=self.e._scene_plan(self.frame,radar(),GROUND,proposal,100)
    self.assertGreater(d.forward,.5);self.assertEqual(d.pitch,0);self.assertFalse(d.flight_probe)
 def test_existing_tilt_is_restored_before_ground_exit(self):
  self.start()
  with patch.object(self.e.pitch,'offset',return_value=.2),patch.object(he.time,'monotonic',return_value=100):
   d=self.e._scene_plan(self.frame,radar(),GROUND,Drive(),100)
  self.assertTrue(d.restore_pitch);self.assertEqual((d.forward,d.strafe),(0,0))
 def test_timed_out_passage_does_not_exclude_surrounding_resources(self):
  from hybrid_navigation import RouteAction
  self.start()
  with patch.object(self.e.hybrid,'choose',return_value=RouteAction(Drive(),'blocked',skip=True)),patch.object(self.e.nav,'exclude_goal') as exclude,patch.object(he.time,'monotonic',return_value=100):
   self.e._scene_plan(self.frame,radar(),GROUND,Drive(.6),100)
  exclude.assert_not_called();self.assertTrue(self.e.hybrid_camp_pending);self.assertEqual(self.e.camp_route.leg,2)
 def test_failed_course_cannot_return_as_empty_map_forward_fallback(self):
  self.start();self.e.camp_route.replan(100)
  self.e.scene_host.current=lambda *a:scene([route(2,.5)],free=.95)
  with patch.object(he.time,'monotonic',return_value=100):
   d=self.e._scene_plan(self.frame,radar(),GROUND,Drive(.6),100)
  self.assertEqual((d.forward,d.strafe),(0,0));self.assertNotEqual(d.yaw,0)
 def test_proven_wall_stall_still_allows_existing_short_lateral_flight(self):
  from hybrid_navigation import RouteAction
  self.start();self.e.budget.energy=80;self.e.terrain_recovery=SimpleNamespace()
  with patch.object(self.e.hybrid,'choose',return_value=RouteAction(Drive(),'wall',skip=True,wall_escape=True)),patch.object(self.e,'_start_terrain_recovery',return_value=True) as flight,patch.object(he.time,'monotonic',return_value=100):
   d=self.e._scene_plan(self.frame,radar(),GROUND,Drive(.6),100)
  self.assertIsNone(d);flight.assert_called_once_with(100,GROUND,short=True)
  self.assertTrue(self.e.hybrid_camp_pending);self.assertTrue(self.e.terrain_recovery.lateral_escape)
