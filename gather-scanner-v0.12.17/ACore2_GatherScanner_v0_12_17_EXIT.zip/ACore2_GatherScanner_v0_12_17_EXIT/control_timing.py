"""Read-only timing watchdog. Never sends input or renews a movement lease."""
import threading,time,sys,traceback

class ControlTiming:
 def __init__(self,emit,slow=.5,stalled=2.):
  self.emit=emit;self.slow=slow;self.stalled=stalled;self.active=None
  self.stop=threading.Event();self.worker=None;self.lock=threading.Lock();self.serial=0
 def start(self):
  if self.worker is None and not self.stop.is_set():
   self.worker=threading.Thread(target=self._watch,daemon=True,name='control-timing');self.worker.start()
 def close(self):self.stop.set()
 def call(self,name,fn,*args,**kwargs):
  began=time.monotonic();cpu_began=time.thread_time()
  with self.lock:
   previous=self.active;self.serial+=1;record=(self.serial,name,began,threading.get_ident());self.active=record
  try:return fn(*args,**kwargs)
  finally:
   elapsed=time.monotonic()-began
   with self.lock:
    if self.active is record:self.active=previous
   if elapsed>=self.slow:self._emit(f'CONTROL_SLOW: {name}; {elapsed:.3f} с; CPU потока={time.thread_time()-cpu_began:.3f} с')
 def _emit(self,message):
  try:self.emit(message)
  except Exception:pass
 def inspect(self,now=None):
  now=time.monotonic() if now is None else now
  with self.lock:record=self.active
  if record is None or now-record[2]<self.stalled:return None
  frame=sys._current_frames().get(record[3]);stack=''
  if frame is not None:
   stack=' > '.join(f'{f.name}:{f.lineno}' for f in traceback.extract_stack(frame,limit=5))
  return f'CONTROL_WAIT: {record[1]}; {now-record[2]:.1f} с; {stack}'
 def _watch(self):
  last=-1e9
  while not self.stop.wait(.25):
   now=time.monotonic()
   if now-last<5:continue
   message=self.inspect(now)
   if message:self._emit(message);last=now
