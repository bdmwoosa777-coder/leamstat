"""Persistent landmark-relative departure; minimap resources are not exit proof."""
import math
from minimap import angle_delta

class CampDeparture:
 def __init__(self,anchor,center,width,now):
  self.anchor=anchor;self.width=width;self.scale=max(.5,width/313)
  self.initial=math.dist(anchor,center)/self.scale;self.distance=self.initial
  self.seen=now;self.until=now+35;self.leg=1;self.failed=[]
  self.bearing=self.away(anchor,center) if self.initial>=6 else None
  self.origin='от кибелиска' if self.bearing is not None else ''
 @staticmethod
 def away(anchor,center):return math.degrees(math.atan2(center[0]-anchor[0],anchor[1]-center[1]))%360
 def observe(self,anchor,center,now):
  if anchor is None:return False
  self.anchor=anchor;self.seen=now;self.distance=math.dist(anchor,center)/self.scale
  return self.distance>=max(45,self.initial+18)
 def replan(self,now):
  if self.bearing is not None:self.failed.append((self.bearing,now+45))
  self.failed=[f for f in self.failed if now<f[1]]
  self.bearing=None;self.origin='';self.until=now+35;self.leg+=1
 def choose(self,heading,ground,now):
  if self.bearing is not None or heading is None or ground is None or ground.drop_support>=.04:return self.bearing
  from hybrid_navigation import route_angle
  options=[r for r in ground.routes if r.confidence>=.40 and r.clearance>=.5
           and not any(abs(angle_delta(heading+route_angle(r),b))<22 for b,t in self.failed if now<t)]
  if not options:return None
  route=max(options,key=lambda r:r.score+.20*r.clearance-.003*abs(route_angle(r)))
  self.bearing=(heading+route_angle(route))%360;self.origin='по видимому проходу'
  return self.bearing
