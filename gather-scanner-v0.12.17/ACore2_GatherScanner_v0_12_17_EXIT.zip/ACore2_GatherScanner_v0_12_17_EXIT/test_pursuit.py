"""Reject repeated wrong captions; finish actual scans and retain nearby Ether."""
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import math,unittest
import cv2,numpy as np
from PIL import Image,ImageDraw,ImageFont
import gather_engine as ge,hybrid_engine as he,vision
from caption_memory import CaptionMemory
from hybrid_engine import HybridGatherEngine
from hybrid_navigation import HybridPlanner
from ground_routes import GroundMap
from navigation import Navigator,Drive
from minimap import Marker
from flight import FlightReading
from test_navigation import GatherFixture,radar,obs
from test_network_control import Source
from test_ether_emblem import scene,ether
from test_hybrid import scene as ground_scene
from test_map_teleport import FONT


def false_caption(scale=1,x=700,y=500):
 if FONT is None:raise unittest.SkipTest('A Cyrillic test font is required')
 image=Image.new('L',(100,32));ImageDraw.Draw(image).text((2,0),'Морфа',font=ImageFont.truetype(FONT,22),fill=255)
 mask=cv2.resize(np.array(image),None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
 mask=(mask>100).astype(np.uint8)*255
 h,w=mask.shape
 return vision.Candidate('Эфир',x+w//2,y+h+10,96,(x,y,w,h),(mask.shape,mask.tobytes()))

def air(x=115,y=100):return Marker('Эфир',x,y,.95,math.hypot(x-100,y-100),'aether')


class CaptionLearning(unittest.TestCase):
 def test_explicit_contradiction_follows_letters_not_screen_position(self):
  m=CaptionMemory();c=false_caption();self.assertTrue(m.remember(c,'Морфа',100))
  self.assertEqual(m.rejected(replace(c,box=(1300,100,120,30),click_x=1360,click_y=140),110),'Морфа')
 def test_resized_rejected_word_is_still_filtered(self):
  m=CaptionMemory();m.remember(false_caption(),'Морфа',100)
  for scale in (.75,1,1.5,2):self.assertEqual(m.rejected(false_caption(scale),101),'Морфа')
 def test_real_ether_at_same_screen_point_is_not_a_rejected_morpha(self):
  m=CaptionMemory();m.remember(false_caption(),'Морфа',100)
  for file in ('ether_near_caption_crop.png','ether_far_caption_crop.png'):
   for scale in (.6,.8,1,1.25,1.5):self.assertIsNone(m.rejected(ether(scene(file,scale)),101))
 def test_unknown_or_agreeing_read_never_teaches_a_negative(self):
  m=CaptionMemory();c=false_caption()
  self.assertFalse(m.remember(c,None,100));self.assertFalse(m.remember(c,'Эфир',100));self.assertEqual(m.entries,())
 def test_no_glyph_cannot_create_a_screen_coordinate_ban(self):
  m=CaptionMemory();self.assertFalse(m.remember(replace(false_caption(),glyph=None),'Морфа',100))
  self.assertIsNone(m.rejected(false_caption(),101))
 def test_memory_expires_and_is_bounded(self):
  m=CaptionMemory(ttl=10,limit=3)
  for i in range(10):m.remember(replace(false_caption(),name=str(i)),'Морфа',100+i)
  self.assertEqual(len(m.entries),3);self.assertIsNone(m.rejected(replace(false_caption(),name='9'),120))
  self.assertEqual(m.entries,())
 def test_repeated_same_mask_refreshes_one_record(self):
  m=CaptionMemory()
  for t in range(100):m.remember(false_caption(),'Морфа',t)
  self.assertEqual(len(m.entries),1);self.assertEqual(m.rejected(false_caption(),120),'Морфа')
 def test_fast_pass_continues_to_other_caption_after_rejected_candidate(self):
  f=scene();crop=cv2.imread(str(Path(ge.ROOT)/'testdata/ether_near_caption_crop.png'));h,w=crop.shape[:2]
  f[550:550+h,700:700+w]=crop
  found=vision.fast_ether_candidates(f,rejected=lambda c:c.box[0]>1000)
  self.assertTrue(found);self.assertTrue(all(c.box[0]<1000 for c in found))
  self.assertLess(vision.find_world_resource(f,rejected=lambda c:c.box[0]>1000).box[0],1000)


class ScanProgress(unittest.TestCase):
 def make(self,near=False):
  n=Navigator({'air_search_wide':True,'air_search_map_radius':30});r=radar([air(108 if near else 115)])
  d=n.update(r,100);return n,r,d
 def test_expired_approach_timer_cannot_abort_a_started_scan(self):
  n,r,_=self.make();n.goal_started=50
  d=n.update(r,102);self.assertGreater(d.pitch,0);self.assertFalse(d.restore_pitch);self.assertFalse(d.flight_probe)
 def test_long_ocr_pause_cannot_switch_to_down_after_only_three_up_commands(self):
  n,r,_=self.make();n.update(r,101);n.update(r,102)
  d=n.update(r,125);self.assertGreater(d.pitch,0);self.assertEqual(n.scan_last_pulse,3)
  self.assertFalse(d.restore_pitch);self.assertIsNotNone(n.goal)
 def test_slow_loop_delivers_all_eight_up_steps_hold_and_eight_down_steps(self):
  n,r,d=self.make();plans=[d]
  for i in range(1,17):plans.append(n.update(r,100+i*1.3))
  self.assertTrue(all(d.pitch>0 for d in plans[:8]));self.assertEqual(plans[8].pitch,0)
  self.assertTrue(all(d.pitch<0 for d in plans[9:]));self.assertAlmostEqual(sum(d.pitch*d.lifetime for d in plans),0)
  end=n.update(r,123);self.assertTrue(end.restore_pitch);self.assertFalse(end.flight_probe)
  self.assertFalse(n.excluded);self.assertEqual(n.goal_started,123)
 def test_outer_finish_leaves_time_to_approach_instead_of_immediate_flight(self):
  n,r,_=self.make();n.goal_started=50;n.scan_last_pulse=16;n.scan_next_at=150
  self.assertTrue(n.update(r,150).restore_pitch)
  d=n.update(r,151);self.assertGreater(d.forward,.5);self.assertFalse(d.flight_probe)
 def test_near_scan_is_finite_by_delivered_steps_even_after_long_pause(self):
  n,r,d=self.make(True);plans=[d];now=100
  while not d.restore_pitch:
   now=max(now+1.1,n.scan_next_at+.01);d=n.update(r,now);plans.append(d)
   self.assertLess(len(plans),44)
  self.assertEqual(sum(d.pitch>0 for d in plans),20);self.assertEqual(sum(d.pitch<0 for d in plans),20)
  self.assertTrue(d.flight_probe);self.assertAlmostEqual(sum(d.pitch*d.lifetime for d in plans),0)
 def test_lost_marker_still_ends_scan_after_freshness_limit(self):
  n,_,_=self.make();d=n.update(radar(),112)
  self.assertTrue(d.restore_pitch);self.assertIsNone(n.air_since)
 def test_far_unscanned_goal_still_has_approach_timeout(self):
  n=Navigator({'minimap_goal_timeout_seconds':45});r=radar([air(160)])
  n.update(r,100);self.assertTrue(n.update(r,146).flight_probe)


class NearbyEther(unittest.TestCase):
 def test_successful_goal_does_not_exclude_even_an_almost_touching_neighbor(self):
  n=Navigator({});a=air(108);b=air(110);n.update(radar([a,b]),100);n.finish_goal(101)
  self.assertFalse(n.excluded);n.update(radar([b]),102);self.assertEqual(n.goal,b)
 def test_completed_goal_does_not_leave_any_kind_cooldown(self):
  n=Navigator({});n.update(radar([air(108)]),100);n.finish_goal(101)
  self.assertFalse(n.kind_until);self.assertFalse(n.is_retreating(102))
 def test_failed_goal_blocks_only_one_of_two_close_ether_points(self):
  n=Navigator({});a=air(108);b=air(110);n.update(radar([a,b]),100);n.exclude_goal(101,30)
  n.update(radar([a,b]),102);self.assertEqual(n.goal,b)
 def test_failed_ether_does_not_disable_whole_resource_kind_after_retreat(self):
  n=Navigator({});a=air(108);b=air(110);n.update(radar([a,b]),100);n.abandon_goal(101,60)
  self.assertNotIn('aether',n.kind_until);self.assertTrue(n.is_retreating(102));n.pause(101)
  n.update(radar([a,b]),107);self.assertEqual(n.goal,b)
 def test_displacement_tracks_failed_marker_without_excluding_neighbor(self):
  n=Navigator({});n.update(radar([air(108)]),100);n.exclude_goal(101,30)
  r=radar([air(112),air(114)]);r.motion_valid=True;r.displacement=(4,0)
  n.update(r,102);self.assertEqual(n.goal.x,114)
 def test_existing_ground_obstacle_area_avoidance_is_preserved(self):
  n=Navigator({});a=replace(air(108),kind='gem',name='Самоцвет');b=replace(a,x=110,distance=10)
  n.update(radar([a,b]),100);n.exclude_goal(101,30);n.update(radar([a,b]),102)
  self.assertIsNone(n.goal)


class FacingEther(unittest.TestCase):
 def test_front_wall_cannot_reverse_a_minimap_turn_to_ether_behind_camera(self):
  r=replace(ground_scene(),ground=GroundMap());p=HybridPlanner()
  a=p.choose(Drive(-.7,.3,.62),r,radar(),100,face_goal=True)
  self.assertEqual(a.drive.yaw,.62);self.assertEqual((a.drive.forward,a.drive.strafe),(0,0));self.assertFalse(a.skip)
 def test_missing_frame_and_old_obstacle_timer_still_cannot_reverse_turn(self):
  p=HybridPlanner();p.blocked_at=90
  a=p.choose(Drive(-.7,-.3,-.62),None,radar(),100,face_goal=True)
  self.assertEqual(a.drive.yaw,-.62);self.assertFalse(a.skip);self.assertEqual(a.drive.forward,0)
 def test_camera_pause_does_not_invent_a_survey_turn_or_a_backwards_step(self):
  a=HybridPlanner().choose(Drive(-.7,.3,0),None,radar(),100,face_goal=True)
  self.assertEqual((a.drive.forward,a.drive.strafe,a.drive.yaw),(0,0,0))
 def test_real_cliff_still_blocks_motion_after_facing_resource(self):
  r=replace(ground_scene(),ground=GroundMap(drop_support=.3))
  a=HybridPlanner().choose(Drive(.78),r,radar(),100,face_goal=True)
  self.assertEqual(a.drive.forward,0);self.assertEqual(a.drive.strafe,0)
 def test_confirmed_open_forward_path_keeps_active_movement(self):
  a=HybridPlanner().choose(Drive(.78),ground_scene(free=.95),radar(),100,face_goal=True)
  self.assertGreater(a.drive.forward,.5)
 def test_camp_exit_keeps_its_separate_path_requirement(self):
  a=HybridPlanner().choose(Drive(-.7,.3,.62),None,radar(),100,face_goal=True,exit_mode=True)
  self.assertEqual((a.drive.forward,a.drive.strafe),(0,0));self.assertEqual(a.drive.yaw,.62)


class PursuitEngine(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e;self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=HybridGatherEngine({**old.cfg,'hybrid_camp_exit':False,'auto_view_recovery':False},self.log.append,self.input,network=self.source)
  self.e.screen=old.screen;self.e.bridge=old.bridge;self.e.mode='SEARCH';self.e.target=None
  self.clock=100.;p=patch.object(he.time,'monotonic',side_effect=lambda:self.clock);p.start();self.addCleanup(p.stop)
  self.c=false_caption();self.e.budget.energy=80
 def reject(self):
  with patch.object(he,'read_world_caption',return_value=('Морфа','Морфа')):
   self.assertFalse(self.e._acquire_caption_matches(self.frame,self.c))
 def test_one_ocr_rejection_prevents_all_six_recorded_repeated_stops(self):
  self.reject()
  with patch.object(he,'read_world_caption',side_effect=AssertionError('repeated OCR')):
   for t in range(101,107):
    self.clock=t;self.e._candidate_observed(self.c,t,0)
    self.assertFalse(self.e._allowed(self.c,t));self.assertFalse(self.e._acquire_caption_matches(self.frame,self.c))
  self.assertIsNone(self.e.caption_latch);self.assertEqual(self.pad.presses,0)
 def test_failed_acquisition_releases_old_latch_and_keeps_scan(self):
  self.e.caption_latch={'candidate':self.c};self.e.nav.update(radar([air(108)]),99)
  self.e._acquire_miss(self.c,100)
  self.assertIsNone(self.e.caption_latch);self.assertIsNotNone(self.e.nav.air_since);self.assertEqual(self.e.mode,'SEARCH')
 def test_rejected_old_snapshot_does_not_stop_next_search_step(self):
  self.reject();self.e.step(self.frame,(0,0),obs(candidate=self.c),radar([air(160)]),FlightReading(80,False),101,1)
  self.assertEqual(self.e.mode,'SEARCH');self.assertEqual(self.pad.presses,0);self.assertGreater(self.pad.axes[1],.5)
 def test_other_real_ether_still_latches_immediately(self):
  self.reject();self.frame=scene();c=ether(self.frame);self.e._candidate_observed(c,100,0)
  self.assertIsNotNone(self.e.caption_latch);self.assertEqual(self.e.caption_latch['candidate'].box,c.box)
 def test_successful_network_collection_uses_no_map_area_exclusion(self):
  f=self.source.state;f.collecting=99;f.nodes[99].used=3;f.nodes[99].gather_time=1000
  self.e.target='Эфир';self.e.target_confirmed=True;self.e.mode='GATHER';self.e.network_target=(1,99)
  self.e.network_owner=7;self.e.network_claimed_at=900;self.e.network_exhausted=True
  self.e.nav.update(radar([air(108),air(110)]),99)
  self.e.return_to_search('completed',self.frame,reading=FlightReading(80,False),exhausted=True)
  self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.nav.excluded)
  self.e.nav.update(radar([air(110)]),101);self.assertEqual(self.e.nav.goal.x,110)
 def test_owned_resource_blocks_search_memory_and_facing_inputs(self):
  f=self.source.state;f.collecting=99;f.attempt_active=True;f.nodes[99].gather_time=1000
  self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
  self.e.network_target=(1,99);self.e.network_claimed_at=900
  with patch.object(self.e,'_resource_fast_tick',return_value=True):
   self.e.step(self.frame,(0,0),obs(candidate=self.c),radar([air(160)]),FlightReading(80,False),100,1)
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.presses,0);self.assertIsNone(self.e.caption_latch)


if __name__=='__main__':unittest.main()
