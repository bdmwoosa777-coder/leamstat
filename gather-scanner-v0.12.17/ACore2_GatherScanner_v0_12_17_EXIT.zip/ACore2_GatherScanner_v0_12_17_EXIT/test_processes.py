"""Real spawn IPC, blocked-child responsiveness, freshness, cancellation and cleanup."""
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import os,sys,queue,threading,time,unittest
import numpy as np
from isolated_vision import ProcessSceneHost,WorldProcess,_latest
from scene_navigation import SceneReading,Lane
from vision import Candidate
from responsive_runtime import ResponsiveRuntime
from navigation import Drive
from flight import FlightReading
from test_navigation import GatherFixture,radar
from hybrid_engine import HybridGatherEngine
from test_network_control import Source


def fake_scene(cfg,inbox,outbox,events,stop):
 events.put('FAKE_SCENE_READY')
 while not stop.is_set():
  try:frame,captured,heading,pitch,revision=inbox.get(timeout=.05)
  except queue.Empty:continue
  r=SceneReading(captured,heading,pitch,1,(Lane(.9,0,0,0),)*3,backend=str(os.getpid()),revision=revision)
  _latest(outbox,r)


def blocked_scene(cfg,inbox,outbox,events,stop):
 events.put('FAKE_SCENE_READY')
 value=1
 while not stop.is_set():value=(value*1664525+1013904223)%4294967296


def ignoring_scene(cfg,inbox,outbox,events,stop):
 events.put('FAKE_SCENE_READY')
 while True:time.sleep(.05)


def echo_world(inbox,outbox,stop):
 while not stop.is_set():
  try:seq,frame,names,entries=inbox.get(timeout=.05)
  except queue.Empty:continue
  if names==('BLOCK',):
   while not stop.wait(.02):pass
   continue
  if names==('WRONG_FIRST',):_latest(outbox,(seq-1,None,None));time.sleep(.05)
  candidate=Candidate(names[0],int(frame[0,0,0]),os.getpid(),95,(1,2,30,12))
  _latest(outbox,(seq,candidate,None))


def wait_for(predicate,seconds=4):
 until=time.monotonic()+seconds
 while time.monotonic()<until:
  if predicate():return True
  time.sleep(.01)
 return False

class SceneProcesses(unittest.TestCase):
 def make(self,target=fake_scene):
  self.notes=[];host=ProcessSceneHost({},self.notes.append,worker_target=target);self.addCleanup(host.close)
  host.start();self.assertTrue(wait_for(lambda:'FAKE_SCENE_READY' in self.notes));return host
 def test_real_spawn_returns_data_from_a_different_pid(self):
  h=self.make();now=time.monotonic();h.offer(np.zeros((100,200,3),np.uint8),now,90,0,7)
  self.assertTrue(wait_for(lambda:h.latest is not None));r=h.current(time.monotonic(),90,0,7)
  self.assertIsNotNone(r);self.assertNotEqual(int(r.backend),os.getpid())
 def test_old_rotated_tilted_or_wrong_camera_epoch_cannot_be_executed(self):
  h=self.make();now=time.monotonic();h.offer(np.zeros((100,200,3),np.uint8),now,90,0,7)
  self.assertTrue(wait_for(lambda:h.latest is not None))
  self.assertIsNone(h.current(now+2,90,0,7));self.assertIsNone(h.current(now+.1,150,0,7))
  self.assertIsNone(h.current(now+.1,90,.1,7));self.assertIsNone(h.current(now+.1,90,0,8))
 def test_busy_child_does_not_make_offer_or_current_wait_for_inference(self):
  h=self.make(blocked_scene)
  for i in range(8):
   h.offer(np.zeros((100,200,3),np.uint8),time.monotonic()+i,90,0)
   self.assertIsNone(h.current(time.monotonic(),90,0))
  self.assertTrue(h.worker.is_alive())
 def test_close_clears_results_and_stops_the_spawned_process(self):
  h=self.make();process=h.worker;h.close();self.assertFalse(process.is_alive());self.assertIsNone(h.latest)
  h.offer(np.zeros((100,200,3),np.uint8),time.monotonic(),90,0);self.assertFalse(process.is_alive())
 def test_ignoring_child_is_terminated_without_hanging_parent_shutdown(self):
  h=self.make(ignoring_scene);process=h.worker;h.close();self.assertFalse(process.is_alive())
 def test_request_and_reply_queues_are_bounded_to_one_frame(self):
  h=self.make(blocked_scene);self.assertEqual(h.inbox._maxsize,1);self.assertEqual(h.outbox._maxsize,1)

class WorldProcesses(unittest.TestCase):
 def make(self,target=echo_world):
  w=WorldProcess(worker_target=target);self.addCleanup(w.close);return w
 def test_world_reply_matches_the_submitted_frame_and_child_pid(self):
  w=self.make();f=np.full((20,30,3),71,np.uint8);c=w.search(f,('Эфир',),(),threading.Event())
  self.assertIsNotNone(c);self.assertEqual(c.click_x,71);self.assertNotEqual(c.click_y,os.getpid())
 def test_reply_from_a_previous_request_cannot_select_a_resource(self):
  w=self.make();c=w.search(np.zeros((20,30,3),np.uint8),('WRONG_FIRST',),(),threading.Event())
  self.assertIsNotNone(c);self.assertEqual(c.name,'WRONG_FIRST')
 def test_cancelled_wait_does_not_wait_for_the_blocked_child(self):
  w=self.make();stop=threading.Event();threading.Timer(.25,stop.set).start()
  c=w.search(np.zeros((20,30,3),np.uint8),('BLOCK',),(),stop)
  self.assertIsNone(c);self.assertTrue(stop.is_set())
 def test_timeout_is_finite_and_close_stops_the_process(self):
  w=self.make();c=w.search(np.zeros((20,30,3),np.uint8),('BLOCK',),(),threading.Event(),timeout=.15)
  self.assertIsNone(c);process=w.worker;w.close();self.assertFalse(process.is_alive())
 def test_closed_worker_cannot_spawn_again(self):
  w=self.make();w.close();self.assertIsNone(w.search(np.zeros((20,30,3),np.uint8),('Эфир',),(),threading.Event()))
  self.assertIsNone(w.worker)

class ControllerIsolation(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e;source=Source();source.state.collecting=None;source.state.attempt_active=False
  self.e=HybridGatherEngine({**old.cfg,'analyzer_enabled':False},self.log.append,self.input,network=source)
  self.e.screen=old.screen;self.e.bridge=old.bridge;self.e.mode='SEARCH'
 def test_parent_keeps_renewing_motion_while_scene_process_is_busy(self):
  notes=[];host=ProcessSceneHost({},notes.append,worker_target=blocked_scene);self.addCleanup(host.close)
  host.start();self.assertTrue(wait_for(lambda:'FAKE_SCENE_READY' in notes));self.e.scene_host=host
  count=0
  for _ in range(6):
   now=time.monotonic();d=self.e._scene_plan(self.frame,radar(),FlightReading(80,False),Drive(.9),now)
   if self.e._motion(d):count+=1
   time.sleep(.04)
  self.assertEqual(count,6);self.assertGreater(self.pad.axes[1],.5);self.assertTrue(host.worker.is_alive())
 def test_real_world_process_detects_existing_caption_without_a_controller(self):
  from test_ether_emblem import scene
  w=WorldProcess();self.addCleanup(w.close);f=scene()
  c=w.search(f,('Эфир',),(),threading.Event(),timeout=5)
  self.assertIsNotNone(c);self.assertEqual(c.name,'Эфир');self.assertIsNotNone(c.emblem)
 def test_confirmed_own_collection_still_blocks_parent_motion_with_busy_child(self):
  self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
  self.e._motion(Drive(.9));self.assertEqual(self.pad.axes,(0,0,0,0))

class ResponsiveScheduling(unittest.TestCase):
 def test_switch_interval_is_restored_after_scope(self):
  old=sys.getswitchinterval();runtime=ResponsiveRuntime()
  try:runtime.start();self.assertAlmostEqual(sys.getswitchinterval(),.001)
  finally:runtime.close()
  self.assertEqual(sys.getswitchinterval(),old)
 def test_start_and_close_are_idempotent(self):
  old=sys.getswitchinterval();r=ResponsiveRuntime();r.start();r.start();r.close();r.close()
  self.assertEqual(sys.getswitchinterval(),old)
 def test_separate_configuration_change_is_not_overwritten_on_close(self):
  old=sys.getswitchinterval();r=ResponsiveRuntime()
  try:r.start();sys.setswitchinterval(.002);r.close();self.assertAlmostEqual(sys.getswitchinterval(),.002)
  finally:sys.setswitchinterval(old)

class WindowsSchedulerContracts(unittest.TestCase):
 def dlls(self,begin=0,priority=0):
  class Call:
   def __init__(self,value):self.value=value;self.calls=[]
   def __call__(self,*args):self.calls.append(args);return self.value
  timer=SimpleNamespace(timeBeginPeriod=Call(begin),timeEndPeriod=Call(0))
  kernel=SimpleNamespace(GetCurrentThread=Call(123),GetThreadPriority=Call(priority),SetThreadPriority=Call(1))
  return timer,kernel
 def test_windows_timer_and_control_thread_priority_are_restored_exactly_once(self):
  import responsive_runtime as rr
  timer,kernel=self.dlls();r=ResponsiveRuntime();old=sys.getswitchinterval()
  with patch.object(rr,'os',SimpleNamespace(name='nt')),patch('ctypes.WinDLL',create=True,side_effect=lambda name,**kw:timer if name=='winmm' else kernel):
   try:r.start();r.start()
   finally:r.close();r.close()
  self.assertEqual(timer.timeBeginPeriod.calls,[(1,)]);self.assertEqual(timer.timeEndPeriod.calls,[(1,)])
  self.assertEqual(kernel.SetThreadPriority.calls,[(123,1),(123,0)]);self.assertEqual(sys.getswitchinterval(),old)
 def test_rejected_timer_request_is_not_claimed_or_released(self):
  import responsive_runtime as rr
  timer,kernel=self.dlls(begin=1);r=ResponsiveRuntime()
  with patch.object(rr,'os',SimpleNamespace(name='nt')),patch('ctypes.WinDLL',create=True,side_effect=lambda name,**kw:timer if name=='winmm' else kernel):
   try:r.start();self.assertIsNone(r.timer)
   finally:r.close()
  self.assertEqual(timer.timeEndPeriod.calls,[])
 def test_existing_higher_priority_is_not_lowered(self):
  import responsive_runtime as rr
  timer,kernel=self.dlls(priority=2);r=ResponsiveRuntime()
  with patch.object(rr,'os',SimpleNamespace(name='nt')),patch('ctypes.WinDLL',create=True,side_effect=lambda name,**kw:timer if name=='winmm' else kernel):
   try:r.start()
   finally:r.close()
  self.assertEqual(kernel.SetThreadPriority.calls,[])

if __name__=='__main__':unittest.main()
