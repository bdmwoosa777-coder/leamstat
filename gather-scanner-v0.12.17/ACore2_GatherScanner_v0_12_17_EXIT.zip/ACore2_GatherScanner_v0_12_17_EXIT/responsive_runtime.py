"""Process-local scheduling hints; no realtime priority or permanent OS changes."""
import os,sys

class ResponsiveRuntime:
 def __init__(self,emit=lambda message:None):
  self.emit=emit;self.previous=None;self.timer=None;self.kernel=None;self.thread=None;self.priority=None
 def start(self):
  if self.previous is not None:return
  self.previous=sys.getswitchinterval();sys.setswitchinterval(.001)
  if os.name=='nt':
   try:
    import ctypes
    from ctypes import wintypes
    timer=ctypes.WinDLL('winmm');timer.timeBeginPeriod.argtypes=[wintypes.UINT];timer.timeBeginPeriod.restype=wintypes.UINT
    timer.timeEndPeriod.argtypes=[wintypes.UINT];timer.timeEndPeriod.restype=wintypes.UINT
    if timer.timeBeginPeriod(1)==0:self.timer=timer
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.GetCurrentThread.restype=wintypes.HANDLE
    kernel.GetThreadPriority.argtypes=[wintypes.HANDLE];kernel.GetThreadPriority.restype=ctypes.c_int
    kernel.SetThreadPriority.argtypes=[wintypes.HANDLE,ctypes.c_int];kernel.SetThreadPriority.restype=wintypes.BOOL
    thread=kernel.GetCurrentThread();priority=kernel.GetThreadPriority(thread)
    if priority!=0x7fffffff and priority<1 and kernel.SetThreadPriority(thread,1):self.kernel=kernel;self.thread=thread;self.priority=priority
   except Exception as exc:self.emit('CONTROL_SCHEDULER: '+str(exc))
  self.emit('CONTROL_SCHEDULER: квант Python 1 мс; запрос таймера 1 мс='+str(self.timer is not None)+'; приоритет управляющего потока повышен='+str(self.kernel is not None))
 def close(self):
  if self.kernel is not None:
   try:self.kernel.SetThreadPriority(self.thread,self.priority)
   except Exception:pass
   self.kernel=None
  if self.timer is not None:
   try:self.timer.timeEndPeriod(1)
   except Exception:pass
   self.timer=None
  if self.previous is not None:
   if abs(sys.getswitchinterval()-.001)<1e-7:sys.setswitchinterval(self.previous)
   self.previous=None
