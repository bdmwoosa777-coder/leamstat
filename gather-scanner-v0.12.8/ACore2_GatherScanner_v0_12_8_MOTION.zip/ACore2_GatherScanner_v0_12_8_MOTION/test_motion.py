"""Faint blue-sky captions, larger up scans, and a persistent obstacle deadline."""
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import math,time,unittest
import cv2,numpy as np
import vision,hybrid_engine as he
from hybrid_engine import HybridGatherEngine
from hybrid_navigation import HybridPlanner
from terrain_recovery import TerrainRecovery
from area_recovery import AreaRecovery
from ground_routes import GroundMap
from scene_navigation import Lane
from flight import FlightReading
from navigation import Navigator,Drive
from test_navigation import GatherFixture,radar
from test_network_control import Source
from test_ether_emblem import scene
from test_hybrid import scene as ground_scene
from test_pursuit import air

GROUND=FlightReading(80,False)
WALL=Lane(.02,.80,0,.18)

def faded(alpha=.14,scale=1,file='ether_near_caption_crop.png',badge=True,y=250):
 f=scene(file,scale=scale,badge=badge,y=y)
 return cv2.addWeighted(f,alpha,np.full_like(f,(135,100,75)),1-alpha,0)

def wall(now=100,drop=0):
 return replace(ground_scene(t=now),lanes=(WALL,)*3,ground=GroundMap(drop_support=drop))


class FaintWorld(unittest.TestCase):
 def test_near_word_faded_into_blue_sky_is_recognized_at_six_contrast_levels(self):
  for alpha in (.10,.14,.18,.24,.40,.70):
   with self.subTest(alpha=alpha):
    found=vision.fast_ether_candidates(faded(alpha))
    self.assertTrue(found);self.assertEqual(found[0].name,'Эфир');self.assertIsNotNone(found[0].emblem)
 def test_far_word_uses_local_chroma_when_absolute_colour_is_absent(self):
  f=faded(.18,file='ether_far_caption_crop.png')
  found=vision.fast_ether_candidates(f);self.assertTrue(found)
  c=found[0];x,y,w,h=c.box
  self.assertEqual(c.glyph_mode,'faint');self.assertEqual(np.count_nonzero(vision.color_mask(f[y:y+h,x:x+w])),0)
 def test_faint_candidate_requires_a_nearby_resource_emblem(self):
  self.assertEqual(vision.fast_ether_candidates(faded(.14,badge=False)),[])
 def test_refresh_uses_the_same_faint_mask_after_the_caption_moves(self):
  f=faded();c=vision.fast_ether_candidates(f)[0]
  moved=cv2.warpAffine(f,np.float32([[1,0,14],[0,1,9]]),(f.shape[1],f.shape[0]),borderValue=(135,100,75))
  fresh=vision.find_resource_near(moved,c)
  self.assertIsNotNone(fresh);self.assertAlmostEqual(fresh.box[0]-c.box[0],14,delta=2)
  self.assertAlmostEqual(fresh.box[1]-c.box[1],9,delta=2);self.assertIsNotNone(fresh.emblem)
 def test_native_size_glyph_and_coordinates_return_from_4k_coarse_pass(self):
  f=faded(.14,scale=1.5);found=vision.fast_ether_candidates(f)
  self.assertTrue(found);c=found[0]
  self.assertGreater(c.box[0],1600);self.assertEqual(c.glyph[0],(c.box[3],c.box[2]))
  self.assertIsNotNone(vision.find_resource_near(f,c))
 def test_upper_world_caption_is_found_before_the_down_bracket(self):
  f=faded(.18,y=0);h,w=f.shape[:2]
  found=vision.fast_ether_candidates(f,bounds=(round(w*.02),round(h*.02),round(w*.98),round(h*.55)))
  self.assertTrue(found);self.assertLess(found[0].box[1],h*.12)
 def test_rejected_faint_word_does_not_bypass_the_existing_caption_filter(self):
  self.assertEqual(vision.fast_ether_candidates(faded(),rejected=lambda c:True),[])
 def test_sky_stars_without_letters_are_not_a_resource(self):
  f=np.full((1152,2048,3),(135,100,75),np.uint8);rng=np.random.default_rng(7)
  for x,y in rng.integers([720,180],[1550,750],size=(500,2)):cv2.circle(f,(int(x),int(y)),1,(200,205,195),-1)
  self.assertEqual(vision.fast_ether_candidates(f),[])
 def test_hud_name_is_still_excluded_in_faint_mode(self):
  f=faded(.18,y=0)
  f=cv2.warpAffine(f,np.float32([[1,0,0],[0,1,-50]]),(f.shape[1],f.shape[0]),borderValue=(135,100,75))
  self.assertEqual(vision.fast_ether_candidates(f),[])


class LargerSearch(unittest.TestCase):
 def test_outer_scan_reaches_fifty_percent_more_upward_axis_time(self):
  n=Navigator({'air_search_wide':True,'air_search_map_radius':30});r=radar([air(115)])
  now=100;d=n.update(r,now);up=[]
  for _ in range(8):
   up.append(d);now=n.scan_next_at+.01;d=n.update(r,now)
  self.assertTrue(all(p.pitch==.45 for p in up));self.assertEqual(d.pitch,0)
  self.assertGreater(sum(p.pitch*p.lifetime for p in up),6*.45*.069*1.49)
  self.assertAlmostEqual(up[0].lifetime,.078);self.assertLess(up[0].lifetime,.080)
 def test_near_scan_does_ten_up_commands_before_any_down(self):
  n=Navigator({'air_search_wide':True});r=radar([air(108)]);d=n.update(r,100)
  for _ in range(10):
   self.assertGreater(d.pitch,0);d=n.update(r,n.scan_next_at+.01)
  self.assertEqual(d.pitch,0);d=n.update(r,n.scan_next_at+.01);self.assertLess(d.pitch,0)
 def test_larger_steps_still_leave_a_stationary_detection_interval(self):
  n=Navigator({'air_search_wide':True});r=radar([air(108)]);d=n.update(r,100)
  self.assertGreaterEqual(n.scan_next_at-100-d.lifetime,.299)
  d=n.update(r,100+.078+.10);self.assertEqual(d.pitch,0);self.assertEqual(n.scan_last_pulse,0)


class PersistentObstacle(unittest.TestCase):
 def test_facing_turns_do_not_reset_the_obstacle_deadline(self):
  p=HybridPlanner();p.choose(Drive(.78),wall(),radar(),100)
  for t in (102,104,106):p.choose(Drive(-.7,.3,.62),None,radar(),t,face_goal=True)
  a=p.choose(Drive(.78),wall(108),radar(),108)
  self.assertTrue(a.skip);self.assertTrue(a.wall_escape);self.assertEqual(a.drive.forward,0)
 def test_tentative_paths_without_measured_motion_do_not_reset_deadline(self):
  p=HybridPlanner();p.choose(Drive(.78),wall(),radar(),100)
  for t in (102,104,106):p.choose(Drive(.78),ground_scene(t=t),radar(),t,hint=0)
  self.assertTrue(p.choose(Drive(.78),wall(108),radar(),108).skip)
 def test_actual_map_translation_resets_episode(self):
  p=HybridPlanner();p.choose(Drive(.78),wall(),radar(),100)
  r=radar();r.motion_valid=True;r.displacement=(4,0)
  self.assertFalse(p.choose(Drive(.78),wall(106),r,106).skip)
  self.assertFalse(p.choose(Drive(.78),wall(108),radar(),108).skip)
 def test_small_back_and_forth_jitter_is_not_progress(self):
  p=HybridPlanner();p.choose(Drive(.78),wall(),radar(),100)
  for t in range(101,109):
   r=radar();r.motion_valid=True;r.displacement=(.1 if t%2 else -.1,0)
   a=p.choose(Drive(.78),wall(t),r,t)
  self.assertTrue(a.skip)
 def test_drop_and_missing_frames_cannot_request_wall_flight(self):
  p=HybridPlanner();p.choose(Drive(.78),wall(drop=.2),radar(),100)
  a=p.choose(Drive(.78),None,radar(),108)
  self.assertTrue(a.skip);self.assertFalse(a.wall_escape);self.assertEqual(a.drive.forward,0)
 def test_prior_cliff_evidence_prevents_relabeling_it_as_a_wall_escape(self):
  p=HybridPlanner();p.choose(Drive(.78),wall(drop=.2),radar(),100)
  a=p.choose(Drive(.78),wall(108),radar(),108)
  self.assertTrue(a.skip);self.assertFalse(a.wall_escape)
 def test_camp_exit_does_not_receive_short_wall_flight(self):
  p=HybridPlanner();p.choose(Drive(.78),wall(),radar(),100,exit_mode=True)
  a=p.choose(Drive(.78),wall(108),radar(),108,exit_mode=True)
  self.assertTrue(a.skip);self.assertFalse(a.wall_escape)
 def test_confirmed_clear_route_has_faster_translation(self):
  r=ground_scene(free=.85);a=HybridPlanner().choose(Drive(.78),r,radar(),100,hint=0)
  self.assertGreaterEqual(a.drive.forward,.69);self.assertLessEqual(a.drive.forward,.71)
 def test_uncertain_or_edge_route_is_not_accelerated(self):
  for r in (ground_scene(free=.4),wall(drop=.2)):
   a=HybridPlanner().choose(Drive(.78),r,radar(),100,hint=0)
   self.assertLessEqual(a.drive.forward,.55)
 def test_short_fresh_gap_keeps_actual_detour_moving(self):
  p=HybridPlanner();p.choose(Drive(.78),ground_scene(t=100),radar(),100,hint=0)
  a=p.choose(Drive(.78),None,radar(),100.2)
  self.assertTrue(a.detour);self.assertAlmostEqual(math.hypot(a.drive.forward,a.drive.strafe),.5)


class WallEscapeEngine(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e;self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=HybridGatherEngine({**old.cfg,'terrain_rescue_enabled':True,'area_search_rescue':True,'hybrid_camp_exit':False},self.log.append,self.input,network=self.source)
  self.e.screen=old.screen;self.e.bridge=old.bridge;self.e.mode='SEARCH';self.e.target=None;self.e.budget.energy=80
  self.e.scene_host=SimpleNamespace(offer=lambda *a:None,current=lambda *a:wall(100));self.e.hybrid.problem_since=90
  self.e.nav.goal=air(115);self.clock=100
  p=patch.object(he.time,'monotonic',side_effect=lambda:self.clock);p.start();self.addCleanup(p.stop)
 def act(self):return self.e._scene_plan(self.frame,radar(),GROUND,Drive(.78),100)
 def test_real_engine_starts_short_recovery_instead_of_area_flight_cycles(self):
  self.assertIsNone(self.act());self.assertEqual(self.e.mode,'RESCUE')
  self.assertIsInstance(self.e.terrain_recovery,TerrainRecovery);self.assertNotIsInstance(self.e.terrain_recovery,AreaRecovery)
  self.assertTrue(self.e.terrain_recovery.fly);self.assertEqual(self.pad.presses,0);self.assertNotIn('V',self.commands)
 def test_low_energy_replans_without_opening_wings(self):
  self.e.budget.energy=49;self.act()
  self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.terrain_recovery);self.assertNotIn('V',self.commands)
 def test_confirmed_own_collection_retires_old_obstacle_episode(self):
  f=self.source.state;f.collecting=99;f.nodes[99].gather_time=1000;f.attempt_active=True
  self.assertTrue(self.e._adopt_network_collection())
  self.assertIsNone(self.e.hybrid.problem_since);self.assertIsNone(self.e.hybrid.blocked_at)
  self.assertTrue(self.e.resource_hold);self.assertEqual(self.pad.presses,0)
 def test_cooldown_prevents_repeated_short_flight(self):
  self.e.wall_escape_after=130;self.act()
  self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.terrain_recovery)
 def test_owned_attempt_arriving_at_final_check_blocks_new_recovery(self):
  def frame():
   f=self.source.state;f.collecting=99;f.nodes[99].gather_time=1000;f.attempt_active=True
   return self.frame,(0,0)
  self.e.screen.frame=frame;self.act()
  self.assertIsNone(self.e.terrain_recovery);self.assertEqual(self.pad.presses,0);self.assertNotIn('V',self.commands)
 def test_caption_arriving_during_final_frame_prevents_escape(self):
  def frame():self.e.caption_latch={'candidate':air()};return self.frame,(0,0)
  self.e.screen.frame=frame;self.act()
  self.assertIsNone(self.e.terrain_recovery);self.assertEqual(self.pad.presses,0);self.assertNotIn('V',self.commands)
 def test_network_loss_during_final_frame_prevents_escape(self):
  def frame():self.source.ready=False;return self.frame,(0,0)
  self.e.screen.frame=frame;self.act()
  self.assertIsNone(self.e.terrain_recovery);self.assertEqual(self.pad.presses,0);self.assertNotIn('V',self.commands)
 def test_stop_or_focus_loss_blocks_all_new_escape_input(self):
  self.e.screen.focused=lambda:False;self.act()
  self.assertIsNone(self.e.terrain_recovery);self.assertEqual(self.commands,[])
  self.e.screen.focused=lambda:True;self.e.stop_event.set();self.act()
  self.assertIsNone(self.e.terrain_recovery);self.assertEqual(self.commands,[])
 def test_short_recovery_retains_five_second_rise_and_four_second_cruise(self):
  self.act();r=self.e.terrain_recovery;r.phase='RISE';r.since=100;r.homed=True;r.pitch_start=0
  a=r.step(104.9,FlightReading(80,True),-.9);self.assertLess(a.drive.forward,0)
  r.step(105.1,FlightReading(80,True),-.9);self.assertEqual(r.phase,'LEVEL')
  r.phase='CRUISE';r.since=110;a=r.step(113.9,FlightReading(80,True),0,90,90)
  self.assertGreater(a.drive.forward,.5);self.assertIsNone(a.command)
  a=r.step(114.1,FlightReading(80,True),0,90,90);self.assertEqual(a.command,'END_AIR')


if __name__=='__main__':unittest.main()
