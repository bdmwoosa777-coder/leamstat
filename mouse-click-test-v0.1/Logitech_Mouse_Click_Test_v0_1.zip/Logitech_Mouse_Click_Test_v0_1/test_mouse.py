import ctypes,threading,unittest
from pathlib import Path
from mouse_core import INPUT,MOUSEINPUT,MSG,BUTTONS,ClickTest,frame_bits
try:
 from lupa import LuaRuntime
except ImportError:LuaRuntime=None

class API:
 def __init__(self):self.events=[];self.fail=False
 def prepare(self,method,button):
  def down():
   self.events.append(('down',method,button))
   if self.fail:raise OSError('failed after report')
  def up():self.events.append(('up',method,button))
  return down,up

class InputTests(unittest.TestCase):
 def test_native_input_struct_size_and_alignment_on_64bit(self):
  self.assertEqual(ctypes.sizeof(INPUT),40 if ctypes.sizeof(ctypes.c_void_p)==8 else 28)
  self.assertEqual(ctypes.sizeof(MOUSEINPUT),32 if ctypes.sizeof(ctypes.c_void_p)==8 else 24)
 def test_windows_message_struct_includes_private_trailer(self):
  self.assertEqual(ctypes.sizeof(MSG),48 if ctypes.sizeof(ctypes.c_void_p)==8 else 32)
 def test_left_and_right_are_distinct_windows_flags(self):
  self.assertEqual(BUTTONS['ЛКМ'][:2],(2,4));self.assertEqual(BUTTONS['ПКМ'][:2],(8,16))
 def test_one_bounded_click_releases_button(self):
  api=API();test=ClickTest(api)
  self.assertTrue(test.execute('SendInput','ПКМ',threading.Event(),delay=0,hold=0))
  self.assertEqual(api.events,[('down','SendInput','ПКМ'),('up','SendInput','ПКМ')])
 def test_cancel_before_countdown_sends_no_button(self):
  api=API();cancel=threading.Event();cancel.set()
  self.assertFalse(ClickTest(api).execute('SendInput','ПКМ',cancel,delay=0));self.assertEqual(api.events,[])
 def test_failure_after_partial_down_still_releases(self):
  api=API();api.fail=True
  with self.assertRaises(OSError):ClickTest(api).execute('SendInput','ПКМ',threading.Event(),delay=0)
  self.assertEqual([e[0] for e in api.events],['down','up'])
 def test_release_all_is_idempotent(self):
  api=API();test=ClickTest(api);test.execute('mouse_event','ЛКМ',threading.Event(),delay=0,hold=0)
  test.release_all();test.release_all();self.assertEqual(len(api.events),2)
 def test_test_channel_never_emits_gather_receiver_sof(self):
  for command in ('LEFT','RIGHT','STOP'):
   bits=frame_bits(command);self.assertEqual(len(bits),7);self.assertNotIn(3,bits);self.assertTrue(set(bits)<={0,1})

class Wire:
 def __init__(self,commands,corrupt=False):
  self.now=0;self.index=0;self.state={};self.events=[];self.buttons=[];start=100
  for command in commands:
   bits=frame_bits(command)
   if corrupt:bits[-1]^=1
   for bit in bits:
    self.events.extend([(start,{'capslock':False,'numlock':bool(bit),'scrolllock':False}),
                        (start+24,{'scrolllock':True}),(start+84,{'scrolllock':False})]);start+=120
   start+=180
  self.end=start+500
 def key(self,name):
  while self.index<len(self.events) and self.events[self.index][0]<=self.now:
   self.state.update(self.events[self.index][1]);self.index+=1
  return self.state.get(name,False)
 def sleep(self,ms):
  self.now+=ms
  if self.now>self.end:self.now+=1800010

@unittest.skipIf(LuaRuntime is None,'Optional lupa is not installed')
class ReceiverTests(unittest.TestCase):
 def run_lua(self,commands,corrupt=False):
  wire=Wire(commands,corrupt);lua=LuaRuntime();g=lua.globals()
  g.IsKeyLockOn=wire.key;g.GetRunningTime=lambda:wire.now;g.Sleep=wire.sleep
  g.OutputLogMessage=lambda *args:None
  g.PressMouseButton=lambda button:wire.buttons.append(('down',button,wire.now))
  g.ReleaseMouseButton=lambda button:wire.buttons.append(('up',button,wire.now))
  lua.execute((Path(__file__).parent/'GHUB_MOUSE_TEST.lua').read_text());g.OnEvent('MOUSE_BUTTON_PRESSED',9)
  return wire
 def test_correct_logitech_right_button_number_and_one_click(self):
  wire=self.run_lua(['RIGHT','STOP'])
  self.assertEqual([(a,b) for a,b,_ in wire.buttons if a=='down'],[('down',3)])
 def test_left_and_right_mapping_are_different(self):
  wire=self.run_lua(['LEFT','RIGHT','STOP'])
  self.assertEqual([b for a,b,_ in wire.buttons if a=='down'],[1,3])
 def test_bad_checksum_cannot_trigger_a_click(self):
  wire=self.run_lua(['RIGHT','LEFT','STOP'],corrupt=True)
  self.assertFalse(any(a=='down' for a,_,_ in wire.buttons))

if __name__=='__main__':unittest.main()
