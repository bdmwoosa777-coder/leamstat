@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto python
py -3 mouse_test.py
if errorlevel 1 pause
exit /b
:python
python mouse_test.py
if errorlevel 1 pause
