"""One bounded test click. Standard Windows APIs; no device/driver injection."""
import ctypes as C
import os,threading,time

DWORD=C.c_uint32;LONG=C.c_int32;WORD=C.c_uint16;PTR=C.c_size_t
class MOUSEINPUT(C.Structure):
    _fields_=[('dx',LONG),('dy',LONG),('mouseData',DWORD),('dwFlags',DWORD),('time',DWORD),('dwExtraInfo',PTR)]
class KEYBDINPUT(C.Structure):
    _fields_=[('wVk',WORD),('wScan',WORD),('dwFlags',DWORD),('time',DWORD),('dwExtraInfo',PTR)]
class HARDWAREINPUT(C.Structure):
    _fields_=[('uMsg',DWORD),('wParamL',WORD),('wParamH',WORD)]
class INPUTUNION(C.Union):
    _fields_=[('mi',MOUSEINPUT),('ki',KEYBDINPUT),('hi',HARDWAREINPUT)]
class INPUT(C.Structure):
    _fields_=[('type',DWORD),('value',INPUTUNION)]
class POINT(C.Structure):_fields_=[('x',LONG),('y',LONG)]
class MSG(C.Structure):
    _fields_=[('hwnd',C.c_void_p),('message',DWORD),('wParam',PTR),('lParam',C.c_ssize_t),
              ('time',DWORD),('pt',POINT),('lPrivate',DWORD)]

# down, up, mouseData, Windows message down/up, held-button word
BUTTONS={'ЛКМ':(0x0002,0x0004,0,0x0201,0x0202,1),
         'ПКМ':(0x0008,0x0010,0,0x0204,0x0205,2)}

class WindowsMouse:
    def __init__(self):
        if os.name!='nt':raise RuntimeError('Тестер ввода требует Windows')
        self.user=C.WinDLL('user32',use_last_error=True)
        self.user.SendInput.argtypes=[C.c_uint,C.POINTER(INPUT),C.c_int];self.user.SendInput.restype=C.c_uint
        self.user.mouse_event.argtypes=[DWORD,DWORD,DWORD,DWORD,PTR]
        self.user.GetForegroundWindow.restype=C.c_void_p
        self.user.GetCursorPos.argtypes=[C.POINTER(POINT)]
        self.user.ScreenToClient.argtypes=[C.c_void_p,C.POINTER(POINT)]
        self.user.PostMessageW.argtypes=[C.c_void_p,C.c_uint,PTR,C.c_ssize_t]
        self.user.PostMessageW.restype=C.c_int
    def prepare(self,method,button):
        down,up,data,wm_down,wm_up,held=BUTTONS[button]
        if method=='SendInput':
            def emit(flag):
                report=INPUT(type=0,value=INPUTUNION(mi=MOUSEINPUT(0,0,data,flag,0,0)))
                if self.user.SendInput(1,C.byref(report),C.sizeof(INPUT))!=1:
                    raise OSError(C.get_last_error(),'Windows не приняла SendInput; проверьте уровень прав тестера и игры')
            return lambda:emit(down),lambda:emit(up)
        if method=='mouse_event':
            return (lambda:self.user.mouse_event(down,0,0,data,0),
                    lambda:self.user.mouse_event(up,0,0,data,0))
        if method=='PostMessage':
            window=self.user.GetForegroundWindow();point=POINT()
            if not window or not self.user.GetCursorPos(C.byref(point)) or not self.user.ScreenToClient(window,C.byref(point)):
                raise OSError('Не удалось получить окно/координаты')
            position=(point.x&65535)|((point.y&65535)<<16)
            def post(message,word):
                if not self.user.PostMessageW(window,message,word,position):raise OSError(C.get_last_error(),'PostMessage не выполнен')
            # Keep the original target window for release even after Alt+Tab.
            return lambda:post(wm_down,held),lambda:post(wm_up,0)
        raise ValueError('Неизвестный метод: '+method)

class ClickTest:
    def __init__(self,api,log=lambda _:None):
        self.api=api;self.log=log;self.lock=threading.RLock();self.release=None
    def execute(self,method,button,cancel,delay=3,hold=.12):
        if cancel.wait(max(0,delay)):return False
        down,up=self.api.prepare(method,button)
        with self.lock:
            if cancel.is_set():return False
            self.release=up
            try:down()
            except Exception:self.release_all();raise
        self.log(method+': отправлено нажатие '+button)
        try:return not cancel.wait(hold)
        finally:self.release_all()
    def release_all(self):
        with self.lock:
            release=self.release;self.release=None
            if release:release()


def frame_bits(command):
    value={'LEFT':0,'RIGHT':1,'STOP':2}[command];hi,lo=value>>1,value&1
    return [1,0,1,0,hi,lo,(hi+lo+1)%2]

class MouseLuaBridge:
    """Dedicated 7-bit test channel. CapsLock stays OFF at every strobe:
    it never emits the SOF=3 used by GatherScanner's receiver.
    """
    def __init__(self,logger=lambda _:None):
        if os.name!='nt':raise RuntimeError('Lua-канал требует Windows')
        self.user=C.WinDLL('user32',use_last_error=True);self.log=logger;self.lock=threading.RLock()
        self.user.GetKeyState.argtypes=[C.c_int];self.user.GetKeyState.restype=C.c_short
        self.user.keybd_event.argtypes=[C.c_ubyte,C.c_ubyte,DWORD,PTR]
        self.saved={k:bool(self.user.GetKeyState(k)&1) for k in (20,144)}
    def toggle(self,key,desired):
        scan={20:0x3a,144:0x45,145:0x46}[key]
        for _ in range(3):
            if bool(self.user.GetKeyState(key)&1)==desired:return
            self.user.keybd_event(key,scan,0,0);time.sleep(.008)
            self.user.keybd_event(key,scan,2,0);time.sleep(.034)
        if bool(self.user.GetKeyState(key)&1)!=desired:raise OSError('Не удалось переключить lock-key')
    def send(self,command,cancel=None):
        bits=frame_bits(command)
        with self.lock:
            if cancel and cancel.is_set():return False
            for index,bit in enumerate(bits):
                if index==6 and cancel and cancel.is_set():bit^=1
                self.toggle(20,False);self.toggle(144,bool(bit));self.toggle(145,False)
                time.sleep(.018);self.toggle(145,True);time.sleep(.078)
                self.toggle(145,False);time.sleep(.040)
        self.log('Lua TX: '+command+'; это отправка, подтверждение из игры не получено')
        return not (cancel and cancel.is_set())
    def close(self):
        with self.lock:
            try:self.send('STOP')
            finally:
                self.toggle(145,False)
                for key,value in self.saved.items():self.toggle(key,value)
