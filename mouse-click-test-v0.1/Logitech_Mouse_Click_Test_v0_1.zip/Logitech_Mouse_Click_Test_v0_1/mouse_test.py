import ctypes as C
from ctypes import wintypes as W
from datetime import datetime
import logging,os,queue,threading,time
from pathlib import Path
import tkinter as tk
from tkinter import ttk
from mouse_core import WindowsMouse,ClickTest,MouseLuaBridge,MSG

ROOT=Path(__file__).resolve().parent

class Watcher:
    """Observe Windows button edges and handle F8/F9. No input from the hook."""
    def __init__(self,queue):self.queue=queue;self.thread=None;self.ident=None
    def start(self):self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
    def run(self):
        user=C.WinDLL('user32',use_last_error=True);kernel=C.WinDLL('kernel32',use_last_error=True)
        kernel.GetCurrentThreadId.restype=W.DWORD;self.ident=kernel.GetCurrentThreadId()
        kernel.GetModuleHandleW.argtypes=[W.LPCWSTR];kernel.GetModuleHandleW.restype=W.HMODULE
        result=C.c_ssize_t
        callback_type=C.WINFUNCTYPE(result,C.c_int,C.c_size_t,C.c_ssize_t)
        class Point(C.Structure):_fields_=[('x',C.c_int32),('y',C.c_int32)]
        class MouseData(C.Structure):
            _fields_=[('pt',Point),('mouseData',C.c_uint32),('flags',C.c_uint32),('time',C.c_uint32),('extra',C.c_size_t)]
        user.CallNextHookEx.argtypes=[W.HHOOK,C.c_int,C.c_size_t,C.c_ssize_t];user.CallNextHookEx.restype=result
        user.SetWindowsHookExW.argtypes=[C.c_int,callback_type,W.HINSTANCE,W.DWORD];user.SetWindowsHookExW.restype=W.HHOOK
        user.UnhookWindowsHookEx.argtypes=[W.HHOOK]
        messages={0x201:'ЛКМ вниз',0x202:'ЛКМ вверх',0x204:'ПКМ вниз',0x205:'ПКМ вверх'}
        def event(code,message,pointer):
            if code>=0 and message in messages:
                data=C.cast(pointer,C.POINTER(MouseData)).contents
                self.queue.put(('log',f'Windows: {messages[message]}, x={data.pt.x}, y={data.pt.y}, injected={bool(data.flags&1)}'))
            return user.CallNextHookEx(None,code,message,pointer)
        self.callback=callback_type(event)
        hook=user.SetWindowsHookExW(14,self.callback,kernel.GetModuleHandleW(None),0)
        if not hook:self.queue.put(('log','Наблюдение кликов недоступно: '+str(C.get_last_error())))
        registered=[]
        for ident,key in ((1,0x77),(2,0x78)):
            if user.RegisterHotKey(None,ident,0x4000,key):registered.append(ident)
            else:self.queue.put(('log',('F8' if ident==1 else 'F9')+' занята другой программой; используйте кнопки окна'))
        user.GetMessageW.argtypes=[C.POINTER(MSG),C.c_void_p,C.c_uint,C.c_uint]
        user.GetMessageW.restype=C.c_int
        msg=MSG()
        try:
            while user.GetMessageW(C.byref(msg),None,0,0)>0:
                if msg.message==0x312:self.queue.put(('start' if msg.wParam==1 else 'stop',None))
        finally:
            for ident in registered:user.UnregisterHotKey(None,ident)
            if hook:user.UnhookWindowsHookEx(hook)
    def close(self):
        if self.ident:
            C.windll.user32.PostThreadMessageW(self.ident,0x12,0,0)
            if self.thread:self.thread.join(1)

class App:
    def __init__(self):
        self.root=tk.Tk();self.root.title('Тест ЛКМ / ПКМ — G502 / G700s');self.root.geometry('780x620')
        self.queue=queue.Queue();self.cancel=threading.Event();self.worker=None;self.bridge=None;self.closing=False;self.cleaned=threading.Event()
        self.api=WindowsMouse();self.click=ClickTest(self.api,self.log)
        self.file=logging.getLogger('mouse-test');self.file.setLevel(logging.INFO)
        handler=logging.FileHandler(ROOT/'mouse_test.log',encoding='utf-8');handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'));self.file.addHandler(handler)
        panel=ttk.Frame(self.root,padding=12);panel.pack(fill='x')
        ttk.Label(panel,text='Остановите бота. Откройте карту игры и наведите курсор на точку.').pack(anchor='w')
        ttk.Label(panel,text='F8 — один тестовый клик после отсчёта. F9 — отменить. Курсор не перемещается.').pack(anchor='w',pady=5)
        self.method=tk.StringVar(value='SendInput');self.button=tk.StringVar(value='ПКМ')
        row=ttk.Frame(panel);row.pack(fill='x',pady=8)
        ttk.Label(row,text='Метод:').pack(side='left');ttk.Combobox(row,textvariable=self.method,values=['SendInput','mouse_event','PostMessage','G HUB Lua'],state='readonly',width=20).pack(side='left',padx=8)
        ttk.Combobox(row,textvariable=self.button,values=['ПКМ','ЛКМ'],state='readonly',width=8).pack(side='left')
        ttk.Button(row,text='F8: клик через 3 с',command=self.start).pack(side='left',padx=8)
        ttk.Button(row,text='F9: отменить',command=self.stop).pack(side='left')
        ttk.Label(panel,text='Для Windows-тестов память мыши можно оставить включённой.\nG HUB Lua требует отдельного тестового профиля и режима памяти OFF.').pack(anchor='w',pady=5)
        ttk.Button(panel,text='Скопировать Lua для отдельного тестового профиля',command=self.copy_lua).pack(anchor='w')
        ttk.Label(panel,text='Физический клик G-кнопкой тоже попадёт в журнал. injected=False не доказывает приём игрой.').pack(anchor='w',pady=8)
        result=ttk.Frame(panel);result.pack(fill='x')
        ttk.Button(result,text='В игре сработало',command=lambda:self.log('ОТМЕТКА ПОЛЬЗОВАТЕЛЯ: сработало в игре')).pack(side='left')
        ttk.Button(result,text='В игре не сработало',command=lambda:self.log('ОТМЕТКА ПОЛЬЗОВАТЕЛЯ: не сработало в игре')).pack(side='left',padx=8)
        ttk.Button(result,text='Скопировать журнал',command=self.copy_log).pack(side='left')
        self.status=ttk.Label(self.root,text='Готово. Начните с SendInput / ПКМ.');self.status.pack(anchor='w',padx=12)
        self.text=tk.Text(self.root,wrap='word',height=18);self.text.pack(fill='both',expand=True,padx=12,pady=8)
        self.watch=Watcher(self.queue);self.watch.start();self.root.after(50,self.pump)
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.log('Журнал: '+str(ROOT/'mouse_test.log'))
        self.log('Тестер не запускает произвольную G9 в памяти мыши. Проверяются программные клики и наблюдаются физические.')
    def log(self,text):self.queue.put(('log',text))
    def start(self):
        if self.worker and self.worker.is_alive():self.log('Предыдущий тест ещё завершается');return
        self.cancel=threading.Event();method=self.method.get();button=self.button.get()
        self.worker=threading.Thread(target=self.run_test,args=(method,button,self.cancel),daemon=True);self.worker.start()
    def run_test(self,method,button,cancel):
        try:
            self.log('ТЕСТ: '+method+' / '+button+'. Переключитесь в игру, наведите курсор.')
            for second in (3,2,1):
                self.queue.put(('status','Клик через '+str(second)+' с'))
                if cancel.wait(1):return
            if method=='G HUB Lua':
                if self.bridge is None:self.bridge=MouseLuaBridge(self.log)
                self.bridge.send('RIGHT' if button=='ПКМ' else 'LEFT',cancel)
            else:self.click.execute(method,button,cancel,delay=0)
            self.log('Тест завершён. Отметьте, было ли действие в игре.')
        except Exception as exc:self.log('ОШИБКА: '+str(exc))
        finally:self.queue.put(('status','Готово. F8 — следующий тест; F9 — отмена.'))
    def stop(self):
        self.cancel.set()
        try:self.click.release_all()
        except Exception as exc:self.log('Освобождение кнопки: '+str(exc))
        self.log('Тест отменён')
    def copy_lua(self):
        self.root.clipboard_clear();self.root.clipboard_append((ROOT/'GHUB_MOUSE_TEST.lua').read_text(encoding='utf-8'))
        self.log('Lua скопирован. Вставьте в отдельный профиль G HUB; физически нажмите G9, чтобы запустить приёмник.')
    def copy_log(self):
        self.root.clipboard_clear();self.root.clipboard_append(self.text.get('1.0','end'))
    def pump(self):
        if self.closing:return
        for _ in range(150):
            try:kind,value=self.queue.get_nowait()
            except queue.Empty:break
            if kind=='start':self.start()
            elif kind=='stop':self.stop()
            elif kind=='status':self.status.config(text=value)
            elif kind=='log':
                self.file.info(value);self.text.insert('end',datetime.now().strftime('%H:%M:%S')+' '+str(value)+'\n');self.text.see('end')
        self.root.after(50,self.pump)
    def close(self):
        self.stop();self.closing=True;self.watch.close()
        def finish():
            if self.worker:self.worker.join(2)
            if self.bridge:
                try:self.bridge.close()
                except Exception:pass
            self.cleaned.set()
        threading.Thread(target=finish,daemon=True).start()
        self.root.withdraw();self.root.after(50,self.finish_close)
    def finish_close(self):
        if self.cleaned.is_set():self.root.destroy()
        else:self.root.after(50,self.finish_close)
    def run(self):self.root.mainloop()

if __name__=='__main__':
    if os.name!='nt':raise SystemExit('Тестер требует Windows')
    try:C.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:pass
    App().run()
