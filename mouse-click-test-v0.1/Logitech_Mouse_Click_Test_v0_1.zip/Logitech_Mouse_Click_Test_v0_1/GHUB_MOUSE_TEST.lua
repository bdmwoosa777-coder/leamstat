-- Separate TEST profile only. G9 physically arms this receiver.
-- Dedicated binary protocol: no SOF=3 from the GatherScanner protocol.
local running=false
function OnEvent(event,arg)
    if event~="MOUSE_BUTTON_PRESSED" or arg~=9 or running then return end
    running=true
    local previous=IsKeyLockOn("scrolllock")
    local buffer={}
    local edge=GetRunningTime()
    local last_rx=edge
    OutputLogMessage("[MOUSE TEST] ARMED on G9; LMB=1, RMB=3\n")
    while GetRunningTime()-last_rx<1800000 do
        local now=GetRunningTime()
        if now-edge>850 then buffer={} end
        local scroll=IsKeyLockOn("scrolllock")
        if scroll and not previous then
            edge=now
            if IsKeyLockOn("capslock") then
                buffer={}
            else
                local bit=IsKeyLockOn("numlock") and 1 or 0
                table.insert(buffer,bit)
                if #buffer>7 then table.remove(buffer,1) end
                if #buffer==7 and buffer[1]==1 and buffer[2]==0 and buffer[3]==1 and buffer[4]==0 then
                    local hi,lo=buffer[5],buffer[6]
                    local parity=buffer[7]
                    buffer={}
                    if parity==(hi+lo+1)%2 then
                        local command=hi*2+lo
                        last_rx=GetRunningTime()
                        if command==0 or command==1 then
                            local button=command==0 and 1 or 3
                            OutputLogMessage("[MOUSE TEST] click button=%d\n",button)
                            PressMouseButton(button);Sleep(120);ReleaseMouseButton(button)
                        elseif command==2 then
                            ReleaseMouseButton(1);ReleaseMouseButton(3)
                        end
                    end
                end
            end
        end
        previous=scroll
        Sleep(12)
    end
    ReleaseMouseButton(1);ReleaseMouseButton(3)
    running=false
end
