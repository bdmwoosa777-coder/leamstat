"""Calibrated world XY -> map pixels; map arrows are CHARACTER headings."""
from dataclasses import dataclass
from pathlib import Path
import math,json,time
import cv2,numpy as np
from map_reference import TerrainMatcher,ArrowLocator,arrow_mask,transform
from spatial import Atlas,resource_names
from vision import DEFAULT_NAMES
from functools import lru_cache
from atlas_registration import AtlasRegistration
from minimap_resource_fix import locate as locate_resources
from minimap_position import MinimapPosition

ROOT=Path(__file__).resolve().parent

@lru_cache(maxsize=1)
def full_catalogue():
 data=json.loads((ROOT/'assets/atlas/gather_full.json').read_text(encoding='utf-8'))
 if data.get('version')!=1:raise ValueError('Неизвестный формат каталога ресурсов')
 resources={r['id']:r for r in data['resources']};maps={}
 for layer in data['maps']:
  table={}
  for group in layer['groups']:
   if len(group['env_object_ids'])!=1:raise ValueError('Неоднозначный тип спавна')
   template=group['env_object_ids'][0]
   if template not in resources:raise ValueError('Нет описания типа ресурса')
   points=table.setdefault(str(template),[])
   for xyz in group['points']:
    if len(xyz)!=3 or not all(math.isfinite(v) and abs(v)<1e6 for v in xyz):raise ValueError('Некорректная позиция спавна')
    points.append(tuple(xyz))
  maps[layer['map_id']]=table
 return maps

def fit_world(points):
 if len(points)<3:raise ValueError('Нужны три разных ориентира')
 world=np.float64([p['world'][:2] for p in points]);pixels=np.float64([p['pixel'] for p in points])
 if not np.isfinite(world).all() or not np.isfinite(pixels).all():raise ValueError('Некорректные точки')
 if abs(cv2.contourArea(world.astype(np.float32)))<1e6 or abs(cv2.contourArea(pixels.astype(np.float32)))<500:raise ValueError('Выберите три разнесённых ориентира, не на одной линии')
 # North-up similarity: positive isotropic scale and translation only.
 center=world.mean(axis=0);pc=pixels.mean(axis=0);v=world-center;u=pixels-pc
 scale=float(np.sum(v*u)/np.sum(v*v))
 if not 1e-5<scale<.1:raise ValueError('Масштаб/направление карты не совпали; север должен быть сверху')
 offset=pc-scale*center;error=np.linalg.norm(world*scale+offset-pixels,axis=1)
 if error.max()>min(8,scale*100*10):raise ValueError('Ориентиры не совпали с базой или карта слишком мелкая: ошибка '+str(round(float(error.max()),1))+' пикселей')
 return [[scale,0,float(offset[0])],[0,scale,float(offset[1])],[0,0,1]]

@dataclass(frozen=True)
class MapGoal:
 key:object
 name:str
 reference:tuple
 xyz:tuple|None=None
 live:bool=False
 air:bool=False

class MapCoordinates:
 def __init__(self,cfg):
  self.spec=cfg.get('map_mousekeys',{});self.ready=False;self.atlas=Atlas();self.allowed=set(cfg.get('target_names',DEFAULT_NAMES));self.full=full_catalogue();self.cooldown={};self.location_cooldown={}
  spec=self.spec
  if cfg.get('map_use_builtin',False) or not spec.get('reference'):
   self.builtin(cfg);return
  try:
   path=(ROOT/spec['reference']).resolve()
   if not path.is_relative_to(ROOT):return
   self.image=cv2.imread(str(path));self.matrix=np.array(spec['world_matrix'],np.float64);self.inverse=np.linalg.inv(self.matrix)
   self.zone=np.array(spec['zone'],np.float32);self.layer=spec['layer'];self.meta=self.atlas.maps[self.layer]
   if self.image is None or self.matrix.shape!=(3,3) or not np.isfinite(self.matrix).all() or len(self.zone)<3:return
   self.matcher=TerrainMatcher(self.image);self.roi=spec['roi'];self.frame_width=spec['frame_width']
   arrow=np.array(spec['arrow'],np.uint8)
   if arrow.ndim!=2 or min(arrow.shape)<10 or np.count_nonzero(arrow)<20:return
   self.arrow=ArrowLocator(arrow);self.arrow_size=spec['arrow_size'];self.ready=True
  except (KeyError,TypeError,ValueError,cv2.error,np.linalg.LinAlgError):return
 def builtin(self,cfg):
  self.layer='altgard';self.meta=self.atlas.maps[self.layer]
  self.image=cv2.imread(str(ROOT/'assets/atlas/altgard_reference.jpg'))
  if self.image is None:return
  k=self.meta['scale']*.5
  self.matrix=np.array([[k,0,self.meta['offsetX']*.5],[0,k,self.meta['offsetY']*.5],[0,0,1]],float);self.inverse=np.linalg.inv(self.matrix)
  self.native=AtlasRegistration(self.image);self.automatic=True;self.ready=True;self.zone=None
  self.farm_center=None;self.farm_radius=max(150,min(1000,float(cfg.get('map_farm_radius_m',450))))
  self.nearby_fix=None;self.nearby_at=0
  self.spec={'air_points':[],'builtin':True}
  self.calibration=[];self.learned_projection=None;self.texture_enabled=bool(cfg.get('map_minimap_texture_enabled',False))
  self.mini_position=MinimapPosition(self.image);self.mini_goals=[];self.mini_goals_at=-1e9;self.nearby_markers=False
 def valid_layer(self,state):return self.ready and (state.map_id in self.meta.get('openZones',[]) or getattr(self,'automatic',False) and state.map_id is None)
 def inside(self,point):
  if getattr(self,'automatic',False):return self.farm_center is not None and math.dist(point,self.farm_center)<=self.farm_radius*100*self.matrix[0,0]
  return cv2.pointPolygonTest(self.zone,tuple(map(float,point)),False)>=0
 def register_open_map(self,frame):return self.register(frame,centered=True)
 def register(self,frame,centered=False):
  if getattr(self,'automatic',False):
   fix=self.native.register(frame,centered=True) if centered else self.native.register(frame)
   if fix is None:return None
   if fix.get('position') is not None:self.mini_position.anchor(fix['position'])
   fix['world']=transform(fix['position'],self.inverse) if fix.get('position') is not None else None
   if self.farm_center is None and fix.get('position') is not None:self.farm_center=fix['position']
   return fix
  h,w=frame.shape[:2];x0,y0,x1,y1=[round(v*s) for v,s in zip(self.roi,(w,h,w,h))]
  crop=frame[y0:y1,x0:x1]
  if crop.size==0:return None
  reg=self.matcher.register(crop)
  if reg is None:return None
  # A game map pans/zooms; a rotated or heavily projective match is wrong.
  m=reg.matrix/mat_scale(reg.matrix)
  if abs(m[0,1])+abs(m[1,0])>max(abs(m[0,0]),abs(m[1,1]))*.12 or abs(m[2,0])+abs(m[2,1])>1e-4:return None
  m=np.array([[1,0,x0],[0,1,y0],[0,0,1]],float)@reg.matrix
  found=self.arrow.locate(crop,self.arrow_size*w/self.frame_width,threshold=.65)
  if found is None:return None
  _,px,py,rotation=found
  position=transform((px+x0,py+y0),np.linalg.inv(m))
  return dict(matrix=m,position=position,world=transform(position,self.inverse),viewport=(x0,y0,x1,y1),arrow_rotation=rotation,inliers=reg.inliers)
 def prepare(self,fix,state):
  if not getattr(self,'automatic',False):return fix
  if fix.get('position') is None and state.own is not None and getattr(state,'xyz',None) is not None and getattr(state,'position_at',None) is not None:
   age=(time.time()*1000-state.position_at)/1000
   xyz=state.xyz
   if -.1<=age<=.8 and all(math.isfinite(v) and abs(v)<1e6 for v in xyz):
    fix['world']=tuple(xyz[:2]);fix['position']=transform(xyz[:2],self.matrix);fix['position_source']='fresh_own_network'
  raw=fix.get('map_world',fix.get('world'))
  independent=None;independent_source=None
  xyz=getattr(state,'xyz',None);stamp=getattr(state,'position_at',None)
  if (getattr(state,'own',None) is not None and xyz is not None and stamp is not None
      and -.1<=time.time()-stamp/1000<=.8 and all(math.isfinite(v) and abs(v)<1e6 for v in xyz)):
   independent=tuple(xyz[:2]);independent_source='fresh_own_network'
  nearby=getattr(self,'nearby_fix',None)
  if independent is None and nearby is not None and 0<=time.monotonic()-self.nearby_at<=4:
   independent=nearby.xy;independent_source='minimap_resource_match'
  if independent is None:
   remembered=self.collection_reference(state)
   if remembered is not None:
    cached=self.projection_at(raw) if raw is not None else None
    if remembered[1]!='own_gather_near_resource' or cached is None or not cached[1].startswith('learned_own'):
     independent,independent_source,_=remembered
  if independent is not None and raw is not None and fix.get('position_source') in ('map_open_center','player_arrow'):
   self.learn_projection(raw,independent,independent_source)
   self.apply_bias(fix,tuple(a-b for a,b in zip(independent,raw)),independent_source)
  elif raw is not None:
   learned=self.projection_at(raw)
   if learned is not None:
    model,source=learned;a,bx,by=model
    corrected=(raw[0]*a+bx,raw[1]*a+by)
    self.apply_bias(fix,tuple(x-y for x,y in zip(corrected,raw)),source);fix['projection_model']=model
  if fix.get('position') is not None:
   anchor=transform(fix['world'],self.matrix) if fix.get('projection_bias') is not None else fix['position']
   source=fix.get('world_source',fix.get('position_source','player_arrow'))
  else:
   nearby=getattr(self,'nearby_fix',None)
   if nearby is not None and 0<=time.monotonic()-self.nearby_at<12:
    anchor=transform(nearby.xy,self.matrix);source='minimap_resource_match'
    fix['nearby_matches']=nearby.matches;fix['nearby_error']=nearby.error
   else:
    remembered=self.collection_reference(state)
    if remembered is None:anchor=None;source='unknown'
    else:
     xy,source,stamp=remembered;anchor=transform(xy,self.matrix)
     fix['reference_at']=stamp
  fix['search_position']=anchor;fix['search_source']=source
  if self.farm_center is None and anchor is not None:self.farm_center=anchor
  return fix
 def learn_projection(self,raw,xy,source):
  now=time.monotonic();approx=source not in ('fresh_own_network','stationary_own_network_reference')
  if not all(math.isfinite(v) for v in (*raw,*xy)):return
  # M centre and independent own position refer to the same capture. A
  # gathered node is explicitly only a nearby reference, not exact own XYZ.
  previous=getattr(self,'learned_projection',None)
  if previous is not None and now-previous[3]<600 and math.dist(raw,previous[2])<20000:
   a,bx,by=previous[0];predicted=(a*raw[0]+bx,a*raw[1]+by)
   if approx and math.dist(predicted,xy)>1500:return
  points=[p for p in getattr(self,'calibration',[]) if now-p[2]<600]
  points.append((tuple(raw),tuple(xy),now,approx));self.calibration=points[-12:]
  model=(1.,xy[0]-raw[0],xy[1]-raw[1]);label=('learned_gather_near_resource' if source=='own_gather_near_resource' else 'learned_resource_geometry') if approx else 'learned_own_network'
  exact=[p for p in self.calibration if not p[3]]
  if len(exact)>=3:
   x=np.float64([p[0] for p in exact]);y=np.float64([p[1] for p in exact]);u=x-x.mean(0);v=y-y.mean(0)
   denominator=float(np.sum(u*u))
   if denominator>4000**2:
    a=float(np.sum(u*v)/denominator);b=y.mean(0)-a*x.mean(0)
    error=np.linalg.norm(a*x+b-y,axis=1)
    if .85<a<1.15 and max(error)<400:model=(a,float(b[0]),float(b[1]));label='learned_own_network_scale'
  # Never replace an exact local calibration with a coarser gathered-node fix.
  if approx and previous is not None and previous[1].startswith('learned_own') and now-previous[3]<600 and math.dist(raw,previous[2])<20000:return
  self.learned_projection=(model,label,tuple(raw),now)
 def projection_at(self,raw):
  item=getattr(self,'learned_projection',None)
  if item is None or not 0<=time.monotonic()-item[3]<600 or math.dist(raw,item[2])>20000:return None
  return item[:2]
 def apply_bias(self,fix,bias,source):
  if fix.get('world') is None:return fix
  raw=fix.get('map_world',fix['world']);fix['map_world']=raw;fix.pop('projection_model',None)
  fix['projection_bias']=tuple(bias);fix['world']=tuple(a+b for a,b in zip(raw,bias));fix['world_source']=source
  fix['search_position']=transform(fix['world'],self.matrix);fix['search_source']=source
  return fix
 def observe_minimap(self,frame,radar,state,now):
  if not getattr(self,'automatic',False) or not self.valid_layer(state):return None
  if self.mini_position.seed is None and getattr(state,'xyz',None) is not None and getattr(state,'position_at',None) is not None:
   if 0<=time.time()-state.position_at/1000<.8:self.mini_position.anchor(transform(state.xyz[:2],self.matrix))
  pose=self.mini_position.observe(frame,radar,now)
  if pose is None:self.mini_goals=[];return None
  goals=[];active=getattr(self,'active_names',self.allowed)
  for m in radar.markers:
   if m.kind not in ('aether','gem') or m.distance>110*max(.5,(radar.bounds[2]-radar.bounds[0])/313):continue
   name='Эфир' if m.kind=='aether' else m.name
   if m.kind=='aether' and 'Эфир' not in active or m.kind=='gem' and not any('эфир' not in n.lower() for n in active):continue
   reference=tuple(v+(p-c)/pose.scale for v,p,c in zip(pose.reference,(m.x,m.y),radar.center))
   if not self.inside(reference):continue
   key=('mini',m.kind,*(round(v*2)/2 for v in reference))
   goals.append(MapGoal(key,name,reference))
  self.mini_goals=sorted(goals,key=lambda g:math.dist(g.reference,pose.reference));self.mini_goals_at=now
  return pose
 def followup_goal(self,goal,now):
  pose=self.mini_position.latest if getattr(self,'automatic',False) else None
  if pose is None or not 0<=now-pose.at<=1.5 or not 0<=now-self.mini_goals_at<=1.5:return None
  family='aether' if 'эфир' in goal.name.lower() else 'gem'
  items=[g for g in self.mini_goals if g.key[1]==family and self.cooldown.get(g.key,0)<=now]
  if not items:return None
  g=items[0]
  # A different atlas point and a still-distant CURRENT marker justify one
  # corrected map route; a claimed catalogue arrival cannot veto it.
  if math.dist(g.reference,pose.reference)*pose.scale<=12:return None
  if math.dist(g.reference,goal.reference)*pose.scale<=6:return None
  return g
 def set_nearby(self,state,radar,now):
  if not getattr(self,'automatic',False):return
  if radar is not None and radar.motion_valid and math.hypot(*radar.displacement)>2:self.departed()
  self.nearby_fix=locate_resources(state,radar,self.allowed);self.nearby_at=now
  self.nearby_markers=bool(radar is not None and any(m.kind in ('aether','gem') for m in radar.markers))
 def departed(self):
  self.collection_anchor=None;self.nearby_fix=None
  self.blocked_collection=getattr(self,'last_collection_token',None)
 def observe_context(self,state,flow):
  context=(flow,state.own,state.map_id)
  previous=getattr(self,'reference_context',context)
  if context!=previous:
   self.departed()
   if getattr(self,'automatic',False) and (previous[0]!=context[0] or previous[2]!=context[2] or previous[1] is not None and context[1] is not None and previous[1]!=context[1]):
    self.mini_position.reset();self.mini_goals=[];self.calibration=[];self.learned_projection=None
  self.reference_context=context
  cached=getattr(self,'collection_anchor',None)
  if (cached and getattr(state,'position_source','') in ('zone-spawn','own-teleport')
      and (getattr(state,'position_at',None) or 0)>cached[0][4]):self.departed()
 def remember_collection(self,state,node,flow,now):
  # Called only after the engine confirms its OWN gathering lease. A spawn,
  # selection, or another player's interaction must never set this reference.
  token=(flow,state.own,state.map_id,node.actor,node.gather_time)
  if token==getattr(self,'blocked_collection',None):return
  if (state.own is None or node.xyz is None or node.gather_time is None
      or not all(math.isfinite(v) and abs(v)<1e6 for v in node.xyz)):return
  self.last_collection_token=token
  self.collection_anchor=(token,tuple(node.xyz[:2]),now)
 def collection_reference(self,state):
  cached=getattr(self,'collection_anchor',None)
  if cached is None:return None
  token,xy,observed=cached
  if (token[1:3]!=(state.own,state.map_id) or not 0<=time.monotonic()-observed<30):return None
  if (getattr(state,'position_source','') in ('zone-spawn','own-teleport')
      and (getattr(state,'position_at',None) or 0)>token[4]):return None
  # A delayed real fix can refine ranking while this gathering reference has
  # not been invalidated by movement. Retain the real capture timestamp.
  xyz=getattr(state,'xyz',None);stamp=getattr(state,'position_at',None)
  if (xyz is not None and stamp is not None and token[4]<=stamp
      and all(math.isfinite(v) and abs(v)<1e6 for v in xyz)
      and math.dist(xy,xyz[:2])>1500):return None
  if (xyz is not None and stamp is not None and token[4]<=stamp
      and 0<=time.time()*1000-stamp<=30000
      and all(math.isfinite(v) and abs(v)<1e6 for v in xyz)
      and math.dist(xy,xyz[:2])<=1500):
   return tuple(xyz[:2]),'stationary_own_network_reference',stamp
  # This is the resource's location, an approximate nearby area, never own XYZ.
  return xy,'own_gather_near_resource',token[4]
 def pixel(self,goal,fix):
  reference=goal.reference
  if fix.get('projection_bias') is not None and not (isinstance(goal.key,tuple) and goal.key[0]=='mini'):
   model=fix.get('projection_model')
   if model is not None:
    a,bx,by=model;xy=goal.xyz[:2] if goal.xyz is not None else transform(reference,self.inverse)
    reference=transform(((xy[0]-bx)/a,(xy[1]-by)/a),self.matrix)
   else:reference=tuple(v-b*self.matrix[0,0] for v,b in zip(reference,fix['projection_bias']))
  p=transform(reference,fix['matrix']);x0,y0,x1,y1=fix['viewport']
  return tuple(round(v) for v in p) if x0+12<p[0]<x1-12 and y0+12<p[1]<y1-12 else None
 def refine_goal(self,goal,state):
  if goal.xyz is None:return goal
  names=resource_names();nodes=[]
  for n in state.nodes.values():
   if (names.get(n.template)!=goal.name or not n.visible or n.used==3 or n.xyz is None
       or n.removed_reason==4 or n.actor in state.players or n.actor in state.npcs or n.actor in state.deaths):continue
   if not all(math.isfinite(v) and abs(v)<1e6 for v in n.xyz):continue
   if math.dist(n.xyz[:2],goal.xyz[:2])<=1500:nodes.append(n)
  if not nodes:return goal
  n=min(nodes,key=lambda n:math.dist(n.xyz,goal.xyz))
  return MapGoal(('node',state.map_id,n.actor,n.generation),goal.name,transform(n.xyz[:2],self.matrix),tuple(n.xyz),True,goal.air)
 def catalogue_spec(self):
  return (getattr(self,'layer',''),tuple(float(v) for v in self.matrix.ravel()),tuple(sorted(getattr(self,'allowed',DEFAULT_NAMES))))
 def catalogue_sources(self):
  names=resource_names();table=getattr(self,'full',{}).get(self.meta['table']) or self.atlas.points.get(self.meta['table'],{})
  return tuple((int(t),names[int(t)],tuple(xyz)) for t,points in table.items()
               if str(t).isdigit() and names.get(int(t)) in getattr(self,'allowed',DEFAULT_NAMES) for xyz in points)
 def spawn_goals(self):
  prepared=getattr(self,'prepared_catalogue',None)
  if prepared is not None and getattr(self,'prepared_catalogue_spec',None)==self.catalogue_spec():return prepared
  return (MapGoal(('spawn',str(t),*xyz[:2]),name,transform(xyz[:2],self.matrix),xyz) for t,name,xyz in self.catalogue_sources())
 def goals(self,state,fix,now,allow_air=True,prefer_ether=True,camp=False,escape=False):
  if not self.valid_layer(state):return []
  self.prepare(fix,state)
  if fix.get('search_position') is None and fix.get('position') is None:return []
  mini=list(getattr(self,'mini_goals',[])) if 0<=now-getattr(self,'mini_goals_at',-1e9)<=8 else []
  goals=[]
  if camp and not getattr(self,'automatic',False):
   p=self.spec.get('exit')
   if p:goals=[MapGoal(('exit',self.layer),'выход из лагеря',tuple(p))]
  elif escape:
   goals=[MapGoal(('air',i),'точка облёта',tuple(p),air=True) for i,p in enumerate(self.spec.get('air_points',[]))] if allow_air else []
  else:
   names={k:v for k,v in resource_names().items() if v in getattr(self,'allowed',DEFAULT_NAMES) and v in getattr(self,'active_names',getattr(self,'allowed',DEFAULT_NAMES))}
   for n in state.nodes.values():
    name=names.get(n.template)
    if (not name or not n.visible or n.used==3 or n.removed_reason==4 or n.xyz is None
        or n.actor in state.players or n.actor in state.npcs or n.actor in state.deaths):continue
    p=transform(n.xyz[:2],self.matrix)
    goal=MapGoal(('node',state.map_id,n.actor,n.generation),name,p,tuple(n.xyz),True)
    if self.inside(p) and self.cooldown.get(goal.key,0)<=now and (allow_air or 'эфир' not in name.lower()):goals.append(goal)
   for goal in self.spawn_goals():
    template=int(goal.key[1]);xyz=goal.xyz
    if goal.name not in names.values() or not allow_air and 'эфир' in goal.name.lower():continue
    if any(n.template==template and n.xyz is not None and (n.visible or n.used==3 or n.removed_reason==4)
           and math.dist(n.xyz,xyz)<200 for n in state.nodes.values()):continue
    if self.inside(goal.reference):goals.append(goal)
  if not camp and not escape:goals=mini+goals
  goals=[g for g in goals if self.cooldown.get(g.key,0)<=now and not any(t>now and math.dist(g.reference,p)<max(4,abs(self.matrix[0,0])*300) for p,t in getattr(self,'location_cooldown',{}).items()) and self.pixel(g,fix) is not None]
  def score(g):
   preferred=0 if not prefer_ether or 'эфир' in g.name.lower() else 1
   visual=isinstance(g.key,tuple) and g.key[0]=='mini'
   pose=self.mini_position.latest if visual else None
   anchor=pose.reference if pose is not None else fix.get('search_position') or fix['position']
   return (preferred,math.dist(g.reference,anchor),0 if g.live or visual else 1)
  return sorted(goals,key=score)
 def defer(self,goal,now,seconds=60):
  if goal:
   self.cooldown[goal.key]=now+seconds
   if not hasattr(self,'location_cooldown'):self.location_cooldown={}
   self.location_cooldown[tuple(goal.reference)]=now+seconds
  self.location_cooldown={p:t for p,t in getattr(self,'location_cooldown',{}).items() if t>now}
  self.cooldown={k:t for k,t in self.cooldown.items() if t>now}

def mat_scale(matrix):
 value=float(matrix[2,2]);return value if abs(value)>1e-9 else 1.
