# -*- coding: utf-8 -*-
from __future__ import annotations
import json,logging,os,queue,threading,time
os.environ.setdefault('OMP_THREAD_LIMIT','1')
import cv2
cv2.setNumThreads(1)
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from gamepad_input import GamepadInput
from network_feed import NetworkFeed
from gather_engine import GatherEngine
from screen_capture import ScreenCapture
from minimap_setup import MinimapSetup
from map_setup import MapSetup
from win_hotkeys import SystemHotkeys
from vision import DEFAULT_NAMES
from camera_working_view import WORKING_VIEW_PRESETS,DEFAULT_WORKING_VIEW_MS,working_view_ms
from return_exit import DEFAULT_EXIT

if os.name=='nt':
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:pass

ROOT=Path(__file__).resolve().parent
CONF=ROOT/'settings_gather.json'
DEFAULT={
 'ground_route_navigation':True,'analyzer_enabled':True,'analyzer_model':'qwen3-vl:4b','analyzer_url':'http://127.0.0.1:11434',
 'map_safe_return_enabled':True,'map_return_destination':'Временный приют','map_return_index':13,
 'scene_navigation_enabled':True,'scene_gpu_device':None,'area_search_rescue':True,
 'no_yield_return_enabled':True,'return_exit_route':DEFAULT_EXIT,
 'terrain_rescue_enabled':True,'terrain_rescue_seconds':90,
 'network_enabled':True,'resource_click_interaction':True,'visual_route_hold':True,'air_search_wide':True,
 'defense_during_approach':False,'defense_arrival_distance':10,
 'only_aether':False,'allow_click':True,'camera_scan':True,'dry_run':False,
 'aether_priority_low_percent':20,'aether_priority_resume_percent':35,
 'probe_retreat_pitch_offset':.20,'probe_retreat_rise_seconds':1.5,
 'assist_manual_target':True,'approach_timeout':60,'approach_stall_seconds':6,
 'gather_timeout':55,'audio_device':'AG271QG4','target_names':list(DEFAULT_NAMES),
 'defense_air_search':True,'collection_event_driven':True,'native_cursor_chord':True,'preserve_owned_resource':True,'repeat_owned_clicks':True,'calibrate_during_collection':False,'collection_cursor_hold':True,'debug_screenshots':True,'click_backend':'gamepad','ground_walk':True,
 'minimap_search':True,'minimap_roi':[],'minimap_templates':[],
 'minimap_threshold':.80,'gem_icon_threshold':.74,'target_missing_seconds':.6,
 'cursor_alt':True,'a_gap_seconds':.32,'flight_low_percent':8.0,
 'flight_resume_percent':18.0,'navigation_stall_seconds':6,'camera_yaw_sign':1,
 'scan_seconds':3.5,
 'patrol_leg_seconds':24,'patrol_walk_speed':.78,'resource_walk_speed':.78,
 'steering_deadband_degrees':16,'camera_pulse_seconds':.12,'camera_settle_seconds':.55,
 'heading_min_confidence':.30,'air_search_map_radius':12,'air_pitch_strength':.45,
 'world_map_enabled':False,'world_map_check_seconds':12,'world_map':{},
 'protect_player':True,'player_name':'Darkleam','threat_roi':[.665,.028,.752,.054],
 'patrol_escape_enabled':True,'flight_retry_delay':3,'retreat_seconds':5,'air_sweep_pause_seconds':.9,'gather_idle_seconds':6,
 'hp_fast_seconds':.05,'hp_ocr_seconds':.20,'hp_roi':[.405,.858,.477,.888],
 'flight_probe_enabled':True,'flight_probe_min_percent':18,'probe_pitch_offset':.12,
 'probe_rise_seconds':1.0,'probe_peek_seconds':.8,'auto_view_recovery':True,
 'defense_max_tabs':8,'defense_max_cycles':6,
 'ground_search_map_radius':8,'navigation_unknown_stall_seconds':12,'minimap_goal_timeout_seconds':45,
 'camera_auto_calibrate':True,'camera_working_view_ms':DEFAULT_WORKING_VIEW_MS,
}

def read_config():
 try:r=json.loads(CONF.read_text(encoding='utf-8'))
 except Exception:r={}
 r.pop('network_exe',None)
 return {**DEFAULT,**r}

class UI:
    def __init__(self):
        self.root=tk.Tk();self.root.title('ACore2 Gather Scanner v0.11.0 — ИИ-навигация (тест)')
        self.root.geometry('1100x900')
        self.cfg=read_config();self.q=queue.Queue();self.worker=None;self.engine=None
        self.file_log=logging.getLogger('gather_scanner')
        self.file_log.setLevel(logging.INFO)
        try:
            handler=logging.FileHandler(ROOT/'gather.log',encoding='utf-8')
            handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
            self.file_log.addHandler(handler)
        except OSError:pass
        self.gamepad=None
        self.vars={}
        self._start_token=0
        self._start_pending=False
        self._closing=False
        row=ttk.Frame(self.root,padding=10);row.pack(fill='x')
        for key,label in [('analyzer_enabled','Локальный анализатор Ollama: выбор прохода по снимку (нужен SETUP_ANALYZER.bat)'),('scene_navigation_enabled','ИИ-навигация: обходить видимые препятствия и искать выход (DirectML)'),('map_safe_return_enabled','Возврат через карту: Временный приют (нужен Lua v0.10.2)'),('network_enabled','Встроенная сеть: подтверждать сбор и удары (Npcap)'),('dry_run','Только наблюдение (НЕ нажимать)'),('allow_click','Выбирать ресурс, проверять его ID и повторным кликом запускать сбор'),('minimap_search','Искать иконки на миникарте и двигаться к ним'),('assist_manual_target','Продолжать сбор уже выбранного ресурса'),('only_aether','Приоритет эфира; самоцветы при восстановлении энергии'),('camera_scan','Коротко осматривать вверх-вниз: эфир и наземные ресурсы'),('flight_probe_enabled','Один пробный подъём крыльями над препятствием'),('patrol_escape_enabled','Выход из застревания при патруле: короткий отлёт вбок'),('ground_walk','Патрулировать и двигаться к ресурсам стиком Xbox'),('protect_player','Защита: подтверждённый удар по персонажу → Tab → два удара ]'),('world_map_enabled','Сверять положение по M и возвращаться в настроенную зону')]:
            v=tk.BooleanVar(value=bool(self.cfg.get(key)))
            self.vars[key]=v
            ttk.Checkbutton(row,text=label,variable=v).pack(anchor='w')
        netrow=ttk.Frame(self.root,padding=5);netrow.pack(fill='x')
        ttk.Button(netrow,text='Состояние сети',command=self.network_status).pack(side='left',padx=5)
        ttk.Button(netrow,text='Анализатор',command=self.analyzer_status).pack(side='left',padx=5)
        ttk.Button(netrow,text='Состояние ИИ',command=self.scene_status).pack(side='left',padx=5)
        ttk.Label(netrow,text='Захват встроен. CubeRadar выбирать и запускать не требуется.').pack(side='left')
        camera=ttk.Frame(self.root,padding=5);camera.pack(fill='x')
        self.vars['camera_auto_calibrate']=tk.BooleanVar(value=self.cfg.get('camera_auto_calibrate',True))
        ttk.Checkbutton(camera,text='Автокалибровка камеры: 2 с вверх, затем вниз на',variable=self.vars['camera_auto_calibrate']).pack(side='left')
        self.working_ms=tk.StringVar(value=str(working_view_ms(self.cfg)))
        ttk.Combobox(camera,textvariable=self.working_ms,values=[str(v) for v in WORKING_VIEW_PRESETS],width=5,state='readonly').pack(side='left',padx=5)
        ttk.Label(camera,text='мс (650–1200, сила 0,45; при следующей калибровке)').pack(side='left')
        connection=ttk.Frame(self.root,padding=5);connection.pack(fill='x')
        ttk.Label(connection,text='Выбор ресурса:').pack(side='left')
        self.backend=tk.StringVar(value=self.cfg.get('click_backend','gamepad'))
        ttk.Combobox(connection,textvariable=self.backend,values=['gamepad'],width=12,state='readonly').pack(side='left',padx=5)
        ttk.Button(connection,text='Подключить Xbox',command=self.connect_gamepad).pack(side='left',padx=5)
        ttk.Button(connection,text='Настроить миникарту / добавить иконку',command=self.setup_minimap).pack(side='left',padx=5)
        ttk.Button(connection,text='Зона поиска по M',command=self.setup_world_map).pack(side='left',padx=5)
        ttk.Label(self.root,text='Xbox: A, движение и камера. G HUB Lua: Alt, F, V, прыжок. G9 запускает Lua. Миникарта распознаётся автоматически.',foreground='#245').pack(anchor='w',padx=10)
        ttk.Label(self.root,text='Для карты нужен Lua v0.10.2 или из этой папки. Если он уже установлен, менять не нужно. Приёмник: G9.',foreground='#a43').pack(anchor='w',padx=10)
        buttons=ttk.Frame(self.root,padding=10);buttons.pack(fill='x')
        ttk.Button(buttons,text='Сохранить настройки',command=self.save).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F8 Старт/пауза',command=self.toggle).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F9 СТОП',command=self.stop).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F10 Заглушить сигнал',command=self.silence).pack(side='left',padx=3)
        ttk.Button(buttons,text='ТЕСТ по двум кадрам',command=self.offline).pack(side='left',padx=3)
        journal=ttk.Frame(self.root,padding=5);journal.pack(fill='x')
        ttk.Button(journal,text='Скопировать журнал',command=self.copy_log).pack(side='left',padx=4)
        ttk.Button(journal,text='Сохранить журнал...',command=self.save_log).pack(side='left',padx=4)
        ttk.Button(journal,text='Папка журнала',command=self.open_log_folder).pack(side='left',padx=4)
        ttk.Button(journal,text='Диагностический кадр через 3 с',command=self.diagnostic).pack(side='left',padx=4)
        self.status=ttk.Label(self.root,text='Не запущено');self.status.pack(anchor='w',padx=10)
        self.box=tk.Text(self.root,height=23,wrap='word');self.box.pack(fill='both',expand=True,padx=10,pady=10)
        self.root.after(180,self.pump)
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.hotkeys=SystemHotkeys(self.q)
        self.root.after(150,self.connect_gamepad)

    def network_status(self):
        network=self.engine.network if self.engine else None
        self.log(network.describe() if network else 'Сеть запускается вместе с ботом по Ctrl+F8. Нужен установленный Npcap.')

    def analyzer_status(self):
        host=self.engine.analyzer if self.engine else None
        if host is None:self.log('ANALYZER: включается вместе с ботом; установка — SETUP_ANALYZER.bat');return
        self.log('ANALYZER: '+('готов, '+self.cfg.get('analyzer_model','qwen3-vl:4b') if host.ready else 'не подключён: '+str(host.error or 'ожидаю первый кадр')))

    def scene_status(self):
        host=self.engine.scene_host if self.engine else None
        if host is None:
            self.log('SCENE: '+('загрузится после Ctrl+F8; настройка ИИ включена' if self.vars['scene_navigation_enabled'].get() else 'ИИ выключен; используется прежняя навигация'))
            return
        if host.error:self.log('SCENE ERROR: '+host.error);return
        with host.lock:reading=host.latest
        if reading is None:self.log('SCENE: загрузка моделей или ожидание первого кадра; подробности в журнале');return
        self.log(f'SCENE: {reading.backend}, последний результат {max(0,time.monotonic()-reading.captured):.2f} с назад, обработка {reading.elapsed_ms:.0f} мс. При повороте устаревший кадр не используется.')

    def connect_gamepad(self):
        if self.gamepad:return True
        try:
            self.gamepad=GamepadInput(logger=self.log)
            self.log('Xbox готов. Оставьте программу открытой; приёмник F710 можно отключить.')
            return True
        except Exception as exc:
            self.log('Xbox не подключён: '+str(exc))
            return False

    def setup_minimap(self):
        self.stop('НАСТРОЙКА МИНИКАРТЫ')
        self.log('Снимок через 4 секунды: переключитесь в игру, откройте миникарту с видимой иконкой ресурса.')
        self.root.iconify()
        self.root.after(4000,self._capture_minimap)

    def _capture_minimap(self):
        if self._closing:return
        if self.worker and self.worker.is_alive():
            self.root.after(250,self._capture_minimap);return
        try:
            screen=ScreenCapture()
            if not screen.pick():raise RuntimeError('Окно AION2 не найдено')
            frame,_=screen.frame()
            self.root.deiconify()
            MinimapSetup(self.root,frame,self.cfg,self._minimap_saved)
        except Exception as exc:
            self.root.deiconify();self.log('Не удалось настроить миникарту: '+str(exc))

    def _minimap_saved(self):
        self.vars['minimap_search'].set(True)
        self.save()
        self.log('Миникарта сохранена. Иконок-эталонов: '+str(len(self.cfg['minimap_templates'])))

    def setup_world_map(self):
        self.stop('НАСТРОЙКА ЗОНЫ')
        self.log('Снимок через 5 секунд: переключитесь в игру и физически откройте большую карту M.')
        self.root.iconify();self.root.after(5000,self._capture_world_map)

    def _capture_world_map(self):
        if self._closing:return
        if self.worker and self.worker.is_alive():
            self.root.after(250,self._capture_world_map);return
        try:
            screen=ScreenCapture()
            if not screen.pick():raise RuntimeError('Окно AION2 не найдено')
            frame,_=screen.frame();self.root.deiconify()
            MapSetup(self.root,frame,self.cfg,self._world_map_saved)
        except Exception as exc:
            self.root.deiconify();self.log('Не удалось настроить зону: '+str(exc))

    def _world_map_saved(self):
        self.vars['world_map_enabled'].set(True);self.save()
        self.log('Зона сохранена. Закройте M в игре перед запуском. Для проверок M нужен Lua v0.5 из этой сборки.')
    def log(self,t):
        self.file_log.info(str(t));self.q.put(str(t))

    def copy_log(self):
        value=(ROOT/'gather.log').read_text(encoding='utf-8') if (ROOT/'gather.log').exists() else self.box.get('1.0','end')
        self.root.clipboard_clear();self.root.clipboard_append(value)
        self.log('Журнал скопирован в буфер обмена')

    def open_log_folder(self):
        try:os.startfile(str(ROOT))
        except Exception as exc:messagebox.showerror('Папка журнала',str(exc),parent=self.root)

    def save_log(self):
        destination=filedialog.asksaveasfilename(parent=self.root,title='Сохранить журнал',
            defaultextension='.txt',initialfile='gather_log.txt',filetypes=[('Текст','*.txt'),('Все','*.*')])
        if destination:
            try:
                value=(ROOT/'gather.log').read_text(encoding='utf-8') if (ROOT/'gather.log').exists() else self.box.get('1.0','end')
                Path(destination).write_text(value,encoding='utf-8');self.log('Журнал сохранён: '+destination)
            except Exception as exc:messagebox.showerror('Журнал',str(exc),parent=self.root)

    def diagnostic(self):
        self.stop('ДИАГНОСТИЧЕСКИЙ КАДР')
        self.log('Через 3 секунды снимок игры; затем снова Ctrl+F8 для работы')
        self.root.iconify();self.root.after(3000,self._diagnostic_capture)

    def _diagnostic_capture(self):
        try:
            from diagnostics import analyze
            screen=ScreenCapture()
            if not screen.pick():raise RuntimeError('Окно игры не найдено')
            frame,_=screen.frame();path=ROOT/'debug_gather'/('diagnostic_'+time.strftime('%Y%m%d_%H%M%S'))
            data=analyze(frame,self.cfg,path)
            self.log('Диагностика: '+str(path)+'.png / .json')
            self.log('Энергия/дуга: '+str(data['flight'])+'; направление: '+str(data['radar']['heading'])+'; иконок: '+str(len(data['radar']['markers'])))
        except Exception as exc:self.log('Ошибка диагностики: '+str(exc))
        finally:self.root.deiconify()
    def pump(self):
        for _ in range(40):
            try:s=self.q.get_nowait()
            except queue.Empty:break
            if isinstance(s,tuple) and s[0]=='hotkey':
                {'toggle':self.toggle,'stop':self.stop,'silence':self.silence}[s[1]]()
                continue
            s=str(s)
            self.box.insert('end',s+'\n');self.box.see('end')
            self.status.config(text=s[:110])
        self.root.after(180,self.pump)
    def save(self):
        for k,v in self.vars.items():self.cfg[k]=bool(v.get())
        self.cfg['click_backend']=self.backend.get()
        self.cfg['camera_working_view_ms']=working_view_ms({'camera_working_view_ms':self.working_ms.get()})
        CONF.write_text(json.dumps(self.cfg,ensure_ascii=False,indent=2),encoding='utf-8')
        if self.engine is not None:self.engine.cfg['camera_working_view_ms']=self.cfg['camera_working_view_ms']
        self.log('Настройки сохранены; наклон '+str(self.cfg['camera_working_view_ms'])+' мс применяется при следующей калибровке')
    def toggle(self):
        active=(self._start_pending or
                (self.worker is not None and self.worker.is_alive() and
                 self.engine is not None and not self.engine.stop_event.is_set()))
        if active:
            self.stop('ПАУЗА Ctrl+F8')
        else:
            self.start()

    def start(self):
        if self._closing:return
        if self._start_pending:return
        if self.worker and self.worker.is_alive() and self.engine and not self.engine.stop_event.is_set():
            self.log('Скан уже запущен')
            return
        self._start_token+=1
        token=self._start_token
        self._start_pending=True
        self.log('Ctrl+F8: запрос запуска, после завершения прежнего цикла')
        self.root.after(10,lambda:self._launch_if_ready(token))

    def _launch_if_ready(self,token):
        if self._closing or not self._start_pending or token!=self._start_token:return
        if self.worker and self.worker.is_alive():
            self.root.after(150,lambda:self._launch_if_ready(token))
            return
        self.save()
        if not self.cfg['dry_run'] and not (self.cfg['allow_click'] or self.cfg.get('assist_manual_target') or self.cfg.get('ground_walk')):
            self._start_pending=False
            messagebox.showwarning('Режим','Для ввода включите «Автоподход» или используйте режим наблюдения.')
            return
        if self.engine:self.engine.silence() # stop prior alarm before explicit manual restart
        if not self.cfg['dry_run'] and self.cfg.get('click_backend')=='gamepad' and not self.connect_gamepad():
            self._start_pending=False;return
        network=None
        if self.cfg.get('network_enabled') and not self.cfg['dry_run']:
            network=NetworkFeed(logger=self.log)
        self.engine=GatherEngine(dict(self.cfg),self.log,gamepad=None if self.cfg['dry_run'] else self.gamepad,network=network)
        self.log('Переключитесь в AION2 и нажмите физический G9 для Lua. Через 3 с проверю реальный Alt; движение начнётся только после успешной проверки.')
        if self.cfg.get('camera_auto_calibrate') and self.cfg.get('camera_scan') and not self.cfg.get('dry_run'):
            self.log('Камера при запуске: автоматически около 2 с вверх, затем '+str(self.cfg['camera_working_view_ms'])+' мс вниз. Ручная подготовка не нужна.')
        self.root.after(3000,lambda:self._go(token))

    def _go(self,token):
        if self._closing or not self._start_pending or token!=self._start_token:return
        self._start_pending=False
        if not self.engine or self.engine.stop_event.is_set():return
        self.worker=threading.Thread(target=self.engine.run,daemon=True)
        self.worker.start()

    def stop(self,reason='СТОП Ctrl+F9'):
        self._start_token+=1
        self._start_pending=False
        if self.engine:self.engine.stop()
        self.log(reason+': скан/CAPTCHA/смерть остановлены')

    def silence(self):
        if self.engine:self.engine.silence()
        self.log('Ctrl+F10: прекращён текущий звук CAPTCHA/смерти; состояние скана не изменено')

    def offline(self):
        if self._start_pending or (self.worker and self.worker.is_alive()):return
        cfg={**self.cfg,'dry_run':True,'allow_click':False,'camera_scan':False}
        self.engine=GatherEngine(cfg,self.log)
        samples=[ROOT/'testdata/orihalkon_example.jpg',ROOT/'testdata/air_gather_example.jpg']
        self.worker=threading.Thread(target=lambda:self.engine.run(offline=samples),daemon=True)
        self.worker.start()
    def close(self):
        self._closing=True
        self.stop('ЗАКРЫТИЕ')
        self.silence()
        self.hotkeys.stop()
        if self.gamepad:self.gamepad.close()
        self.root.after(500,self.root.destroy)
    def run(self):self.root.mainloop()

if __name__=='__main__':UI().run()
