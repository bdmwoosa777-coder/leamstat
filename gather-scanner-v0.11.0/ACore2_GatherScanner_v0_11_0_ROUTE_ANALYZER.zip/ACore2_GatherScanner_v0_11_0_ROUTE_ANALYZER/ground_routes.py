"""Connected ground routes in the current image, not three area averages.

Image geometry is not a collision map or metric depth. Discontinuities affect
individual graph transitions; a rock outline cannot label the whole view a cliff.
"""
from dataclasses import dataclass
import heapq,math
import cv2,numpy as np
from navigation import Drive

@dataclass(frozen=True)
class GroundRoute:
 id:int
 points:tuple
 score:float
 confidence:float
 clearance:float
 @property
 def endpoint(self):return self.points[-1]

@dataclass(frozen=True)
class GroundMap:
 routes:tuple=()
 reachable:int=0
 drop_support:float=0
 seed:tuple|None=None
 anchor_measured:bool=False

def avatar_foot(labels,id2label):
 """Visible central person component; None means no measured avatar anchor."""
 ids=[int(k) for k,name in id2label.items() if 'person' in {n.strip().casefold() for n in name.split(';')}]
 if not ids:return None
 mask=np.isin(labels,ids).astype(np.uint8);h,w=mask.shape
 count,_,stats,centers=cv2.connectedComponentsWithStats(mask)
 choices=[]
 for i in range(1,count):
  x,y,rw,rh,area=stats[i];cx,cy=centers[i];bottom=(y+rh)/h
  if abs(cx/w-.5)<.10 and .48<bottom<.83 and .04<rh/h<.35 and area>w*h*.0004:
   choices.append((bottom-abs(cx/w-.5)*2,((x+rw/2)/w,bottom)))
 return max(choices,key=lambda item:item[0])[1] if choices else None

def build_ground_map(groups,depth,foot=None,confidence=None):
 if groups.ndim!=2 or depth.ndim!=2 or not np.isfinite(depth).all():raise ValueError('Invalid route inputs')
 # 60x36 cells span the visible near ground, beneath distant ceilings/arches.
 H,W=36,60;x0,x1,y0,y1=.12,.88,.35,.82
 h,w=groups.shape
 def fraction(mask):return cv2.resize(mask[round(h*y0):round(h*y1),round(w*x0):round(w*x1)].astype(np.float32),(W,H),interpolation=cv2.INTER_AREA)
 free=fraction((groups==1)|(groups==3));solid=fraction(groups==2);sky=fraction(groups==4)
 water=fraction(groups==3)
 dh,dw=depth.shape;crop=depth[round(dh*y0):round(dh*y1),round(dw*x0):round(dw*x1)]
 lo,hi=np.percentile(depth,[5,95]);z=cv2.resize(np.clip((crop-lo)/max(1e-5,hi-lo),0,1).astype(np.float32),(W,H),interpolation=cv2.INTER_AREA)
 walk=(free>=.32)&(solid<.62)&(sky<.35)
 # The avatar occludes its own feet. Choose actual nearby ground as the seed;
 # never paint a bridge through the central rock/person-shaped region.
 measured=foot is not None
 foot=(.5,.68) if foot is None else foot
 fx=(foot[0]-x0)/(x1-x0)*W;fy=(foot[1]-y0)/(y1-y0)*H
 if not (0<=fx<W and 0<=fy<H):return GroundMap()
 anchors=[(abs(x-fx)+abs(y-fy)*1.4,y,x) for y in range(max(0,round(fy)-1),min(H,round(fy)+5)) for x in range(max(0,round(fx)-7),min(W,round(fx)+8)) if walk[y,x]]
 if not anchors:return GroundMap()
 _,sy,sx=min(anchors);seed=(sy,sx)
 clearance=cv2.distanceTransform(walk.astype(np.uint8),cv2.DIST_L2,3)
 # Supported near-ground -> distant sky/water boundaries, rather than every
 # gradient of inverse depth in textured rock. Level shoreline remains usable.
 support=np.zeros_like(walk)
 support[1:]=(free[1:]>.45)&((sky[:-1]+water[:-1])>.45)&(z[1:]-z[:-1]>.32)
 drop=float(np.mean(support[max(0,sy-12):sy+1,max(0,sx-10):min(W,sx+11)]))
 semantic=fraction(confidence) if confidence is not None else np.ones_like(free)
 distance={seed:0.};parent={};queue=[(0.,sy,sx)]
 while queue:
  cost,y,x=heapq.heappop(queue)
  if cost>distance[(y,x)]:continue
  for dy,dx in ((-1,0),(0,-1),(0,1),(1,0),(-1,-1),(-1,1),(1,-1),(1,1)):
   yy,xx=y+dy,x+dx
   if not (0<=yy<H and 0<=xx<W and walk[yy,xx]):continue
   if dx and dy and not (walk[y,xx] and walk[yy,x]):continue
   # A high jump across *adjacent ground cells* can be a real discontinuity.
   # It blocks that crossing, not every point left/right of the same wall.
   if abs(float(z[yy,xx]-z[y,x]))>.38:continue
   step=math.hypot(dx,dy)*(1+1.8*(1-float(free[yy,xx]))+.5/max(.5,float(clearance[yy,xx])))
   nxt=cost+step
   if nxt<distance.get((yy,xx),1e30):distance[(yy,xx)]=nxt;parent[(yy,xx)]=(y,x);heapq.heappush(queue,(nxt,yy,xx))
 candidates=[]
 # One frontier per column band gives distinct connected alternatives to rank.
 for band in range(5):
  cells=[(y,x) for y,x in distance if y<=sy-6 and band*W/5<=x<(band+1)*W/5]
  if not cells:continue
  endpoint=min(cells,key=lambda p:(p[0],distance[p]-.4*float(clearance[p])))
  chain=[endpoint]
  while chain[-1]!=seed:chain.append(parent[chain[-1]])
  chain.reverse();conf=float(np.mean([free[y,x]*semantic[y,x] for y,x in chain]));width=float(np.min([clearance[y,x] for y,x in chain]))
  score=(sy-endpoint[0])/H*3-distance[endpoint]/len(chain)*.18+min(4,width)*.08
  points=tuple((x0+(x+.5)/W*(x1-x0),y0+(y+.5)/H*(y1-y0)) for y,x in chain)
  candidates.append(GroundRoute(band,points,score,conf,width))
 return GroundMap(tuple(candidates),len(distance),drop,(x0+(sx+.5)/W*(x1-x0),y0+(sy+.5)/H*(y1-y0)),measured)

class GroundFollower:
 def __init__(self):self.route_id=None;self.until=0;self.next_yaw=0;self.last_seq=None;self.stalled_since=None;self.avoid={};self.missing_since=None
 def choose(self,ground,plan,now,exit_mode=False,hint=None):
  options=[r for r in ground.routes if now>=self.avoid.get(r.id,0)]
  if not options:return None
  desired=max(.15,min(.85,.5+math.atan2(plan.strafe,max(.1,plan.forward))/math.pi*.7))
  def score(r):
   value=r.score-abs(r.endpoint[0]-(.5 if exit_mode else desired))*.7
   if r.id==self.route_id and now<self.until:value+=.35
   if hint is not None and r.id==hint:value+=2
   return value
  route=max(options,key=score)
  if route.id!=self.route_id:self.route_id=route.id;self.until=now+4;self.stalled_since=None
  return route
 def drive(self,route,now,yaw_sign=1):
  start=route.points[0]
  point=next((p for p in route.points if start[1]-p[1]>.075),route.endpoint)
  lateral=max(-.42,min(.42,(point[0]-.5)*1.65))
  # Local route owns this complete report; Navigator's simultaneous yaw is
  # not combined with it. Turns are rare and followed by a settling interval.
  end_x=route.endpoint[0]
  if (end_x<.25 or end_x>.75) and now>=self.next_yaw:
   self.next_yaw=now+.9
   return Drive(.35,lateral,(.28 if end_x>.5 else -.28)*yaw_sign,0,reason='поворачиваю вдоль связного прохода',lifetime=.65,yaw_lifetime=.07)
  return Drive(.58,lateral,0,0,reason='иду по связному проходу в текущем кадре',lifetime=.65)
 def observe_progress(self,radar,now,active):
  if not active or not radar.motion_valid:self.stalled_since=None;return False
  if math.hypot(*radar.displacement)>.35:self.stalled_since=None;return False
  if self.stalled_since is None:self.stalled_since=now
  if now-self.stalled_since>=5 and self.route_id is not None:
   self.avoid[self.route_id]=now+8;self.route_id=None;self.stalled_since=None;return True
  return False

def draw_routes(frame,ground):
 out=frame.copy();h,w=out.shape[:2]
 for route in ground.routes:
  pts=np.array([(round(x*w),round(y*h)) for x,y in route.points],np.int32)
  cv2.polylines(out,[pts],False,(50,230,80),max(2,w//500))
  x,y=pts[-1];cv2.circle(out,(int(x),int(y)),14,(20,40,230),-1)
  cv2.putText(out,str(route.id),(int(x)-6,int(y)+6),cv2.FONT_HERSHEY_SIMPLEX,.6,(255,255,255),2)
 return out
