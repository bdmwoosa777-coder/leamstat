"""Run on the user's Windows PC; install local Ollama and the vision model."""
from pathlib import Path
import json,os,shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
MODEL='qwen3-vl:4b'

def find_ollama():
 return shutil.which('ollama') or next((str(p) for p in (Path(os.environ.get('LOCALAPPDATA',''))/'Programs/Ollama/ollama.exe',Path(os.environ.get('ProgramFiles','C:/Program Files'))/'Ollama/ollama.exe') if p.is_file()),None)

def main():
 from route_analyzer import LocalOllama
 exe=find_ollama()
 if exe is None:
  winget=shutil.which('winget')
  if os.name!='nt' or not winget:
   print('Установите Ollama: https://ollama.com/download/windows , затем повторите SETUP_ANALYZER.bat');return 1
  print('Устанавливаю Ollama из официального пакета winget. Окно установки может потребовать действие Windows.',flush=True)
  subprocess.run([winget,'install','--id','Ollama.Ollama','--exact','--source','winget','--accept-source-agreements','--accept-package-agreements'],check=True)
  exe=find_ollama()
  if exe is None:raise RuntimeError('Ollama не найден после установки. Откройте приложение Ollama и повторите запуск.')
 env=os.environ.copy();env['OLLAMA_HOST']='127.0.0.1:11434'
 client=LocalOllama(model=MODEL)
 try:version=client.call('/api/version',timeout=2)
 except Exception:
  log=open(ROOT/'analyzer_server.log','ab')
  subprocess.Popen([exe,'serve'],env=env,stdout=log,stderr=log,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));log.close()
  deadline=time.monotonic()+20;version=None
  while time.monotonic()<deadline:
   try:version=client.call('/api/version',timeout=2);break
   except Exception:time.sleep(.4)
  if version is None:raise RuntimeError('Локальный Ollama не запустился; откройте его приложение и повторите установку анализатора.')
 import re
 numbers=tuple(int(v) for v in re.findall(r'\d+',version.get('version',''))[:3])
 if numbers<(0,12,7):raise RuntimeError('Нужен Ollama 0.12.7 или новее. Обновите Ollama и перезапустите его.')
 print('Загружаю '+MODEL+' (около 3,3 ГБ; хранится в Ollama и сохраняется при замене папки бота).',flush=True)
 subprocess.run([exe,'pull',MODEL],env=env,check=True)
 client.probe()
 from ground_routes import GroundMap
 import numpy as np
 print('Проверяю настоящий ответ модели на тестовом кадре. Игра не захватывается, кнопки не нажимаются.',flush=True)
 began=time.monotonic()
 # Allow a longer first load; normal bot requests have a shorter deadline.
 answer=client.analyze(np.full((360,640,3),60,np.uint8),GroundMap(),'test only; blank image, choose -1 and no resources',timeout=60)
 state=client.call('/api/ps',timeout=3)
 info={'model':MODEL,'ollama':version,'warmup_seconds':round(time.monotonic()-began,2),'test_answer':answer,'running':state}
 (ROOT/'analyzer_model_info.json').write_text(json.dumps(info,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 if not any(m.get('size_vram',0)>0 for m in state.get('models',[])):
  print('Модель ответила, но Ollama не подтвердил загрузку в VRAM. Проверьте драйвер NVIDIA/состояние Ollama; CPU может быть слишком медленным.')
 print('Готово. В боте включите «Локальный анализатор Ollama». Подробности проверки: analyzer_model_info.json');return 0

if __name__=='__main__':
 try:raise SystemExit(main())
 except Exception as exc:print('Установка анализатора не завершена:',exc);raise SystemExit(1)
