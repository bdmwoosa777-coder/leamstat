"""Long-run camp starvation, nonrenewable deadline, and delivered diagonal exit."""
import unittest
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import gather_engine as ge,hybrid_engine as he
from camp_departure import CampDeparture
from navigation import Drive
from post_tp_exit import BackExit
from test_navigation import radar
from test_hybrid import scene
from test_patrol import GROUND
from test_assist_recovery import FRAME
import test_camp_departure as campfx
import test_tp_exit37 as exitfx

class CampLimit(unittest.TestCase):
 def setUp(self):
  self.f=campfx.DepartureControl('test_existing_map_ether_does_not_prevent_initial_departure');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.f.start();self.e=self.f.e
 def test_replans_never_extend_the_original_sixty_second_limit(self):
  c=self.e.camp_route;c.replan(135);self.assertEqual(c.until,160)
  for now in (150,160,200,1000):c.replan(now);self.assertLessEqual(c.until,160)
  self.assertFalse(c.expired(159.9));self.assertTrue(c.expired(160))
 def test_update_expires_controller_after_one_leg_replan(self):
  with patch('hybrid_engine.purple_anchor',return_value=(90,100)):
   self.e._camp_update(self.f.frame,radar(),135);self.assertTrue(self.e.hybrid_camp_pending)
   self.e._camp_update(self.f.frame,radar(),160)
  self.assertFalse(self.e.hybrid_camp_pending);self.assertIsNone(self.e.camp_route);self.assertTrue(self.e.camp_failure_latched)
 def test_half_hour_of_same_anchor_cannot_rearm_failed_controller(self):
  self.e._expire_camp_departure(160)
  for now in range(170,2100,35):
   with patch('hybrid_engine.purple_anchor',return_value=None):self.e._camp_update(self.f.frame,radar(),now)
   with patch('hybrid_engine.purple_anchor',return_value=(90,100)):self.e._camp_update(self.f.frame,radar(),now+4)
   self.assertFalse(self.e.hybrid_camp_pending);self.assertIsNone(self.e.camp_route)
 def test_expiry_does_not_fake_a_collection_result_or_stop_bot(self):
  before=(self.e.no_yield.idle,self.e.no_yield.result_stamp)
  self.assertTrue(self.e._expire_camp_departure(160))
  self.assertEqual(before,(self.e.no_yield.idle,self.e.no_yield.result_stamp));self.assertFalse(self.e.stop_event.is_set())
 def test_expiry_preserves_active_resource_ownership(self):
  self.e.target_confirmed=True;self.e.resource_hold=True;self.e.target='Алмаз'
  self.assertFalse(self.e._expire_camp_departure(160));self.assertTrue(self.e.resource_hold)
  self.e.target_confirmed=False;self.e.resource_hold=False
  self.assertTrue(self.e._expire_camp_departure(161))
 def test_automatic_tick_expires_camp_even_without_minimap_callback(self):
  with patch.object(self.e,'_ensure_observers'):
   self.assertFalse(self.e._automatic_recovery_tick(self.f.frame,160))
  self.assertIsNone(self.e.camp_route);self.assertFalse(self.e.hybrid_camp_pending)
 def test_scene_planning_releases_camp_and_returns_to_resource_navigation(self):
  self.e.scene_host.current=lambda *a:scene(t=160,free=.95)
  with patch('hybrid_engine.time.monotonic',return_value=160):
   drive=self.e._scene_plan(self.f.frame,radar(),GROUND,Drive(.78),160)
  self.assertGreater(drive.forward,.5);self.assertFalse(self.e.hybrid_camp_pending)
 def test_landmark_far_outside_camp_releases_failure_latch(self):
  self.e._expire_camp_departure(160)
  with patch('hybrid_engine.purple_anchor',return_value=(300,300)):self.e._camp_update(self.f.frame,radar(),300)
  self.assertFalse(self.e.camp_failure_latched)
 def test_own_resource_proof_releases_failure_latch(self):
  self.e._expire_camp_departure(160);self.e.target_confirmed=True
  with patch.object(ge.GatherEngine,'_adopt_network_collection'),patch.object(self.e,'_net_gather_proof',return_value=True),patch.object(self.e,'_path_collection_reached'):
   self.e._adopt_network_collection()
  self.assertFalse(self.e.camp_failure_latched)
 def test_unconfirmed_target_cannot_release_failure_latch(self):
  self.e._expire_camp_departure(160);self.e.target_confirmed=True
  with patch.object(ge.GatherEngine,'_adopt_network_collection'),patch.object(self.e,'_net_gather_proof',return_value=False),patch.object(self.e,'_path_collection_reached'):
   self.e._adopt_network_collection()
  self.assertTrue(self.e.camp_failure_latched)

class FreshSceneProbe(unittest.TestCase):
 def setUp(self):
  self.f=campfx.DepartureControl('test_existing_map_ether_does_not_prevent_initial_departure');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.f.start();self.e=self.f.e
  self.clock=101.3;self.focus=True;self.grab_seconds=.02;self.grabs=0;self.picture=FRAME.copy();self.on_grab=lambda:None
  self.e.screen.focused=lambda:self.focus
  def grab():
   self.grabs+=1;self.clock+=self.grab_seconds;self.on_grab();return self.picture.copy(),(0,0)
  self.e.screen.frame=grab;self.e.gamepad.reset();self.e.camp_route.bearing=90
  self.r=replace(scene(t=100,free=.95),source=FRAME.copy(),revision=self.e.scene_camera_epoch)
  p=patch('hybrid_engine.time.monotonic',side_effect=lambda:self.clock);p.start();self.addCleanup(p.stop)
 def probe(self,**kw):
  return self.e._probe_stationary_scene(kw.get('candidate',self.r),FRAME,self.clock,90,0,99,kw.get('stationary',True))
 def test_recorded_one_point_three_second_lag_is_checked_against_new_pixels(self):
  self.assertIs(self.probe(),self.r);self.assertEqual(self.r.captured,100);self.assertEqual(self.grabs,1)
 def test_changed_world_pixels_do_not_validate_old_ground(self):
  self.picture=np.roll(FRAME,20,axis=1);self.assertIsNone(self.probe())
 def test_live_translation_prevents_capture_and_revalidation(self):
  self.e.gamepad.translation=(.8,0);self.e.gamepad.translation_deadline=103
  self.assertIsNone(self.probe());self.assertEqual(self.grabs,0)
 def test_live_yaw_prevents_revalidation(self):
  self.e.gamepad.yaw_deadline=103;self.assertIsNone(self.probe());self.assertEqual(self.grabs,0)
 def test_camera_revision_changed_during_capture_revokes_result(self):
  self.on_grab=lambda:setattr(self.e,'scene_camera_epoch',self.e.scene_camera_epoch+1)
  self.assertIsNone(self.probe())
 def test_focus_loss_during_capture_revokes_result(self):
  self.on_grab=lambda:setattr(self,'focus',False);self.assertIsNone(self.probe())
 def test_resource_selection_during_capture_has_priority(self):
  self.on_grab=lambda:setattr(self.e,'target_confirmed',True);self.assertIsNone(self.probe())
 def test_slow_capture_does_not_get_a_forged_fresh_timestamp(self):
  self.grab_seconds=.4;self.assertIsNone(self.probe());self.assertEqual(self.r.captured,100)
 def test_resize_during_capture_revokes_result(self):
  self.picture=FRAME[:180];self.assertIsNone(self.probe())
 def test_visible_active_bar_cannot_be_overridden_by_recheck(self):
  with patch('hybrid_engine.gathering_panel_pair',return_value=True):self.assertIsNone(self.probe())
 def test_very_old_model_result_does_not_even_trigger_probe(self):
  self.clock=104;self.assertIsNone(self.probe());self.assertEqual(self.grabs,0)
 def test_new_probe_is_rate_limited(self):
  self.probe();self.assertIsNone(self.probe());self.assertEqual(self.grabs,1)
 def test_invalid_camera_pose_cannot_be_attached_to_same_pixels(self):
  self.assertIsNone(self.probe(candidate=replace(self.r,heading=110)));self.assertEqual(self.grabs,0)
 def test_capture_failure_retains_finite_controller_instead_of_stopping(self):
  self.e.screen.frame=lambda:(_ for _ in ()).throw(RuntimeError('capture unavailable'))
  self.assertIsNone(self.probe());self.assertFalse(self.e.stop_event.is_set())
 def test_real_camp_planner_releases_wait_with_point_six_second_main_loop_delay(self):
  self.e.scene_host.current=lambda *a:None;self.e.scene_host.latest=self.r
  drive=self.e._scene_plan(FRAME,radar(heading=90),GROUND,Drive(.78),100.7)
  self.assertGreater(drive.forward,.4);self.assertEqual(drive.yaw,0);self.assertEqual(self.r.captured,100)
 def test_revalidated_cliff_still_cannot_authorize_walking(self):
  self.r=replace(self.r,ground=replace(self.r.ground,drop_support=.15))
  self.e.scene_host.current=lambda *a:None;self.e.scene_host.latest=self.r
  drive=self.e._scene_plan(FRAME,radar(heading=90),GROUND,Drive(.78),100.7)
  self.assertEqual((drive.forward,drive.strafe),(0,0))

class DeliveredRightExit(unittest.TestCase):
 def test_right_time_is_delivered_time_and_does_not_count_capture_gaps(self):
  b=BackExit(14,0);b.sent(0,.7,True);b.advance(3)
  self.assertAlmostEqual(b.right_delivered,.7);self.assertAlmostEqual(b.delivered,.7)
  b.sent(3,3.5,True);b.advance(5)
  self.assertAlmostEqual(b.right_delivered,1.2);self.assertAlmostEqual(b.right_remaining,0)
 def test_repeated_lease_renewal_does_not_credit_right_twice(self):
  b=BackExit(14,0);b.sent(0,.7,True);b.sent(.3,1,True);b.advance(.8)
  self.assertAlmostEqual(b.right_delivered,.8)
 def test_neutral_stops_both_time_counters(self):
  b=BackExit(14,0);b.sent(0,.7,True);b.stop_motion(.2);b.advance(2)
  self.assertAlmostEqual(b.right_delivered,.2);self.assertAlmostEqual(b.delivered,.2)
 def test_pure_backward_lease_does_not_add_right_time(self):
  b=BackExit(14,0);b.sent(0,.7);b.advance(.7);self.assertEqual(b.right_delivered,0)

class BackwardRightEngine(unittest.TestCase):
 def setUp(self):
  self.f=exitfx.BackwardExitEngine('test_initial_backward_right_stick_with_zero_camera_stick');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
 def test_first_one_point_two_seconds_are_diagonal_then_only_backwards(self):
  self.f.start_motion();self.assertEqual(self.f.f.pad.axes,(1,-1,0,0))
  for t in (103.9,104.3,104.7):self.f.tick(t)
  self.assertEqual(self.f.f.pad.axes,(0,-1,0,0));self.assertAlmostEqual(self.e.post_tp_exit.right_delivered,1.2)
 def test_requested_fourteen_seconds_still_finish_with_exact_right_phase(self):
  self.e.cfg['post_tp_back_exit_seconds']=14;self.f.arm();b=self.e.post_tp_exit
  for i in range(181):self.f.tick(100+i*.1)
  self.assertIsNone(self.e.post_tp_exit);self.assertAlmostEqual(b.delivered,14);self.assertAlmostEqual(b.right_delivered,1.2)
  self.assertTrue(all(v==(0,0) for v in self.f.angles));self.assertEqual(self.f.f.pad.presses,0)
 def test_failed_actual_right_report_is_not_counted(self):
  self.f.arm();self.f.tick(100)
  with patch.object(self.e.gamepad,'drive',return_value=False):self.f.tick(103.5)
  self.assertEqual(self.e.post_tp_exit.right_delivered,0);self.assertEqual(self.e.post_tp_exit.delivered,0)
 def test_focus_loss_releases_both_translation_axes(self):
  self.f.start_motion();self.f.focus=False;self.f.tick(103.7)
  self.assertEqual(self.f.f.pad.axes,(0,0,0,0));self.assertLess(self.e.post_tp_exit.right_delivered,1.2)

if __name__=='__main__':unittest.main()
