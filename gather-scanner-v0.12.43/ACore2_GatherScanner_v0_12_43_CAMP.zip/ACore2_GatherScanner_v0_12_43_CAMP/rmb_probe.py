"""Standalone input experiment. Never imported by the gather bot."""
import ctypes,os
from ctypes import wintypes

BUTTONS={'A':0x1000,'B':0x2000,'X':0x4000,'Y':0x8000,'LB':0x0100,'RB':0x0200,'LS':0x0040,'RS':0x0080,'Back':0x0020,'Start':0x0010}
MODES=('Windows: ПКМ вместо кнопки Xbox','Steam Input: кнопка Xbox')

class MouseInput(ctypes.Structure):
 _fields_=[('dx',ctypes.c_int32),('dy',ctypes.c_int32),('mouseData',ctypes.c_uint32),('dwFlags',ctypes.c_uint32),('time',ctypes.c_uint32),('dwExtraInfo',ctypes.c_size_t)]
class KeyboardInput(ctypes.Structure):
 _fields_=[('wVk',ctypes.c_uint16),('wScan',ctypes.c_uint16),('dwFlags',ctypes.c_uint32),('time',ctypes.c_uint32),('dwExtraInfo',ctypes.c_size_t)]
class HardwareInput(ctypes.Structure):
 _fields_=[('uMsg',ctypes.c_uint32),('wParamL',ctypes.c_uint16),('wParamH',ctypes.c_uint16)]
class InputUnion(ctypes.Union):
 _fields_=[('mi',MouseInput),('ki',KeyboardInput),('hi',HardwareInput)]
class Input(ctypes.Structure):
 _anonymous_=('value',)
 _fields_=[('type',ctypes.c_uint32),('value',InputUnion)]

class WindowsBackend:
 def __init__(self):
  if os.name!='nt':raise RuntimeError('Тест ввода работает только в Windows')
  self.api=ctypes.WinDLL('user32',use_last_error=True);self.pad=None
  self.api.SendInput.argtypes=[wintypes.UINT,ctypes.POINTER(Input),ctypes.c_int];self.api.SendInput.restype=wintypes.UINT
  self.api.GetForegroundWindow.restype=wintypes.HWND
  self.api.GetWindowTextLengthW.argtypes=[wintypes.HWND];self.api.GetWindowTextLengthW.restype=ctypes.c_int
  self.api.GetWindowTextW.argtypes=[wintypes.HWND,wintypes.LPWSTR,ctypes.c_int];self.api.GetWindowTextW.restype=ctypes.c_int
 def foreground(self):
  h=self.api.GetForegroundWindow();buf=ctypes.create_unicode_buffer(self.api.GetWindowTextLengthW(h)+1)
  self.api.GetWindowTextW(h,buf,len(buf));return buf.value
 def mouse(self,down):
  event=Input(type=0);event.mi.dwFlags=0x0008 if down else 0x0010
  sent=self.api.SendInput(1,ctypes.byref(event),ctypes.sizeof(Input))
  if sent!=1:raise RuntimeError('Windows принял 0 из 1 событий ПКМ. Проверь одинаковые права игры и теста; ошибка '+str(ctypes.get_last_error()))
 def connect(self):
  if self.pad is None:
   try:import vgamepad
   except ImportError as exc:raise RuntimeError('vgamepad не найден. Запусти тест тем же Python, что и бот; новых драйверов этот тест не ставит') from exc
   self.pad=vgamepad.VX360Gamepad()
 def button(self,name,down):
  self.connect()
  import vgamepad
  value=vgamepad.XUSB_BUTTON(BUTTONS[name])
  (self.pad.press_button if down else self.pad.release_button)(button=value);self.pad.update()
 def reset_pad(self):
  if self.pad is not None:self.pad.reset();self.pad.update()

class Probe:
 def __init__(self,backend):self.backend=backend;self.active=None
 def target_ready(self):
  title=self.backend.foreground().casefold()
  return 'aion2' in title or 'aion 2' in title
 def press(self,mode,button):
  if self.active is not None:return False
  if mode not in MODES or button not in BUTTONS:raise ValueError('Неизвестный режим/кнопка')
  if not self.target_ready():raise RuntimeError('Переключись в окно AION2; затем нажми F8')
  # Store before dispatch so a partially delivered command is still released.
  self.active=(mode,button)
  if mode==MODES[0]:self.backend.mouse(True)
  else:self.backend.button(button,True)
  return True
 def release(self):
  if self.active is None:return False
  mode,button=self.active
  if mode==MODES[0]:self.backend.mouse(False)
  else:self.backend.button(button,False)
  self.active=None;return True
 def toggle(self,mode,button):
  if self.active is not None:self.release();return False
  self.press(mode,button);return True
 def emergency_release(self):
  failures=[]
  try:self.release()
  except Exception as exc:failures.append(str(exc))
  try:self.backend.mouse(False)
  except Exception as exc:failures.append(str(exc))
  try:self.backend.reset_pad()
  except Exception as exc:failures.append(str(exc))
  if not failures:self.active=None
  return failures
