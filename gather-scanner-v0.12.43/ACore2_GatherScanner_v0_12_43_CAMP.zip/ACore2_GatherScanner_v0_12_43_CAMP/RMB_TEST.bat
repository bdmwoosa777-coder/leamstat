@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 python rmb_launch.py
) else (
 py -3 rmb_launch.py
)
if errorlevel 1 pause
