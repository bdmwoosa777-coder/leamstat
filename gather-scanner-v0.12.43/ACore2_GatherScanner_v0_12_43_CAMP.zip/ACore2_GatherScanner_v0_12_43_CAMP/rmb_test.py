"""Separate Windows GUI: direct right-mouse input versus Steam-mapped Xbox."""
import os,ctypes,time
from ctypes import wintypes
import tkinter as tk
from tkinter import ttk
from rmb_probe import WindowsBackend,Probe,BUTTONS,MODES

def main():
 if os.name!='nt':raise SystemExit('RMB_TEST — отдельная программа только для Windows')
 root=tk.Tk();root.title('Тест ПКМ / Xbox — отдельный эксперимент');root.geometry('720x430')
 backend=WindowsBackend();probe=Probe(backend);mode=tk.StringVar(value=MODES[0]);button=tk.StringVar(value='X')
 status=tk.StringVar(value='Отпущено');jobs=[];registered=[]
 ttk.Label(root,text='Закрой бота перед тестом. F8 — удержать/отпустить; F9 — отпустить всё.',padding=10).pack(anchor='w')
 ttk.Combobox(root,textvariable=mode,values=MODES,state='readonly',width=52).pack(padx=12,anchor='w')
 line=ttk.Frame(root);line.pack(padx=12,pady=10,anchor='w')
 ttk.Label(line,text='Кнопка Xbox для Steam Input: ').pack(side='left')
 ttk.Combobox(line,textvariable=button,values=tuple(BUTTONS),state='readonly',width=8).pack(side='left')
 ttk.Label(root,textvariable=status,padding=10).pack(anchor='w')
 log=tk.Text(root,height=12,wrap='word',state='disabled');log.pack(padx=12,pady=8,fill='both',expand=True)
 def note(text):
  log.configure(state='normal');log.insert('end',time.strftime('%H:%M:%S')+' '+text+'\n');log.see('end');log.configure(state='disabled')
 def show():status.set('Отпущено' if probe.active is None else 'Удерживается: '+('ПКМ' if probe.active[0]==MODES[0] else probe.active[1]))
 def cancel_jobs():
  for job in jobs:
   try:root.after_cancel(job)
   except tk.TclError:pass
  jobs.clear()
 def release():
  cancel_jobs();errors=probe.emergency_release();show()
  note('Все команды отпущены' if not errors else 'Ошибка отпускания: '+'; '.join(errors))
 def toggle():
  try:
   held=probe.toggle(mode.get(),button.get());show()
   note(('Удержание передано. ' if held else 'Отпускание передано. ')+('Это подтверждение Windows, реакцию игры проверь сам.' if mode.get()==MODES[0] else 'Xbox-кнопка отправлена; ПКМ требует настроенного Steam Input.'))
  except Exception as exc:
   note(str(exc));probe.emergency_release();show()
 def timed_test():
  release();note('Через 3 секунды: удержание на 2 секунды. Переключись в AION2.')
  def begin():
   toggle()
   if probe.active is not None:jobs.append(root.after(2000,release))
  jobs.append(root.after(3000,begin))
 def connect():
  try:backend.connect();note('Виртуальный Xbox создан. В Steam назначь выбранную кнопку на ПКМ.')
  except Exception as exc:note(str(exc))
 controls=ttk.Frame(root);controls.pack(padx=12,pady=6,fill='x')
 ttk.Button(controls,text='Тест 2 с через 3 с',command=timed_test).pack(side='left')
 ttk.Button(controls,text='Отпустить всё (F9)',command=release).pack(side='left',padx=8)
 ttk.Button(controls,text='Подключить Xbox для Steam',command=connect).pack(side='left')
 def changed(*args):
  if probe.active is not None:release()
 mode.trace_add('write',changed);button.trace_add('write',changed)
 api=backend.api
 api.RegisterHotKey.argtypes=[wintypes.HWND,ctypes.c_int,wintypes.UINT,wintypes.UINT];api.RegisterHotKey.restype=wintypes.BOOL
 api.UnregisterHotKey.argtypes=[wintypes.HWND,ctypes.c_int];api.UnregisterHotKey.restype=wintypes.BOOL
 api.PeekMessageW.argtypes=[ctypes.POINTER(wintypes.MSG),wintypes.HWND,wintypes.UINT,wintypes.UINT,wintypes.UINT];api.PeekMessageW.restype=wintypes.BOOL
 for ident,key in ((1,0x77),(2,0x78)):
  if api.RegisterHotKey(None,ident,0x4000,key):registered.append(ident)
  else:note('Горячая клавиша '+('F8' if ident==1 else 'F9')+' занята; доступна кнопка отложенного теста.')
 def tick():
  msg=wintypes.MSG()
  while api.PeekMessageW(ctypes.byref(msg),None,0x0312,0x0312,1):
   if msg.wParam==1:toggle()
   elif msg.wParam==2:release()
  if probe.active is not None and not probe.target_ready():release();note('Окно игры потеряло фокус — удержание снято.')
  root.after(40,tick)
 def close():
  release()
  for ident in registered:api.UnregisterHotKey(None,ident)
  root.destroy()
 root.protocol('WM_DELETE_WINDOW',close)
 note('Режим Windows отправляет настоящий тип события ПКМ через SendInput, без кнопки Xbox. Принятие игрой пока не проверено.')
 note('Режим Steam отправляет только кнопку Xbox. Без привязки в Steam это не мышиный клик.')
 root.after(40,tick);root.mainloop()

if __name__=='__main__':main()
