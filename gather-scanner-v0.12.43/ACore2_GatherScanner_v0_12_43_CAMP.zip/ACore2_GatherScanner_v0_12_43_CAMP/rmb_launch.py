"""Use the existing bot runtime when present. Never run setup/installers."""
from pathlib import Path
import subprocess,sys

def main():
 root=Path(__file__).resolve().parent
 try:
  from runtime_env import find_runtime
  runtime=find_runtime(root)
 except ImportError:runtime=None
 return subprocess.run([str(runtime or sys.executable),str(root/'rmb_test.py')],cwd=root).returncode

if __name__=='__main__':raise SystemExit(main())
