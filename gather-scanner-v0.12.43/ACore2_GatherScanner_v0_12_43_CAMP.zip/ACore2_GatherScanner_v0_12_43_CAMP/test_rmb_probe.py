"""No Windows/game claims: test dispatch, releases and native INPUT layout."""
import ctypes,unittest
from types import SimpleNamespace
from unittest.mock import patch
from rmb_probe import Probe,WindowsBackend,Input,MouseInput,MODES
import rmb_launch

class Backend:
 def __init__(self):self.title='AION2';self.events=[];self.fail=False
 def foreground(self):return self.title
 def mouse(self,down):
  self.events.append(('mouse',down))
  if self.fail:raise RuntimeError('failed dispatch')
 def button(self,name,down):self.events.append(('pad',name,down))
 def reset_pad(self):self.events.append(('reset',))

class Dispatch(unittest.TestCase):
 def setUp(self):self.b=Backend();self.p=Probe(self.b)
 def test_windows_mode_replaces_xbox_output_with_mouse_events(self):
  self.p.press(MODES[0],'X');self.p.release();self.assertEqual(self.b.events,[('mouse',True),('mouse',False)])
 def test_steam_mode_sends_only_the_selected_xbox_button(self):
  self.p.press(MODES[1],'RS');self.p.release();self.assertEqual(self.b.events,[('pad','RS',True),('pad','RS',False)])
 def test_toggle_releases_original_mode_even_if_selection_changed(self):
  self.p.toggle(MODES[0],'X');self.p.toggle(MODES[1],'A');self.assertEqual(self.b.events,[('mouse',True),('mouse',False)])
 def test_second_press_does_not_duplicate_down_event(self):
  self.p.press(MODES[0],'X');self.assertFalse(self.p.press(MODES[0],'X'));self.assertEqual(len(self.b.events),1)
 def test_game_focus_is_required_for_down(self):
  self.b.title='Тест ПКМ'
  with self.assertRaises(RuntimeError):self.p.press(MODES[0],'X')
  self.assertEqual(self.b.events,[])
 def test_release_is_allowed_after_focus_loss(self):
  self.p.press(MODES[0],'X');self.b.title='Desktop';self.p.release();self.assertIsNone(self.p.active)
 def test_partial_failed_dispatch_is_still_recorded_for_release(self):
  self.b.fail=True
  with self.assertRaises(RuntimeError):self.p.press(MODES[0],'X')
  self.assertIsNotNone(self.p.active);self.b.fail=False;self.p.release();self.assertEqual(self.b.events[-1],('mouse',False))
 def test_emergency_release_resets_both_possible_outputs(self):
  self.p.press(MODES[1],'X');self.assertEqual(self.p.emergency_release(),[])
  self.assertIn(('mouse',False),self.b.events);self.assertIn(('reset',),self.b.events);self.assertIsNone(self.p.active)
 def test_failed_mouse_release_does_not_skip_pad_reset(self):
  self.p.press(MODES[0],'X');self.b.fail=True
  self.assertTrue(self.p.emergency_release());self.assertIn(('reset',),self.b.events)
 def test_unknown_button_is_rejected_before_any_output(self):
  with self.assertRaises(ValueError):self.p.press(MODES[1],'Unknown')
  self.assertEqual(self.b.events,[])

class NativeABI(unittest.TestCase):
 def test_input_has_windows_x64_or_x86_size_and_pointer_alignment(self):
  self.assertEqual(ctypes.sizeof(Input),40 if ctypes.sizeof(ctypes.c_void_p)==8 else 28)
  self.assertEqual(ctypes.sizeof(MouseInput),32 if ctypes.sizeof(ctypes.c_void_p)==8 else 24)
 def test_right_down_and_up_use_mouse_flags_not_keyboard_or_gamepad(self):
  seen=[];b=WindowsBackend.__new__(WindowsBackend)
  def send(count,p,size):
   e=ctypes.cast(p,ctypes.POINTER(Input)).contents;seen.append((count,e.type,e.mi.dwFlags,size));return 1
  b.api=SimpleNamespace(SendInput=send);b.mouse(True);b.mouse(False)
  self.assertEqual([s[2] for s in seen],[8,16]);self.assertTrue(all(s[0]==1 and s[1]==0 and s[3]==ctypes.sizeof(Input) for s in seen))
 def test_zero_injected_events_is_reported_as_failure(self):
  b=WindowsBackend.__new__(WindowsBackend);b.api=SimpleNamespace(SendInput=lambda *a:0)
  with patch.object(ctypes,'get_last_error',return_value=5,create=True):
   with self.assertRaises(RuntimeError):b.mouse(True)

class ExistingRuntime(unittest.TestCase):
 def test_uses_existing_python_without_running_setup(self):
  with patch('runtime_env.find_runtime',return_value='/existing/python.exe'),patch.object(rmb_launch.subprocess,'run',return_value=SimpleNamespace(returncode=0)) as run:
   self.assertEqual(rmb_launch.main(),0)
  args=run.call_args.args[0];self.assertEqual(args[0],'/existing/python.exe');self.assertTrue(args[1].endswith('rmb_test.py'))
 def test_missing_runtime_uses_current_python_without_installing(self):
  with patch('runtime_env.find_runtime',return_value=None),patch.object(rmb_launch.subprocess,'run',return_value=SimpleNamespace(returncode=0)) as run:
   rmb_launch.main()
  self.assertEqual(run.call_args.args[0][0],rmb_launch.sys.executable)

if __name__=='__main__':unittest.main()
