"""No failed terrain maneuver may silently terminate a healthy gather loop."""
import unittest
from unittest.mock import patch
from pathlib import Path
import json
import gather_engine as ge
from app import DEFAULT
from camera_control import PITCH_STRENGTH
from flight import FlightReading
from patrol_escape import PatrolEscape
from terrain_recovery import RecoveryWatch,TerrainRecovery
from test_navigation import GatherFixture,obs
from test_exploration import radar
from test_network_control import Source

GROUND=FlightReading(None,False)
AIR=FlightReading(80,True)

class WatchTests(unittest.TestCase):
    def test_stationary_measured_terrain_triggers_after_90_seconds(self):
        w=RecoveryWatch();seen=[]
        for i in range(181):
            if w.update(radar(flow=(0,0),valid=True),True,i*.5):seen.append(i*.5)
        self.assertEqual(seen,[90])
    def test_minor_back_and_forth_does_not_reset_persistent_stall(self):
        w=RecoveryWatch();due=False
        for i in range(181):due=w.update(radar(flow=(2 if i%2 else -2,0),valid=True),True,i*.5)
        self.assertTrue(due)
    def test_real_displacement_keeps_normal_patrol_out_of_rescue(self):
        w=RecoveryWatch()
        for i in range(400):self.assertFalse(w.update(radar(flow=(-1,0),valid=True),True,i*.5))
    def test_unknown_motion_requires_two_minutes_not_fake_zero_displacement(self):
        w=RecoveryWatch()
        for i in range(240):self.assertFalse(w.update(radar(valid=False),True,i*.5))
        self.assertTrue(w.update(radar(valid=False),True,120))
    def test_collection_resets_idle_period_and_attempt_has_cooldown(self):
        w=RecoveryWatch()
        for i in range(180):w.update(radar(flow=(0,0),valid=True),True,i*.5)
        self.assertFalse(w.update(radar(),False,90))
        self.assertFalse(w.update(radar(flow=(0,0),valid=True),True,100))
        w.attempted(100);self.assertEqual(w.next_at,130)
        self.assertFalse(w.update(radar(flow=(0,0),valid=True),True,101))

class RescuePolicyTests(unittest.TestCase):
    def test_unknown_or_under_50_energy_never_opens_wings(self):
        for energy in (None,0,49.9):
            e=TerrainRecovery(0,energy)
            commands=[]
            for i in range(100):
                a=e.step(i*.1,GROUND,0)
                if a.command:commands.append(a.command)
            self.assertEqual(commands,[])
    def test_exactly_50_energy_allows_preparing_one_flight(self):
        e=TerrainRecovery(0,50)
        self.assertGreater(e.step(0,GROUND,0).drive.pitch,0)
        self.assertEqual(e.step(2,GROUND,2*PITCH_STRENGTH).command,'V')
        self.assertIsNone(e.step(2.2,GROUND,2*PITCH_STRENGTH).command)
    def test_no_arc_has_no_rise_motion_no_repeat_v_and_ground_fallback(self):
        e=TerrainRecovery(0,80);e.step(0,GROUND,0)
        self.assertEqual(e.step(2,GROUND,.9).command,'V');e.sent('V',3)
        self.assertIsNone(e.step(6,GROUND,.9).drive)
        a=e.step(6.6,GROUND,.9);self.assertTrue(a.failed_takeoff)
        self.assertEqual(e.phase,'LEVEL')
        e.step(6.7,GROUND,.9);e.step(7.7,GROUND,.9-.94*PITCH_STRENGTH)
        self.assertEqual(e.phase,'GROUND')
        self.assertIsNotNone(e.step(7.8,GROUND,0).drive)
    def test_up_hold_is_bounded_if_stick_reports_never_advance(self):
        e=TerrainRecovery(0,80);e.step(0,GROUND,0)
        a=e.step(6.1,GROUND,0)
        self.assertIsNone(a.command);self.assertEqual(e.phase,'GROUND');self.assertTrue(a.levelled)
    def test_actual_energy_after_open_must_also_reach_50(self):
        for energy in (None,49):
            e=TerrainRecovery(0,80);e.step(0,GROUND,0);e.step(2,GROUND,.9)
            a=e.step(2.2,FlightReading(energy,True),.9)
            self.assertEqual(e.phase,'LEVEL');self.assertEqual(a.drive.pitch,-PITCH_STRENGTH)
    def test_rise_uses_forward_and_alternating_sides_then_940ms_level(self):
        e=TerrainRecovery(0,80);e.step(0,GROUND,0);e.step(2,GROUND,.9)
        a=e.step(2.1,AIR,.9);b=e.step(3.3,AIR,.9)
        self.assertGreater(a.drive.forward,0);self.assertLess(a.drive.strafe*b.drive.strafe,0)
        a=e.step(7.7,AIR,.9);self.assertEqual(e.phase,'LEVEL');self.assertLess(a.drive.pitch,0)
        a=e.step(8.7,AIR,.9-.94*PITCH_STRENGTH)
        self.assertTrue(a.levelled);self.assertEqual(e.phase,'CRUISE')
    def test_low_energy_ends_ascent_early(self):
        e=TerrainRecovery(0,80);e.step(0,GROUND,0);e.step(2,GROUND,.9);e.step(2.1,AIR,.9)
        self.assertLess(e.step(3,FlightReading(19,True),.9).drive.pitch,0)
        self.assertEqual(e.phase,'LEVEL')
    def test_cruise_uses_minimap_bearing_without_claiming_xyz(self):
        e=TerrainRecovery(0,80);e.phase='CRUISE';e.since=0
        a=e.step(1,AIR,0,heading=0,bearing=90)
        self.assertGreater(a.drive.strafe,.5);self.assertGreater(a.drive.yaw,0)
    def test_cruise_is_limited_to_four_seconds(self):
        e=TerrainRecovery(0,80);e.phase='CRUISE';e.since=0
        self.assertEqual(e.step(4.1,AIR,0).command,'END_AIR')
    def test_failed_close_keeps_moving_without_more_than_two_toggle_commands(self):
        e=TerrainRecovery(0,None,True);e.phase='CLOSE';commands=[]
        for i in range(50):
            a=e.step(i*.25,AIR,0)
            if a.command:commands.append(a.command);e.sent(a.command,i*.25)
        self.assertEqual(commands,['END_AIR','END_AIR']);self.assertEqual(e.phase,'AIR_EXIT')
        self.assertIsNotNone(e.step(13,AIR,0).drive)
        e.step(13.1,GROUND,0);e.step(13.5,GROUND,0)
        self.assertEqual(e.phase,'GROUND');self.assertTrue(e.step(22,GROUND,0).done)
    def test_ground_sequence_changes_directions_and_returns_to_search(self):
        e=TerrainRecovery(0);e.step(0,GROUND,0)
        motions=[e.step(t,GROUND,0).drive for t in (.1,2.1,4.1,6.1)]
        self.assertLess(motions[0].forward,0);self.assertGreater(motions[2].forward,0)
        self.assertGreater(motions[1].strafe,0);self.assertLess(motions[3].strafe,0)
        self.assertTrue(e.step(8.1,GROUND,0).done)

class RescueEngineTests(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(terrain_rescue_enabled=True,auto_view_recovery=False)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.collecting=None;self.f.attempt_active=False;self.f.selected=0
        self.e.target=None;self.e.target_confirmed=False;self.e.resource_hold=False
        self.clock=100.;self.e.budget.energy=80
        p=patch.object(ge.time,'monotonic',side_effect=lambda:self.clock);p.start();self.addCleanup(p.stop)
    def tick(self,dt=.1,reading=GROUND):
        self.clock+=dt;return self.e._terrain_recovery_tick(self.frame,reading,self.clock,radar(flow=(0,0),valid=True))
    def test_exact_log_failure_moves_on_and_never_sets_scanner_stop(self):
        self.e.patrol_escape=PatrolEscape(100);self.e.mode='PATROL_ESCAPE'
        self.e._patrol_escape_tick(self.frame,GROUND,100)
        self.clock=104;self.e._patrol_escape_tick(self.frame,GROUND,self.clock)
        self.assertFalse(self.e.stop_event.is_set());self.assertEqual(self.e.mode,'RESCUE')
        self.assertEqual(self.commands.count('V'),1)
        self.tick();self.tick();self.assertNotEqual(self.pad.axes,(0,0,0,0))
        self.tick(9)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.terrain_recovery)
        self.assertFalse(self.e.stop_event.is_set());self.assertEqual(self.commands.count('V'),1)
    def test_routine_failed_close_enters_recovery_instead_of_stopping(self):
        self.e.wing_close_pending=100;self.e.wing_close_started=100;self.clock=107
        self.assertTrue(self.e._service_wing_close(AIR,self.clock))
        self.assertEqual(self.e.mode,'RESCUE');self.assertFalse(self.e.stop_event.is_set())
    def test_completed_collection_is_never_replaced_by_rescue(self):
        self.f.collecting=99;self.f.selected=99;self.f.attempt_active=True
        self.assertFalse(self.e._start_terrain_recovery(self.clock,AIR))
        self.assertEqual(self.commands,[]);self.assertEqual(self.pad.axes,(0,0,0,0))
    def test_visible_lower_panel_blocks_start_without_network_owner(self):
        with patch.object(ge,'gathering_panel_pair',return_value=True):
            self.assertFalse(self.e._start_terrain_recovery(self.clock,GROUND))
        self.assertEqual(self.commands,[])
    def test_collection_appearing_during_rescue_cancels_only_maneuver(self):
        self.assertTrue(self.e._start_terrain_recovery(self.clock,GROUND))
        self.f.collecting=99;self.f.selected=99;self.f.attempt_active=True;self.f.nodes[99].gather_time=1000
        self.assertFalse(self.tick());self.assertIsNone(self.e.terrain_recovery)
        self.assertFalse(self.e.stop_event.is_set());self.assertEqual(self.commands,[])
        self.assertTrue(self.e._adopt_network_collection())
    def test_focus_loss_and_unready_network_send_no_recovery_motion(self):
        self.e._start_terrain_recovery(self.clock,GROUND)
        self.e.screen.focused=lambda:False;self.tick();self.assertEqual(self.pad.axes,(0,0,0,0))
        self.e.screen.focused=lambda:True;self.source.ready=False
        self.tick();self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.commands,[])
    def test_unknown_energy_and_blocked_budget_choose_ground_exit(self):
        for energy,blocked in ((None,False),(49,False),(80,True)):
            self.e.budget.energy=energy;self.e.budget.blocked=blocked
            self.assertTrue(self.e._start_terrain_recovery(self.clock,GROUND))
            self.assertFalse(self.e.terrain_recovery.fly);self.tick();self.tick()
        self.assertNotIn('V',self.commands)
    def test_stop_request_cannot_start_another_recovery(self):
        self.e.stop_event.set();self.assertFalse(self.e._start_terrain_recovery(self.clock,GROUND))
    def test_persistent_watch_triggers_rescue_from_main_step(self):
        with patch.object(self.e.terrain_watch,'update',return_value=True):
            self.e.step(self.frame,(0,0),obs(),radar(),GROUND,self.clock,1)
        self.assertEqual(self.e.mode,'RESCUE');self.assertFalse(self.e.stop_event.is_set())
    def test_short_failed_escapes_do_not_reset_long_stall_escalation(self):
        self.e.terrain_watch.reset(100);self.e.terrain_watch.valid=20
        for stamp in (130,160):
            self.clock=stamp;self.assertTrue(self.e._start_terrain_recovery(stamp,GROUND,force_ground=True))
            self.tick();self.tick();self.tick(9)
            self.assertEqual(self.e.mode,'SEARCH');self.assertEqual(self.e.terrain_watch.since,100)
        self.assertTrue(self.e.terrain_watch.update(radar(flow=(0,0),valid=True),True,190))
    def test_selected_resource_cancels_short_escape_without_stopping_scanner(self):
        self.e.patrol_escape=PatrolEscape(100);self.e.target_confirmed=True
        self.e._patrol_escape_tick(self.frame,GROUND,101)
        self.assertIsNone(self.e.patrol_escape);self.assertFalse(self.e.stop_event.is_set())
        self.assertEqual(self.commands,[])
    def test_wait_for_short_takeoff_starts_after_transmission(self):
        self.e.patrol_escape=PatrolEscape(100)
        send=self.e.bridge_cmd
        def slow(command):self.clock+=1.2;return send(command)
        with patch.object(self.e,'bridge_cmd',side_effect=slow):self.e._patrol_escape_tick(self.frame,GROUND,100)
        self.assertAlmostEqual(self.e.patrol_escape.since,101.2)
        self.clock=104;self.e._patrol_escape_tick(self.frame,GROUND,self.clock)
        self.assertIsNotNone(self.e.patrol_escape);self.assertFalse(self.e.stop_event.is_set())
    def test_default_rescue_enabled_at_90_seconds_and_camera_stays_940(self):
        self.assertTrue(DEFAULT['terrain_rescue_enabled']);self.assertEqual(DEFAULT['terrain_rescue_seconds'],90)
        config=json.loads((Path(ge.ROOT)/'settings_gather.json').read_text())
        self.assertTrue(config['terrain_rescue_enabled']);self.assertEqual(config['camera_working_view_ms'],940)

if __name__=='__main__':unittest.main()
