"""Track an already-owned, camera-facing resource badge; never discover a target."""
from dataclasses import replace
import threading
import cv2
import numpy as np

class OwnedEmblem:
 def __init__(self):self.lock=threading.RLock();self.key=None;self.candidate=None;self.template=None;self.at=-1e9;self.size=None
 def clear(self):
  with self.lock:self.key=None;self.candidate=None;self.template=None;self.at=-1e9;self.size=None
 def seed(self,key,candidate,frame,at):
  if candidate is None or candidate.emblem is None:return False
  x,y,w,h=map(int,candidate.emblem);H,W=frame.shape[:2]
  if min(w,h)<9 or x<0 or y<0 or x+w>W or y+h>H:return False
  template=cv2.cvtColor(frame[y:y+h,x:x+w],cv2.COLOR_BGR2GRAY)
  if np.std(template)<15:return False
  with self.lock:
   if key==self.key and at<self.at:return False
   self.key=key;self.candidate=replace(candidate,glyph=None);self.template=template.copy();self.at=at;self.size=(H,W)
  return True
 def refresh(self,key,frame,at):
  with self.lock:
   if key!=self.key or self.candidate is None or self.size!=frame.shape[:2] or not 0<=at-self.at<=2.5:return None
   old=self.candidate;x,y,w,h=old.emblem;cx,cy=x+w/2,y+h/2
   jump=max(12,min(36,min(w,h)*.75));margin=round(jump+max(w,h)*.20)
   H,W=frame.shape[:2];x0=max(0,x-margin);y0=max(0,y-margin);x1=min(W,x+w+margin);y1=min(H,y+h+margin)
   gray=cv2.cvtColor(frame[y0:y1,x0:x1],cv2.COLOR_BGR2GRAY);matches=[]
   for scale in (1.,.9,1.1):
    tpl=cv2.resize(self.template,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA);th,tw=tpl.shape
    if th>gray.shape[0] or tw>gray.shape[1]:continue
    scores=cv2.matchTemplate(gray,tpl,cv2.TM_CCOEFF_NORMED)
    for _ in range(3):
     _,score,_,(xx,yy)=cv2.minMaxLoc(scores)
     if score<.80:break
     scores[max(0,yy-th//2):yy+max(2,th//2),max(0,xx-tw//2):xx+max(2,tw//2)]=-1
     ex,ey=x0+xx,y0+yy;distance=float(np.hypot(ex+tw/2-cx,ey+th/2-cy))
     if distance<=jump:matches.append((distance,float(score),ex,ey,tw,th))
   if not matches:return None
   matches.sort(key=lambda v:(v[0],-v[1]));best=matches[0];distance,score,ex,ey,ew,eh=best
   for d,s,xx,yy,ww,hh in matches[1:]:
    separate=np.hypot(xx+ww/2-ex-ew/2,yy+hh/2-ey-eh/2)>max(6,min(ew,eh)*.45)
    if separate and s>=max(.82,score-.06) and d<=distance+max(8,min(ew,eh)*.4):return None
   bx,by,bw,bh=old.box;dx=round(ex+ew/2-cx);dy=round(ey+eh/2-cy)
   fresh=replace(old,box=(bx+dx,by+dy,bw,bh),click_x=ex+ew//2,click_y=ey+eh//2,emblem=(ex,ey,ew,eh),glyph=None)
   self.candidate=fresh;self.template=gray[ey-y0:ey-y0+eh,ex-x0:ex-x0+ew].copy();self.at=at
   return fresh
