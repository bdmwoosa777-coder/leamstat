"""A bounded local resource inspection, measured after the camera is ready."""
from dataclasses import dataclass

@dataclass
class ArrivalSearch:
 goal:object
 created:float
 initial:bool=False
 elapsed:float=0.
 observed:int=0
 last:float|None=None
 next_probe:float=0.
 candidate_until:float=0.
 terminal:object=None
 def pause(self,now):self.last=now
 def observe(self,now):
  if self.last is not None:self.elapsed+=max(0,min(3.,now-self.last))
  self.last=now;self.observed+=1
 @property
 def limit(self):return 6. if self.initial else 14.
 def expired(self,now):
  if now-self.created>=45:return True
  # Slow OCR must not spend the budget after one tiny UP pulse. The old
  # finite vertical scan gets to finish; the absolute 45 s bound still holds.
  if self.terminal is not None and getattr(self.terminal,'scan_pending',False):return False
  return self.observed>=2 and self.elapsed>=self.limit
