"""Classic resource state machine + fast minimap driver + asynchronous detours."""
from dataclasses import replace
import math,time,threading
import cv2
from gather_engine import GatherEngine,OWN_RESOURCE
from hybrid_navigation import RouteAdvisor,HybridPlanner
from qwen_experiment import TemporalAdvisor,network_context
from scene_recheck import recheck as recheck_scene
from navigation import Drive
from vision import gathering_panel_pair,find_resource_near,find_world_resource,fast_ether_candidates,read_world_caption,Observation,find_owned_resource_emblem
from acquisition_track import AcquisitionTrack
from resource_return import ResourceReturn
from return_exit import purple_anchor
from xbox_bridge import XboxBridge
from map_teleport import same_stamp,is_map,menu_stamp
from idle_return import map_evidence
from caption_memory import CaptionMemory
from camp_departure import CampDeparture
from resource_liveness import ResourceLiveness
from ether_neighbors import EtherNeighbors,same_caption
from camp_memory import load_routes,store_path,matching_route,ExitFollower
from post_tp_exit import BackExit,back_exit_seconds
from flight import read_flight
from combat_resume import CombatResource,UnownedFlightGate
from network_defense import AirDefenseView
from obstacle_follow import ObstacleFollower
from terrain_experience import TerrainExperience,terrain_signature,ExperienceGuide
from map_autopath import MapAutopath
from autopath_profile import effective as map_profile
from camera_working_view import working_view_ms

class HybridGatherEngine(GatherEngine):
 def _make_bridge(self,gamepad,cfg,emit):
  if cfg.get('control_transport','xbox')=='lua' or gamepad is None:return super()._make_bridge(gamepad,cfg,emit)
  return XboxBridge(gamepad,self.stop_event,lambda:self.screen.focused(),lambda:self.map_active and self.map_teleport is not None,cfg.get('dry_run',False),emit)
 def _wait_keyboard_alt_state(self,desired,seconds=.6):
  if not getattr(self.bridge,'controller_native',False):return super()._wait_keyboard_alt_state(desired,seconds)
  if self._focus_ok() and bool(self.bridge.alt_is_down())==desired:return True
  self.halt_reason='Режим курсора Xbox LB+LT не подтверждён в отчёте';self.say(self.halt_reason);self.stop();return False
 def _preflight_receiver(self):
  self.map_start_view_prepared=False
  if not getattr(self.bridge,'controller_native',False):return super()._preflight_receiver()
  until=time.monotonic()+10
  while not self.stop_event.is_set() and not self.screen.focused():
   if time.monotonic()>=until:self.halt_reason='Окно AION2 не активно';return False
   if self.stop_event.wait(.05):return False
  if not self._focus_ok():return False
  self._neutral();self.receiver_ready=False
  try:
   if not self.bridge.send('ALT_DOWN') or not self._wait_alt_state(True):return False
   self.bridge.send('ALT_UP')
   if not self._wait_alt_state(False):return False
   path=getattr(self,'map_autopath',None)
   if path is not None and path.required:
    tr=path._transport(self);result=tr.ping(lambda:self._focus_ok())
    if not result.acknowledged:
     self.say('MAP_PREFLIGHT: '+result.reason+'; Save & Run нового Lua, затем G9. Движение стиком запрещено');return False
    self.say('MAP_PREFLIGHT: ACK G9 Lua подтверждён; карта встроена, сбор через Xbox')
   self.receiver_ready=True;self.say('Xbox готов: LB+LT вниз/вверх без A; при автопути требуется новый G9 Lua')
   return True
  finally:self.bridge.send('ALT_UP')
 def __init__(self,cfg,*args,**kwargs):
  cfg=map_profile(cfg)
  if cfg.get('post_tp_back_exit_enabled',True):cfg['recorded_camp_exit_enabled']=False
  enabled=cfg.get('analyzer_enabled',True)
  super().__init__({**cfg,'analyzer_enabled':False},*args,**kwargs)
  self.combat_resource=None;self.unowned_flight=UnownedFlightGate();self.combat_note=-1e9
  self.post_tp_exit=None;self.post_tp_saved_floor=None;self.post_tp_flow=None;self.post_tp_owner=None
  self.cfg['analyzer_enabled']=enabled
  self.cfg['continuous_patrol_defense']=True
  self.cfg['defense_tab_limit']=max(3,min(8,int(cfg.get('defense_max_tabs',8))))
  self.world_process=None
  self.map_start_view_prepared=False
  if cfg.get('isolate_vision_processes',False):
   from isolated_vision import WorldProcess
   self.world_process=WorldProcess(self.say)
  self.scene_recheck_note=-1e9
  self.map_autopath=MapAutopath(self.cfg,self.say) if cfg.get('map_mousekeys_enabled',False) else None
  self.camp_failure_latched=False;self.scene_probe_after=0
  self.map_exit_failure=None
  self.native_close_after=0
  advisor=TemporalAdvisor if cfg.get('qwen_temporal_enabled',False) else RouteAdvisor
  self.analyzer=advisor(self.cfg,self.say) if enabled and self.scene_host is not None else None
  self.hybrid=HybridPlanner(cfg.get('camera_yaw_sign',1));self.hybrid_note=-1e9;self.hybrid_camp_check=-1e9;self.hybrid_identity_note=-1e9;self.hybrid_camp_pending=False;self.caption_latch=None;self.caption_after=0
  self.fast_sight_after=0;self.scan_checked_pulse=None
  self.camp_route=None;self.camp_rearm=True;self.sprint_surface_until=0;self.hybrid_goal_context=(self.nav.goal_epoch,None,False)
  self.interrupted_reacquire_key=None;self.interrupted_reacquire_until=None
  self.continuation_watch=None;self.continuation_check_after=0
  self.quick_probe_after=0;self.quick_probe_last=None;self.quick_input_proof=None;self.return_resource=None
  self.caption_memory=CaptionMemory()
  self.wall_escape_after=0
  self.obstacle_jump_pending=False;self.obstacle_action_until=0
  self.ether_neighbors=EtherNeighbors();self.neighbor_check_after=0
  self.ether_handoff_until=0;self.ether_handoff_candidate=None;self.ether_handoff_previous=None
  self.ether_handoff_point=None;self.ether_handoff_identity_until=0
  self.resource_liveness=ResourceLiveness();self.resource_wait_note=-1e9
  self.automatic_recovery=None;self.observers_check_after=0;self.death_wait=False;self.death_absent_since=None
  self.network_restart_after=0
  self.recorded_routes=();self.recorded_exit=None;self.recorded_probe=None;self.recorded_rejected=None;self.recorded_note=-1e9
  self.nearby_ground_proof=None;self.nearby_ground_used=False;self.nearby_ground_after=0;self.nearby_ground_pending=0
  self.resource_radar=None
  self.obstacle_follow=ObstacleFollower();self.path_episode=None;self.path_memory_note=-1e9;self.scene_turn_after=0
  memory_file=store_path(cfg).with_name('navigation_memory.json') if cfg.get('terrain_experience_enabled',True) and not cfg.get('dry_run',False) else None
  self.path_memory=TerrainExperience(memory_file,self.say)
  if cfg.get('recorded_camp_exit_enabled',False):
   try:self.recorded_routes=load_routes(store_path(cfg))
   except Exception as exc:self.say('ROUTE_LOAD: '+str(exc)+'; записанные выходы не используются')
  if self.gamepad is not None:self.gamepad.translation_lease_floor=float(self.cfg.get('smooth_translation_seconds',.75))
  if self.gamepad is not None:self.gamepad.sprint_repeat_seconds=max(1.,float(self.cfg.get('patrol_sprint_repeat_seconds',3.0)))
  # One progress watchdog owns detours. The legacy one stores screen-band IDs,
  # which are unsuitable for avoidance across camera changes.
  self.scene_pilot.follower.observe_progress=lambda *a:False
  self.say('HYBRID 0.12.53: курс к ресурсу, приоритет свежего эфира и ударов; выход из ошибки карты без остановки поиска')
 def change_mode(self,mode):
  previous=getattr(self,'mode',None)
  if mode!=previous and mode in ('APPROACH','REACQUIRE','RETURN','MAP_RETURN'):
   coordinates=getattr(getattr(self,'map_autopath',None),'coordinates',None)
   departed=getattr(coordinates,'departed',None)
   if callable(departed):departed()
  super().change_mode(mode)
  if hasattr(self,'hybrid') and mode!=previous:
   self.hybrid.reset_progress(clear_routes=mode!='SEARCH')
  if mode!=previous and mode in ('RETURN','MAP_RETURN') and hasattr(self,'camp_route'):
   self.camp_route=None;self.hybrid_camp_pending=False;self.camp_exit_until=0;self.camp_rearm=True
   self.recorded_exit=None;self.recorded_probe=None;self.recorded_rejected=None
 def _audit_pad_motion(self,forward,strafe,yaw,pitch,lifetime):
  terminal=self._map_terminal()
  if terminal is not None and self.mode=='SEARCH':terminal.delivered(forward,strafe,yaw,pitch,lifetime,time.monotonic())
  if abs(forward)+abs(strafe)>.001:
   coordinates=getattr(getattr(self,'map_autopath',None),'coordinates',None)
   departed=getattr(coordinates,'departed',None)
   if callable(departed):departed()
  return super()._audit_pad_motion(forward,strafe,yaw,pitch,lifetime)
 def _neutral(self):
  follower=getattr(self,'obstacle_follow',None)
  if follower is not None:
   stamp=time.monotonic();follower.delivered(stamp,stamp,False)
  exit=getattr(self,'post_tp_exit',None)
  if exit is not None:
   exit.stop_motion(time.monotonic())
   if not self._focus_ok():exit.ready_since=None
  return super()._neutral()
 def _camera_input_ready(self):
  if getattr(self,'post_tp_exit',None) is not None:return False
  return super()._camera_input_ready()
 def _prepare_working_view(self):
  ready=super()._prepare_working_view()
  if ready:self.map_start_view_prepared=True
  return ready
 def _map_terminal(self):
  path=getattr(self,'map_autopath',None)
  if path is None or not getattr(path,'required',False) or getattr(path,'owns',False):return None
  return getattr(getattr(path,'arrival',None),'terminal',None)
 def _translation_input_ready(self):
  path=getattr(self,'map_autopath',None)
  if path is not None and not getattr(path,'cancelling',False):
   if path.owns:return False
   if getattr(path,'required',False) and self.mode in ('SEARCH','ACQUIRE_WAIT'):
    terminal=self._map_terminal()
    if (self.mode!='SEARCH' or terminal is None or self.caption_latch is not None
        or self.map_active or self.target_confirmed or self.resource_hold
        or not terminal.permits_translation(time.monotonic())):return False
  return super()._translation_input_ready()
 def _a_input_ready(self):
  path=getattr(self,'map_autopath',None)
  if path is not None and path.owns:return False
  if getattr(self,'post_tp_exit',None) is not None:return False
  if not super()._a_input_ready():return False
  proof=getattr(self,'quick_input_proof',None)
  if proof is None:return True
  frame,_=self.screen.frame()
  return bool(self._completed_wait_proof(self._net_view())==proof
              and not gathering_panel_pair(frame) and not self._urgent_damage_pending())
 def _map_teleport_arrived(self,trip,now):
  path=getattr(self,'map_autopath',None)
  if path is not None and getattr(path,'required',False) and trip.used:
   self._neutral();self.pitch.set_working_baseline(now);self.camera_alignment_due=None
   self.return_exit_guard=False;self.exit_route=None;self.hybrid_camp_pending=False
   path.force_camp=True;path.next_at=now+3.5;self.change_mode('SEARCH')
   self.say('MAP_CAMP: после загрузки выход к ресурсу игровым автопутём; ход назад не запускается');return
  if trip.used:self.camp_failure_latched=False
  if (not self.cfg.get('post_tp_back_exit_enabled',True) or not trip.used
      or self.gamepad is None or not getattr(self.bridge,'controller_native',False)):
   return super()._map_teleport_arrived(trip,now)
  self._neutral();self._release_collection_cursor()
  self.obstacle_follow.reset();self.path_episode=None
  self.target=None;self.candidate=None;self.target_confirmed=False;self.resource_hold=False
  self.collecting_visible=False;self._reset_resource_watch();self._clear_view_recovery()
  self.caption_latch=None;self.probe=None;self.pending_probe=None;self.patrol_escape=None;self.terrain_recovery=None
  self.return_exit_guard=False;self.exit_route=None;self.return_sequence=None
  self.recorded_exit=None;self.recorded_probe=None;self.camp_route=None
  self.hybrid_camp_pending=False;self.camp_exit_until=0;self.camp_rearm=False
  self.hybrid.reset_progress(clear_routes=True)
  with self.pitch.lock:self.pitch.pause_depth=0;self.pitch.paused_at=None
  # The game establishes the arrival pose. Adopt it as the user's relative
  # reference without issuing a calibration or returning a pre-transfer tilt.
  self.pitch.set_working_baseline(now);self.camera_alignment_due=None
  self.camera_aligned_revision=self.camera_search_revision
  self.post_tp_exit=BackExit(back_exit_seconds(self.cfg),now)
  view=self._net_view();self.post_tp_flow=view['flow'] if view else None
  self.post_tp_owner=view['state'].own if view and view['ready'] else None
  self.post_tp_saved_floor=self.gamepad.translation_lease_floor;self.gamepad.translation_lease_floor=0
  self.change_mode('POST_TP_EXIT')
  self.say('BACK_EXIT_ARM: прибытие подтверждено; '+str(self.post_tp_exit.duration)+' с назад после загрузки; камера, запись и выбор ресурсов не вмешиваются')
 def _finish_post_tp_exit(self,now,done,reason):
  state=self.post_tp_exit
  if state is None:return
  self._neutral()
  if self.gamepad is not None and self.post_tp_saved_floor is not None:self.gamepad.translation_lease_floor=self.post_tp_saved_floor
  self.post_tp_exit=None;self.post_tp_saved_floor=None
  self.camp_route=None;self.hybrid_camp_pending=False;self.camp_exit_until=0;self.camp_rearm=False
  self.recorded_exit=None;self.recorded_probe=None;self.hybrid.reset_progress(clear_routes=True)
  self.nav.finish_goal(now);self.terrain_watch.reset(now);self.patrol_stall.reset(now)
  self.camera_alignment_due=None;self.identity_valid_after=now;self.change_mode('SEARCH')
  if done:self.no_yield.relocated(now)
  self.say(('BACK_EXIT_DONE: ' if done else 'BACK_EXIT_CANCEL: ')+reason+'; назад передано '+str(round(state.delivered,2))+' с; продолжаю поиск')
 def _post_tp_exit_tick(self,frame,now):
  state=self.post_tp_exit
  if state is None:return False
  stamp=time.monotonic();state.advance(stamp)
  if not self.cfg.get('post_tp_back_exit_enabled',True):
   self._finish_post_tp_exit(stamp,False,'выход назад отключён');return True
  if not self._focus_ok():self._neutral();return True
  view=self._net_view()
  if not view or not view['ready']:
   self._neutral();state.ready_since=None;return True
  if (view['flow']!=self.post_tp_flow or self.post_tp_owner is not None and view['state'].own!=self.post_tp_owner):
   self._finish_post_tp_exit(stamp,False,'изменилось соединение или свой персонаж');return True
  if self._own_collection(view) is not None or self._live_attempt(view) or self.target_confirmed or self.resource_hold:
   self._finish_post_tp_exit(stamp,False,'начато собственное взаимодействие с ресурсом');return True
  evidence=map_evidence(frame,self.minimap.bounds(frame));flight=read_flight(frame)
  usable=(not self.map_active and not is_map(frame) and evidence.usable and not evidence.loading
          and not flight.confirmed and not flight.swimming and 0<=stamp-now<=.9)
  if not state.ready(stamp,usable):self._neutral();return True
  path=getattr(self,'map_autopath',None)
  if path is not None and path.enabled and path.transport is not None and path.transport.ready:
   self._finish_post_tp_exit(stamp,False,'загрузился; выход передаётся игровому автопути по карте')
   path.force_camp=True;path.next_at=stamp;return True
  if state.done:
   self._finish_post_tp_exit(stamp,True,'заданный ход назад завершён без изменения камеры');return True
  right=state.right_remaining>.005;strafe=1. if right else 0.
  lease=min(.70,state.remaining,state.right_remaining if right else .70)
  self.gamepad.drive(-1.,strafe,0,0,lifetime=lease)
  sent=time.monotonic();deadline=getattr(self.gamepad,'translation_deadline',None)
  moving=self.gamepad.current_translation()
  if deadline is not None and deadline>sent and moving[0]<-.99 and abs(moving[1]-strafe)<.01:state.sent(sent,deadline,right)
  else:state.stop_motion(sent)
  if sent-state.note_at>=2:
   state.note_at=sent;self.say('BACK_EXIT: '+str(round(state.delivered,1))+'/'+str(state.duration)+' с назад; вправо '+str(round(state.right_delivered,2))+'/1.2 с; правый стик 0/0')
  return True
 def say(self,text):
  self.last_control_note=text;super().say(text)
 def stop(self,manual=False,terminal=False):
  path=getattr(self,'map_autopath',None)
  if path is not None:
   if manual or terminal or self.alert=='CAPTCHA':path.stop(self)
   elif path.owns:path.cancel(self,'восстановление управления')
  if hasattr(self,'obstacle_follow'):self.obstacle_follow.reset();self.path_episode=None
  if getattr(self,'post_tp_exit',None) is not None:self._finish_post_tp_exit(time.monotonic(),False,'остановка/восстановление управления')
  if manual or terminal or self.alert=='CAPTCHA':
   stats=getattr(self.network,'gather_stats',None)
   if stats is not None:stats.pause()
   result=super().stop(manual=manual,terminal=terminal)
   if hasattr(self,'path_memory'):self.path_memory.close()
   return result
  if self.stop_event.is_set():return
  now=time.monotonic();reason=self.halt_reason or getattr(self,'last_control_note','ошибка состояния')
  if self.automatic_recovery is None:
   self.automatic_recovery={'reason':reason,'since':now,'map_sent':None}
   self.say('AUTO_RECOVER: '+reason+'; процесс, наблюдение и защита не выключаются')
  self.halt_reason=None
  try:self._stop_defense_motion();self._neutral();self._release_inputs()
  except Exception as exc:self.emit('AUTO_RECOVER: освобождение ввода: '+str(exc))
 def trigger_alarm(self,kind,frame):
  if kind=='CAPTCHA':return super().trigger_alarm(kind,frame)
  if self.stop_event.is_set() or self.death_wait:return
  self.death_wait=True;self.death_absent_since=None;self.stop()
  self.say('DEATH_RECOVER: окно смерти; сигнал и наблюдение продолжаются, после воскрешения продолжу автоматически')
  try:self.death_alarm.start(self.cfg.get('audio_device','AG271QG4'),error_cb=self.emit)
  except Exception as exc:self.emit('Ошибка звука: '+str(exc))
 def _runtime_failure(self,exc):
  if self.stop_event.is_set():return False
  self.halt_reason='Ошибка рабочего цикла: '+repr(exc);self.stop();return True
 def _retry_runtime_setup(self):
  if self.stop_event.is_set():return False
  self.stop();return True
 def _ensure_observers(self,now):
  if now<self.observers_check_after or not self.safety_threads:return
  self.observers_check_after=now+2
  specs=((self._vision_loop,()),(self._health_fast_loop,()),(self._health_numeric_loop,()),
         (self._heartbeat_loop,()),(self._input_audit_loop,()),
         (self._dialog_loop,('CAPTCHA',self.cap,1.)),(self._dialog_loop,('DEATH',self.death,3.)))
  for i,worker in enumerate(tuple(self.safety_threads)):
   if not worker.is_alive() and not self.stop_event.is_set():
    target,args=specs[i];fresh=threading.Thread(target=target,args=args,daemon=True)
    self.safety_threads[i]=fresh;fresh.start();self.say('AUTO_RECOVER: восстановлен поток '+target.__name__)
 def _priority_network_defense(self,now):
  path=getattr(self,'map_autopath',None)
  if path is not None and (path.owns or getattr(path,'required',False) and self.mode=='SEARCH' and not self.target_confirmed and now>=getattr(path,'visual_until',0)):return False # Hits do not interrupt or delay map travel.
  return super()._priority_network_defense(now)
 def _automatic_recovery_tick(self,frame,now):
  if self.stop_event.is_set():return True
  path=getattr(self,'map_autopath',None)
  if path is not None and path.owns and (self.death_wait or self.automatic_recovery is not None):
   path.cancel(self,'приоритет восстановления/смерти',move=not self.death_wait)
  self._expire_camp_departure(now)
  self._ensure_observers(now)
  if self.death_wait:
   self._neutral()
   if self.death.check(frame)[0]:self.death_absent_since=None;return True
   if self.death_absent_since is None:self.death_absent_since=now
   if now-self.death_absent_since<1:return True
   self.death_wait=False;self.death_alarm.stop();self.say('DEATH_RECOVER: окно исчезло; восстанавливаю поиск')
  recovery=self.automatic_recovery
  if recovery is None and self.post_tp_exit is not None:return self._post_tp_exit_tick(frame,now)
  if recovery is None:
   path=getattr(self,'map_autopath',None)
   return path.tick(self,frame,now) if path is not None else False
  self._neutral();self.f_disable()
  if not self._focus_ok():return True
  view=self._net_view()
  if self.network is not None and (not view or not view['ready']):
   process=getattr(self.network,'process',None);failed=bool(view and view.get('error')) or process is not None and process.poll() is not None
   restart=getattr(self.network,'recover',None)
   if failed and callable(restart) and now>=self.network_restart_after:
    self.network_restart_after=now+5
    try:restart();self.say('AUTO_RECOVER: сетевой модуль перезапущен, жду свежие данные')
    except Exception as exc:self.say('AUTO_RECOVER: повтор сетевого подключения: '+str(exc))
   return True
  if is_map(frame):
   if recovery['map_sent'] is None or now-recovery['map_sent']>=2:
    recovery['map_sent']=now;self.map_active=True
    allowed=lambda:self._focus_ok() and is_map(self.screen.frame()[0])
    if hasattr(self.bridge,'send_guarded'):self.bridge.send_guarded('MAP',allowed)
    elif allowed():self.bridge.send('MAP')
   return True
  self.map_active=False;self.map_teleport=None;self.map_exit_failure=None;self.return_sequence=None
  self.camera_in_progress=False;self.camera_gate_busy=False;self.click_busy=False;self.view_click_pending=False
  self._resource_liveness_tick(frame,now)
  if self._live_attempt(view) or self._own_collection(view) is not None or self.caption_latch is not None:
   self.automatic_recovery=None;self._adopt_network_collection();return False
  self._stop_defense_motion();self.network_defense=None;self.defense_restore_view=None;self.defense_air_view=None
  self.defense_camera_until=None;self.hp_next_defense=now;self.attacker_retry_after.clear()
  self.target=None;self.candidate=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
  self.resume_resource_id=None;self.reacquire_until=None;self._reset_resource_watch();self._clear_view_recovery()
  self.collection_cycle.reset();self.cycle_authorized=None;self.cycle_ui_note=None
  self.probe=None;self.pending_probe=None;self.patrol_escape=None;self.terrain_recovery=None
  self.return_exit_guard=False;self.exit_route=None;self.wing_close_pending=None;self.wing_close_started=None
  self.nav.finish_goal(now);self.hybrid.problem_since=None;self.hybrid.blocked_at=None
  with self.pitch.lock:
   self.pitch.pause_depth=0;self.pitch.paused_at=None;self.pitch.failed=False;self.pitch.returning=False
  self.view_guard=type(self.view_guard)()
  if self.budget.airborne:self.camera_alignment_due=None;self.rescue_air_search_until=now+5
  else:self.camera_alignment_due='после восстановления управления';self.camera_requested_at=now
  self.automatic_recovery=None;self.identity_valid_after=now;self.change_mode('SEARCH')
  self.say('AUTO_RECOVER: поиск возобновлён, защита включена');return False
 def _camp_departure_owns_recovery(self,now):
  return bool(self.hybrid_camp_pending and self.camp_route is not None
              and 0<=now-self.camp_route.started<(90 if self.recorded_exit is not None else 60) and not self.return_exit_guard)
 def _expire_camp_departure(self,now):
  camp=self.camp_route
  if (not self.hybrid_camp_pending or camp is None or not camp.expired(now)
      or self.recorded_exit is not None and now-camp.started<90
      or self._productive_action_active(now)):return False
  self._neutral();self.camp_route=None;self.camp_exit_until=0;self.hybrid_camp_pending=False
  self.camp_failure_latched=True;self.camp_rearm=False
  self.camp_exit_retry_after=max(self.camp_exit_retry_after,now+120)
  self.recorded_exit=None;self.recorded_probe=None;self.recorded_rejected=None
  self.hybrid.reset_progress(clear_routes=True);self.nav.finish_goal(now)
  self.say('CAMP_LIMIT: общий срок выхода исчерпан; перепланирования не продлевают его. Поиск ресурсов и штатное восстановление продолжаются; тот же ориентир не запускает выход повторно')
  return True
 def _resource_options(self,now):
  sample=getattr(self,'resource_radar',None)
  if (sample is None or not 0<=now-sample[1]<=1.5 or self.return_exit_guard
      or self.hybrid_camp_pending or self.map_active):return []
  radar,_=sample
  return [m for m in self.nav.available_markers(radar,now,self.budget.can_start())
          if self.policy.allows('Эфир' if m.kind=='aether' else 'Самоцвет')]
 def _productive_action_active(self,now):
  # The resource FSM owns its own finite approach/acquisition/attempt deadlines.
  # A no-yield clock is not permission to cancel that FSM halfway through.
  if self.target_confirmed or self.resource_hold or self.collecting_visible or self.click_busy:return True
  if self.mode in ('ACQUIRE_WAIT','ACQUIRE','VERIFY_NATIVE','VERIFY_EMBLEM') and self.candidate is not None and 0<=now-self.started<10:return True
  if self.mode=='REACQUIRE' and self.resume_resource_id is not None and self.reacquire_until is not None and now<self.reacquire_until:return True
  latch=self.caption_latch
  if latch is not None and now<latch['until']:return True
  emblem=self.emblem_acquisition
  return bool(emblem is not None and now<emblem['until'])
 def _defer_return_for_resource(self,now):
  if not self._productive_action_active(now):return False
  if now>=getattr(self,'productive_return_note',0):
   self.productive_return_note=now+5
   self.say('RESOURCE_PRIORITY: активный выбор/подход/сбор важнее таймера возврата; маршрут и ID сохранены')
  return True
 def _return_input_ready(self):
  if self._productive_action_active(time.monotonic()):return False
  return super()._return_input_ready()
 def _start_return(self,frame,reading,now,view):
  if self._defer_return_for_resource(now):return False
  options=self._resource_options(now)
  if options:
   if now>=getattr(self,'resource_return_note',0):
    self.resource_return_note=now+10
    self.say('RETURN_DEFER: на свежей миникарте есть ещё '+str(len(options))+' доступных отметок; продолжаю поиск вместо телепорта')
   return False
  if self._camp_departure_owns_recovery(now):
   if now>=getattr(self,'camp_return_note',0):
    self.camp_return_note=now+15
    self.say('CAMP_RETURN_DEFER: сначала текущий выход из лагеря; старый таймер добычи не запускает повторный возврат')
   return False
  return super()._start_return(frame,reading,now,view)
 def _start_map_teleport(self,now):
  if self._defer_return_for_resource(now):return False
  if self._resource_options(now):
   self.return_sequence=None;self.pitch.resume_return(now);self.change_mode('SEARCH')
   self.say('RETURN_DEFER: перед открытием карты появились доступные ресурсы; возвращаюсь к поиску')
   return False
  if (self.map_teleport is None and self.cfg.get('post_tp_back_exit_enabled',True)
      and getattr(self.bridge,'controller_native',False) and self._automatic_camera_enabled()):
   frame,_=self.screen.frame();view=self._net_view()
   if (not self._focus_ok() or self.stop_event.is_set() or self.cfg.get('dry_run')
       or now<self.map_return_after or not view or not view['ready']
       or self._own_collection(view) is not None or gathering_panel_pair(frame)
       or self.resource_hold or self.target_confirmed or self._urgent_damage_pending()):return self._defer_map_departure(now)
   reading=read_flight(frame)
   if reading.confirmed or reading.swimming:return self._defer_map_departure(now)
   self._neutral();self._release_collection_cursor()
   self.say('MAP_DEPARTURE_VIEW: восстанавливаю рабочий наклон ДО открытия карты; после прибытия правый стик не трогаю')
   if not self._calibrate_camera('перед телепортом в лагерь'):return self._defer_map_departure(time.monotonic())
   now=time.monotonic()
   if self._defer_return_for_resource(now) or self._resource_options(now):return self._defer_map_departure(now)
  return super()._start_map_teleport(now)
 def _defer_map_departure(self,now):
  if self.mode=='RETURN' and self.map_teleport is None:
   self.return_sequence=None;self.pitch.resume_return(now);self.change_mode('SEARCH')
   self.no_yield.next_return=max(self.no_yield.next_return,now+5)
  return False
 def _no_yield_rescue_allowed(self,now):
  if self._productive_action_active(now):return False
  if self._camp_departure_owns_recovery(now) or self._resource_options(now):return False
  # Ninety seconds without loot is not evidence that walking needs takeoff.
  return self.terrain_watch.due(now)
 def bridge_cmd(self,command):
  path=getattr(self,'map_autopath',None)
  if path is not None and path.owns:
   if command not in ('PING','STOP','F_OFF','ALT_UP','MAP') and not (command=='V' and path.run.phase=='WINGS'):return False
  if getattr(self,'post_tp_exit',None) is not None and command not in ('STOP','F_OFF','ALT_UP','PING'):return False
  native=getattr(self.bridge,'controller_native',False)
  free_close=(command=='END_AIR' and native and self.mode in ('SEARCH','ACQUIRE_WAIT','RESCUE','PROBE','PATROL_ESCAPE') and not self.target_confirmed and not self.resource_hold)
  if free_close and time.monotonic()<getattr(self,'native_close_after',0):return False
  sent=super().bridge_cmd(command)
  if free_close and sent:
   self.native_close_after=time.monotonic()+8;self.rescue_air_search_until=max(self.rescue_air_search_until,self.native_close_after)
  return sent
 def _wing_action_allowed(self,command,announce=True):
  free=(command=='END_AIR' and getattr(self.bridge,'controller_native',False)
        and self.mode in ('SEARCH','ACQUIRE_WAIT') and not self.target_confirmed
        and not self.resource_hold and not self.network_exhausted
        and self.abandoning_binding is None and self.wing_close_pending is None)
  if free:
   frame,_=self.screen.frame();reading=read_flight(frame)
   if not self.unowned_flight.observe(reading,time.monotonic()):return False
  return super()._wing_action_allowed(command,announce)
 def _service_wing_close(self,reading,now):
  if not getattr(self.bridge,'controller_native',False) or self.wing_close_pending is None:return super()._service_wing_close(reading,now)
  if not reading.confirmed:return super()._service_wing_close(reading,now)
  if now-self.wing_close_pending<3:self._neutral();return True
  self.wing_close_pending=None;self.wing_close_started=None;self.wing_close_retries=0
  self.rescue_air_search_until=max(self.rescue_air_search_until,now+5);self.nav.pause(now)
  self.say('AIR_CLOSE: одна Y уже передана; исчезновение дуги не подтверждено, повтор при падении запрещён. Продолжаю поиск без новой Y')
  return False
 def _map_teleport_failed(self,observation,reason,now):
  if self.map_teleport is None or self.map_teleport.used:
   return super()._map_teleport_failed(observation,reason,now)
  self._neutral();self.map_exit_failure={'reason':reason,'since':now,'sent':False,'absent':None}
  self.say('MAP_RECOVER: телепорт не подтверждался; закрываю карту и возвращаю поиск после проверки игрового экрана: '+reason)
 def _map_failure_exit_tick(self,frame,now):
  failure=self.map_exit_failure
  if failure is None:return False
  self._neutral()
  if not self._focus_ok():return True
  if not self._map_input_ready():
   self.halt_reason='MAP_RECOVER: сеть или сбор запрещают ввод';self.say(self.halt_reason);self.stop();return True
  opened=same_stamp(frame,self.map_menu_stamp) or is_map(frame)
  evidence=map_evidence(frame,self.minimap.bounds(frame))
  if opened:
   failure['absent']=None
   if not failure['sent']:
    if self.map_menu_stamp is None:self.map_menu_stamp=menu_stamp(frame)
    failure['sent']=True # A partially delivered toggle must not be repeated.
    if hasattr(self.bridge,'send_guarded'):self.bridge.send_guarded('MAP',lambda:self._map_input_ready(menu=True))
    else:self.bridge_cmd('MAP')
  elif evidence.usable and not evidence.loading:
   if failure['absent'] is None:failure['absent']=now
   if now-failure['absent']>=.6:
    self.bridge.send('STOP');self.map_teleport=None;self.map_active=False;self.map_exit_failure=None
    self.pitch.resume_return(now);self.return_exit_guard=False;self.exit_route=None
    self.no_yield.next_return=max(self.no_yield.next_return,self.map_return_after,now+60)
    self.nav.exclude_goal(now,30);self.nav.pause(now);self.terrain_watch.attempted(now)
    self.hybrid=HybridPlanner(self.cfg.get('camera_yaw_sign',1));self.scene_camera_epoch+=1
    self.identity_valid_after=now;self.change_mode('SEARCH')
    self.say('MAP_RECOVER: игровой экран подтверждён; продолжаю поиск, телепорт успешным не считаю')
    return True
  else:failure['absent']=None
  if now-failure['since']>8:
   self.halt_reason='MAP_RECOVER: закрытие карты не подтверждено за 8 с';self.say(self.halt_reason);self.stop()
  return True
 def _combat_current(self):
  lease=self.combat_resource
  if lease is None or self.network_target!=(lease.flow,lease.actor):return None
  return lease if lease.node(self._net_view()) is not None else None
 def _track_combat_marker(self,frame,now):
  lease=self._combat_current()
  if lease is None or lease.marker_key is None:return None
  return self.owned_emblem.refresh(lease.marker_key,frame,now,reacquire=True)
 def _begin_network_defense(self,resume):
  previous=self._combat_current()
  if (resume and previous is None and getattr(self.bridge,'controller_native',False)
      and self.network_target is not None and self.target is not None and self._focus_ok()):
   view=self._net_view();node=self._net_node(view)
   if view and view['ready'] and view['state'].own is not None and node is not None:
    lease=CombatResource(view['flow'],view['state'].own,node.actor,node.generation,node.template,
                         view['state'].map_id,self.target,self._owned_emblem_key())
    if lease.node(view) is not None:
     self.combat_resource=lease
     frame,_=self.screen.frame();self._observe_owned_emblem(frame,time.monotonic())
  super()._begin_network_defense(resume)
  lease=self._combat_current()
  if (self.network_defense is not None and previous is not None and previous.view is not None
      and previous.name=='Эфир' and self.network_defense.resource=='Эфир'
      and self.network_defense.resource_id==previous.actor):
   # The already-established downward view remains after the previous mob.
   self.defense_air_view=AirDefenseView(time.monotonic(),self.pitch.offset(time.monotonic()),phase='READY')
   self.defense_camera_until=None
   self.say('DEFENSE_RESOURCE: сохраняю нижний ракурс для следующего агрессора, без нового наклона и калибровки')
  if lease is not None:lease.pause(time.monotonic())
 def _restore_pitch(self):
  lease=self._combat_current()
  if lease is not None and lease.view is not None and self.mode!='SEARCH':
   with self.pitch.lock:self.pitch.returning=False;self.pitch.failed=False
   return
  if self._map_terminal() is not None and self.mode in ('SEARCH','ACQUIRE_WAIT'):
   with self.pitch.lock:self.pitch.returning=False;self.pitch.failed=False
   return
  if (self.cfg.get('map_autopath_required',False) and self.target=='Эфир'
      and (self.target_confirmed or self.resource_hold)
      and self.mode in ('APPROACH','TAKEOFF','GATHER','VERIFY_NATIVE','VERIFY_EMBLEM')):
   with self.pitch.lock:self.pitch.returning=False;self.pitch.failed=False
   return
  return super()._restore_pitch()
 def _finish_combat_view(self):
  lease=self.combat_resource
  if lease is None:return
  self.combat_resource=None
  if lease.view is not None and self._automatic_camera_enabled():
   network=self._net_view()
   if self._own_collection(network) is not None:
    self.camera_alignment_due='после текущего сбора, прерванного защитой'
    self.camera_requested_at=time.monotonic();self.defense_restore_view=None
    return
   self.defense_restore_view=lease.view;self.camera_alignment_due=None
   with self.pitch.lock:self.pitch.returning=False;self.pitch.failed=False
   self.say('DEFENSE_RESOURCE: ресурс завершён/недоступен; возвращаю рабочую камеру один раз перед навигацией')
 def _free_air_close_ready(self,reading,now):
  if self._map_terminal() is not None:return False
  if not getattr(self.bridge,'controller_native',False):return True
  ready=self.unowned_flight.observe(reading,now)
  if not ready and now-getattr(self,'unowned_air_note',-1e9)>=5:
   self.unowned_air_note=now
   self.say('FREE_AIR_WAIT: переключение крыльев без своего ресурса требует устойчивой сильной дуги, одиночный кадр не нажимает Y')
  return ready
 def _combat_click_ready(self,lease,frame):
  if (self.combat_resource is not lease or self._combat_current() is not lease
      or self.mode!='REACQUIRE' or not self._focus_ok() or self.stop_event.is_set()
      or self.map_active or self.camera_in_progress or self._urgent_damage_pending()
      or gathering_panel_pair(frame)):return False
  view=self._net_view();node=lease.node(view)
  if node is None or self._own_collection(view) is not None:return False
  if self._live_attempt(view) and not self._stale_defense_lease(view,node):return False
  return True
 def _combat_resume_tick(self,frame,now):
  lease=self._combat_current()
  if lease is None or lease.view is None or self.mode!='REACQUIRE':return False
  self._neutral()
  view=self._net_view()
  if not self._focus_ok() or not view or not view['ready']:lease.pause(now);return True
  lease.resume(now)
  if self._urgent_damage_pending():return True
  if self._own_collection(view) is not None:
   lease.pending=None;self._adopt_network_collection();return True
  pending=lease.pending
  if pending is not None:
   state=view['state']
   if (state.selection_time>=pending['after'] and state.selected
       and state.selected!=lease.actor):
    # One selection event may name another object. Never activate it again.
    lease.pending=None;lease.misses+=1;lease.after=now+.4
    self.say('DEFENSE_RESOURCE: выбран другой ID; повтор на нём запрещён, сохранён исходный ресурс')
    return True
   if self._selected_resource(view,lease.name) and state.selected==lease.actor:
    candidate=self._track_combat_marker(frame,now)
    if candidate is None:candidate=pending['candidate']
    # This point was already selected; binding is established by the NEW
    # resource ID response. No second A is sent to stale image coordinates.
    if self._bind_resource_candidate(candidate):
     self.route_f_sent=True;self.route_active=True;self.native_route_started_at=now
     self.route_click_tries=1;self.route_click_sent_at=now
     self._clear_view_recovery();self.resume_resource_id=None;lease.pending=None
     self.last_progress=now;self.identity_valid_after=now;self.change_mode('APPROACH')
     key=self._owned_emblem_key()
     live=self.owned_emblem.refresh(lease.marker_key,frame,now,reacquire=True) if lease.marker_key is not None else None
     if live is not None and key is not None:
      self.owned_emblem.seed(key,live,frame,now);lease.marker_key=key
     self.say('DEFENSE_RESOURCE: тот же ID снова выбран; штатный подход запрошен одним кликом, жду свой старт без подъёма камеры')
    return True
   if now<pending['until']:return True
   lease.pending=None;lease.misses+=1;lease.after=now+.3
  if now>=lease.until or lease.misses>=2:return False
  if now<lease.after:return True
  candidate=self._track_combat_marker(frame,now)
  if candidate is None:return False
  if not self._combat_click_ready(lease,frame):return True
  self.click_busy=True
  try:
   if not self.bridge_cmd('ALT_DOWN') or not self._wait_alt_state(True):return True
   if not self.gamepad.wait(.10,self.stop_event,self.screen.focused):return True
   current,origin=self.screen.frame();candidate=self._track_combat_marker(current,time.monotonic())
   if candidate is None or not self._combat_click_ready(lease,current):return True
   self.bridge.cursor(origin[0]+candidate.click_x,origin[1]+candidate.click_y)
   if not self.gamepad.wait(.06,self.stop_event,self.screen.focused):return True
   current,origin=self.screen.frame();fresh=self._track_combat_marker(current,time.monotonic())
   if fresh is None or not self._combat_click_ready(lease,current):return True
   self.bridge.cursor(origin[0]+fresh.click_x,origin[1]+fresh.click_y)
   if not self._cursor_click_ready():return True
   self.network_selection_after=int(time.time()*1000);self.acquisition_clicked_at=time.monotonic()
   self.resume_resource_id=(lease.flow,lease.actor)
   if self.gamepad.tap_a(self.stop_event,self.screen.focused):
    lease.pending={'after':self.network_selection_after,'candidate':fresh,'until':time.monotonic()+2.5}
    lease.after=time.monotonic()+.3
    self.say('DEFENSE_RESOURCE: свежий отслеженный значок; один LB+LT+A для возврата, ожидаю исходный ID/свой старт')
   return True
  finally:
   self.bridge_cmd('ALT_UP');self.click_busy=False
 def _network_defense_tick(self,now):
  lease=self.combat_resource
  if lease is not None:
   view=self._net_view()
   if not view or not view['ready']:lease.pause(now)
   elif self._combat_current() is None or self.mode=='SEARCH':self._finish_combat_view()
   elif self._focus_ok():
    frame,_=self.screen.frame();self._track_combat_marker(frame,time.monotonic())
  if self.network_defense is None and self.mode!='DEFENSE' and self.defense_restore_view is None:
   if self._net_defense(now):return True
  return super()._network_defense_tick(now)
 def _net_defense(self,now):
  if self.mode in ('RESCUE','PROBE','PATROL_ESCAPE'):
   if not self._pending_network_hits(now):return False
   self._neutral();self.caption_latch=None;self.terrain_recovery=None;self.probe=None;self.pending_probe=None;self.patrol_escape=None
   self.pitch.resume_return(now);self.change_mode('SEARCH')
  return super()._net_defense(now)
 def _finish_network_defense(self,success,reason=''):
  goal=self.nav.goal;episode=self.network_defense;air=self.defense_air_view
  super()._finish_network_defense(success,reason)
  lease=self._combat_current()
  if success and lease is not None and episode is not None and episode.resume and self.mode=='REACQUIRE':
   if air is not None and air.moved:
    if lease.view is not None:air.turn_seconds+=lease.view.turn_seconds
    lease.view=air
   elif air is not None and lease.view is not None:lease.view.turn_seconds+=air.turn_seconds
   if lease.view is not None:
    self.defense_restore_view=None;self.camera_alignment_due=None
    with self.pitch.lock:self.pitch.returning=False;self.pitch.failed=False
    now=time.monotonic();lease.arm(now);self.reacquire_until=lease.until
    self.interrupted_reacquire_until=lease.until;self._clear_view_recovery()
    self.say('DEFENSE_RESOURCE: бой окончен; нижний ракурс сохранён до конца этого ресурса, калибровка отложена')
  elif self.combat_resource is not None:
   self._finish_combat_view()
  if success and goal is not None and self.nav.goal is goal and self.mode=='SEARCH':
   # Combat and its camera search are not failed attempts to walk to this
   # unselected minimap goal. The old 45 s deadline otherwise expires almost
   # immediately after a long fight and blacklists a still-visible resource.
   now=time.monotonic();self.nav.goal_started=now;self.nav.best_distance=goal.distance
   self.nav.goal_motion_at=None;self.nav.pause(now);self.hybrid.reset_progress(clear_routes=True)
   self.hybrid.goal_avoid.clear();self.hybrid.observe_goal(None,None,now,visible=False)
   self.say('GOAL_RESUME: защита завершена; сохранённой точке дан новый срок подхода без старого штрафа за бой')
 def save_debug(self,frame,label):
  if not self.cfg.get('debug_screenshots'):return
  try:
   self.screenshot_path.mkdir(exist_ok=True)
   safe=''.join(c for c in label if c.isalnum() or c=='_')[:80]
   file=self.screenshot_path/('hybrid_'+str(time.time_ns())+'_'+safe+'.jpg')
   if not cv2.imwrite(str(file),frame,[cv2.IMWRITE_JPEG_QUALITY,90]):return
   files=sorted(self.screenshot_path.glob('hybrid_*.jpg'),key=lambda p:p.name);total=sum(p.stat().st_size for p in files)
   while files and (len(files)>60 or total>64*1024*1024):
    old=files.pop(0);total-=old.stat().st_size;old.unlink()
  except (OSError,cv2.error) as exc:self.say('DEBUG_SAVE: '+str(exc)+'; управление продолжается')

 def _caption_rejected(self,candidate):
  return bool(self.caption_memory.rejected(candidate,time.monotonic()))
 def _retired_collection(self,view,node):
  return self.resource_liveness.retired(view,node)
 def _adopt_network_collection(self):
  adopted=super()._adopt_network_collection()
  self._path_collection_reached()
  if self.target_confirmed and self._net_gather_proof():self.camp_failure_latched=False
  if self.target=='Эфир' and self._net_gather_proof():self.nearby_ground_used=False
  if self.hybrid_camp_pending and self.target_confirmed and self._net_gather_proof():
   self.hybrid_camp_pending=False;self.camp_exit_until=0;self.camp_route=None
   self.say('CAMP_DONE: собственный сбор подтверждён; ресурс действительно доступен')
  if self.hybrid.problem_since is not None and self.target_confirmed and self._net_gather_proof():
   self.hybrid.problem_since=None;self.hybrid.blocked_at=None
  return adopted
 def _allowed(self,candidate,now):
  return not self._caption_rejected(candidate) and super()._allowed(candidate,now)
 def _acquire_miss(self,candidate,now):
  self.caption_latch=None
  super()._acquire_miss(candidate,now)
 def _acquire_caption_matches(self,frame,candidate):
  if candidate.name!='Эфир':return True
  if self._caption_rejected(candidate):return False
  x,y,w,h=candidate.box
  if candidate.emblem is not None:
   ex,ey,ew,eh=candidate.emblem;gap=y-ey-eh
   if not (-2<=gap<=max(12,h*1.7) and abs(ex+ew/2-x-w/2)<=max(10,w*.30)):
    self.say(f'ACQUIRE_REJECT: ромбик не привязан к подписи Эфир; caption={candidate.box}, emblem={candidate.emblem}')
    return False
  current,_=self.screen.frame();name,text=read_world_caption(current,candidate,self._owned_resource_names())
  self.say(f'ACQUIRE_POINT: ожидаю Эфир; локальное имя={name}, текст={text[:60]!r}, caption={candidate.box}, emblem={candidate.emblem}')
  if name is None and ''.join(c for c in text.casefold() if c.isalpha()) in ('войти','отмена','закрыть'):
   self.caption_memory.remember(candidate,'UI: '+text.strip(),time.monotonic())
   self.say('ACQUIRE_REJECT: надпись интерфейса '+repr(text.strip())+' вместо ресурса; A не отправлена')
   return False
  if name is not None and name!=candidate.name:
   self.caption_memory.remember(candidate,name,time.monotonic())
   self.say('ACQUIRE_REJECT: локальная подпись '+name+' противоречит Эфиру; A не отправлена')
   return False
  return self._focus_ok()
 def _completed_wait_proof(self,view):
  if (not view or not view['ready'] or self.network_target is None or self.mode!='GATHER' or self.map_active
      or not self.target_confirmed or not self.resource_hold or not self.real_gather_panel_seen):return None
  state=view['state'];node=self._net_node(view);result=state.last_own_result
  if (node is None or node.actor!=self.network_target[1] or not node.visible or node.gather_time is None or node.used not in (1,2)
      or state.own is None or view['flow']!=self.network_target[0]
      or self.network_owner is not None and state.own!=self.network_owner
      or state.collecting!=node.actor or state.selected not in (0,node.actor) or state.attempt_active
      or node.actor in state.npcs or node.actor in state.players
      or not result or result[0]!=node.actor or state.last_own_result_used!=node.used
      or result[1]<max(self.network_claimed_at,node.gather_time,state.started or 0)):return None
  return (self.network_target,state.own,node.gather_time,state.started,state.attempt_ordinal,node.used,result[1])
 def _completed_point_wait_tick(self,frame,now):
  if self.stop_event.is_set() or not self._focus_ok():
   self.continuation_watch=None;return False
  if self.network is None or self.click_busy or now<self.continuation_check_after:return False
  self.continuation_check_after=now+.20
  view=self._net_view();proof=self._completed_wait_proof(view)
  if proof is None or gathering_panel_pair(frame) or self._fresh_click_candidate(frame) is not None:
   self.continuation_watch=None;return False
  quick=self._native_owned_emblem()
  if quick:self._clear_view_recovery()
  if self._quick_visible_continuation(frame,now,proof):return True
  if self.continuation_watch is None or self.continuation_watch['proof']!=proof:
   self.continuation_watch={'proof':proof,'since':now}
   self.say('CONTINUATION_WAIT: попытка окончена; '+('до 2,5 с на видимый значок, без движения камеры' if self._native_owned_emblem() else 'не более 8 с на восстановление'))
   return False
  if now-self.continuation_watch['since']<(2.5 if quick else 8):
   if quick:self._ether_occlusion_peek(frame,now,proof)
   return False
  current,_=self.screen.frame();latest=self._net_view()
  if (self._completed_wait_proof(latest)!=proof or gathering_panel_pair(current)
      or self._fresh_click_candidate(current) is not None):
   self.continuation_watch=None;return False
  if quick:
   node=self._net_node(latest)
   if self.return_resource is None or self.return_resource.done:
    self.return_resource=ResourceReturn(latest['flow'],latest['state'].own,node.actor,node.generation,self.target,node.xyz,now)
   self.ignored_collection_lease=(latest['flow'],node.actor,node.gather_time)
   self._neutral();self.f_disable();self._clear_view_recovery();self.collection_cycle.reset();self.cycle_authorized=None
   self.target=None;self.candidate=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
   self.resume_resource_id=None;self.reacquire_until=None;self._reset_resource_watch()
   self.nav.finish_goal(now);self.continuation_watch=None;self.change_mode('SEARCH')
   self.rescue_air_search_until=max(self.rescue_air_search_until,now+2)
   self.say('QUICK_SEARCH: 2,5 с без видимого значка; продолжаю поиск без поворотов камеры и без штрафа ресурсу на 45 с. Прежняя точка сохранена')
   return True
  self._release_resource_wait(latest,now,'CONTINUATION_RELEASE: 8 с без точки после подтверждённого окончания')
  return True
 def _ether_occlusion_peek(self,frame,now,proof):
  watch=self.continuation_watch
  if (watch is None or self.target!='Эфир' or self.click_busy or self.camera_in_progress
      or self.cfg.get('dry_run') or self._urgent_damage_pending()
      or self._completed_wait_proof(self._net_view())!=proof or gathering_panel_pair(frame)
      or not (read_flight(frame).confirmed or self.resource_flight_owned)) :return False
  count=watch.get('peeks',0)
  if count>=3 or now-watch['since']<.3+count*.65:return False
  if not self._camera_input_ready():return False
  # One side only; do not translate, fold wings or alter pitch around the pet.
  self._neutral()
  try:
   self.gamepad.drive(0,0,.30,0,lifetime=.12)
   self.gamepad.wait(.12,self.stop_event,self.screen.focused)
  finally:self._neutral()
  watch['peeks']=count+1;self.identity_valid_after=time.monotonic()
  self.say('ETHER_SIDE_VIEW: перекрытый значок; короткий поворот вправо '+str(count+1)+'/3 без изменения высоты/наклона')
  return True
 def _quick_visible_continuation(self,frame,now,proof):
  if (not self._native_owned_emblem() or now<self.quick_probe_after or self.quick_probe_last==proof
      or self.cfg.get('dry_run') or not self.cfg.get('allow_click',True)
      or self.click_busy or self.camera_in_progress or self._urgent_damage_pending()):return False
  self.quick_probe_after=now+.5
  candidate=find_owned_resource_emblem(frame,self.target,allow_multiple=True)
  if candidate is None:return False
  view=self._net_view();old=self._net_node(view)
  if old is None or self._completed_wait_proof(view)!=proof:return False
  self._neutral();self.click_busy=True
  try:
   if not self.bridge_cmd('ALT_DOWN') or not self._wait_alt_state(True):return False
   if not self.gamepad.wait(.06,self.stop_event,self.screen.focused):return False
   current,origin=self.screen.frame()
   candidate=find_owned_resource_emblem(current,self.target,candidate,allow_multiple=True)
   if candidate is None or gathering_panel_pair(current) or self._completed_wait_proof(self._net_view())!=proof:return False
   after=int(time.time()*1000);stamp=time.monotonic()
   track=AcquisitionTrack(view,candidate,current,stamp,after,allow_any=True)
   if not track.seeded:return False
   point=(candidate.click_x,candidate.click_y);self.bridge.cursor(origin[0]+point[0],origin[1]+point[1])
   if not self.gamepad.wait(.06,self.stop_event,self.screen.focused):return False
   final,final_origin=self.screen.frame();live=self._net_view();stamp=time.monotonic()
   fresh=track.marker.refresh(track.key,final,stamp,reacquire=True)
   if (fresh is None or final_origin!=origin or gathering_panel_pair(final)
       or self._completed_wait_proof(live)!=proof or self._urgent_damage_pending()):return False
   x,y,w,h=fresh.emblem
   if not (x+1<=point[0]<x+w-1 and y+1<=point[1]<y+h-1) or not self._cursor_click_ready():return False
   after=int(time.time()*1000);track.after=after
   self.quick_probe_last=proof;self.network_selection_after=after;self.acquisition_clicked_at=stamp
   self.acquisition_track=track;self.acquisition_track_after=0
   if self.return_resource is None or self.return_resource.done:
    self.return_resource=ResourceReturn(live['flow'],live['state'].own,old.actor,old.generation,self.target,old.xyz,stamp)
   self.quick_input_proof=proof
   if not self.gamepad.tap_a(self.stop_event,self.screen.focused):return False
   self.ignored_collection_lease=(live['flow'],old.actor,old.gather_time)
   self.emblem_acquisition={'candidate':fresh,'flow':live['flow'],'owner':live['state'].own,
                            'clicked':stamp,'after':after,'until':stamp+12,'allow_any':True}
   self.target=fresh.name;self.target_confirmed=False;self.resource_hold=False;self.candidate=fresh
   self._clear_view_recovery();self._reset_resource_watch();self.collecting_visible=False
   self.continuation_watch=None;self.resume_resource_id=None;self.change_mode('VERIFY_EMBLEM')
   self.say('QUICK_CONTINUATION: попытка окончена; один клик по видимому значку без поиска точного совпадения. Жду фактический ID; прежний ресурс сохранён для возврата')
   return True
  finally:
   self.quick_input_proof=None;self.bridge_cmd('ALT_UP');self.click_busy=False
 def _release_resource_wait(self,view,now,reason,retire=False,hard=False):
  node=self._net_node(view) or view['state'].nodes.get(view['state'].collecting)
  binding=self.network_target or (view['flow'],node.actor)
  if retire and node is not None:self.resource_liveness.retire(view,node,hard)
  self._neutral();self.f_disable()
  self.resource_retry_after[binding]=now+45
  if node is not None:self.abandoned_lease=(*binding,node.gather_time)
  self._clear_view_recovery();self.collection_cycle.reset();self.cycle_authorized=None;self.cycle_ui_note=None
  self.target=None;self.candidate=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
  self.resume_resource_id=None;self.reacquire_until=None;self.missing_since=None;self._reset_resource_watch()
  self.nav.exclude_goal(now,45);self.pitch.restore(now)
  self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
  self.continuation_watch=None;self.change_mode('SEARCH');self.identity_valid_after=now
  self.resource_liveness.reset()
  self.say(reason+'; цель отложена на 45 с, поиск и защита продолжаются без нового A/B/Y')
 def _resource_wait_proof(self,view):
  if not view or not view['ready'] or self.map_active:return None
  s=view['state'];node=self._net_node(view)
  private=node is None and s.started is not None and s.attempt_active and s.collecting in s.nodes
  if private:node=s.nodes[s.collecting]
  if (node is None or s.own is None
      or not node.visible or node.used==3 or node.actor in s.npcs or node.actor in s.players
      or self._retired_collection(view,node)):return None
  if not private and (not self.target_confirmed or self.mode not in ('APPROACH','TAKEOFF','GATHER','REACQUIRE')):return None
  own=s.collecting==node.actor and s.started is not None
  if not own and self._live_attempt(view):return None
  result=s.last_own_result if s.last_own_result and s.last_own_result[0]==node.actor else None
  key=(self.resource_liveness.attempt(view,node),node.used,result,self.last_distance if not own else None)
  return key,12 if own else 20,own
 def _resource_liveness_tick(self,frame,now):
  if (not self._focus_ok() or self.click_busy or self.map_active or self.camera_in_progress):
   self.resource_liveness.reset();return False
  view=self._net_view()
  if not view or not view['ready']:self.resource_liveness.reset();return False
  panel=gathering_panel_pair(frame)
  pending=view['state'].nodes.get(view['state'].collecting)
  if panel and self._retired_collection(view,pending) and not self.resource_liveness.hard(view,pending):
   self.resource_liveness.restore(view,pending);self._adopt_network_collection()
   self.say('RESOURCE_ALIVE: нижняя шкала вернулась; собственный сбор принят без клика')
  proof=self._resource_wait_proof(view)
  if not proof:self.resource_liveness.reset();return False
  key,seconds,own=proof
  node=self._net_node(view) or pending
  attempt=self.resource_liveness.attempt(view,node) if own and view['state'].attempt_active else None
  began=max(view['state'].started or 0,node.gather_time or 0) if attempt else 0
  age=(time.time()*1000-began)/1000 if began else None
  if age is not None and not 0<=age<=300:age=None
  hard=self.resource_liveness.expired_attempt(attempt,now,age)
  if not hard and not self.resource_liveness.due(key,now,panel,seconds):return False
  current,_=self.screen.frame();latest=self._net_view()
  if (not hard and gathering_panel_pair(current)) or self._resource_wait_proof(latest)!=proof:
   self.resource_liveness.reset();return False
  self._release_resource_wait(latest,now,
      'RESOURCE_ALIVE: попытка превысила предел 15 с' if hard else 'RESOURCE_ALIVE: '+str(seconds)+' с без нижней шкалы и нового состояния попытки',retire=own,hard=hard)
  return True
 def _recover_resource_wait(self,frame,reading,now,kind):
  if self.network is None:return False
  if self._resource_liveness_tick(frame,now):return True
  # Visible collection is productive waiting, not a reason to switch off
  # the entire process and its defense/network/dialog services.
  self.started=now;self.collection_activity_at=now
  if now-self.resource_wait_note>=5:
   self.resource_wait_note=now;self.say('RESOURCE_ALIVE: тайм-аут '+kind+' не выключает бот; перепроверка сбора, защита остаётся включена')
  return True
 def _resource_fast_tick(self,frame,reading,now,panel=None,slots=None):
  if not reading.confirmed:self.unowned_flight.reset()
  self._adopt_network_collection()
  self._acquisition_marker_tick(frame,now)
  if self.return_resource is not None:
   self.return_resource.observe(self._net_view(),now)
   if self.return_resource.done:self.return_resource=None
  if self._combat_resume_tick(frame,now):return True
  key=self._owned_emblem_key()
  if key is not None:self.owned_emblem.refresh(key,frame,now,reacquire=self._net_gather_proof())
  if self._resource_liveness_tick(frame,now):return True
  if self._nearby_ground_tick(frame,reading,now):return True
  if self._completed_point_wait_tick(frame,now):return True
  return super()._resource_fast_tick(frame,reading,now,panel,slots)
 def _needs_visual_hp(self):
  if self.network is None:return True
  if not hasattr(self.network,'confirm_own_hp'):return False
  view=self._net_view();return bool(view and view['ready'] and view['state'].own is None)
 def _health_identity_sample(self,value,captured,verified):
  if self.network is None or not hasattr(self.network,'confirm_own_hp') or not verified or value is None or value.current>=value.maximum or not self._focus_ok() or not self._needs_visual_hp():return
  self.network.confirm_own_hp(value.current,value.maximum,int((time.time()-time.monotonic()+captured)*1000))
 def _world_resource(self,frame,names):
  names=tuple(n for n in names if isinstance(n,str) and n)
  if not names:return None
  if self.world_process is None:return super()._world_resource(frame,names)
  with self.caption_memory.lock:entries=self.caption_memory.entries
  return self.world_process.search(frame,names,entries,self.stop_event)
 def _network_world_observation(self,frame):
  self._observe_nearby_ground(frame)
  if self.mode=='RESCUE' and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE':
   return Observation(find_world_resource(frame,('Эфир',)),None,None,False,0,False,None,'HIDDEN')
  observation=super()._network_world_observation(frame)
  now=time.monotonic()
  if (self.cfg.get('ether_neighbor_handoff',False) and self.mode=='GATHER' and self.target=='Эфир'
      and not self.map_active and not self.camera_in_progress and now>=self.neighbor_check_after):
   self.neighbor_check_after=now+1
   view=self._net_view();owned=self._own_collection(view)
   previous=observation.candidate or self.candidate
   if owned is not None and previous is not None:
    choices=fast_ether_candidates(frame,('Эфир',),deadline=time.monotonic()+.18,rejected=self._caption_rejected)
    # Sightings are data only: they never replace the owned observation and
    # cannot send A or camera input while any of its attempts remain.
    if self.mode=='GATHER' and self.target=='Эфир':
     self.ether_neighbors.observe(self._neighbor_key(view),choices,previous,now)
  return observation
 def _nearby_ground_ready(self,now):
  if (not self.cfg.get('nearby_ground_exception',False) or not self.policy.priority
      or self.cfg.get('dry_run',False) or not self.cfg.get('allow_click',True)
      or self.mode!='SEARCH' or self.target_confirmed or self.resource_hold or self.click_busy
      or self.map_active or self.caption_latch is not None or self.hybrid_camp_pending
      or self.budget.airborne or self.budget.swimming or self.wing_close_pending is not None
      or self.camera_in_progress or self.camera_alignment_due or self.pitch.returning or abs(self.pitch.offset(now))>.009
      or self.nav.air_since is not None or self.network_defense is not None or self._urgent_damage_pending()
      or not self._focus_ok() or self.stop_event.is_set() or self.network is None
      or not getattr(self.bridge,'controller_native',False) or self.gamepad is None
      or getattr(self.gamepad,'cursor_held',False)):return False
  view=self._net_view()
  return bool(view and view['ready'] and self._own_collection(view) is None and not self._live_attempt(view))
 def _observe_nearby_ground(self,frame):
  now=time.monotonic()
  if self.nearby_ground_used or now<self.nearby_ground_after or not self._nearby_ground_ready(now):return
  if self.resource_radar is None:return
  radar,stamp=self.resource_radar;scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  if not 0<=now-stamp<=.8 or not any(m.kind=='gem' and m.distance<=8*scale for m in radar.markers):return
  prompt,score=self.vision.prompt.detect_collect(frame)
  if not prompt:return
  names=tuple(n for n in self.cfg['target_names'] if n!='Эфир')
  if not names:return
  candidate=self._world_resource(frame,names)
  if candidate is None or candidate.glyph is None or self._caption_rejected(candidate):return
  h,w=frame.shape[:2];x,y,cw,ch=candidate.box
  if not (.30*w<x+cw/2<.74*w and .25*h<y<.73*h):return
  if not self._nearby_ground_ready(time.monotonic()):return
  self.nearby_ground_proof={'candidate':candidate,'at':now,'score':score}
 def _nearby_ground_tick(self,frame,reading,now):
  wall=time.monotonic()
  if now<self.nearby_ground_pending and self._nearby_ground_ready(now):
   self._neutral();return True
  proof=self.nearby_ground_proof
  if (proof is None or self.nearby_ground_used or now<self.nearby_ground_after
      or not 0<=wall-now<=.5 or not 0<=wall-proof['at']<=.8 or not self._nearby_ground_ready(wall)):return False
  # Recheck BOTH the action prompt and resource-specific text on this frame.
  fresh=find_resource_near(frame,proof['candidate'])
  if not self.vision.prompt.detect_collect(frame)[0] or fresh is None:
   self.nearby_ground_proof=None;return False
  self._neutral();self.nearby_ground_used=True;self.nearby_ground_after=now+45;self.nearby_ground_proof=None
  # This one explicit candidate may bypass Ether priority for acquisition.
  # Reuse the normal cursor/ID checks; contextual B could pick up nearby loot.
  previous=self.rescue_selecting
  self.rescue_selecting=True
  try:
   current,origin=self.screen.frame();fresh=find_resource_near(current,fresh)
   sent=bool(fresh is not None and self.vision.prompt.detect_collect(current)[0] and self.click_candidate(fresh,origin))
  finally:self.rescue_selecting=previous
  if not sent and fresh is not None and self.mode in ('ACQUIRE','ACQUIRE_WAIT') and not self.target_confirmed:
   self._acquire_miss(fresh,time.monotonic())
  self.say('NEARBY_GEM: '+proof['candidate'].name+'; точечный выбор значка через курсор, без B; отправлено='+str(bool(sent))+'; один ресурс, затем снова приоритет эфира; начало требует подтверждения сетью')
  return True
 def _neighbor_key(self,view):
  if not view or not view['ready'] or view['state'].own is None:return None
  s=view['state'];return view['flow'],s.own,s.map_id
 def _prepare_next_ether_view(self,frame,now):
  self.ether_handoff_until=0;self.ether_handoff_identity_until=0
  if (not self.cfg.get('ether_neighbor_handoff',False) or self.stop_event.is_set() or not self._focus_ok()
      or self.map_active or self.pitch.returning or self.pitch.failed or not self.budget.can_start()):return False
  view=self._net_view();node=self._net_node(view)
  if (not view or not view['ready'] or self._live_attempt(view) or node is None
      or not (node.used==3 or not node.visible and node.removed_reason==4)):return False
  previous=self.candidate
  if previous is None:return False
  if frame is None:frame,_=self.screen.frame()
  key=self._neighbor_key(view)
  candidates=self.ether_neighbors.current(key,now)
  if not candidates:
   choices=fast_ether_candidates(frame,('Эфир',),deadline=time.monotonic()+.18,rejected=self._caption_rejected)
   self.ether_neighbors.observe(key,choices,previous,now);candidates=self.ether_neighbors.current(key,now)
  for candidate in candidates:
   fresh=find_resource_near(frame,candidate)
   if fresh is None or same_caption(fresh,previous) or self._caption_rejected(fresh):continue
   # The final SEARCH frame will verify it again after the landing/fold.
   self.ether_handoff_candidate=fresh;self.ether_handoff_previous=previous
   self.ether_handoff_point=(previous.click_x,previous.click_y)
   self.ether_handoff_until=time.monotonic()+2.5;self.ether_handoff_identity_until=self.ether_handoff_until+2
   self.camera_alignment_due=None
   self.say('ETHER_NEIGHBOR: соседний эфир виден; после завершённых 3/3 сначала проверю его, без опускания камеры')
   return True
  return False
 def _cooldown_blocks(self,candidate,x,y):
  if (candidate.name=='Эфир' and time.monotonic()<self.ether_handoff_identity_until
      and self.ether_handoff_point==(x,y) and same_caption(candidate,self.ether_handoff_candidate)
      and not same_caption(candidate,self.ether_handoff_previous)):return False
  return super()._cooldown_blocks(candidate,x,y)
 def _handoff_frame(self,frame,obs,now):
  if not self.ether_handoff_until or self.mode not in ('SEARCH','ACQUIRE_WAIT'):return obs
  if now<self.post_gather_until:return obs
  view=self._net_view()
  if (self.stop_event.is_set() or self.map_active or not self._focus_ok()
      or not view or not view['ready'] or self._neighbor_key(view)!=self.ether_neighbors.key
      or self._live_attempt(view) or self._own_collection(view) is not None):
   self.ether_handoff_until=0;return obs
  fresh=find_resource_near(frame,self.ether_handoff_candidate) if now<self.ether_handoff_until else None
  if fresh is not None and not same_caption(fresh,self.ether_handoff_previous):
   pose,baseline=self.pitch.capture(time.monotonic())
   self._candidate_observed(fresh,time.monotonic(),pose,baseline)
   if self.caption_latch is not None:
    self.ether_handoff_until=0;return replace(obs,candidate=fresh)
  self.ether_handoff_until=0;self.ether_handoff_identity_until=0
  self.camera_alignment_due='соседний эфир больше не подтверждён';self.camera_requested_at=now
  self._restore_pitch();return obs
 def _visible_resource_before_map(self,frame,now):
  """Give an already visible Ether caption to the existing gather controller."""
  if (self.mode!='SEARCH' or self.caption_latch is not None or self.target_confirmed
      or self.resource_hold or self.click_busy or self.map_active or self.camera_in_progress
      or self.pitch.returning or self.return_exit_guard or self.wing_close_pending is not None
      or now<self.caption_after or now<getattr(self,'map_sight_after',0)
      or not self.cfg.get('allow_click',True) or not self._focus_ok() or self.stop_event.is_set()):
   return self.caption_latch is not None
  self.map_sight_after=now+.8
  with self.snapshot_lock:snapshot=self.snapshot
  candidate=None;captured=now
  if (snapshot is not None and self.identity_valid_after<=snapshot[1]<=now
      and now-snapshot[1]<=.8 and snapshot[0].candidate is not None):
   candidate=snapshot[0].candidate;captured=snapshot[1]
  if candidate is None and self.policy.allows('Эфир') and self.budget.can_start():
   choices=fast_ether_candidates(frame,('Эфир',),deadline=time.monotonic()+.15,rejected=self._caption_rejected)
   if choices:candidate=choices[0]
  if candidate is None:return False
  pose,baseline=self.pitch.capture(time.monotonic())
  self._candidate_observed(candidate,captured,pose,baseline)
  return self.caption_latch is not None
 def _candidate_observed(self,candidate,captured,pose,baseline=None):
  now=time.monotonic()
  if self._caption_rejected(candidate):return
  rescue=self.mode=='RESCUE' and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE'
  if (candidate.name not in self.cfg['target_names'] or self.caption_latch is not None or self.mode not in ('SEARCH','ACQUIRE_WAIT') and not (rescue and candidate.name=='Эфир')
      or self.target_confirmed or self.resource_hold or self.click_busy or self.camera_in_progress
      or self.map_active or self.return_exit_guard or self.pitch.returning or self.pitch.failed or not self.cfg.get('allow_click',True)
      or now<self.caption_after or now<self.defense_evade_until
      or not self.policy.allows(candidate.name) or candidate.name=='Эфир' and not self.budget.can_start()
      or self.nav.is_retreating(now)
      or not self._focus_ok() or not 0<=now-captured<=1.5):return
  if any(n==candidate.name and until>now and self._cooldown_blocks(candidate,x,y) for n,x,y,until in self.cooldowns):return
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None or self._live_attempt(view)):return
  if now-captured>.8:
   current,_=self.screen.frame();fresh=find_resource_near(current,candidate)
   if fresh is None:return
   candidate=fresh;pose,baseline=self.pitch.capture(time.monotonic())
  self.caption_latch={'candidate':candidate,'pose':pose,'baseline':self.pitch.baseline_revision if baseline is None else baseline,'until':time.monotonic()+2.5,'restored':False,'settle':0}
  if candidate.name=='Эфир':
   self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
   self.wing_close_pending=None;self.wing_close_started=None;self.wing_close_retries=0
  self._neutral() # Stop as soon as recognition completes, not after the next full navigation tick.
  # A caption pauses the exit through the normal acquisition state. Only
  # actual own gathering or measured departure may complete that exit.
  self.say(('ETHER_SIGHT' if candidate.name=='Эфир' else 'RESOURCE_SIGHT')+': '+candidate.name+' замечен; проверяю ромбик на свежем кадре без обязательного подхода вплотную')
 def _search_caption_priority(self,obs,now):
  # A fresh world caption over sky is actionable. A ground-view repair is
  # useful for walking, but must not turn away from a verified airborne node.
  if self._map_terminal() is not None and self.mode in ('SEARCH','ACQUIRE_WAIT'):return True
  return bool(self.caption_latch is not None and now<self.caption_latch['until']
              and obs.candidate is not None and self._allowed(obs.candidate,now))
 def _motion(self,plan):
  path=getattr(self,'map_autopath',None)
  if path is not None and path.required and self.mode in ('SEARCH','ACQUIRE_WAIT'):
   if not getattr(path,'searching',False):
    if not self.pitch.returning:self._neutral();return False
    # A post-gather pitch return needs camera input, never a patrol lease.
    plan=replace(plan,forward=0,strafe=0,yaw=0,flight_probe=False,local_approach=False)
   terminal=self._map_terminal()
   allowed=bool(plan.local_approach and terminal is not None and self.mode=='SEARCH' and terminal.permits_translation(time.monotonic()))
   plan=replace(plan,forward=plan.forward if allowed else 0,strafe=plan.strafe if allowed else 0,flight_probe=False)
  # A recognition callback can arrive after navigation has planned a turn.
  # Do not let that pending turn sweep a newly seen caption out of view.
  if getattr(self,'caption_latch',None) is not None and self.mode in ('SEARCH','ACQUIRE_WAIT'):
   self._neutral();return True
  if (self.scene_host is not None and self.mode=='SEARCH' and self.nav.goal is not None
      and not self.hybrid_camp_pending and not self.return_exit_guard and abs(plan.pitch)<.001
      and not plan.restore_pitch and abs(plan.yaw)>.001):
   stamp=time.monotonic()
   if stamp<self.scene_turn_after:plan=replace(plan,yaw=0,yaw_lifetime=None)
   else:self.scene_turn_after=stamp+1.2
  floor=getattr(self.gamepad,'translation_lease_floor',0) if self.gamepad is not None else 0
  if plan.local_approach and self.gamepad is not None:self.gamepad.translation_lease_floor=0
  try:result=super()._motion(plan)
  finally:
   if plan.local_approach and self.gamepad is not None:self.gamepad.translation_lease_floor=floor
  if self.gamepad is not None:
   self.obstacle_follow.delivered(time.monotonic(),getattr(self.gamepad,'translation_deadline',None),bool(result and math.hypot(plan.forward,plan.strafe)>.2))
  delivered=getattr(self.gamepad,'translation',(0.,0.)) if self.gamepad is not None else (0.,0.)
  if (result and self.mode=='SEARCH' and not self.hybrid_camp_pending and self.nav.goal is not None
      and abs(plan.yaw)+abs(plan.pitch)<.001 and math.hypot(*delivered)>.2):self.hybrid.note_goal_motion(time.monotonic())
  obstacle_ready=bool(result and self._obstacle_action_ready())
  if obstacle_ready:self.hybrid.note_escape_motion(time.monotonic())
  jump=self.obstacle_jump_pending;self.obstacle_jump_pending=False
  if result and jump and not obstacle_ready:self._neutral();return result
  if obstacle_ready and jump and self.gamepad is not None and hasattr(self.gamepad,'tap_moving_jump'):
   if not self.gamepad.tap_moving_jump(self.stop_event,self.screen.focused,self._obstacle_state_ready):self._neutral()
  if (result and self.gamepad is not None and hasattr(self.gamepad,'tap_sprint')
      and math.hypot(plan.forward,plan.strafe)>=.65 and abs(plan.yaw)+abs(plan.pitch)<.001):
   self.gamepad.tap_sprint(self.stop_event,self.screen.focused,self._sprint_input_ready)
  return result
 def _obstacle_state_ready(self):
  now=time.monotonic()
  if (now>=self.obstacle_action_until or self.hybrid.hazard_until>now or self.mode!='SEARCH'
      or self.stop_event.is_set() or not self._focus_ok() or self.map_active or self.click_busy
      or self.target_confirmed or self.resource_hold or self.collecting_visible or self.caption_latch is not None
      or self.budget.airborne or self.return_exit_guard or self.network_defense is not None
      or self.camera_in_progress or self.camera_alignment_due or self.pitch.returning
      or abs(self.pitch.offset(now))>.009):return False
  view=self._net_view()
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None or self._live_attempt(view)):return False
  return self._translation_input_ready()
 def _obstacle_action_ready(self):
  if not self._obstacle_state_ready():return False
  frame,_=self.screen.frame()
  return not gathering_panel_pair(frame) and self._obstacle_state_ready()
 def _sprint_input_ready(self):
  now=time.monotonic()
  if (not self.cfg.get('patrol_sprint',True) or not getattr(self.bridge,'controller_native',False)
      or self.mode!='SEARCH' or not self._focus_ok() or self.target_confirmed or self.resource_hold
      or self.collecting_visible or self.caption_latch is not None or self.click_busy or self.map_active
      or self.budget.airborne or self.return_exit_guard or self.hybrid_camp_pending and now>=self.obstacle_action_until or self.nav.air_since is not None
      or self.probe is not None or self.terrain_recovery is not None or self.patrol_escape is not None
      or self.network_defense is not None or self.defense_restore_view is not None
      or self.camera_in_progress or self.camera_alignment_due or self.pitch.returning
      or abs(self.pitch.offset(now))>.009 or now>=max(self.sprint_surface_until,self.obstacle_action_until) or self.nav.is_retreating(now)):
   return False
  if self.nav.goal is not None and self.nav.goal.distance<10*self.nav.last_scale:return False
  if now<self.obstacle_action_until and not self._obstacle_state_ready():return False
  if self.network is not None:
   view=self._net_view()
   if not view or not view['ready'] or self._own_collection(view) is not None or self._live_attempt(view):return False
  return self._translation_input_ready()
 def _terrain_recovery_tick(self,frame,reading,now,radar=None):
  if (self.caption_latch is not None and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE'
      and not self.target_confirmed and not self.resource_hold and self._own_collection() is None):
   self._neutral();self.terrain_recovery=None;self.pitch.resume_return(now);self.change_mode('SEARCH');self.nav.pause(now)
   self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
   self.say('ETHER_SIGHT: спасательный перелёт прерван свежей подписью; проверяю ресурс без закрытия крыльев')
   return False
  return super()._terrain_recovery_tick(frame,reading,now,radar)
 def _begin_reacquire(self,reason):
  super()._begin_reacquire(reason)
  self._bound_interrupted_reacquire(time.monotonic())
 def _bound_interrupted_reacquire(self,now):
  binding=self.defense_interrupted
  if binding is None or self.network_target!=binding[:2]:
   self.interrupted_reacquire_key=None;self.interrupted_reacquire_until=None;return
  if self.interrupted_reacquire_key!=binding:
   self.interrupted_reacquire_key=binding;self.interrupted_reacquire_until=now+8
   self.say('REACQUIRE_LIMIT: после прерывания боем до 8 с суммарно на возврат ресурса, включая камеру')
  deadline=self.interrupted_reacquire_until
  if self.reacquire_until is not None:self.reacquire_until=min(self.reacquire_until,deadline)
  if self.view_recovery is not None:self.view_recovery.until=min(self.view_recovery.until,deadline)
 def _restore_defense_camera(self):
  try:return super()._restore_defense_camera()
  finally:self._bound_interrupted_reacquire(time.monotonic())
 def _view_recovery_tick(self,frame,reading,now):
  if self._map_terminal() is not None and self.mode in ('SEARCH','ACQUIRE_WAIT'):return False
  self._bound_interrupted_reacquire(now)
  if (self.mode=='APPROACH' and self.route_f_sent and not self.real_gather_panel_seen
      and self.native_route_started_at is not None
      and (now-self.native_route_started_at<6 or now-self.last_progress<3)):
   self._clear_view_recovery();return False
  return super()._view_recovery_tick(frame,reading,now)
 def _start_terrain_recovery(self,now,reading,force_ground=False,short=False):
  fallen=self.working_area.rapid_drop(int(time.time()*1000))
  if not short and not fallen and (self._camp_departure_owns_recovery(now) or self._resource_options(now)):return False
  proven=now<self.hybrid.wall_flight_proven_until
  if short and not force_ground and not proven:return False
  ground_only=not short and not force_ground and not reading.confirmed and not fallen
  started=super()._start_terrain_recovery(now,reading,force_ground=force_ground or ground_only,short=short or ground_only)
  if started and ground_only:
   self.terrain_watch.attempted(now)
   self.say('GROUND_RESCUE: отсутствие результата не доказывает препятствие; наземный выход без открытия крыльев')
  return started
 def _caption_frame(self,frame,obs,now):
  latch=self.caption_latch
  if latch is None:return obs,False
  if (self.target_confirmed or self.resource_hold or self.mode not in ('SEARCH','ACQUIRE_WAIT')
      or self.map_active or not self._focus_ok() or self._own_collection() is not None):
   self.caption_latch=None;return obs,False
  if now>=latch['until']:
   self.caption_latch=None;self.caption_after=now+1;self.nav.air_since=None;self.nav.scan_kind=None
   return obs,False
  if not latch['restored']:
   self._neutral();error=latch['pose']-self.pitch.offset(now) if latch.get('baseline',self.pitch.baseline_revision)==self.pitch.baseline_revision else 0;latch['restored']=True
   if abs(error)>.006:
    seconds=min(.12,abs(error)/.45)
    self.gamepad.drive(0,0,0,.45 if error>0 else -.45,lifetime=seconds)
    latch['settle']=now+seconds+.2
    return obs,True
  if now<latch['settle']:return obs,True
  fresh=find_resource_near(frame,latch['candidate'])
  if fresh is not None:return replace(obs,candidate=fresh),False
  self._neutral();return obs,True
 def _camp_update(self,frame,radar,now,visible=False):
  if self._expire_camp_departure(now):return
  if not self.cfg.get('hybrid_camp_exit',True) or self.return_exit_guard:
   if now-getattr(self,'camp_status_note',-1e9)>=10:
    self.camp_status_note=now;self.say('CAMP_STATUS: выход из лагеря выключен' if not self.cfg.get('hybrid_camp_exit',True) else 'CAMP_STATUS: выходом управляет маршрут мостика')
   return
  width=radar.bounds[2]-radar.bounds[0];scale=max(.5,width/313)
  if now-self.hybrid_camp_check>=.5:
   self.hybrid_camp_check=now
   near=self.camp_route.anchor if self.camp_route is not None else None
   if near is not None and radar.motion_valid:near=(near[0]+radar.displacement[0],near[1]+radar.displacement[1])
   anchor=purple_anchor(frame,radar.bounds,near=near,search_radius=65*scale)
   if now-getattr(self,'camp_status_note',-1e9)>=10:
    self.camp_status_note=now
    self.say('CAMP_STATUS: '+('фиолетовый ориентир не найден' if anchor is None else 'ориентир на расстоянии '+str(round(math.dist(anchor,radar.center)/scale,1))+' пикс. масштаба 313')+'; входной радиус 65; активен='+str(self.hybrid_camp_pending))
   if anchor is not None:
    self.camp_last_seen=now
    close=math.dist(anchor,radar.center)<=65*scale
    if not close:self.camp_failure_latched=False
    if self.camp_route is None and close and self.camp_rearm and not self.camp_failure_latched and now>=self.camp_exit_retry_after and not visible:
     self.camp_route=CampDeparture(anchor,radar.center,width,now,prefer_visible=True)
     self.camp_exit_until=self.camp_route.until;self.hybrid_camp_pending=True;self.camp_rearm=False
     self.nav.retreat_until=0;self.nav.retreat_pending=False;self.nav.escape_until=0
     self.hybrid.reset_progress(clear_routes=True)
     self.say('HYBRID_CAMP_EXIT: держу курс из лагеря; точки миникарты не отменяют выход')
    replay_pending=self.recorded_exit is not None or self.recorded_probe is not None and self.recorded_probe['camp'] is self.camp_route and self.recorded_rejected is not self.camp_route
    if self.camp_route is not None and self.camp_route.observe(anchor,radar.center,now) and not replay_pending:
     self.hybrid_camp_pending=False;self.camp_exit_until=0;self.camp_route=None
     self.hybrid.reset_progress(clear_routes=True)
     self.say('CAMP_DONE: удаление от кибелиска подтверждено его положением на миникарте')
   elif self.camp_route is None and now-self.camp_last_seen>=3:self.camp_rearm=True
  if self.hybrid_camp_pending and self.camp_route is not None:
   if self.recorded_exit is not None:
    # The normal 35 s leg must not hand camera ownership to empty-map patrol
    # while a demonstrated route still advances. Its own 4/90 s bounds apply.
    self.camp_exit_until=max(self.camp_exit_until,now+2)
    return
   if now>=self.camp_exit_until:
    self.camp_route.replan(now);self.camp_exit_until=self.camp_route.until
    self.hybrid.reset_progress(clear_routes=True)
    self.say('CAMP_REPLAN: 35 с не подтвердили выход; меняю проход, выход из лагеря остаётся целью')

 def _recorded_exit_plan(self,frame,radar,reading,now):
  camp=self.camp_route
  if not self.recorded_routes or camp is None or self.recorded_rejected is camp or not self.hybrid_camp_pending:return None
  if (self.mode!='SEARCH' or not self._focus_ok() or self.map_active or self.target_confirmed or self.resource_hold
      or self.collecting_visible or self.click_busy or self.caption_latch is not None or reading.confirmed or self.budget.airborne
      or self.return_exit_guard or self.network_defense is not None or self.pitch.returning or abs(self.pitch.offset(now))>.015):return None
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None or self._live_attempt(view)):return None
  if gathering_panel_pair(frame):return Drive(reason='записанный выход: приоритет окна сбора')
  if self.recorded_probe is None or self.recorded_probe['camp'] is not camp:
   probe={'camp':camp,'at':now,'done':False,'title':'','error':None};self.recorded_probe=probe;image=frame.copy();bounds=radar.bounds
   def identify():
    try:
     from return_exit import place_title
     probe['title']=place_title(image,bounds)
    except Exception as exc:probe['error']=str(exc)
    finally:probe['done']=True
   threading.Thread(target=identify,daemon=True).start()
   self.say('ROUTE_MATCH: проверяю название места перед повтором записанного выхода')
   return Drive(reason='проверка записанного выхода')
  probe=self.recorded_probe
  if self.recorded_exit is None:
   if not probe['done'] and now-probe['at']<=3:return Drive(reason='проверка названия места')
   route=matching_route(self.recorded_routes,probe['title']) if probe['done'] else None
   if route is None:
    self.recorded_rejected=camp;self.say('ROUTE_REPLAY_ABORT: название места не совпало с записью; '+str(probe['error'] or probe['title']));return Drive()
   anchor=purple_anchor(frame,radar.bounds,near=camp.anchor)
   if anchor is None:return Drive(reason='ожидаю ориентир для начала записанного выхода') if now-probe['at']<=3 else self._abort_recorded_exit(camp,'не найден ориентир старта')
   try:self.recorded_exit=ExitFollower(route,anchor,radar.center,radar.bounds,now,self.hybrid.yaw_sign)
   except ValueError as exc:return self._abort_recorded_exit(camp,str(exc))
   self.say('ROUTE_REPLAY: '+route.place+'; '+str(len(route.points))+' точек; присоединение к точке '+str(self.recorded_exit.index+1)+'; поперечное отклонение '+str(round(self.recorded_exit.join_distance,2))+'; позиция '+str(tuple(round(v,2) for v in self.recorded_exit.current))+'; маршрут управляет выходом без локальных обходов')
  heading=radar.heading if radar.confidence>=.30 else None
  if self.scene_host is not None:
   self.scene_host.offer(frame,now,heading,self.pitch.offset(now),self.scene_camera_epoch)
   fresh=self.scene_host.current(now,heading,self.pitch.offset(now),self.scene_camera_epoch)
   if fresh is not None and fresh.ground is not None and fresh.ground.drop_support>=.04:
    self.hybrid.hazard_until=float('inf');return self._abort_recorded_exit(camp,'свежий кадр показывает возможный обрыв')
  anchor=purple_anchor(frame,radar.bounds,near=self.recorded_exit.last_anchor)
  action=self.recorded_exit.step(anchor,radar.center,radar.bounds,heading,now)
  if action.error:return self._abort_recorded_exit(camp,action.error)
  if action.done:
   self.say('ROUTE_REPLAY_DONE: последняя точка достигнута по свежему положению кибелиска; продолжаю сбор')
   self.recorded_exit=None;self.recorded_probe=None;self.recorded_rejected=None
   self.camp_route=None;self.hybrid_camp_pending=False;self.camp_exit_until=0;self.hybrid.reset_progress(clear_routes=True)
   return Drive()
  if now-self.recorded_note>=2:
   self.recorded_note=now;self.say('ROUTE_REPLAY: '+action.drive.reason)
  return action.drive
 def _abort_recorded_exit(self,camp,reason):
  self.recorded_exit=None;self.recorded_rejected=camp
  self.hybrid.reset_progress(clear_routes=True)
  self.say('ROUTE_REPLAY_ABORT: '+reason+'; записанный путь отозван, обычный поиск остаётся включён')
  return Drive()
 def step(self,frame,origin,obs,radar,reading,now,sequence=0):
  if self.stop_event.is_set():return
  self.resource_radar=(radar,now)
  obs=self._handoff_frame(frame,obs,now)
  searching=self.mode in ('SEARCH','ACQUIRE_WAIT') and not self.resource_hold and not self.target_confirmed and not self.map_active and self._focus_ok()
  self.policy.observe_map(radar.markers,now,searching)
  path=getattr(self,'map_autopath',None)
  local=getattr(path,'arrival',None) if path is not None else None
  if local is not None and searching and not self.camera_in_progress and not self.pitch.returning:
   local.observe(now)
   if obs.candidate is None and self.caption_latch is None and now>=local.next_probe:
    local.next_probe=now+.8
    names=self.policy.names(self.cfg.get('target_names',('Эфир','Алмаз','Сапфир','Рубин')))
    candidate=find_world_resource(frame,names,rejected=self._caption_rejected)
    if candidate is not None:
     obs=replace(obs,candidate=candidate)
     self.say('MAP_LOCAL_SIGHT: '+candidate.name+' в мире; передаю прежнему контроллеру выбора и полного сбора')
   if obs.candidate is not None and self._allowed(obs.candidate,now):local.candidate_until=now+2.5
  prefer_air=self.policy.priority and self.policy.air_on_map and self.policy.allows('Эфир')
  if searching and prefer_air and not self.click_busy:
   radar=replace(radar,markers=[m for m in radar.markers if m.kind=='aether'])
   if self.nav.goal is not None and self.nav.goal.kind!='aether':self.nav.goal=None;self.nav.best_distance=None
   if self.caption_latch is not None and self.caption_latch['candidate'].name!='Эфир':self.caption_latch=None
   if self.mode=='ACQUIRE_WAIT' and self.candidate is not None and self.candidate.name!='Эфир':
    self.candidate=None;self.change_mode('SEARCH')
  goal=self.nav.goal
  looking=self.nav.air_since is not None
  near_goal=(goal is not None and goal.kind=='aether' and goal.distance<60*self.nav.last_scale)
  if (self.cfg.get('scan_frame_checks',True) and self.mode=='SEARCH' and (looking or near_goal or local is not None) and (local is None or obs.candidate is None)
      and self.caption_latch is None and not self.target_confirmed and not self.resource_hold
      and not self.map_active and self._focus_ok() and now>=self.fast_sight_after
      and now>=self.nav.scan_pulse_end and now>=self.caption_after and not self.pitch.returning
      and not self.camera_in_progress and not self.return_exit_guard and not self.nav.is_retreating(now)):
   # This frame was captured after the last pulse expired. Inspect it before
   # Navigator can send the next pulse, especially before the down bracket.
   self.fast_sight_after=now+(.18 if looking else .65)
   h,w=frame.shape[:2];pose,baseline=self.pitch.capture(time.monotonic())
   candidates=fast_ether_candidates(frame,('Эфир',),deadline=time.monotonic()+.20,
                                   bounds=(round(w*.02),round(h*.02),round(w*.98),round(h*.55)),rejected=self._caption_rejected)
   if candidates:
    self._candidate_observed(candidates[0],now,pose,baseline)
    if self.caption_latch is not None:obs=replace(obs,candidate=candidates[0])
   self.scan_checked_pulse=(self.nav.air_since,self.nav.scan_last_pulse)
  if self.caption_latch is not None:
   obs,waiting=self._caption_frame(frame,obs,now)
   if waiting:return
  if self.mode=='SEARCH' and not self.target_confirmed and not self.resource_hold and not reading.confirmed and not self.map_active:
   self._camp_update(frame,radar,now,obs.candidate is not None and self._allowed(obs.candidate,now))
   # Actual minimap progress owns its timer. A succession of visual detours
   # must not erase the fact that the destination never gets any closer.
  if self.hybrid_camp_pending and self.mode=='SEARCH' and not self.target_confirmed:
   # Policy has already observed the real markers above. Only navigation is
   # redirected: visible world captions can still enter normal acquisition.
   self.nav.goal=None;self.nav.best_distance=None;self.nav.air_since=None;self.nav.scan_kind=None
   radar=replace(radar,markers=[])
  return super().step(frame,origin,obs,radar,reading,now,sequence)
 def _path_context(self,frame,radar,goal,now):
  view=self._net_view();map_id=view['state'].map_id if view and view['ready'] else None
  zone='map:'+str(map_id) if map_id is not None else 'camp:'+str(self.cfg.get('map_return_destination',''))
  key=(zone,self.nav.goal_epoch,goal.kind)
  self.obstacle_follow.observe(key,radar,now)
  episode=self.path_episode
  if episode is None or episode['key']!=key:
   bearing=math.degrees(math.atan2(goal.x-radar.center[0],radar.center[1]-goal.y))%360
   signature=terrain_signature(frame,radar,goal) if self.cfg.get('terrain_experience_enabled',True) else None
   episode={'key':key,'zone':zone,'kind':goal.kind,'sector':round(bearing/30)%12,'signature':signature,
            'at':now,'near_at':-1e9,'side':0,'travel':0,'saved':False,'preferred':None,'points':[],'guide':None,'leg':None}
   if signature is not None:
    recalled=self.path_memory.recall(zone,goal.kind,episode['sector'],signature)
    if recalled is not None:
     episode['preferred']=recalled['side'];episode['guide']=ExperienceGuide(recalled['path'])
    if episode['preferred'] is not None:self.say('PATH_MEMORY: узнал рельеф и сторону подхода; предлагаю обход '+('слева' if episode['preferred']<0 else 'справа')+'; каждый шаг требует свежего прохода')
   self.path_episode=episode
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  if goal.distance<=12*scale:episode['near_at']=now
  point=((radar.center[0]-goal.x)/scale,(radar.center[1]-goal.y)/scale)
  guide=episode['guide']
  if guide is not None and guide.points is not None:
   # A goal can enter the minimap long before the saved obstacle leg begins.
   # Wait for its start corridor instead of declaring that distant start lost.
   if guide.index is not None or min(math.dist(point,p) for p in guide.points)<=4:
    episode['leg']=guide.bearing(point)
  if self.obstacle_follow.side and radar.motion_valid:
   points=episode['points']
   if not points or 2<=math.dist(point,points[-1])<=16:
    if len(points)<64:points.append(point)
   elif math.dist(point,points[-1])>16:episode['points']=[];episode['signature']=None
  if self.obstacle_follow.side:
   episode['side']=self.obstacle_follow.side;episode['travel']=self.obstacle_follow.travel
  return episode
 def _path_collection_reached(self):
  episode=self.path_episode
  if episode is None or episode['saved'] or not self._net_gather_proof():return
  now=time.monotonic();view=self._net_view();node=self._net_node(view)
  kind='aether' if self.target=='Эфир' else 'gem'
  if (node is None or kind!=episode['kind'] or not view['state'].attempt_active
      or now-episode['near_at']>15 or now-episode['at']>90 or not episode['side'] or episode['travel']<3):return
  episode['saved']=True
  if not self.cfg.get('terrain_experience_enabled',True):return
  spawn={'template':node.template,'xyz':list(node.xyz)} if node.xyz is not None else None
  if self.path_memory.learned(episode['zone'],kind,episode['sector'],episode['signature'],episode['side'],spawn=spawn,points=episode.get('points')):
   self.say('PATH_MEMORY: собственный сбор подтвердил достижение ресурса; удачная сторона обхода сохранена локально, без записи стиков')
 def _probe_stationary_scene(self,candidate,frame,now,heading,pitch,settled,stationary):
  if (not stationary or now<self.scene_probe_after or candidate is None or candidate.source is None
      or not .9<now-candidate.captured<=3.2 or candidate.captured<settled
      or candidate.revision!=self.scene_camera_epoch or heading is None or candidate.heading is None
      or abs((heading-candidate.heading+180)%360-180)>2 or abs(pitch-candidate.pitch)>.005
      or self.camera_in_progress or self.click_busy or not self._focus_ok()
      or self._productive_action_active(now)):return None
  def idle(stamp):
   deadline=getattr(self.gamepad,'translation_deadline',None)
   yaw_end=getattr(self.gamepad,'yaw_deadline',None)
   move=getattr(self.gamepad,'translation',(0.,0.))
   return ((deadline is None or stamp>=deadline or math.hypot(*move)<.05)
           and stamp>=self.scene_settle_until
           and (yaw_end is None or stamp>=yaw_end))
  if not idle(now):return None
  self.scene_probe_after=now+.45;epoch=self.scene_camera_epoch;began=time.monotonic()
  try:fresh,_=self.screen.frame()
  except Exception as exc:
   self.say('SCENE_PROBE: новый кадр не получен: '+str(exc));return None
  stamp=time.monotonic()
  if (not 0<=stamp-began<=.35 or fresh.shape!=frame.shape or epoch!=self.scene_camera_epoch
      or not idle(stamp) or not self._focus_ok() or self.map_active
      or self.camera_in_progress or self._productive_action_active(stamp)
      or abs(self.pitch.offset(stamp)-pitch)>.005 or gathering_panel_pair(fresh)):return None
  result=recheck_scene(candidate,fresh,stamp,heading,pitch,epoch,settled,True,frame_age=stamp-began)
  if result is not None:
   self.say('SCENE_PROBE: задержанный результат проверен по новому неподвижному кадру; исходный возраст '+str(round(stamp-candidate.captured,2))+' с, захват '+str(round((stamp-began)*1000))+' мс; метка модели не изменена')
  return result
 def _scene_plan(self,frame,radar,reading,plan,now):
  path=getattr(self,'map_autopath',None)
  if path is not None and path.required:
   if not getattr(path,'searching',False):return Drive()
   terminal=self._map_terminal()
   if terminal is not None:
    if (self.mode!='SEARCH' or self.caption_latch is not None or self.target_confirmed
        or self.resource_hold or self.camera_in_progress or self.pitch.returning or self._own_collection() is not None):
     terminal.revoke();return Drive()
    stamp=time.monotonic()
    if stamp-now>.5:
     fresh,_=self.screen.frame()
     if is_map(fresh):terminal.revoke();return Drive()
     radar=self.minimap.observe(fresh)
     stamp=time.monotonic()
    result=terminal.plan(radar,stamp,self.pitch.offset(stamp),working_view_ms(self.cfg))
    return replace(result,yaw=result.yaw*self.nav.yaw_sign)
   result=replace(plan,forward=0,strafe=0,flight_probe=False)
   # A forward-only navigator plan would become a silent standstill after
   # translation is removed. Search horizontally in one direction instead.
   if (abs(result.yaw)+abs(result.pitch)<.001 and not result.restore_pitch
       and self.mode=='SEARCH' and not self.target_confirmed and not self.resource_hold
       and self.caption_latch is None and self._own_collection() is None
       and not self.camera_in_progress and not self.pitch.returning):
    result=replace(result,yaw=.26,lifetime=.18,reason='осмотр ресурса после автопути: поворот в одну сторону')
   return result
  self._expire_camp_departure(now)
  ticket=self.return_resource
  if (ticket is not None and self.mode=='SEARCH' and not self.target_confirmed and not self.resource_hold
      and not self.map_active and self._own_collection() is None and not self._urgent_damage_pending()
      and ('эфир' not in ticket.name.lower() or self.budget.can_start())):
   ticket.observe(self._net_view(),now);marker=ticket.choose(radar,now)
   if marker is not None:
    self.nav.finish_goal(now);self.nav.goal=marker;self.nav.goal_seen=now
    self.nav.goal_started=now;self.nav.best_distance=marker.distance;self.nav.goal_epoch+=1
    desired=math.degrees(math.atan2(marker.x-radar.center[0],radar.center[1]-marker.y))%360
    plan=self.nav._move_to(desired,radar.heading,now,'возврат к недособранному ресурсу после соседнего')
    self.say('RETURN_RESOURCE: соседний ресурс закончен; выбираю отметку в направлении прежнего ID='+str(ticket.actor)+' по XYZ двух ресурсов. Это предпочтение миникарты, обход остаётся по свежей сцене')
  self.obstacle_action_until=0;self.obstacle_jump_pending=False
  if (self.obstacle_follow.active and self.nav.goal is not None and self.mode=='SEARCH'
      and not reading.confirmed and (plan.flight_probe or abs(plan.pitch)>.001 or self.nav.air_since is not None)):
   self.nav.air_since=None;self.nav.scan_kind=None
   desired=math.degrees(math.atan2(self.nav.goal.x-radar.center[0],radar.center[1]-self.nav.goal.y))%360
   plan=(Drive(restore_pitch=True,reason='возвращаю обзор для текущего обхода') if abs(self.pitch.offset(now))>=.015
         else self.nav._move_to(desired,radar.heading,now,'продолжаю контролируемый обход той же цели'))
  context=((self.camp_route.leg if self.camp_route is not None else None),None,True) if now<self.camp_exit_until else (self.nav.goal_epoch,self.nav.goal.kind if self.nav.goal is not None else None,False)
  if context!=self.hybrid_goal_context:
   self.hybrid_goal_context=context;self.hybrid.reset_progress(clear_routes=True)
  camp_ground=(now<self.camp_exit_until and self.mode=='SEARCH' and not self.return_exit_guard
               and not self.target_confirmed and not self.resource_hold and not self.map_active
               and not reading.confirmed and not self.budget.airborne)
  if camp_ground and not self.pitch.returning:
   # Empty-map patrol (including its camera/flight proposal) cannot override
   # the still-unfinished departure. Restore a real tilt before ground routing.
   plan=(Drive(restore_pitch=True,reason='возвращаю землю в обзор для выхода из лагеря')
         if abs(self.pitch.offset(now))>.015 else Drive(.6,reason='продолжаю выход из лагеря'))
  if not plan.restore_pitch:
   recorded=self._recorded_exit_plan(frame,radar,reading,now)
   if recorded is not None:return recorded
  if abs(plan.pitch)>.001 or plan.restore_pitch or self.nav.air_since is not None:
   # An intentional sky scan is not eight seconds of failed walking.
   self.hybrid.reset_progress(clear_routes=True)
  if (self.scene_host is None or self.cfg.get('dry_run') or self.mode!='SEARCH' or self.target_confirmed
      or self.resource_hold or self.collecting_visible or self.caption_latch is not None or self.map_active or reading.confirmed or self.budget.airborne
      or self.camera_alignment_due or self.pitch.returning or abs(self.pitch.offset(now))>.015
      or not self._focus_ok() or abs(plan.pitch)>.001 or plan.restore_pitch or plan.flight_probe
      ):return plan
  if gathering_panel_pair(frame):
   live=self._net_view();pending=live['state'].nodes.get(live['state'].collecting) if live and live['ready'] else None
   if not self.resource_liveness.hard(live,pending):return plan
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None):return plan
  heading=radar.heading if radar.confidence>=.30 else None;pitch=self.pitch.offset(now)
  captured=time.monotonic()
  self.scene_host.offer(frame,now,heading,pitch,self.scene_camera_epoch)
  result=self.scene_host.current(captured,heading,pitch,self.scene_camera_epoch)
  # Camera-only surveying also needs new frames. Previously this returned
  # before offer(), starving the analyser precisely while facing a wall.
  if math.hypot(plan.forward,plan.strafe)<.05:return plan
  if result is None and captured-getattr(self,'path_scene_note',-1e9)>=5:
   self.path_scene_note=captured;latest=getattr(self.scene_host,'latest',None)
   if latest is not None:
    delta=abs((heading-latest.heading+180)%360-180) if heading is not None and latest.heading is not None else None
    self.say('PATH_SCENE: результат отклонён; возраст='+str(round(captured-latest.captured,2))+' с; ревизия='+str(latest.revision)+'/'+str(self.scene_camera_epoch)+'; разница курса='+str(round(delta,1) if delta is not None else None)+'; разница наклона='+str(round(abs(pitch-latest.pitch),3)))
  exit_mode=now<self.camp_exit_until
  if exit_mode and result is None and self.camp_route is not None:
   translation=getattr(self.gamepad,'translation',(0.,0.))
   deadline=getattr(self.gamepad,'translation_deadline',None)
   stationary=deadline is None or captured>=deadline or math.hypot(*translation)<.05
   candidate=getattr(self.scene_host,'latest',None)
   settled=max(self.camp_route.view_after,self.scene_settle_until)
   if captured-now>.35:
    result=self._probe_stationary_scene(candidate,frame,captured,heading,pitch,settled,stationary)
   else:
    result=recheck_scene(candidate,frame,captured,heading,pitch,self.scene_camera_epoch,
                         settled,stationary,frame_age=captured-now)
   if result is not None and result.ground is not None and result.ground.drop_support>=.04:
    self.hybrid.hazard_until=float('inf');result=None
   if result is not None and captured-self.scene_recheck_note>=2:
    self.scene_recheck_note=captured
    self.say('SCENE_RECHECK: исходному кадру '+str(round(captured-result.captured,2))+' с; неподвижный текущий вид совпал; исходная метка времени сохранена')
  goal=None if exit_mode else self.nav.goal
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  visible=bool(goal is not None and any(m.kind==goal.kind and math.hypot(m.x-goal.x,m.y-goal.y)<=4*scale for m in radar.markers))
  episode=self._path_context(frame,radar,goal,now) if goal is not None else None
  if goal is None:self.obstacle_follow.reset();self.path_episode=None
  failed=None if self.obstacle_follow.active else self.hybrid.observe_goal((self.nav.goal_epoch,goal.kind) if goal is not None else None,
   math.hypot(goal.x-radar.center[0],goal.y-radar.center[1]) if goal is not None else None,now,visible,scale)
  if failed is not None:self.say('GOAL_DETOUR: ходьба не приближает к ресурсу; меняю направление обхода '+str(round(failed))+' без отмены цели')
  goal_bearing=math.degrees(math.atan2(goal.x-radar.center[0],radar.center[1]-goal.y))%360 if goal else None
  context={'mode':'camp_exit' if exit_mode else 'resources','kind':goal.kind if goal else None,
           'goal_bearing':round(goal_bearing) if goal_bearing is not None else None,
           'goal_relative':round((goal_bearing-heading+180)%360-180) if goal_bearing is not None and heading is not None else None,
           'failed_bearings':[round(b) for b,t in self.hybrid.avoid+self.hybrid.goal_avoid if now<t]}
  temporal=self.analyzer is not None and getattr(self.analyzer,'temporal',False) is True
  if temporal:
   context.update(goal_epoch=self.camp_route.leg if exit_mode and self.camp_route is not None else self.nav.goal_epoch,camp_leg=self.camp_route.leg if exit_mode and self.camp_route is not None else None,
     goal_distance_px=round(math.hypot(goal.x-radar.center[0],goal.y-radar.center[1]),1) if goal else None,
     attempted_motion={'forward':round(plan.forward,2),'strafe':round(plan.strafe,2)},
     motion_valid=bool(radar.motion_valid),displacement=[round(v,2) for v in radar.displacement] if radar.motion_valid else None,
     network=network_context(view))
   context['frame_age_s']=round(max(0,captured-now),3)
   context['map_id']=getattr(view['state'],'map_id',None) if view and view.get('ready') else None
   self.analyzer.feedback(radar,now,context)
   context['position']=[round(v,2) for v in self.analyzer.position]
   self.analyzer.observe(frame,now,heading,pitch,context,radar.bounds)
   # Camp camera stabilisation must not prevent the asynchronous adviser
   # receiving observations. No VLM answer is required to leave this gate.
   if result is None and (exit_mode or self.hybrid.blocked_at is not None):
    self.analyzer.offer(frame,None,now,heading,pitch,context)
  if exit_mode:
   camp=self.camp_route
   if camp is not None:
    if result is not None and result.captured<max(camp.view_after,self.scene_settle_until):result=None
    previous_bearing=camp.bearing
    bearing=camp.choose(heading,result.ground if result is not None else None,now)
    if previous_bearing is None and bearing is not None:
     self.say('CAMP_CHOICE: '+camp.origin+'; курс '+str(round(bearing))+'; это выбор локального прохода, распознавание ворот не подтверждено')
    gate=camp.view_plan(heading,result is not None,now,self.hybrid.yaw_sign,wait_seconds=6)
    if gate is None and bearing is None and result is not None and result.ground is not None and result.ground.routes and any(now<t for _,t in camp.failed):
     gate=camp.camera_pulse(now,.42*self.hybrid.yaw_sign,.16,'выход: прежний проход не подошёл; проверяю следующий ракурс')
    if gate is not None:
     self.hybrid.tracking=False;self.hybrid.last_progress=now
     self._camp_view_note(gate,radar,result,now)
     return gate
   else:bearing=None
   plan=(self.nav._move_to(bearing,heading,now,'выход из лагеря: сохраняю выбранный проход')
         if bearing is not None else Drive(.6,reason='ищу видимый наземный проход из лагеря'))
   # The camera gate owns facing. Steer the stick along this current image;
   # incidental navigation yaw must not destroy every following scene result.
   plan=replace(plan,yaw=0,yaw_lifetime=None)
  hint=None;warning=None
  if result is not None and result.ground is not None:
   relative=math.degrees(math.atan2(plan.strafe,plan.forward));lane=result.lanes[0 if relative< -18 else 2 if relative>18 else 1]
   wide=(not exit_mode and abs(relative)<60 and result.ground.drop_support<.04 and lane.free>=.45 and lane.solid<.12 and lane.edge<.012
         and (lane.free>=.60 or any(r.confidence>=.60 and r.clearance>=1 for r in result.ground.routes)))
   self.sprint_surface_until=min(captured+.6,result.captured+.9) if wide else 0
  if self.analyzer is not None and result is not None and result.ground is not None:
   relative=math.degrees(math.atan2(plan.strafe,plan.forward))
   lane=result.lanes[0 if relative< -18 else 2 if relative>18 else 1]
   clear=(abs(relative)<=80 and result.ground.drop_support<.04 and lane.free>=.55 and lane.solid<.18 and lane.edge<.02
          and any(r.confidence>=.60 for r in result.ground.routes))
   if exit_mode or not clear or self.hybrid.blocked_at is not None or self.hybrid.commit is not None and now<self.hybrid.commit_until:
    self.analyzer.offer(result.source if result.source is not None else frame,result.ground,result.captured,result.heading,result.pitch,context)
   hint=self.analyzer.recommend(result.ground,frame,captured,heading,pitch,context)
   warning=self.analyzer.warning(captured,heading,pitch,context)
  face_goal=bool(goal is not None and goal.kind=='aether' and not self.nav.is_retreating(now) and now>=self.nav.escape_until)
  action=None;owned_bypass=False
  if goal is not None and visible and not exit_mode:
   action=(self.obstacle_follow.wait_for_scene(now) if result is None
           else self.obstacle_follow.choose(plan,result,radar,now,goal.distance,episode['preferred'],episode['leg']))
   if self.obstacle_follow.active:
    # The measured bypass owns this goal. Old straight-line stall timers
    # must not launch an unrelated wing probe or exclude it halfway around.
    self.nav.progress_at=now;self.nav.goal_motion_at=now
    self.nav.goal_started=max(self.nav.goal_started or now,now-20)
    self.hybrid.reset_progress(clear_routes=True)
   if action is not None:
    owned_bypass=True
    episode['side']=self.obstacle_follow.side;episode['travel']=self.obstacle_follow.travel
    if action.wall_escape:self.hybrid.wall_flight_proven_until=now+.9
    if action.skip:
     self.path_memory.learned(episode['zone'],episode['kind'],episode['sector'],episode['signature'],self.obstacle_follow.failed_side,success=False)
  if action is None:action=self.hybrid.choose(plan,result,radar,now,hint,exit_mode,warning,face_goal=face_goal)
  if exit_mode and self.camp_route is not None:
   if action.detour:
    action.drive=replace(action.drive,yaw=0,yaw_lifetime=None)
   elif abs(action.drive.yaw)>.001:
    action.drive=self.camp_route.camera_pulse(now,action.drive.yaw,action.drive.yaw_lifetime or .12,action.reason)
  if temporal and hint is not None and action.detour and action.reason.startswith('ИИ выбрал обход'):
   self.analyzer.executed(hint,captured,heading,context)
  if action.escape:
   self.obstacle_action_until=time.monotonic()+.8;self.obstacle_jump_pending=action.jump
  if self.caption_latch is not None:return Drive()
  if action.recalibrate:
   if now>=self.scene_view_retry_after:
    self.scene_view_retry_after=now+3;self.scene_view_repair=True;self.nav.air_since=None;self.nav.scan_kind=None;self.view_guard.force(now)
   return Drive()
  if action.skip and exit_mode and not action.wall_escape:
   if self.camp_route is not None:self.camp_route.replan(now);self.camp_exit_until=self.camp_route.until
   self.hybrid.reset_progress(clear_routes=True)
   self.say('CAMP_REPLAN: проход не дал продвижения; выбираю другой без исключения ресурсов')
   return Drive()
  if action.skip:
   measured=(radar.motion_valid and self.hybrid.last_progress is not None
             and now-self.hybrid.last_progress>=3)
   if self.nav.goal is not None and not measured and not action.wall_escape and not owned_bypass:
    self.hybrid.reset_progress(clear_routes=True)
    self.say('GOAL_KEEP: осмотр/поворот без подтверждённого упора не отменяет ресурс на миникарте')
    # Face the same goal on the next frame; never invent a clear path here.
    return Drive(yaw=plan.yaw,lifetime=min(.35,plan.lifetime),yaw_lifetime=plan.yaw_lifetime)
   if (action.wall_escape and now>=self.wall_escape_after and self.budget.energy is not None
       and self.budget.energy>=50 and self.budget.can_start() and not self.return_exit_guard):
    self.wall_escape_after=now+45
    if self._start_terrain_recovery(now,reading,short=True):
     self.terrain_recovery.lateral_escape=True;self.terrain_recovery.side=self.hybrid.escape_side
     self.terrain_recovery.cruise_bearing=(radar.heading+90*self.hybrid.escape_side)%360 if radar.heading is not None else None
     self.say('WALL_ESCAPE: боковые шаги и прыжки не помогли; подъём до 3 с со смещением в одну сторону, затем короткий боковой перелёт')
     return None
   if exit_mode:
    if self.camp_route is not None:self.camp_route.replan(now);self.camp_exit_until=self.camp_route.until
    self.hybrid.reset_progress(clear_routes=True)
    self.say('CAMP_REPLAN: боковой выход не помог; проверяю новый проход')
    return Drive()
   self.nav.exclude_goal(now,25);self.nav.air_since=None;self.nav.scan_kind=None
   self.say('HYBRID_REPLAN: недоступная цель отложена; выбираю другой ресурс/наземный выход')
  if now-self.hybrid_note>=1.5:
   self.hybrid_note=now
   state='нет' if self.analyzer is None else ('занят: '+getattr(self.analyzer,'phase','анализ')) if self.analyzer.busy else 'ошибка' if self.analyzer.error else 'готов' if self.analyzer.ready else 'ожидание'
   detail=('; полосы земля/стена/край='+str(tuple(tuple(round(v,2) for v in (l.free,l.solid,l.edge)) for l in result.lanes))+'; drop='+str(round(result.ground.drop_support,3)) if result is not None and result.ground is not None else '')
   self.say('HYBRID_NAV: '+action.reason+'; Qwen='+state+'; локальному кадру '+(str(round(captured-result.captured,2))+' с' if result else 'нет данных')+detail)
  return action.drive

 def _camp_view_note(self,drive,radar,result,now):
  if now-getattr(self,'camp_view_note',-1e9)<1.5:return
  self.camp_view_note=now
  latest=getattr(self.scene_host,'latest',None)
  age=round(time.monotonic()-latest.captured,2) if latest is not None else None
  revision=getattr(latest,'revision',None)
  bearing=self.camp_route.bearing if self.camp_route is not None else None
  self.say('CAMP_VIEW: '+drive.reason+'; курс='+str(round(bearing) if bearing is not None else None)
           +'; камера='+str(round(radar.heading) if radar.heading is not None else None)
           +'; возраст кадра='+str(age)+'; ревизия кадра/управления='+str(revision)+'/'+str(self.scene_camera_epoch)
           +'; свежий='+str(result is not None)+'; обработка='+str(round(latest.elapsed_ms) if latest is not None else None)+' мс; кадру управления='+str(round(time.monotonic()-now,2))+' с')
