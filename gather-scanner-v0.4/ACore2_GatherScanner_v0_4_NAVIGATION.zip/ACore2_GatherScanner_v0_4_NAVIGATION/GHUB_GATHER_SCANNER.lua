-- ACore2 Gather Scanner v0.4: ISOLATED G HUB profile.
-- DO NOT install over GHUB_AION2_SCANNER_V26.lua or existing PUBG macros.
-- Physically click G9 once while AION2 profile active to arm receiver.
-- Python sends 4 ScrollLock rising-edge strobes: SOF(3), HI, LO, CHECK.
-- Commands: 0 PING, 1 ALT_DOWN, 2 DOUBLE_CLICK, 3 ALT_UP,
-- 4 F_ON, 5 F_OFF, 6 V, 7 STOP, 8 TURN_RIGHT, 9 TURN_LEFT, 10 TAP_F.
-- 11 W_STEP, 12 LEFT_STEP, 13 RIGHT_STEP (bounded keyboard steps).
-- 14 JUMP. Navigation/camera now use the virtual Xbox sticks from Python.

local G9=9
local POLL_MS=12
local RX_GAP_MS=850
local WATCHDOG_MS=6500
local MAX_IDLE_MS=1800000
local F_INTERVAL_MS=1000
local F_HOLD_MS=85
local DOUBLE_CLICK_GAP_MS=105
local CAMERA_STEP=160
local WALK_STEP_MS=430
local STRAFE_STEP_MS=220
local running=false

local function receiver()
    local prev=IsKeyLockOn("scrolllock")
    local phase=0
    local hi=0
    local lo=0
    local last_edge=GetRunningTime()
    local last_rx=last_edge
    local last_f=last_rx
    local last_f_press=-1
    local f_enabled=false
    local alt_held=false
    local num_commands=0
    local receiver_active=true
    local walking_key=nil
    local walking_release_ms=-1

    local function release_all()
        if last_f_press>=0 then ReleaseKey("f");last_f_press=-1 end
        if alt_held then ReleaseKey("lalt");alt_held=false end
        f_enabled=false
        if walking_key then ReleaseKey(walking_key);walking_key=nil;walking_release_ms=-1 end
    end

    local function dispatch(cmd)
        num_commands=num_commands+1
        if cmd~=0 then
            OutputLogMessage("[GATHER RX] t=%d cmd=%d alt=%s f=%s\n",
                GetRunningTime(),cmd,tostring(alt_held),tostring(f_enabled))
        end
        if cmd==0 then
            -- Heartbeat; watchdog counts all validated commands.
        elseif cmd==1 then
            if not alt_held then PressKey("lalt");alt_held=true end
        elseif cmd==2 then
            if alt_held then
                OutputLogMessage("[GATHER CLICK] t=%d begin 2 x LMB\n",GetRunningTime())
                PressMouseButton(1);Sleep(50);ReleaseMouseButton(1)
                Sleep(DOUBLE_CLICK_GAP_MS)
                PressMouseButton(1);Sleep(50);ReleaseMouseButton(1)
                OutputLogMessage("[GATHER CLICK] t=%d functions finished (NOT game acknowledgement)\n",GetRunningTime())
                -- Leave Alt held until command 3 (cursor may need re-positioning).
            else
                OutputLogMessage("[GATHER CLICK SKIPPED] alt_held=false; expected cmd 1 before cmd 2\n")
            end
        elseif cmd==3 then
            if alt_held then ReleaseKey("lalt");alt_held=false end
        elseif cmd==4 then
            f_enabled=true
            last_f=GetRunningTime()-F_INTERVAL_MS -- first F immediately
        elseif cmd==5 then
            f_enabled=false
            if last_f_press>=0 then ReleaseKey("f");last_f_press=-1 end
        elseif cmd==6 then
            if not alt_held then PressKey("v");Sleep(70);ReleaseKey("v") end
        elseif cmd==7 then
            release_all()
            OutputLogMessage("[GATHER STOP] F/ALT released; receiver remains armed for next Ctrl+F8\n")
        elseif cmd==8 then
            if not alt_held then MoveMouseRelative(CAMERA_STEP,0) end
        elseif cmd==9 then
            if not alt_held then MoveMouseRelative(-CAMERA_STEP,0) end
        elseif cmd==10 then
            if last_f_press<0 and not alt_held then
                PressKey("f");last_f_press=GetRunningTime()
            end
        elseif cmd==11 or cmd==12 or cmd==13 then
            -- Short bounded keyboard movement; never hold W indefinitely.
            if not alt_held and not walking_key and not f_enabled then
                local k=(cmd==11 and "w" or (cmd==12 and "a" or "d"))
                walking_key=k
                walking_release_ms=GetRunningTime()+(cmd==11 and WALK_STEP_MS or STRAFE_STEP_MS)
                PressKey(k)
                OutputLogMessage("[WALK] key=%s limit=%dms\n",k,walking_release_ms-GetRunningTime())
            end
        elseif cmd==14 then
            if not alt_held then PressKey("space");Sleep(70);ReleaseKey("space") end
        end
        if num_commands<=6 or num_commands%30==0 then
            OutputLogMessage("[GATHER] cmd=%d total=%d F=%s\n",cmd,num_commands,tostring(f_enabled))
        end
    end

    OutputLogMessage("[GATHER] G9 ARMED; F=%dms; protocol=4-strobe\n",F_INTERVAL_MS)
    while receiver_active do
        local now=GetRunningTime()
        if walking_key and now>=walking_release_ms then
            ReleaseKey(walking_key)
            walking_key=nil
            walking_release_ms=-1
        end
        if last_f_press>=0 and now-last_f_press>=F_HOLD_MS then
            ReleaseKey("f");last_f_press=-1
        end
        if now-last_rx>WATCHDOG_MS then
            if f_enabled or alt_held then
                release_all()
                OutputLogMessage("[GATHER] WATCHDOG: released F/ALT\n")
            end
        end
        if now-last_rx>MAX_IDLE_MS then break end
        if phase~=0 and now-last_edge>RX_GAP_MS then phase=0 end
        local scroll=IsKeyLockOn("scrolllock")
        if scroll and not prev then
            local code=(IsKeyLockOn("capslock") and 2 or 0)+
                       (IsKeyLockOn("numlock") and 1 or 0)
            last_edge=GetRunningTime()
            if phase==0 then
                if code==3 then phase=1 end
            elseif phase==1 then
                hi=code;phase=2
            elseif phase==2 then
                lo=code;phase=3
            elseif phase==3 then
                phase=0
                local expected=(hi+2*lo+1)%4
                local value=hi*4+lo
                if code==expected and value<=14 then
                    last_rx=GetRunningTime()
                    dispatch(value)
                else
                    OutputLogMessage("[GATHER] bad frame/checksum: %d,%d,%d\n",hi,lo,code)
                end
            end
        end
        prev=scroll
        now=GetRunningTime()
        if f_enabled and not alt_held and last_f_press<0 and now-last_f>=F_INTERVAL_MS then
            PressKey("f");last_f_press=now;last_f=now
        end
        Sleep(POLL_MS)
    end
    release_all()
    OutputLogMessage("[GATHER] receiver finished\n")
end

function OnEvent(event,arg)
    if event=="MOUSE_BUTTON_PRESSED" and arg==G9 then
        receiver()
    end
end
