"""Steer using the camera cone and resource bearing; verify motion instead of counting W sends."""
from dataclasses import dataclass
import math
from minimap import angle_delta


@dataclass
class Drive:
    forward:float=0.0
    strafe:float=0.0
    yaw:float=0.0
    pitch:float=0.0
    reason:str=''


class Navigator:
    def __init__(self,cfg):
        self.cfg=cfg;self.goal=None;self.best_distance=None
        self.progress_at=None;self.last_time=None;self.last_heading=None
        self.heading_at=None;self.last_yaw=0;self.yaw_sign=cfg.get('camera_yaw_sign',1)
        self.sign_votes=0;self.excluded=[];self.recovery_until=0
        self.motion_sum=0;self.motion_samples=0;self.motion_since=None

    def pause(self,now):
        self.progress_at=now;self.motion_since=now
        self.motion_sum=0;self.motion_samples=0;self.last_yaw=0

    def exclude_goal(self,now,seconds=35):
        if self.goal:self.excluded.append([self.goal.kind,self.goal.x,self.goal.y,now+seconds])
        self.goal=None;self.best_distance=None;self.pause(now)

    def update(self,radar,now,allow_air=True):
        dt=.1 if self.last_time is None else max(.01,min(1,now-self.last_time));self.last_time=now
        self.excluded=[g for g in self.excluded if g[3]>now]
        if radar.motion_valid:
            dx,dy=radar.displacement
            for g in self.excluded:g[1]+=dx;g[2]+=dy
        candidates=[m for m in radar.markers if (allow_air or m.kind!='aether') and
                    not any(e[0]==m.kind and math.hypot(m.x-e[1],m.y-e[2])<12 for e in self.excluded)]
        if self.goal:
            dx,dy=radar.displacement if radar.motion_valid else (0,0)
            matches=[m for m in candidates if m.kind==self.goal.kind and math.hypot(m.x-self.goal.x-dx,m.y-self.goal.y-dy)<35]
            self.goal=min(matches,key=lambda m:math.hypot(m.x-self.goal.x-dx,m.y-self.goal.y-dy)) if matches else None
        if self.goal is None and candidates:
            self.goal=min(candidates,key=lambda m:m.distance)
            self.best_distance=self.goal.distance;self.progress_at=now
        heading=radar.heading
        if heading is not None:
            if self.last_heading is not None and self.heading_at is not None and abs(self.last_yaw)>.15:
                change=angle_delta(heading,self.last_heading)
                if 1<abs(change)<35:
                    vote=1 if change*self.last_yaw>0 else -1
                    self.sign_votes=max(-8,min(8,self.sign_votes+vote))
                    if abs(self.sign_votes)>=4:self.yaw_sign=1 if self.sign_votes>0 else -1
            self.last_heading=heading;self.heading_at=now
        elif self.heading_at is not None and now-self.heading_at<.7:
            heading=self.last_heading
        if now<self.recovery_until:
            remaining=self.recovery_until-now
            plan=Drive(-.35,.45,0,0,'обход застревания: назад/вбок') if remaining>.7 else Drive(0,0,.6*self.yaw_sign,0,'обход застревания: смена направления')
            self.last_yaw=plan.yaw;return plan
        if self.goal:
            goal=self.goal
            if self.best_distance is None or goal.distance<self.best_distance-1.5:
                self.best_distance=goal.distance;self.progress_at=now
            desired=math.degrees(math.atan2(goal.x-radar.center[0],radar.center[1]-goal.y))%360
            if heading is None:
                plan=Drive(0,0,.4*self.yaw_sign,0,'ищу две границы обзора перед движением к иконке')
            else:
                error=angle_delta(desired,heading)
                yaw=max(-.65,min(.65,error/65))*self.yaw_sign
                forward=.72 if abs(error)<18 else .30 if abs(error)<35 else 0
                if abs(error)>35:self.progress_at=now
                pitch=.12 if goal.kind=='aether' and goal.distance<18 else 0
                plan=Drive(forward,0,yaw,pitch,f'к {goal.name}: иконка {desired:.0f}°, камера {heading:.0f}°, ошибка {error:.0f}°')
            if self.progress_at is not None and now-self.progress_at>self.cfg.get('navigation_stall_seconds',6):
                self.exclude_goal(now);self.recovery_until=now+1.5
                return Drive(-.35,.45,0,0,'расстояние до иконки не уменьшается; меняю подход')
        else:
            # Continuous exploration between visible nodes; no 16-turn stationary loop.
            plan=Drive(.58,0,.10*self.yaw_sign,0,'патруль: движение и обзор миникарты')
        if self.motion_since is None:self.motion_since=now
        if radar.motion_valid and plan.forward>.2:
            self.motion_sum+=math.hypot(*radar.displacement);self.motion_samples+=1
        if now-self.motion_since>=3:
            if self.motion_samples>=8 and self.motion_sum<1.2 and plan.forward>.2:
                self.recovery_until=now+1.5;self.pause(now)
                return Drive(-.35,.45,0,0,'мини-карта не смещается: попытка выйти из упора')
            self.motion_since=now;self.motion_sum=0;self.motion_samples=0
        self.last_yaw=plan.yaw
        return plan
