# -*- coding: utf-8 -*-
"""AION 2 visual-only helpers, first prototype. No game memory access."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import os
import re
import cv2
import numpy as np
import pytesseract
from flight import read_flight

ROOT=Path(__file__).resolve().parent
if os.name=='nt':
    _tess=Path(r'C:\Program Files\Tesseract-OCR\tesseract.exe')
    if _tess.is_file():pytesseract.pytesseract.tesseract_cmd=str(_tess)

@dataclass
class Candidate:
    name: str
    click_x: int
    click_y: int
    confidence: float
    box: tuple

@dataclass
class Observation:
    candidate: Candidate | None
    target_name: str | None
    distance_m: float | None
    f_prompt: bool
    prompt_score: float
    gathering: bool
    flight_energy: float | None
    flight_state: str

DEFAULT_NAMES=('Эфир','Сапфир','Рубин','Алмаз')


def norm(text):
    return re.sub(r'[^а-яё]', '', text.lower().replace('e','е').replace('o','о'))


def clean_match(text, names):
    t=norm(text)
    for name in names:
        n=norm(name)
        if t==n or (len(n)>=5 and n in t and len(t)<=len(n)+3):
            return name
    return None


def color_mask(bgr):
    hsv=cv2.cvtColor(bgr,cv2.COLOR_BGR2HSV)
    # Cyan-to-green text from Russian Global UI; restrict saturation and brightness.
    lower=np.array([32,43,65],np.uint8)
    upper=np.array([96,255,255],np.uint8)
    mask=cv2.inRange(hsv,lower,upper)
    b,g,r=cv2.split(bgr.astype(np.int16))
    mask[(g<b*.97)|(g-r<18)]=0
    return mask


def _trim(mask):
    y,x=np.nonzero(mask)
    return mask[y.min():y.max()+1,x.min():x.max()+1] if len(x) else None


_name_library=None
def visual_name(mask,names):
    global _name_library
    if _name_library is None:
        _name_library=[]
        for file in (ROOT/'assets/name_masks').glob('*.png'):
            label={'ether':'Эфир','sapphire':'Сапфир'}.get(file.stem)
            image=cv2.imread(str(file),0)
            if label and image is not None:_name_library.append((label,_trim(image)))
    sample=_trim(mask)
    if sample is None:return None,0
    best=(None,0)
    for label,template in _name_library:
        if label not in names or template is None:continue
        ratio=(sample.shape[1]/sample.shape[0])/(template.shape[1]/template.shape[0])
        if not .76<ratio<1.30:continue
        a=cv2.resize(sample,(template.shape[1]*3,template.shape[0]*3))>100
        b=cv2.resize(template,(template.shape[1]*3,template.shape[0]*3))>100
        kernel=np.ones((3,3),np.uint8)
        da=cv2.dilate(a.astype('uint8'),kernel)>0;db=cv2.dilate(b.astype('uint8'),kernel)>0
        score=float(((a&db).sum()+(b&da).sum())/max(1,a.sum()+b.sum()))
        if score>best[1]:best=(label,score)
    return best if best[1]>=.86 else (None,best[1])


def local_world_candidates(frame,names):
    h,w=frame.shape[:2];scale=w/2048
    x0,y0,x1,y1=int(w*.10),int(h*.10),int(w*.80),int(h*.72)
    roi=frame[y0:y1,x0:x1];mask=color_mask(roi)
    grouped=cv2.dilate(mask,np.ones((max(1,round(scale*2)),max(2,round(scale*6))),np.uint8))
    _,_,stats,_=cv2.connectedComponentsWithStats(grouped)
    proposals=[]
    for x,y,rw,rh,area in stats[1:]:
        if not (12*scale<rw<210*scale and 5*scale<rh<35*scale and area>30*scale*scale):continue
        ax,ay=x0+x,y0+y
        above=frame[max(0,ay-round(65*scale)):max(0,ay-round(5*scale)),
                    max(0,ax-round(12*scale)):min(w,ax+rw+round(12*scale))]
        if above.size==0:continue
        ah=cv2.cvtColor(above,cv2.COLOR_BGR2HSV)
        white=cv2.inRange(ah,np.array([0,0,175]),np.array([179,90,255]))
        evidence=int(np.count_nonzero(white))
        if evidence<max(15,35*scale*scale):continue
        proposals.append((evidence,ax,ay,rw,rh))
    result=[]
    for _,x,y,rw,rh in sorted(proposals,reverse=True)[:12]:
        patch=frame[max(0,y-3):min(h,y+rh+3),max(0,x-3):min(w,x+rw+3)]
        name,score=visual_name(color_mask(patch),names)
        if name is None:
            text=pytesseract.image_to_string(cv2.resize(patch,None,fx=4,fy=4),lang='rus',config='--psm 7')
            name=clean_match(text,names);score=.85 if name else score
        if name:
            offset=max(18,round(h*.035)) if name=='Эфир' else max(18,round(h*.010))
            result.append(Candidate(name,x+rw//2,y+rh+offset,score*100,(x,y,rw,rh)))
    return result


def _text_words(mask, psm=11):
    # 255 background, dark glyphs. Upscale for Cyrillic Tesseract.
    bw=cv2.resize(255-mask,None,fx=1.55,fy=1.55,interpolation=cv2.INTER_NEAREST)
    data=pytesseract.image_to_data(bw,lang='rus',config=f'--oem 3 --psm {psm}',output_type=pytesseract.Output.DICT)
    for i,s in enumerate(data['text']):
        s=s.strip()
        if not s: continue
        try: conf=float(data['conf'][i])
        except (TypeError, ValueError): conf=-1
        if conf<35: continue
        yield (s,conf,float(data['left'][i])/1.55,float(data['top'][i])/1.55,
               float(data['width'][i])/1.55,float(data['height'][i])/1.55)


def find_world_resource(frame,names=DEFAULT_NAMES):
    """Detect cyan world name in a large scene ROI. Strict allowlist.

    MVP restriction: expects OCR to read a resource name as one contiguous token;
    the name is not itself proof of a clickable object in an obstructed scene.
    """
    h,w=frame.shape[:2]
    x0,y0,x1,y1=int(w*.12),int(h*.10),int(w*.85),int(h*.70)
    roi=frame[y0:y1,x0:x1]
    mask=color_mask(roi)
    results=[]
    for txt,conf,x,y,tw,th in _text_words(mask):
        name=clean_match(txt,names)
        if not name: continue
        cx=int(x0+x+tw*.5)
        offset=max(18,h*.035) if name=='Эфир' else max(18,h*.010)
        cy=int(y0+y+th+offset)
        # Avoid target panel region and character names when a target is highlighted.
        if cy<int(h*.12): continue
        results.append(Candidate(name,cx,cy,conf,(int(x0+x),int(y0+y),int(tw),int(th))))
    if not results:results=local_world_candidates(frame,names)
    results.sort(key=lambda c:c.confidence,reverse=True)
    return results[0] if results else None


def selected_target(frame,names=DEFAULT_NAMES):
    """Read selected resource title in the fixed TOP CENTRE overlay.
    Text-only colour segmentation fails against the teal HP bar, so use
    a narrowly cropped RGB title row + single-line Cyrillic OCR instead.
    """
    h,w=frame.shape[:2]
    if segment_count(frame) is None:return None,None
    # Crop above the actual green track, so the track cannot merge with the letters.
    band=frame[int(.035*h):int(.09*h),int(.39*w):int(.62*w)]
    bm=color_mask(band)
    solid=cv2.morphologyEx(bm,cv2.MORPH_OPEN,np.ones((1,max(8,round(w*.035))),np.uint8))
    rows=np.flatnonzero((solid>0).sum(axis=1)>w*.035)
    name_bottom=(int(.035*h)+int(rows[0])-2) if len(rows) else int(.055*h)
    name_top=max(int(.020*h),name_bottom-int(.033*h))
    a=frame[name_top:name_bottom,int(.425*w):int(.57*w)]
    if a.size==0:return None,None
    a=cv2.resize(a,None,fx=3,fy=3,interpolation=cv2.INTER_CUBIC)
    mask=color_mask(a)
    trimmed=_trim(mask)
    text=pytesseract.image_to_string(a,lang='rus',config='--oem 3 --psm 7')
    selected=None
    clean=norm(text)
    for name in names:
        if norm(name) in clean:
            selected=name
            break
    if selected is None and trimmed is not None:
        selected,_=visual_name(trimmed,names)
        if selected is None:
            text=pytesseract.image_to_string(cv2.resize(255-trimmed,None,fx=3,fy=3),lang='rus',config='--psm 7')
            selected=clean_match(text,names)
    if selected is None:
        old=frame[int(.034*h):int(.055*h),int(.45*w):int(.54*w)]
        if old.size:
            text=pytesseract.image_to_string(cv2.resize(old,None,fx=3,fy=3),lang='rus',config='--psm 7')
            clean=norm(text)
            selected=next((name for name in names if norm(name) in clean),None)
    if selected is None:return None,None
    try:
        sub=frame[int(.027*h):int(.060*h),int(.57*w):int(.595*w)]
        gray=cv2.cvtColor(sub,cv2.COLOR_BGR2GRAY)
        gray=cv2.resize(gray,None,fx=4,fy=4)
        s=pytesseract.image_to_string(gray,lang='eng+rus',config='--psm 7 -c tessedit_char_whitelist=0123456789.,mMмМ')
        if not re.search(r'\d',s):
            s=pytesseract.image_to_string(gray,lang='eng+rus',config='--psm 8 -c tessedit_char_whitelist=0123456789.,mMмМ')
        m=re.search(r'(\d{1,3})(?:[.,](\d))?\s*[мmMМ]',s)
        dist=(float(m.group(1))+float('0.'+m.group(2)) if m and m.group(2) else float(m.group(1))) if m else None
        if dist is None:
            number=re.search(r'\d{1,3}(?:[.,]\d)?',s)
            if number:dist=float(number.group().replace(',','.'))
        return selected,dist
    except Exception:return selected,None


def gathering_panel(frame):
    """Two parallel coloured horizontal bars in lower-center gather UI.
    Returns true only when both identifiable blue/cyan and orange stripes exist.
    """
    h,w=frame.shape[:2]
    region=frame[int(h*.690):int(h*.856),int(w*.345):int(w*.685)]
    if region.size==0:return False
    hsv=cv2.cvtColor(region,cv2.COLOR_BGR2HSV)
    cyan=cv2.inRange(hsv,np.array([80,45,90]),np.array([113,255,255]))
    orange=cv2.inRange(hsv,np.array([5,80,80]),np.array([29,255,255]))
    # Ignore nearby UI/buffs: require reasonably wide runs in DIFFERENT rows.
    def horizontal_rows(m):
        row=(m>0).sum(axis=1)
        return set(np.flatnonzero(row>max(55,region.shape[1]*.16)).tolist())
    cr,orr=horizontal_rows(cyan),horizontal_rows(orange)
    # A gathering attempt can have ONLY success OR failure filled, not necessarily both.
    if cr and orr:return min(abs(a-b) for a in cr for b in orr)<100
    for m in (cyan,orange):
        contours,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        for c in contours:
            x,y,rw,rh=cv2.boundingRect(c)
            if rw>max(30,w*.07) and 2<=rh<=max(10,h*.035) and rw>rh*2:
                return True
    return False


class PromptDetector:
    def __init__(self,reference=None):
        p=reference or ROOT/'assets/f_prompt_reference.png'
        self.template=cv2.imread(str(p),cv2.IMREAD_GRAYSCALE)
        if self.template is None:raise FileNotFoundError(p)
        # Cross-resolution template scale is relative to source 2558-wide video.
    def detect(self,frame):
        h,w=frame.shape[:2]
        # Searching center world instead of entire window reduces false matches.
        roi=frame[int(h*.27):int(h*.75),int(w*.33):int(w*.72)]
        gray=cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY)
        best=-1
        for f in (0.80,0.90,1.0,1.10,1.20):
            scale=f*w/2558
            if scale<.2:continue
            tpl=cv2.resize(self.template,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
            if tpl.shape[0]>=gray.shape[0] or tpl.shape[1]>=gray.shape[1]:continue
            # Edge maps reduce sensitivity to background under semi-transparent UI.
            a=cv2.Canny(gray,50,120);t=cv2.Canny(tpl,50,120)
            if np.std(t)<2:continue
            _,score,_,_=cv2.minMaxLoc(cv2.matchTemplate(a,t,cv2.TM_CCOEFF_NORMED))
            best=max(best,float(score))
        return best>=.57,round(max(0,best),3)


def flight_gauge(frame):
    reading=read_flight(frame)
    return reading.energy,('CYAN' if reading.confirmed else 'HIDDEN')


def flight_mode_hint(frame):
    """Fallback state only (not energy measurement): contextual fly controls."""
    h,w=frame.shape[:2]
    roi=frame[int(.76*h):int(.95*h),int(.79*w):int(.99*w)]
    if roi.size==0:return False
    txt=pytesseract.image_to_string(roi,lang='rus',config='--psm 11').lower()
    return 'парение' in txt and ('режим' in txt or 'пол' in txt)


class WorldVision:
    def __init__(self,names=DEFAULT_NAMES):
        self.names=names
        self.prompt=PromptDetector()
    def scan(self,frame,world=True,candidates=True):
        name,dist=selected_target(frame,self.names) if world else (None,None)
        candidate=find_world_resource(frame,self.names) if world and candidates else None
        f,score=self.prompt.detect(frame) if world and (name or candidate) else (False,0.0)
        g=gathering_panel(frame) if world else False
        e,st=flight_gauge(frame) if world else (None,'UNKNOWN')
        # Context help and cyan scenery alone do not prove that wings are open.
        return Observation(candidate,name,dist,bool(f),score,g,e,st)


def segment_count(frame):
    """Initial THREE-slot resource gauge model calibrated from t63/t276.
    Returns 1/2/3 or None. Doesn't invent count if upper panel is hidden.
    """
    h,w=frame.shape[:2]
    # A resource track has a dark horizontal frame around its green fill.
    # Green scenery/aurora in the same fixed rectangle is not a target panel.
    hud=frame[int(h*.05):int(h*.085),int(w*.405):int(w*.595)]
    if hud.size==0:return None
    hh=cv2.cvtColor(hud,cv2.COLOR_BGR2HSV)
    hm=cv2.inRange(hh,np.array([32,45,55]),np.array([95,255,255]))
    green=(hm>0).mean(axis=1)>.20
    dark=(hud.max(axis=2)<70).mean(axis=1)>.60
    margin=max(2,round(h*5/1440));framed=False
    starts=np.flatnonzero(green & ~np.r_[False,green[:-1]])
    ends=np.flatnonzero(green & ~np.r_[green[1:],False])
    for a,b in zip(starts,ends):
        if b-a+1<max(2,round(h/720)):continue
        if dark[max(0,a-margin):a].any() and dark[b+1:min(len(dark),b+1+margin)].any():
            framed=True;break
    if not framed:return None
    # Sample inside the three equal-sized coloured portions of upper HP/resource bar.
    rect=frame[int(h*84/1438):int(h*112/1438),int(w*1040/2558):int(w*1505/2558)]
    if rect.size==0:return None
    hsv=cv2.cvtColor(rect,cv2.COLOR_BGR2HSV)
    mask=cv2.inRange(hsv,np.array([32,45,55]),np.array([95,255,255]))
    scores=[]
    for i in range(3):
        tile=mask[:,round(mask.shape[1]*i/3):round(mask.shape[1]*(i+1)/3)]
        scores.append(float((tile>0).mean()))
    # Distinguish a valid 1/2/3-fill from random target bars / backgrounds.
    slots=[v>.31 for v in scores]
    if not slots[0]:return None
    if slots==[True,False,False]:return 1
    if slots==[True,True,False]:return 2
    if slots==[True,True,True]:return 3
    return None


def gather_result_full(frame):
    """For the LAST remaining segment only: cyan/orange bar reached far right.
    One matching frame is a visual clue, not an infallible game event.
    """
    h,w=frame.shape[:2]
    # Learned from original 2560x1440 footage, bars at x~1034..1605 y~1086/1129.
    x1,x2=round(w*1540/2558),round(w*1602/2558)
    y1,y2=round(h*1080/1438),round(h*1154/1438)
    a=frame[y1:y2,x1:x2]
    if a.size==0:return False
    hsv=cv2.cvtColor(a,cv2.COLOR_BGR2HSV)
    cy=cv2.inRange(hsv,np.array([80,45,90]),np.array([113,255,255]))
    orange=cv2.inRange(hsv,np.array([5,80,80]),np.array([29,255,255]))
    for mask in (cy,orange):
        if ((mask>0).sum(axis=1)>a.shape[1]*.7).sum()>=6:return True
    return False
