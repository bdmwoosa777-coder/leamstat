"""Tentative ADE20K scene labels; no navigation or game controls."""
from dataclasses import dataclass
import cv2
import numpy as np

GROUND={'floor','road','grass','sidewalk','earth','field','sand','path','runway','dirt track'}
SOLID={'wall','building','tree','ceiling','windowpane','door','mountain','plant','house',
       'fence','rock','railing','column','stairs','stairway','step','bridge','tower',
       'vehicle','car','truck','bus','person','animal'}
WATER={'water','sea','river','swimming pool','lake','waterfall'}
# BGR: these are observations, never a certified walkable route.
PALETTE=np.array([[0,0,0],[55,175,60],[45,70,235],[225,130,35],[190,175,65]],np.uint8)
GROUP_NAMES=('unknown','ground_candidate','obstacle_or_structure','water','sky')


@dataclass
class Scene:
    labels:np.ndarray
    confidence:np.ndarray
    groups:np.ndarray
    boundary:np.ndarray
    summary:dict


def world_mask(shape,hide_hud=True):
    h,w=shape[:2];mask=np.ones((h,w),bool)
    if hide_hud:
        for x0,y0,x1,y1 in ((0,0,1,.105),(0,0,.34,.23),(.81,0,1,.44),
                             (0,.70,.34,1),(.24,.835,.81,1),(.88,.80,1,1)):
            mask[round(y0*h):round(y1*h),round(x0*w):round(x1*w)]=False
    return mask


def interpret(labels,confidence,id2label,threshold=.55,hide_hud=True):
    if labels.ndim!=2 or labels.shape!=confidence.shape:raise ValueError('Invalid segmentation shape')
    if not np.isfinite(confidence).all():raise ValueError('Non-finite confidence')
    valid=world_mask(labels.shape,hide_hud)&(confidence>=threshold)
    groups=np.zeros(labels.shape,np.uint8)
    for key,name in id2label.items():
        # ADE names sometimes contain synonyms; the pinned configuration is
        # retained in the model manifest to make this grouping inspectable.
        names={n.strip().casefold() for n in name.split(';')}
        group=1 if names&GROUND else 2 if names&SOLID else 3 if names&WATER else 4 if 'sky' in names else 0
        if group:groups[(labels==int(key))&valid]=group
    ground=(groups==1).astype(np.uint8)
    nearby_air_water=((groups==3)|(groups==4)).astype(np.uint8)
    boundary=(cv2.dilate(ground,np.ones((5,5),np.uint8))&cv2.dilate(nearby_air_water,np.ones((5,5),np.uint8))).astype(bool)
    boundary[:round(labels.shape[0]*.35)]=False
    h,w=labels.shape;sectors={}
    # Fractions describe appearance only. They do not claim bridge load-bearing
    # surfaces, clearance, distance, elevation, or connectivity to the player.
    for name,left,right in (('left',.18,.40),('center',.40,.62),('right',.62,.80)):
        cut=groups[round(h*.45):round(h*.82),round(w*left):round(w*right)]
        sectors[name]={'ground_fraction':float(np.mean(cut==1)),
                       'obstacle_fraction':float(np.mean(cut==2)),
                       'water_fraction':float(np.mean(cut==3)),
                       'unknown_fraction':float(np.mean(cut==0))}
    denominator=max(1,int(world_mask(labels.shape,hide_hud).sum()))
    summary={'threshold':threshold,'tentative_only':True,'path_certified':False,
             'groups':{name:float(np.count_nonzero(groups==i)/denominator) for i,name in enumerate(GROUP_NAMES) if i},
             'sectors':sectors,'ground_air_water_boundary_pixels':int(boundary.sum())}
    return Scene(labels,confidence,groups,boundary,summary)


def overlay(frame,scene,opacity=.43):
    if frame.shape[:2]!=scene.groups.shape:raise ValueError('Frame and scene dimensions differ')
    result=frame.copy();known=scene.groups>0
    colors=PALETTE[scene.groups]
    blend=cv2.addWeighted(frame,1-opacity,colors,opacity,0)
    result[known]=blend[known]
    result[scene.boundary]=(30,220,255)
    return result
