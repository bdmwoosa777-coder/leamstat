import unittest,tempfile,json
from pathlib import Path
from unittest.mock import patch
from types import SimpleNamespace
from zipfile import ZipFile
import numpy as np
from depth import DepthRunner,inspect_depth
from samples import SampleStore
from scene import interpret
import launch_setup

class DepthTests(unittest.TestCase):
 def test_flat_depth_never_invents_edge_or_metric_height(self):
  d,e,v,m=inspect_depth(np.ones((100,200),np.float32),(200,400,3))
  self.assertFalse(e.any());self.assertFalse(m['usable_contrast']);self.assertIsNone(m['metric_height_m']);self.assertIsNone(m['fall_detected'])
 def test_near_below_far_above_creates_candidate_without_declaring_fall(self):
  a=np.zeros((100,200),np.float32);a[50:]=10
  d,e,v,m=inspect_depth(a,(100,200,3))
  self.assertTrue(e[48:53,40:70].any());self.assertFalse(m['path_certified']);self.assertIsNone(m['fall_detected'])
 def test_reverse_step_not_labeled_as_forward_drop(self):
  a=np.zeros((100,200),np.float32);a[:50]=10
  self.assertFalse(inspect_depth(a,(100,200,3))[1].any())
 def test_avatar_and_hud_edges_excluded(self):
  a=np.zeros((100,200),np.float32);a[50:]=10
  e=inspect_depth(a,(100,200,3))[1]
  self.assertFalse(e[:,90:110].any());self.assertFalse(e[:25].any())
 def test_invalid_depth_rejected(self):
  with self.assertRaises(ValueError):inspect_depth(np.full((20,30),np.nan),(20,30,3))
 def test_actual_fp16_model_works_without_extended_fusion(self):
  r=DepthRunner(cpu=True);a,ms=r.predict(np.full((180,320,3),80,np.uint8))
  self.assertEqual(a.shape,(294,518));self.assertTrue(np.isfinite(a).all());self.assertGreater(ms,0)
 def test_depth_saved_and_parts_are_independent_zip_files(self):
  with tempfile.TemporaryDirectory() as t:
   store=SampleStore(Path(t)/'samples');frame=np.zeros((50,100,3),np.uint8)
   scene=interpret(np.zeros((50,100),np.uint8),np.ones((50,100),np.float32),{'0':'wall'})
   for _ in range(2):store.save(frame,frame,scene,{},depth=np.zeros((30,40),np.float32),depth_view=frame,edge_view=frame)
   parts=store.export_parts(budget=14000);self.assertGreater(len(parts),1)
   names=[]
   for p in parts:
    self.assertLess(p.stat().st_size,14000)
    with ZipFile(p) as z:self.assertIsNone(z.testzip());names+=z.namelist()
   self.assertEqual(len(names),16);self.assertEqual(sum(n.endswith('depth_raw.npy') for n in names),2)
 def test_empty_export_reports_missing_examples(self):
  with tempfile.TemporaryDirectory() as t:
   with self.assertRaises(ValueError):SampleStore(t).export_parts()

class LauncherTests(unittest.TestCase):
 def result(self,version,exe='python.exe'):return SimpleNamespace(returncode=0,stdout=json.dumps({'version':version,'bits':64,'exe':exe}))
 def test_manager_success_code_without_runtime_is_rejected(self):
  with patch('launch_setup.subprocess.run',return_value=SimpleNamespace(returncode=0,stdout='No runtime installed')):
   self.assertIsNone(launch_setup.probe(['py','-3.12']))
 def test_unsupported_python_314_is_rejected(self):
  with patch('launch_setup.subprocess.run',return_value=self.result([3,14])):
   self.assertIsNone(launch_setup.probe(['py','-3']))
 def test_installed_312_uses_actual_executable(self):
  with patch('launch_setup.subprocess.run',return_value=self.result([3,12])),patch('launch_setup.Path.is_file',return_value=True):
   self.assertEqual(launch_setup.probe(['py','-3.12']),'python.exe')

if __name__=='__main__':unittest.main()
