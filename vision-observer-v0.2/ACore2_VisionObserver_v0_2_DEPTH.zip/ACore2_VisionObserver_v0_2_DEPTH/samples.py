"""User-requested local examples. No uploads or network calls."""
from datetime import datetime
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,os,threading,uuid
import cv2
import numpy as np

ROOT=Path(__file__).resolve().parent


def write_image(path,image,extension='.png',quality=95):
    parameters=[cv2.IMWRITE_JPEG_QUALITY,quality] if extension=='.jpg' else []
    ok,data=cv2.imencode(extension,image,parameters)
    if not ok:raise OSError('Не удалось закодировать изображение')
    path.write_bytes(data.tobytes())


class SampleStore:
    def __init__(self,folder=None):
        self.folder=Path(folder or ROOT/'samples');self.lock=threading.Lock()
    def save(self,frame,overlay,scene,metadata,depth=None,depth_view=None,edge_view=None):
        self.folder.mkdir(parents=True,exist_ok=True)
        name=datetime.now().strftime('%Y%m%d_%H%M%S_')+uuid.uuid4().hex[:6]
        temporary=self.folder/('.writing_'+name);destination=self.folder/name
        with self.lock:
            temporary.mkdir()
            try:
                write_image(temporary/'frame.jpg',frame,'.jpg')
                write_image(temporary/'overlay.jpg',overlay,'.jpg',quality=88)
                write_image(temporary/'classes.png',scene.labels)
                write_image(temporary/'confidence.png',np.round(np.clip(scene.confidence,0,1)*255).astype(np.uint8))
                (temporary/'summary.json').write_text(json.dumps({**metadata,'scene':scene.summary},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                if depth is not None:
                    np.save(temporary/'depth_raw.npy',depth,allow_pickle=False)
                    write_image(temporary/'depth.jpg',depth_view,'.jpg',quality=90)
                    write_image(temporary/'edges.jpg',edge_view,'.jpg',quality=90)
                temporary.rename(destination)
            except Exception:
                import shutil
                shutil.rmtree(temporary,ignore_errors=True);raise
        return destination
    def export(self):
        self.folder.mkdir(parents=True,exist_ok=True)
        destination=self.folder.parent/('vision_examples_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]+'.zip')
        with self.lock,ZipFile(destination,'w',ZIP_DEFLATED,compresslevel=5) as archive:
            for directory in sorted(self.folder.iterdir()):
                if directory.is_symlink() or not directory.is_dir() or directory.name.startswith('.'):continue
                for name in ('frame.jpg','overlay.jpg','classes.png','confidence.png','summary.json','depth_raw.npy','depth.jpg','edges.jpg'):
                    path=directory/name
                    if path.is_file() and not path.is_symlink():archive.write(path,directory.name+'/'+name)
        return destination

    def export_parts(self,budget=23*1024*1024):
        """Independent ZIPs below the upload limit, without 7z/multipart tools."""
        self.folder.mkdir(parents=True,exist_ok=True)
        stamp=datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]
        names=('frame.jpg','overlay.jpg','classes.png','confidence.png','summary.json','depth_raw.npy','depth.jpg','edges.jpg')
        with self.lock:
            files=[]
            for directory in sorted(self.folder.iterdir()):
                if directory.is_symlink() or not directory.is_dir() or directory.name.startswith('.'):continue
                for name in names:
                    p=directory/name
                    if p.is_file() and not p.is_symlink():files.append(p)
            if not files:raise ValueError('Сначала сохраните примеры')
            if any(p.stat().st_size+4096>budget for p in files):raise ValueError('Один файл слишком велик для части архива')
            paths=[];archive=None;size=0
            try:
                for p in files:
                    cost=p.stat().st_size+4096
                    if archive is None or size+cost>budget:
                        if archive is not None:archive.close()
                        path=self.folder.parent/f'vision_examples_{stamp}_{len(paths)+1:02d}.zip'
                        archive=ZipFile(path,'w',ZIP_DEFLATED,compresslevel=5);paths.append(path);size=0
                    archive.write(p,p.relative_to(self.folder));size+=cost
            finally:
                if archive is not None:archive.close()
        return paths
