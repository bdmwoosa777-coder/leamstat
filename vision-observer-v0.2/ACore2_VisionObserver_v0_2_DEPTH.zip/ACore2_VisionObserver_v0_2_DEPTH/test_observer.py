import hashlib,json,queue,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from zipfile import ZipFile
import cv2,numpy as np
import model_runner,observer,win_capture
from model_runner import SegmentationRunner
from scene import interpret,overlay,world_mask
from samples import SampleStore

LABELS={'0':'wall','1':'grass','2':'water','3':'sky','4':'bridge','5':'unknown'}


class SceneTests(unittest.TestCase):
    def test_ground_is_tentative_not_certified(self):
        s=interpret(np.ones((100,200),np.uint8),np.ones((100,200),np.float32),LABELS,hide_hud=False)
        self.assertTrue((s.groups==1).all());self.assertFalse(s.summary['path_certified'])
        self.assertTrue(s.summary['tentative_only'])
    def test_low_confidence_and_unknown_classes_do_not_become_ground(self):
        labels=np.ones((10,10),np.uint8);confidence=np.full((10,10),.2,np.float32)
        self.assertFalse(interpret(labels,confidence,LABELS,hide_hud=False).groups.any())
        self.assertFalse(interpret(labels*5,np.ones_like(confidence),LABELS,hide_hud=False).groups.any())
    def test_water_and_structures_remain_distinct(self):
        labels=np.array([[0,1,2,3,4]],np.uint8);s=interpret(labels,np.ones_like(labels),LABELS,hide_hud=False)
        self.assertEqual(s.groups.tolist(),[[2,1,3,4,2]])
    def test_hud_is_excluded_from_ground_scores_and_overlay(self):
        labels=np.ones((100,200),np.uint8);s=interpret(labels,np.ones_like(labels),LABELS)
        self.assertFalse(s.groups[10,180]);self.assertEqual(s.groups[50,60],1)
        f=np.full((100,200,3),80,np.uint8);out=overlay(f,s)
        self.assertTrue(np.array_equal(out[10,180],f[10,180]))
    def test_only_ground_sky_or_water_transition_is_yellow_hint(self):
        labels=np.ones((100,100),np.uint8);labels[50:,50:]=2
        s=interpret(labels,np.ones_like(labels),LABELS,hide_hud=False)
        self.assertTrue(s.boundary[70,49]);self.assertFalse(s.boundary[30,30])
    def test_nonfinite_output_and_wrong_dimensions_are_rejected(self):
        for confidence in (np.full((2,2),np.nan),np.ones((1,2))):
            with self.assertRaises(ValueError):interpret(np.ones((2,2)),confidence,LABELS)


class StorageTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        self.store=SampleStore(Path(self.temp.name)/'samples')
        self.frame=np.full((80,120,3),80,np.uint8)
        self.scene=interpret(np.ones((80,120),np.uint8),np.ones((80,120),np.float32),LABELS)
    def test_image_masks_and_metadata_round_trip(self):
        p=self.store.save(self.frame,overlay(self.frame,self.scene),self.scene,{'controls_game':False})
        self.assertEqual({f.name for f in p.iterdir()},{'frame.jpg','overlay.jpg','classes.png','confidence.png','summary.json'})
        self.assertTrue(np.array_equal(cv2.imread(str(p/'classes.png'),0),self.scene.labels))
        self.assertFalse(json.loads((p/'summary.json').read_text())['controls_game'])
    def test_export_only_completed_examples_not_logs_or_temp_files(self):
        self.store.save(self.frame,self.frame,self.scene,{})
        (self.store.folder/'observer.log').write_text('private unrelated log')
        (self.store.folder/'.writing_partial').mkdir();(self.store.folder/'.writing_partial/frame.png').write_bytes(b'partial')
        with ZipFile(self.store.export()) as z:
            self.assertEqual(len(z.namelist()),5);self.assertFalse(any('observer.log' in n or 'partial' in n for n in z.namelist()))
    def test_repeated_saves_and_exports_do_not_overwrite(self):
        a=self.store.save(self.frame,self.frame,self.scene,{});b=self.store.save(self.frame,self.frame,self.scene,{})
        self.assertNotEqual(a,b);self.assertNotEqual(self.store.export(),self.store.export())
    def test_failed_write_has_no_published_partial_example(self):
        with patch('samples.write_image',side_effect=OSError('disk full')):
            with self.assertRaises(OSError):self.store.save(self.frame,self.frame,self.scene,{})
        self.assertFalse(list(self.store.folder.iterdir()))


class CaptureTests(unittest.TestCase):
    def test_plain_game_quick_slot_never_triggers_observer_shortcut(self):
        with patch.object(win_capture,'pressed',side_effect=lambda vk:vk==0x75):
            self.assertEqual(win_capture.shortcut_edges({}),[])
    def test_modified_shortcut_has_one_edge_and_requires_game_focus(self):
        previous={}
        with patch.object(win_capture,'pressed',side_effect=lambda vk:vk in (0x11,0x12,0x75)):
            self.assertEqual(win_capture.shortcut_edges(previous),[0x75])
            self.assertEqual(win_capture.shortcut_edges(previous),[])
            self.assertEqual(win_capture.shortcut_edges({},active=False),[])
    def capture(self,focus=(7,7),black=False):
        class User:
            def __init__(self):self.states=iter(focus)
            def GetForegroundWindow(self):return next(self.states)
            def IsIconic(self,hwnd):return False
            def GetClientRect(self,hwnd,rect):rect._obj.right=640;rect._obj.bottom=360;return True
            def ClientToScreen(self,hwnd,point):point._obj.x=-50;point._obj.y=20;return True
        raw=np.zeros((360,640,4),np.uint8) if black else np.full((360,640,4),100,np.uint8)
        screen=SimpleNamespace(grab=lambda area:raw,close=lambda:None)
        with patch.object(win_capture,'_user32',return_value=User()),patch('mss.mss',return_value=screen):
            return win_capture.WindowCapture(win_capture.Window(7,'AION2'))
    def test_other_foreground_window_cannot_be_captured(self):
        capture=self.capture((8,));capture.mss.grab=lambda area:self.fail('captured another application')
        with self.assertRaises(win_capture.PausedCapture):capture.grab()
    def test_switch_after_capture_discards_frame(self):
        with self.assertRaises(win_capture.PausedCapture):self.capture((7,8)).grab()
    def test_client_area_capture_returns_bgr_only(self):
        self.assertEqual(self.capture().grab().shape,(360,640,3))
    def test_black_capture_is_not_sent_to_model(self):
        with self.assertRaises(win_capture.PausedCapture):self.capture(black=True).grab()


class FakeRunner:
    def __init__(self,*args):
        self.id2label=LABELS;self.backend='FAKE';self.manifest={'source':'test','revision':'test'}
    def predict(self,frame):return np.ones(frame.shape[:2],np.uint8),np.ones(frame.shape[:2],np.float32),1


class WorkerTests(unittest.TestCase):
    def make(self):
        self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
        output=queue.Queue(maxsize=1);events=queue.Queue()
        w=observer.Worker('image','test.png',output,events,dict(device_id=0,cpu=True),SampleStore(self.temp.name))
        return w,output,events
    def run_worker(self,w):
        with patch.object(observer,'SegmentationRunner',FakeRunner),patch.object(observer,'read_image',return_value=np.zeros((80,120,3),np.uint8)):w.run()
    def test_one_image_replaces_old_queued_result_and_finishes(self):
        w,out,events=self.make();out.put('stale');self.run_worker(w)
        result=out.get_nowait();self.assertIsInstance(result,observer.Result)
        self.assertFalse(result.metadata['controls_game']);self.assertFalse(w.is_alive())
        self.assertTrue(any(k=='finished' for k,v in list(events.queue)))
    def test_auto_save_stops_at_sixty_per_session(self):
        w,out,events=self.make();w.saved=60;w.auto.set();self.run_worker(w)
        self.assertFalse(w.auto.is_set());self.assertFalse(list(w.store.folder.glob('*/summary.json')))
    def test_inference_error_is_visible_and_thread_finishes(self):
        w,out,events=self.make()
        with self.assertLogs(level='ERROR'),patch.object(observer,'SegmentationRunner',side_effect=RuntimeError('test failure')):w.run()
        self.assertEqual([k for k,v in list(events.queue)][-2:],['error','finished'])


class ModelTests(unittest.TestCase):
    def test_rgb_normalization_and_output_alignment(self):
        runner=SegmentationRunner.__new__(SegmentationRunner);runner.mean=np.zeros((1,1,3),np.float32);runner.std=np.ones((1,1,3),np.float32)
        runner.id2label={'0':'wall','1':'grass'};runner.size=2;seen=[]
        def run(names,inputs):
            seen.append(inputs['pixel_values']);logits=np.zeros((1,2,2,2),np.float32);logits[:,1]=10;return [logits]
        runner.session=SimpleNamespace(run=run)
        frame=np.full((10,20,3),(30,60,90),np.uint8);labels,confidence,latency=runner.predict(frame)
        self.assertEqual(labels.shape,(10,20));self.assertTrue((labels==1).all());self.assertTrue((confidence>.99).all())
        np.testing.assert_allclose(seen[0][0,:,0,0],[90/255,60/255,30/255],atol=1e-6)
    def test_corrupted_model_is_rejected_before_session_creation(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory);(root/'models').mkdir();(root/'models/model.onnx').write_bytes(b'corrupt')
            (root/'models/model.json').write_text(json.dumps({'file':'model.onnx','sha256':'0'*64}))
            with patch.object(model_runner,'ROOT',root),patch('onnxruntime.InferenceSession') as session:
                with self.assertRaises(RuntimeError):SegmentationRunner(cpu=True)
                session.assert_not_called()
    def test_packaged_graph_and_real_inference(self):
        runner=SegmentationRunner(cpu=True)
        labels,confidence,latency=runner.predict(np.full((90,160,3),(70,100,140),np.uint8))
        self.assertEqual(labels.shape,(90,160));self.assertTrue(np.isfinite(confidence).all())
        self.assertGreaterEqual(float(confidence.min()),0);self.assertLessEqual(float(confidence.max()),1)


if __name__=='__main__':unittest.main()
