"""ACore2 Vision Observer 0.1: a read-only local model evaluation tool."""
from pathlib import Path
from dataclasses import dataclass
import argparse,json,logging,os,queue,threading,time,traceback
import cv2
import numpy as np
from model_runner import SegmentationRunner
from scene import interpret,overlay
from depth import DepthRunner,inspect_depth
from samples import SampleStore
from win_capture import WindowCapture,PausedCapture,windows,adapters,shortcut_edges

ROOT=Path(__file__).resolve().parent
cv2.setNumThreads(2)


@dataclass
class Result:
    frame:object
    overlay:object
    scene:object
    metadata:dict
    created:float
    depth:object=None
    depth_view:object=None
    edge_view:object=None


def analyze(runner,frame,threshold=.55,hide_hud=True,source='image',position=None):
    captured_unix=time.time();captured_at=time.monotonic()
    labels,confidence,latency=runner.predict(frame)
    scene=interpret(labels,confidence,runner.id2label,threshold,hide_hud)
    meta=dict(version='0.2',model=runner.manifest['source'],model_revision=runner.manifest['revision'],
              backend=runner.backend,inference_ms=round(latency,2),source=source,video_seconds=position,
              frame_size=[frame.shape[1],frame.shape[0]],captured_unix=captured_unix,
              controls_game=False,classes_legend=runner.id2label)
    result=Result(frame,overlay(frame,scene),scene,meta,captured_at)
    depth_runner=getattr(runner,'depth_runner',None)
    if depth_runner is not None:
        raw,depth_ms=depth_runner.predict(frame)
        depth,edges,view,info=inspect_depth(raw,frame.shape)
        result.depth=raw;result.depth_view=view;result.edge_view=frame.copy()
        result.edge_view[cv2.dilate(edges.astype(np.uint8),np.ones((3,3),np.uint8))>0]=(220,30,240)
        result.metadata.update(depth=info,depth_ms=round(depth_ms,2),depth_backend=depth_runner.backend,depth_model=depth_runner.manifest,
                               total_ms=round((time.monotonic()-captured_at)*1000,2))
    return result


def read_image(path):
    frame=cv2.imdecode(np.frombuffer(Path(path).read_bytes(),np.uint8),cv2.IMREAD_COLOR)
    if frame is None:raise ValueError('Не удалось прочитать изображение')
    return frame


class Worker(threading.Thread):
    def __init__(self,kind,source,output,events,settings,store):
        super().__init__(daemon=True);self.kind=kind;self.source=source;self.output=output;self.events=events
        self.settings=settings;self.store=store;self.stop=threading.Event();self.paused=threading.Event()
        self.auto=threading.Event();self.saved=0;self.last_save=0;self.last_status=None
    def status(self,message):
        if message!=self.last_status:self.events.put(('status',message));self.last_status=message
    def run(self):
        capture=None;video=None
        try:
            self.status('Загружаю локальную модель…')
            runner=SegmentationRunner(self.settings['device_id'],self.settings['cpu'],lambda m:self.events.put(('log',m)))
            runner.depth_runner=DepthRunner(self.settings['device_id'],self.settings['cpu'],lambda m:self.events.put(('log',m)))
            if self.kind=='live':capture=WindowCapture(self.source)
            elif self.kind=='video':
                video=cv2.VideoCapture(str(self.source))
                if not video.isOpened():raise ValueError('Не удалось открыть видео')
            next_at=0;video_at=0
            while not self.stop.is_set():
                if self.paused.is_set():self.status('Наблюдение приостановлено');self.stop.wait(.1);continue
                if time.monotonic()<next_at:self.stop.wait(min(.1,next_at-time.monotonic()));continue
                started=time.monotonic();position=None
                if self.kind=='live':
                    try:frame=capture.grab()
                    except PausedCapture as exc:self.status(str(exc));self.stop.wait(.15);continue
                elif self.kind=='image':frame=read_image(self.source)
                else:
                    video.set(cv2.CAP_PROP_POS_MSEC,video_at*1000);ok,frame=video.read()
                    if not ok:self.status('Видео закончилось');break
                    position=video_at;video_at+=1
                threshold=float(self.settings.get('threshold',.55))
                result=analyze(runner,frame,threshold,self.settings.get('hide_hud',True),self.kind,position)
                if self.stop.is_set():break
                # Keep only the newest result. Slow UI rendering cannot queue
                # seconds of old game frames behind the player.
                while True:
                    try:self.output.put_nowait(result);break
                    except queue.Full:
                        try:self.output.get_nowait()
                        except queue.Empty:pass
                self.status(f'Наблюдение: {runner.backend}; нейросеть {result.metadata.get("total_ms",result.metadata["inference_ms"]):.0f} мс; управление выключено')
                if self.auto.is_set() and time.monotonic()-self.last_save>=2:
                    if self.saved>=60:
                        self.auto.clear();self.events.put(('auto_done','Автосохранение остановлено: 60 примеров за сеанс'))
                    else:
                        path=self.store.save(result.frame,result.overlay,result.scene,result.metadata,depth=result.depth,depth_view=result.depth_view,edge_view=result.edge_view)
                        self.saved+=1;self.last_save=time.monotonic();self.events.put(('log','Сохранён пример: '+path.name))
                if self.kind=='image':self.status('Изображение обработано; его можно сохранить');break
                next_at=started+.5
        except Exception as exc:
            logging.exception('Observer worker failed');self.events.put(('error',str(exc)))
        finally:
            if capture is not None:capture.close()
            if video is not None:video.release()
            self.events.put(('finished',self))


class Application:
    def __init__(self,root):
        import tkinter as tk
        from tkinter import ttk
        from tkinter import font
        for name in ('TkDefaultFont','TkTextFont','TkMenuFont','TkHeadingFont'):
            font.nametofont(name).configure(family='Segoe UI' if os.name=='nt' else 'DejaVu Sans',size=10)
        self.tk=tk;self.ttk=ttk;self.root=root;root.title('ACore2 — ИИ-зрение, тест 0.2 (без управления)')
        root.geometry('1160x840');root.minsize(850,640)
        self.worker=None;self.latest=None;self.output=queue.Queue(maxsize=1);self.events=queue.Queue()
        self.store=SampleStore();self.key_states={};self.image_ref=None;self.window_list=[]
        self.cpu=tk.BooleanVar(value=False);self.auto=tk.BooleanVar(value=False);self.hide_hud=tk.BooleanVar(value=True)
        self.threshold=tk.DoubleVar(value=.55);self.preview=tk.StringVar(value='Перепады глубины')
        self.status=tk.StringVar(value='Выбери окно игры и нажми «Наблюдать». Бот для теста не нужен.')
        self.detail=tk.StringVar(value='');self.age=tk.StringVar(value='Кадров пока нет')
        self.gpus=[]
        try:self.gpus=adapters()
        except Exception:logging.exception('DXGI enumeration failed')
        if not self.gpus:self.gpus=[dict(id=0,name='Адаптер 0 (авто)',vram_gb=0,vendor=0)]
        bar=ttk.Frame(root,padding=8);bar.pack(fill='x')
        ttk.Label(bar,text='Окно AION2:').pack(side='left')
        self.window_combo=ttk.Combobox(bar,state='readonly',width=42);self.window_combo.pack(side='left',padx=5)
        ttk.Button(bar,text='Обновить',command=self.refresh_windows).pack(side='left')
        ttk.Button(bar,text='Наблюдать',command=self.start_live).pack(side='left',padx=5)
        ttk.Button(bar,text='Пауза / продолжить',command=self.pause).pack(side='left')
        ttk.Button(bar,text='Стоп',command=self.stop).pack(side='left',padx=5)
        options=ttk.Frame(root,padding=(8,0));options.pack(fill='x')
        ttk.Label(options,text='Видеокарта:').pack(side='left')
        self.gpu_combo=ttk.Combobox(options,state='readonly',width=37,values=[f'{g["id"]}: {g["name"]} ({g["vram_gb"]} ГБ)' for g in self.gpus]);self.gpu_combo.pack(side='left',padx=5)
        selected=next((i for i,g in enumerate(self.gpus) if '4080' in g['name']),next((i for i,g in enumerate(self.gpus) if g['vendor']==0x10de),0));self.gpu_combo.current(selected)
        ttk.Checkbutton(options,text='CPU вместо GPU',variable=self.cpu).pack(side='left',padx=4)
        ttk.Checkbutton(options,text='Не подсвечивать HUD',variable=self.hide_hud).pack(side='left',padx=4)
        ttk.Label(options,text='Порог:').pack(side='left');ttk.Spinbox(options,from_=.35,to=.90,increment=.05,textvariable=self.threshold,width=5).pack(side='left')
        files=ttk.Frame(root,padding=8);files.pack(fill='x')
        ttk.Button(files,text='Открыть скриншот',command=lambda:self.open_file('image')).pack(side='left')
        ttk.Button(files,text='Открыть видео',command=lambda:self.open_file('video')).pack(side='left',padx=5)
        ttk.Button(files,text='Сохранить пример',command=self.save).pack(side='left')
        ttk.Checkbutton(files,text='Сохранять каждые 2 с',variable=self.auto,command=self.sync_auto).pack(side='left',padx=5)
        ttk.Button(files,text='Собрать примеры.zip',command=self.export).pack(side='left')
        ttk.Button(files,text='Папка',command=self.open_folder).pack(side='left',padx=5)
        ttk.Label(root,text='В игре: Ctrl+Alt+F6 — сохранить; Ctrl+Alt+F7 — автосохранение; Ctrl+Alt+F10 — пауза.',padding=(8,0)).pack(fill='x')
        ttk.Label(root,text='Перепады глубины: фиолетовые линии — возможный резкий переход. Режим «Глубина»: светлее — ближе.',padding=(8,0)).pack(fill='x')
        legend=ttk.Frame(root,padding=(8,0));legend.pack(fill='x')
        for text,color in [('Зелёный: похоже на землю','#238335'),('Красный: преграда/строение','#cf3535'),('Синий: вода','#2768a0'),('Жёлтая линия: граница с небом/водой','#9a7800')]:
            ttk.Label(legend,text=text,foreground=color).pack(side='left',padx=(0,12))
        ttk.Label(root,text='Подсветка экспериментальная: зелёный цвет НЕ доказывает безопасный проход. Край скалы может быть пропущен.',padding=(8,5)).pack(fill='x')
        self.canvas=tk.Canvas(root,background='#171b22',highlightthickness=0);self.canvas.pack(fill='both',expand=True,padx=8)
        self.canvas.bind('<Configure>',lambda event:self.draw())
        bottom=ttk.Frame(root,padding=8);bottom.pack(fill='x')
        choice=ttk.Combobox(bottom,textvariable=self.preview,values=['Перепады глубины','Глубина','Подсветка','Оригинал'],state='readonly',width=22);choice.pack(side='left');choice.bind('<<ComboboxSelected>>',lambda event:self.draw())
        ttk.Label(bottom,textvariable=self.age).pack(side='left',padx=10)
        ttk.Label(root,textvariable=self.detail,padding=(8,0),wraplength=1120).pack(fill='x')
        ttk.Label(root,textvariable=self.status,padding=8,wraplength=1120).pack(fill='x')
        self.refresh_windows();root.protocol('WM_DELETE_WINDOW',self.close);root.after(100,self.poll)
    def refresh_windows(self):
        try:self.window_list=windows()
        except Exception as exc:self.status.set(str(exc));self.window_list=[]
        self.window_combo['values']=[w.title for w in self.window_list]
        if self.window_list:self.window_combo.current(0)
    def start_live(self):
        index=self.window_combo.current()
        if index<0 or index>=len(self.window_list):self.status.set('Окно AION2 не найдено. Открой игру и нажми «Обновить».');return
        self.start('live',self.window_list[index])
    def start(self,kind,source):
        if self.worker is not None and self.worker.is_alive():
            self.status.set('Сначала нажми «Стоп» и дождись завершения текущего просмотра.');return
        try:threshold=float(self.threshold.get())
        except Exception:self.status.set('Порог должен быть числом от 0.35 до 0.90');return
        if not .35<=threshold<=.90:self.status.set('Порог должен быть от 0.35 до 0.90');return
        settings=dict(device_id=self.gpus[self.gpu_combo.current()]['id'],cpu=self.cpu.get(),threshold=threshold,hide_hud=self.hide_hud.get())
        self.worker=Worker(kind,source,self.output,self.events,settings,self.store)
        self.sync_auto();self.worker.start();self.status.set('Запуск. Для живого просмотра переключись в AION2.')
    def open_file(self,kind):
        from tkinter import filedialog
        path=filedialog.askopenfilename(title='Открыть '+('скриншот' if kind=='image' else 'видео'),filetypes=[('Изображения','*.png *.jpg *.jpeg *.bmp')] if kind=='image' else [('Видео','*.mp4 *.mkv *.avi *.mov')])
        if path:self.start(kind,path)
    def pause(self):
        if self.worker is None:return
        if self.worker.paused.is_set():self.worker.paused.clear()
        else:self.worker.paused.set()
    def stop(self):
        if self.worker is not None:self.worker.stop.set();self.status.set('Останавливаю наблюдение…')
    def sync_auto(self):
        if self.worker is not None:
            if self.auto.get():self.worker.auto.set()
            else:self.worker.auto.clear()
    def save(self):
        result=self.latest
        if result is None:self.status.set('Сначала дождись обработанного кадра');return
        def work():
            try:
                path=self.store.save(result.frame,result.overlay,result.scene,result.metadata,depth=result.depth,depth_view=result.depth_view,edge_view=result.edge_view)
                self.events.put(('log','Пример сохранён: '+str(path)))
            except Exception as exc:logging.exception('Save failed');self.events.put(('error',str(exc)))
        threading.Thread(target=work,daemon=True).start()
    def export(self):
        def work():
            try:
                paths=self.store.export_parts()
                self.events.put(('log',f'Готово архивов: {len(paths)}; первый: {paths[0]}. Части до 23 МБ, все самостоятельные ZIP.'))
            except Exception as exc:self.events.put(('error',str(exc)))
        threading.Thread(target=work,daemon=True).start()
    def open_folder(self):
        self.store.folder.mkdir(parents=True,exist_ok=True)
        if os.name=='nt':os.startfile(self.store.folder)
        else:self.status.set(str(self.store.folder))
    def draw(self):
        if self.latest is None:return
        from PIL import Image,ImageTk
        choices={'Оригинал':self.latest.frame,'Подсветка':self.latest.overlay,'Глубина':self.latest.depth_view,'Перепады глубины':self.latest.edge_view}
        frame=choices.get(self.preview.get())
        if frame is None:frame=self.latest.overlay
        h,w=frame.shape[:2];width=max(1,self.canvas.winfo_width());height=max(1,self.canvas.winfo_height())
        scale=min(width/w,height/h);size=(max(1,int(w*scale)),max(1,int(h*scale)))
        rgb=cv2.cvtColor(cv2.resize(frame,size,interpolation=cv2.INTER_AREA),cv2.COLOR_BGR2RGB)
        self.image_ref=ImageTk.PhotoImage(Image.fromarray(rgb));self.canvas.delete('all')
        self.canvas.create_image(width//2,height//2,image=self.image_ref)
    def poll(self):
        try:
            result=self.output.get_nowait();self.latest=result;self.draw()
            s=result.scene.summary['sectors'];names={'left':'слева','center':'по центру','right':'справа'}
            values='; '.join(f'{names[k]} {v["ground_fraction"]:.0%}' for k,v in s.items())
            self.detail.set(('Глубина: светлее — ближе; фиолетовый — возможный перепад, не доказанный обрыв. ' if result.depth is not None else '')+'Доля похожей на землю поверхности: '+values+'. Это наблюдение, не команда движения.')
        except queue.Empty:pass
        while True:
            try:kind,value=self.events.get_nowait()
            except queue.Empty:break
            if kind=='finished':
                if self.worker is value:self.worker=None
            else:
                logging.info('%s: %s',kind,value);self.status.set(str(value))
                if kind=='auto_done':self.auto.set(False)
        if self.latest is not None:
            elapsed=time.monotonic()-self.latest.created
            if self.latest.metadata['source']=='image':
                self.age.set(f'Скриншот; анализ {self.latest.metadata.get("total_ms",self.latest.metadata["inference_ms"]):.0f} мс')
            else:self.age.set(f'Возраст кадра: {elapsed:.1f} с'+(' — кадр устарел' if elapsed>2 else ''))
        if self.worker is not None:
            try:self.worker.settings['threshold']=min(.9,max(.35,float(self.threshold.get())))
            except (ValueError,self.tk.TclError):pass
            self.worker.settings['hide_hud']=self.hide_hud.get()
            if self.worker.kind=='live':
                from win_capture import _user32
                active=_user32().GetForegroundWindow()==self.worker.source.hwnd
                actions={0x75:self.save,0x76:lambda:(self.auto.set(not self.auto.get()),self.sync_auto()),0x79:self.pause}
                for vk in shortcut_edges(self.key_states,active):actions[vk]()
        self.root.after(100,self.poll)
    def close(self):
        if self.worker is not None:self.worker.stop.set();self.worker.join(timeout=.2)
        self.root.destroy()


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    group=parser.add_mutually_exclusive_group();group.add_argument('--image');group.add_argument('--video');group.add_argument('--self-test',action='store_true')
    parser.add_argument('--output',type=Path,default=ROOT/'samples');parser.add_argument('--cpu',action='store_true');parser.add_argument('--device',type=int,default=0)
    parser.add_argument('--max-frames',type=int,default=10);parser.add_argument('--interval',type=float,default=2)
    args=parser.parse_args()
    logging.basicConfig(filename=ROOT/'observer.log',level=logging.INFO,format='%(asctime)s %(levelname)s %(message)s',encoding='utf-8')
    if args.image or args.video or args.self_test:
        runner=SegmentationRunner(args.device,args.cpu,print)
        runner.depth_runner=DepthRunner(args.device,args.cpu,print)
        if args.self_test:
            frame=np.zeros((360,640,3),np.uint8);result=analyze(runner,frame)
            print(json.dumps({'depth_backend':runner.depth_runner.backend,'depth_ms':result.metadata['depth_ms'],'total_ms':result.metadata['total_ms'],'backend':runner.backend,'inference_ms':result.metadata['inference_ms'],'dimensions':list(result.scene.labels.shape),'game_controls':False}));return
        store=SampleStore(args.output)
        if args.image:
            result=analyze(runner,read_image(args.image));print(store.save(result.frame,result.overlay,result.scene,result.metadata,depth=result.depth,depth_view=result.depth_view,edge_view=result.edge_view));return
        if args.interval<=0 or args.max_frames<=0:parser.error('interval/max-frames must be positive')
        video=cv2.VideoCapture(args.video)
        if not video.isOpened():raise ValueError('Could not open video')
        try:
            for i in range(args.max_frames):
                video.set(cv2.CAP_PROP_POS_MSEC,i*args.interval*1000);ok,frame=video.read()
                if not ok:break
                result=analyze(runner,frame,source='video',position=i*args.interval)
                print(store.save(result.frame,result.overlay,result.scene,result.metadata,depth=result.depth,depth_view=result.depth_view,edge_view=result.edge_view))
        finally:video.release()
        return
    if os.name=='nt':
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:pass
    import tkinter as tk
    root=tk.Tk();Application(root);root.mainloop()


if __name__=='__main__':
    try:main()
    except Exception:
        logging.exception('Observer failed');traceback.print_exc();raise SystemExit(1)
