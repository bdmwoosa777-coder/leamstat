"""Install an isolated runtime; do not modify the gather bot's environment."""
from pathlib import Path
import os,subprocess,sys,venv

ROOT=Path(__file__).resolve().parent


def main():
    if not (3,10)<=sys.version_info[:2]<(3,14):
        raise RuntimeError('Нужен Python 3.10–3.13 (рекомендуется 3.12 x64): https://www.python.org/downloads/windows/')
    if sys.maxsize<=2**32:raise RuntimeError('Нужен Python x64, не 32-bit')
    folder=ROOT/'.venv'
    if not folder.exists():venv.EnvBuilder(with_pip=True).create(folder)
    python=folder/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
    subprocess.run([str(python),'-m','pip','install','--disable-pip-version-check','-r',str(ROOT/'requirements.txt')],check=True)
    subprocess.run([str(python),str(ROOT/'observer.py'),'--self-test'],check=True)
    print('Готово. Запустите START.bat')


if __name__=='__main__':main()
