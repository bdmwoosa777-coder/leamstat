# Third-party model and libraries

The application source is MIT-licensed. The included model is separate:

- NVIDIA SegFormer B0, fine-tuned on ADE20K; upstream Hugging Face snapshot:
  https://huggingface.co/nvidia/segformer-b0-finetuned-ade-512-512/tree/489d5cd81a0b59fab9b7ea758d3548ebe99677da
- Original source/model license: NVIDIA Source Code License for SegFormer.
  Its complete, unmodified text is in `models/LICENSE_SEGFORMER.txt`.
  Use limitation: research or evaluation purposes only, non-commercially.
- The included ONNX conversion remains subject to that model license. It is
  a derivative of the checkpoint, not an independently trained AION2 model.
- Model card including the paper citation: `models/UPSTREAM_MODEL_CARD.md`.
- Export code: `tools/export_model.py`; provenance and source/export hashes:
  `models/model.json`. The application does not load executable hub code.

Runtime dependencies are installed separately by pip, rather than included as
binaries in this archive. Their license notices ship with their distributions:
ONNX Runtime/DirectML (MIT), NumPy (BSD), OpenCV (Apache-2.0), Pillow (HPND),
and MSS (MIT). The installed package metadata is authoritative for those notices.

User captures, logs and private evaluation screenshots are not distributed.

Depth model added in v0.2:
- https://huggingface.co/onnx-community/depth-anything-v2-small/tree/4472b7362082ad9968fee890ca0f1e5aca36b93d
- Base model: Depth Anything V2 Small by Lihe Yang et al., Apache-2.0.
- FP16 checkpoint is included unmodified. Full license, upstream card and pinned
  model hash are in models/depth/. This applies to Small, not other model sizes.
