"""Private start racing OCR, exact attempt deadlines and nonterminal recovery."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import unittest
import cv2,numpy as np
import gather_engine as ge,hybrid_engine as he,app
from gamepad_input import GamepadInput
from hybrid_engine import HybridGatherEngine
from resource_liveness import ResourceLiveness
from network_feed import NetworkFeed
from network_state import Flow,Node
from flight import FlightReading
from navigation import Drive
from spatial import resource_names
from test_navigation import GatherFixture
from test_network_control import Source
from test_ether_emblem import scene,ether

GROUND=FlightReading(80,False)


class AliveEngine(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e;self.source=Source();self.f=self.source.state
  self.e=HybridGatherEngine({**old.cfg,'collection_event_driven':True,'resource_click_interaction':True,
      'preserve_owned_resource':True,'auto_view_recovery':False,'hybrid_camp_exit':False},self.log.append,self.input,network=self.source)
  self.e.screen=old.screen;self.e.bridge=old.bridge
  self.f.nodes[99].template=next(k for k,v in resource_names().items() if v=='Эфир')
  self.f.nodes[99].gather_time=1000;self.f.nodes[99].used=0
  self.f.started=1000;self.f.attempt_ordinal=1
  self.e.mode='GATHER';self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True
  self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
  self.e.real_gather_panel_seen=True;self.clock=100.;self.wall=1100
  for p in (patch.object(he.time,'monotonic',side_effect=lambda:self.clock),patch.object(he.time,'time',side_effect=lambda:self.wall/1000)):
   p.start();self.addCleanup(p.stop)
 def tick(self,t):self.clock=t;return self.e._resource_liveness_tick(self.frame,t)
 def panel(self):
  self.frame=np.full((1440,2560,3),35,np.uint8)
  crop=cv2.imread(str(Path(ge.ROOT)/'testdata/current_gather_panel.png'));h,w=crop.shape[:2]
  self.frame[1014:1014+h,930:930+w]=crop
 def idle(self):
  self.f.collecting=None;self.f.attempt_active=False;self.f.started=None;self.f.nodes[99].gather_time=None
  self.e.target=None;self.e.target_confirmed=False;self.e.resource_hold=False;self.e.network_target=None;self.e.mode='SEARCH'
 def acquire(self):
  self.idle();self.frame=scene();self.c=ether(self.frame);self.e.current_size=(self.frame.shape[1],self.frame.shape[0])
  self.e.cfg['native_cursor_chord']=True;self.input.native_cursor=True
 def start_own(self):
  self.f.collecting=99;self.f.started=self.wall;self.f.attempt_active=True
  self.f.nodes[99].gather_time=self.wall;self.f.nodes[99].used=0;self.f.attempt_ordinal=1

 def test_recorded_own_start_during_ocr_prevents_cancellation_a(self):
  self.acquire()
  def check(*args):self.start_own();return True
  with patch.object(self.e,'_acquire_caption_matches',side_effect=check),patch.object(GamepadInput,'wait',return_value=True):
   self.assertTrue(self.e.click_candidate(self.c,(0,0),refresh=False,retry=True))
  self.assertEqual(self.pad.presses,0);self.assertTrue(self.e.resource_hold);self.assertTrue(self.e._net_gather_proof())
 def test_private_start_before_first_gauge_also_prevents_a(self):
  self.acquire()
  def check(*args):self.start_own();self.f.nodes[99].gather_time=None;self.f.nodes[99].used=None;return True
  with patch.object(self.e,'_acquire_caption_matches',side_effect=check),patch.object(GamepadInput,'wait',return_value=True):
   self.e.click_candidate(self.c,(0,0),refresh=False)
  self.assertEqual(self.pad.presses,0)
 def test_a_down_gate_checks_for_start_after_last_foreground_check(self):
  self.acquire();gate=self.e._a_input_ready
  def late():self.start_own();return gate()
  self.input.a_gate=late
  with patch.object(self.e,'_acquire_caption_matches',return_value=True),patch.object(GamepadInput,'wait',return_value=True):
   self.assertTrue(self.e.click_candidate(self.c,(0,0),refresh=False))
  self.assertEqual(self.pad.presses,0);self.assertTrue(self.e.resource_hold)
 def test_own_start_caused_by_initial_a_during_hold_hands_off_without_another_a(self):
  self.acquire()
  def wait(seconds,stop,focused):
   if self.pad.presses:self.start_own()
   return not stop.is_set() and focused()
  with patch.object(self.e,'_acquire_caption_matches',return_value=True),patch.object(GamepadInput,'wait',side_effect=wait):
   self.assertTrue(self.e.click_candidate(self.c,(0,0),refresh=False))
  self.assertEqual(self.pad.presses,1);self.assertTrue(self.e.resource_hold);self.assertFalse(self.e.stop_event.is_set())
 def test_absent_lower_panel_and_unchanged_active_flag_recovers_in_twelve_seconds(self):
  self.assertFalse(self.tick(100));self.assertFalse(self.tick(111.9));self.assertTrue(self.tick(112.1))
  self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.stop_event.is_set());self.assertTrue(self.f.attempt_active)
  self.assertEqual(self.f.nodes[99].used,0);self.assertEqual(self.e.node_count,0);self.assertFalse(self.e._live_attempt(self.source.view()))
  self.e._motion(Drive(.78));self.assertGreater(self.pad.axes[1],.5);self.assertEqual(self.pad.presses,0)
 def test_fresh_mob_hit_after_stale_collection_release_starts_defense(self):
  self.tick(100);self.tick(113)
  self.f.attacks[55]=self.wall;self.f.npcs[55]={'time':1000,'born_at':1000};self.f.selected=0
  self.assertTrue(self.e._net_defense(114));self.assertEqual(self.e.mode,'DEFENSE')
  self.assertEqual(self.e.network_defense.attacker,55);self.assertFalse(self.e.stop_event.is_set())
 def test_visible_panel_before_limit_protects_real_attempt(self):
  self.panel()
  for t in (100,106,114.9):self.assertFalse(self.tick(t))
  self.assertEqual(self.e.mode,'GATHER');self.assertTrue(self.e.resource_hold)
 def test_fifteen_second_limit_applies_even_to_a_stuck_visible_panel(self):
  self.panel();self.tick(100);self.assertTrue(self.tick(115.1))
  self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.stop_event.is_set())
  self.assertFalse(self.tick(116));self.assertFalse(self.e._adopt_network_collection())
  self.assertFalse(self.e._live_attempt(self.source.view()));self.assertEqual(self.e.node_count,0)
 def test_fresh_capture_time_already_fifteen_seconds_old_is_not_given_another_minute(self):
  self.wall=17000;self.panel();self.assertTrue(self.tick(100));self.assertEqual(self.e.mode,'SEARCH')
 def test_duplicate_gauge_timestamp_does_not_renew_attempt_budget(self):
  self.panel();self.tick(100)
  for t in range(101,116):
   self.f.nodes[99].gather_time=1000+(t-100)*10;released=self.tick(t)
  self.assertTrue(released)
  self.f.nodes[99].gather_time+=10;self.assertFalse(self.e._live_attempt(self.source.view()))
 def test_next_private_start_before_gauge_immediately_revokes_retirement(self):
  self.tick(100);self.tick(113);self.f.started=1200
  self.assertTrue(self.e._live_attempt(self.source.view()));self.assertFalse(self.e._translation_input_ready())
  self.assertTrue(self.e._adopt_network_collection());self.assertTrue(self.e.resource_hold)
 def test_retired_active_flag_does_not_block_starting_a_different_resource(self):
  self.tick(100);self.tick(113)
  self.f.nodes[101]=Node(101,self.f.nodes[99].template,used=0,time=1100);self.f.selected=101
  self.e.network_target=(1,101);self.e.network_owner=7;self.e.target='Эфир';self.e.target_confirmed=True;self.e.mode='APPROACH'
  self.e.route_f_pending=True;self.assertTrue(self.e._click_ready((1,101),False))
  self.f.collecting=101;self.f.started=1200
  self.assertFalse(self.e._click_ready((1,101),False))
 def test_new_ordinal_without_second_interaction_gets_a_fresh_budget(self):
  self.panel();self.tick(100);self.f.attempt_ordinal=2;self.f.nodes[99].gather_time=1200
  self.assertFalse(self.tick(114));self.assertFalse(self.tick(120));self.assertEqual(self.e.mode,'GATHER')
 def test_three_attempts_are_not_treated_as_one_fifteen_second_collection(self):
  self.panel();self.tick(100)
  for used,at in ((1,106),(2,116)):
   self.f.attempt_active=False;self.f.nodes[99].used=used;self.f.last_own_result=(99,1100+used*100);self.f.last_own_result_used=used
   self.assertFalse(self.tick(at));self.f.attempt_active=True;self.f.started+=100;self.f.nodes[99].gather_time+=100;self.f.attempt_ordinal+=1
   self.assertFalse(self.tick(at+1))
  self.assertFalse(self.tick(125));self.assertEqual(self.e.mode,'GATHER')
 def test_real_panel_return_can_restore_soft_but_not_hard_retirement(self):
  self.tick(100);self.tick(113);self.panel();self.tick(114)
  self.assertTrue(self.e.resource_hold);self.assertTrue(self.e._net_gather_proof())
 def test_final_frame_returning_panel_prevents_soft_release(self):
  self.tick(100)
  def frame():self.panel();return self.frame,(0,0)
  self.e.screen.frame=frame;self.assertFalse(self.tick(113));self.assertEqual(self.e.mode,'GATHER')
 def test_new_attempt_during_final_read_prevents_release(self):
  self.tick(100)
  def frame():self.f.started=1200;return self.frame,(0,0)
  self.e.screen.frame=frame;self.assertFalse(self.tick(113));self.assertEqual(self.e.mode,'GATHER')
 def test_selected_dead_mob_does_not_pin_old_collection_forever(self):
  self.f.selected=55;self.f.npcs[55]={'dead':True,'time':1100}
  self.tick(100);self.assertTrue(self.tick(113));self.assertEqual(self.e.mode,'SEARCH')
 def test_private_interaction_without_gauge_or_engine_binding_is_bounded(self):
  self.e.network_target=None;self.e.target_confirmed=False;self.e.mode='SEARCH'
  self.f.nodes[99].gather_time=None;self.f.nodes[99].used=None
  self.tick(100);self.assertTrue(self.tick(115.1));self.assertFalse(self.e._live_attempt(self.source.view()))
 def test_stop_or_lost_focus_never_triggers_resource_release(self):
  self.tick(100);self.e.screen.focused=lambda:False;self.assertFalse(self.tick(113))
  self.e.screen.focused=lambda:True;self.e.stop_event.set();self.assertFalse(self.tick(140))
  self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.pad.presses,0)
 def test_no_own_route_wait_is_bounded_without_inventing_a_result(self):
  self.f.collecting=None;self.f.attempt_active=False;self.f.started=None;self.f.nodes[99].gather_time=None
  self.f.nodes[99].used=None;self.e.mode='APPROACH'
  self.tick(100);self.assertFalse(self.tick(119));self.assertTrue(self.tick(120.1));self.assertEqual(self.e.node_count,0)
 def test_real_route_distance_progress_renews_only_the_route_wait(self):
  self.f.collecting=None;self.f.attempt_active=False;self.f.started=None;self.f.nodes[99].gather_time=None
  self.e.mode='APPROACH';self.e.last_distance=40;self.tick(100);self.e.last_distance=20
  self.assertFalse(self.tick(119));self.assertFalse(self.tick(125))
 def test_legacy_gather_timeout_hook_keeps_engine_and_defense_alive(self):
  self.panel();self.assertTrue(self.e._recover_resource_wait(self.frame,GROUND,100,'gather_timeout'))
  self.assertFalse(self.e.stop_event.is_set());self.assertEqual(self.e.mode,'GATHER')
 def test_automatic_recovery_preserves_a_pending_continuation_reservation(self):
  self.f.attempt_active=False;self.f.nodes[99].used=1;self.f.last_own_result=(99,1100);self.f.last_own_result_used=1
  self.e.collection_cycle.consumed.add(('end',1));self.e.collection_cycle.pending=('end',1)
  self.e.stop();self.e._automatic_recovery_tick(self.frame,101)
  self.assertIn(('end',1),self.e.collection_cycle.consumed);self.assertEqual(self.e.collection_cycle.pending,('end',1))
  self.assertFalse(self.e.stop_event.is_set());self.assertEqual(self.pad.presses,0)


class RecoverySupervisor(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e;self.source=Source();self.source.state.collecting=None;self.source.state.started=None;self.source.state.attempt_active=False
  self.e=HybridGatherEngine({**old.cfg,'hybrid_camp_exit':False},self.log.append,self.input,network=self.source)
  self.e.screen=old.screen;self.e.bridge=old.bridge;self.e.mode='SEARCH';self.e.target=None
  self.clock=100.;p=patch.object(he.time,'monotonic',side_effect=lambda:self.clock);p.start();self.addCleanup(p.stop)
 def test_internal_stop_requests_recovery_and_does_not_close_observers_or_network(self):
  self.e.click_busy=True;self.e.say('тайм-аут камеры');self.e.stop()
  self.assertFalse(self.e.stop_event.is_set());self.assertIsNotNone(self.e.automatic_recovery)
  self.assertFalse(self.e._automatic_recovery_tick(self.frame,101));self.assertEqual(self.e.mode,'SEARCH')
  self.assertIsNone(self.e.automatic_recovery);self.assertIsNone(self.e.release_thread)
  self.assertFalse(self.e.click_busy)
 def test_manual_stop_really_stops(self):
  self.e.stop(manual=True);self.assertTrue(self.e.stop_event.is_set())
  if self.e.release_thread:self.e.release_thread.join(1)
 def test_captcha_really_stops_and_alarms(self):
  with patch.object(self.e.cap_alarm,'start') as alarm:self.e.trigger_alarm('CAPTCHA',self.frame)
  self.assertTrue(self.e.stop_event.is_set());self.assertEqual(self.e.alert,'CAPTCHA');alarm.assert_called_once()
  if self.e.release_thread:self.e.release_thread.join(1)
 def test_death_keeps_observation_alive_and_resumes_after_window_disappears(self):
  with patch.object(self.e.death_alarm,'start') as alarm:self.e.trigger_alarm('DEATH',self.frame)
  alarm.assert_called_once();self.assertFalse(self.e.stop_event.is_set())
  with patch.object(self.e.death,'check',return_value=(True,1)):
   self.assertTrue(self.e._automatic_recovery_tick(self.frame,101))
  with patch.object(self.e.death,'check',return_value=(False,0)):
   self.assertTrue(self.e._automatic_recovery_tick(self.frame,102));self.e._automatic_recovery_tick(self.frame,103.1)
  self.assertFalse(self.e.death_wait);self.assertFalse(self.e.stop_event.is_set());self.assertEqual(self.e.mode,'SEARCH')
 def test_captcha_during_death_wait_is_still_terminal(self):
  with patch.object(self.e.death_alarm,'start'),patch.object(self.e.cap_alarm,'start'):
   self.e.trigger_alarm('DEATH',self.frame);self.e.trigger_alarm('CAPTCHA',self.frame)
  self.assertTrue(self.e.stop_event.is_set());self.assertEqual(self.e.alert,'CAPTCHA')
  if self.e.release_thread:self.e.release_thread.join(1)
 def test_loss_of_focus_or_network_suspends_input_without_ending_session(self):
  self.e.stop();self.e.screen.focused=lambda:False;self.assertTrue(self.e._automatic_recovery_tick(self.frame,101))
  self.e.screen.focused=lambda:True;self.source.ready=False;self.assertTrue(self.e._automatic_recovery_tick(self.frame,102))
  self.assertFalse(self.e.stop_event.is_set());self.assertEqual(self.pad.presses,0)
 def test_recovery_cannot_issue_a_map_toggle_on_an_unverified_scene(self):
  self.e.stop();self.e._automatic_recovery_tick(self.frame,101);self.assertNotIn('MAP',self.commands)
 def test_failed_vision_worker_is_restarted_without_restarting_live_workers(self):
  seen=[]
  def observer():seen.append('running')
  old=SimpleNamespace(is_alive=lambda:False);self.e.safety_threads=[old];self.e._vision_loop=observer
  self.e._ensure_observers(100);self.e.safety_threads[0].join(1)
  self.assertEqual(seen,['running']);self.assertIsNot(self.e.safety_threads[0],old)
 def test_runtime_exception_is_recoverable_but_not_after_manual_stop(self):
  self.assertTrue(self.e._runtime_failure(RuntimeError('capture retry')));self.assertFalse(self.e.stop_event.is_set())
  self.e.stop(manual=True);self.assertFalse(self.e._runtime_failure(RuntimeError('late error')))
  if self.e.release_thread:self.e.release_thread.join(1)
 def test_real_run_loop_recovers_exception_and_honors_later_manual_stop(self):
  seen=[];self.source.start=lambda:None;self.source.close=lambda:seen.append('closed')
  self.e.screen.pick=lambda:'game';self.e._preflight_receiver=lambda:True;self.e._prepare_working_view=lambda:True
  for name in ('_vision_loop','_health_fast_loop','_health_numeric_loop','_heartbeat_loop','_input_audit_loop','_dialog_loop'):
   setattr(self.e,name,lambda *a:None)
  def guard(now):
   seen.append('tick')
   if seen.count('tick')==1:raise RuntimeError('one frame failed')
   self.e.stop(manual=True);return True
  self.e._network_guard=guard
  with patch.object(self.e.stop_event,'wait',side_effect=lambda *a:self.e.stop_event.is_set()):self.e.run()
  self.assertEqual(seen.count('tick'),2);self.assertEqual(seen.count('closed'),1)
  self.assertTrue(any('AUTO_RECOVER: поиск возобновлён' in s for s in self.log))
 def test_qwen_is_optional_and_disabled_in_shipped_default(self):
  self.assertFalse(app.DEFAULT['analyzer_enabled']);self.assertIsNone(self.e.analyzer)
 def test_ui_stop_explicitly_marks_the_user_request(self):
  from unittest.mock import Mock
  ui=object.__new__(app.UI);ui._start_token=0;ui._start_pending=True;ui.engine=SimpleNamespace(stop=Mock());ui.log=lambda _:None
  ui.stop();ui.engine.stop.assert_called_once_with(manual=True);self.assertFalse(ui._start_pending)
 def test_startup_window_failure_retries_in_same_supervisor_until_manual_stop(self):
  seen=[];self.source.start=lambda:seen.append('started');self.source.close=lambda:seen.append('closed')
  def pick():seen.append('pick');return None if seen.count('pick')==1 else 'game'
  self.e.screen.pick=pick;self.e._preflight_receiver=lambda:True;self.e._prepare_working_view=lambda:True
  for name in ('_vision_loop','_health_fast_loop','_health_numeric_loop','_heartbeat_loop','_input_audit_loop','_dialog_loop'):
   setattr(self.e,name,lambda *a:None)
  def guard(now):self.e.stop(manual=True);return True
  self.e._network_guard=guard
  with patch.object(self.e.stop_event,'wait',side_effect=lambda *a:self.e.stop_event.is_set()):self.e.run()
  self.assertEqual(seen.count('pick'),2);self.assertEqual(seen.count('started'),1);self.assertEqual(seen.count('closed'),1)
  self.assertEqual(self.pad.presses,0)
 def test_capture_recovery_resets_old_identity_and_requires_new_protocol(self):
  feed=NetworkFeed(command=['offline']);feed.telemetry.flows[1]=Flow(own=7);feed.protocol_ok=True
  feed.latest_flow=1;feed.error='old error';feed.closed.set()
  with patch.object(feed,'close') as close,patch.object(feed,'start') as start:feed.recover()
  close.assert_called_once();start.assert_called_once();self.assertEqual(feed.telemetry.flows,{})
  self.assertFalse(feed.protocol_ok);self.assertIsNone(feed.latest_flow);self.assertIsNone(feed.error);self.assertFalse(feed.closed.is_set())
 def test_failed_capture_restart_remains_retryable(self):
  feed=NetworkFeed(command=['offline'])
  with patch.object(feed,'close'),patch.object(feed,'start',side_effect=RuntimeError('capture retry')):
   with self.assertRaisesRegex(RuntimeError,'capture retry'):feed.recover()
  self.assertIn('capture retry',feed.error)


if __name__=='__main__':unittest.main()
