"""Replay the service order that precedes acquisition, defense and map exit."""
import io,json,unittest
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
import gather_engine as ge
import hybrid_engine as he
import hybrid_navigation as hn
import test_hybrid as fixtures
from hybrid_engine import HybridGatherEngine
from camera_pitch import PitchLedger
from flight import FlightReading
from navigation import Drive
from navigation import Navigator
from minimap import Marker
from network_defense import NetworkDefense
from map_teleport import MapTeleport,MapObservation,menu_stamp
from idle_return import MapEvidence
from terrain_recovery import TerrainRecovery
from test_navigation import GatherFixture,obs,radar
from test_network_control import Source
from test_map_teleport import map_frame

GROUND=FlightReading(None,False);AIR=FlightReading(80,True)

class PurposeEngine(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();bridge=self.e.bridge;screen=self.e.screen
  cfg={**self.e.cfg,'hybrid_camp_exit':False,'auto_view_recovery':False,'analyzer_enabled':False,'terrain_rescue_enabled':True}
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=HybridGatherEngine(cfg,self.log.append,self.input,network=self.source);self.e.bridge=bridge;self.e.screen=screen
  self.e.mode='SEARCH';self.e.target=None;self.e.budget.energy=80;self.clock=100.
  self.patches=[patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',return_value=1000.),patch.object(ge,'gathering_panel_pair',return_value=False),patch.object(ge,'gathering_panel',return_value=False),patch.object(ge,'segment_count',return_value=None)]
  for p in self.patches:p.start();self.addCleanup(p.stop)
  self.input.motion_worker=object();self.c=replace(self.c,name='Эфир')
 def test_rescue_caption_survives_fast_service_then_reaches_acquisition(self):
  self.e.mode='RESCUE';self.e.terrain_recovery=TerrainRecovery(90,80);self.e.terrain_recovery.phase='CRUISE'
  self.e._candidate_observed(self.c,100,0)
  self.assertFalse(self.e._network_defense_tick(100));self.assertFalse(self.e._no_yield_tick(self.frame,AIR,100))
  self.assertFalse(self.e._terrain_recovery_tick(self.frame,AIR,100,radar()))
  with patch.object(he,'find_resource_near',return_value=self.c):
   for t in (100.1,100.4):
    self.clock=t
    self.assertFalse(self.e._resource_fast_tick(self.frame,AIR,t))
    self.e.step(self.frame,(0,0),obs(),radar(),AIR,t,1)
   self.assertEqual(self.e.mode,'ACQUIRE_WAIT')
   self.clock=100.7
   with patch.object(self.e,'click_candidate',return_value=True) as click:
    self.e.step(self.frame,(0,0),obs(),radar(),AIR,self.clock,2);click.assert_called_once()
  self.assertNotIn('END_AIR',self.commands);self.assertNotIn('V',self.commands);self.assertFalse(self.e.stop_event.is_set())
 def test_camera_baseline_change_during_recognition_cannot_reverse_the_new_view(self):
  old=self.e.pitch.baseline_revision;self.e.pitch.balance=-.4;self.e.pitch.set_working_baseline(100)
  self.e._candidate_observed(self.c,100,-.4,old)
  with patch.object(he,'find_resource_near',return_value=self.c):
   current,waiting=self.e._caption_frame(self.frame,obs(),100)
  self.assertFalse(waiting);self.assertEqual(current.candidate.name,'Эфир');self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_failed_caption_has_a_finite_air_search_grace(self):
  self.e._candidate_observed(self.c,100,0);self.assertEqual(self.e.rescue_air_search_until,105)
  self.clock=103
  _,waiting=self.e._caption_frame(self.frame,obs(),103)
  self.assertFalse(waiting);self.assertIsNone(self.e.caption_latch);self.assertLess(self.e.rescue_air_search_until,110)
 def test_slow_recognition_must_revalidate_on_a_current_frame_before_stopping(self):
  with patch.object(he,'find_resource_near',return_value=self.c) as fresh:
   self.e._candidate_observed(self.c,98.9,0)
  fresh.assert_called_once();self.assertIsNotNone(self.e.caption_latch);self.assertEqual(self.pad.presses,0)
 def test_caption_cancels_only_pending_close_retries_and_preserves_input_for_acquisition(self):
  self.e.wing_close_pending=99;self.e.wing_close_started=99
  self.e._candidate_observed(self.c,100,0)
  self.assertIsNone(self.e.wing_close_pending);self.assertIsNone(self.e.wing_close_started)
  self.assertFalse(self.e._resource_fast_tick(self.frame,AIR,100));self.assertNotIn('END_AIR',self.commands)
 def test_native_close_does_not_toggle_y_again_during_fall_animation(self):
  self.e.bridge.controller_native=True
  with patch.object(ge,'read_flight',return_value=AIR):self.assertTrue(self.e.bridge_cmd('END_AIR'))
  self.e.wing_close_pending=100;self.e.wing_close_started=100
  for t in (101.6,102.8):
   self.clock=t;self.assertTrue(self.e._service_wing_close(AIR,t))
  self.clock=103.1;self.assertFalse(self.e._service_wing_close(AIR,103.1))
  self.assertIsNone(self.e.wing_close_pending);self.assertEqual(self.commands.count('END_AIR'),1)
  self.assertFalse(self.e._resource_fast_tick(self.frame,AIR,103.1));self.assertFalse(self.e.bridge_cmd('END_AIR'))
 def test_loot_timeout_does_not_allow_flight_without_stagnation_evidence(self):
  self.e.cfg['no_yield_return_enabled']=True;self.e.no_yield.idle=95
  self.e.terrain_watch.reset(99)
  self.assertFalse(self.e._no_yield_rescue_allowed(100));self.assertFalse(self.e._no_yield_tick(self.frame,GROUND,100))
  self.assertIsNone(self.e.terrain_recovery);self.assertNotIn('V',self.commands)
 def test_real_persistent_stagnation_still_allows_recovery(self):
  self.e.terrain_watch.since=0;self.e.terrain_watch.valid=30
  self.assertTrue(self.e._no_yield_rescue_allowed(100))
 def hit(self):
  self.source.state.attacks[33]=1000000;self.source.state.npcs[33]={'time':1,'born_at':1};self.source.state.selected=21
 def test_new_hit_interrupts_rescue_before_its_next_motion(self):
  self.assertTrue(self.e._start_terrain_recovery(100,GROUND));self.hit()
  with patch.object(ge,'read_flight',return_value=AIR):self.assertTrue(self.e._network_defense_tick(100))
  self.assertIsNone(self.e.terrain_recovery);self.assertEqual(self.e.mode,'DEFENSE')
  self.assertEqual(self.e.network_defense.attacker,33);self.assertEqual(self.e.network_defense.max_tabs,8)
  self.assertNotIn('V',self.commands);self.assertNotIn('ATTACK_PAIR',self.commands)
 def test_old_patrol_episode_count_cannot_disable_all_later_defense(self):
  self.hit();self.e.defense_cycles=10;self.assertTrue(self.e._pending_network_hits(100))
  self.e.network_target=(1,99);self.assertEqual(self.e._pending_network_hits(100),[])
 def test_unknown_own_identity_still_cannot_authorize_a_random_attack(self):
  self.hit();self.source.state.own=None
  self.assertFalse(self.e._network_defense_tick(100));self.assertIsNone(self.e.network_defense);self.assertNotIn('ATTACK_PAIR',self.commands)
 def test_visual_detours_cannot_reset_distance_progress_without_closing_in(self):
  node=Marker('Эфир',140,100,.9,40,'aether')
  with patch.object(self.e,'_scene_plan',return_value=Drive(.7)):
   self.e.step(self.frame,(0,0),obs(),radar([node]),GROUND,100,1)
   self.e.hybrid.active=True;self.clock=105
   self.e.step(self.frame,(0,0),obs(),radar([node]),GROUND,105,2)
  self.assertEqual(self.e.nav.progress_at,100)
 def begin_failed_map(self):
  self.frame=map_frame();self.e.map_teleport=MapTeleport(100);self.e.map_active=True;self.e.mode='MAP_RETURN'
  self.e.map_return_after=400;self.e.map_menu_stamp=menu_stamp(self.frame);self.e.no_yield.idle=180;self.e.pitch.pause_return(100)
  self.e._map_teleport_failed(MapObservation(opened=True),'list did not scroll',100)
 def test_map_scroll_failure_closes_once_then_resumes_without_claiming_teleport(self):
  self.begin_failed_map()
  self.assertTrue(self.e._map_teleport_tick(self.frame,GROUND,100));self.assertEqual(self.commands.count('MAP'),1)
  self.clock=101;self.e._map_teleport_tick(self.frame,GROUND,101);self.assertEqual(self.commands.count('MAP'),1)
  self.frame=np.full_like(self.frame,70)
  with patch.object(he,'is_map',return_value=False),patch.object(he,'same_stamp',return_value=False),patch.object(he,'map_evidence',return_value=MapEvidence(usable=True)):
   for t in (102,102.7):self.clock=t;self.e._map_teleport_tick(self.frame,GROUND,t)
  self.assertIsNone(self.e.map_teleport);self.assertFalse(self.e.map_active);self.assertEqual(self.e.mode,'SEARCH')
  self.assertFalse(self.e.stop_event.is_set());self.assertEqual(self.e.no_yield.idle,180);self.assertGreaterEqual(self.e.no_yield.next_return,400)
  self.assertNotIn('TAP_F',self.commands)
 def test_loading_or_unknown_world_frame_does_not_resume_walking(self):
  self.begin_failed_map()
  with patch.object(he,'is_map',return_value=False),patch.object(he,'same_stamp',return_value=False),patch.object(he,'map_evidence',return_value=MapEvidence(loading=True)):
   self.clock=105;self.e._map_teleport_tick(self.frame,GROUND,105)
  self.assertTrue(self.e.map_active);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.e.mode,'MAP_RETURN')
 def test_failed_trip_after_paid_confirmation_requests_recovery_without_another_payment(self):
  self.e.map_teleport=MapTeleport(100);self.e.map_teleport.used=True
  self.e._map_teleport_failed(MapObservation(),'arrival unknown',100)
  self.assertFalse(self.e.stop_event.is_set());self.assertIsNone(self.e.map_exit_failure)
  self.assertIsNotNone(self.e.automatic_recovery);self.assertNotIn('TAP_F',self.commands)

class GoalDirectedRoute(unittest.TestCase):
 def test_near_aether_is_inspected_before_more_translation(self):
  plan=Navigator({'air_search_map_radius':18}).update(radar([Marker('Эфир',110,100,.9,10,'aether')]),100)
  self.assertEqual(plan.forward,0);self.assertNotEqual(plan.pitch,0)
 def test_rough_but_connected_ground_keeps_direct_goal_course(self):
  p=hn.HybridPlanner();reading=fixtures.scene(free=.56)
  a=p.choose(Drive(.78),reading,radar(),100)
  self.assertEqual(a.drive.forward,.78);self.assertEqual(a.drive.strafe,0)
 def test_goal_behind_camera_is_not_replaced_by_a_forward_local_route(self):
  a=hn.HybridPlanner().choose(Drive(-.7,0),fixtures.scene(free=.5),radar(),100)
  self.assertLess(a.drive.forward,0)
 def test_failed_direct_course_has_a_bounded_camera_survey(self):
  p=hn.HybridPlanner();p.avoid=[(90,200)]
  p.choose(Drive(.7),None,radar(),100)
  self.assertTrue(p.choose(Drive(.7),None,radar(),109).skip)
 def test_commit_follows_current_path_direction_instead_of_the_best_new_screen_id(self):
  p=hn.HybridPlanner();first=fixtures.scene(free=.5)
  p.choose(Drive(.7),first,radar(),100,hint=0)
  right=replace(fixtures.route(4,.8),score=100)
  fresh=replace(first,ground=replace(first.ground,routes=(fixtures.route(88,.2),right)))
  a=p.choose(Drive(.7),fresh,radar(),101)
  self.assertLess(a.drive.strafe,0)

class ProtocolAndIdentity(unittest.TestCase):
 def test_empty_advisor_reports_token_and_thinking_metadata_without_accepting_a_route(self):
  raw=json.dumps({'message':{'content':'','thinking':'secret thoughts'},'done_reason':'length','eval_count':96}).encode()
  with self.assertRaisesRegex(ValueError,'Empty advisor content: done_reason=length; output_tokens=96; thinking_chars=15'):hn.decode_reply(raw)
 def test_route_request_disables_thinking_when_model_supports_it(self):
  captured={}
  class Opener:
   def open(self,req,timeout):
    captured.update(json.loads(req.data));return io.BytesIO(b'{"message":{"content":"{\\"route_id\\":2,\\"scene\\":\\"open\\"}"}}')
  c=hn.RouteClient(model='qwen3-vl:4b');c.capabilities=['vision','thinking'];c.opener=Opener()
  self.assertEqual(c.analyze(fixtures.FRAME,fixtures.scene().ground,{})['route_id'],2)
  self.assertIs(captured['think'],False);self.assertEqual(captured['options']['num_predict'],192)
 def test_more_than_three_target_changes_can_find_exact_attacker_without_random_attack(self):
  state=Source().state;state.collecting=None;state.attempt_active=False;state.attacks[33]=1000000;state.npcs[33]={'time':1}
  d=NetworkDefense(33,1,7,100,max_tabs=8)
  for i,selected in enumerate((21,22,23,24)):
   state.selected=selected;now=100+i*.3
   self.assertEqual(d.plan(state,1000000,now),'TAB');d.sent_tab(1000000+i,now);state.selection_time=1000000+i
  state.selected=33;self.assertEqual(d.plan(state,1000000,101.2),'WAIT')
  self.assertEqual(d.plan(state,1000000,101.5),'PAIR')
 def test_pitch_capture_has_a_revision_that_changes_on_new_calibration(self):
  p=PitchLedger();p.balance=.4;old=p.capture(100);p.set_working_baseline(100)
  new=p.capture(100);self.assertEqual(old,(.4,0));self.assertEqual(new,(0,1))

if __name__=='__main__':unittest.main()
