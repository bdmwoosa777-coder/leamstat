"""Short-lived, read-only sightings of other Ether captions in the current view."""
import threading


def same_caption(a,b):
 if a is None or b is None:return False
 pairs=((a.emblem,b.emblem),) if a.emblem is not None and b.emblem is not None else ((a.box,b.box),)
 for box,other in pairs:
  if box is None or other is None:continue
  x,y,w,h=box;xx,yy,ww,hh=other
  overlap=max(0,min(x+w,xx+ww)-max(x,xx))*max(0,min(y+h,yy+hh)-max(y,yy))
  if overlap/max(1,min(w*h,ww*hh))>.35:return True
 return False


class EtherNeighbors:
 def __init__(self):self.lock=threading.RLock();self.key=None;self.entries=()
 def clear(self):
  with self.lock:self.key=None;self.entries=()
 def observe(self,key,candidates,owned,now):
  if key is None or owned is None:return
  with self.lock:
   if key!=self.key:self.entries=();self.key=key
   entries=[(c,t) for c,t in self.entries if 0<=now-t<=5 and not same_caption(c,owned)]
   for c in candidates:
    if c.name!='Эфир' or c.emblem is None or same_caption(c,owned):continue
    entries=[(old,t) for old,t in entries if not same_caption(c,old)]
    entries.append((c,now))
   self.entries=tuple(entries[-6:])
 def current(self,key,now):
  with self.lock:
   if key is None or key!=self.key:return ()
   self.entries=tuple((c,t) for c,t in self.entries if 0<=now-t<=5)
   return tuple(c for c,t in reversed(self.entries))
