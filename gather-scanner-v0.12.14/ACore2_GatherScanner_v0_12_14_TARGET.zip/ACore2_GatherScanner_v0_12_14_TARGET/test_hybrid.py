import json,math,threading,time,tempfile,unittest,contextlib,io
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from http.server import HTTPServer,BaseHTTPRequestHandler
import numpy as np
from hybrid_navigation import HybridPlanner,RouteAdvisor,RouteClient,Advice,decode_reply,route_angle
from hybrid_engine import HybridGatherEngine
from ground_routes import GroundMap,GroundRoute
from scene_navigation import SceneReading,Lane
from navigation import Drive
from flight import FlightReading
from route_analyzer import signature
from test_navigation import GatherFixture,radar,obs
from test_network_control import Source

FRAME=np.full((360,640,3),100,np.uint8)
def route(i,x):return GroundRoute(i,((.5,.72),(x,.60),(x,.45)),1.,.8,2)
def scene(routes=None,t=100,free=.5):
 return SceneReading(t,90,0,1,(Lane(free,.1,0,.1),)*3,ground=GroundMap(tuple(routes or [route(0,.2),route(2,.5),route(4,.8)]),100,0,(.5,.72)),source=FRAME)
CTX={'mode':'resources','kind':'gem','goal_bearing':90}

class AdvisorProtocol(unittest.TestCase):
 def test_complete_advisory_with_false_or_missing_done_is_validated_not_discarded(self):
  for meta in ({'done':False},{},{'done':True}):
   answer,_=decode_reply(json.dumps({**meta,'message':{'content':'{"route_id":2,"scene":"open"}'}}).encode())
   self.assertEqual(answer,{'route_id':2,'scene':'open'})
 def test_ndjson_despite_disabled_stream_is_joined_before_plan_validation(self):
  raw=b'\n'.join(json.dumps(x).encode() for x in [{'response':'{"route_id":2,','done':False},{'response':'"scene":"open"}','done':False}])
  self.assertEqual(decode_reply(raw)[0]['route_id'],2)
 def test_truncated_inner_json_or_gamepad_commands_cannot_be_advisory(self):
  for text in ('{"route_id":','{"action":"move"}','{"route_id":true,"scene":"open"}'):
   with self.assertRaises(ValueError):decode_reply(json.dumps({'response':text}).encode())
 def test_error_record_is_preserved_as_error(self):
  with self.assertRaisesRegex(RuntimeError,'runner died'):decode_reply(b'{"error":"runner died"}')
 def test_actual_http_advisor_contract_and_image(self):
  captured={}
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*a):pass
   def do_POST(self):
    captured.update(json.loads(self.rfile.read(int(self.headers['Content-Length']))));captured['path']=self.path
    raw=json.dumps({'message':{'content':'{"route_id":0,"scene":"passage"}'},'done':False}).encode()
    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   c=RouteClient('http://127.0.0.1:'+str(server.server_port));a=c.analyze(FRAME,scene().ground,CTX)
   self.assertEqual(a['route_id'],0);self.assertTrue(captured['stream']);self.assertEqual(captured['path'],'/api/chat')
   self.assertEqual(captured['options']['num_ctx'],4096);self.assertTrue(captured['messages'][0]['images'])
  finally:server.shutdown();server.server_close();thread.join()

class FreshRouteAdvice(unittest.TestCase):
 def host(self,r=None,heading=90,captured=100):
  h=RouteAdvisor({},lambda _:None);h.latest=Advice(captured,heading,0,route(0,.2) if r is None else r,'passage',CTX,signature(FRAME),4000);return h
 def test_slow_advice_maps_to_a_new_current_route_not_old_screen_id(self):
  h=self.host();g=GroundMap((route(99,.2),route(4,.8)),100)
  self.assertEqual(h.recommend(g,FRAME,105,90,0,CTX),99)
 def test_missing_fresh_route_revokes_old_choice(self):
  self.assertIsNone(self.host().recommend(GroundMap((route(4,.8),),100),FRAME,105,90,0,CTX))
 def test_turn_old_reply_goal_change_and_drop_revoke_advice(self):
  h=self.host();g=scene().ground
  for now,heading,context in ((111,90,CTX),(105,180,CTX),(105,90,{**CTX,'kind':'aether'}),(105,90,{**CTX,'goal_bearing':180})):
   self.assertIsNone(h.recommend(g,FRAME,now,heading,0,context))
  from dataclasses import replace
  self.assertIsNone(h.recommend(replace(g,drop_support=.1),FRAME,105,90,0,CTX))
 def test_unknown_warning_does_not_become_a_stop_order(self):
  h=self.host();h.latest=Advice(100,90,0,None,'unknown',CTX,signature(FRAME),20)
  self.assertIsNone(h.warning(101,90,0,CTX))

class FastMotion(unittest.TestCase):
 def test_without_scene_or_model_navigation_still_produces_translation(self):
  a=HybridPlanner().choose(Drive(.78),None,radar(),100)
  self.assertGreater(a.drive.forward,.5);self.assertLessEqual(a.drive.lifetime,.35)
 def test_explicit_ai_detour_overrides_even_an_open_direct_lane(self):
  p=HybridPlanner();a=p.choose(Drive(.78),scene(free=.95),radar(),100,hint=0)
  self.assertLess(a.drive.strafe,-.2);self.assertTrue(a.detour);self.assertIn('ИИ',a.reason)
  self.assertLessEqual(a.drive.yaw,0)
 def test_failed_bearing_is_avoided_without_changing_destination(self):
  p=HybridPlanner();r=radar();r.motion_valid=True
  a=p.choose(Drive(.7),scene(),r,100,hint=0);self.assertLess(a.drive.strafe,0)
  b=p.choose(Drive(.7),scene(t=104),r,104,hint=0)
  self.assertGreaterEqual(b.drive.strafe,0);self.assertTrue(p.avoid)
 def test_current_wall_causes_actual_camera_survey_not_stationary_wait(self):
  r=scene();from dataclasses import replace
  r=replace(r,ground=GroundMap(),lanes=(Lane(.02,.8,0,.18),)*3)
  p=HybridPlanner();a=p.choose(Drive(.7),r,radar(),100)
  self.assertEqual(a.drive.forward,0);self.assertNotEqual(a.drive.yaw,0)
  self.assertTrue(p.choose(Drive(.7),r,radar(),109).skip)
 def test_cliff_evidence_is_remembered_when_next_local_frame_is_missing(self):
  from dataclasses import replace
  p=HybridPlanner();r=replace(scene(),ground=GroundMap(drop_support=.1))
  p.choose(Drive(.7),r,radar(),100);a=p.choose(Drive(.7),None,radar(),100.5)
  self.assertEqual(a.drive.forward,0);self.assertLessEqual(a.drive.lifetime,.35)
 def test_camp_exit_never_blindly_walks_without_a_ground_frame(self):
  a=HybridPlanner().choose(Drive(.7),None,radar(),100,exit_mode=True)
  self.assertEqual(a.drive.forward,0);self.assertNotEqual(a.drive.yaw,0)

class HybridEngineCases(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();bridge=self.e.bridge;screen=self.e.screen;cfg={**self.e.cfg,'scene_navigation_enabled':True,'analyzer_enabled':True}
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=HybridGatherEngine(cfg,self.log.append,self.input,network=self.source);self.e.bridge=bridge;self.e.screen=screen;self.e.mode='SEARCH'
  self.e.scene_host=SimpleNamespace(offer=lambda *a:None,current=lambda *a:None,error=None,close=lambda:None)
  self.e.analyzer=SimpleNamespace(offer=lambda *a:None,recommend=lambda *a:None,warning=lambda *a:None,busy=True,ready=False,error=None,close=lambda:None)
 def plan(self,reading=None,now=100):
  if reading is not None:self.e.scene_host.current=lambda *a:reading
  with patch('hybrid_engine.time.monotonic',return_value=now):return self.e._scene_plan(self.frame,radar(),FlightReading(None,False),Drive(.78),now)
 def test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion(self):
  for state in ('busy','error','off'):
   if state=='error':self.e.analyzer.busy=False;self.e.analyzer.error='runner failed'
   if state=='off':self.e.analyzer=None
   drive=self.plan();self.assertGreater(drive.forward,.5);self.assertTrue(self.e._motion(drive));self.assertGreater(self.pad.axes[1],.4)
 def test_advisor_really_owns_detour_when_fresh(self):
  self.e.analyzer.recommend=lambda *a:0
  drive=self.plan(scene(free=.95));self.assertLess(drive.strafe,-.2)
 def test_clear_ground_course_does_not_launch_another_expensive_model_request(self):
  with patch.object(self.e.analyzer,'offer') as offer:
   drive=self.plan(scene(free=.95));offer.assert_not_called()
  self.assertGreater(drive.forward,.5);self.assertEqual(drive.strafe,0)
 def test_obstructed_course_still_requests_model_advice_without_blocking_local_policy(self):
  from dataclasses import replace
  with patch.object(self.e.analyzer,'offer') as offer:
   drive=self.plan(replace(scene(),ground=GroundMap(),lanes=(Lane(.02,.8,0,.18),)*3));offer.assert_called_once()
  self.assertEqual(drive.forward,0);self.assertNotEqual(drive.yaw,0)
 def test_confirmed_collection_bypasses_all_ground_advice(self):
  self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
  self.e.analyzer.offer=lambda *a:(_ for _ in ()).throw(AssertionError('model during collection'))
  drive=self.plan(scene());self.assertEqual(drive.forward,.78)
 def test_detour_does_not_throw_away_the_existing_resource_goal(self):
  self.e.nav.update(radar([__import__('minimap').Marker('Самоцвет',150,100,.9,50)]),100)
  goal=self.e.nav.goal;self.e.analyzer.recommend=lambda *a:0;self.plan(scene())
  self.assertIs(self.e.nav.goal,goal)
 def test_native_candidate_can_interrupt_search_while_advisor_is_busy(self):
  self.e.cfg['hybrid_camp_exit']=False
  with patch('hybrid_engine.time.monotonic',return_value=100):self.e.step(self.frame,(0,0),obs(candidate=self.c),radar(),FlightReading(None,False),100)
  self.assertEqual(self.e.mode,'ACQUIRE_WAIT');self.assertIsNotNone(self.e.candidate)
 def test_diagnostic_io_failure_cannot_abort_the_control_loop(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'file';path.write_text('not a directory');self.e.screenshot_path=path;self.e.cfg['debug_screenshots']=True
   self.e.save_debug(FRAME,'test');self.assertFalse(self.e.stop_event.is_set());self.assertTrue(any('DEBUG_SAVE' in x for x in self.log))
 def test_optional_debug_capture_is_bounded_and_leaves_unrelated_files(self):
  with tempfile.TemporaryDirectory() as tmp:
   self.e.screenshot_path=Path(tmp);self.e.cfg['debug_screenshots']=True
   (Path(tmp)/'keep.jpg').write_bytes(b'preserve')
   for i in range(65):self.e.save_debug(FRAME[:20,:20],'test')
   self.assertEqual(len(list(Path(tmp).glob('hybrid_*.jpg'))),60);self.assertTrue((Path(tmp)/'keep.jpg').is_file())
 def test_camp_survey_expires_without_claiming_that_exit_was_reached(self):
  self.e.hybrid_camp_pending=True;self.e.camp_exit_until=90;self.e.camp_last_seen=100
  with patch('hybrid_engine.purple_anchor',return_value=None):self.e._camp_update(self.frame,radar(),100)
  self.assertEqual(self.e.camp_exit_until,0);self.assertFalse(self.e.hybrid_camp_pending);self.assertTrue(any('выход не подтверждён' in m for m in self.log))

class SharedRuntime(unittest.TestCase):
 def test_same_requirements_reuse_environment_across_version_folders(self):
  import runtime_env
  with tempfile.TemporaryDirectory() as tmp,patch.dict('os.environ',{'LOCALAPPDATA':tmp}):
   a=Path(tmp)/'a';b=Path(tmp)/'b';a.mkdir();b.mkdir()
   for p in (a,b):(p/'requirements.txt').write_text('numpy==2.2.6\n')
   env=runtime_env.runtime_dir(a);exe=runtime_env.runtime_python(env);exe.parent.mkdir(parents=True);exe.touch()
   (env/'ready.json').write_text(json.dumps({'requirements_sha256':runtime_env.requirement_hash(a),'python_version':[3,12]}))
   self.assertEqual(runtime_env.find_runtime(b),exe);self.assertFalse((b/'.venv').exists())
   (b/'requirements.txt').write_text('different');self.assertIsNone(runtime_env.find_runtime(b))
 def test_unfinished_environment_is_never_treated_as_ready(self):
  import runtime_env
  with tempfile.TemporaryDirectory() as tmp,patch.dict('os.environ',{'LOCALAPPDATA':tmp}):
   root=Path(tmp);(root/'requirements.txt').write_text('numpy')
   env=runtime_env.runtime_dir(root);exe=runtime_env.runtime_python(env);exe.parent.mkdir(parents=True);exe.touch()
   self.assertIsNone(runtime_env.find_runtime(root))
 def test_launcher_rejects_arbitrary_script_paths(self):
  import launch
  with self.assertRaises(ValueError):launch.main(['../other.py'])

class BoundedAdviceAndRecovery(unittest.TestCase):
 def test_advice_has_three_seconds_of_control_before_a_new_proposal_is_needed(self):
  h=RouteAdvisor({},lambda _:None);h.latest=Advice(100,90,0,route(0,.2),'passage',CTX,signature(FRAME),4000)
  self.assertEqual(h.recommend(scene().ground,FRAME,104,90,0,CTX),0)
  self.assertIsNone(h.recommend(scene().ground,FRAME,107.5,90,0,CTX))
 def test_left_viewpoint_only_turns_and_is_finished_when_new_heading_is_reached(self):
  h=RouteAdvisor({},lambda _:None);h.latest=Advice(100,90,0,None,'passage',CTX,signature(FRAME),4000,-1)
  self.assertEqual(h.recommend(GroundMap(),FRAME,104,90,0,CTX),-2)
  from dataclasses import replace
  r=replace(scene(),ground=GroundMap());a=HybridPlanner().choose(Drive(.7),r,radar(),104,hint=-2)
  self.assertEqual(a.drive.forward,0);self.assertLess(a.drive.yaw,0)
  self.assertIsNone(h.recommend(GroundMap(),FRAME,105,55,0,CTX))
 def test_detour_commit_is_not_immediately_replaced_by_direct_minimap_heading(self):
  p=HybridPlanner();p.choose(Drive(.7),scene(),radar(),100,hint=0)
  a=p.choose(Drive(.7),scene(free=.95),radar(),101)
  self.assertLess(a.drive.strafe,0)
 def test_failed_direct_course_is_not_reintroduced_by_open_lane_shortcut(self):
  p=HybridPlanner();r=radar();r.motion_valid=True
  p.choose(Drive(.7),scene(),r,100,hint=2)
  a=p.choose(Drive(.7),scene(free=.95),r,104)
  self.assertGreater(abs(a.drive.strafe)+abs(a.drive.yaw),.1)
 def test_deep_edge_does_not_allow_direct_route_and_remains_guarded_without_new_frame(self):
  from dataclasses import replace
  p=HybridPlanner();reading=replace(scene(),ground=replace(scene().ground,drop_support=.1))
  a=p.choose(Drive(.7),reading,radar(),100);self.assertEqual(a.drive.forward,0)
  self.assertEqual(p.choose(Drive(.7),None,radar(),120).drive.forward,0)
 def test_sky_does_not_create_an_untracked_permanent_camera_offset(self):
  from dataclasses import replace
  r=replace(scene(),sky=.9,lanes=(Lane(0,0,0,1),)*3)
  a=HybridPlanner().choose(Drive(.7),r,radar(),100)
  self.assertTrue(a.recalibrate);self.assertEqual(a.drive.pitch,0)

class InstallerReuse(unittest.TestCase):
 def test_ready_shared_runtime_does_not_reinstall_dependencies(self):
  import bootstrap
  with tempfile.TemporaryDirectory() as tmp,patch.object(bootstrap,'ROOT',Path(tmp)),patch.object(bootstrap,'find_runtime',return_value=Path(tmp)/'shared/bin/python'),patch.object(bootstrap.subprocess,'run') as run,contextlib.redirect_stdout(io.StringIO()):
   bootstrap.main();self.assertEqual(run.call_count,1)
   self.assertIn('check_scene.py',str(run.call_args.args[0]));self.assertNotIn('pip',run.call_args.args[0]);self.assertFalse((Path(tmp)/'.venv').exists())
 def test_first_setup_uses_external_environment_and_does_not_fill_pip_cache(self):
  import bootstrap
  with tempfile.TemporaryDirectory() as tmp,patch.dict('os.environ',{'LOCALAPPDATA':tmp}),contextlib.redirect_stdout(io.StringIO()):
   root=Path(tmp)/'version';root.mkdir();(root/'requirements.txt').write_text('numpy==2.2.6')
   class Builder:
    def __init__(self,**kw):pass
    def create(self,env):
     executable=bootstrap.runtime_python(env);executable.parent.mkdir(parents=True);executable.touch()
   with patch.object(bootstrap,'ROOT',root),patch.object(bootstrap.venv,'EnvBuilder',Builder),patch.object(bootstrap.subprocess,'run') as run:
    bootstrap.main();calls=[a.args[0] for a in run.call_args_list]
   self.assertIn('--no-cache-dir',calls[0]);self.assertFalse((root/'.venv').exists())
   self.assertIsNotNone(bootstrap.find_runtime(root))

class HybridDefaults(unittest.TestCase):
 def test_free_flight_patrol_is_off_but_bounded_terrain_recovery_remains_available(self):
  from app import DEFAULT
  self.assertFalse(DEFAULT['patrol_escape_enabled']);self.assertFalse(DEFAULT['area_search_rescue'])
  self.assertTrue(DEFAULT['terrain_rescue_enabled']);self.assertFalse(DEFAULT['debug_screenshots'])

class FrameHandoff(unittest.TestCase):
 def test_short_scene_refresh_gap_does_not_fight_committed_detour(self):
  p=HybridPlanner();p.choose(Drive(.7),scene(),radar(),100,hint=0)
  a=p.choose(Drive(.7),None,radar(),100.2)
  self.assertLess(a.drive.strafe,0);self.assertEqual(a.drive.yaw,0);self.assertLessEqual(a.drive.lifetime,.2)
  b=p.choose(Drive(.7),None,radar(),101)
  self.assertEqual(b.drive.strafe,0);self.assertGreater(b.drive.forward,.5)

class DenseGroundFallback(unittest.TestCase):
 def test_missing_avatar_anchor_does_not_stop_walking_on_dense_visible_floor(self):
  from dataclasses import replace
  r=replace(scene(free=.95),ground=GroundMap());a=HybridPlanner().choose(Drive(.7),r,radar(),100)
  self.assertGreater(a.drive.forward,.3);self.assertLessEqual(a.drive.forward,.65)
 def test_false_open_lane_cannot_keep_walking_into_the_same_wall_with_zero_flow(self):
  from dataclasses import replace
  reading=replace(scene(free=.95),ground=GroundMap());r=radar();r.motion_valid=True;p=HybridPlanner()
  p.choose(Drive(.7),reading,r,100);a=p.choose(Drive(.7),reading,r,104)
  self.assertEqual(a.drive.forward,0);self.assertNotEqual(a.drive.yaw,0)

class MotionEvidence(unittest.TestCase):
 def test_unmeasured_time_is_not_counted_as_three_seconds_stuck(self):
  p=HybridPlanner();r=radar()
  p.choose(Drive(.7),scene(),r,100,hint=0);p.choose(Drive(.7),scene(t=110),r,110,hint=0)
  r.motion_valid=True;p.choose(Drive(.7),scene(t=110.1),r,110.1,hint=0)
  self.assertFalse(p.avoid)

class CameraSettling(unittest.TestCase):
 def test_wall_survey_pauses_yaw_for_local_inference_instead_of_invalidating_every_frame(self):
  from dataclasses import replace
  p=HybridPlanner();reading=replace(scene(),ground=GroundMap(),lanes=(Lane(.02,.8,0,.18),)*3)
  self.assertNotEqual(p.choose(Drive(.7),reading,radar(),100).drive.yaw,0)
  a=p.choose(Drive(.7),None,radar(),100.2)
  self.assertEqual(a.drive.yaw,0);self.assertEqual(a.drive.forward,0)
  self.assertNotEqual(p.choose(Drive(.7),reading,radar(),101.1).drive.yaw,0)
