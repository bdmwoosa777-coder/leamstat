"""Real isolated resource captions and live-anchored emblem/body interaction."""
from pathlib import Path
import unittest
from unittest.mock import patch
import cv2
import numpy as np
import gather_engine as ge
import vision
from flight import FlightReading
from resource_clicks import ether_click_points
from test_navigation import GatherFixture
from test_network_control import Source

ROOT=Path(__file__).resolve().parent/'testdata'


def scene(file='ether_near_caption_crop.png',scale=1,x=1100,y=250,badge=True):
    crop=cv2.imread(str(ROOT/file))
    if not badge:crop[:100]=35
    crop=cv2.resize(crop,None,fx=scale,fy=scale)
    frame=np.full((round(1395*scale),round(2480*scale),3),35,np.uint8)
    h,w=crop.shape[:2];x,y=round(x*scale),round(y*scale)
    frame[y:y+h,x:x+w]=crop
    return frame


def ether(frame):
    found=vision.fast_ether_candidates(frame,('Эфир',))
    if not found:raise AssertionError('real Ether caption was missed')
    return found[0]


class EtherRecognition(unittest.TestCase):
    def test_both_real_captions_bypass_ocr_in_five_scales(self):
        with patch.object(vision.pytesseract,'image_to_data',side_effect=AssertionError('OCR')),patch.object(vision.pytesseract,'image_to_string',side_effect=AssertionError('OCR')):
            for file in ('ether_near_caption_crop.png','ether_far_caption_crop.png'):
                for scale in (.6,.8,1,1.25,1.5):
                    with self.subTest(file=file,scale=scale):
                        found=vision.find_world_resource(scene(file,scale))
                        self.assertEqual(found.name,'Эфир');self.assertIsNotNone(found.emblem)
                        x,y,w,h=found.emblem
                        self.assertEqual((found.click_x,found.click_y),(x+w//2,y+h//2))

    def test_visible_caption_does_not_require_the_emblem(self):
        f=scene(badge=False);c=ether(f)
        self.assertIsNone(c.emblem);self.assertGreater(c.click_y,c.box[1]+c.box[3])

    def test_sapphire_word_suffix_is_not_ether_at_any_scale(self):
        for scale in (.6,.8,1,1.25,1.5):
            self.assertEqual(vision.fast_ether_candidates(scene('sapphire_caption_negative.png',scale)),[])

    def test_resource_on_right_below_minimap_is_visible(self):
        self.assertEqual(ether(scene(x=2140,y=700)).name,'Эфир')

    def test_minimap_and_chat_names_are_not_world_resources(self):
        for x,y in ((2140,130),(100,980)):
            self.assertEqual(vision.fast_ether_candidates(scene(x=x,y=y)),[])

    def test_upper_target_title_is_not_a_world_caption(self):
        f=scene()
        c=ether(f);x,y,w,h=c.box
        title=f[y:y+h,x:x+w].copy();f[:]=35;f[45:45+h,1200:1200+w]=title
        self.assertEqual(vision.fast_ether_candidates(f),[])

    def test_emblem_and_green_glow_without_name_do_not_authorize_click(self):
        f=scene();c=ether(f);x,y,w,h=c.box;f[y-2:y+h+2,x-3:x+w+3]=35
        self.assertEqual(vision.fast_ether_candidates(f),[])

    def test_yellow_npc_caption_and_blue_flag_are_not_ether(self):
        f=scene();m=vision.color_mask(f)>0;f[m]=(0,180,240)
        cv2.rectangle(f,(1140,410),(1220,520),(240,160,40),-1)
        self.assertEqual(vision.fast_ether_candidates(f),[])

    def test_dim_green_letters_use_strict_shape_validation(self):
        f=np.full((1395,2480,3),35,np.uint8)
        mask=cv2.imread(str(vision.ROOT/'assets/name_masks/ether_near.png'),0);h,w=mask.shape
        f[350:350+h,1100:1100+w][mask>100]=(105,110,100)
        self.assertEqual(ether(f).glyph_mode,'relaxed')

    def test_dim_central_ether_is_not_starved_by_many_strict_green_components(self):
        import time
        f=np.full((1395,2480,3),35,np.uint8)
        for y in range(180,430,25):
            for x in range(150,1900,70):
                cv2.rectangle(f,(x,y),(x+30,y+10),(120,180,70),1)
        mask=cv2.imread(str(vision.ROOT/'assets/name_masks/ether_near.png'),0);h,w=mask.shape
        f[600:600+h,1200:1200+w][mask>100]=(105,110,100)
        found=vision.fast_ether_candidates(f,('Эфир',),deadline=time.monotonic()+3)
        self.assertTrue(found);self.assertEqual(found[0].glyph_mode,'relaxed')
        self.assertAlmostEqual(found[0].box[0],1200,delta=5)

    def test_ocr_latin_confusables_do_not_require_fuzzy_short_names(self):
        self.assertEqual(vision.clean_match('Эфиp',('Эфир',)),'Эфир')
        for word in ('Эфнр','Сапфир','Эфирный','Дух огня'):
            self.assertIsNone(vision.clean_match(word,('Эфир',)))

    def test_local_tracking_moves_emblem_with_caption_without_ocr(self):
        f=scene();c=ether(f);moved=np.roll(np.roll(f,12,axis=1),7,axis=0)
        found=vision.find_resource_near(moved,c)
        self.assertIsNotNone(found.emblem)
        self.assertAlmostEqual(found.click_x,c.click_x+12,delta=1)
        self.assertAlmostEqual(found.click_y,c.click_y+7,delta=1)

    def test_disappeared_emblem_is_not_retained_as_a_click_point(self):
        f=scene();c=ether(f);x,y,w,h=c.emblem;f[y-10:y+h+10,x-10:x+w+10]=35
        found=vision.find_resource_near(f,c)
        self.assertIsNone(found.emblem);self.assertGreater(found.click_y,found.box[1]+found.box[3])

    def test_unrelated_white_object_is_not_a_resource_emblem(self):
        f=scene(badge=False);c=ether(f);x,y,w,h=c.box
        cv2.rectangle(f,(x+10,y-55),(x+w-10,y-20),(240,240,240),-1)
        self.assertIsNone(vision.locate_resource_emblem(f,c.box))

    def test_downward_fallback_reaches_real_glow_below_name(self):
        for file in ('ether_near_caption_crop.png','ether_far_caption_crop.png'):
            f=scene(file);c=ether(f);pts=ether_click_points(c,f.shape[1],f.shape[0])
            self.assertEqual(len(pts),4);ys=[y for x,y in pts]
            # Both actual glow centres are more than 30 px below caption.
            lower=f[c.box[1]+c.box[3]+30:c.box[1]+c.box[3]+100,c.click_x-12:c.click_x+13]
            _,_,_,(_,gy)=cv2.minMaxLoc(lower[:,:,1])
            glow=c.box[1]+c.box[3]+30+gy
            self.assertTrue(ys[0]<glow<ys[-1]);self.assertLess(min(abs(y-glow) for y in ys),20)


class EmblemControl(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(resource_click_interaction=True,defense_during_approach=False)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.selected=99;self.f.selection_time=1100;self.f.attempt_active=False;self.f.collecting=None
        self.f.nodes[99].template=1500000
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='APPROACH'
        self.clock=100.;self.wall=1100;self.clicks=[];self.callback=lambda:None
        def wait(seconds,*args):self.clock+=seconds;return True
        def click(*args,**kwargs):self.clicks.append(self.positions[-1]);self.callback();return True
        self.input.tap_a=click
        for q in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),patch.object(ge.GamepadInput,'wait',side_effect=wait)):
            q.start();self.addCleanup(q.stop)
        self.frame=scene();self.e.candidate=ether(self.frame)
        self.e.current_size=(self.frame.shape[1],self.frame.shape[0])

    def start(self):
        self.f.collecting=99;self.f.attempt_active=True;self.f.nodes[99].gather_time=self.wall

    def remove_badge(self):
        x,y,w,h=self.e.candidate.emblem;self.frame[y-10:y+h+10,x-10:x+w+10]=35

    def test_first_activation_clicks_emblem_once(self):
        c=self.e.candidate;self.assertTrue(self.e._start_resource_route())
        self.assertEqual(self.clicks,[(c.click_x,c.click_y)])
        self.assertFalse({'TAP_F','F_ON','V','TAB'}&set(self.commands))

    def test_ground_resource_also_uses_emblem(self):
        self.frame=scene('sapphire_caption_negative.png')
        self.e.target='Сапфир';self.f.nodes[99].template=1550020
        self.e.candidate=vision.find_world_resource(self.frame,('Сапфир',))
        c=self.e.candidate;self.assertIsNotNone(c.emblem)
        self.e._start_resource_route();self.assertEqual(self.clicks,[(c.click_x,c.click_y)])

    def test_unproductive_badge_click_falls_back_to_four_lower_points(self):
        self.e._start_resource_route();self.clock+=2.1;self.e._start_resource_route(repeat_click=True)
        self.assertEqual(len(self.clicks),5)
        lower=self.clicks[1:];self.assertTrue(all(b[1]>a[1] for a,b in zip(lower,lower[1:])))
        self.assertTrue(all(y>self.e.candidate.box[1]+self.e.candidate.box[3] for x,y in lower))

    def test_real_start_stops_fallback_and_preserves_wings(self):
        self.e._start_resource_route();self.clock+=2.1
        self.callback=self.start;self.e._start_resource_route(repeat_click=True)
        self.assertEqual(len(self.clicks),2);self.assertNotIn('END_AIR',self.commands)

    def test_missing_badge_does_not_preserve_old_above_caption_offset(self):
        self.remove_badge();fresh=self.e._fresh_click_candidate(self.frame)
        self.assertIsNone(fresh.emblem);self.assertGreater(fresh.click_y,fresh.box[1]+fresh.box[3])
        self.e._start_resource_route();self.assertEqual(len(self.clicks),4)

    def test_badge_disappearing_while_cursor_settles_blocks_old_click(self):
        cursor=self.e.bridge.cursor;calls=[0]
        def move(x,y):
            cursor(x,y);calls[0]+=1
            if calls[0]==1:self.remove_badge()
        self.e.bridge.cursor=move
        self.e._start_resource_route();self.assertEqual(self.clicks,[])

    def test_badge_moves_after_cursor_move_reanchors_before_press(self):
        old=self.e.candidate;cursor=self.e.bridge.cursor;calls=[0]
        def move(x,y):
            cursor(x,y);calls[0]+=1
            if calls[0]==1:self.frame=np.roll(self.frame,12,axis=1)
        self.e.bridge.cursor=move;self.e._start_resource_route()
        self.assertEqual(len(self.clicks),1);self.assertAlmostEqual(self.clicks[0][0],old.click_x+12,delta=1)

    def test_next_attempt_uses_badge_and_keeps_server_counter(self):
        self.f.collecting=99;self.f.attempt_active=False;self.f.nodes[99].gather_time=1000;self.f.nodes[99].used=1
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True;self.e.mode='GATHER';self.e.f_enable()
        self.assertEqual(len(self.clicks),1);self.assertEqual(self.f.nodes[99].used,1)
        self.assertEqual(self.e.next_attempt_click_tries,1)

    def visual_setup(self,badge=True):
        self.frame=scene(badge=badge);self.c=ether(self.frame)
        self.f.selected=0;self.e.cfg['visual_route_hold']=True;self.alt_held=True
        self.e.target_confirmed=False;self.e.network_target=None
        self.e.acquisition_clicked_at=self.clock-.1
        self.e.visual_selection=(1,0,'Эфир',self.clock)

    def test_missing_network_selection_still_activates_visible_badge_once(self):
        self.visual_setup();self.assertTrue(self.e._start_visual_route(self.c,(0,0)))
        self.assertEqual(self.clicks,[(self.c.click_x,self.c.click_y)])
        self.assertEqual(self.e.mode,'VERIFY_NATIVE');self.assertIsNone(self.e.visual_route['distance'])

    def test_missing_selection_body_fallback_uses_four_fresh_points(self):
        self.visual_setup(False)
        with patch.object(ge,'resource_header_visible',return_value=True):
            self.assertTrue(self.e._start_visual_route(self.c,(0,0)))
        self.assertEqual(len(self.clicks),4)
        self.assertTrue(all(b[1]>a[1] for a,b in zip(self.clicks,self.clicks[1:])))

    def test_changed_target_ends_unbound_fallback(self):
        self.visual_setup(False);self.callback=lambda:setattr(self.f,'selected',55)
        with patch.object(ge,'resource_header_visible',return_value=True):
            self.e._start_visual_route(self.c,(0,0))
        self.assertEqual(len(self.clicks),1)
        self.assertIsNone(self.e.visual_route)

    def test_actual_start_during_visual_activation_is_adopted_immediately(self):
        self.visual_setup();self.callback=self.start
        self.assertTrue(self.e._start_visual_route(self.c,(0,0)))
        self.e._resource_fast_tick(self.frame,FlightReading(50,True),self.clock)
        self.assertEqual(self.e.mode,'GATHER');self.assertEqual(len(self.clicks),1)
        self.assertIsNone(self.e.visual_route)

    def test_resource_id_arriving_on_activation_keeps_native_route(self):
        self.visual_setup();self.e.network_target=None
        def selected():self.f.selected=99;self.f.selection_time=self.wall
        self.callback=selected
        self.assertTrue(self.e._start_visual_route(self.c,(0,0)))
        self.assertEqual(self.e.network_target,(1,99));self.assertTrue(self.e.route_active)
        self.assertEqual(self.e.mode,'APPROACH');self.assertEqual(len(self.clicks),1)

    def test_disconnect_during_visual_activation_does_not_create_a_hold(self):
        self.visual_setup();self.callback=lambda:setattr(self.source,'ready',False)
        self.assertFalse(self.e._start_visual_route(self.c,(0,0)))
        self.assertIsNone(self.e.visual_route);self.assertEqual(len(self.clicks),1)


if __name__=='__main__':unittest.main()
