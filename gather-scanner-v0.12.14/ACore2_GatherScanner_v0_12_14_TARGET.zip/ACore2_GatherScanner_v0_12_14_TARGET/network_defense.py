"""Bounded defense against an ID that actually hit this character.

A missing initial NPC spawn profile does not erase a verified hit. Selection
and positive hit evidence are still required; known players/pets/resources
are excluded. This module never sends input itself.
"""
from dataclasses import dataclass
from camera_control import PITCH_STRENGTH

@dataclass
class AirDefenseView:
    started:float
    pitch_start:float
    phase:str='DOWN'
    moved:bool=False
    rounds:int=0
    turn_seconds:float=0
    failed:bool=False

    def down_remaining(self,balance):return max(0.,2-(self.pitch_start-balance)/PITCH_STRENGTH)

def dead(state,actor):
    return actor in state.deaths or bool(state.npcs.get(actor,{}).get('dead'))

def attack_reason(state,actor,wall):
    if state.own is None:return 'не определён ID своего персонажа'
    if actor is None or actor==state.own:return 'нет отдельного агрессора'
    if dead(state,actor):return 'агрессор уже умер'
    if actor in state.players:return 'известный игрок, атака запрещена'
    if actor in state.nodes:return 'ресурс, атака запрещена'
    npc=state.npcs.get(actor)
    if npc and npc.get('summoned'):return 'призванное существо, атака запрещена'
    hit=state.attacks.get(actor)
    if hit is None or not 0<=wall-hit<=12000:return 'нет свежего подтверждённого удара по нашему персонажу'
    if npc and hit<npc.get('born_at',npc.get('time',0)):return 'ID получил новое воплощение после удара'
    if state.selected!=actor:return 'выбран другой ID'
    return None

@dataclass
class NetworkDefense:
    attacker:int
    flow:int
    owner:int
    started:float
    resume:bool=False
    resource:str|None=None
    resource_id:int|None=None
    tabs:int=0
    pairs:int=0
    confirm_at:float|None=None
    tab_requested:int|None=None
    selection_deadline:float=0
    next_attack:float=0
    first_attack:int|None=None
    outgoing_seen:int=0
    reason:str=''
    max_tabs:int=3
    interrupted_at:int|None=None

    def plan(self,state,wall,now):
        if dead(state,self.attacker):return 'DONE'
        if now-self.started>16:
            self.reason='за 16 с не подтверждена смерть агрессора';return 'ABORT'
        if self.tab_requested is not None:
            if state.selection_time>=self.tab_requested:
                self.tab_requested=None;self.confirm_at=None
            elif now>=self.selection_deadline:
                self.reason='нет сетевого ответа на Tab; повторные Tab отменены';return 'ABORT'
            else:return 'WAIT'
        reason=attack_reason(state,self.attacker,wall)
        if reason=='выбран другой ID':
            self.confirm_at=None
            if self.tabs>=self.max_tabs or self.pairs:
                self.reason='выбранный ID не совпал с источником урона';return 'ABORT'
            return 'TAB'
        if reason:
            self.reason=reason;return 'ABORT'
        if self.confirm_at is None:self.confirm_at=now;return 'WAIT'
        if now-self.confirm_at<.18:return 'WAIT'
        if self.pairs<3 and now>=self.next_attack:return 'PAIR'
        return 'WAIT'

    def sent_tab(self,requested,now):
        self.tabs+=1;self.tab_requested=requested;self.selection_deadline=now+1.5

    def sent_pair(self,requested,now):
        self.pairs+=1
        if self.first_attack is None:self.first_attack=requested
        self.next_attack=now+2.0
