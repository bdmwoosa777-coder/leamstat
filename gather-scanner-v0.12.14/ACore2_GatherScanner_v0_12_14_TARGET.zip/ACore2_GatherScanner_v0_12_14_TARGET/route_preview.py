"""Offline passage preview; no controller, capture loop, or game input."""
from pathlib import Path
import argparse,cv2
from model_runner import SegmentationRunner
from depth import DepthRunner
from scene import interpret
from ground_routes import build_ground_map,draw_routes,avatar_foot

def main():
 p=argparse.ArgumentParser();p.add_argument('image',nargs='?');p.add_argument('--cpu',action='store_true');args=p.parse_args()
 filename=args.image
 if not filename:
  import tkinter as tk
  from tkinter import filedialog
  root=tk.Tk();root.withdraw();filename=filedialog.askopenfilename(title='Игровой кадр для проверки проходов',filetypes=[('Images','*.png *.jpg *.jpeg')]);root.destroy()
 if not filename:return
 import numpy as np
 frame=cv2.imdecode(np.fromfile(filename,np.uint8),cv2.IMREAD_COLOR)
 if frame is None:raise RuntimeError('Не удалось прочитать изображение')
 semantic=SegmentationRunner(cpu=args.cpu,log=print);depth=DepthRunner(cpu=args.cpu,log=print)
 labels,conf,_=semantic.predict(frame);groups=interpret(labels,conf,semantic.id2label,threshold=.28).groups;raw,_=depth.predict(frame)
 ground=build_ground_map(groups,raw,avatar_foot(labels,semantic.id2label),conf);out=Path(__file__).resolve().parent/'route_preview.png'
 ok,data=cv2.imencode('.png',draw_routes(frame,ground))
 if not ok:raise RuntimeError('Не удалось сохранить схему')
 out.write_bytes(data.tobytes());print('Маршрутов:',len(ground.routes),'достижимых ячеек:',ground.reachable,'файл:',out)
 import os
 if os.name=='nt':os.startfile(out)
if __name__=='__main__':main()
