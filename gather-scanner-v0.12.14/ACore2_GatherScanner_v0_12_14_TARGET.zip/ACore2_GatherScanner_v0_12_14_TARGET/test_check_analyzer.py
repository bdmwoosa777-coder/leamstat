import contextlib,io,json,tempfile,threading,unittest
from pathlib import Path
from unittest.mock import patch
from http.server import HTTPServer,BaseHTTPRequestHandler
import check_analyzer

class DiagnosticReport(unittest.TestCase):
 def check_response(self,answer,expected):
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*a):pass
   def do_GET(self):self.reply({'version':'test'} if self.path=='/api/version' else {'models':[]})
   def do_POST(self):
    self.rfile.read(int(self.headers['Content-Length']))
    self.reply({'capabilities':['vision']} if self.path=='/api/show' else {'message':{'content':json.dumps(answer)},'done':True,'done_reason':'stop'})
   def reply(self,obj):
    raw=json.dumps(obj).encode();self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   with tempfile.TemporaryDirectory() as folder:
    root=Path(folder);(root/'settings_gather.json').write_text(json.dumps({'analyzer_url':'http://127.0.0.1:'+str(server.server_port),'analyzer_model':'qwen2.5vl:3b'}))
    with patch.object(check_analyzer,'__file__',str(root/'check_analyzer.py')),contextlib.redirect_stdout(io.StringIO()):
     code=check_analyzer.main()
    data=json.loads((root/'analyzer_check.json').read_text());self.assertEqual(data['valid_answer'],expected)
    self.assertEqual(code,0 if expected else 1);self.assertTrue(data['synthetic_image'])
    self.assertEqual(json.loads(data['test_response']['content']),answer)
    self.assertNotIn('images',data);self.assertNotIn('request',data)
  finally:server.shutdown();server.server_close();thread.join()
 def test_rejected_synthetic_response_is_preserved_for_diagnosis(self):self.check_response({'type':'object','properties':{}},False)
 def test_valid_synthetic_response_is_reported_as_valid(self):self.check_response({'route_id':2,'scene':'passage'},True)
