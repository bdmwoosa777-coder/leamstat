import unittest
from unittest.mock import patch
from types import SimpleNamespace
from dataclasses import replace
from scene_navigation import ScenePilot,SceneReading,Lane
from navigation import Drive
from flight import FlightReading
from area_recovery import AreaRecovery
from view_guard import ViewGuard
from test_navigation import GatherFixture,radar
from test_network_control import Source
import gather_engine as ge

EDGE=Lane(.55,0,.09,.2);WALL=Lane(0,.85,.15,.1);FREE=Lane(.95,0,0,.03)
AIR=FlightReading(80,True);GROUND=FlightReading(None,False)
def view(lanes,seq=1,sky=0):return SceneReading(100,0,0,seq,tuple(lanes),sky=sky)

class EscapePolicy(unittest.TestCase):
 def test_edge_confirmation_blocks_even_a_primary_camera_turns_translation(self):
  a=ScenePilot().decide(Drive(.6,.4,.62),view([EDGE]*3),100,80)
  self.assertEqual(a.drive.forward,0);self.assertEqual(a.drive.yaw,0)
 def test_two_frames_of_edge_request_a_real_reverse_escape(self):
  p=ScenePilot();p.decide(Drive(.7),view([EDGE]*3),100,80)
  self.assertTrue(p.decide(Drive(.7),view([EDGE]*3,2),101.1,80).escape)
 def test_duplicate_frame_is_not_two_edge_confirmations(self):
  p=ScenePilot();p.decide(Drive(.7),view([EDGE]*3),100,80)
  self.assertFalse(p.decide(Drive(.7),view([EDGE]*3),102,80).escape)
 def test_sky_triggers_view_repair_before_walking(self):
  a=ScenePilot().decide(Drive(.7),view([Lane(0,0,0,0)]*3,sky=.8),100,80)
  self.assertTrue(a.recalibrate);self.assertEqual(a.drive.forward,0)
 def test_wall_below_resources_can_start_backward_ascent_without_xyz(self):
  p=ScenePilot();p.decide(Drive(.7),view([WALL]*3),100,80,resource_nearby=True)
  self.assertTrue(p.decide(Drive(.7),view([WALL]*3,2),104.1,80,resource_nearby=True).fly)
 def test_unknown_energy_does_not_authorize_that_ascent(self):
  p=ScenePilot();p.decide(Drive(.7),view([WALL]*3),100,None,resource_nearby=True)
  self.assertFalse(p.decide(Drive(.7),view([WALL]*3,2),104.1,None,resource_nearby=True).fly)
 def test_forced_view_repair_uses_bounded_down_pulses(self):
  guard=ViewGuard(.12);guard.force(100)
  with patch('view_guard.scene_view',return_value='sky'):
   action,accepted,failed=guard.update(None,100)
  self.assertLess(action.pitch,0);self.assertEqual(action.lifetime,.12)
  self.assertFalse(accepted);self.assertFalse(failed)

class EscapeEngine(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e.network=self.source;self.e.mode='SEARCH'
  self.e.scene_host=SimpleNamespace(offer=lambda *a:None,current=lambda *a:view([EDGE]*3,2),error=None,close=lambda:None)
  self.e.scene_pilot.edge_since=100;self.e.scene_pilot.edge_seq=1;self.e.scene_pilot.edge_frames=1
 def test_cliff_escape_latches_opposite_world_direction(self):
  with patch.object(ge.time,'monotonic',return_value=101.1):
   plan=self.e._scene_plan(self.frame,radar(heading=0),GROUND,Drive(.7),101.1)
  self.assertLess(plan.forward,0);self.assertEqual(self.e.nav.retreat_bearing,180)
  self.assertGreater(self.e.nav.retreat_until,108);self.assertGreater(self.e.scene_avoid_until,130)
 def test_explicit_escape_is_not_overruled_by_the_next_scene_detour(self):
  self.e.nav.retreat_pending=True;self.e.nav.retreat_until=110
  with patch.object(ge.time,'monotonic',return_value=102):
   plan=self.e._scene_plan(self.frame,radar(heading=0),GROUND,Drive(-.7),102)
  self.assertLess(plan.forward,0)
 def test_active_collection_never_starts_camera_repair(self):
  self.e.scene_host.current=lambda *a:view([Lane(0,0,0,0)]*3,sky=.9)
  self.e.resource_hold=True;self.e.target_confirmed=True
  self.e._scene_plan(self.frame,radar(),GROUND,Drive(.7),100)
  self.assertFalse(self.e.scene_view_repair)
 def test_rescue_handoff_is_not_immediately_folded_by_stray_flight_logic(self):
  r=AreaRecovery(100,80);r.phase='SCAN';r.since=100;r.long_attempt=True
  self.e.cfg['area_search_rescue']=True;self.e.terrain_recovery=r;self.e.mode='RESCUE'
  with patch.object(ge.time,'monotonic',return_value=107):self.e._terrain_recovery_tick(self.frame,AIR,107,radar())
  self.assertEqual(self.e.terrain_recovery.phase,'DESC_DOWN');self.assertEqual(self.e.mode,'RESCUE')
  with patch.object(ge,'gathering_panel_pair',return_value=False):self.e._resource_fast_tick(self.frame,AIR,108,panel=False,slots=None)
  self.assertNotIn('END_AIR',self.commands)
 def test_unknown_island_place_uses_named_map_return_instead_of_bridge_loop(self):
  self.e.cfg['map_safe_return_enabled']=True;self.e.return_exit_guard=True;self.e.return_exit_scan_at=90
  self.e.exit_place='Кряж Транейн';self.e.exit_place_at=100
  with patch.object(self.e,'_start_map_teleport',return_value=True) as start:
   self.e._return_exit_tick(self.frame,GROUND,100);start.assert_called_once_with(100)
  self.assertEqual(self.pad.axes,(0,0,0,0))

if __name__=='__main__':unittest.main()
