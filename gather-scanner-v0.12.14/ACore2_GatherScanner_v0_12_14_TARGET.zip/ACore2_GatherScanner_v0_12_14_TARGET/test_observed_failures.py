"""Models of the user's private log; no actual log/capture content is shipped."""
import struct,unittest
from unittest.mock import patch
from types import SimpleNamespace
import gather_engine as ge
from camera_pitch import PitchLedger
from camera_control import PITCH_STRENGTH
from navigation import Navigator
from network_state import Telemetry
from test_network_state import v,profile,gauge
from test_navigation import GatherFixture,obs
from test_network_control import Source
from test_control_regressions import caption_frame
from vision import caption_candidate
from flight import FlightReading

GROUND=FlightReading(None,False)

class PausedCameraBudget(unittest.TestCase):
    def test_long_combat_does_not_consume_camera_return_budget(self):
        p=PitchLedger();p.balance=.2;p.restore(0);end=p.return_end
        p.pause_return(1);self.assertEqual(p.correction(25),0);self.assertFalse(p.failed)
        p.resume_return(25);self.assertAlmostEqual(p.return_end,end+24)
        self.assertLess(p.correction(25),0);self.assertFalse(p.failed);self.assertAlmostEqual(p.balance,.2)

    def test_nested_acquisition_and_native_hold_resume_only_once(self):
        p=PitchLedger();p.balance=.2;p.restore(0);end=p.return_end
        p.pause_return(1);p.pause_return(2);p.resume_return(4)
        self.assertEqual(p.pause_depth,1);self.assertEqual(p.correction(25),0)
        p.resume_return(25);self.assertEqual(p.pause_depth,0);self.assertEqual(p.return_end,end+24)

    def test_actual_failure_with_time_available_still_expires_without_erasing_offset(self):
        p=PitchLedger();p.balance=.2;p.restore(0)
        p.pause_return(1);p.resume_return(20);p.correction(p.return_end+.1)
        self.assertTrue(p.failed);self.assertAlmostEqual(p.balance,.2)

    def test_new_return_started_inside_pause_uses_its_own_budget(self):
        p=PitchLedger();p.pause_return(0);p.balance=.1;p.restore(10);end=p.return_end
        p.resume_return(12);self.assertEqual(p.return_end,end+2)

class WideSkySearch(unittest.TestCase):
    def test_slow_updates_do_not_skip_upward_pulses(self):
        n=Navigator({'air_search_wide':True,'camera_working_view_ms':850})
        n.air_since=0;n.scan_kind='aether';up=down=0
        for i in range(100):
            plan=n._wide_air_scan(i*.55)
            if plan.restore_pitch:break
            if plan.pitch>0:up+=plan.lifetime
            if plan.pitch<0:down+=plan.lifetime
            self.assertEqual((plan.forward,plan.strafe,plan.yaw),(0,0,0))
        self.assertAlmostEqual(up,20*.078,places=5) # Ten up, twenty down, ten back; signed total stays zero.
        self.assertAlmostEqual(down,20*.078,places=5)
        self.assertTrue(plan.restore_pitch)

    def test_frequent_updates_renew_a_pulse_instead_of_cutting_it_short(self):
        n=Navigator({'air_search_wide':True,'camera_working_view_ms':850});n.air_since=0;n.scan_kind='aether'
        first=n._wide_air_scan(0);again=n._wide_air_scan(.03)
        self.assertLessEqual(first.lifetime,.078);self.assertGreater(again.pitch,0)
        self.assertAlmostEqual(again.lifetime,first.lifetime-.03)
        self.assertEqual(n.scan_last_pulse,0)
        self.assertEqual(n._wide_air_scan(.1).pitch,0)

    def test_initial_raise_stays_within_the_calibrated_upper_limit(self):
        for ms in (770,850,1200):
            n=Navigator({'air_search_wide':True,'camera_working_view_ms':ms});n.air_since=0
            plans=[n._wide_air_scan(i*.55) for i in range(10)]
            total=sum(p.lifetime for p in plans)
            self.assertLessEqual(total,(ms-20)/1000+.000001);self.assertGreater(total,.55)

class ProbeLookAfterRise(unittest.TestCase):
    def test_probe_does_not_close_before_measured_view_has_been_restored(self):
        from flight_probe import FlightProbe
        from minimap import Marker
        p=FlightProbe(Marker('Эфир',106,100,.9,6,'aether'),0,{})
        p.phase_to('PEEK',0)
        action=p.step(1.2,FlightReading(50,True),-.2,90,90)
        self.assertEqual(p.phase,'PEEK');self.assertGreater(action.drive.pitch,0)
        p.step(2,FlightReading(50,True),.07,90,90)
        self.assertEqual(p.phase,'PEEK')
        p.step(3.9,FlightReading(50,True),.07,90,90)
        self.assertEqual(p.phase,'CLOSE')

    def test_probe_view_has_a_finite_deadline_if_camera_does_not_move(self):
        from flight_probe import FlightProbe
        from minimap import Marker
        p=FlightProbe(Marker('Эфир',106,100,.9,6,'aether'),0,{})
        p.phase_to('PEEK',0);p.step(6.1,FlightReading(50,True),-.2,90,90)
        self.assertEqual(p.phase,'CLOSE')

class MissingSelectionProtocol(unittest.TestCase):
    def make(self,known=True,typed=False):
        t=Telemetry({1550020})
        if known:t.feed(1,'008d',gauge(),1)
        if typed:t.feed(1,'3436',profile(),5)
        return t
    def dialog(self,t,at=30,actor=99):return t.feed(1,'318d',bytes(2)+v(actor)+struct.pack('<I',1)+bytes(25),at)
    def interaction(self,t,at=20,source=7):return t.feed(1,'3836',v(99)+v(source)+b'\1',at)

    def test_known_self_unknown_node_without_selection_can_start_from_paired_private_dialog(self):
        t=self.make();self.interaction(t);self.dialog(t)
        s=t.flows[1];self.assertEqual(s.selected,0);self.assertEqual(s.collecting,99)
        self.assertTrue(s.attempt_active);self.assertEqual(s.nodes[99].used,0)
        self.assertEqual(s.nodes[99].gather_time,30)

    def test_private_dialog_can_precede_interaction(self):
        t=self.make();self.dialog(t,20);self.interaction(t,30)
        self.assertEqual(t.flows[1].collecting,99)

    def test_wrong_source_never_becomes_our_collection(self):
        t=self.make();self.interaction(t,source=8);self.dialog(t)
        self.assertIsNone(t.flows[1].collecting)

    def test_self_actor_is_not_a_resource_even_with_matching_source(self):
        t=self.make();t.feed(1,'3836',v(7)+v(7)+b'\1',20);self.dialog(t,30,7)
        self.assertIsNone(t.flows[1].collecting)

    def test_single_private_dialog_is_insufficient(self):
        t=self.make();self.dialog(t);self.assertIsNone(t.flows[1].collecting)

    def test_stale_pair_is_rejected(self):
        t=self.make();self.interaction(t,10);self.dialog(t,2000)
        self.assertIsNone(t.flows[1].collecting)

    def test_known_npc_and_player_never_become_resource(self):
        for role in ('npcs','players'):
            t=self.make();t.flows[1].__getattribute__(role)[99]={} if role=='npcs' else 1
            self.interaction(t);self.dialog(t);self.assertIsNone(t.flows[1].collecting)

    def test_unknown_own_id_requires_a_typed_resource_for_unselected_bootstrap(self):
        t=self.make(known=False);self.interaction(t);self.dialog(t)
        self.assertIsNone(t.flows[1].own)
        t=self.make(known=False,typed=True);self.interaction(t);self.dialog(t)
        self.assertEqual(t.flows[1].own,7);self.assertEqual(t.flows[1].selected,0)
        self.assertEqual(t.flows[1].collecting,99)

    def test_two_interacting_players_are_ambiguous_for_unknown_self(self):
        t=self.make(known=False,typed=True);self.interaction(t,20,7);self.interaction(t,25,8);self.dialog(t)
        self.assertIsNone(t.flows[1].own)

class RouteHoldAndCombat(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(visual_route_hold=True,resource_click_interaction=True)
        self.source=Source();self.e.network=self.source;self.s=self.source.state
        self.s.selected=0;self.s.collecting=None;self.s.attempt_active=False
        self.frame,box=caption_frame();self.c=caption_candidate(self.frame,'Сапфир',box,95)
        self.clock=100.;self.wall=1100;self.clicks=0
        def wait(seconds,*args):self.clock+=seconds;return True
        def click(*args,**kwargs):
            self.clicks+=1
            if self.clicks==1:self.e.visual_selection=(1,0,'Сапфир',self.clock)
            return True
        self.input.tap_a=click
        for q in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),patch.object(ge.GamepadInput,'wait',side_effect=wait)):
            q.start();self.addCleanup(q.stop)

    def enter(self):self.assertTrue(self.e.click_candidate(self.c,(0,0)))

    def test_positive_resource_hud_without_network_id_activates_and_holds_native_path(self):
        self.enter();self.assertEqual(self.clicks,2);self.assertEqual(self.e.mode,'VERIFY_NATIVE')
        self.assertTrue(self.e.resource_hold);self.assertFalse(self.e.target_confirmed)
        self.assertIsNone(self.e.network_target);self.assertEqual(self.pad.axes,(0,0,0,0))
        self.assertFalse({'TAP_F','V','TAB'}&set(self.commands))

    def test_no_manual_retreat_or_probe_while_native_confirmation_is_pending(self):
        self.enter()
        with patch.object(self.input,'drive') as drive:
            for _ in range(20):
                self.clock+=.1;self.assertTrue(self.e._resource_fast_tick(self.frame,GROUND,self.clock))
        drive.assert_not_called();self.assertEqual(self.e.mode,'VERIFY_NATIVE')

    def test_own_start_adopts_node_and_releases_the_visual_hold(self):
        self.enter();self.s.nodes[99].gather_time=1100;self.s.collecting=99;self.s.attempt_active=True
        self.e._resource_fast_tick(self.frame,GROUND,self.clock)
        self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.e.mode,'GATHER')
        self.assertIsNone(self.e.visual_route);self.assertEqual(self.e.pitch.pause_depth,0)

    def test_unknown_template_keeps_the_fresh_visually_confirmed_resource_name(self):
        self.enter();self.s.nodes[99].template=None
        self.s.nodes[99].gather_time=1100;self.s.collecting=99;self.s.attempt_active=True
        self.e._resource_fast_tick(self.frame,GROUND,self.clock)
        self.assertEqual(self.e.target,'Сапфир');self.assertIsNone(self.s.nodes[99].template)
        self.assertEqual(self.e.network_target,(1,99))

    def test_own_start_during_timeout_frame_prevents_cancel_and_preserves_hold(self):
        self.enter();self.clock=self.e.visual_route['until']+.1
        original=self.e.screen.frame
        def frame():
            self.s.collecting=99;self.s.attempt_active=True;self.s.nodes[99].gather_time=1100
            return original()
        self.e.screen.frame=frame
        with patch.object(self.input,'drive') as drive:self.e._verify_visual_route(self.frame,GROUND,self.clock)
        drive.assert_not_called();self.assertIsNotNone(self.e.visual_route)
        self.e._resource_fast_tick(self.frame,GROUND,self.clock)
        self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.e.target,'Сапфир')

    def test_distance_progress_extends_quiet_deadline_with_a_finite_total(self):
        self.enter();start=self.clock
        for distance in (30,25,20,15,10):
            self.clock+=5;self.e.snapshot=(obs('Сапфир',distance=distance),self.clock,1,self.clock)
            self.e._verify_visual_route(self.frame,GROUND,self.clock)
        self.assertEqual(self.e.mode,'VERIFY_NATIVE');self.assertLessEqual(self.e.visual_route['until'],start+35)

    def test_hold_timeout_cancels_only_unconfirmed_path_and_keeps_search_running(self):
        self.enter();self.clock=self.e.visual_route['until']+.1
        self.e._verify_visual_route(self.frame,GROUND,self.clock)
        self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.stop_event.is_set())
        self.assertFalse(self.e.resource_hold);self.assertEqual(self.e.pitch.pause_depth,0)

    def test_unconfirmed_but_distant_route_is_not_cancelled_for_harmless_hits(self):
        self.enter();self.e.visual_route['distance']=25
        self.s.attacks[55]=1050;self.s.npcs[55]={'time':900}
        self.assertFalse(self.e._net_defense(self.clock));self.assertEqual(self.e.mode,'VERIFY_NATIVE')

    def test_near_visual_route_clears_native_hold_before_defending_and_keeps_name(self):
        self.enter();self.e.visual_route['distance']=8
        self.s.attacks[55]=1050;self.s.npcs[55]={'time':900}
        self.assertTrue(self.e._net_defense(self.clock));self.assertEqual(self.e.mode,'DEFENSE')
        self.assertIsNone(self.e.visual_route);self.assertEqual(self.e.pitch.pause_depth,1)
        self.assertEqual(self.e.network_defense.resource,'Сапфир')
        self.clock+=5;self.e._finish_network_defense(True)
        self.assertEqual(self.e.pitch.pause_depth,0);self.assertEqual(self.e.mode,'REACQUIRE')

    def test_unknown_distance_during_visual_native_hold_waits_for_own_gather(self):
        self.enter();self.s.attacks[55]=1050;self.s.npcs[55]={'time':900}
        self.assertFalse(self.e._net_defense(self.clock));self.assertTrue(self.e.resource_hold)

    def test_known_wrong_selected_npc_cannot_use_visual_only_activation(self):
        self.s.selected=55;self.s.npcs[55]={'time':900}
        self.e.acquisition_clicked_at=99;self.e.visual_selection=(1,0,'Сапфир',100)
        self.assertFalse(self.e._visual_route_allowed(self.c))

    def test_stale_or_wrong_name_hud_is_not_an_activation_permission(self):
        self.e.acquisition_clicked_at=100
        self.e.visual_selection=(1,0,'Сапфир',99);self.assertFalse(self.e._visual_route_allowed(self.c))
        self.e.visual_selection=(1,0,'Эфир',100);self.assertFalse(self.e._visual_route_allowed(self.c))

    def test_camera_budget_is_suspended_during_the_native_hold(self):
        self.e.pitch.balance=.1;self.e.pitch.restore(99);self.enter()
        self.clock+=9;self.e.pitch.correction(self.clock);self.assertFalse(self.e.pitch.failed)
        self.e._release_visual_route();self.assertLess(self.e.pitch.correction(self.clock),0)

    def test_reproduced_long_defense_does_not_leave_an_expired_camera_deadline(self):
        self.e.pitch.balance=.2;self.e.pitch.restore(99)
        self.e.network_attacker=55;self.s.attacks[55]=1050;self.s.npcs[55]={'time':900}
        self.e._begin_network_defense(False);self.clock+=22;self.e._finish_network_defense(True)
        self.assertLess(self.e.pitch.correction(self.clock),0);self.assertFalse(self.e.pitch.failed)
        self.assertFalse(self.e.stop_event.is_set())

    def test_defense_lowers_a_raised_camera_before_tab_without_translation(self):
        self.e.pitch.balance=.2;self.e.network_attacker=55
        self.s.attacks[55]=1050;self.s.npcs[55]={'time':900}
        self.e._begin_network_defense(False)
        self.e._network_defense_tick(self.clock)
        self.assertEqual(self.pad.axes[:3],(0,0,0));self.assertLess(self.pad.axes[3],0)
        self.assertNotIn('TAB',self.commands)

    def test_gem_found_during_probe_is_clicked_after_closure_instead_of_abandoning(self):
        from flight_probe import FlightProbe
        from test_navigation import radar
        from minimap import Marker
        goal=Marker('Эфир',100,100,.9,5,'aether');probe=FlightProbe(goal,self.clock,self.e.cfg)
        probe.phase='CLOSE';probe.ground_candidate=self.c;self.e.probe=probe;self.e.mode='PROBE'
        with patch.object(self.e,'click_candidate',return_value=True) as click:
            self.e._probe_step(self.frame,(0,0),obs(candidate=self.c),radar(),GROUND,self.clock)
        click.assert_called_once();self.assertIsNone(self.e.probe)
        self.assertFalse(self.e.nav.is_retreating(self.clock))

if __name__=='__main__':unittest.main()
