"""No chained lookup, input-timed combat interruption, bounded recovery, repeated sprint."""
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import threading,unittest
import gamepad_input as gp,gather_engine as ge,hybrid_engine as he
from gamepad_input import GamepadInput
from hybrid_engine import HybridGatherEngine
from navigation import Navigator,Drive
from network_defense import AirDefenseView
from flight import FlightReading
from test_navigation import GatherFixture,radar
from test_network_control import Source
from test_lookup import marker
from test_xbox_bridge import Reports

GROUND=FlightReading(80,False)

class LookupProgress(unittest.TestCase):
 def setup_scan(self,close=False):
  self.n=Navigator({'air_search_wide':True,'ether_quick_search':True,'air_search_map_radius':22})
  self.r=radar([marker(105 if close else 113)]);self.now=100.
  plans=[]
  for _ in range(16):
   d=self.n.update(self.r,self.now)
   if d.restore_pitch:break
   plans.append(d);self.now=self.n.scan_next_at+.001
  else:self.fail('lookup did not finish')
  return d,plans
 def test_outer_then_near_lookup_cannot_chain_without_walking(self):
  _,plans=self.setup_scan();self.assertEqual(len(plans),13)
  self.r=radar([marker(105)])
  for dt in (1,2,5,20):
   d=self.n.update(self.r,self.now+dt)
   self.assertGreater(abs(d.forward)+abs(d.strafe),.6);self.assertEqual(d.pitch,0);self.assertFalse(d.flight_probe)
  self.assertEqual(self.n.lookup_walk_remaining,1.5)
 def test_near_lookup_is_balanced_thirteen_steps_then_repositions(self):
  d,plans=self.setup_scan(True)
  self.assertEqual(len(plans),13);self.assertFalse(d.flight_probe)
  self.assertAlmostEqual(sum(p.pitch*p.lifetime for p in plans),0)
  self.assertGreater(self.n.update(self.r,self.now+1).forward,.5)
 def test_stopped_or_denied_motion_does_not_spend_required_translation(self):
  self.setup_scan()
  for i in range(10):self.n.track_walk(self.r,False,self.now+i*.3)
  self.assertEqual(self.n.lookup_walk_remaining,1.5)
 def test_delivered_translation_unlocks_the_next_lookup(self):
  self.setup_scan()
  for i in range(7):self.n.track_walk(self.r,True,self.now+i*.3)
  self.assertEqual(self.n.lookup_walk_remaining,0)
  self.r=radar([marker(105)])
  self.assertGreater(self.n.update(self.r,self.now+2).pitch,0)
 def test_long_missing_loop_interval_cannot_count_as_delivered_walk(self):
  self.setup_scan();self.n.track_walk(self.r,True,self.now);self.n.track_walk(self.r,True,self.now+30)
  self.assertEqual(self.n.lookup_walk_remaining,1.5)
 def test_marker_reset_and_exclusion_cannot_bypass_repositioning(self):
  self.setup_scan();self.n.finish_goal(self.now)
  self.n.update(radar([marker(106)]),self.now+1)
  self.assertIsNone(self.n.air_since);self.assertEqual(self.n.lookup_walk_remaining,1.5)
 def test_directly_under_marker_uses_translation_instead_of_another_sky_sweep(self):
  self.setup_scan(True);d=self.n.update(radar([marker(102)]),self.now+1)
  self.assertGreater(d.strafe,.5);self.assertEqual(d.pitch,0)

class CombatProgress(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e
  self.e=HybridGatherEngine({**old.cfg,'preserve_owned_resource':True,'resource_click_interaction':True,
      'collection_event_driven':True,'analyzer_enabled':False},self.log.append,self.input)
  self.e.screen=old.screen;self.e.bridge=old.bridge
  self.source=Source();self.e.network=self.source;self.f=self.source.state;self.node=self.f.nodes[99]
  self.node.template=1500000;self.node.gather_time=1000;self.f.started=1000;self.f.attempt_ordinal=1
  self.f.attacks[55]=1000;self.f.npcs[55]={'time':900,'born_at':900}
  self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
  self.e.network_attacker=55;self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
  self.clock=100.;self.wall=1100
  def wait(seconds,*args):self.clock+=seconds;return True
  for p in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),
      patch.object(GamepadInput,'wait',side_effect=wait),patch.object(ge,'read_flight',return_value=GROUND),
      patch.object(ge,'gathering_panel_pair',return_value=False)):
   p.start();self.addCleanup(p.stop)
 def begin(self):self.e._begin_network_defense(True)
 def tab(self):
  self.wall=2100;self.clock=101.
  with patch.object(self.e,'bridge_cmd',return_value=True):self.e._network_defense_tick(self.clock)
  self.assertEqual(self.e.network_defense.tabs,1)
 def finish(self):
  self.f.collecting=None;self.f.attempt_active=False;self.f.selected=55
  self.e._finish_network_defense(True)
 def test_delayed_first_gauge_during_camera_preparation_cannot_erase_latch(self):
  self.begin();self.f.started=1150;self.node.gather_time=1150
  self.assertIsNone(self.e._own_collection());self.assertIsNotNone(self.e.defense_interrupted)
 def test_actual_tab_recuts_binding_after_the_delayed_gauge(self):
  self.begin();self.f.started=1150;self.node.gather_time=1150;self.tab();self.finish()
  self.assertEqual(self.e.defense_interrupted,(1,99,2100));self.assertFalse(self.e._owned_resource_remaining())
 def test_gauge_arriving_inside_the_tab_press_is_older_than_completed_input(self):
  self.begin();self.wall=2100;self.clock=101.
  def command(*args):
   self.wall=2130;self.f.started=2130;self.node.gather_time=2130
   self.wall=2170;return True
  with patch.object(self.e,'bridge_cmd',side_effect=command):self.e._network_defense_tick(self.clock)
  self.finish();self.assertEqual(self.e.defense_interrupted,(1,99,2170))
  self.assertFalse(self.e._owned_resource_remaining())
 def test_no_tab_or_attack_and_still_active_own_attempt_is_preserved(self):
  self.begin();self.e._finish_network_defense(True)
  self.assertIsNotNone(self.e._own_collection());self.assertIsNone(self.e.defense_interrupted)
 def test_fresh_attempt_after_actual_input_restores_collection_protection(self):
  self.begin();self.tab();self.finish()
  self.f.collecting=99;self.f.selected=99;self.f.started=2200;self.node.gather_time=2200;self.f.attempt_active=True
  self.assertIsNotNone(self.e._own_collection());self.assertIsNone(self.e.defense_interrupted)
  self.assertFalse(self.e._translation_input_ready())
 def test_reacquire_has_eight_seconds_shared_across_retries(self):
  self.begin();self.tab();self.finish();self.assertEqual(self.e.view_recovery.until,109)
  self.clock=105;self.e._begin_reacquire('retry');self.assertEqual(self.e.view_recovery.until,109)
 def test_camera_restoration_cannot_extend_interrupted_resource_deadline(self):
  self.begin();self.tab();self.finish();self.e.defense_restore_view=AirDefenseView(self.clock,0,moved=True)
  def hold(seconds):self.clock+=seconds;return True
  with patch.object(self.e,'_hold_pitch_up',side_effect=hold),patch.object(self.e,'_hold_pitch_down',side_effect=hold):
   self.e._restore_defense_camera()
  self.assertEqual(self.e.view_recovery.until,109);self.assertEqual(self.e.reacquire_until,109)
 def test_expired_interrupted_resource_returns_to_search_without_extra_gather_wait(self):
  self.begin();self.tab();self.finish();self.clock=109.1
  self.assertTrue(self.e._view_recovery_tick(self.frame,GROUND,self.clock))
  self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.network_target);self.assertFalse(self.e.stop_event.is_set())
  self.assertNotIn('F_ON',self.commands)
 def test_visible_live_lower_panel_still_prevents_abandoning_at_deadline(self):
  self.begin();self.tab();self.finish();self.clock=109.1
  with patch.object(ge,'gathering_panel_pair',return_value=True):self.e._view_recovery_tick(self.frame,GROUND,self.clock)
  self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.pad.axes,(0,0,0,0))

class RepeatedSprint(unittest.TestCase):
 def setUp(self):
  self.clock=100.;self.pad=Reports();self.g=GamepadInput(factory=lambda:self.pad,a_button=0x1000)
  self.g.motion_worker=object();self.g.translation_lease_floor=.75;self.stop=threading.Event()
  p=patch.object(gp.time,'monotonic',side_effect=lambda:self.clock);p.start();self.addCleanup(p.stop);self.addCleanup(self.g.close)
 def move(self,at):self.clock=at;self.g.drive(.9)
 def tap(self,authorized=True):
  with patch.object(self.g,'wait',return_value=True):return self.g.tap_sprint(self.stop,lambda:True,lambda:authorized)
 def test_three_second_repeat_preserves_translation_and_does_not_spam_a(self):
  self.move(100);self.move(100.2);self.assertTrue(self.tap())
  for i in range(1,16):
   self.move(100.2+i*.2);result=self.tap()
   self.assertEqual(result,i==15)
  self.assertEqual(self.pad.presses,2);self.assertEqual(self.pad.axes[1],.9);self.assertEqual(self.pad.buttons,0)
 def test_repeat_is_rechecked_and_blocked_when_collection_or_hazard_revokes_authorization(self):
  self.move(100);self.move(100.2);self.tap()
  for t in (101,102,103,103.3):self.move(t)
  self.assertFalse(self.tap(False));self.assertEqual(self.pad.presses,1)
 def test_expired_lease_cannot_dash_at_rest_when_repeat_timer_is_due(self):
  self.move(100);self.move(100.2);self.tap();self.clock=104
  with self.g.lock:self.g._expire_motion(self.clock)
  self.assertFalse(self.tap());self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.axes,(0,0,0,0))

if __name__=='__main__':unittest.main()
