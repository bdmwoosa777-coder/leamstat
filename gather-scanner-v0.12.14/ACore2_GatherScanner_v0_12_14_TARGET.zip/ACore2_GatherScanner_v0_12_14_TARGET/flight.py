"""Validate the curved HUD track before measuring flight energy (sky is not a gauge)."""
from dataclasses import dataclass
import numpy as np
from functools import lru_cache


@dataclass
class FlightReading:
    energy: float | None
    confirmed: bool
    evidence: int = 0


@lru_cache(maxsize=16)
def _flight_samples(h,w):
    yy=np.arange(476,727,dtype=float)
    xx=1047+46*((yy-597)/123)**2
    offset=max(3,round(12*w/2560));ys=[];xs=[]
    for dy in range(-40,33,6):
        y=np.rint((yy+180+dy)*h/1440).astype(int)
        if y.min()<0 or y.max()>=h:continue
        for dx in range(-12,15,3):
            x=np.rint((xx+dx)*w/2560).astype(int)
            if x.min()<offset or x.max()+offset>=w:continue
            ys.append(y);xs.append(x)
    return np.asarray(ys),np.asarray(xs),offset


def read_flight(frame):
    """Same track tests, batched across all HUD offsets instead of Python scans."""
    h,w=frame.shape[:2]
    if w<900 or h<600:return FlightReading(None,False)
    ys,xs,offset=_flight_samples(h,w)
    if not len(ys):return FlightReading(None,False,0)
    c=frame[ys,xs].astype(np.int16)
    l=frame[ys,xs-offset].astype(np.int16);r=frame[ys,xs+offset].astype(np.int16)
    b,g,red=c[:,:,0],c[:,:,1],c[:,:,2]
    cyan=(g-red>22)&(b-red>15)&(g>145)&(b>130)
    low=(red-g>45)&(red-b>35)&(red>130)
    v=c.max(axis=2);side_low=np.minimum(l.max(axis=2),r.max(axis=2))
    side_high=np.maximum(l.max(axis=2),r.max(axis=2))
    fill=(cyan|low)&(v-side_high>18);track=v<side_low-18
    scores=(fill|track).sum(axis=1);raw_best=int(scores.max())
    valid=(fill.sum(axis=1)>=6)&(fill[:,-25:].sum(axis=1)>=2)
    if not valid.any():return FlightReading(None,False,raw_best)
    i=int(np.argmax(np.where(valid,scores,-1)));score=int(scores[i]);fill=fill[i]
    if score<110:return FlightReading(None,False,raw_best)
    smooth=np.convolve(fill.astype(int),np.ones(5,dtype=int),mode='same')>=2
    positions=np.flatnonzero(smooth)
    if len(positions)<2:return FlightReading(0.0,True,score)
    if smooth[-25:].sum()<2:return FlightReading(None,True,score)
    energy=round(float((len(fill)-positions[0])/len(fill)*100),1)
    return FlightReading(energy,True,score)


class FlightBudget:
    def __init__(self,low=8.0,resume=18.0,recovery=.55,retry_delay=3.0):
        self.low,self.resume,self.recovery=low,resume,recovery
        self.retry_delay=max(1.0,retry_delay)
        self.energy=None;self.last_time=None;self.airborne=False;self.ground_since=None
        self.blocked=False;self.retry_after=0.0;self.failures=0;self.reason=''

    def failed_takeoff(self,now):
        # Missing confirmation is not proof of zero energy. Back off globally,
        # rather than toggling V again as soon as a different node is selected.
        self.failures=min(5,self.failures+1)
        self.retry_after=max(self.retry_after,now+min(30,self.retry_delay*2**(self.failures-1)))
        self.blocked=True;self.ground_since=now
        self.reason='раскрытие крыльев не подтверждено'

    def update(self,reading,now):
        if reading.confirmed:
            self.airborne=True;self.ground_since=None
            if reading.energy is not None:
                self.energy=reading.energy
                if self.energy<self.low:self.blocked=True;self.reason='мало энергии'
                elif self.energy>=self.resume:
                    self.failures=0;self.retry_after=0;self.blocked=False;self.reason=''
        else:
            if self.ground_since is None:self.ground_since=now
            if now-self.ground_since>1.5:
                self.airborne=False
                if self.energy is not None and self.last_time is not None:
                    # A long pause cannot prove uninterrupted regeneration.
                    self.energy=min(100,self.energy+max(0,min(1.0,now-self.last_time))*self.recovery)
        self.last_time=now
        if now<self.retry_after:self.blocked=True
        elif self.energy is None or self.energy>=self.resume:
            self.blocked=False;self.reason=''
        elif self.energy<self.low:self.blocked=True

    def can_start(self):return not self.blocked

    def can_probe(self,minimum=18):
        return self.can_start() and (self.energy is None or self.energy>=minimum)

    def describe(self,now):
        value='не измерена' if self.energy is None else f'{self.energy:.1f}% (измерение/оценка)'
        wait=max(0,self.retry_after-now)
        rule=f'возврат от {self.resume:.0f}%' if self.energy is not None else 'затем одна проверочная попытка'
        return f'энергия {value}; {self.reason or "ожидание восстановления"}; защитная задержка {wait:.0f} с, {rule}'
