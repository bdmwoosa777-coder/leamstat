"""Aether-first selection with ground gathering during energy recovery."""
class ResourcePolicy:
    def __init__(self,cfg):
        self.priority=bool(cfg.get('only_aether'))
        self.low=float(cfg.get('aether_priority_low_percent',20))
        self.resume=max(self.low+5,float(cfg.get('aether_priority_resume_percent',35)))
        self.recovering=None;self.air_ready=True
        self.absence_seconds=max(5,float(cfg.get('aether_absence_seconds',30)))
        self.map_at=None;self.searching=False;self.absent_for=0.;self.ground_fallback=False;self.air_on_map=False

    def observe_map(self,markers,now,searching=True):
        """Only active search time counts; menus, combat and collection do not."""
        self.air_on_map=any(m.kind=='aether' for m in markers)
        if self.air_on_map:self.absent_for=0.;self.ground_fallback=False
        elif searching and self.searching and self.map_at is not None:
            self.absent_for+=max(0,min(2.,now-self.map_at))
            self.ground_fallback=self.absent_for>=self.absence_seconds
        self.searching=searching;self.map_at=now

    def update(self,budget):
        self.air_ready=budget.can_start()
        if not self.priority:return
        energy=budget.energy
        if not self.air_ready:self.recovering=True
        elif energy is None and self.recovering and budget.failures:
            # A missing measurement is not zero. The flight budget has already
            # enforced its bounded retry delay; allow one new measured attempt.
            self.recovering=None
        elif energy is not None:
            if self.recovering is None:self.recovering=energy<self.resume
            elif self.recovering and energy>=self.resume:self.recovering=False
            elif not self.recovering and energy<=self.low:self.recovering=True

    def allows(self,name):
        if name=='Эфир':return self.air_ready and (not self.priority or not self.recovering)
        return not self.priority or bool(self.recovering) or self.ground_fallback

    def names(self,names):return tuple(n for n in names if self.allows(n))
