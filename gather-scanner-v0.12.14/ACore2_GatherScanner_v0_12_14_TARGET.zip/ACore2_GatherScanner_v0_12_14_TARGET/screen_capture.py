import os
import threading,time
import numpy as np


class ScreenCapture:
    def __init__(self):
        self.hwnd=None;self.title='';self._captures=threading.local();self.last_capture=None
        if os.name=='nt':
            import win32gui
            self.win32gui=win32gui

    def pick(self):
        if os.name!='nt':return 'OFFLINE'
        options=[]
        def cb(h,_):
            if self.win32gui.IsWindowVisible(h):
                name=self.win32gui.GetWindowText(h)
                if 'aion2' in name.lower() or 'aion 2' in name.lower():options.append((h,name))
        self.win32gui.EnumWindows(cb,None)
        if not options:return None
        self.hwnd,self.title=options[0];return self.title

    def focused(self):
        return os.name!='nt' or self.hwnd is not None and self.win32gui.GetForegroundWindow()==self.hwnd

    def frame(self):
        if os.name!='nt':raise RuntimeError('Захват игры доступен только на Windows')
        if not self.hwnd or not self.win32gui.IsWindow(self.hwnd):raise RuntimeError('Окно AION2 не найдено')
        left,top=self.win32gui.ClientToScreen(self.hwnd,(0,0))
        _,_,w,h=self.win32gui.GetClientRect(self.hwnd)
        import mss
        holder=getattr(self._captures,'holder',None)
        if holder is None:
            holder=_CaptureSession(mss.mss());self._captures.holder=holder
        began=time.monotonic()
        try:frame=np.array(holder.capture.grab({'left':left,'top':top,'width':w,'height':h}))[:,:,:3].copy()
        except Exception:
            holder.close();del self._captures.holder;raise
        self.last_capture=(time.monotonic(),time.monotonic()-began,threading.current_thread().name)
        return frame,(left,top)

class _CaptureSession:
    """Thread-local MSS/GDI handles; pixels are always grabbed again."""
    def __init__(self,capture):self.capture=capture
    def close(self):
        if self.capture is not None:
            capture=self.capture;self.capture=None;capture.close()
    def __del__(self):
        try:self.close()
        except Exception:pass
