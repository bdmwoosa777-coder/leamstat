"""Delivered movement, open-floor pursuit, wall escapes, and finite list navigation."""
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import math,threading,unittest
import numpy as np
import gamepad_input as gp
import hybrid_engine as he
import map_teleport as mt
from hybrid_navigation import HybridPlanner
from hybrid_engine import HybridGatherEngine
from gamepad_input import GamepadInput
from navigation import Drive
from flight import FlightReading
from ground_routes import GroundMap
from scene_navigation import Lane
from test_navigation import GatherFixture,radar
from test_network_control import Source
from test_hybrid import scene
from test_motion import wall
from test_xbox_bridge import Reports

GROUND=FlightReading(80,False)

class ActivePlanner(unittest.TestCase):
 def start(self,camp=False):
  p=HybridPlanner();p.choose(Drive(.78),wall(100),radar(),100,exit_mode=camp);return p
 def test_wall_becomes_translation_and_jump_after_one_second(self):
  p=self.start();a=p.choose(Drive(.78),wall(101.1),radar(),101.1)
  self.assertTrue(a.escape);self.assertTrue(a.jump);self.assertGreater(abs(a.drive.strafe),.7)
  self.assertLess(a.drive.forward,0);self.assertEqual(a.drive.yaw,0);self.assertGreaterEqual(a.drive.lifetime,.65)
 def test_same_side_is_held_for_several_frames_and_jump_is_not_spammed(self):
  p=self.start();actions=[p.choose(Drive(.78),wall(t),radar(),t) for t in (101.1,101.7,102.3,102.9)]
  self.assertEqual(len({a.drive.strafe for a in actions}),1)
  self.assertEqual([a.jump for a in actions],[True,False,False,True])
 def test_next_leg_changes_side_only_after_a_real_sideways_attempt(self):
  p=self.start();a=p.choose(Drive(.78),wall(101.1),radar(),101.1)
  b=p.choose(Drive(.78),wall(104.4),radar(),104.4)
  self.assertLess(a.drive.strafe*b.drive.strafe,0)
 def test_camp_uses_the_same_active_ground_escape(self):
  p=self.start(True);a=p.choose(Drive(.78),wall(101.2),radar(),101.2,exit_mode=True)
  self.assertTrue(a.escape);self.assertGreater(abs(a.drive.strafe),.7)
 def test_cliff_revokes_translation_jump_and_flight(self):
  p=self.start();p.choose(Drive(.78),wall(101.1),radar(),101.1)
  a=p.choose(Drive(.78),wall(101.7,drop=.2),radar(),101.7)
  self.assertFalse(a.escape);self.assertFalse(a.jump);self.assertEqual(a.drive.forward,0)
  self.assertFalse(p.choose(Drive(.78),wall(108),radar(),108).wall_escape)
 def test_side_depth_edge_uses_the_other_side_when_it_has_no_edge(self):
  p=self.start();view=replace(wall(101.1),lanes=(Lane(.5,.2,.1,.2),Lane(.1,.8,0,.1),Lane(.1,.8,0,.1)))
  a=p.choose(Drive(.78),view,radar(),101.1);self.assertTrue(a.escape);self.assertGreater(a.drive.strafe,0)
 def test_rock_depth_outline_cancels_current_jump_without_inventing_a_permanent_cliff(self):
  p=self.start();outlined=replace(wall(101.1),lanes=(Lane(.02,.8,.1,.1),)*3)
  self.assertFalse(p.choose(Drive(.78),outlined,radar(),101.1).escape)
  self.assertTrue(p.choose(Drive(.78),wall(101.7),radar(),101.7).escape)
 def test_missing_or_turned_or_sky_frame_is_not_authority_to_jump(self):
  for kind in ('missing','turned','sky'):
   p=self.start();p.choose(Drive(.78),wall(101.1),radar(),101.1)
   view=None if kind!='sky' else replace(wall(101.4),sky=.8)
   r=radar(heading=160 if kind=='turned' else 90);t=103 if kind=='missing' else 101.4
   self.assertFalse(p.choose(Drive(.78),view,r,t).escape,kind)
 def test_real_displacement_resets_stuck_budget(self):
  p=self.start();p.escape_walk_seconds=3.2;r=radar();r.motion_valid=True;r.displacement=(4,0)
  a=p.choose(Drive(.78),wall(102),r,102)
  self.assertFalse(a.escape);self.assertEqual(p.escape_walk_seconds,0)
 def test_camera_time_does_not_authorize_wings(self):
  p=self.start();a=p.choose(Drive(.78),wall(108),radar(),108)
  self.assertTrue(a.skip);self.assertFalse(a.wall_escape)
 def test_actual_sideways_commands_then_still_blocked_can_authorize_short_flight(self):
  p=self.start()
  for t in (101.1,101.7,102.3,102.9,103.5,104.1,104.7):
   r=radar();r.motion_valid=True
   a=p.choose(Drive(.78),wall(t),r,t);self.assertTrue(a.escape);p.note_escape_motion(t)
  r=radar();r.motion_valid=True
  a=p.choose(Drive(.78),wall(105.3),r,105.3);p.note_escape_motion(105.3)
  a=p.choose(Drive(.78),wall(105.9),r,105.9);p.note_escape_motion(105.9)
  a=p.choose(Drive(.78),wall(106.5),r,106.5);p.note_escape_motion(106.5)
  a=p.choose(Drive(.78),wall(107.1),r,107.1);p.note_escape_motion(107.1)
  a=p.choose(Drive(.78),wall(107.7),r,107.7);p.note_escape_motion(107.7)
  a=p.choose(Drive(.78),wall(108),r,108)
  self.assertTrue(a.wall_escape);self.assertGreater(p.wall_flight_proven_until,108)
 def test_sent_steps_without_measured_stagnation_do_not_authorize_flight(self):
  p=self.start()
  for t in (101.1,101.7,102.3,102.9,103.5,104.1,104.7,105.3,105.9,106.5,107.1,107.7):
   p.choose(Drive(.78),wall(t),radar(),t);p.note_escape_motion(t)
  self.assertFalse(p.choose(Drive(.78),wall(108),radar(),108).wall_escape)
 def test_open_floor_or_level_water_does_not_need_a_connected_graph(self):
  for free in (.38,.50,.90):
   view=replace(scene(t=100,free=free),ground=GroundMap())
   a=HybridPlanner().choose(Drive(.78),view,radar(),100,face_goal=True)
   self.assertGreater(a.drive.forward,.6);self.assertEqual(a.drive.yaw,0);self.assertFalse(a.skip)
 def test_open_side_lane_walks_towards_ether_while_turning(self):
  a=HybridPlanner().choose(Drive(.05,.78,.62),scene(t=100,free=.9),radar(),100,face_goal=True)
  self.assertGreater(a.drive.strafe,.6);self.assertGreater(a.drive.yaw,0)
 def test_behind_camera_or_cliff_still_requires_facing_before_translation(self):
  for plan,view in ((Drive(-.7,.3,.62),scene(t=100,free=.9)),(Drive(.05,.78,.62),wall(100,drop=.2))):
   a=HybridPlanner().choose(plan,view,radar(),100,face_goal=True)
   self.assertEqual((a.drive.forward,a.drive.strafe),(0,0))

class MovingJump(unittest.TestCase):
 def setUp(self):
  self.pad=Reports();self.g=GamepadInput(factory=lambda:self.pad,a_button=0x1000);self.g.motion_worker=object()
  self.addCleanup(self.g.close);self.stop=threading.Event()
 def test_jump_does_not_release_stick_or_extend_lease(self):
  self.g.drive(-.42,.78,lifetime=.7);deadline=self.g.translation_deadline;reports=[]
  def wait(seconds,*a):reports.extend(self.pad.reports);return True
  with patch.object(self.g,'wait',side_effect=wait):self.assertTrue(self.g.tap_moving_jump(self.stop,lambda:True,lambda:True))
  self.assertTrue(any(buttons&0x4000 and axes[0]==.78 for buttons,lt,axes in reports))
  self.assertEqual(self.pad.axes[:2],(.78,-.42));self.assertEqual(self.pad.buttons,0)
  self.assertEqual(self.g.translation_deadline,deadline)
 def test_stationary_cursor_or_new_collection_never_gets_jump(self):
  self.assertFalse(self.g.tap_moving_jump(self.stop,lambda:True,lambda:True))
  self.g.drive(.7);self.assertFalse(self.g.tap_moving_jump(self.stop,lambda:True,lambda:False))
  self.g.cursor_held=True;self.assertFalse(self.g.tap_moving_jump(self.stop,lambda:True,lambda:True))
  self.assertEqual(self.pad.buttons,0)
 def test_loss_of_focus_mid_jump_releases_everything(self):
  self.g.drive(.7)
  with patch.object(self.g,'wait',return_value=False):self.assertFalse(self.g.tap_moving_jump(self.stop,lambda:True,lambda:True))
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.buttons,0)
 def test_watchdog_can_release_x_without_a_successful_return(self):
  self.g.drive(.7);self.g.jump_deadline=100;self.pad.press_button(button=0x4000)
  self.g._expire_motion(100.1);self.assertFalse(self.pad.buttons&0x4000)

class ActiveEngine(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e;self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=HybridGatherEngine({**old.cfg,'terrain_rescue_enabled':True,'area_search_rescue':True,'hybrid_camp_exit':False,'analyzer_enabled':False},self.log.append,self.input,network=self.source)
  self.e.screen=old.screen;self.e.bridge=old.bridge;self.e.mode='SEARCH';self.e.target=None;self.e.budget.energy=80
  self.clock=100;timer=patch.object(he.time,'monotonic',side_effect=lambda:self.clock);timer.start();self.addCleanup(timer.stop)
  self.e.scene_host=SimpleNamespace(offer=lambda *a:None,current=lambda *a:wall(self.clock))
  self.input.motion_worker=object();self.e.bridge.controller_native=True
 def plan(self):return self.e._scene_plan(self.frame,radar(),GROUND,Drive(.78),self.clock)
 def escape(self):
  self.plan();self.clock=101.2;d=self.plan();self.assertGreater(abs(d.strafe),.7);return d
 def test_real_escape_reports_x_with_translation_and_credits_delivered_movement(self):
  d=self.escape();buttons=[];original=self.pad.press_button
  def press(button):buttons.append((button,self.pad.axes));return original(button)
  self.pad.press_button=press
  with patch.object(self.input,'wait',return_value=True):self.e._motion(d)
  self.assertTrue(any(b==0x4000 and abs(axes[0])>.7 for b,axes in buttons));self.assertIsNotNone(self.e.hybrid.escape_walk_at)
  self.assertGreater(abs(self.pad.axes[0]),.7);self.assertEqual(self.pad.buttons,0)
 def test_private_start_after_plan_blocks_movement_and_jump(self):
  d=self.escape();self.source.state.attempt_active=True
  with patch.object(self.input,'tap_moving_jump') as jump:self.e._motion(d);jump.assert_not_called()
  self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_collection_arriving_during_last_frame_cancels_jump_and_translation(self):
  d=self.escape()
  def frame():self.source.state.attempt_active=True;return self.frame,(0,0)
  self.e.screen.frame=frame
  with patch.object(self.input,'wait',return_value=True):self.e._motion(d)
  self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_timeout_without_collision_proof_is_ground_only(self):
  self.assertTrue(self.e._start_terrain_recovery(100,GROUND));self.assertFalse(self.e.terrain_recovery.fly)
 def test_short_flight_is_denied_without_delivered_ground_escape(self):
  self.assertFalse(self.e._start_terrain_recovery(100,GROUND,short=True));self.assertIsNone(self.e.terrain_recovery)
 def test_fresh_rapid_drop_keeps_real_fall_recovery_available(self):
  with patch.object(self.e.working_area,'rapid_drop',return_value=True):self.assertTrue(self.e._start_terrain_recovery(100,GROUND))
  self.assertTrue(self.e.terrain_recovery.fly)
 def test_explicit_wall_flight_moves_to_one_side_instead_of_cancelling_sideways_legs(self):
  self.e.hybrid.problem_since=90;self.e.hybrid.escape_walk_seconds=3.2;self.e.hybrid.escape_still_seconds=2;self.e.hybrid.escape_still_at=100
  self.assertIsNone(self.plan());r=self.e.terrain_recovery;self.assertTrue(r.lateral_escape)
  r.phase='RISE';r.since=100
  a=r.step(100.4,FlightReading(80,True),-.9);b=r.step(102,FlightReading(80,True),-.9)
  self.assertGreater(a.drive.strafe*b.drive.strafe,0);self.assertGreater(abs(a.drive.strafe),.6)
 def test_stop_and_lost_focus_revoke_escape_authority(self):
  self.escape();self.e.stop_event.set();self.assertFalse(self.e._obstacle_action_ready())
  self.e.stop_event.clear();self.e.screen.focused=lambda:False;self.assertFalse(self.e._obstacle_action_ready())

class FiniteMapList(unittest.TestCase):
 def o(self,a,b,p=0):return mt.MapObservation(True,list_first=a,list_last=b,list_signature=np.full((24,40),p,np.uint8))
 def test_48_of_61_starts_with_fast_seek_to_end(self):
  m=mt.MapTeleport(0);a=m.step(0,self.o(1,9))
  self.assertEqual((a.kind,a.direction,a.scroll_mode),('SCROLL',-1,'end'));self.assertEqual(a.scroll_seconds,.65)
 def test_bottom_is_verified_then_searches_upwards_towards_48(self):
  m=mt.MapTeleport(0);m.step(0,self.o(1,9));a=m.step(1,self.o(53,61,10))
  self.assertEqual((a.kind,a.direction,a.scroll_mode),('SCROLL',1,'fine'));self.assertLessEqual(a.scroll_seconds*a.scroll_scale,.065)
 def test_target_seen_during_fast_seek_is_selected_without_another_scroll(self):
  m=mt.MapTeleport(0);m.step(0,self.o(1,9));o=replace(self.o(44,52,10),row=(80,500))
  self.assertEqual(m.step(1,o).kind,'ROW')
 def test_nearby_and_top_half_destinations_do_not_seek_bottom(self):
  for index,a,b in ((13,1,9),(48,40,46),(5,9,16)):
   action=mt.MapTeleport(0,index=index).step(0,self.o(a,b))
   self.assertNotEqual(action.scroll_mode,'end')
 def test_list_can_scroll_again_after_short_settling_interval(self):
  m=mt.MapTeleport(0);m.step(0,self.o(1,9));m.sent(1)
  self.assertEqual(m.step(1.1,self.o(15,23,10)).kind,'WAIT')
  self.assertEqual(m.step(1.2,self.o(15,23,10)).kind,'SCROLL')
 def test_wrong_destination_still_cannot_authorize_payment(self):
  m=mt.MapTeleport(0);o=mt.MapObservation(True,popup=True,destination='Другая точка',confirm=(1000,500))
  self.assertEqual(m.step(0,o).kind,'FAILED');self.assertFalse(m.used)
 def test_list_only_observation_uses_only_one_ocr_region_after_map_stamp_proof(self):
  f=np.zeros((720,1280,3),np.uint8);regions=[]
  def lines(frame,region,*args,**kwargs):regions.append(region);return [mt.Line('48. Рабочий лагерь стальн...', (20,300,200,20))]
  with patch.object(mt,'lines',side_effect=lines),patch.object(mt,'is_map',side_effect=AssertionError('redundant full OCR')),patch.object(mt,'confirmation_dialog',side_effect=AssertionError('no modal before row click')):
   o=mt.observe(f,mt.DEFAULT_DESTINATION,'WAIT_SCROLL',index=48,verified_map=True,list_only=True)
  self.assertEqual(regions,[(0,.13,.225,.97)]);self.assertIsNotNone(o.row);self.assertFalse(o.popup)
 def test_unverified_frame_cannot_take_the_list_only_shortcut(self):
  with patch.object(mt,'is_map',return_value=False),patch.object(mt,'confirmation_dialog',return_value=None):
   o=mt.observe(np.zeros((720,1280,3),np.uint8),mt.DEFAULT_DESTINATION,'FIND',list_only=True)
  self.assertFalse(o.opened)
 def test_long_hold_has_a_watchdog_deadline_beyond_the_requested_scroll(self):
  pad=Reports();g=GamepadInput(factory=lambda:pad,a_button=0x1000);g.motion_worker=object();self.addCleanup(g.close)
  g.map_scroll_seconds=.65;g.map_scroll_strength=.85;durations=[]
  def wait(seconds,*args):durations.append(seconds);return True
  with patch.object(g,'wait',side_effect=wait):self.assertTrue(g.scroll_map_list(-1,threading.Event(),lambda:True,lambda:True))
  self.assertEqual(durations[-1],.65);self.assertEqual(pad.axes,(0,0,0,0));self.assertEqual(pad.lt,0)
 def test_stop_during_long_scroll_releases_trigger_and_stick(self):
  pad=Reports();g=GamepadInput(factory=lambda:pad,a_button=0x1000);g.motion_worker=object();self.addCleanup(g.close)
  g.map_scroll_seconds=.65
  with patch.object(g,'wait',side_effect=[True,False]):self.assertFalse(g.scroll_map_list(-1,threading.Event(),lambda:True,lambda:True))
  self.assertEqual(pad.axes,(0,0,0,0));self.assertEqual(pad.lt,0)

if __name__=='__main__':unittest.main()
