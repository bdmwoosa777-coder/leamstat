@echo off
chcp 65001 >nul
cd /d "%~dp0"
call RUN_PYTHON.bat setup_analyzer.py
pause
