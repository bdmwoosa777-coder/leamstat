import unittest,threading
from unittest.mock import patch
from dataclasses import replace
from types import SimpleNamespace
import numpy as np,cv2
from PIL import Image,ImageDraw,ImageFont
from pathlib import Path
from map_teleport import MapTeleport as ProductionTrip,MapObservation,observe,exact_name,menu_stamp,same_stamp
from functools import partial
NAME='Временный приют' # Legacy screenshots remain an explicit, configurable test destination.
MapTeleport=partial(ProductionTrip,destination=NAME,index=13)
from gamepad_input import GamepadInput
from test_navigation import Pad,GatherFixture,radar
from test_network_control import Source
from flight import FlightReading
import gather_engine as ge

FONT=next((str(p) for p in (Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),Path('C:/Windows/Fonts/arial.ttf')) if p.is_file()),None)
def map_frame(row=True,popup=False,wrong=False,icon=False,inactive=False):
 if FONT is None:raise unittest.SkipTest('A Cyrillic test font is required')
 im=Image.new('RGB',(1280,720),(52,64,62));d=ImageDraw.Draw(im)
 def text(x,y,s,size=22,colour=(235,235,235)):d.text((x,y),s,font=ImageFont.truetype(FONT,size),fill=colour)
 text(28,14,'Карта: Альтгард',26);text(460,50,'Кибелиск',18)
 d.rectangle((0,95,288,710),fill=(20,28,35))
 if row:
  text(20,635,'13. '+NAME,20,(140,225,230));text(20,662,'Активирован',16)
 if icon:
  text(600,430,NAME,21)
  d.polygon([(680,365),(699,390),(680,416),(661,390)],fill=(180,70,225))
 if popup:
  d.rectangle((965,280,1270,515),fill=(24,31,46))
  text(982,303,NAME if not wrong else 'Убежище клыка',21)
  text(982,336,'Не активирован' if inactive else 'Активирован',15,(130,155,170))
  text(982,365,'Подробная информация',16)
  text(974,470,'Переместиться',16)
  d.rectangle((1120,455,1260,510),fill=(215,165,35));text(1130,469,'F',19)
 return cv2.cvtColor(np.asarray(im),cv2.COLOR_RGB2BGR)

def modal_frame(name=NAME,gold=True):
 frame=(map_frame(popup=True)*.22).astype(np.uint8)
 im=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));d=ImageDraw.Draw(im)
 d.rectangle((320,260,960,460),fill=(38,46,65))
 font=ImageFont.truetype(FONT,18)
 d.text((375,287),'Телепортироваться в зону '+name+'?',font=font,fill='white')
 d.rectangle((478,412,635,444),fill=(50,65,85));d.text((510,418),'Отмена',font=font,fill='white')
 d.rectangle((644,412,802,444),fill=(215,165,35) if gold else (50,65,85));d.text((700,418),'F OK',font=font,fill='white')
 return cv2.cvtColor(np.asarray(im),cv2.COLOR_RGB2BGR)

class SecondConfirmation(unittest.TestCase):
 def test_real_ocr_central_modal_survives_dimmed_map(self):
  o=observe(modal_frame(),NAME,'WAIT_TRANSFER')
  self.assertTrue(o.dialog);self.assertTrue(o.opened);self.assertIsNotNone(o.confirm)
 def test_wrong_destination_or_missing_gold_cannot_confirm(self):
  for f in (modal_frame('Убежище клыка'),modal_frame(gold=False)):
   self.assertFalse(observe(f,NAME,'WAIT_TRANSFER').dialog)
 def test_second_confirmation_once_then_arrival(self):
  m=MapTeleport(0);m.step(0,MapObservation(True,popup=True,destination=NAME,confirm=(1000,500)))
  modal=MapObservation(True,popup=True,destination=NAME,confirm=(700,430),dialog=True)
  self.assertEqual(m.step(2,modal).kind,'CONFIRM_DIALOG')
  self.assertEqual(m.step(3,modal).kind,'WAIT')
  self.assertEqual(m.step(6,modal).kind,'WAIT')
  o=MapObservation(False,arrived=True,usable=True)
  m.step(14,o);self.assertEqual(m.step(15,o).kind,'DONE')

class MapPolicy(unittest.TestCase):
 def test_open_is_issued_once(self):
  m=MapTeleport(0);self.assertEqual(m.step(0,MapObservation()).kind,'OPEN')
  self.assertEqual(m.step(1,MapObservation()).kind,'WAIT')
  self.assertEqual(m.step(6,MapObservation()).kind,'FAILED')
 def test_already_open_map_does_not_get_toggled_closed(self):
  m=MapTeleport(0);self.assertEqual(m.step(0,MapObservation(True,row=(40,650))).kind,'ROW')
 def test_scrolls_list_without_guessing_a_map_location(self):
  m=MapTeleport(0);a=m.step(0,MapObservation(True,list_first=1,list_last=8))
  self.assertEqual(a.kind,'SCROLL');self.assertEqual(a.direction,-1)
 def test_scrolls_up_if_target_index_has_been_passed(self):
  m=MapTeleport(0);a=m.step(0,MapObservation(True,list_first=20,list_last=27))
  self.assertEqual(a.direction,1)
 def test_nonmoving_list_has_finite_failure(self):
  m=MapTeleport(0);o=MapObservation(True,list_signature=np.zeros((24,40),np.uint8))
  m.step(0,o);m.step(1,o);m.step(2,o);m.step(3,o);a=m.step(4,o)
  self.assertEqual(a.kind,'FAILED')
 def test_confirmation_requires_matching_popup(self):
  m=MapTeleport(0);a=m.step(0,MapObservation(True,popup=True,destination='Убежище клыка',confirm=(1000,500)))
  self.assertEqual(a.kind,'FAILED');self.assertFalse(m.used)
 def test_row_centering_can_be_followed_by_a_labelled_icon(self):
  m=MapTeleport(0);m.step(0,MapObservation(True,row=(50,650)))
  m.step(2.1,MapObservation(True));self.assertEqual(m.phase,'FIND_ICON')
  self.assertEqual(m.step(3,MapObservation(True,icon=(680,390))).kind,'ICON')
 def test_exact_popup_is_confirmed_only_once(self):
  m=MapTeleport(0);o=MapObservation(True,popup=True,destination=NAME,confirm=(1000,500))
  self.assertEqual(m.step(0,o).kind,'CONFIRM');self.assertEqual(m.step(1,o).kind,'WAIT')
 def test_map_still_open_does_not_prove_transfer(self):
  m=MapTeleport(0);m.phase='WAIT_TRANSFER';m.loading_seen=True
  for t in (6,8):self.assertEqual(m.step(t,MapObservation(True,usable=True,arrived=True)).kind,'WAIT')
 def test_destination_or_loading_sequence_can_prove_arrival(self):
  for loading in (False,True):
   m=MapTeleport(0);m.phase='WAIT_TRANSFER';m.loading_seen=loading
   o=MapObservation(False,arrived=not loading,usable=True)
   m.step(6,o);self.assertEqual(m.step(7,o).kind,'DONE')
 def test_closed_map_alone_does_not_prove_transfer(self):
  m=MapTeleport(0);m.phase='WAIT_TRANSFER'
  m.step(6,MapObservation(False,usable=True))
  self.assertEqual(m.step(21,MapObservation(False,usable=True)).kind,'FAILED')
 def test_no_infinite_scan_or_repeated_confirmation(self):
  m=MapTeleport(0);m.phase='FIND'
  self.assertEqual(m.step(151,MapObservation(True)).kind,'FAILED')
 def test_name_is_full_and_not_a_prefix(self):
  self.assertTrue(exact_name('13. '+NAME,NAME,index=True))
  for bad in (NAME+' II',NAME+' 2','Старый '+NAME,NAME+'а'):
   self.assertFalse(exact_name(bad,NAME))

class MapVision(unittest.TestCase):
 def test_real_russian_ocr_finds_full_name_in_list(self):
  o=observe(map_frame(),NAME,'FIND');self.assertTrue(o.opened);self.assertIsNotNone(o.row)
  self.assertLess(o.row[0],1280*.225)
 def test_real_russian_ocr_requires_exact_popup_and_button(self):
  o=observe(map_frame(popup=True),NAME,'WAIT_ROW')
  self.assertTrue(o.opened);self.assertTrue(o.popup);self.assertEqual(o.destination,NAME)
 def test_missing_gold_f_option_does_not_authorize_confirmation(self):
  frame=map_frame(popup=True);frame[455:511,1120:1261]=(24,31,46)
  o=observe(frame,NAME,'WAIT_ROW')
  self.assertTrue(o.popup);self.assertIsNone(o.confirm)
 def test_wrong_or_inactive_popup_never_gets_confirm_authority(self):
  for kwargs in ({'wrong':True},{'inactive':True}):
   o=observe(map_frame(popup=True,**kwargs),NAME,'WAIT_ROW');self.assertFalse(o.popup)
 def test_icon_requires_the_target_label(self):
  o=observe(map_frame(row=False,icon=True),NAME,'FIND_ICON')
  self.assertIsNotNone(o.icon);self.assertAlmostEqual(o.icon[0],680,delta=4)
 def test_world_or_loading_frame_cannot_look_like_verified_map(self):
  for frame in (np.zeros((720,1280,3),np.uint8),np.full((720,1280,3),150,np.uint8)):
   self.assertFalse(observe(frame,NAME,'FIND').opened)
 def test_fast_menu_guard_rejects_map_disappearing(self):
  frame=map_frame();stamp=menu_stamp(frame)
  self.assertTrue(same_stamp(frame,stamp));self.assertFalse(same_stamp(np.zeros_like(frame),stamp))

class MenuTransport(unittest.TestCase):
 def test_plain_ui_a_never_inherits_lb_lt(self):
  p=Pad();g=GamepadInput(factory=lambda:p,a_button=0x1000);g.native_cursor=True
  try:
   with patch.object(GamepadInput,'wait',return_value=True):self.assertTrue(g.tap_ui_a(threading.Event(),lambda:True,lambda:True))
   self.assertEqual(p.presses,1);self.assertEqual(p.buttons,0);self.assertEqual(p.lt,0)
  finally:g.close()
 def test_ui_a_rechecks_authorization_at_press_boundary(self):
  p=Pad();g=GamepadInput(factory=lambda:p,a_button=0x1000);checks=iter((True,False))
  try:self.assertFalse(g.tap_ui_a(threading.Event(),lambda:True,lambda:next(checks)));self.assertEqual(p.presses,0)
  finally:g.close()

class MapEngine(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e.network=self.source;self.e.cfg.update(map_safe_return_enabled=True,map_return_destination=NAME,map_return_index=13)
  self.e.bridge.send_guarded=lambda command,authorize: self.commands.append(command) is None if authorize() else False
 def start(self):
  with patch.object(ge,'place_title',return_value='Кряж Транейн'):
   self.assertTrue(self.e._start_map_teleport(100))
 def test_start_never_uses_the_nearest_scroll(self):
  self.start();self.assertTrue(self.e.map_active);self.assertEqual(self.e.mode,'MAP_RETURN')
  self.assertEqual(self.pad.presses,0);self.assertNotIn('TAP_F',self.commands)
 def test_new_own_collection_blocks_menu_input(self):
  self.start();s=self.source.state;s.collecting=99;s.attempt_active=True;s.nodes[99].gather_time=1000
  with patch.object(self.e,'_own_collection',return_value=s.nodes[99]):self.assertFalse(self.e._map_input_ready())
 def test_arrival_releases_island_exit_guard_before_camera_restore(self):
  self.start();self.e.return_exit_guard=True;self.e.map_teleport.phase='DONE'
  with patch.object(ge,'observe_map',return_value=MapObservation()),patch.object(self.e,'_calibrate_camera',return_value=True) as calibrate:
   self.e._map_teleport_tick(self.frame,FlightReading(None,False),100)
   calibrate.assert_called_once()
  self.assertFalse(self.e.return_exit_guard);self.assertFalse(self.e.map_active);self.assertEqual(self.e.mode,'SEARCH')
 def test_full_ui_trip_selects_name_confirms_once_and_waits_for_arrival(self):
  self.start();self.input.native_cursor=True
  with patch.object(ge.time,'monotonic',return_value=100):self.e._map_teleport_tick(self.frame,FlightReading(None,False),100)
  self.frame=map_frame()
  with patch.object(ge.time,'monotonic',return_value=101):self.e._map_teleport_tick(self.frame,FlightReading(None,False),101)
  with patch.object(ge.time,'monotonic',return_value=102),patch.object(GamepadInput,'wait',return_value=True):
   self.e._map_teleport_tick(self.frame,FlightReading(None,False),102)
  self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.lt,0)
  self.frame=map_frame(popup=True)
  with patch.object(ge.time,'monotonic',return_value=103):self.e._map_teleport_tick(self.frame,FlightReading(None,False),103)
  self.assertEqual(self.commands.count('TAP_F'),1)
  self.frame=np.zeros_like(self.frame)
  with patch.object(ge.time,'monotonic',return_value=104):self.e._map_teleport_tick(self.frame,FlightReading(None,False),104)
  yy,xx=np.indices((720,1280));self.frame=np.repeat(((xx+yy)%120+60).astype(np.uint8)[:,:,None],3,axis=2)
  with patch.object(ge,'place_title',return_value=NAME),patch.object(self.e,'_calibrate_camera',return_value=True) as calibrate:
   for t in (110,111):
    with patch.object(ge.time,'monotonic',return_value=t):self.e._map_teleport_tick(self.frame,FlightReading(None,False),t)
   calibrate.assert_called_once()
  self.assertIsNone(self.e.map_teleport);self.assertEqual(self.e.mode,'SEARCH')
  self.assertEqual(self.commands.count('TAP_F'),1)
 def test_changed_popup_revokes_the_final_confirmation_guard(self):
  from map_teleport import title_stamp
  self.start();self.frame=map_frame(popup=True)
  check=observe(self.frame,NAME,'FIND')
  self.e.map_menu_stamp=menu_stamp(self.frame);self.e.map_popup_box=check.popup_box
  self.e.map_popup_stamp=title_stamp(self.frame,check.popup_box)
  self.assertTrue(self.e._map_input_ready(menu=True,popup=True))
  self.frame=map_frame(popup=True,wrong=True)
  self.assertFalse(self.e._map_input_ready(menu=True,popup=True))
 def test_engine_confirms_the_second_dimmed_modal_once(self):
  self.start();self.frame=map_frame();self.e.map_menu_stamp=menu_stamp(self.frame)
  self.e.map_teleport.phase='WAIT_TRANSFER';self.e.map_teleport.used=True
  self.frame=modal_frame()
  with patch.object(ge.time,'monotonic',return_value=102):
   self.e._map_teleport_tick(self.frame,FlightReading(None,False),102)
  self.assertEqual(self.commands.count('TAP_F'),1)
  self.assertTrue(self.e.map_teleport.dialog_used)
  with patch.object(ge.time,'monotonic',return_value=104):
   self.e._map_teleport_tick(self.frame,FlightReading(None,False),104)
  self.assertEqual(self.commands.count('TAP_F'),1)
 def test_cooldown_defers_return_without_repeating_it(self):
  self.e.map_return_after=400
  self.assertFalse(self.e._start_map_teleport(100));self.assertFalse(self.e.stop_event.is_set())
  self.assertEqual(self.e.no_yield.next_return,400)

if __name__=='__main__':unittest.main()
