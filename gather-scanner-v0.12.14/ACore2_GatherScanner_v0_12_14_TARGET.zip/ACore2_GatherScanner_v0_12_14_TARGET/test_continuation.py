"""Completed own collection with lost selection must not pin navigation forever."""
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch
import unittest
import cv2
import numpy as np
import gather_engine as ge
import hybrid_engine as he
import vision
from hybrid_engine import HybridGatherEngine
from flight import FlightReading
from test_navigation import GatherFixture
from test_network_control import Source
from test_ether_emblem import scene,ether


class Continuation(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e
  self.source=Source()
  self.e=HybridGatherEngine({**old.cfg,'collection_event_driven':True,'resource_click_interaction':True,
      'preserve_owned_resource':True,'auto_view_recovery':False},self.log.append,self.input,network=self.source)
  self.e.screen=old.screen;self.e.bridge=old.bridge
  self.e.mode='GATHER';self.e.target=ge.OWN_RESOURCE;self.e.target_confirmed=True
  self.e.resource_hold=True;self.e.real_gather_panel_seen=True
  self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
  self.f=self.source.state;self.f.nodes[99].template=None;self.f.nodes[99].gather_time=1000
  self.f.started=1000;self.f.attempt_ordinal=1;self.f.nodes[99].used=1
  self.f.attempt_active=False;self.f.selected=0;self.f.last_own_result=(99,1100);self.f.last_own_result_used=1
  self.clock=100.
  p=patch.object(he.time,'monotonic',side_effect=lambda:self.clock);p.start();self.addCleanup(p.stop)

 def tick(self,t):
  self.clock=t;return self.e._completed_point_wait_tick(self.frame,t)

 def test_recorded_completed_unknown_node_selected_zero_has_bounded_escape_without_input(self):
  self.assertFalse(self.tick(100));self.assertFalse(self.tick(107.9))
  # The independent deadline survives resets in the older recovery machinery.
  self.e.collection_cycle.reset();self.e.view_recovery=None
  with patch.object(self.input,'drive',wraps=self.input.drive) as drive:
   self.assertTrue(self.tick(108.3))
  drive.assert_not_called();self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.network_target)
  self.assertEqual(self.pad.presses,0);self.assertFalse({'TAP_F','F_ON','V','END_AIR','TAB'}&set(self.commands))
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.e.node_count,0)
  self.assertGreater(self.e.resource_retry_after[(1,99)],150);self.assertIsNone(self.e.ignored_collection_lease)
  self.assertFalse(self.e._adopt_network_collection());self.assertEqual(self.e.mode,'SEARCH')

 def test_real_partial_panel_blocks_release_even_when_result_arrived_early(self):
  panel=cv2.imread(str(Path(ge.ROOT)/'testdata/current_gather_panel.png'))
  self.frame=np.full((1440,2560,3),35,np.uint8);h,w=panel.shape[:2];self.frame[1014:1014+h,930:930+w]=panel
  self.assertTrue(he.gathering_panel_pair(self.frame))
  for t in (100,109,150):self.assertFalse(self.tick(t))
  self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.pad.presses,0)

 def test_active_attempt_blocks_release_for_any_elapsed_time(self):
  self.tick(100);self.f.attempt_active=True
  for t in (109,150):self.assertFalse(self.tick(t))
  self.assertEqual(self.e.mode,'GATHER');self.assertIsNone(self.e.continuation_watch)

 def test_missing_point_without_own_end_is_not_permission_to_abandon(self):
  self.f.last_own_result=None
  for t in (100,110,150):self.assertFalse(self.tick(t))
  self.assertEqual(self.e.mode,'GATHER')

 def test_wrong_actor_owner_flow_counter_stale_result_or_new_attempt_rejects_end_proof(self):
  mutations=(lambda:setattr(self.f,'last_own_result',(100,1100)),
    lambda:setattr(self.f,'own',8),lambda:setattr(self.e,'network_target',(2,99)),
    lambda:setattr(self.f,'last_own_result_used',2),lambda:setattr(self.f,'last_own_result',(99,999)),
    lambda:setattr(self.f,'started',1200),lambda:self.f.players.update({99:{}}),
    lambda:setattr(self.f,'selected',100),lambda:setattr(self.f.nodes[99],'visible',False))
  for mutate in mutations:
   with self.subTest(mutate=mutate):
    original=self.source.view()['state'];binding=self.e.network_target
    mutate();self.assertIsNone(self.e._completed_wait_proof(self.source.view()))
    self.source.state=original;self.f=original;self.e.network_target=binding

 def test_own_next_attempt_revokes_old_deadline_and_gets_full_new_wait(self):
  self.tick(100);self.f.attempt_active=True;self.assertFalse(self.tick(107))
  self.f.attempt_active=False;self.f.started=1200;self.f.attempt_ordinal=2
  self.f.nodes[99].gather_time=1200;self.f.nodes[99].used=2
  self.f.last_own_result=(99,1300);self.f.last_own_result_used=2
  self.assertFalse(self.tick(110));self.assertFalse(self.tick(117));self.assertTrue(self.tick(118.1))

 def test_fresh_local_point_cancels_deadline(self):
  self.tick(100)
  with patch.object(self.e,'_fresh_click_candidate',return_value=self.c):self.assertFalse(self.tick(109))
  self.assertIsNone(self.e.continuation_watch);self.assertFalse(self.tick(110));self.assertFalse(self.tick(117))

 def test_recheck_sees_new_active_attempt_before_release(self):
  self.tick(100)
  def frame():self.f.attempt_active=True;return self.frame,(0,0)
  self.e.screen.frame=frame
  self.assertFalse(self.tick(109));self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.pad.presses,0)

 def test_recheck_sees_returned_point_before_release(self):
  self.tick(100)
  with patch.object(self.e,'_fresh_click_candidate',side_effect=[None,self.c]):self.assertFalse(self.tick(109))
  self.assertEqual(self.e.mode,'GATHER');self.assertIsNone(self.e.continuation_watch)

 def test_resumed_active_same_lease_is_adopted_immediately_after_quarantine(self):
  self.tick(100);self.tick(109);self.f.attempt_active=True
  self.assertTrue(self.e._adopt_network_collection());self.assertTrue(self.e._net_gather_proof())
  self.assertIn(self.e.mode,('APPROACH','GATHER'));self.assertTrue(self.e.resource_hold)
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.presses,0)

 def test_map_stop_and_lost_focus_cannot_release_or_send_commands(self):
  self.tick(100);self.e.map_active=True;self.assertFalse(self.tick(109))
  self.e.map_active=False;self.e.screen.focused=lambda:False;self.assertFalse(self.tick(120))
  self.e.screen.focused=lambda:True;self.assertFalse(self.tick(121))
  self.e.stop_event.set();self.assertFalse(self.tick(140))
  self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.commands,[])

 def test_fast_resource_service_calls_bounded_escape_even_with_unknown_caption(self):
  for t in (100,109):
   self.clock=t
   released=self.e._resource_fast_tick(self.frame,FlightReading(None,False),t)
  self.assertTrue(released);self.assertEqual(self.e.mode,'SEARCH')

 def test_catalog_resolves_actual_morpha_without_adding_it_to_search_whitelist(self):
  self.assertNotIn('Морфа',self.e.cfg['target_names']);self.assertIn('Морфа',self.e._owned_resource_names())
  self.e.network_bound_at=90;self.e.visual_selection=(1,99,'Морфа',100)
  self.e._adopt_network_collection();self.assertEqual(self.e.target,'Морфа')
  self.assertEqual(self.e._vision_names(),('Морфа',));self.assertNotIn('Морфа',self.e.cfg['target_names'])

 def test_foreign_or_stale_visual_name_cannot_rename_owned_node(self):
  self.e.network_bound_at=90
  for proof in ((1,100,'Морфа',100),(2,99,'Морфа',100),(1,99,'Морфа',89)):
   self.e.visual_selection=proof;self.e._adopt_network_collection();self.assertEqual(self.e.target,ge.OWN_RESOURCE)

 def test_vision_worker_reads_actual_owned_catalog_name(self):
  self.e.budget.energy=80
  def wait(_):self.e.stop_event.set();return True
  with patch.object(self.e.stop_event,'wait',side_effect=wait),patch.object(ge,'selected_resource_name',return_value='Морфа') as header,patch.object(self.e,'_analyzer_aether',return_value=None):
   self.e._vision_loop()
  self.assertIn('Морфа',header.call_args.args[1]);self.assertEqual(self.e.visual_selection[:3],(1,99,'Морфа'))


class InitialCaption(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e
  self.e=HybridGatherEngine(old.cfg,self.log.append,self.input);self.e.screen=old.screen;self.e.bridge=old.bridge
  self.frame=scene();self.c=ether(self.frame);self.e.current_size=(2480,1395)

 def test_actual_ether_captions_read_as_ether_and_geometry_is_accepted(self):
  for file in ('ether_near_caption_crop.png','ether_far_caption_crop.png'):
   self.frame=scene(file);candidate=ether(self.frame)
   name,_=vision.read_world_caption(self.frame,candidate,self.e._owned_resource_names())
   self.assertEqual(name,'Эфир');self.assertTrue(self.e._acquire_caption_matches(self.frame,candidate))

 def test_correct_badge_geometry_survives_all_existing_detection_scales(self):
  with patch.object(he,'read_world_caption',return_value=('Эфир','Эфир')):
   for file in ('ether_near_caption_crop.png','ether_far_caption_crop.png'):
    for scale in (.6,.8,1,1.25,1.5):
     self.frame=scene(file,scale);self.assertTrue(self.e._acquire_caption_matches(self.frame,ether(self.frame)))

 def test_clear_morpha_contradiction_prevents_first_a_in_real_click_path(self):
  with patch.object(he,'read_world_caption',return_value=('Морфа','Морфа')),patch.object(ge.GamepadInput,'wait',return_value=True):
   self.assertFalse(self.e.click_candidate(self.c,(0,0),refresh=False))
  self.assertEqual(self.pad.presses,0);self.assertEqual(self.commands[-1],'ALT_UP');self.assertFalse(self.e.target_confirmed)

 def test_unreadable_ocr_does_not_discard_shape_recognition(self):
  with patch.object(he,'read_world_caption',return_value=(None,'')):
   self.assertTrue(self.e._acquire_caption_matches(self.frame,self.c))

 def test_distant_or_sideways_badge_is_not_ether_caption_hitbox(self):
  x,y,w,h=self.c.emblem
  for emblem in ((x,y-100,w,h),(x+70,y,w,h)):
   with patch.object(he,'read_world_caption') as read:
    self.assertFalse(self.e._acquire_caption_matches(self.frame,replace(self.c,emblem=emblem)))
   read.assert_not_called()

 def test_caption_without_badge_keeps_body_path_and_focus_guard(self):
  with patch.object(he,'read_world_caption',return_value=('Эфир','Эфир')):
   self.assertTrue(self.e._acquire_caption_matches(self.frame,replace(self.c,emblem=None)))
   self.e.screen.focused=lambda:False
   self.assertFalse(self.e._acquire_caption_matches(self.frame,self.c))


if __name__=='__main__':unittest.main()
