"""Ranged ground aggressor while collecting in flight: no orphan DEFENSE."""
from pathlib import Path
import unittest
from unittest.mock import patch
import cv2,numpy as np
import gather_engine as ge
from app import DEFAULT
from camera_control import PITCH_STRENGTH
from flight import FlightReading
from gamepad_input import GamepadInput
from network_defense import AirDefenseView
from test_navigation import GatherFixture
from test_network_control import Source

AIR=FlightReading(70,True)
GROUND=FlightReading(None,False)

class AirDefense(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(defense_air_search=True,collection_event_driven=True,
            resource_click_interaction=True,repeat_owned_clicks=True,preserve_owned_resource=True,
            calibrate_during_collection=False)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.nodes[99].template=1500000;self.f.nodes[99].used=0;self.f.nodes[99].gather_time=1000
        self.f.started=1000;self.f.attempt_ordinal=1;self.f.attacks[55]=1000
        self.f.npcs[55]={'time':900,'born_at':900};self.e.network_attacker=55
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True;self.e.resource_flight_owned=True
        self.clock=100.;self.wall=1100;self.drives=[]
        self.addCleanup(self.e._stop_defense_motion)
        def wait(seconds,*args):self.clock+=seconds;return True
        drive=self.input.drive
        def driven(*a,**k):self.drives.append(a);return drive(*a,**k)
        self.input.drive=driven
        for p in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),
                  patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),
                  patch.object(GamepadInput,'wait',side_effect=wait),
                  patch.object(ge,'read_flight',return_value=AIR)):
            p.start();self.addCleanup(p.stop)

    def begin(self):self.e._begin_network_defense(True)
    def ready(self):
        self.e.defense_air_view.phase='READY';self.e.defense_air_view.moved=True
        self.f.collecting=None;self.f.attempt_active=False;self.f.selected=66
    def tick(self,dt=.06):
        self.clock+=dt;self.wall+=round(dt*1000)
        return self.e._network_defense_tick(self.clock)
    def panel(self):
        self.frame=np.full((1440,2560,3),35,np.uint8)
        p=cv2.imread(str(Path(ge.ROOT)/'testdata/current_gather_panel.png'))
        self.frame[1014:1172,930:1630]=p

    def test_air_ether_uses_full_down_search_without_requiring_fresh_xyz(self):
        self.f.xyz=None;self.begin()
        self.assertIsNotNone(self.e.defense_air_view);self.assertEqual(self.e.mode,'DEFENSE')
        self.assertIsNone(self.e.defense_camera_until)
    def test_ether_collection_can_identify_air_when_arc_is_not_readable(self):
        with patch.object(ge,'read_flight',return_value=GROUND):self.begin()
        self.assertIsNotNone(self.e.defense_air_view)
    def test_ground_collection_does_not_get_an_air_down_hold(self):
        self.e.target='Сапфир';self.e.resource_flight_owned=False
        with patch.object(ge,'read_flight',return_value=GROUND):self.begin()
        self.assertIsNone(self.e.defense_air_view)
    def test_down_hold_is_two_delivered_seconds_before_first_tab(self):
        self.begin();self.f.selected=0
        for _ in range(30):
            self.tick();self.assertNotIn('TAB',self.commands)
        for _ in range(7):
            self.tick()
            if 'TAB' in self.commands:break
        self.assertIn('TAB',self.commands)
        self.assertTrue(self.drives);self.assertTrue(all(d[:3]==(0,0,0) and d[3]<0 for d in self.drives))
        self.assertFalse({'V','END_AIR','ATTACK_PAIR'}&set(self.commands))
    def test_wall_time_alone_does_not_claim_two_seconds_were_delivered(self):
        self.begin();self.e.pitch.balance=-.2;self.clock=103
        self.e._network_defense_tick(self.clock)
        self.assertEqual(self.e.defense_air_view.phase,'DOWN');self.assertNotIn('TAB',self.commands)
    def test_down_phase_is_bounded_when_no_motion_was_delivered(self):
        self.begin();self.clock=106.1;self.f.selected=0
        self.e._network_defense_tick(self.clock)
        self.assertEqual(self.e.defense_air_view.phase,'READY');self.assertIn('TAB',self.commands)
    def test_three_wrong_ids_get_one_turn_and_one_more_tab_round(self):
        self.begin();self.ready();episode=self.e.network_defense;episode.tabs=3
        episode.reason='выбранный ID не совпал с источником урона'
        with patch.object(episode,'plan',return_value='ABORT'):self.tick()
        self.assertEqual(self.e.defense_air_view.rounds,1);self.assertEqual(episode.tabs,0)
        self.assertAlmostEqual(self.e.defense_air_view.turn_seconds,.6)
        self.assertTrue(any(d[:3]==(0,0,.62) for d in self.drives))
        self.assertNotIn('ATTACK_PAIR',self.commands);self.assertEqual(self.e.mode,'DEFENSE')
    def test_second_failed_view_finishes_into_escape_instead_of_orphan_mode(self):
        self.begin();self.ready();self.e.defense_air_view.rounds=1
        episode=self.e.network_defense;episode.tabs=3;episode.reason='выбранный ID не совпал с источником урона'
        with patch.object(episode,'plan',return_value='ABORT'):self.tick()
        self.assertIsNone(self.e.network_defense);self.assertEqual(self.e.mode,'SEARCH')
        self.assertIsNone(self.e.resume_resource_id);self.assertIsNotNone(self.e.defense_restore_view)
        self.assertFalse(self.e.stop_event.is_set());self.assertNotIn('END_AIR',self.commands)
    def test_missing_tab_reply_does_not_trigger_another_camera_round(self):
        self.begin();self.ready();episode=self.e.network_defense
        episode.sent_tab(self.wall,self.clock);self.tick(1.6)
        self.assertIsNone(self.e.network_defense);self.assertEqual(self.e.mode,'SEARCH')
        self.assertFalse(any(d[2] for d in self.drives));self.assertNotIn('ATTACK_PAIR',self.commands)
    def test_only_the_verified_attacker_is_hit_after_down_search(self):
        self.begin();self.ready();self.f.selected=55
        self.tick();self.tick(.2);self.assertIn('ATTACK_PAIR',self.commands)
        self.f.deaths[55]=self.wall;self.tick()
        self.assertEqual(self.e.mode,'REACQUIRE');self.assertEqual(self.e.resume_resource_id,(1,99))
        self.assertIsNone(self.e.network_defense)
    def test_episode_deadline_exits_even_if_view_search_never_succeeds(self):
        self.begin();self.ready();self.clock=117;self.wall=18100
        self.e._network_defense_tick(self.clock)
        self.assertIsNone(self.e.network_defense);self.assertEqual(self.e.mode,'SEARCH')
    def test_log_reproduction_resource_guard_cannot_leave_defense_without_episode(self):
        self.begin();self.ready();self.e._finish_network_defense(False,'three unrelated targets')
        self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.network_defense)
        self.assertFalse(self.e._adopt_network_collection());self.assertFalse(self.e.stop_event.is_set())
        self.assertNotIn('V',self.commands);self.assertNotIn('END_AIR',self.commands)
    def test_one_camera_restore_returns_yaw_then_uses_940ms_and_keeps_resource(self):
        self.begin();self.ready();self.e.defense_air_view.turn_seconds=.6
        self.e._finish_network_defense(True);before=self.e.reacquire_until
        def held(seconds):self.clock+=seconds;return True
        with patch.object(self.e,'_hold_pitch_up',side_effect=held) as up,patch.object(self.e,'_hold_pitch_down',side_effect=held) as down:
            self.e._network_defense_tick(self.clock)
        up.assert_called_once_with(2);down.assert_called_once_with(.94)
        self.assertIsNone(self.e.defense_restore_view);self.assertEqual(self.e.mode,'REACQUIRE')
        self.assertTrue(any(d[:3]==(0,0,-.62) for d in self.drives))
        self.assertGreater(self.e.reacquire_until,before+3);self.assertAlmostEqual(self.e.pitch.offset(self.clock),0)
    def test_focus_loss_during_restore_is_paused_and_can_finish_after_return(self):
        self.begin();self.ready();self.e._finish_network_defense(False,'not visible');focused=[True]
        self.e.screen.focused=lambda:focused[0]
        def failed(seconds):focused[0]=False;return False
        with patch.object(self.e,'_hold_pitch_up',side_effect=failed):self.e._network_defense_tick(self.clock)
        self.assertIsNotNone(self.e.defense_restore_view);self.assertEqual(self.pad.axes,(0,0,0,0))
        focused[0]=True
        with patch.object(self.e,'_hold_pitch_up',return_value=True),patch.object(self.e,'_hold_pitch_down',return_value=True):self.e._network_defense_tick(self.clock)
        self.assertIsNone(self.e.defense_restore_view);self.assertFalse(self.e.stop_event.is_set())
    def test_network_uncertainty_does_not_move_during_pending_restore(self):
        self.begin();self.ready();self.e._finish_network_defense(False,'not visible');self.source.ready=False
        self.e._network_defense_tick(self.clock)
        self.assertEqual(self.drives,[]);self.assertIsNotNone(self.e.defense_restore_view)
    def test_pending_restore_blocks_automatic_collection_adoption(self):
        self.begin();self.ready();self.e._finish_network_defense(False,'not visible')
        self.f.collecting=99;self.f.started=1200;self.f.nodes[99].gather_time=1200;self.f.selected=99
        self.assertFalse(self.e._adopt_network_collection());self.assertEqual(self.e.mode,'SEARCH')
    def test_old_interrupted_lease_cannot_be_adopted_as_live_collection(self):
        self.begin();self.e.network_defense.interrupted_at=self.wall  # selection input interrupted this attempt
        self.e._finish_network_defense(False,'not visible')
        self.f.collecting=99;self.f.selected=0;self.f.attempt_active=True
        self.assertIsNone(self.e._own_collection());self.assertFalse(self.e._net_gather_proof())
        self.assertFalse(self.e._adopt_network_collection())
    def test_fresh_own_start_restores_normal_collection_and_movement_protection(self):
        self.begin();self.e._finish_network_defense(False,'not visible')
        self.f.collecting=99;self.f.selected=99;self.f.started=1200;self.f.nodes[99].gather_time=1200
        self.assertIsNotNone(self.e._own_collection());self.assertIsNone(self.e.defense_interrupted)
        self.e.defense_restore_view=None;self.e._adopt_network_collection()
        self.f.collecting=None
        self.assertTrue(self.e._owned_resource_remaining())
        self.assertFalse(self.input.drive(.5,0,lifetime=.05));self.assertEqual(self.pad.axes,(0,0,0,0))
    def test_fresh_own_result_can_confirm_collection_that_never_stopped(self):
        self.begin();self.e._finish_network_defense(False,'brief interruption')
        self.f.collecting=99;self.f.selected=0;self.f.last_own_result=(99,1200);self.f.last_own_result_used=1
        self.assertIsNotNone(self.e._own_collection());self.assertIsNone(self.e.defense_interrupted)
    def test_real_lower_panel_blocks_abandon_even_for_an_old_defense_lease(self):
        self.begin();self.e._finish_network_defense(True);self.panel()
        self.f.collecting=99;self.f.started=1000;self.f.attempt_active=False;self.f.selected=0
        self.e.abandoning_binding=(1,99)
        self.assertFalse(self.e._can_abandon_resource());self.assertFalse(self.e._end_air_still_allowed())
    def test_failed_reacquisition_can_close_wings_skip_resource_and_patrol(self):
        self.e.cfg['defense_air_search']=False;self.begin()
        self.f.collecting=None;self.f.attempt_active=False;self.f.selected=66
        self.e._finish_network_defense(False,'not visible')
        self.e.defense_restore_view=None;self.e.resource_flight_owned=True
        self.clock=self.e.view_recovery.until+.1
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.network_target)
        self.assertIn('END_AIR',self.commands);self.assertFalse(self.e.stop_event.is_set())
        self.input.drive(.6,0,lifetime=.05);self.assertNotEqual(self.pad.axes,(0,0,0,0))
    def test_air_failure_skips_resource_and_allows_retreat_instead_of_repeated_tab(self):
        self.begin();self.ready();self.e._finish_network_defense(False,'not visible')
        self.e.defense_restore_view=None
        self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.network_target)
        self.assertEqual(self.e.resource_retry_after[(1,99)],self.clock+45)
        self.f.attacks[55]=self.wall;self.f.selected=55
        self.assertEqual(self.e._pending_network_hits(self.clock),[])
        self.assertFalse(self.e._allowed(type('Candidate',(),{'name':'Эфир'})(),self.clock))
        self.input.drive(.6,0,lifetime=.05)
        self.assertNotEqual(self.pad.axes,(0,0,0,0));self.assertFalse(self.e.stop_event.is_set())
    def test_escape_grace_starts_after_camera_restore_finishes(self):
        self.begin();self.ready();self.e._finish_network_defense(False,'not visible')
        def held(seconds):self.clock+=seconds;return True
        with patch.object(self.e,'_hold_pitch_up',side_effect=held),patch.object(self.e,'_hold_pitch_down',side_effect=held):
            self.e._network_defense_tick(self.clock)
        self.assertEqual(self.e.mode,'SEARCH');self.assertGreaterEqual(self.e.defense_evade_until,self.clock+5.9)
        self.assertIsNone(self.e.defense_restore_view)
    def test_stale_active_lease_does_not_block_escape_wing_close_after_binding_cleared(self):
        self.begin();self.e.network_defense.interrupted_at=self.wall  # selection input interrupted this attempt
        self.e._finish_network_defense(False,'not visible')
        self.f.collecting=99;self.f.attempt_active=True;self.f.selected=0
        self.assertIsNone(self.e.network_target);self.assertTrue(self.e._end_air_still_allowed())
    def test_real_lower_panel_still_blocks_escape_wing_close_with_cleared_binding(self):
        self.begin();self.e._finish_network_defense(False,'not visible');self.panel()
        self.f.collecting=99;self.f.attempt_active=True;self.f.selected=0
        self.assertFalse(self.e._end_air_still_allowed())
    def test_escape_fast_tick_closes_confirmed_wings_despite_old_network_active(self):
        self.begin();self.e.network_defense.interrupted_at=self.wall  # selection input interrupted this attempt
        self.e._finish_network_defense(False,'not visible');self.e.defense_restore_view=None
        self.f.collecting=99;self.f.attempt_active=True;self.f.selected=0;self.wall=5000
        self.assertTrue(self.e._resource_fast_tick(self.frame,AIR,self.clock,panel=False,slots=3))
        self.assertIn('END_AIR',self.commands);self.assertEqual(self.e.mode,'SEARCH')
        self.assertIsNotNone(self.e.wing_close_pending);self.assertFalse(self.e.stop_event.is_set())
    def test_resource_exhausted_during_successful_defense_can_finish_flight(self):
        self.begin();self.ready();self.f.nodes[99].used=3;self.f.collecting=99
        self.f.last_own_result=(99,1200);self.f.last_own_result_used=3
        self.e._finish_network_defense(True);self.e.defense_restore_view=None;self.wall=5000
        self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.network_target)
        self.assertTrue(self.e._resource_fast_tick(self.frame,AIR,self.clock,panel=False,slots=3))
        self.assertIn('END_AIR',self.commands);self.assertFalse(self.e.stop_event.is_set())
    def test_real_lower_panel_blocks_wing_close_for_old_completed_resource(self):
        self.begin();self.ready();self.f.nodes[99].used=3;self.f.collecting=99
        self.e._finish_network_defense(True);self.panel()
        self.assertFalse(self.e._end_air_still_allowed())
    def test_late_result_after_failed_defense_does_not_block_escape_wing_close(self):
        self.begin();self.ready();self.e._finish_network_defense(False,'not visible')
        self.e.defense_restore_view=None;self.f.collecting=99;self.f.attempt_active=False
        self.f.last_own_result=(99,1200);self.f.last_own_result_used=1;self.wall=5000
        self.assertTrue(self.e._resource_fast_tick(self.frame,AIR,self.clock,panel=False,slots=3))
        self.assertIn('END_AIR',self.commands);self.assertEqual(self.e.mode,'SEARCH')
    def test_orphan_defense_with_resource_is_recovered_on_next_tick(self):
        self.e.mode='DEFENSE';self.e.network_defense=None;self.f.selected=0
        self.e._network_defense_tick(self.clock)
        self.assertEqual(self.e.mode,'REACQUIRE');self.assertFalse(self.e._adopt_network_collection())
        self.assertFalse(self.e.stop_event.is_set())
    def test_orphan_patrol_defense_returns_to_search(self):
        self.e.mode='DEFENSE';self.e.target=None;self.e.network_target=None;self.f.collecting=None;self.f.attempt_active=False
        self.e._network_defense_tick(self.clock)
        self.assertEqual(self.e.mode,'SEARCH');self.input.drive(.6,0,lifetime=.05)
        self.assertNotEqual(self.pad.axes,(0,0,0,0))
    def test_orphan_state_preserves_an_actual_live_lower_panel(self):
        self.panel();self.e.mode='DEFENSE';self.e.network_defense=None
        self.e._network_defense_tick(self.clock)
        self.assertEqual(self.e.mode,'GATHER');self.e.f_enable();self.assertEqual(self.pad.presses,0)
    def test_lost_focus_neutralizes_a_down_pulse(self):
        self.begin();self.tick();self.assertNotEqual(self.pad.axes,(0,0,0,0))
        self.e.screen.focused=lambda:False;self.tick()
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertNotIn('TAB',self.commands)
    def test_air_search_enabled_and_940ms_default_are_preserved(self):
        self.assertTrue(DEFAULT['defense_air_search']);self.assertEqual(DEFAULT['camera_working_view_ms'],940)

class AirViewBudget(unittest.TestCase):
    def test_remaining_is_measured_axis_time_not_wall_clock(self):
        v=AirDefenseView(100,.3)
        self.assertAlmostEqual(v.down_remaining(.3-PITCH_STRENGTH),1)
        self.assertEqual(v.down_remaining(.3-2.1*PITCH_STRENGTH),0)

if __name__=='__main__':unittest.main()
