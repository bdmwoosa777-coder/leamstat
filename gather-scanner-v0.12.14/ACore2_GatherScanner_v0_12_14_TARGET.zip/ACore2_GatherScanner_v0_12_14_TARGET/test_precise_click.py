"""Small aether click failures and stalled routes with no combat prerequisite."""
import copy,unittest
from dataclasses import replace
from unittest.mock import patch
from types import SimpleNamespace
import cv2,numpy as np
import gather_engine as ge
import vision
from flight import FlightReading
from resource_clicks import ether_click_points
from network_state import Node
from test_navigation import GatherFixture,obs
from test_network_control import Source

GROUND=FlightReading(None,False)
AIR=FlightReading(50,True)

class PreciseClicks(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(resource_click_interaction=True,defense_during_approach=False)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.selected=99;self.f.selection_time=1100;self.f.attempt_active=False;self.f.collecting=None
        self.f.nodes[99].template=1500000
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='APPROACH'
        self.frame=np.full((720,1280,3),35,np.uint8)
        mask=cv2.imread(str(vision.ROOT/'assets/name_masks/ether.png'),0)
        h,w=mask.shape;self.frame[250:250+h,600:600+w][mask>100]=(120,180,70)
        self.e.candidate=vision.caption_candidate(self.frame,'Эфир',(600,250,w,h),95)
        self.e.current_size=(1280,720);self.clock=100.;self.wall=1100;self.clicks=[]
        self.callback=lambda:None
        def wait(seconds,*args):self.clock+=seconds;return True
        def click(*args,**kwargs):
            self.clicks.append(self.positions[-1]);self.callback();return True
        self.input.tap_a=click
        for p in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),
                  patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),
                  patch.object(ge.GamepadInput,'wait',side_effect=wait)):
            p.start();self.addCleanup(p.stop)

    def start(self):
        self.f.collecting=99;self.f.attempt_active=True;self.f.nodes[99].gather_time=self.wall

    def own_gap(self):
        self.f.collecting=99;self.f.attempt_active=False;self.f.nodes[99].gather_time=1000;self.f.nodes[99].used=1
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True;self.e.mode='GATHER'

    def test_missed_activation_probes_four_descending_hitbox_points(self):
        self.assertTrue(self.e._start_resource_route())
        self.assertEqual(len(self.clicks),4);self.assertEqual(len(set(self.clicks)),4)
        self.assertFalse({'TAP_F','F_ON','V','TAB'}&set(self.commands))
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP'])

    def test_only_third_probe_hits_small_body_and_starts_gather(self):
        self.callback=lambda:self.start() if len(self.clicks)==3 else None
        self.e._start_resource_route()
        self.assertEqual(len(self.clicks),3);self.assertEqual(self.f.collecting,99)
        self.e._resource_fast_tick(self.frame,AIR,self.clock)
        self.assertEqual(self.e.mode,'GATHER');self.assertNotIn('END_AIR',self.commands)

    def test_first_hit_starts_attempt_and_remaining_burst_is_unnecessary(self):
        self.callback=self.start;self.e._start_resource_route()
        self.assertEqual(len(self.clicks),1)

    def test_native_flight_can_receive_multiple_clicks_without_an_f_toggle(self):
        self.e._start_resource_route();self.clock+=2.1
        self.e._start_resource_route(repeat_click=True)
        self.assertEqual(len(self.clicks),8);self.assertTrue(self.e.route_active)
        self.assertFalse({'TAP_F','F_ON','V'}&set(self.commands))

    def test_preselected_resource_does_not_treat_an_old_target_as_activation_ack(self):
        self.e.network_target=None;self.e.target_confirmed=False
        self.f.selection_time=900
        self.assertTrue(self.e.click_candidate(self.e.candidate,(0,0)))
        self.assertGreater(len(self.clicks),1)
        self.assertEqual(self.e.network_target,(1,99))

    def test_alt_shift_beyond_local_tracking_revalidates_real_ether_before_click(self):
        original=self.e.candidate
        shifted=np.roll(self.frame,110,axis=1)
        self.assertIsNone(vision.find_resource_near(shifted,original))
        send=self.e.bridge.send
        def alt_shift(command):
            send(command)
            if command=='ALT_DOWN':self.frame[:]=shifted
        self.e.bridge.send=alt_shift
        self.e.network_target=None;self.e.target_confirmed=False
        self.f.selection_time=900;self.callback=self.start
        self.assertTrue(self.e.click_candidate(original,(0,0)))
        self.assertTrue(self.clicks)
        self.assertGreater(self.clicks[0][0],original.click_x+90)
        self.assertNotIn('TAP_F',self.commands)

    def test_enlarged_target_caption_uses_fresh_background_anchor(self):
        original=self.e.candidate
        def enlarge():
            if len(self.clicks)!=1:return
            mask=cv2.imread(str(vision.ROOT/'assets/name_masks/ether.png'),0)
            mask=cv2.resize(mask,None,fx=2,fy=2,interpolation=cv2.INTER_NEAREST)
            h,w=mask.shape;self.frame[:]=35
            self.frame[240:240+h,580:580+w][mask>100]=(120,180,70)
            c=vision.caption_candidate(self.frame,'Эфир',(580,240,w,h),95)
            self.e.snapshot=(obs(candidate=c),self.clock,2,self.clock)
        self.callback=enlarge;self.e._start_resource_route()
        self.assertEqual(len(self.clicks),4)
        self.assertGreater(self.e.candidate.box[2],original.box[2]*1.5)
        self.assertAlmostEqual(self.e.candidate.box[0],580,delta=1)

    def test_actual_start_between_cursor_move_and_press_sends_no_extra_a(self):
        base_cursor=self.e.bridge.cursor;seen=[0]
        def cursor(x,y):
            seen[0]+=1;base_cursor(x,y)
            if seen[0]>=2:self.start()
        self.e.bridge.cursor=cursor
        self.e._start_resource_route()
        self.assertEqual(self.clicks,[]);self.assertFalse(self.e.stop_event.is_set())

    def test_caption_disappears_after_first_miss_no_further_blind_clicks(self):
        self.callback=lambda:self.frame.fill(0)
        self.e._start_resource_route();self.assertEqual(len(self.clicks),1)

    def test_neighbour_selected_after_miss_ends_burst_before_activation(self):
        self.f.nodes[100]=Node(100,1500000,used=0,time=1000)
        self.callback=lambda:setattr(self.f,'selected',100)
        self.e._start_resource_route();self.assertEqual(len(self.clicks),1)

    def test_npc_selected_after_miss_never_gets_a_second_a(self):
        self.f.npcs[55]={'time':900};self.callback=lambda:setattr(self.f,'selected',55)
        self.e._start_resource_route();self.assertEqual(len(self.clicks),1)

    def test_resource_exhausted_during_burst_stops_clicks(self):
        self.callback=lambda:setattr(self.f.nodes[99],'used',3)
        self.e._start_resource_route();self.assertEqual(len(self.clicks),1)

    def test_disconnect_during_burst_stops_clicks_and_releases_alt(self):
        self.callback=lambda:setattr(self.source,'ready',False)
        self.e._start_resource_route();self.assertEqual(len(self.clicks),1);self.assertFalse(self.alt_held)

    def test_fresh_hit_before_next_probe_yields_to_defense(self):
        def hit():self.f.attacks[55]=1050;self.f.npcs[55]={'time':900}
        self.e.distance_live=6;self.e.distance_live_at=100
        self.callback=hit;self.e._start_resource_route();self.assertEqual(len(self.clicks),1)

    def test_moving_caption_is_reanchored_after_cursor_settling(self):
        base=self.frame.copy();shift=[0]
        def frame():
            shift[0]+=3
            return np.roll(base,shift[0],axis=1),(0,0)
        self.e.screen.frame=frame
        boxes=[]
        def clicked():
            boxes.append((self.clicks[-1][0],self.e.candidate.box[0],shift[0]))
        self.callback=clicked;self.e._start_resource_route()
        self.assertEqual(len(boxes),4)
        for x,left,offset in boxes:self.assertAlmostEqual(left,600+offset,delta=1)
        self.assertGreater(boxes[-1][0],boxes[0][0])

    def test_next_attempt_burst_counts_as_one_request_and_keeps_counter(self):
        self.own_gap();self.e.f_enable()
        self.assertEqual(len(self.clicks),4);self.assertEqual(self.e.next_attempt_click_tries,1)
        self.assertEqual(self.e.next_attempt_sent_used,1);self.assertEqual(self.f.nodes[99].used,1)

    def test_start_during_next_attempt_burst_stops_remaining_probes(self):
        self.own_gap();self.callback=self.start;self.e.f_enable()
        self.assertEqual(len(self.clicks),1);self.assertEqual(self.e.next_attempt_sent_used,1)

    def test_no_combat_and_no_distance_still_arms_stalled_route_recovery(self):
        self.e.native_route_started_at=94;self.e.last_progress=94
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.assertIsNotNone(self.e.view_recovery);self.assertEqual(self.f.attacks,{})

    def test_far_resource_with_unchanging_distance_also_recovers_view(self):
        self.e.native_route_started_at=94;self.e.last_progress=94
        self.e.distance_live=28;self.e.distance_live_at=100
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.assertIsNotNone(self.e.view_recovery)

    def test_far_but_progressing_route_does_not_waste_time_on_camera_sweep(self):
        self.e.native_route_started_at=80;self.e.last_progress=99.5
        self.e.distance_live=25;self.e.distance_live_at=100
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.assertIsNone(self.e.view_recovery)

    def test_inactive_next_attempt_after_fall_can_use_view_recovery(self):
        self.own_gap();self.e.next_attempt_wait_at=97;self.e.next_attempt_sent_used=1
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.assertIsNotNone(self.e.view_recovery)
        self.clock=self.e.view_recovery.next_at+.1
        self.assertTrue(self.e._view_recovery_tick(self.frame,AIR,self.clock))
        self.clock+=.21;self.e.f_enable()
        self.assertGreater(len(self.clicks),0);self.assertFalse(self.e.stop_event.is_set())

    def test_unreachable_inactive_resource_is_skipped_without_stopping_bot(self):
        self.own_gap();self.e.resource_flight_owned=True;self.e.next_attempt_wait_at=97
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.clock=self.e.view_recovery.until+.1
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.stop_event.is_set())
        self.assertIn('END_AIR',self.commands);self.assertGreater(self.e.resource_retry_after[(1,99)],self.clock)
        self.assertIsNone(self.e._own_collection())
        self.assertFalse(self.e._adopt_network_collection())
        self.assertIsNotNone(self.e._navigation_observation(None,self.clock))

    def test_actual_new_attempt_at_skip_boundary_wins_and_preserves_wings(self):
        self.own_gap();self.e.resource_flight_owned=True;self.e.next_attempt_wait_at=97
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.clock=self.e.view_recovery.until+.1;self.start()
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.assertIsNone(self.e.view_recovery);self.assertNotIn('END_AIR',self.commands)
        self.assertEqual(self.e.resource_retry_after,{})

    def test_new_active_attempt_revokes_skip_permission_before_manual_movement(self):
        self.own_gap();self.e.abandoning_binding=(1,99)
        original=self.e.screen.frame
        def frame():self.start();return original()
        self.e.screen.frame=frame
        self.assertFalse(self.e._cancel_autopath(allow_inactive_collection=True))
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_active_collection_can_be_adopted_even_if_actor_was_temporarily_ignored(self):
        self.e.resource_retry_after[(1,99)]=145;self.start()
        self.assertIsNotNone(self.e._own_collection())

    def test_expired_quarantine_does_not_resurrect_an_old_inactive_collection(self):
        self.own_gap();self.e.next_attempt_wait_at=97
        self.e._view_recovery_tick(self.frame,GROUND,self.clock)
        self.clock=self.e.view_recovery.until+.1;self.e._view_recovery_tick(self.frame,GROUND,self.clock)
        self.clock+=46
        self.assertIsNone(self.e._own_collection());self.assertFalse(self.e._adopt_network_collection())
        self.assertEqual(self.e.mode,'SEARCH')

    def test_skipped_inactive_collection_allows_actual_patrol_movement(self):
        from navigation import Drive
        self.own_gap();self.e.next_attempt_wait_at=97
        self.e._view_recovery_tick(self.frame,GROUND,self.clock)
        self.clock=self.e.view_recovery.until+.1;self.e._view_recovery_tick(self.frame,GROUND,self.clock)
        self.e._motion(Drive(forward=.6))
        self.assertNotEqual(self.pad.axes,(0,0,0,0))

    def test_new_actual_collection_can_reuse_previously_abandoned_actor(self):
        self.own_gap();self.e.abandoned_lease=(1,99,1000)
        self.assertIsNone(self.e._own_collection())
        self.f.nodes[99].gather_time=1100;self.f.attempt_active=True
        self.assertIsNotNone(self.e._own_collection())
        self.f.attempt_active=False
        self.assertIsNotNone(self.e._own_collection())

    def test_reselecting_old_actor_cannot_turn_abandoned_lease_into_gather_proof(self):
        self.own_gap();self.e.abandoned_lease=(1,99,1000)
        self.assertFalse(self.e._net_gather_proof())

    def test_skip_permission_never_authorizes_wing_closure_for_another_actor(self):
        self.own_gap();self.e.abandoning_binding=(1,100)
        self.assertFalse(self.e._can_abandon_resource());self.assertFalse(self.e._end_air_still_allowed())

class HitboxGeometry(unittest.TestCase):
    def test_small_ui_scales_have_multiple_distinct_near_caption_points(self):
        for scale in (.5,1,1.5):
            c=SimpleNamespace(box=(100,100,round(60*scale),round(20*scale)),click_x=100+round(30*scale),click_y=100+round(20*scale)+6)
            points=ether_click_points(c,1280,720)
            self.assertEqual(len(points),4)
            self.assertEqual(len(set(x for x,y in points)),1)
            gaps=[y-(c.box[1]+c.box[3]) for x,y in points]
            self.assertTrue(all(b>a for a,b in zip(gaps,gaps[1:])))
            self.assertGreater(gaps[-1],30)

    def test_points_are_clipped_at_screen_edges(self):
        c=SimpleNamespace(box=(1265,710,20,10),click_x=1290,click_y=750)
        self.assertTrue(all(0<=x<1280 and 0<=y<720 for x,y in ether_click_points(c,1280,720)))

if __name__=='__main__':unittest.main()
