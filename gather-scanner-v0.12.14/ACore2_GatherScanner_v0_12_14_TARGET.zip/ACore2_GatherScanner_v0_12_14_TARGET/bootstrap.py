from pathlib import Path
import json,os,subprocess,sys,venv
from runtime_env import runtime_dir,runtime_python,find_runtime,requirement_hash
ROOT=Path(__file__).resolve().parent

def main():
 if not (3,10)<=sys.version_info[:2]<(3,14) or sys.maxsize<=2**32:raise RuntimeError('Нужен Python 3.12 x64; поддерживаются 3.10–3.13')
 python=find_runtime(ROOT)
 if python is None:
  env=runtime_dir(ROOT);env.parent.mkdir(parents=True,exist_ok=True)
  if not runtime_python(env).is_file():venv.EnvBuilder(with_pip=True).create(env)
  python=runtime_python(env);install_env=os.environ.copy();install_env['VGAMEPAD_SKIP_VIGEMBUS_INSTALL']='true'
  subprocess.run([str(python),'-m','pip','install','--no-cache-dir','--disable-pip-version-check','-r',str(ROOT/'requirements.txt')],check=True,env=install_env)
  subprocess.run([str(python),str(ROOT/'check_scene.py')],check=True,cwd=ROOT)
  (env/'ready.json').write_text(json.dumps({'requirements_sha256':requirement_hash(ROOT),'python_version':list(sys.version_info[:2])})+'\n')
 else:
  print('Использую общее окружение:',python,flush=True)
  subprocess.run([str(python),str(ROOT/'check_scene.py')],check=True,cwd=ROOT)
 print('Готово. Окружение общее для версий с одинаковыми зависимостями; START.bat запускает бот из этой папки.')
if __name__=='__main__':main()
