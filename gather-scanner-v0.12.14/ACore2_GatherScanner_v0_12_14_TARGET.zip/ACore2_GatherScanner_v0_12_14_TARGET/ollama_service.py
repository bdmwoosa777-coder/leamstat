"""Start an already installed loopback Ollama when connection is refused.
No installation, model pull, process killing or changes to other services.
"""
from pathlib import Path
import os,shutil,subprocess,threading,time,urllib.error,errno

def refused(exc):
 reason=exc.reason if isinstance(exc,urllib.error.URLError) else exc
 return isinstance(reason,ConnectionRefusedError) or getattr(reason,'winerror',None)==10061 or getattr(reason,'errno',None)==errno.ECONNREFUSED

class OllamaService:
 def __init__(self,root,emit):self.root=Path(root);self.emit=emit;self.next_start=0;self.process=None;self.windows=os.name=='nt'
 def ensure(self,exc):
  if not self.windows or not refused(exc) or time.monotonic()<self.next_start:return False
  if self.process is not None and self.process.poll() is None:return False
  self.next_start=time.monotonic()+60
  exe=shutil.which('ollama') or next((str(p) for p in (Path(os.environ.get('LOCALAPPDATA',''))/'Programs/Ollama/ollama.exe',Path(os.environ.get('ProgramFiles','C:/Program Files'))/'Ollama/ollama.exe') if p.is_file()),None)
  if exe is None:self.emit('OLLAMA_START: программа не найдена; выполните SETUP_ANALYZER.bat');return False
  env=os.environ.copy();env['OLLAMA_HOST']='127.0.0.1:11434'
  try:
   self.process=subprocess.Popen([exe,'serve'],env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   process=self.process
   def drain():
    tail=b''
    try:
     while True:
      part=process.stderr.read1(4096)
      if not part:break
      tail=(tail+part)[-65536:];(self.root/'ollama_start.log').write_bytes(tail)
    except OSError:pass
   threading.Thread(target=drain,daemon=True).start();self.emit('OLLAMA_START: запускаю установленный локальный сервер; движение не ждёт запуска');return True
  except OSError as err:self.emit('OLLAMA_START: '+str(err));return False
