"""Small stdlib launcher; can run under the Python Manager's default Python."""
from pathlib import Path
import subprocess,sys
from runtime_env import find_runtime
ROOT=Path(__file__).resolve().parent
ALLOWED={'app.py','setup_analyzer.py','check_scene.py','check_hybrid.py','route_preview.py'}
def main(argv=None):
 args=list(sys.argv[1:] if argv is None else argv)
 if not args or args[0] not in ALLOWED:raise ValueError('Неизвестный инструмент запуска')
 python=find_runtime(ROOT)
 if python is None:
  result=subprocess.run([sys.executable,str(ROOT/'launch_setup.py')],cwd=ROOT)
  if result.returncode:return result.returncode
  python=find_runtime(ROOT)
 if python is None:raise RuntimeError('Общее окружение не подготовлено: выполните SETUP.bat')
 return subprocess.run([str(python),str(ROOT/args[0]),*args[1:]],cwd=ROOT).returncode
if __name__=='__main__':raise SystemExit(main())
