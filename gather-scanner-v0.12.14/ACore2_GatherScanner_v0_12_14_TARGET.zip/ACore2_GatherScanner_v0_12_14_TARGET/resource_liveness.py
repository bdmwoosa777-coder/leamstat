"""Bounded missing-UI waits and exact-attempt retirement, never fake depletion."""
class ResourceLiveness:
 def __init__(self):
  self.key=None;self.since=None;self.retired_attempts={};self.hard_retired=set();self.attempt_key=None;self.attempt_since=None
 @staticmethod
 def attempt(view,node):
  if not view or not view['ready'] or node is None:return None
  s=view['state']
  return (view['flow'],s.own,node.actor,s.started if s.started is not None else node.gather_time,s.attempt_ordinal)
 def retired(self,view,node):
  key=self.attempt(view,node)
  return bool(key and self.retired_attempts.get(key[:3])==key)
 def retire(self,view,node,hard=False):
  key=self.attempt(view,node)
  if key is None:return
  self.retired_attempts[key[:3]]=key
  if hard:self.hard_retired.add(key)
  while len(self.retired_attempts)>16:self.retired_attempts.pop(next(iter(self.retired_attempts)))
  self.hard_retired.intersection_update(self.retired_attempts.values())
 def hard(self,view,node):return self.attempt(view,node) in self.hard_retired
 def restore(self,view,node):
  key=self.attempt(view,node)
  if key and self.retired(view,node):self.retired_attempts.pop(key[:3],None)
 def reset(self):self.key=None;self.since=None;self.attempt_key=None;self.attempt_since=None
 def expired_attempt(self,key,now,age=None):
  if key is None:self.attempt_key=None;self.attempt_since=None;return False
  if key!=self.attempt_key:self.attempt_key=key;self.attempt_since=now
  return now-self.attempt_since>=15 or age is not None and age>=15
 def due(self,key,now,panel,seconds):
  if key is None or panel:self.key=None;self.since=None;return False
  if key!=self.key:self.key=key;self.since=now
  return now-self.since>=seconds
