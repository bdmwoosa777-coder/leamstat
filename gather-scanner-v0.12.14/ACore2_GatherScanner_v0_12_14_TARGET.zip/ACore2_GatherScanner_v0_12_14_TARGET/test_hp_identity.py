"""Synthetic cross-source identity proof; no private network captures."""
import struct,time,unittest
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
from network_state import Telemetry,Flow
from test_network_state import v
from network_feed import NetworkFeed
from hybrid_engine import HybridGatherEngine as AIGatherEngine
from health import HPReading
from network_defense import attack_reason

def hp_row(actor,hp,maximum=12000):
 return v(actor)+b'\2'+v(2)+b'\0'+struct.pack('<Q',hp)+b'\7'+struct.pack('<Q',maximum)

def hit(target,source=55,damage=100):
 return v(target)+v(4)+v(0)+v(source)+struct.pack('<I',100)+b'\0'+v(2)+struct.pack('<II',1,1)+v(10000)+v(damage)+b'\1\0'

class HPIdentity(unittest.TestCase):
 def setUp(self):self.t=Telemetry()
 def sample(self,hp,stamp,actor=7,other=False):
  self.t.feed(1,'0438',hit(actor),stamp-10)
  self.t.feed(1,'008d',hp_row(actor,hp),stamp)
  if other:
   self.t.feed(1,'0438',hit(8),stamp)
   self.t.feed(1,'008d',hp_row(8,hp),stamp)
  return self.t.confirm_own_hp(1,hp,12000,stamp)
 def test_two_exact_changed_hp_pairs_restore_recent_verified_attacker(self):
  self.assertFalse(self.sample(11900,1000));self.assertTrue(self.sample(11800,1400))
  f=self.t.flows[1];self.assertEqual(f.own,7);self.assertEqual(f.identity_source,'hud-hp-correlated')
  self.assertEqual(f.attacks[55],1390);f.selected=55;self.assertIsNone(attack_reason(f,55,1450))
 def test_one_pair_or_repeated_ocr_of_same_packet_cannot_identify(self):
  self.sample(11900,1000)
  for stamp in (1010,1100,1200):self.assertFalse(self.t.confirm_own_hp(1,11900,12000,stamp))
  self.assertIsNone(self.t.flows[1].own)
 def test_same_full_hp_is_never_enough(self):
  self.assertFalse(self.sample(12000,1000));self.assertFalse(self.sample(12000,1400));self.assertIsNone(self.t.flows[1].own)
 def test_no_attack_cannot_establish_identity_from_stats(self):
  for hp,stamp in ((11900,1000),(11800,1400)):
   self.t.feed(1,'008d',hp_row(7,hp),stamp);self.assertFalse(self.t.confirm_own_hp(1,hp,12000,stamp))
 def test_neighbour_or_pet_hits_do_not_prove_our_hp(self):
  for hp,stamp in ((11900,1000),(11800,1400)):
   self.t.feed(1,'0438',hit(8),stamp-10);self.t.feed(1,'008d',hp_row(7,hp),stamp)
   self.assertFalse(self.t.confirm_own_hp(1,hp,12000,stamp))
 def test_ambiguous_players_with_identical_values_are_rejected(self):
  self.assertFalse(self.sample(11900,1000,other=True));self.assertFalse(self.sample(11800,1400,other=True));self.assertIsNone(self.t.flows[1].own)
 def test_npc_or_resource_cannot_be_bound_as_self(self):
  for kind in ('npcs','nodes'):
   t=Telemetry();t.flows[1]=Flow();getattr(t.flows[1],kind)[7]={}
   old=self.t;self.t=t
   self.sample(11900,1000);self.assertFalse(self.sample(11800,1400));self.assertIsNone(t.flows[1].own);self.t=old
 def test_existing_direct_identity_is_never_replaced(self):
  self.sample(11900,1000);self.t.flows[1].own=8;self.assertFalse(self.sample(11800,1400));self.assertEqual(self.t.flows[1].own,8)
 def test_old_mismatched_or_foreign_flow_reading_does_not_bind(self):
  self.sample(11900,1000);self.t.feed(1,'0438',hit(7),1390);self.t.feed(1,'008d',hp_row(7,11800),1400)
  for args in ((1,11700,12000,1400),(1,11800,13000,1400),(2,11800,12000,1400),(1,11800,12000,5000)):
   self.assertFalse(self.t.confirm_own_hp(*args))
  self.assertIsNone(self.t.flows[1].own)
 def test_regeneration_only_does_not_prove_changed_damage(self):
  self.sample(11800,1000);self.assertFalse(self.sample(11900,1400));self.assertIsNone(self.t.flows[1].own)
 def test_new_map_erases_unbound_identity_anchor(self):
  self.sample(11900,1000);data=bytearray(46);struct.pack_into('<I',data,4,2)
  self.t.flows[1].map_id=1;self.t.feed(1,'2136',bytes(data),1200)
  self.assertIsNone(self.t.flows[1].hud_anchor);self.assertFalse(self.sample(11800,1400))
 def test_old_low_hp_cannot_match_a_later_packet_for_another_actor(self):
  self.sample(11900,1000);self.sample(11800,5000,actor=8);self.assertIsNone(self.t.flows[1].own)
 def test_hp_packet_advancing_during_ocr_keeps_exact_capture_pair(self):
  self.t.feed(1,'0438',hit(7),990);self.t.feed(1,'008d',hp_row(7,11900),1000)
  self.t.feed(1,'0438',hit(7),1390);self.t.feed(1,'008d',hp_row(7,11800),1400)
  self.assertFalse(self.t.confirm_own_hp(1,11900,12000,1050))
  self.assertTrue(self.t.confirm_own_hp(1,11800,12000,1450));self.assertEqual(self.t.flows[1].own,7)
 def test_temporary_nonmatching_ocr_cannot_erase_fresh_first_pair(self):
  self.sample(11900,1000);self.assertFalse(self.t.confirm_own_hp(1,11850,12000,1200))
  self.assertTrue(self.sample(11800,1400))
 def test_snapshot_cannot_mutate_bootstrap_state(self):
  self.sample(11900,1000);f=self.t.flows[1];snap=f.snapshot();snap.unbound_stats.clear();snap.unbound_hits.clear()
  self.assertTrue(f.unbound_stats);self.assertTrue(f.unbound_hits)

class BootstrapIntegration(unittest.TestCase):
 def test_feed_requires_fresh_unique_flow_and_emits_identity_notice(self):
  log=[];n=NetworkFeed(log.append);now=int(time.time()*1000)
  for hp,stamp in ((11900,now-300),(11800,now)):
   n.ingest({'type':'frame','flow':1,'op':'0438','hex':hit(7).hex(),'t':stamp-10})
   n.ingest({'type':'frame','flow':1,'op':'008d','hex':hp_row(7,hp).hex(),'t':stamp})
   ok=n.confirm_own_hp(hp,12000,stamp)
  self.assertTrue(ok);self.assertTrue(n.view()['identity_ready']);self.assertTrue(any('hud-hp-correlated' in x for x in log))
 def test_visual_only_mode_does_not_try_to_bind_network_identity(self):
  e=object.__new__(AIGatherEngine);e.network=None
  e._health_identity_sample(HPReading(11900,12000),100,True)
 def test_ai_worker_enables_hp_for_unknown_identity_only(self):
  e=object.__new__(AIGatherEngine);e.network=SimpleNamespace(confirm_own_hp=lambda *a:None)
  e._net_view=lambda:{'ready':True,'state':Flow()}
  self.assertTrue(e._needs_visual_hp());e._net_view=lambda:{'ready':True,'state':Flow(own=7)};self.assertFalse(e._needs_visual_hp())
 def test_only_two_variant_ocr_verified_low_readings_are_submitted(self):
  calls=[];e=object.__new__(AIGatherEngine);e._focus_ok=lambda:True;e._needs_visual_hp=lambda:True
  e.network=SimpleNamespace(confirm_own_hp=lambda *a:calls.append(a))
  with patch('hybrid_engine.time.time',return_value=5),patch('hybrid_engine.time.monotonic',return_value=100):
   e._health_identity_sample(HPReading(11900,12000),99.8,False);e._health_identity_sample(HPReading(12000,12000),99.8,True)
   self.assertFalse(calls);e._health_identity_sample(HPReading(11900,12000),99.8,True)
  self.assertEqual(calls,[(11900,12000,4799)])
