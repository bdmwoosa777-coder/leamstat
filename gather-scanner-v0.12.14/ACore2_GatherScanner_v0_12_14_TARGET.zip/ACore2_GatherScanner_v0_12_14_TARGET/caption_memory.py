"""Bounded, session-only memory of captions contradicted by a local OCR read.

Store tiny letter masks, never coordinates or full frames. A different caption
at the same screen point remains eligible, including a real Ether above Morpha.
"""
import threading
import cv2
import numpy as np


class CaptionMemory:
 def __init__(self,ttl=120,limit=16):
  self.ttl=ttl;self.limit=limit;self.entries=();self.lock=threading.Lock()

 @staticmethod
 def signature(candidate):
  if candidate.glyph is None:return None
  shape,data=candidate.glyph
  if len(shape)!=2 or min(shape)<1 or max(shape)>1024 or len(data)!=shape[0]*shape[1]:return None
  mask=np.frombuffer(data,np.uint8).reshape(shape);y,x=np.nonzero(mask>100)
  if len(x)<8:return None
  crop=mask[y.min():y.max()+1,x.min():x.max()+1]
  return crop.shape[1]/crop.shape[0],cv2.resize(crop,(96,32),interpolation=cv2.INTER_AREA)>110

 @staticmethod
 def same(a,b):
  ratio,mask=a;other,reference=b
  if not .85<ratio/other<1.18:return False
  dice=2*np.count_nonzero(mask&reference)/max(1,np.count_nonzero(mask)+np.count_nonzero(reference))
  if dice>=.90:return True
  if dice<.80:return False
  # Font downsampling changes a one-pixel edge. Require both substantial
  # exact overlap and very similar smoothed letters, not dilated word blobs.
  smooth=cv2.GaussianBlur(mask.astype(np.float32),(5,5),0).reshape(-1)
  saved=cv2.GaussianBlur(reference.astype(np.float32),(5,5),0).reshape(-1)
  return float(np.dot(smooth,saved)/max(1e-6,np.linalg.norm(smooth)*np.linalg.norm(saved)))>=.95

 def remember(self,candidate,actual,now):
  value=self.signature(candidate)
  if not actual or actual==candidate.name or value is None:return False
  with self.lock:
   entries=[e for e in self.entries if now-e[3]<self.ttl
            and not (e[0]==candidate.name and self.same(value,e[2]))]
   self.entries=tuple((entries+[(candidate.name,actual,value,now)])[-self.limit:])
  return True

 def rejected(self,candidate,now):
  value=self.signature(candidate)
  if value is None:return None
  with self.lock:
   self.entries=tuple(e for e in self.entries if 0<=now-e[3]<self.ttl);entries=self.entries
  return next((actual for claimed,actual,saved,_ in entries
               if claimed==candidate.name and self.same(value,saved)),None)
