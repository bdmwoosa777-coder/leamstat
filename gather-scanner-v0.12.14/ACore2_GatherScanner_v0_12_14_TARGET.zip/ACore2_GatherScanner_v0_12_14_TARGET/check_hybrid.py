"""Check the actual advisor API. Never captures or controls the game."""
from pathlib import Path
import json,time
import numpy as np
from ground_routes import GroundMap
from hybrid_navigation import RouteClient

def main():
 root=Path(__file__).resolve().parent;cfg=json.loads((root/'settings_gather.json').read_text(encoding='utf-8'))
 client=RouteClient(cfg['analyzer_url'],cfg['analyzer_model']);data={'model':client.model,'synthetic':True,'game_navigation_verified':False};started=time.monotonic()
 try:
  client.probe();data['answer']=client.analyze(np.full((360,640,3),60,np.uint8),GroundMap(),{'mode':'blank_test','expected':'no visible paths'},timeout=30)
  data['valid_answer']=data['answer']['route_id']==-1;data['response_shape']=client.last_shape
 except Exception as exc:data['valid_answer']=False;data['error']=str(exc);data['raw_reply']=getattr(client,'last_raw',b'')[:8192].decode(errors='replace')
 data['seconds']=round(time.monotonic()-started,2)
 (root/'hybrid_check.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(data,ensure_ascii=False,indent=2))
 print('Это проверка формата советника, не умения обходить реальные стены. Навигатор работает независимо от ответа.')
 return 0 if data['valid_answer'] else 1
if __name__=='__main__':raise SystemExit(main())
