"""Goal ownership, stale detour epochs, urgent defense and fresh capture transport."""
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import threading,unittest,sys,time
import cv2,numpy as np
import gather_engine as ge,hybrid_engine as he,screen_capture as sc
from hybrid_engine import HybridGatherEngine
from hybrid_navigation import HybridPlanner
from minimap import Marker
from navigation import Drive
from flight import FlightReading,read_flight
from scene_navigation import Lane
from ground_routes import GroundMap
from control_timing import ControlTiming
from test_navigation import GatherFixture,radar
from test_network_control import Source
from test_hybrid import scene

GROUND=FlightReading(80,False)

class GoalOwnership(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=HybridGatherEngine({**old.cfg,'scene_navigation_enabled':True,'analyzer_enabled':False},self.log.append,self.input,network=self.source)
  self.e.screen=old.screen;self.e.bridge=old.bridge
  self.e.scene_host=SimpleNamespace(offer=lambda *a:None,current=lambda *a:None,close=lambda:None)
  self.clock=100.
  p=patch.object(he.time,'monotonic',side_effect=lambda:self.clock);p.start();self.addCleanup(p.stop)
 def goal(self,x=150):self.e.nav.update(radar([Marker('Эфир',x,100,.99,abs(x-100),'aether')]),self.clock)
 def plan(self):return self.e._scene_plan(self.frame,radar(),GROUND,Drive(.9),self.clock)
 def poison(self):
  p=self.e.hybrid;p.problem_since=80;p.blocked_at=80;p.last_progress=80;p.tracking=True;p.avoid=[(90,200)]
 def test_defense_pause_does_not_expire_resource_on_the_first_frame_after_battle(self):
  self.goal();self.plan();self.poison();self.e.change_mode('DEFENSE');self.clock=125;self.e.change_mode('SEARCH')
  self.assertGreater(self.plan().forward,.5);self.assertIsNotNone(self.e.nav.goal);self.assertFalse(self.e.nav.excluded)
 def test_caption_verification_does_not_age_an_old_wall_timeout(self):
  self.goal();self.plan();self.poison();self.e.change_mode('ACQUIRE_WAIT');self.clock=110;self.e.change_mode('SEARCH')
  self.assertGreater(self.plan().forward,.5);self.assertFalse(self.e.nav.excluded)
 def test_new_marker_cannot_inherit_unreachable_verdict_from_previous_goal(self):
  self.goal();self.plan();self.poison();self.e.nav.finish_goal(100);self.goal(160)
  self.assertGreater(self.plan().forward,.5);self.assertFalse(self.e.nav.excluded)
 def test_marker_jitter_keeps_goal_epoch_and_does_not_clear_actual_obstacle_state(self):
  self.goal();self.plan();epoch=self.e.nav.goal_epoch;self.e.hybrid.problem_since=99
  self.clock=100.5;self.goal(151);self.plan()
  self.assertEqual(self.e.nav.goal_epoch,epoch);self.assertIsNotNone(self.e.hybrid.problem_since)
 def test_surveys_without_measured_collision_keep_the_same_ether_marker(self):
  self.goal();self.plan();self.e.hybrid.problem_since=80;self.e.hybrid.blocked_at=80;original=self.e.nav.goal
  self.plan();self.assertIs(self.e.nav.goal,original);self.assertFalse(self.e.nav.excluded)
  self.assertTrue(any('GOAL_KEEP' in s for s in self.log))
 def test_completed_arrival_and_sky_lookup_drop_old_detours_before_next_ground_step(self):
  self.goal();self.plan();self.poison()
  self.e._scene_plan(self.frame,radar(),GROUND,Drive(pitch=.45),self.clock)
  self.assertIsNone(self.e.hybrid.problem_since);self.assertEqual(self.e.hybrid.avoid,[])
 def test_hazard_survives_a_mode_change_and_resource_switch(self):
  self.e.hybrid.hazard_until=float('inf');self.e.change_mode('DEFENSE');self.e.change_mode('SEARCH')
  self.goal();self.plan();self.assertEqual(self.e.hybrid.hazard_until,float('inf'))
 def test_urgent_defense_begins_without_any_new_capture_or_flight_scan(self):
  self.e.network_attacker=55;self.source.state.attacks[55]=1000;self.source.state.npcs[55]={'time':900}
  with patch.object(self.e.screen,'frame',side_effect=AssertionError('new capture during urgent reaction')),patch.object(ge,'read_flight',side_effect=AssertionError('repeat flight check')):
   self.e._begin_network_defense(False)
  self.assertEqual(self.e.mode,'DEFENSE');self.assertIsNotNone(self.e.network_defense)
 def test_priority_reacts_to_a_fresh_hit_without_requiring_the_next_screen_frame(self):
  self.source.state.attacks[55]=1000;self.source.state.npcs[55]={'time':900,'born_at':900}
  with patch.object(ge.time,'time',return_value=1.1),patch.object(self.e.screen,'frame',side_effect=AssertionError('capture before hit')):
   self.assertTrue(self.e._priority_network_defense(self.clock))
  self.assertEqual(self.e.mode,'DEFENSE')
 def test_existing_defense_episode_is_serviced_before_another_capture(self):
  self.e.network_defense=object()
  with patch.object(self.e,'_network_defense_tick',return_value=True) as tick:
   self.assertTrue(self.e._priority_network_defense(self.clock));tick.assert_called_once_with(self.clock)
  self.e.network_defense=None
 def test_priority_cannot_bypass_death_map_or_manual_stop(self):
  with patch.object(self.e,'_net_defense') as defend:
   self.e.death_wait=True;self.assertFalse(self.e._priority_network_defense(self.clock))
   self.e.death_wait=False;self.e.map_active=True;self.assertFalse(self.e._priority_network_defense(self.clock))
   self.e.map_active=False;self.e.stop_event.set();self.assertFalse(self.e._priority_network_defense(self.clock))
   defend.assert_not_called()
 def test_existing_air_state_still_selects_air_defense_without_a_new_capture(self):
  self.e.cfg['defense_air_search']=True;self.e.budget.airborne=True;self.e.network_attacker=55
  with patch.object(self.e.screen,'frame',side_effect=AssertionError('new capture')):self.e._begin_network_defense(False)
  self.assertIsNotNone(self.e.defense_air_view)

class DirectFloor(unittest.TestCase):
 def test_depth_texture_on_dense_floor_does_not_deflect_course(self):
  p=HybridPlanner();s=replace(scene(free=.99),lanes=(Lane(.99,0,.05,0),)*3)
  a=p.choose(Drive(.9),s,radar(),100,face_goal=True)
  self.assertEqual(a.drive.forward,.9);self.assertEqual(a.drive.strafe,0);self.assertEqual(a.drive.yaw,0)
 def test_old_side_route_commitment_does_not_override_fresh_dense_floor(self):
  p=HybridPlanner();p.commit=40;p.commit_until=103;p.avoid=[(90,120)];p.problem_since=90
  s=replace(scene(free=.99),lanes=(Lane(.99,0,.05,0),)*3)
  a=p.choose(Drive(.9),s,radar(),100,face_goal=True)
  self.assertEqual(a.drive.forward,.9);self.assertFalse(a.skip)
 def test_visually_dense_floor_cannot_erase_measured_collision_after_delivered_walk(self):
  p=HybridPlanner();p.tracking=True;p.last_progress=100
  s=replace(scene(free=.99,t=104),lanes=(Lane(.99,0,.05,0),)*3)
  r=radar();r.motion_valid=True;r.displacement=(0,0)
  a=p.choose(Drive(.9),s,r,104,face_goal=True)
  self.assertIsNotNone(p.problem_since);self.assertNotIn('плотная свободная земля',a.reason)
 def test_drop_wall_and_large_depth_edge_do_not_get_dense_floor_exemption(self):
  base=replace(scene(free=.99),lanes=(Lane(.99,0,.05,0),)*3)
  views=(replace(base,ground=replace(base.ground,drop_support=.1)),replace(base,lanes=(Lane(.3,.65,.02,0),)*3),replace(base,lanes=(Lane(.99,0,.2,0),)*3))
  for s in views:
   a=HybridPlanner().choose(Drive(.9),s,radar(),100,face_goal=True)
   self.assertNotIn('плотная свободная земля',a.reason)
 def test_explicit_advisor_detour_is_still_validated_in_the_local_graph(self):
  s=replace(scene(free=.99),lanes=(Lane(.99,0,.05,0),)*3)
  a=HybridPlanner().choose(Drive(.9),s,radar(),100,hint=0)
  self.assertTrue(a.detour);self.assertLess(a.drive.strafe,0)

class FreshCapture(unittest.TestCase):
 def setUp(self):
  self.s=sc.ScreenCapture();self.s.hwnd=1
  self.s.win32gui=SimpleNamespace(IsWindow=lambda h:True,ClientToScreen=lambda h,p:(10,20),GetClientRect=lambda h:(0,0,32,24))
  self.created=[]
  outer=self
  class Capture:
   def __init__(self):self.owner=threading.get_ident();self.calls=0;self.closed=0;outer.created.append(self)
   def grab(self,rect):
    assert self.owner==threading.get_ident();self.calls+=1
    return np.full((24,32,4),self.calls,np.uint8)
   def close(self):self.closed+=1
  self.patches=[patch.object(sc,'os',SimpleNamespace(name='nt')),patch.dict(sys.modules,{'mss':SimpleNamespace(mss=Capture)})]
  for p in self.patches:p.start();self.addCleanup(p.stop)
  self.addCleanup(self.close)
 def close(self):
  holder=getattr(self.s._captures,'holder',None)
  if holder:holder.close();del self.s._captures.holder
 def test_same_thread_reuses_gdi_handles_but_always_grabs_new_pixels(self):
  a,pos=self.s.frame();b,_=self.s.frame()
  self.assertEqual(len(self.created),1);self.assertEqual(self.created[0].calls,2)
  self.assertFalse(np.array_equal(a,b));self.assertEqual(pos,(10,20));self.assertEqual(a.shape,(24,32,3))
 def test_two_threads_never_share_the_same_native_capture_handle(self):
  errors=[]
  def work():
   try:self.s.frame();self.s.frame()
   except Exception as e:errors.append(e)
  threads=[threading.Thread(target=work) for _ in range(2)]
  for t in threads:t.start()
  for t in threads:t.join(1)
  self.assertFalse(errors);self.assertEqual(len(self.created),2);self.assertTrue(all(c.calls==2 for c in self.created))
 def test_error_closes_only_failed_session_and_next_capture_reconnects(self):
  self.s.frame();first=self.created[0];first.grab=lambda r:(_ for _ in ()).throw(RuntimeError('grab failed'))
  with self.assertRaises(RuntimeError):self.s.frame()
  self.assertEqual(first.closed,1);self.s.frame();self.assertEqual(len(self.created),2)
 def test_frame_buffer_does_not_alias_a_later_capture(self):
  first,_=self.s.frame();snapshot=first.copy();self.s.frame();np.testing.assert_array_equal(first,snapshot)

class ControlTimingTests(unittest.TestCase):
 def test_slow_completed_stage_is_reported_without_changing_its_result(self):
  notes=[];timer=ControlTiming(notes.append);clock=[100.]
  def work():clock[0]+=2;return 7
  with patch('control_timing.time.monotonic',side_effect=lambda:clock[0]):self.assertEqual(timer.call('capture',work),7)
  self.assertTrue(any('capture' in s for s in notes));self.assertIsNone(timer.active)
 def test_exception_and_nested_stage_restore_observer_state(self):
  timer=ControlTiming(lambda m:None)
  with self.assertRaises(ValueError):timer.call('outer',lambda:timer.call('inner',lambda:(_ for _ in ()).throw(ValueError())))
  self.assertIsNone(timer.active)
 def test_blocked_stage_can_be_identified_without_sending_any_input(self):
  timer=ControlTiming(lambda m:None,stalled=.01);ready=threading.Event();release=threading.Event()
  def wait():ready.set();release.wait(1)
  thread=threading.Thread(target=lambda:timer.call('capture',wait));thread.start();self.assertTrue(ready.wait(1))
  message=timer.inspect(time.monotonic()+1);release.set();thread.join(1)
  self.assertIn('capture',message);self.assertIn('CONTROL_WAIT',message);timer.close()

class VectorFlight(unittest.TestCase):
 def test_air_fixture_preserves_energy_and_track_evidence_at_four_resolutions(self):
  f=cv2.imread(str(Path(__file__).parent/'testdata/air_gather_example.jpg'))
  for w,energy,evidence in ((1280,80.9,238),(2048,80.9,240),(2560,80.9,239),(3840,80.5,241)):
   r=read_flight(cv2.resize(f,(w,round(w*9/16))))
   self.assertEqual((r.energy,r.confirmed,r.evidence),(energy,True,evidence))
 def test_ground_fixture_remains_negative_at_four_resolutions(self):
  f=cv2.imread(str(Path(__file__).parent/'testdata/orihalkon_example.jpg'))
  for w,evidence in ((1280,58),(2048,58),(2560,61),(3840,62)):
   r=read_flight(cv2.resize(f,(w,round(w*9/16))))
   self.assertEqual((r.energy,r.confirmed,r.evidence),(None,False,evidence))
 def test_small_or_uniform_frames_do_not_invent_airborne_state(self):
  for h,w in ((360,640),(720,1280),(1152,2048),(2160,3840)):
   r=read_flight(np.full((h,w,3),120,np.uint8));self.assertFalse(r.confirmed);self.assertIsNone(r.energy)

if __name__=='__main__':unittest.main()
