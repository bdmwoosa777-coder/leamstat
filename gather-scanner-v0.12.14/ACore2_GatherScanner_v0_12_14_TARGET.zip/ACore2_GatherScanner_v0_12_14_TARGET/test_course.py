"""Delayed selection ACK cannot toggle auto-approach; fresh cone owns sky scans."""
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import math,time,unittest
import cv2,numpy as np
import app,gather_engine as ge,hybrid_engine as he
from hybrid_engine import HybridGatherEngine
from hybrid_navigation import HybridPlanner
from gamepad_input import GamepadInput
from navigation import Navigator,Drive
from minimap import MinimapVision,Marker
from ground_routes import GroundMap
from scene_navigation import Lane
from flight import FlightReading
from test_navigation import GatherFixture,radar
from test_network_control import Source
from test_hybrid import scene
from test_motion import wall

GROUND=FlightReading(80,False)

def air(angle,distance=10):
 a=math.radians(angle);return Marker('Эфир',100+distance*math.sin(a),100-distance*math.cos(a),.99,distance,'aether')

def cone(angle=90,half=45,markers=None):return replace(radar(markers,angle),cone_half_angle=half)

class FreshCone(unittest.TestCase):
 def nav(self):return Navigator({'air_search_wide':True,'ether_quick_search':True,'air_search_map_radius':22})
 def test_two_nearby_points_outside_the_cone_never_start_an_upward_scan(self):
  n=self.nav();r=cone(270,40,[air(30),air(150)])
  for t in (100,101,102):
   d=n.update(r,t);self.assertEqual(d.pitch,0);self.assertIsNone(n.air_since)
 def test_close_marker_behind_camera_has_no_overhead_exemption(self):
  n=self.nav();d=n.update(cone(270,45,[air(90,3)]),100)
  self.assertEqual(d.pitch,0);self.assertNotEqual(d.yaw,0)
 def test_raw_cone_overrides_old_steering_median_for_scan_permission(self):
  n=self.nav();n.last_heading=90;n.heading_at=100;n.headings.extend([90,90,90])
  d=n.update(cone(270,35,[air(90)]),100.1)
  self.assertEqual(d.pitch,0);self.assertIsNone(n.air_since);self.assertLess(d.forward,0)
 def test_target_inside_measured_cone_starts_lookup_and_logs_both_boundaries(self):
  n=self.nav();d=n.update(cone(90,50,[air(115)]),100)
  self.assertGreater(d.pitch,0);self.assertIn('±50',d.reason)
 def test_target_near_the_boundary_waits_for_a_better_heading(self):
  n=self.nav();d=n.update(cone(90,40,[air(127)]),100)
  self.assertEqual(d.pitch,0);self.assertGreater(abs(d.forward)+abs(d.strafe),.5)
 def test_started_scan_is_cancelled_if_camera_turns_away_from_target(self):
  n=self.nav();r=cone(90,45,[air(90)]);self.assertGreater(n.update(r,100).pitch,0)
  d=n.update(replace(r,heading=270),101)
  self.assertTrue(d.restore_pitch);self.assertEqual(d.pitch,0);self.assertIsNone(n.air_since)
 def test_marker_moving_out_of_the_cone_also_cancels_scan(self):
  n=self.nav();r=cone(90,45,[air(90,4)]);n.update(r,100)
  r=cone(90,45,[air(270,4)]);d=n.update(r,101)
  self.assertTrue(d.restore_pitch);self.assertEqual(d.pitch,0)
 def test_missing_cone_pauses_then_restores_rather_than_scanning_blindly(self):
  n=self.nav();r=cone(90,45,[air(90)]);n.update(r,100)
  missing=replace(r,heading=None,confidence=0)
  d=n.update(missing,101);self.assertEqual(d.pitch,0);self.assertFalse(d.restore_pitch)
  self.assertTrue(n.update(missing,102).restore_pitch)
 def test_far_marker_gets_approach_not_the_previous_sixty_pixel_lookup(self):
  d=self.nav().update(cone(90,45,[air(90,30)]),100)
  self.assertEqual(d.pitch,0);self.assertGreater(d.forward,.5)
 def test_cone_crossing_zero_degrees_uses_circular_angles(self):
  n=self.nav();d=n.update(cone(355,35,[air(5)]),100);self.assertGreater(d.pitch,0)
 def test_actual_white_boundary_lines_provide_bisector_and_half_angle(self):
  f=np.full((200,200,3),(70,100,120),np.uint8)
  cv2.line(f,(115,85),(170,30),(255,255,255),2);cv2.line(f,(115,115),(170,170),(255,255,255),2)
  heading,confidence,half=MinimapVision.cone_geometry(f,(100,100))
  self.assertLess(abs(heading-90),10);self.assertGreater(confidence,.3);self.assertGreater(half,35);self.assertLess(half,55)
  self.assertEqual(MinimapVision.cone_heading(f,(100,100)),(heading,confidence))

class PendingEmblem(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.e.cfg.update(resource_click_interaction=True,collection_event_driven=True,visual_route_hold=False)
  self.source=Source();self.e.network=self.source;self.f=self.source.state
  self.f.selected=0;self.f.collecting=None;self.f.attempt_active=False;self.f.nodes[99].template=1500000;self.f.nodes[99].gather_time=None
  self.e.target=None;self.e.target_confirmed=False;self.e.resource_hold=False;self.e.network_target=None
  self.c=replace(self.c,name='Эфир',click_x=695,click_y=315,emblem=(680,300,30,30))
  self.clock=100.;self.wall=1100;self.input.motion_worker=object()
  def wait(seconds,*args):self.clock+=seconds;return True
  for p in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),patch.object(GamepadInput,'wait',side_effect=wait),patch.object(ge,'find_resource_near',return_value=self.c)):
   p.start();self.addCleanup(p.stop)
 def begin(self):
  self.assertTrue(self.e.click_candidate(self.c,(0,0),refresh=False));self.assertEqual(self.pad.presses,1)
  self.assertEqual(self.e.mode,'VERIFY_EMBLEM');self.assertIsNotNone(self.e.emblem_acquisition)
 def test_delayed_selection_does_not_send_second_a_inside_acquisition(self):
  self.begin();self.assertNotIn('TAP_F',self.commands);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_repeated_acquisition_calls_while_ack_is_pending_never_click_again(self):
  self.begin()
  for _ in range(6):self.clock+=.1;self.assertTrue(self.e.click_candidate(self.c,(0,0),refresh=False))
  self.assertEqual(self.pad.presses,1);self.assertEqual(self.commands.count('ALT_DOWN'),1)
 def test_log_reproduction_selection_at_1_25_seconds_preserves_the_first_route(self):
  self.begin();clicked=self.e.emblem_acquisition['clicked'];self.clock=clicked+1.25
  self.f.selected=99;self.f.selection_time=self.wall
  self.assertTrue(self.e._service_emblem_acquisition(self.clock))
  self.assertEqual(self.e.mode,'APPROACH');self.assertTrue(self.e.route_active);self.assertTrue(self.e.route_f_sent)
  self.assertEqual(self.e.native_route_started_at,clicked);self.assertEqual(self.pad.presses,1);self.assertNotIn('TAP_F',self.commands)
 def test_own_start_before_selected_profile_hands_off_without_a(self):
  self.begin();self.f.selected=99;self.f.collecting=99;self.f.started=1200;self.f.nodes[99].gather_time=1200
  self.f.attempt_active=True;self.f.attempt_ordinal=1;self.wall=1200
  self.e._service_emblem_acquisition(self.clock)
  self.assertIsNone(self.e.emblem_acquisition);self.assertEqual(self.pad.presses,1);self.assertTrue(self.e.resource_hold)
 def test_pending_has_a_finite_deadline_without_click_or_manual_route_cancel(self):
  self.begin();self.clock=self.e.emblem_acquisition['until']+.01
  self.e._service_emblem_acquisition(self.clock)
  self.assertIsNone(self.e.emblem_acquisition);self.assertEqual(self.e.mode,'SEARCH');self.assertEqual(self.pad.presses,1)
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertNotIn('TAP_F',self.commands)
 def test_focus_loss_or_network_loss_cannot_click_or_claim(self):
  self.begin();self.e.screen.focused=lambda:False;self.e._service_emblem_acquisition(self.clock)
  self.e.screen.focused=lambda:True;self.source.ready=False;self.e._service_emblem_acquisition(self.clock)
  self.assertEqual(self.pad.presses,1);self.assertIsNotNone(self.e.emblem_acquisition)
 def test_npc_selection_is_not_accepted_as_the_pending_resource(self):
  self.begin();self.f.selected=55;self.f.selection_time=self.wall;self.f.npcs[55]={'time':1100}
  self.e._service_emblem_acquisition(self.clock);self.assertFalse(self.e.target_confirmed);self.assertEqual(self.pad.presses,1)
 def test_new_flow_revokes_pending_without_repeating_a(self):
  self.begin();original=self.source.view;self.source.view=lambda:{**original(),'flow':2}
  self.e._service_emblem_acquisition(self.clock)
  self.assertIsNone(self.e.emblem_acquisition);self.assertEqual(self.pad.presses,1)
 def test_no_yield_return_does_not_interrupt_the_pending_initial_approach(self):
  self.begin();self.e.cfg['no_yield_return_enabled']=True
  with patch.object(self.e.no_yield,'return_due',return_value=True),patch.object(self.e,'_start_return') as teleport:
   self.assertFalse(self.e._no_yield_tick(self.frame,GROUND,self.clock));teleport.assert_not_called()

class PurposefulCourse(unittest.TestCase):
 def test_free_direction_keeps_minimap_course_even_with_a_side_route(self):
  view=scene(free=.30);a=HybridPlanner().choose(Drive(.90),view,radar(),100)
  self.assertEqual(a.drive.forward,.90);self.assertEqual(a.drive.strafe,0);self.assertEqual(a.drive.yaw,0)
 def test_one_side_depth_edge_leaves_the_other_side_available_for_escape(self):
  p=HybridPlanner();p.choose(Drive(.9),wall(100),radar(),100)
  view=replace(wall(101.2),lanes=(Lane(.2,.7,.1,.0),Lane(.1,.8,.1,.0),Lane(.2,.7,0,.0)))
  a=p.choose(Drive(.9),view,radar(),101.2);self.assertTrue(a.escape);self.assertGreater(a.drive.strafe,0)
 def test_drop_or_both_hazardous_sides_do_not_get_active_movement(self):
  for view in (wall(101.2,drop=.2),replace(wall(101.2),lanes=(Lane(.2,.7,.1,0),)*3)):
   p=HybridPlanner();p.choose(Drive(.9),wall(100),radar(),100);self.assertFalse(p.choose(Drive(.9),view,radar(),101.2).escape)
 def test_goal_walk_speed_default_is_stronger_than_old_point_seven_eight(self):self.assertEqual(app.DEFAULT['resource_walk_speed'],.90)
 def test_started_sideways_escape_survives_one_inference_gap_without_camera_survey(self):
  p=HybridPlanner();p.choose(Drive(.9),wall(100),radar(),100)
  first=p.choose(Drive(.9),wall(101.1),radar(),101.1)
  gap=p.choose(Drive(.9),None,radar(),102.2)
  self.assertTrue(first.escape);self.assertTrue(gap.escape);self.assertEqual(gap.drive.strafe,first.drive.strafe);self.assertEqual(gap.drive.yaw,0)

class ApproachProgress(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e;self.e=HybridGatherEngine({**old.cfg,'analyzer_enabled':False},self.log.append,self.input)
  self.e.screen=old.screen;self.e.bridge=old.bridge
 def test_progressing_auto_approach_does_not_get_view_recovery_input(self):
  self.e.mode='APPROACH';self.e.route_f_sent=True;self.e.native_route_started_at=100;self.e.last_progress=104
  self.e.view_recovery=object()
  self.assertFalse(self.e._view_recovery_tick(self.frame,GROUND,105));self.assertIsNone(self.e.view_recovery)
  self.assertEqual(self.commands,[]);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_vertical_lookup_time_is_not_counted_as_failed_walking(self):
  self.e.mode='SEARCH';self.e.target_confirmed=False;self.e.resource_hold=False;self.e.hybrid.problem_since=80
  d=self.e._scene_plan(self.frame,radar(),GROUND,Drive(pitch=.45,lifetime=.1),100)
  self.assertGreater(d.pitch,0);self.assertIsNone(self.e.hybrid.problem_since)

if __name__=='__main__':unittest.main()
