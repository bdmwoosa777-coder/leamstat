"""Resource-first camp handling, map dead-zone feedback and ground-only sprint."""
from pathlib import Path
from types import SimpleNamespace
from dataclasses import replace
from unittest.mock import patch
import threading,unittest
import numpy as np
import gamepad_input as gp,hybrid_engine as he,gather_engine as ge
from gamepad_input import GamepadInput
from hybrid_engine import HybridGatherEngine
from hybrid_navigation import HybridPlanner
from resource_policy import ResourcePolicy
from navigation import Drive
from minimap import Marker
from map_teleport import MapTeleport,MapObservation
from flight import FlightReading
from test_navigation import GatherFixture,obs,radar
from test_network_control import Source
from test_xbox_bridge import Reports
from test_hybrid import scene

AIR=Marker('Эфир',140,100,.95,40,'aether')
GEM=Marker('Самоцвет',120,100,.95,20,'gem')
GROUND=FlightReading(80,False)

def policy():
 p=ResourcePolicy({'only_aether':True});p.update(SimpleNamespace(energy=80,failures=0,can_start=lambda:True));return p

class AetherAbsence(unittest.TestCase):
 def test_healthy_energy_allows_ground_after_thirty_active_seconds_without_map_aether(self):
  p=policy()
  for t in range(30):p.observe_map([GEM],t)
  self.assertFalse(p.allows('Сапфир'));p.observe_map([GEM],30);self.assertTrue(p.allows('Сапфир'))
  self.assertTrue(p.allows('Эфир'));self.assertFalse(p.recovering)
 def test_reappearing_aether_immediately_closes_ground_fallback(self):
  p=policy()
  for t in range(31):p.observe_map([GEM],t)
  self.assertTrue(p.ground_fallback);p.observe_map([GEM,AIR],31)
  self.assertTrue(p.air_on_map);self.assertFalse(p.ground_fallback);self.assertFalse(p.allows('Рубин'))
 def test_energy_recovery_still_allows_ground_even_when_aether_is_visible(self):
  p=policy();p.update(SimpleNamespace(energy=10,failures=0,can_start=lambda:False));p.observe_map([AIR,GEM],0)
  self.assertTrue(p.allows('Алмаз'));self.assertFalse(p.allows('Эфир'))
 def test_menus_and_collection_do_not_count_as_thirty_seconds_of_search(self):
  p=policy()
  for t in range(11):p.observe_map([],t)
  p.observe_map([],11,False);p.observe_map([],100,False);p.observe_map([],101,True)
  self.assertLess(p.absent_for,12);self.assertFalse(p.ground_fallback)
 def test_missing_sampling_interval_is_not_invented_search_time(self):
  p=policy();p.observe_map([],0);p.observe_map([],60)
  self.assertLessEqual(p.absent_for,2);self.assertFalse(p.ground_fallback)
 def test_a_single_missed_map_frame_does_not_enable_ground_collection(self):
  p=policy();p.observe_map([AIR],0);p.observe_map([],1);p.observe_map([AIR],2)
  self.assertEqual(p.absent_for,0);self.assertFalse(p.allows('Сапфир'))

class PatrolEngine(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();screen=self.e.screen;bridge=self.e.bridge
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  cfg={**self.e.cfg,'hybrid_camp_exit':True,'auto_view_recovery':False,'scan_frame_checks':False,'patrol_sprint':True}
  self.e=HybridGatherEngine(cfg,self.log.append,self.input,network=self.source);self.e.screen=screen;self.e.bridge=bridge
  self.e.mode='SEARCH';self.e.target=None;self.clock=100.
  self.clock_patch=patch.object(he.time,'monotonic',side_effect=lambda:self.clock);self.clock_patch.start();self.addCleanup(self.clock_patch.stop)
 def test_purple_camp_icon_cannot_erase_resource_marker_or_world_caption(self):
  with patch.object(he,'purple_anchor',return_value=(90,90)),patch.object(ge.GatherEngine,'step',autospec=True) as step:
   self.e.step(self.frame,(0,0),obs(candidate=self.c),radar([AIR]),GROUND,100,1)
  self.assertIsNotNone(step.call_args.args[3].candidate);self.assertEqual(step.call_args.args[4].markers,[AIR])
  self.assertFalse(self.e.hybrid_camp_pending);self.assertEqual(self.e.camp_exit_until,0)
 def test_camp_survey_is_bounded_and_cannot_rearm_while_same_icon_stays_visible(self):
  with patch.object(he,'purple_anchor',return_value=(90,90)):
   self.e._camp_update(self.frame,radar(),100);self.assertTrue(self.e.hybrid_camp_pending)
   self.e._camp_update(self.frame,radar(),136);self.assertFalse(self.e.hybrid_camp_pending)
   self.e._camp_update(self.frame,radar(),200);self.assertFalse(self.e.hybrid_camp_pending)
  self.assertTrue(any('выход не подтверждён' in m for m in self.log))
 def test_real_new_camp_sighting_can_rearm_after_landmark_disappears(self):
  with patch.object(he,'purple_anchor',return_value=(90,90)):
   self.e._camp_update(self.frame,radar(),100);self.e._camp_update(self.frame,radar(),200)
  with patch.object(he,'purple_anchor',return_value=None):self.e._camp_update(self.frame,radar(),204)
  with patch.object(he,'purple_anchor',return_value=(90,90)):self.e._camp_update(self.frame,radar(),205)
  self.assertTrue(self.e.hybrid_camp_pending)
 def test_live_resource_ends_pending_camp_survey(self):
  self.e.hybrid_camp_pending=True;self.e.camp_exit_until=135
  with patch.object(he,'purple_anchor',return_value=(90,90)):self.e._camp_update(self.frame,radar([AIR]),110)
  self.assertFalse(self.e.hybrid_camp_pending);self.assertEqual(self.e.camp_exit_until,0)
 def test_known_bridge_guard_still_blocks_unselected_resource_click_latch(self):
  self.e.return_exit_guard=True;self.e._candidate_observed(replace(self.c,name='Эфир'),100,0)
  self.assertIsNone(self.e.caption_latch);self.assertEqual(self.pad.presses,0)
 def test_new_map_aether_replaces_only_unselected_ground_goal_and_pending_ground_caption(self):
  self.e.policy=policy()
  for t in range(31):self.e.policy.observe_map([GEM],t)
  self.e.nav.update(radar([GEM]),99);self.e.candidate=self.c;self.e.mode='ACQUIRE_WAIT'
  self.e.caption_latch={'candidate':self.c,'until':103}
  with patch.object(self.e,'click_candidate') as click:
   self.e.step(self.frame,(0,0),obs(candidate=self.c),radar([GEM,AIR]),GROUND,100,1)
  self.assertEqual(self.e.nav.goal.kind,'aether');self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.caption_latch);click.assert_not_called()
 def test_new_map_aether_cannot_cancel_already_confirmed_ground_collection(self):
  self.e.policy=policy();self.e.mode='GATHER';self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True
  with patch.object(ge.GatherEngine,'step'):
   self.e.step(self.frame,(0,0),obs(),radar([GEM,AIR]),GROUND,100,1)
  self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.e.target,'Сапфир');self.assertTrue(self.e.resource_hold)
 def sprint_ready(self):
  self.e.bridge.controller_native=True;self.e.sprint_surface_until=101;self.e.budget.airborne=False
 def test_sprint_gate_blocks_collection_air_map_retreat_and_lost_surface_proof(self):
  self.sprint_ready();self.assertTrue(self.e._sprint_input_ready())
  for attr,value in (('mode','APPROACH'),('mode','GATHER'),('resource_hold',True),('map_active',True),('sprint_surface_until',99),('return_exit_guard',True)):
   old=getattr(self.e,attr)
   with self.subTest(attr=attr,value=value):
    setattr(self.e,attr,value);self.assertFalse(self.e._sprint_input_ready());setattr(self.e,attr,old)
  self.e.budget.airborne=True;self.assertFalse(self.e._sprint_input_ready())
 def test_new_network_collection_blocks_sprint_before_engine_has_adopted_it(self):
  self.sprint_ready();self.source.state.attempt_active=True;self.assertFalse(self.e._sprint_input_ready())
 def test_engine_accelerates_an_existing_free_ground_run_once(self):
  self.sprint_ready();self.input.motion_worker=object()
  with patch.object(self.input,'wait',return_value=True):
   self.e._motion(Drive(.78));self.assertEqual(self.pad.presses,0)
   self.clock=100.25;self.e._motion(Drive(.78));self.assertEqual(self.pad.presses,1)
   self.clock=100.5;self.e._motion(Drive(.78));self.assertEqual(self.pad.presses,1)
  self.assertEqual(self.pad.axes[1],.78);self.assertEqual(self.pad.buttons,0)

class CampFrameContinuity(unittest.TestCase):
 def test_short_camp_frame_gap_can_continue_recent_verified_route(self):
  p=HybridPlanner();p.choose(Drive(.7),scene(),radar(),100,hint=0,exit_mode=True)
  a=p.choose(Drive(.7),None,radar(),100.2,exit_mode=True)
  self.assertGreater(a.drive.forward,.1);self.assertLess(a.drive.strafe,0);self.assertEqual(a.drive.yaw,0)
 def test_missing_camp_frame_still_never_walks_without_a_recent_route(self):
  a=HybridPlanner().choose(Drive(.7),None,radar(),100,exit_mode=True)
  self.assertEqual((a.drive.forward,a.drive.strafe),(0,0))
 def test_cliff_memory_revokes_even_a_previously_good_commit(self):
  p=HybridPlanner();p.choose(Drive(.7),scene(),radar(),100,hint=0,exit_mode=True)
  view=scene();view=replace(view,ground=replace(view.ground,drop_support=.1),lanes=tuple(replace(l,edge=.1) for l in view.lanes))
  p.choose(Drive(.7),view,radar(),100.1,exit_mode=True)
  a=p.choose(Drive(.7),None,radar(),100.2,exit_mode=True);self.assertEqual(a.drive.forward,0)

class MapDeadZone(unittest.TestCase):
 def test_stationary_list_boosts_strength_but_still_has_finite_failure(self):
  m=MapTeleport(0,index=13);o=MapObservation(True,list_first=1,list_last=9,list_signature=np.zeros((24,40)))
  actions=[m.step(t,o) for t in range(5)]
  self.assertEqual([round(a.scroll_strength,2) for a in actions[:4]],[.6,.7,.8,.85]);self.assertEqual(actions[-1].kind,'FAILED')
 def test_successful_list_motion_returns_to_small_normal_strength(self):
  m=MapTeleport(0,index=13);o=MapObservation(True,list_first=1,list_last=9,list_signature=np.zeros((24,40)))
  m.step(0,o);self.assertGreater(m.step(1,o).scroll_strength,.6)
  moved=replace(o,list_first=5,list_last=13,list_signature=np.full((24,40),40))
  self.assertEqual(m.step(2,moved).scroll_strength,.6)

class SprintTransport(unittest.TestCase):
 def setUp(self):
  self.clock=100.;self.pad=Reports();self.g=GamepadInput(factory=lambda:self.pad,a_button=0x1000)
  self.g.motion_worker=object();self.g.translation_lease_floor=.75;self.stop=threading.Event()
  self.timer=patch.object(gp.time,'monotonic',side_effect=lambda:self.clock);self.timer.start();self.addCleanup(self.timer.stop);self.addCleanup(self.g.close)
 def moving(self):self.g.drive(.78);self.clock+=.2;self.g.drive(.78)
 def tap(self):
  with patch.object(self.g,'wait',return_value=True):return self.g.tap_sprint(self.stop,lambda:True,lambda:True)
 def test_one_sprint_does_not_release_stick_and_is_not_spammed_on_renewal(self):
  self.moving();self.pad.reports=[];self.assertTrue(self.tap())
  self.assertTrue(all(axes[1]==.78 and b&0x100==0 and lt==0 for b,lt,axes in self.pad.reports))
  for _ in range(5):self.clock+=.1;self.g.drive(.78);self.assertFalse(self.tap())
  self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.buttons,0)
 def test_releasing_movement_allows_one_sprint_for_the_new_run(self):
  self.moving();self.assertTrue(self.tap());self.g.drive();self.moving();self.assertTrue(self.tap());self.assertEqual(self.pad.presses,2)
 def test_expired_translation_also_requires_new_run_before_sprint(self):
  self.moving();self.tap();self.clock+=1
  with self.g.lock:self.g._expire_motion(self.clock)
  self.assertFalse(self.tap());self.moving();self.assertTrue(self.tap());self.assertEqual(self.pad.presses,2)
 def test_standstill_or_just_started_motion_cannot_send_backwards_dash(self):
  self.assertFalse(self.tap());self.g.drive(.78);self.assertFalse(self.tap());self.assertEqual(self.pad.presses,0)
 def test_cursor_action_focus_and_authorization_guards_block_bare_a(self):
  self.moving()
  for attr,value in (('cursor_held',True),('action_deadline',101)):
   setattr(self.g,attr,value);self.assertFalse(self.tap());setattr(self.g,attr,False if attr=='cursor_held' else None)
  self.assertFalse(self.g.tap_sprint(self.stop,lambda:False,lambda:True));self.assertFalse(self.g.tap_sprint(self.stop,lambda:True,lambda:False))
  self.stop.set();self.assertFalse(self.tap());self.assertEqual(self.pad.presses,0)
 def test_stop_during_sprint_releases_a_and_translation(self):
  self.moving()
  def interrupted(*args):self.stop.set();return False
  with patch.object(self.g,'wait',side_effect=interrupted):self.assertFalse(self.g.tap_sprint(self.stop,lambda:True,lambda:True))
  self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_driver_failure_after_a_down_is_reset_immediately(self):
  self.moving();self.pad.fail=True
  with self.assertRaises(RuntimeError):self.tap()
  self.pad.fail=False;self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_watchdog_can_release_a_without_stopping_the_run(self):
  self.moving()
  def held(seconds,*args):
   self.clock+=seconds+.01
   with self.g.lock:self.g._expire_motion(self.clock)
   self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.axes[1],.78);return True
  with patch.object(self.g,'wait',side_effect=held):self.assertTrue(self.g.tap_sprint(self.stop,lambda:True,lambda:True))
  self.assertTrue(self.g.sprint_used)
 def test_old_sprint_cleanup_cannot_release_a_of_a_new_cursor_generation(self):
  self.moving()
  def replace_input(*args):
   self.g.reset();self.g.cursor_held=True;self.pad.press_button(button=0x1100);self.pad.left_trigger_float(value_float=1);self.pad.update();return True
  with patch.object(self.g,'wait',side_effect=replace_input):self.assertTrue(self.g.tap_sprint(self.stop,lambda:True,lambda:True))
  self.assertEqual(self.pad.buttons,0x1100);self.assertTrue(self.g.cursor_held)

if __name__=='__main__':unittest.main()
