"""Real scanner methods + Xbox reports; no Windows or live game input."""
import ast,json,re,threading,types,unittest
from pathlib import Path
from types import SimpleNamespace
from tempfile import TemporaryDirectory
from xbox_combat import XboxCombatBridge,RB
from test_xbox_combat import Pad

ROOT=Path(__file__).parent
TREE=ast.parse((ROOT/'target_scanner.py').read_text())
CLS=next(n for n in TREE.body if isinstance(n,ast.ClassDef) and n.name=='ScannerApp')
METHODS={n.name:n for n in CLS.body if isinstance(n,ast.FunctionDef)}
def compile_methods(names,scope):
 nodes=[n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name in ('normalize_name','parse_targets')]
 nodes += [METHODS[n] for n in names]
 exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'scanner-camera-source','exec'),scope)
 return scope

class CameraPatterns(unittest.TestCase):
 def setUp(self):
  self.now=100.;self.active=True;self.focus=True;self.locked=False
  self.pad=Pad();self.messages=[]
  self.bridge=XboxCombatBridge(lambda:self.focus and not self.locked,lambda:self.active,self.messages.append,lambda:self.pad,lambda:self.now,False)
  self.addCleanup(self.bridge.close);self.bridge.begin_session({});self.bridge.send('START')
  self.scope=compile_methods(['rotate_search','maybe_rotate_camera'],{'time':SimpleNamespace(monotonic=lambda:self.now)})
  self.app=SimpleNamespace(can_send=lambda:self.active and self.focus,bridge=self.bridge,last_sweep=0.,tabs_since_turn=10,log=self.messages.append,camera_next_left=True)
  self.app.rotate_search=types.MethodType(self.scope['rotate_search'],self.app)
  self.app.maybe_rotate_camera=types.MethodType(self.scope['maybe_rotate_camera'],self.app)
  self.cfg={'camera_pattern':'влево–вправо','turn_ms':400,'search_turn_sec':2.,'search_turn_mode':'рывок','combat_spin':True}
 def turn(self,state='поиск'):
  self.bridge.send('START')
  return self.app.maybe_rotate_camera(self.cfg,state)
 def test_actual_stick_alternates_left_right_across_search_combat_and_continuous_modes(self):
  reports=[]
  for i,state in enumerate(('поиск','бой','непрерывная атака','поиск')):
   self.now=100+i*2.;self.assertTrue(self.turn(state));reports.append(self.pad.reports[-1])
  self.assertEqual([r.yaw for r in reports],[-.45,.45,-.45,.45])
  self.assertTrue(all(r.buttons&RB and r.rt==1 for r in reports))
 def test_circle_keeps_original_signed_direction_for_every_pulse(self):
  self.cfg['camera_pattern']='по кругу'
  for value,direction in ((400,.45),(-400,-.45)):
   self.cfg['turn_ms']=value
   for _ in range(3):self.now+=2;self.assertTrue(self.turn());self.assertEqual(self.pad.yaw,direction)
 def test_old_settings_without_new_pattern_keep_circle_behavior(self):
  self.cfg.pop('camera_pattern')
  for _ in range(3):self.now+=2;self.turn();self.assertEqual(self.pad.yaw,.45)
 def test_same_duration_setting_controls_both_alternating_directions(self):
  for milliseconds in (200,600):
   self.cfg['turn_ms']=milliseconds
   for _ in range(2):
    self.now+=2;self.turn();self.assertAlmostEqual(self.bridge.state.yaw_until-self.now,milliseconds/1000)
 def test_frequent_pulses_keep_existing_quarter_duration_and_alternate(self):
  self.cfg['search_turn_mode']='часто';directions=[]
  for _ in range(2):
   self.now+=2;self.turn();directions.append(self.pad.yaw)
   self.assertAlmostEqual(self.bridge.state.yaw_until-self.now,.1)
  self.assertEqual(directions,[-.45,.45])
 def test_negative_duration_does_not_change_first_left_in_alternating_mode(self):
  self.cfg['turn_ms']=-400;self.turn();self.assertEqual(self.pad.yaw,-.45)
  self.now+=2;self.turn();self.assertEqual(self.pad.yaw,.45)
 def test_disabled_camera_or_combat_option_does_not_consume_direction(self):
  self.cfg['never_move_camera']=True;self.assertFalse(self.turn());self.assertTrue(self.app.camera_next_left)
  self.cfg['never_move_camera']=False;self.cfg['combat_spin']=False
  self.assertFalse(self.turn('бой'));self.assertTrue(self.app.camera_next_left)
  self.assertTrue(self.turn('поиск'));self.assertEqual(self.pad.yaw,-.45)
 def test_focus_loss_or_alarm_rejects_pulse_without_consuming_direction(self):
  for attr in ('focus','locked'):
   setattr(self,attr,False if attr=='focus' else True)
   self.now+=2;self.assertFalse(self.turn());self.assertTrue(self.app.camera_next_left)
   setattr(self,attr,True if attr=='focus' else False)
  self.now+=2;self.turn();self.assertEqual(self.pad.yaw,-.45)
 def test_timer_prevents_double_flip_before_next_scheduled_turn(self):
  self.turn();self.now+=.1;self.assertFalse(self.turn());self.assertFalse(self.app.camera_next_left)
  self.now+=1.9;self.turn();self.assertEqual(self.pad.yaw,.45)
 def test_zero_impulse_sends_nothing_even_in_frequent_mode(self):
  self.cfg.update(turn_ms=0,search_turn_mode='часто')
  self.assertFalse(self.turn());self.assertEqual(self.pad.yaw,0);self.assertTrue(self.app.camera_next_left)
 def test_stop_clears_an_alternating_pulse_and_all_attack_controls(self):
  self.turn();self.active=False;self.bridge.tick()
  self.assertEqual((self.pad.yaw,self.pad.buttons,self.pad.lt,self.pad.rt),(0,0,0,0))
  self.now+=2;self.assertFalse(self.turn())

class CameraSettings(unittest.TestCase):
 def app(self,pattern):
  cfg=json.loads((ROOT/'settings.json').read_text());app=SimpleNamespace(config=cfg,fields={})
  def var(value):return SimpleNamespace(get=lambda *a:value)
  app.targets_box=var('\n'.join(cfg['targets']));app.visual_mode=var(cfg['visual_mode']);app.visual_player_enabled=var(cfg['visual_player_enabled'])
  pairs=[('captcha_enabled_var','captcha_watch_enabled'),('death_enabled_var','death_watch_enabled'),('captcha_device_var','captcha_audio_device'),('attack_all_var','attack_all_targets'),('repeat_var','repeat_search'),('six_spam_var','six_spam_enabled'),('combat_spin_var','combat_spin'),('never_camera_var','never_move_camera'),('protect_var','protect_player'),('player_var','player_name'),('threat_sec_var','threat_scan_sec'),('turn_sec_var','search_turn_sec'),('turn_mode_var','search_turn_mode')]
  for attr,key in pairs:setattr(app,attr,var(str(cfg[key]) if attr in ('threat_sec_var','turn_sec_var') else cfg[key]))
  app.camera_pattern_var=var(pattern);return app
 def test_actual_ui_parser_accepts_and_persists_both_patterns(self):
  scope=compile_methods(['parse_ui'],{'re':re})
  for pattern in ('по кругу','влево–вправо'):
   parsed=scope['parse_ui'](self.app(pattern))
   self.assertEqual(json.loads(json.dumps(parsed))['camera_pattern'],pattern)
 def test_actual_ui_parser_rejects_unknown_pattern(self):
  scope=compile_methods(['parse_ui'],{'re':re})
  with self.assertRaisesRegex(ValueError,'движение камеры'):scope['parse_ui'](self.app('unknown'))
 def test_loading_old_config_adds_default_circle_without_losing_user_settings(self):
  with TemporaryDirectory() as tmp:
   path=Path(tmp)/'settings.json';path.write_text(json.dumps({'targets':['Керуб'],'turn_ms':620}))
   nodes=[n for n in TREE.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='DEFAULTS' for t in n.targets)]
   nodes +=[n for n in TREE.body if isinstance(n,ast.FunctionDef) and n.name=='load_config']
   scope={'json':json,'CONFIG_PATH':path}
   exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),'scanner-config-source','exec'),scope)
   loaded=scope['load_config']()
   self.assertEqual(loaded['camera_pattern'],'по кругу');self.assertEqual(loaded['turn_ms'],620);self.assertEqual(loaded['targets'],['Керуб'])
