"""Probe orchestration with real sender/Lua; hook event parsing off Windows."""
import unittest
from unittest.mock import Mock
from TEST_MAP_CLICK import execute_probe
from click_event_observer import key_record,mouse_record
from test_map_wire47 import Link
from map_mousekeys import Dispatch

class Probe(unittest.TestCase):
 def test_manual_map_one_real_click_and_no_map_or_movement_command(self):
  link=Link();link.map=True;messages=[]
  with link.patch():result=execute_probe(link.tr,lambda:True,messages.append);link.tr.close()
  self.assertEqual(result,dict(ping_ack=True,attempted=True,ack=True));self.assertTrue(link.map);self.assertTrue(link.route)
  downs=[k for t,a,k in link.events if a=='down']
  self.assertEqual(downs.count('num5'),1);self.assertNotIn('m',downs)
  self.assertTrue(set(downs)<={20,145,'capslock','numminus','num5'})
 def test_no_ack_never_sends_click(self):
  link=Link(legacy=True);link.map=True
  with link.patch():result=execute_probe(link.tr,lambda:True,lambda _:None)
  self.assertFalse(result['ping_ack']);self.assertFalse(any(k=='num5' for _,_,k in link.events))
 def test_no_authorization_has_no_input(self):
  link=Link()
  with link.patch():result=execute_probe(link.tr,lambda:False,lambda _:None)
  self.assertFalse(result['attempted']);self.assertEqual(link.events,[])
 def test_uncertain_click_is_not_retried(self):
  transport=Mock();transport.ping.return_value=Dispatch(True,True);transport.click.return_value=Dispatch(True,False,'unknown')
  result=execute_probe(transport,lambda:True,lambda _:None)
  self.assertTrue(result['attempted']);self.assertFalse(result['ack']);transport.click.assert_called_once()
 def test_numlock_off_never_sends_a_key(self):
  link=Link();link.flags[144]=False
  with link.patch():result=execute_probe(link.tr,lambda:True,lambda _:None)
  self.assertFalse(result['attempted']);self.assertFalse(link.flags[144]);self.assertEqual(link.events,[])

class Events(unittest.TestCase):
 def test_right_button_down_and_up_are_distinct(self):
  self.assertEqual(mouse_record(0x204,100,200,1),dict(kind='mouse',action='RIGHT_DOWN',x=100,y=200,flags=1))
  self.assertEqual(mouse_record(0x205,100,200,0)['action'],'RIGHT_UP')
 def test_left_click_is_not_counted_as_right(self):
  self.assertEqual(mouse_record(0x201,1,2,0)['action'],'LEFT_DOWN')
  self.assertEqual(mouse_record(0x202,1,2,0)['action'],'LEFT_UP')
 def test_mouse_motion_is_not_collected(self):self.assertIsNone(mouse_record(0x200,1,2,0))
 def test_numpad_virtual_key_and_clear_variant_are_both_seen(self):
  self.assertEqual(key_record(0x100,0x65,0x4c,16)['key'],'NUM5')
  self.assertEqual(key_record(0x101,0x0c,0x4c,0)['action'],'UP')
 def test_numpad_scan_is_seen_even_with_unexpected_virtual_key(self):
  self.assertEqual(key_record(0x100,0x35,0x4c,0)['key'],'NUM_SCAN')
 def test_ordinary_typing_is_not_collected(self):
  scans=[0x1e,0x30,0x2e,0x20,0x12,0x21,0x22,0x23,0x17,0x24,0x25,0x26,0x32,0x31,0x18,0x19,0x10,0x13,0x1f,0x14,0x16,0x2f,0x11,0x2d,0x15,0x2c]
  for vk,scan in zip(range(0x41,0x5b),scans):self.assertIsNone(key_record(0x100,vk,scan,0))
 def test_numlock_wire_keys_and_flags_are_only_observed(self):
  for vk in (20,144,145):self.assertEqual(key_record(0x104,vk,0,16)['flags'],16)

if __name__=='__main__':unittest.main()
