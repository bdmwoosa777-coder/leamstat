import json,threading,time,unittest,math
from types import SimpleNamespace
from unittest.mock import patch
from http.server import HTTPServer,BaseHTTPRequestHandler
import numpy as np
from ai_policy import PolicyClient,PolicyHost,Decision,validate,decision_from_plan,plan_schema,available_actions,picture
from ai_engine import AIGatherEngine,unchanged
from gather_engine import GatherEngine
from flight import FlightReading
from test_navigation import GatherFixture,radar,obs
from test_network_control import Source

ACTION={'action':'move','direction':'forward','resource':'none','x':500,'y':500,'duration_ms':600,'reason':'clear road'}
PLAN={'scene':'road','landmark':'open road ahead, beyond grass','path':'clear','action':'move','direction':'forward','resource':'none','point':[500,650],'duration_ms':1600}
FRAME=np.full((360,640,3),40,np.uint8)

class PolicyContract(unittest.TestCase):
 def test_one_tool_has_a_bounded_lease(self):self.assertEqual(validate(ACTION,['Эфир']),ACTION)
 def test_arbitrary_commands_and_bad_coordinates_are_rejected(self):
  for bad in ({**ACTION,'action':'shell'},{**ACTION,'x':True},{**ACTION,'duration_ms':5000},{**ACTION,'x':float('nan')},{**ACTION,'command':'F'}):
   with self.assertRaises(ValueError):validate(bad,['Эфир'])
 def test_resource_action_needs_known_identity(self):
  for name in ('none','Страж'):
   with self.assertRaises(ValueError):validate({**ACTION,'action':'acquire','resource':name},['Эфир'])
 def test_generate_receives_one_current_image_and_action_history(self):
  c=PolicyClient();response={'message':{'content':json.dumps(PLAN)}}
  with patch.object(c,'call',return_value=response) as call:
   self.assertEqual(c.decide(FRAME,FRAME,{'flight_confirmed':False},[{'feedback':'blocked'}],['Эфир'])['action'],'move')
  args,kw=call.call_args;payload=args[1]
  self.assertEqual(args[0],'/api/generate');self.assertTrue(payload['stream']);self.assertEqual(len(payload['images']),1)
  self.assertIn('blocked',payload['prompt']);self.assertNotIn('messages',payload)
 def test_changed_view_revokes_stale_points(self):
  self.assertTrue(unchanged(FRAME,FRAME.copy()));self.assertFalse(unchanged(FRAME,np.full_like(FRAME,180)))
 def test_late_reply_cannot_cross_a_tool_generation(self):
  entered=threading.Event();release=threading.Event()
  class Client:
   def __init__(self,*a):pass
   def probe(self):pass
   def decide(self,*a):entered.set();release.wait(2);return ACTION
  host=PolicyHost({'target_names':['Эфир']},lambda s:None)
  with patch('ai_policy.PolicyClient',Client):
   host.offer(FRAME,{},[],time.monotonic());self.assertTrue(entered.wait(1));host.invalidate();release.set();host.worker.join(2)
  self.assertIsNone(host.take());host.close()
 def test_generate_stream_is_joined_through_final_record(self):
  content=json.dumps(PLAN)
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*a):pass
   def do_POST(self):
    self.rfile.read(int(self.headers['Content-Length']))
    raw=b'\n'.join(json.dumps(o).encode() for o in [{'response':'','done':False},{'response':content[:15],'done':False},{'response':content[15:],'done':True}])
    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   c=PolicyClient('http://127.0.0.1:'+str(server.server_port));self.assertEqual(c.decide(FRAME,None,{},[],['Эфир'])['perception']['landmark'],PLAN['landmark'])
  finally:server.shutdown();server.server_close();thread.join()

class FakeHost:
 def __init__(self):self.latest=None;self.offers=[];self.invalid=0
 def offer(self,*a):self.offers.append(a)
 def take(self):r=self.latest;self.latest=None;return r
 def invalidate(self):self.invalid+=1;self.latest=None
 def close(self):pass

class AITools(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();bridge=self.e.bridge;screen=self.e.screen;cfg=self.e.cfg
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=AIGatherEngine(cfg,self.log.append,self.input,network=self.source);self.e.bridge=bridge;self.e.screen=screen
  self.e.ai=FakeHost();self.e.mode='SEARCH'
 def tick(self,a=None,t=100):
  if a is not None:self.e.ai.latest=Decision(0,t,self.frame.copy(),a,.2)
  with patch('ai_engine.time.monotonic',return_value=t):self.e.step(self.frame,(0,0),obs(),radar(),FlightReading(None,False),t)
 def test_waiting_for_model_never_runs_legacy_navigation(self):
  with patch.object(self.e.nav,'update',side_effect=AssertionError('old planner')):self.tick()
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(len(self.e.ai.offers),1)
 def test_ai_move_is_executed_once_and_does_not_renew_forever(self):
  self.tick(ACTION);self.assertIsNotNone(self.input.motion_deadline)
  self.tick(t=101);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.e.ai_history[-1]['action'],'move')
 def test_old_response_does_not_execute_after_view_change(self):
  self.e.ai.latest=Decision(0,100,np.full_like(self.frame,180),ACTION,.2);self.tick()
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertTrue(any('AI_STALE' in s for s in self.log))
 def test_collection_delegates_without_ai_movement(self):
  self.e.resource_hold=True;self.e.target_confirmed=True;self.e.mode='GATHER'
  with patch.object(GatherEngine,'step') as legacy:self.tick(ACTION);legacy.assert_called_once()
  self.assertFalse(self.e.ai.offers)
 def test_unknown_energy_cannot_toggle_flight(self):
  self.tick({**ACTION,'action':'takeoff'});self.assertNotIn('V',self.commands)
 def test_stop_revokes_future_actions(self):
  self.e.stop_event.set();self.tick(ACTION);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_wrong_network_identity_does_not_get_a_second_click(self):
  self.input.native_cursor=True
  a={**ACTION,'action':'acquire','resource':'Эфир','y':500}
  with patch('ai_engine.GamepadInput.wait',return_value=True):self.tick(a)
  self.assertEqual(self.pad.presses,1);self.assertFalse(self.e.target_confirmed);self.assertFalse(self.alt_held)
 def test_fresh_resource_identity_hands_off_after_exactly_one_native_click(self):
  self.input.native_cursor=True;tap=self.input.tap_a
  def click(*a,**kw):
   ok=tap(*a,**kw);self.source.state.nodes[99].template=1500000
   self.source.state.selection_time=int(time.time()*1000)+10;return ok
  self.input.tap_a=click
  with patch('ai_engine.GamepadInput.wait',return_value=True):self.tick({**ACTION,'action':'acquire','resource':'Эфир'})
  self.assertEqual(self.pad.presses,1);self.assertTrue(self.e.target_confirmed);self.assertEqual(self.e.mode,'APPROACH')
  self.assertEqual(self.e.network_target,(1,99));self.assertFalse(self.alt_held);self.assertEqual(self.pad.buttons,0)
 def test_network_failure_prevents_ai_input(self):
  self.source.ready=False;self.tick(ACTION);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.presses,0)
 def test_no_legacy_no_yield_or_rescue_or_patrol_can_take_over(self):
  self.assertFalse(self.e._no_yield_tick(None,None,100));self.assertFalse(self.e._start_terrain_recovery(100,None))
  self.assertFalse(self.e._return_exit_tick(None,None,100));self.assertFalse(self.e._patrol_escape_tick(None,None,100))
 def test_observation_mode_records_decision_without_pressing(self):
  self.e.cfg['dry_run']=True;self.tick(ACTION);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.presses,0)
 def test_selected_goal_is_carried_into_the_next_ai_observation(self):
  self.tick({**ACTION,'resource':'Эфир'});self.tick(t=101);self.tick(t=101.4)
  self.assertEqual(self.e.ai.offers[-1][1]['goal'],'Эфир')
 def test_move_is_renewed_in_short_leases_then_stops_at_macro_deadline(self):
  self.tick({**ACTION,'duration_ms':1600});self.tick(t=100.9)
  self.assertAlmostEqual(self.input.motion_deadline,101.25);self.assertIsNotNone(self.e.ai_drive)
  self.tick(t=101.7);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertIsNone(self.e.ai_drive)
 def test_look_uses_current_pose_and_is_not_rejected_like_a_stale_click(self):
  self.e.ai.latest=Decision(0,100,np.full_like(self.frame,180),{**ACTION,'action':'look','direction':'right','duration_ms':400},.2)
  self.tick();self.assertTrue(any('AI_DECISION' in s for s in self.log));self.assertFalse(any('AI_STALE' in s for s in self.log))
 def test_after_action_waits_for_settling_before_requesting_another_frame(self):
  self.tick(ACTION);self.tick(t=101)
  self.assertEqual(self.e.ai.offers,[]);self.tick(t=101.4);self.assertEqual(len(self.e.ai.offers),1)
 def test_interrupted_move_cannot_restart_during_a_later_wait(self):
  self.tick({**ACTION,'duration_ms':1600});self.e.resource_hold=True;self.e.mode='GATHER'
  with patch.object(GatherEngine,'step'):self.tick(t=100.2)
  self.e.resource_hold=False;self.e.target_confirmed=False;self.e.mode='SEARCH';self.tick({**ACTION,'action':'wait'},t=101)
  self.tick(t=101.2);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertIsNone(self.e.ai_drive)
 def test_fresh_detector_point_and_camera_relative_bearing_are_supplied_to_ai(self):
  from test_navigation import obs,radar
  from minimap import Marker
  with patch('ai_engine.time.monotonic',return_value=100):
   self.e.step(self.frame,(0,0),obs(candidate=self.c),radar([Marker('Самоцвет',150,100,.9,50)],90),FlightReading(None,False),100)
  state=self.e.ai.offers[-1][1];self.assertEqual(state['resource_hint']['name'],'Сапфир')
  self.assertEqual(state['minimap_resources'][0]['camera_error_degrees'],0)

class GroundedPolicy(unittest.TestCase):
 def looks(self):return [{'action':'look','direction':'right','tool_result':'input sent','map_net_pixels':0} for _ in range(4)]
 def test_reported_four_look_loop_cannot_issue_another_look(self):
  history=self.looks();s=plan_schema(history,['Эфир'])
  self.assertNotIn('look',s['properties']['action']['enum'])
  with self.assertRaisesRegex(ValueError,'AI_INSPECTION_LIMIT'):
   decision_from_plan({**PLAN,'action':'look','direction':'right','path':'unknown','point':None},['Эфир'],history)
 def test_loop_does_not_force_walk_when_scene_is_unclear(self):
  result=decision_from_plan({**PLAN,'scene':'unclear','path':'unknown','point':None,'action':'wait','direction':'none','landmark':'ground hidden by foreground rock'},['Эфир'],self.looks())
  self.assertEqual(result['action'],'wait')
  for plan in ({**PLAN,'scene':'unclear'},{**PLAN,'scene':'deep_drop'},{**PLAN,'path':'blocked'},{**PLAN,'point':None}):
   with self.assertRaisesRegex(ValueError,'AI_MOVE_UNGROUNDED'):decision_from_plan(plan,['Эфир'],self.looks())
 def test_honest_grounded_move_is_available_after_repeated_inspection(self):
  result=decision_from_plan(PLAN,['Эфир'],self.looks());self.assertEqual(result['action'],'move')
  self.assertEqual((result['x'],result['y']),(500,650));self.assertEqual(result['perception']['path'],'clear')
 def test_wait_failed_click_and_denied_takeoff_do_not_reset_budget(self):
  history=self.looks()+[{'action':'wait'},{'action':'acquire','confirmed':False},{'action':'takeoff','tool_result':'denied'}]
  self.assertNotIn('look',available_actions(history))
  self.assertNotIn('look',available_actions([{'action':'wait'}]*8,{'inspections_without_progress':2}))
 def test_actual_displacement_or_confirmed_resource_restores_budget(self):
  for feedback in ({'action':'move','tool_result':'input sent','map_net_pixels':3},{'action':'acquire','confirmed':True}):
   self.assertIn('look',available_actions(self.looks()+[feedback]))
  self.assertNotIn('look',available_actions(self.looks()+[{'action':'move','tool_result':'input sent','map_net_pixels':0}]))
 def test_coordinates_cannot_point_to_hud_or_image_corner(self):
  for point in ([1000,1000],[920,200],[500,30],[True,500]):
   with self.assertRaises(ValueError):decision_from_plan({**PLAN,'point':point},['Эфир'],[])
 def test_photo_has_more_detail_but_does_not_upscale_low_resolution(self):
  import base64,cv2
  for width,expected in ((1920,960),(640,640)):
   raw=picture(np.full((width*9//16,width,3),150,np.uint8));image=cv2.imdecode(np.frombuffer(base64.b64decode(raw),np.uint8),cv2.IMREAD_COLOR)
   self.assertEqual(image.shape[1],expected);self.assertLess(int(image[int(image.shape[0]*.5),int(expected*.9)].mean()),40)
 def test_perception_precedes_tools_and_unused_coordinates_are_null(self):
  schema=plan_schema([],['Эфир']);keys=list(schema['properties'])
  self.assertLess(keys.index('landmark'),keys.index('action'));self.assertNotIn('x',keys)
  result=decision_from_plan({**PLAN,'action':'look','direction':'up','point':None,'path':'unknown'},['Эфир'],[])
  self.assertEqual(result['perception']['point'],None)

class InspectionExecution(GatherFixture,unittest.TestCase):
 def setUp(self):
  GatherFixture.setUp(self);bridge=self.e.bridge;screen=self.e.screen;cfg=self.e.cfg
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=AIGatherEngine(cfg,self.log.append,self.input,network=self.source);self.e.bridge=bridge;self.e.screen=screen
  self.e.ai=FakeHost();self.e.mode='SEARCH'
 tick=AITools.tick
 def test_controller_rejects_third_look_even_if_client_ignores_contract(self):
  self.e.ai_history=[{'action':'look','tool_result':'input sent','map_net_pixels':0}]*2;self.e.ai_inspections=2
  self.tick({**ACTION,'action':'look','direction':'right'})
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertTrue(any('AI_INSPECTION_LIMIT' in x for x in self.log))
 def test_grounded_movement_remains_possible_after_limit(self):
  self.e.ai_history=[{'action':'look','tool_result':'input sent','map_net_pixels':0}]*2;self.e.ai_inspections=2
  self.tick(decision_from_plan(PLAN,['Эфир'],self.e.ai_history));self.assertIsNotNone(self.input.motion_deadline)
 def test_budget_survives_history_eviction_by_many_waits(self):
  self.e.ai_history=[{'action':'wait'}]*8;self.e.ai_inspections=2;self.tick()
  self.assertEqual(self.e.ai.offers[-1][1]['inspections_without_progress'],2)
 def test_confirmed_new_area_restores_inspections_but_failed_transfer_does_not(self):
  for phase,expected in [('DONE',0),('FAILED',2)]:
   self.e.ai_inspections=2;self.e.map_teleport=SimpleNamespace(phase=phase)
   with patch.object(GatherEngine,'_map_teleport_tick',return_value=True):self.e._map_teleport_tick(None,None,100)
   self.assertEqual(self.e.ai_inspections,expected)
 def test_perception_is_carried_in_tool_result(self):
  a=decision_from_plan(PLAN,['Эфир'],[]);self.tick(a);self.tick(t=102)
  self.assertEqual(self.e.ai_history[-1]['perception']['landmark'],PLAN['landmark'])

class AIReviewChecks(unittest.TestCase):
 def test_blank_view_cannot_pass_by_returning_any_valid_tool(self):
  from check_ai import blank_check
  c=SimpleNamespace(decide=lambda *a:decision_from_plan(PLAN,['Эфир'],[]))
  with self.assertRaisesRegex(ValueError,'AI_BLANK_SANITY'):blank_check(c,['Эфир'])
 def test_unclear_wait_with_unknown_path_passes_only_blank_sanity(self):
  from check_ai import blank_check
  expected=decision_from_plan({**PLAN,'action':'wait','scene':'unclear','path':'unknown','point':None},['Эфир'],[])
  self.assertEqual(blank_check(SimpleNamespace(decide=lambda *a:expected),['Эфир']),expected)
 def test_review_uses_saved_image_without_instantiating_input_controller(self):
  import tempfile,contextlib,io,cv2
  from pathlib import Path
  import review_ai_view
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'settings_gather.json').write_text(json.dumps({'analyzer_url':'http://localhost:11434','analyzer_model':'qwen2.5vl:3b','target_names':['Эфир']}))
   cv2.imwrite(str(root/'source.jpg'),FRAME)
   c=SimpleNamespace(probe=lambda:None,decide=lambda *a:decision_from_plan(PLAN,['Эфир'],[]))
   with patch.object(review_ai_view,'__file__',str(root/'review_ai_view.py')),patch.object(review_ai_view,'PolicyClient',return_value=c),contextlib.redirect_stdout(io.StringIO()):
    self.assertEqual(review_ai_view.main(['--saved',str(root/'source.jpg')]),0)
   result=json.loads((root/'ai_review.json').read_text());self.assertTrue(result['read_only']);self.assertFalse(result['navigation_verified'])
   self.assertEqual(result['answer']['action'],'move');self.assertTrue((root/'ai_review_view.jpg').is_file())
   self.assertNotIn('gamepad_input',review_ai_view.__dict__);self.assertNotIn('GamepadInput',review_ai_view.__dict__)
 def test_missing_saved_image_produces_failed_report(self):
  import tempfile,contextlib,io
  from pathlib import Path
  import review_ai_view
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'settings_gather.json').write_text(json.dumps({'analyzer_model':'qwen2.5vl:3b'}))
   with patch.object(review_ai_view,'__file__',str(root/'review_ai_view.py')),contextlib.redirect_stdout(io.StringIO()):
    self.assertEqual(review_ai_view.main(['--saved',str(root/'missing.jpg')]),1)
   self.assertFalse(json.loads((root/'ai_review.json').read_text())['valid_answer'])
