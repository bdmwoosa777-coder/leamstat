"""Read-only live/saved scene review: no gamepad, bridge or keyboard imports."""
from pathlib import Path
import argparse,base64,json,time
import cv2,numpy as np
from ai_policy import PolicyClient,picture

def main(argv=None):
 parser=argparse.ArgumentParser();parser.add_argument('--saved',type=Path,help='Use an existing picture; otherwise capture focused AION2 after 5 seconds')
 args=parser.parse_args(argv);root=Path(__file__).resolve().parent
 cfg=json.loads((root/'settings_gather.json').read_text(encoding='utf-8'));data={'model':cfg['analyzer_model'],'read_only':True,'navigation_verified':False}
 try:
  if args.saved:
   frame=cv2.imdecode(np.frombuffer(args.saved.read_bytes(),np.uint8),cv2.IMREAD_COLOR)
   if frame is None:raise ValueError('Не удалось прочитать изображение')
   data['source']='saved'
  else:
   from screen_capture import ScreenCapture
   screen=ScreenCapture()
   if not screen.pick():raise ValueError('Окно AION2 не найдено')
   print('Бот должен быть закрыт. Переключитесь в игру: через 5 секунд будет один снимок. Кнопки не нажимаются.',flush=True)
   time.sleep(5)
   if not screen.focused():raise ValueError('Игра не в фокусе; снимок отменён')
   frame,_=screen.frame();data['source']='focused_game'
  (root/'ai_review_view.jpg').write_bytes(base64.b64decode(picture(frame)))
  client=PolicyClient(cfg['analyzer_url'],cfg['analyzer_model']);client.probe();began=time.monotonic()
  data['answer']=client.decide(frame,None,{'review_only':True,'flight_confirmed':False,'flight_energy':None,'xyz':None,'minimap_resources':[],'resource_hint':None},[],cfg['target_names'])
  data['seconds']=round(time.monotonic()-began,2);data['valid_answer']=True
 except Exception as exc:data['valid_answer']=False;data['error']=str(exc)
 (root/'ai_review.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(data,ensure_ascii=False,indent=2))
 print('Решение только показано. Оно не выполнялось. Файлы: ai_review_view.jpg и ai_review.json.')
 return 0 if data['valid_answer'] else 1
if __name__=='__main__':raise SystemExit(main())
