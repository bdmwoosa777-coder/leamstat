"""Protocol + blank-view sanity check. Does not establish game navigation quality."""
from pathlib import Path
import json,time
import numpy as np
from ai_policy import PolicyClient

def blank_check(client,names):
 answer=client.decide(np.full((360,640,3),60,np.uint8),None,{'test':'blank picture, no visible road or resource; observe honestly'},[],names)
 if answer['action']!='wait' or answer['perception']['scene']!='unclear' or answer['perception']['path']!='unknown':
  raise ValueError('AI_BLANK_SANITY: пустой кадр не распознан как unclear/wait/unknown; ответ='+json.dumps(answer,ensure_ascii=False))
 return answer

def main():
 root=Path(__file__).resolve().parent;cfg=json.loads((root/'settings_gather.json').read_text(encoding='utf-8'))
 client=PolicyClient(cfg['analyzer_url'],cfg['analyzer_model']);data={'model':client.model,'synthetic':True,'game_navigation_verified':False}
 started=time.monotonic()
 try:
  client.probe();data['answer']=blank_check(client,cfg['target_names']);data['valid_answer']=True
 except Exception as exc:data['valid_answer']=False;data['error']=str(exc)
 data['seconds']=round(time.monotonic()-started,2)
 try:data['running_models']=client.call('/api/ps')
 except Exception as exc:data['gpu_error']=str(exc)
 (root/'ai_check.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(data,ensure_ascii=False,indent=2))
 print('Проверены формат и реакция на пустой кадр. Это НЕ проверка распознавания дороги в игре. Для кадра игры: CHECK_AI_VIEW.bat.')
 return 0 if data['valid_answer'] else 1
if __name__=='__main__':raise SystemExit(main())
