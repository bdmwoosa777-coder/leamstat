"""Separate launcher; does not alter the classic version's folder/settings."""
import json
from tkinter import ttk
import app
from ai_engine import AIGatherEngine,FORCED

class AIUI(app.UI):
 def __init__(self):
  super().__init__();self.root.title('ACore2 AI Pilot v0.1.2 — эксперимент, отдельная версия')
  row=ttk.Frame(self.root,padding=5);row.pack(before=self.root.winfo_children()[0],fill='x')
  ttk.Label(row,text='ИИ принимает решения поиска. Модель:').pack(side='left')
  self.model=app.tk.StringVar(value=self.cfg.get('analyzer_model','qwen2.5vl:3b'))
  ttk.Combobox(row,textvariable=self.model,values=['qwen2.5vl:3b','qwen2.5vl:7b'],state='readonly',width=22).pack(side='left')
  ttk.Label(row,text='Сохранить → SETUP_ANALYZER.bat для выбранной модели').pack(side='left',padx=8)
 def save(self):
  self.cfg.update(FORCED);self.cfg['analyzer_model']=self.model.get()
  super().save()
 def analyzer_status(self):self.scene_status()
 def scene_status(self):
  host=getattr(self.engine,'ai',None)
  self.log('AI_POLICY: '+('модель '+self.cfg.get('analyzer_model','')+'; busy='+str(host.busy)+'; error='+str(host.error) if host else 'запускается вместе с ботом. Проверка модели: CHECK_AI.bat'))

def main():
 app.GatherEngine=AIGatherEngine;app.DEFAULT.update(FORCED)
 AIUI().run()
if __name__=='__main__':main()
