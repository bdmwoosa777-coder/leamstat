import unittest,threading,json,time,os
from unittest.mock import patch
from http.server import HTTPServer,BaseHTTPRequestHandler
import numpy as np
from route_analyzer import LocalOllama,AnalyzerHost,AnalyzerHint,compatible,signature,validate_answer
from ground_routes import GroundMap,GroundRoute

ANSWER={'route_id':2,'scene':'passage','reason':'road through the arch','aether':[[400,300,100,80]]}
ROUTE=GroundRoute(2,((.5,.78),(.5,.4)),1,.9,2)
GROUND=GroundMap((ROUTE,),100)
FRAME=np.random.default_rng(3).integers(0,255,(360,640,3),dtype=np.uint8)

class HTTPTests(unittest.TestCase):
 def setUp(self):
  self.requests=[];self.answer=ANSWER.copy();self.capabilities=['vision'];self.redirect=False;self.big=False
  parent=self
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_POST(self):
    payload=json.loads(self.rfile.read(int(self.headers['Content-Length'])));parent.requests.append((self.path,payload))
    if parent.redirect:self.send_response(302);self.send_header('Location','http://example.com/');self.end_headers();return
    result={'capabilities':parent.capabilities} if self.path=='/api/show' else {'message':{'content':json.dumps(parent.answer)}}
    raw=b'x'*70000 if parent.big else json.dumps(result).encode()
    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  self.server=HTTPServer(('127.0.0.1',0),Handler);self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
  self.client=LocalOllama('http://127.0.0.1:'+str(self.server.server_port))
 def tearDown(self):self.server.shutdown();self.server.server_close();self.thread.join()
 def test_real_local_http_vision_schema_and_image(self):
  self.client.probe();a=self.client.analyze(FRAME,GROUND,'leave shelter')
  self.assertEqual(a['route_id'],2);body=self.requests[-1][1]
  self.assertFalse(body['stream']);self.assertNotIn('think',body);self.assertEqual(body['options']['num_ctx'],8192)
  self.assertTrue(body['messages'][0]['images'])
  schema=body['format'];self.assertEqual(set(schema['properties']),{'route_id','scene'})
  self.assertEqual(schema['properties']['route_id']['enum'],[-1,2]);self.assertFalse(schema['additionalProperties'])
  self.assertNotIn('additionalProperties',body['messages'][0]['content'])
 def test_remote_proxy_environment_is_not_used_for_loopback_images(self):
  with patch.dict(os.environ,{'HTTP_PROXY':'http://127.0.0.1:1','HTTPS_PROXY':'http://127.0.0.1:1','NO_PROXY':''}):
   client=LocalOllama(self.client.url);self.assertEqual(client.analyze(FRAME,GROUND,'test')['route_id'],2)
 def test_redirect_cannot_forward_image_to_an_external_host(self):
  self.redirect=True
  with self.assertRaises(ValueError):self.client.analyze(FRAME,GROUND,'test')
 def test_text_only_model_is_not_reported_as_a_vision_analyzer(self):
  self.capabilities=['completion']
  with self.assertRaises(RuntimeError):self.client.probe()
 def test_unknown_route_id_is_rejected(self):
  self.answer={**ANSWER,'route_id':999}
  with self.assertRaises(ValueError):self.client.analyze(FRAME,GROUND,'test')
 def test_excessive_http_response_is_bounded(self):
  self.big=True
  with self.assertRaises(ValueError):self.client.analyze(FRAME,GROUND,'test')

class ContractTests(unittest.TestCase):
 def test_echoed_schema_is_rejected_with_field_names_for_diagnosis(self):
  echoed={'type':'object','properties':{},'required':['route_id','scene']}
  with patch.object(LocalOllama,'call',return_value={'message':{'content':json.dumps(echoed)}}):
   with self.assertRaisesRegex(ValueError,'keys=properties,required,type'):LocalOllama().analyze(FRAME,GROUND,'test')
 def test_partial_answer_is_not_treated_as_a_confirmed_route(self):
  with patch.object(LocalOllama,'call',return_value={'message':{'content':'{"route_id":2}'}}):
   with self.assertRaisesRegex(ValueError,'keys=route_id'):LocalOllama().analyze(FRAME,GROUND,'test')
 def test_compact_route_answer_is_validated_and_has_no_unverified_ether_boxes(self):
  client=LocalOllama()
  with patch.object(client,'call',return_value={'message':{'content':'{"route_id":2,"scene":"passage"}'}}):
   a=client.analyze(FRAME,GROUND,'test');self.assertEqual(a['route_id'],2);self.assertEqual(a['aether'],[])
 def test_compact_unknown_route_cannot_bypass_contract(self):
  with patch.object(LocalOllama,'call',return_value={'message':{'content':'{"route_id":900,"scene":"passage"}'}}):
   with self.assertRaises(ValueError):LocalOllama().analyze(FRAME,GROUND,'test')
 def test_api_error_envelope_is_exposed_instead_of_empty_content(self):
  with patch.object(LocalOllama,'call',return_value={'error':'unsupported option'}):
   with self.assertRaisesRegex(RuntimeError,'Ollama API error: unsupported option'):LocalOllama().analyze(FRAME,GROUND,'test')
 def test_unexpected_envelope_reports_keys_without_capturing_private_content(self):
  with patch.object(LocalOllama,'call',return_value={'status':'private status'}):
   with self.assertRaisesRegex(RuntimeError,'keys=status; message_keys='):LocalOllama().analyze(FRAME,GROUND,'test')
 def test_empty_output_explains_generation_status_without_logging_private_content(self):
  client=LocalOllama()
  with patch.object(client,'call',return_value={'message':{'content':'','thinking':'private'},'done_reason':'length','eval_count':220}):
   with self.assertRaisesRegex(RuntimeError,'done_reason=length; output_tokens=220; thinking_chars=7'):
    client.analyze(FRAME,GROUND,'test')
 def test_fenced_json_still_requires_the_original_strict_schema(self):
  client=LocalOllama()
  with patch.object(client,'call',return_value={'message':{'content':'```json\n'+json.dumps(ANSWER)+'\n```'}}):
   self.assertEqual(client.analyze(FRAME,GROUND,'test'),ANSWER)
 def test_remote_urls_and_cloud_models_are_rejected(self):
  for url in ('https://example.com','http://192.168.0.2:11434','http://user:pw@localhost:11434','http://localhost:11434/forward'):
   with self.assertRaises(ValueError):LocalOllama(url)
  with self.assertRaises(ValueError):LocalOllama(model='qwen3-vl:235b-cloud')
 def test_boxes_need_finite_integer_coordinates_inside_the_image(self):
  for box in ([0,0,1001,3],[900,0,200,3],[0,0,0,3],[float('nan'),0,10,10],[True,0,10,10]):
   with self.assertRaises(ValueError):validate_answer({**ANSWER,'aether':[box]},[-1,2])
 def test_no_free_form_commands_are_accepted(self):
  with self.assertRaises(ValueError):validate_answer({**ANSWER,'press':'f'},[-1,2])
 def test_boolean_is_not_a_route_identifier(self):
  with self.assertRaises(ValueError):validate_answer({**ANSWER,'route_id':True},[-1,2])
 def test_old_or_different_scene_hint_is_not_used(self):
  h=AnalyzerHint(100,7,0,0,signature(FRAME),ANSWER,100)
  self.assertTrue(compatible(h,FRAME,101,7,0,0));self.assertFalse(compatible(h,FRAME,109,7,0,0))
  other=np.random.default_rng(9).integers(0,255,FRAME.shape,dtype=np.uint8)
  self.assertFalse(compatible(h,other,101,7,0,0))
  self.assertFalse(compatible(h,FRAME,101,8,60,0));self.assertFalse(compatible(h,FRAME,101,7,0,.1))

class HostTests(unittest.TestCase):
 def test_close_discards_a_late_response_and_pending_request(self):
  entered=threading.Event();release=threading.Event()
  class Client:
   model='fake-vision'
   def __init__(self,*a):pass
   def probe(self):pass
   def analyze(self,*a):entered.set();release.wait(2);return ANSWER
  host=AnalyzerHost({})
  with patch('route_analyzer.LocalOllama',Client):
   host.offer(FRAME,GROUND,time.monotonic(),7,0,0);self.assertTrue(entered.wait(1))
   host.close();release.set();host.worker.join(timeout=2)
  self.assertIsNone(host.latest);self.assertIsNone(host.pending);self.assertFalse(host.worker.is_alive())
 def test_unavailable_analyzer_is_explicit_and_not_fake_ready(self):
  events=[];host=AnalyzerHost({},events.append)
  with patch('route_analyzer.LocalOllama',side_effect=OSError('not installed')):
   host.offer(FRAME,GROUND,time.monotonic(),0,0,0)
   limit=time.monotonic()+1
   while host.error is None and time.monotonic()<limit:time.sleep(.01)
   host.close();host.worker.join(timeout=1)
  self.assertFalse(host.ready);self.assertIsNone(host.latest);self.assertIn('not installed',host.error)
  self.assertTrue(any('SETUP_ANALYZER' in text for text in events))
 def test_closed_host_cannot_start_a_new_worker(self):
  h=AnalyzerHost({});h.close();h.offer(FRAME,GROUND,100,0,0,0);self.assertIsNone(h.worker)

if __name__=='__main__':unittest.main()
