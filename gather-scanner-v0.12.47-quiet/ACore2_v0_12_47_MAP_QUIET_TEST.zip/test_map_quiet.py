from pathlib import Path
import unittest
import test_map_wire47 as previous
from TEST_MAP_QUIET import execute_probe,wait_quiet
ROOT=Path(__file__).parent
class Quiet(unittest.TestCase):
 def link(self):
  link=previous.Link();link.macros=[];link.aborts=[]
  link.lua.execute((ROOT/'GHUB_MAP_QUIET_TEST.lua').read_text())
  link.lua.globals().PlayMacro=lambda name:link.macros.append((link.now,name))
  link.lua.globals().AbortMacro=lambda:link.aborts.append(link.now)
  link.co=link.lua.eval('function() OnEvent("MOUSE_BUTTON_PRESSED",9) end').coroutine();link.due=link.now;link.advance(.025)
  return link
 def test_receipt_then_two_seconds_without_lock_input_before_named_macro(self):
  link=self.link()
  with link.patch():
   result=execute_probe(link.tr,lambda:True,lambda _:None);self.assertTrue(result['ack']);self.assertEqual(link.macros,[])
   self.assertTrue(wait_quiet(4.,lambda:True,lambda:None,lambda _:None))
  self.assertEqual(len(link.macros),1);start=link.macros[0][0]
  latest=max(t for t,a,k in link.events if a=='up' and k=='capslock' and t<start)
  self.assertGreaterEqual(start-latest,2.)
  self.assertFalse(any(latest<t<start and a=='down' for t,a,k in link.events))
 def test_focus_loss_during_quiet_cancels_before_macro(self):
  link=self.link()
  with link.patch():
   execute_probe(link.tr,lambda:True,lambda _:None)
   def cancel():link.wire._toggle(145,True);link.advance(.12);link.wire._toggle(145,False)
   self.assertFalse(wait_quiet(4.,lambda:False,cancel,lambda _:None));link.advance(4.)
  self.assertEqual(link.macros,[])
 def test_no_receipt_means_no_macro(self):
  link=self.link()
  with link.patch():result=execute_probe(link.tr,lambda:False,lambda _:None);link.advance(4.)
  self.assertFalse(result['ack']);self.assertEqual(link.macros,[])
 def test_macro_remains_one_shot_after_long_idle(self):
  link=self.link()
  with link.patch():execute_probe(link.tr,lambda:True,lambda _:None);link.advance(20)
  self.assertEqual(len(link.macros),1)
 def test_numlock_is_never_pressed(self):
  link=self.link()
  with link.patch():execute_probe(link.tr,lambda:True,lambda _:None);link.advance(4.);link.tr.close()
  self.assertFalse(any(k in (144,'numlock') for _,_,k in link.events))
 def test_interrupt_during_quiet_cancels_before_macro(self):
  link=self.link()
  with link.patch():
   execute_probe(link.tr,lambda:True,lambda _:None)
   def cancel():link.wire._toggle(145,True);link.advance(.12);link.wire._toggle(145,False)
   def interrupt():raise KeyboardInterrupt()
   with self.assertRaises(KeyboardInterrupt):wait_quiet(4.,interrupt,cancel,lambda _:None)
   link.advance(4.)
  self.assertEqual(link.macros,[])
if __name__=='__main__':unittest.main()
