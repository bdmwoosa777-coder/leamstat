"""Visible captions at screen edges, earlier acquisition and directed detours."""
from dataclasses import replace
from pathlib import Path
import io,json,threading,unittest,zipfile
from http.server import HTTPServer,BaseHTTPRequestHandler
from unittest.mock import patch
import cv2,numpy as np
import vision,hybrid_engine as he
from hybrid_engine import HybridGatherEngine
from hybrid_navigation import HybridPlanner,RouteClient,decode_reply
from navigation import Navigator,Drive
from minimap import Marker
from flight import FlightReading
from ground_routes import GroundMap
from test_hybrid import scene,route,FRAME,CTX
from test_navigation import GatherFixture,radar,obs
from test_network_control import Source

ROOT=Path(__file__).resolve().parent

def glyph_frame(x=.70,y=.04,clutter=False):
 f=np.full((1395,2480,3),35,np.uint8)
 if clutter:
  for yy in range(300,850,22):
   for xx in range(600,1900,65):cv2.rectangle(f,(xx,yy),(xx+30,yy+10),(120,180,70),1)
 mask=cv2.imread(str(ROOT/'assets/name_masks/ether_near.png'),0);h,w=mask.shape
 xx,yy=round(x*f.shape[1]),round(y*f.shape[0]);f[yy:yy+h,xx:xx+w][mask>100]=(105,110,100)
 return f

class EdgeCaptions(unittest.TestCase):
 def test_high_world_caption_beside_target_hud_is_read_without_ocr(self):
  for x in (.66,.74):
   with self.subTest(x=x),patch.object(vision,'_text_words',side_effect=AssertionError('slow OCR')):
    c=vision.find_world_resource(glyph_frame(x=x),('Эфир',))
    self.assertIsNotNone(c);self.assertLess(c.box[1],1395*.08)
    self.assertIsNotNone(vision.find_resource_near(glyph_frame(x=x),c))
 def test_clutter_near_screen_centre_cannot_starve_a_high_caption(self):
  found=vision.fast_ether_candidates(glyph_frame(clutter=True))
  self.assertTrue(found);self.assertLess(found[0].box[1],1395*.08)
 def test_upper_resource_hud_minimap_and_log_names_are_never_world_candidates(self):
  for x,y in ((.48,.04),(.86,.15),(.08,.09),(.08,.74)):
   with self.subTest(x=x,y=y):self.assertEqual(vision.fast_ether_candidates(glyph_frame(x,y)),[])

class EarlierAirSearch(unittest.TestCase):
 def make(self):
  # Map pixels are not metres. 15px is outside the old 18px reference radius
  # at this fixture's minimap scale, inside the new 30px reference radius.
  return Navigator({'air_search_wide':True,'air_search_map_radius':30}),radar([Marker('Эфир',115,100,.9,15,'aether')])
 def test_farther_marker_starts_a_grounded_look_before_running_underneath(self):
  nav,r=self.make();d=nav.update(r,100)
  self.assertEqual(d.forward,0);self.assertEqual(d.pitch,.45);self.assertFalse(d.flight_probe)
  self.assertAlmostEqual(d.lifetime,.069)
 def test_wide_scan_preserves_settling_time_and_all_signed_pulses_balance(self):
  nav,r=self.make();r=radar([Marker('Эфир',108,100,.9,8,'aether')]);d=nav.update(r,100);now=100;total=0;count=0
  for _ in range(34):
   if d.pitch:total+=d.pitch*d.lifetime;count+=1;self.assertAlmostEqual(d.lifetime,.069)
   self.assertGreaterEqual(nav.scan_next_at-now-d.lifetime,.3999)
   now=nav.scan_next_at+.001;d=nav.update(r,now)
  self.assertEqual(count,32);self.assertAlmostEqual(total,0)
 def test_failed_outer_scan_closes_in_instead_of_excluding_or_taking_off(self):
  nav,r=self.make();nav.update(r,100);nav.scan_last_pulse=7;nav.scan_next_at=101
  end=nav.update(r,101)
  self.assertTrue(end.restore_pitch);self.assertFalse(end.flight_probe);self.assertTrue(nav.air_outer_scanned)
  self.assertIsNotNone(nav.goal);self.assertFalse(nav.excluded)
  approach=nav.update(r,102);self.assertGreater(approach.forward,.5);self.assertEqual(approach.pitch,0)
  near=radar([Marker('Эфир',108,100,.9,8,'aether')]);self.assertNotEqual(nav.update(near,103).pitch,0)
 def test_new_resource_gets_its_own_outer_scan(self):
  nav,r=self.make();nav.update(r,100);nav.air_outer_scanned=True;nav.exclude_goal(101,1)
  nav.update(r,103);self.assertFalse(nav.air_outer_scanned)
 def test_farther_first_look_does_not_hold_the_full_near_search(self):
  nav,r=self.make();now=100;d=nav.update(r,now);total=0;count=0
  while not d.restore_pitch:
   total+=d.pitch*d.lifetime;count+=1;now=nav.scan_next_at+.001;d=nav.update(r,now)
  self.assertEqual(count,8);self.assertLess(now-100,5);self.assertAlmostEqual(total,0)
  self.assertFalse(d.flight_probe);self.assertIsNotNone(nav.goal)

class VisibleGroundHandoff(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();bridge=self.e.bridge;screen=self.e.screen
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  cfg={**self.e.cfg,'hybrid_camp_exit':False,'analyzer_enabled':False,'auto_view_recovery':True}
  self.e=HybridGatherEngine(cfg,self.log.append,self.input,network=self.source)
  self.e.bridge=bridge;self.e.screen=screen;self.e.mode='SEARCH';self.e.target=None
  self.clock=100.;self.patch=patch.object(he.time,'monotonic',side_effect=lambda:self.clock);self.patch.start();self.addCleanup(self.patch.stop)
 def test_visible_ground_caption_stops_scan_and_has_priority_without_near_distance(self):
  self.input.drive(.7,0,.3);self.e._candidate_observed(self.c,100,0)
  self.assertIsNotNone(self.e.caption_latch);self.assertEqual(self.pad.axes,(0,0,0,0))
  with patch.object(he,'find_resource_near',return_value=self.c):current,waiting=self.e._caption_frame(self.frame,obs(),100)
  self.assertFalse(waiting);self.assertIsNone(current.distance_m);self.assertTrue(self.e._search_caption_priority(current,100))
  with patch.object(he,'find_resource_near',return_value=self.c):
   self.e.step(self.frame,(0,0),current,radar(),FlightReading(None,False),100,1)
  self.assertEqual(self.e.mode,'ACQUIRE_WAIT')
  self.clock=100.3
  with patch.object(he,'find_resource_near',return_value=self.c),patch.object(self.e,'click_candidate',return_value=True) as click:
   self.e.step(self.frame,(0,0),current,radar(),FlightReading(None,False),self.clock,2)
  click.assert_called_once();self.assertEqual(self.pad.presses,0)
 def test_ground_caption_does_not_require_wing_energy_or_enable_wing_actions(self):
  with patch.object(self.e.budget,'can_start',return_value=False):self.e._candidate_observed(self.c,100,0)
  self.assertIsNotNone(self.e.caption_latch);self.assertEqual(self.e.rescue_air_search_until,0)
 def test_search_handoff_cannot_override_owned_collection_or_retreat(self):
  for blocked in ('owned','retreat','focus'):
   self.e.caption_latch=None
   with self.subTest(blocked=blocked),patch.object(self.e.nav,'is_retreating',return_value=blocked=='retreat'),patch.object(self.e,'_focus_ok',return_value=blocked!='focus'):
    self.e.target_confirmed=blocked=='owned';self.e._candidate_observed(self.c,100,0)
    self.assertIsNone(self.e.caption_latch)

class PurposefulGroundMotion(unittest.TestCase):
 def test_moderate_surface_confidence_with_connected_direct_route_keeps_goal_vector(self):
  reading=scene(free=.46);reading=replace(reading,ground=replace(reading.ground,routes=(replace(route(2,.5),confidence=.62),)))
  a=HybridPlanner().choose(Drive(.78),reading,radar(),100)
  self.assertEqual(a.drive.forward,.78);self.assertEqual(a.drive.strafe,0);self.assertFalse(a.detour)
 def test_visible_near_edge_does_not_become_an_open_shortcut(self):
  reading=scene(free=.9);reading=replace(reading,lanes=tuple(replace(l,edge=.1) for l in reading.lanes),ground=replace(reading.ground,drop_support=.1))
  p=HybridPlanner();a=p.choose(Drive(.78),reading,radar(),100)
  self.assertEqual(a.drive.forward,0);self.assertEqual(p.choose(Drive(.78),None,radar(),101).drive.forward,0)
 def test_distant_bend_does_not_turn_camera_while_near_path_is_straight(self):
  bend=replace(route(0,.2),points=((.5,.72),(.5,.60),(.2,.45)))
  reading=replace(scene(),ground=GroundMap((bend,),100))
  p=HybridPlanner();a=p.choose(Drive(.7),reading,radar(),100,hint=0)
  self.assertTrue(a.detour);self.assertGreater(a.drive.forward,.3);self.assertEqual(a.drive.yaw,0)
 def test_near_bend_keeps_camera_steering_and_real_wall_keeps_bounded_survey(self):
  a=HybridPlanner().choose(Drive(.7),scene(),radar(),100,hint=0);self.assertLess(a.drive.yaw,0)
  p=HybridPlanner();wall=replace(scene(),ground=GroundMap());a=p.choose(Drive(.7),wall,radar(),100)
  self.assertEqual(a.drive.forward,0);self.assertNotEqual(a.drive.yaw,0);self.assertTrue(p.choose(Drive(.7),wall,radar(),109).skip)

class StreamingAdvisor(unittest.TestCase):
 def test_recorded_empty_ollama_placeholder_never_authorizes_a_route(self):
  raw=b'{"model":"","created_at":"0001-01-01T00:00:00Z","message":{"role":"","content":""},"done":false}'
  with self.assertRaisesRegex(ValueError,'Empty advisor content'):decode_reply(raw)
 def test_streaming_request_joins_fragments_after_empty_initial_record(self):
  captured={}
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_POST(self):
    captured.update(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
    records=[{'message':{'content':''},'done':False},{'message':{'content':'{"route_id":2,'},'done':False},{'message':{'content':'"scene":"open"}'},'done':True}]
    raw=b'\n'.join(json.dumps(r).encode() for r in records)
    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   c=RouteClient('http://127.0.0.1:'+str(server.server_port));answer=c.analyze(FRAME,scene().ground,CTX)
   self.assertTrue(captured['stream']);self.assertEqual(answer,{'route_id':2,'scene':'open'});self.assertEqual(len(c.last_shape),3)
  finally:server.shutdown();server.server_close();thread.join()

if __name__=='__main__':unittest.main()
