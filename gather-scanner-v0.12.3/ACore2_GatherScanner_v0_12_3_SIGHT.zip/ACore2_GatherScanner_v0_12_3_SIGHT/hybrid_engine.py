"""Classic resource state machine + fast minimap driver + asynchronous detours."""
from dataclasses import replace
import math,time
import cv2
from gather_engine import GatherEngine
from hybrid_navigation import RouteAdvisor,HybridPlanner
from navigation import Drive
from vision import gathering_panel_pair,find_resource_near,find_world_resource,Observation
from return_exit import purple_anchor
from xbox_bridge import XboxBridge
from map_teleport import same_stamp,is_map,menu_stamp
from idle_return import map_evidence

class HybridGatherEngine(GatherEngine):
 def _make_bridge(self,gamepad,cfg,emit):
  if cfg.get('control_transport','xbox')=='lua' or gamepad is None:return super()._make_bridge(gamepad,cfg,emit)
  return XboxBridge(gamepad,self.stop_event,lambda:self.screen.focused(),lambda:self.map_active and self.map_teleport is not None,cfg.get('dry_run',False),emit)
 def _wait_keyboard_alt_state(self,desired,seconds=.6):
  if not getattr(self.bridge,'controller_native',False):return super()._wait_keyboard_alt_state(desired,seconds)
  if self._focus_ok() and bool(self.bridge.alt_is_down())==desired:return True
  self.halt_reason='Режим курсора Xbox LB+LT не подтверждён в отчёте';self.say(self.halt_reason);self.stop();return False
 def _preflight_receiver(self):
  if not getattr(self.bridge,'controller_native',False):return super()._preflight_receiver()
  until=time.monotonic()+10
  while not self.stop_event.is_set() and not self.screen.focused():
   if time.monotonic()>=until:self.halt_reason='Окно AION2 не активно';return False
   if self.stop_event.wait(.05):return False
  if not self._focus_ok():return False
  self._neutral();self.receiver_ready=False
  try:
   if not self.bridge.send('ALT_DOWN') or not self._wait_alt_state(True):return False
   self.bridge.send('ALT_UP')
   if not self._wait_alt_state(False):return False
   self.receiver_ready=True;self.say('Xbox готов: отчёты LB+LT вниз/вверх переданы без A. Lua/G9 не нужны; реакция игры проверяется по кадру, это не игровой ACK')
   return True
  finally:self.bridge.send('ALT_UP')
 def __init__(self,cfg,*args,**kwargs):
  enabled=cfg.get('analyzer_enabled',True)
  super().__init__({**cfg,'analyzer_enabled':False},*args,**kwargs)
  self.cfg['analyzer_enabled']=enabled
  self.cfg['continuous_patrol_defense']=True
  self.cfg['defense_tab_limit']=max(3,min(8,int(cfg.get('defense_max_tabs',8))))
  self.map_exit_failure=None
  self.native_close_after=0
  self.analyzer=RouteAdvisor(self.cfg,self.say) if enabled and self.scene_host is not None else None
  self.hybrid=HybridPlanner(cfg.get('camera_yaw_sign',1));self.hybrid_note=-1e9;self.hybrid_camp_check=-1e9;self.hybrid_identity_note=-1e9;self.hybrid_camp_pending=False;self.caption_latch=None;self.caption_after=0
  if self.gamepad is not None:self.gamepad.translation_lease_floor=float(self.cfg.get('smooth_translation_seconds',.75))
  # One progress watchdog owns detours. The legacy one stores screen-band IDs,
  # which are unsuitable for avoidance across camera changes.
  self.scene_pilot.follower.observe_progress=lambda *a:False
  self.say('HYBRID 0.12.3: курс к ресурсу, приоритет свежего эфира и ударов; выход из ошибки карты без остановки поиска')
 def _no_yield_rescue_allowed(self,now):
  # Ninety seconds without loot is not evidence that walking needs takeoff.
  return self.terrain_watch.due(now)
 def bridge_cmd(self,command):
  native=getattr(self.bridge,'controller_native',False)
  free_close=(command=='END_AIR' and native and self.mode in ('SEARCH','ACQUIRE_WAIT','RESCUE','PROBE','PATROL_ESCAPE') and not self.target_confirmed and not self.resource_hold)
  if free_close and time.monotonic()<getattr(self,'native_close_after',0):return False
  sent=super().bridge_cmd(command)
  if free_close and sent:
   self.native_close_after=time.monotonic()+8;self.rescue_air_search_until=max(self.rescue_air_search_until,self.native_close_after)
  return sent
 def _service_wing_close(self,reading,now):
  if not getattr(self.bridge,'controller_native',False) or self.wing_close_pending is None:return super()._service_wing_close(reading,now)
  if not reading.confirmed:return super()._service_wing_close(reading,now)
  if now-self.wing_close_pending<3:self._neutral();return True
  self.wing_close_pending=None;self.wing_close_started=None;self.wing_close_retries=0
  self.rescue_air_search_until=max(self.rescue_air_search_until,now+5);self.nav.pause(now)
  self.say('AIR_CLOSE: одна Y уже передана; исчезновение дуги не подтверждено, повтор при падении запрещён. Продолжаю поиск без новой Y')
  return False
 def _map_teleport_failed(self,observation,reason,now):
  if self.map_teleport is None or self.map_teleport.used:
   return super()._map_teleport_failed(observation,reason,now)
  self._neutral();self.map_exit_failure={'reason':reason,'since':now,'sent':False,'absent':None}
  self.say('MAP_RECOVER: телепорт не подтверждался; закрываю карту и возвращаю поиск после проверки игрового экрана: '+reason)
 def _map_failure_exit_tick(self,frame,now):
  failure=self.map_exit_failure
  if failure is None:return False
  self._neutral()
  if not self._focus_ok():return True
  if not self._map_input_ready():
   self.halt_reason='MAP_RECOVER: сеть или сбор запрещают ввод';self.say(self.halt_reason);self.stop();return True
  opened=same_stamp(frame,self.map_menu_stamp) or is_map(frame)
  evidence=map_evidence(frame,self.minimap.bounds(frame))
  if opened:
   failure['absent']=None
   if not failure['sent']:
    if self.map_menu_stamp is None:self.map_menu_stamp=menu_stamp(frame)
    failure['sent']=True # A partially delivered toggle must not be repeated.
    if hasattr(self.bridge,'send_guarded'):self.bridge.send_guarded('MAP',lambda:self._map_input_ready(menu=True))
    else:self.bridge_cmd('MAP')
  elif evidence.usable and not evidence.loading:
   if failure['absent'] is None:failure['absent']=now
   if now-failure['absent']>=.6:
    self.bridge.send('STOP');self.map_teleport=None;self.map_active=False;self.map_exit_failure=None
    self.pitch.resume_return(now);self.return_exit_guard=False;self.exit_route=None
    self.no_yield.next_return=max(self.no_yield.next_return,self.map_return_after,now+60)
    self.nav.exclude_goal(now,30);self.nav.pause(now);self.terrain_watch.attempted(now)
    self.hybrid=HybridPlanner(self.cfg.get('camera_yaw_sign',1));self.scene_camera_epoch+=1
    self.identity_valid_after=now;self.change_mode('SEARCH')
    self.say('MAP_RECOVER: игровой экран подтверждён; продолжаю поиск, телепорт успешным не считаю')
    return True
  else:failure['absent']=None
  if now-failure['since']>8:
   self.halt_reason='MAP_RECOVER: закрытие карты не подтверждено за 8 с';self.say(self.halt_reason);self.stop()
  return True
 def _network_defense_tick(self,now):
  if self.network_defense is None and self.mode!='DEFENSE' and self.defense_restore_view is None:
   if self._net_defense(now):return True
  return super()._network_defense_tick(now)
 def _net_defense(self,now):
  if self.mode in ('RESCUE','PROBE','PATROL_ESCAPE'):
   if not self._pending_network_hits(now):return False
   self._neutral();self.caption_latch=None;self.terrain_recovery=None;self.probe=None;self.pending_probe=None;self.patrol_escape=None
   self.pitch.resume_return(now);self.change_mode('SEARCH')
  return super()._net_defense(now)
 def save_debug(self,frame,label):
  if not self.cfg.get('debug_screenshots'):return
  try:
   self.screenshot_path.mkdir(exist_ok=True)
   safe=''.join(c for c in label if c.isalnum() or c=='_')[:80]
   file=self.screenshot_path/('hybrid_'+str(time.time_ns())+'_'+safe+'.jpg')
   if not cv2.imwrite(str(file),frame,[cv2.IMWRITE_JPEG_QUALITY,90]):return
   files=sorted(self.screenshot_path.glob('hybrid_*.jpg'),key=lambda p:p.name);total=sum(p.stat().st_size for p in files)
   while files and (len(files)>60 or total>64*1024*1024):
    old=files.pop(0);total-=old.stat().st_size;old.unlink()
  except (OSError,cv2.error) as exc:self.say('DEBUG_SAVE: '+str(exc)+'; управление продолжается')

 def _needs_visual_hp(self):
  if self.network is None:return True
  if not hasattr(self.network,'confirm_own_hp'):return False
  view=self._net_view();return bool(view and view['ready'] and view['state'].own is None)
 def _health_identity_sample(self,value,captured,verified):
  if self.network is None or not hasattr(self.network,'confirm_own_hp') or not verified or value is None or value.current>=value.maximum or not self._focus_ok() or not self._needs_visual_hp():return
  self.network.confirm_own_hp(value.current,value.maximum,int((time.time()-time.monotonic()+captured)*1000))
 def _network_world_observation(self,frame):
  if self.mode=='RESCUE' and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE':
   return Observation(find_world_resource(frame,('Эфир',)),None,None,False,0,False,None,'HIDDEN')
  return super()._network_world_observation(frame)
 def _candidate_observed(self,candidate,captured,pose,baseline=None):
  now=time.monotonic()
  rescue=self.mode=='RESCUE' and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE'
  if (candidate.name not in self.cfg['target_names'] or self.caption_latch is not None or self.mode not in ('SEARCH','ACQUIRE_WAIT') and not (rescue and candidate.name=='Эфир')
      or self.target_confirmed or self.resource_hold or self.click_busy or self.camera_in_progress
      or self.map_active or self.hybrid_camp_pending or self.pitch.returning or self.pitch.failed or not self.cfg.get('allow_click',True)
      or now<self.caption_after or now<self.camp_exit_until or now<self.defense_evade_until
      or not self.policy.allows(candidate.name) or candidate.name=='Эфир' and not self.budget.can_start()
      or self.nav.is_retreating(now)
      or not self._focus_ok() or not 0<=now-captured<=1.5):return
  if any(n==candidate.name and until>now and abs(candidate.click_x-x)<80 and abs(candidate.click_y-y)<80 for n,x,y,until in self.cooldowns):return
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None or view['state'].attempt_active):return
  if now-captured>.8:
   current,_=self.screen.frame();fresh=find_resource_near(current,candidate)
   if fresh is None:return
   candidate=fresh;pose,baseline=self.pitch.capture(time.monotonic())
  self.caption_latch={'candidate':candidate,'pose':pose,'baseline':self.pitch.baseline_revision if baseline is None else baseline,'until':time.monotonic()+2.5,'restored':False,'settle':0}
  if candidate.name=='Эфир':
   self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
   self.wing_close_pending=None;self.wing_close_started=None;self.wing_close_retries=0
  self._neutral() # Stop as soon as recognition completes, not after the next full navigation tick.
  self.say(('ETHER_SIGHT' if candidate.name=='Эфир' else 'RESOURCE_SIGHT')+': '+candidate.name+' замечен; проверяю ромбик на свежем кадре без обязательного подхода вплотную')
 def _search_caption_priority(self,obs,now):
  # A fresh world caption over sky is actionable. A ground-view repair is
  # useful for walking, but must not turn away from a verified airborne node.
  return bool(self.caption_latch is not None and now<self.caption_latch['until']
              and obs.candidate is not None and self._allowed(obs.candidate,now))
 def _motion(self,plan):
  # A recognition callback can arrive after navigation has planned a turn.
  # Do not let that pending turn sweep a newly seen caption out of view.
  if getattr(self,'caption_latch',None) is not None and self.mode in ('SEARCH','ACQUIRE_WAIT'):
   self._neutral();return True
  return super()._motion(plan)
 def _terrain_recovery_tick(self,frame,reading,now,radar=None):
  if (self.caption_latch is not None and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE'
      and not self.target_confirmed and not self.resource_hold and self._own_collection() is None):
   self._neutral();self.terrain_recovery=None;self.pitch.resume_return(now);self.change_mode('SEARCH');self.nav.pause(now)
   self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
   self.say('ETHER_SIGHT: спасательный перелёт прерван свежей подписью; проверяю ресурс без закрытия крыльев')
   return False
  return super()._terrain_recovery_tick(frame,reading,now,radar)
 def _caption_frame(self,frame,obs,now):
  latch=self.caption_latch
  if latch is None:return obs,False
  if (self.target_confirmed or self.resource_hold or self.mode not in ('SEARCH','ACQUIRE_WAIT')
      or self.map_active or not self._focus_ok() or self._own_collection() is not None):
   self.caption_latch=None;return obs,False
  if now>=latch['until']:
   self.caption_latch=None;self.caption_after=now+1;self.nav.air_since=None;self.nav.scan_kind=None
   return obs,False
  if not latch['restored']:
   self._neutral();error=latch['pose']-self.pitch.offset(now) if latch.get('baseline',self.pitch.baseline_revision)==self.pitch.baseline_revision else 0;latch['restored']=True
   if abs(error)>.006:
    seconds=min(.12,abs(error)/.45)
    self.gamepad.drive(0,0,0,.45 if error>0 else -.45,lifetime=seconds)
    latch['settle']=now+seconds+.2
    return obs,True
  if now<latch['settle']:return obs,True
  fresh=find_resource_near(frame,latch['candidate'])
  if fresh is not None:return replace(obs,candidate=fresh),False
  self._neutral();return obs,True
 def _camp_update(self,frame,radar,now):
  if not self.cfg.get('hybrid_camp_exit',True):return
  if now-self.hybrid_camp_check>=.5:
   self.hybrid_camp_check=now;anchor=purple_anchor(frame,radar.bounds)
   if anchor is not None:
    self.camp_last_seen=now
    if now>=self.camp_exit_retry_after:
     self.camp_exit_until=now+35;self.camp_exit_retry_after=now+65;self.camp_motion=0;self.hybrid_camp_pending=True
     self.say('HYBRID_CAMP_EXIT: сначала наземный выход из области кибелиска, затем ресурсы')
  if self.hybrid_camp_pending:
   self.camp_exit_until=max(self.camp_exit_until,now+.3)
   if radar.motion_valid:self.camp_motion+=math.hypot(*radar.displacement)
   if now-self.camp_last_seen>1.5 and self.camp_motion>8:
    self.camp_exit_until=0;self.hybrid_camp_pending=False;self.say('HYBRID_CAMP_EXIT: удалился по миникарте; возвращаю поиск ресурсов')
 def step(self,frame,origin,obs,radar,reading,now,sequence=0):
  if self.stop_event.is_set():return
  if self.caption_latch is not None:
   obs,waiting=self._caption_frame(frame,obs,now)
   if waiting:return
  if self.mode=='SEARCH' and not self.target_confirmed and not self.resource_hold and not reading.confirmed and not self.map_active:
   self._camp_update(frame,radar,now)
   if now<self.camp_exit_until:
    obs=replace(obs,candidate=None);radar=replace(radar,markers=[])
   # Actual minimap progress owns its timer. A succession of visual detours
   # must not erase the fact that the destination never gets any closer.
  return super().step(frame,origin,obs,radar,reading,now,sequence)
 def _scene_plan(self,frame,radar,reading,plan,now):
  if (self.scene_host is None or self.cfg.get('dry_run') or self.mode!='SEARCH' or self.target_confirmed
      or self.resource_hold or self.collecting_visible or self.map_active or reading.confirmed or self.budget.airborne
      or self.camera_alignment_due or self.pitch.returning or abs(self.pitch.offset(now))>.015
      or not self._focus_ok() or abs(plan.pitch)>.001 or plan.restore_pitch or plan.flight_probe):return plan
  if gathering_panel_pair(frame):return plan
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None):return plan
  heading=radar.heading if radar.confidence>=.30 else None;pitch=self.pitch.offset(now)
  captured=time.monotonic()
  self.scene_host.offer(frame,captured,heading,pitch,self.scene_camera_epoch)
  result=self.scene_host.current(captured,heading,pitch,self.scene_camera_epoch)
  exit_mode=now<self.camp_exit_until
  if exit_mode:plan=Drive(.6,reason='ищу наземный выход из области кибелиска')
  goal=self.nav.goal
  goal_bearing=math.degrees(math.atan2(goal.x-radar.center[0],radar.center[1]-goal.y))%360 if goal else None
  context={'mode':'camp_exit' if exit_mode else 'resources','kind':goal.kind if goal else None,
           'goal_bearing':round(goal_bearing) if goal_bearing is not None else None,
           'goal_relative':round((goal_bearing-heading+180)%360-180) if goal_bearing is not None and heading is not None else None,
           'failed_bearings':[round(b) for b,t in self.hybrid.avoid if now<t]}
  hint=None;warning=None
  if self.analyzer is not None and result is not None and result.ground is not None:
   relative=math.degrees(math.atan2(plan.strafe,plan.forward))
   lane=result.lanes[0 if relative< -18 else 2 if relative>18 else 1]
   clear=(abs(relative)<=80 and result.ground.drop_support<.04 and lane.free>=.55 and lane.solid<.18 and lane.edge<.02
          and any(r.confidence>=.60 for r in result.ground.routes))
   if exit_mode or not clear or self.hybrid.blocked_at is not None or self.hybrid.commit is not None and now<self.hybrid.commit_until:
    self.analyzer.offer(result.source if result.source is not None else frame,result.ground,result.captured,result.heading,result.pitch,context)
   hint=self.analyzer.recommend(result.ground,frame,captured,heading,pitch,context)
   warning=self.analyzer.warning(captured,heading,pitch,context)
  action=self.hybrid.choose(plan,result,radar,now,hint,exit_mode,warning)
  if action.recalibrate:
   if now>=self.scene_view_retry_after:
    self.scene_view_retry_after=now+3;self.scene_view_repair=True;self.nav.air_since=None;self.nav.scan_kind=None;self.view_guard.force(now)
   return Drive()
  if action.skip:
   self.nav.exclude_goal(now,25);self.nav.air_since=None;self.nav.scan_kind=None
   self.say('HYBRID_REPLAN: недоступная цель отложена; выбираю другой ресурс/наземный выход')
  if now-self.hybrid_note>=1.5:
   self.hybrid_note=now
   state='нет' if self.analyzer is None else 'занят' if self.analyzer.busy else 'ошибка' if self.analyzer.error else 'готов' if self.analyzer.ready else 'ожидание'
   self.say('HYBRID_NAV: '+action.reason+'; Qwen='+state+'; локальному кадру '+(str(round(captured-result.captured,2))+' с' if result else 'нет данных'))
  return action.drive
