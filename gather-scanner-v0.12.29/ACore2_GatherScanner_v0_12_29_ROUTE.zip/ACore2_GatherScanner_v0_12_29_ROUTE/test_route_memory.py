"""Demonstrated path storage, closed-loop replay, and control ownership."""
import json,math,tempfile,threading,time,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
from dataclasses import replace
from camp_memory import SavedExit,validate_route,save_route,load_routes,matching_route,ExitRecorder,ExitFollower,RecordingSession
from navigation import Drive
from app import UI
from test_navigation import radar
from test_hybrid import scene,FRAME
import test_camp_departure as camp_fixture
import test_ready_experiment as ready_fixture

TITLE='Рабочий лагерь стального молота'
BOUNDS=(0,0,313,207);CENTER=(156.5,103.5)
def route():return SavedExit(TITLE,313/207,tuple((18.,-3.*i) for i in range(17)))
def anchor(point):return CENTER[0]-point[0],CENTER[1]-point[1]

class PersistentRoutes(unittest.TestCase):
 def test_valid_path_round_trips_and_multiple_places_are_preserved(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'routes.json';save_route(p,route());other=replace(route(),place='Убежище временного приюта')
   save_route(p,other);self.assertEqual(load_routes(p),(route(),other));save_route(p,route())
   self.assertEqual(len(load_routes(p)),2)
 def test_names_require_same_place_and_do_not_match_another_camp(self):
  self.assertEqual(matching_route((route(),),TITLE.upper()),route())
  self.assertIsNone(matching_route((route(),),'Рабочий лагерь другой локации'));self.assertIsNone(matching_route((route(),),''))
 def test_cancel_or_invalid_route_never_overwrites_previous_route(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'routes.json';save_route(p,route());before=p.read_bytes();cancel=threading.Event();cancel.set()
   with self.assertRaises(ValueError):save_route(p,route(),cancel)
   with self.assertRaises(ValueError):save_route(p,replace(route(),points=((0,0),(1,1))))
   self.assertEqual(p.read_bytes(),before)
 def test_nonfinite_points_large_gaps_and_short_paths_are_rejected(self):
  for points in (((0,0),(float('nan'),50)),((0,0),(0,50)),((0,0),(0,1)),((0,0),(True,50))):
   with self.assertRaises(ValueError):validate_route({'place':TITLE,'aspect':1.5,'points':points})
 def test_unknown_schema_and_oversized_store_are_not_executed(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'routes.json';p.write_text('{"version":2,"routes":[]}')
   with self.assertRaises(ValueError):load_routes(p)
   p.write_bytes(b' '*131073)
   with self.assertRaises(ValueError):load_routes(p)

class ReadOnlyDemonstration(unittest.TestCase):
 def test_recorder_captures_landmark_relative_path_and_rejects_lost_landmark(self):
  rec=ExitRecorder(TITLE,CENTER,BOUNDS,anchor((18,0)),100)
  for i in range(1,17):rec.sample(CENTER,BOUNDS,anchor((18,-3*i)),100+.2*i)
  self.assertEqual(rec.finish(103.25),route())
  with self.assertRaises(ValueError):rec.sample(CENTER,BOUNDS,None,105)
 def test_moved_map_or_teleport_is_not_saved_as_walkable_path(self):
  for bounds,point in (((0,0,300,200),(18,-3)),(BOUNDS,(90,-50))):
   rec=ExitRecorder(TITLE,CENTER,BOUNDS,anchor((18,0)),100)
   with self.assertRaises(ValueError):rec.sample(CENTER,bounds,anchor(point),100.2)
 def test_whole_recording_session_reads_frames_without_any_gamepad_commands(self):
  with tempfile.TemporaryDirectory() as tmp:
   session=RecordingSession({'camp_route_store':str(Path(tmp)/'routes.json')},lambda _:None)
   class Capture:
    def __init__(self):self.i=-1
    def pick(self):return 'AION2'
    def focused(self):return True
    def frame(self):
     self.i+=1
     if self.i==16:session.finish_request.set()
     return FRAME.copy(),(0,0)
   capture=Capture();vision=SimpleNamespace(bounds=lambda f:BOUNDS,player=lambda f:CENTER)
   with patch('screen_capture.ScreenCapture',return_value=capture),patch('minimap.MinimapVision',return_value=vision),patch('return_exit.place_title',return_value=TITLE),patch('return_exit.purple_anchor',side_effect=lambda *a,**kw:anchor((18,-3*capture.i))),patch('gamepad_input.GamepadInput.drive') as drive:
    session.start();session.worker.join(5)
   self.assertTrue(session.done.is_set());self.assertIsNone(session.error);drive.assert_not_called()
   self.assertEqual(load_routes(Path(tmp)/'routes.json'),(route(),))
 def test_record_cancel_does_not_create_a_route_file(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'routes.json';session=RecordingSession({'camp_route_store':str(p)},lambda _:None);session.cancel.set()
   screen=SimpleNamespace(pick=lambda:True,focused=lambda:True,frame=lambda:(FRAME,(0,0)))
   vision=SimpleNamespace(bounds=lambda f:BOUNDS,player=lambda f:CENTER)
   with patch('screen_capture.ScreenCapture',return_value=screen),patch('minimap.MinimapVision',return_value=vision),patch('return_exit.place_title',return_value=TITLE),patch('return_exit.purple_anchor',return_value=anchor((18,0))):
    session.start();session.worker.join(2)
   self.assertFalse(p.exists());self.assertIsNone(session.saved)

class ClosedLoopExit(unittest.TestCase):
 def test_shown_corner_is_followed_instead_of_cutting_directly_to_the_endpoint(self):
  points=tuple([(18+3*i,0.) for i in range(11)]+[(48.,-3.*i) for i in range(1,16)])
  saved=validate_route({'place':TITLE,'aspect':313/207,'points':points})
  player=[18.,0.];heading=240.;f=ExitFollower(saved,anchor(player),CENTER,BOUNDS,100,yaw_sign=-1);done=False
  for i in range(280):
   a=f.step(anchor(player),CENTER,BOUNDS,heading,100+i*.25);self.assertIsNone(a.error,a.error)
   if a.done:done=True;break
   d=a.drive;h=math.radians(heading)
   player[0]+=(d.forward*math.sin(h)+d.strafe*math.cos(h))*8*.25
   player[1]+=(-d.forward*math.cos(h)+d.strafe*math.sin(h))*8*.25
   heading=(heading-d.yaw*(d.yaw_lifetime or 0)*500)%360
   self.assertLess(min(abs(player[1]),abs(player[0]-48)),2.1,player)
  self.assertTrue(done,player);self.assertLess(math.dist(player,points[-1]),2)
 def test_replay_uses_measured_position_not_recorded_timing_and_reaches_last_point(self):
  for units_per_second in (4.,8.):
   player=[18.,0.];heading=170.;f=ExitFollower(route(),anchor(player),CENTER,BOUNDS,100);done=False
   for i in range(240):
    now=100+i*.25;a=f.step(anchor(player),CENTER,BOUNDS,heading,now)
    self.assertIsNone(a.error,a.error)
    if a.done:done=True;break
    h=math.radians(heading);d=a.drive
    player[0]+=(d.forward*math.sin(h)+d.strafe*math.cos(h))*units_per_second*.25
    player[1]+=(-d.forward*math.cos(h)+d.strafe*math.sin(h))*units_per_second*.25
    heading=(heading+d.yaw*(d.yaw_lifetime or 0)*500)%360
   self.assertTrue(done,(units_per_second,player));self.assertLess(math.dist(player,route().points[-1]),2)
 def test_wrong_start_or_minimap_shape_is_rejected(self):
  for point,bounds in (((40,0),BOUNDS),((18,0),(0,0,313,313))):
   with self.assertRaises(ValueError):ExitFollower(route(),anchor(point),CENTER,bounds,100)
 def test_actual_wall_stall_is_detected_without_resetting_on_a_visual_route(self):
  f=ExitFollower(route(),anchor((18,0)),CENTER,BOUNDS,100);last=None
  for i in range(19):last=f.step(anchor((18,0)),CENTER,BOUNDS,0,100+i*.25)
  self.assertIsNotNone(last.error);self.assertIn('4 с',last.error)
 def test_missing_landmark_or_position_jump_revokes_drive(self):
  f=ExitFollower(route(),anchor((18,0)),CENTER,BOUNDS,100)
  self.assertIsNotNone(f.step(None,CENTER,BOUNDS,0,101).error)
  f=ExitFollower(route(),anchor((18,0)),CENTER,BOUNDS,100)
  self.assertIsNotNone(f.step(anchor((60,-30)),CENTER,BOUNDS,0,100.2).error)
 def test_last_point_requires_fresh_anchor_not_elapsed_time(self):
  f=ExitFollower(route(),anchor((18,0)),CENTER,BOUNDS,100)
  a=f.step(None,CENTER,BOUNDS,0,100.5);self.assertFalse(a.done)

class EngineReplayOwner(unittest.TestCase):
 def setUp(self):
  self.f=camp_fixture.DepartureControl('test_existing_map_ether_does_not_prevent_initial_departure');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.r=replace(radar(heading=0),center=CENTER,bounds=BOUNDS);self.e.recorded_routes=(route(),)
  with patch('hybrid_engine.purple_anchor',return_value=anchor((18,0))):self.e._camp_update(self.f.frame,self.r,100)
  self.e.recorded_probe={'camp':self.e.camp_route,'at':100,'done':True,'title':TITLE,'error':None}
 def plan(self,now=100):
  with patch('hybrid_engine.time.monotonic',return_value=now),patch('hybrid_engine.purple_anchor',return_value=anchor((18,0))):
   return self.e._scene_plan(self.f.frame,self.r,camp_fixture.GROUND,Drive(.6),now)
 def test_replay_owns_output_and_does_not_call_generic_local_detour(self):
  with patch.object(self.e.hybrid,'choose',side_effect=AssertionError('must not replace demonstrated route')):
   d=self.plan()
  self.assertGreater(d.forward,.4);self.assertEqual(d.yaw,0);self.assertIsNotNone(self.e.recorded_exit)
 def test_own_gathering_target_has_priority_over_replay(self):
  self.e.target_confirmed=True;d=self.plan();self.assertEqual(d.forward,.6)
  self.assertIsNone(self.e.recorded_exit)
 def test_fresh_drop_revokes_saved_route_without_stopping_entire_engine(self):
  self.e.scene_host.current=lambda *a:replace(scene(),ground=replace(scene().ground,drop_support=.1))
  d=self.plan();self.assertEqual((d.forward,d.strafe),(0,0));self.assertIsNone(self.e.recorded_exit)
  self.assertFalse(self.e.stop_event.is_set());self.assertIs(self.e.recorded_rejected,self.e.camp_route)
 def test_wrong_title_never_starts_recorded_drive(self):
  self.e.recorded_probe['title']='Другая локация на карте';d=self.plan()
  self.assertEqual((d.forward,d.strafe),(0,0));self.assertIsNone(self.e.recorded_exit)
 def test_late_collection_after_replay_plan_blocks_actual_controller_translation(self):
  d=self.plan();self.f.source.state.attempt_active=True
  self.e._motion(d)
  self.assertEqual(self.f.pad.axes,(0,0,0,0));self.assertFalse(self.e.stop_event.is_set())
 def test_lost_focus_after_replay_plan_revokes_actual_controller_input(self):
  d=self.plan();self.e.screen.focused=lambda:False;self.e._motion(d)
  self.assertEqual(self.f.pad.axes,(0,0,0,0))
 def test_old_camp_distance_threshold_cannot_finish_replay_before_its_last_point(self):
  self.plan()
  with patch('hybrid_engine.purple_anchor',return_value=anchor((18,-42))):self.e._camp_update(self.f.frame,self.r,101)
  self.assertTrue(self.e.hybrid_camp_pending);self.assertIsNotNone(self.e.recorded_exit)

class RecordingUI(unittest.TestCase):
 def test_ctrl_f8_finishes_recording_without_starting_farm(self):
  u=ready_fixture.StartGate().ui();u.route_record=SimpleNamespace(finish_request=threading.Event());u.start=Mock()
  u.toggle();self.assertTrue(u.route_record.finish_request.is_set());u.start.assert_not_called()
 def test_stop_cancels_pending_recording_and_invalidates_delayed_start(self):
  u=ready_fixture.StartGate().ui();record=SimpleNamespace(cancel=threading.Event());u.route_record=record;u.engine=None
  u.stop();self.assertTrue(record.cancel.is_set());self.assertIsNone(u.route_record);self.assertFalse(u._start_pending)
 def test_saved_route_defers_qwen_and_releases_controller_start_even_with_wait_checked(self):
  u=ready_fixture.StartGate().ui();h=ready_fixture.StartGate().host();u._schedule_game_start=Mock()
  e=SimpleNamespace(analyzer=h,recorded_routes=(route(),))
  with patch('app.GatherEngine',return_value=e):u._launch_if_ready(5)
  h.prepare.assert_not_called();u._schedule_game_start.assert_called_once_with(5)
 def test_saved_route_also_does_not_wait_for_old_model_cleanup(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'routes.json';save_route(p,route());old=ready_fixture.StartGate().host()
   u=ready_fixture.StartGate().ui(old);u.cfg['camp_route_store']=str(p);u._schedule_game_start=Mock()
   new=ready_fixture.StartGate().host();e=SimpleNamespace(analyzer=new,recorded_routes=(route(),))
   with patch('app.GatherEngine',return_value=e):u._launch_if_ready(5)
   u._schedule_game_start.assert_called_once_with(5);new.prepare.assert_not_called();old.close.assert_called_once()

if __name__=='__main__':unittest.main()
