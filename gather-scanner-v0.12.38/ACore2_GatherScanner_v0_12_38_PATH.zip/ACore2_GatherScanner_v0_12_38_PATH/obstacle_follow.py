"""One goal, persistent wall-following side, feedback from delivered walking.

No guessed obstacle height. Fresh connected ground/side lane authorizes each
step; failure escalates to the engine's existing bounded flight protocol.
"""
from collections import deque
from dataclasses import replace
import math
from navigation import Drive
from minimap import angle_delta
from hybrid_navigation import RouteAction,near_route_vector,near_route_angle

class ObstacleFollower:
 def __init__(self):self.reset()
 def reset(self):
  self.key=None;self.side=0;self.phase=None;self.started=0;self.entry_distance=None;self.walk=0.;self.travel=0.
  self.at=None;self.lease=0.;self.samples=deque();self.last_now=None;self.clear_hits=0;self.clear_seq=None;self.last_rejoin=0
  self.failed_side=0;self.switched=False;self.learned_side=0;self.bypass_bearing=None;self.obstacle_kind=None
 @property
 def active(self):return self.phase is not None
 def delivered(self,now,deadline,moving):
  self.advance(now)
  self.lease=min(deadline,now+.8) if moving and deadline is not None else now
 def advance(self,now):
  if self.at is not None and now<self.at:return
  dt=0 if self.at is None else max(0,min(now,self.lease)-self.at)
  if self.active:self.walk+=dt
  self.samples.append([now,dt,0.,0.]);self.at=now
  while self.samples and now-self.samples[0][0]>2.5:self.samples.popleft()
 def observe(self,key,radar,now):
  if key!=self.key:self.reset();self.key=key
  self.advance(now)
  if self.last_now!=now:
   self.last_now=now
   if radar.motion_valid:
    move=math.hypot(*radar.displacement)/max(.5,(radar.bounds[2]-radar.bounds[0])/313)
    if move<15:
     self.travel+=move
     scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
     self.samples[-1][2]+=radar.displacement[0]/scale;self.samples[-1][3]+=radar.displacement[1]/scale
    else:self.samples.clear()
   else:self.samples.clear()
 def stalled(self):return sum(s[1] for s in self.samples)>=1.6 and math.hypot(sum(s[2] for s in self.samples),sum(s[3] for s in self.samples))<1.1
 def choose(self,plan,scene,radar,now,distance,preferred=None,waypoint=None):
  if scene is None or not 0<=now-scene.captured<=.9 or radar.heading is None or radar.confidence<.3:return None
  graph=scene.ground
  if graph is None:return None
  if graph.drop_support>=.04 or scene.sky>.55 or scene.water>.25:
   self.phase=None;return None
  desired=math.degrees(math.atan2(plan.strafe,plan.forward));lane=scene.lanes[0 if desired< -18 else 2 if desired>18 else 1]
  if abs(desired)>75 and not self.active:return None
  stalled=self.stalled()
  blocked=(lane.solid>=.26 and lane.free<.55) or stalled
  clear=(abs(desired)<=70 and lane.free>=.55 and lane.solid<.15 and lane.edge<.02 and graph.drop_support<.015
         and any(r.confidence>=.60 and r.clearance>=.5 and abs(near_route_angle(r,scene)-desired)<20 for r in graph.routes))
  if not self.active:
   if not blocked:return None
   allowed=[side for side in (-1,1) if scene.lanes[0 if side<0 else 2].edge<.02]
   if not allowed:return None
   self.side=preferred if preferred in allowed else max(allowed,key=lambda side:scene.lanes[0 if side<0 else 2].free-scene.lanes[0 if side<0 else 2].solid)
   self.phase='BYPASS';self.started=now;self.walk=0.;self.travel=0.;self.entry_distance=distance
   self.bypass_bearing=(radar.heading+desired+self.side*70)%360
   self.obstacle_kind='протяжённая преграда' if sum(l.solid>=.26 for l in scene.lanes)>=2 else 'локальная преграда'
  if clear and self.travel>=3:
   if scene.sequence!=self.clear_seq:self.clear_hits+=1;self.clear_seq=scene.sequence
   if self.clear_hits>=2 and self.phase!='REJOIN':
    self.phase='REJOIN';self.last_rejoin=now;self.learned_side=self.side
    if not stalled:return RouteAction(replace(plan,yaw=0,yaw_lifetime=None,lifetime=.65),'обход: прямой коридор открылся, возвращаюсь к тому же ресурсу',detour=True)
  else:self.clear_hits=0;self.clear_seq=None
  if self.phase=='REJOIN':
   if clear and not stalled:
    if now-self.last_rejoin>2:self.phase=None
    return RouteAction(replace(plan,yaw=0,yaw_lifetime=None,lifetime=.65),'обход: продолжаю сближение с сохранённой целью',detour=True)
   self.phase='BYPASS';self.clear_hits=0
  steer_bearing=waypoint if waypoint is not None else self.bypass_bearing
  relative=angle_delta(steer_bearing,radar.heading)
  lane=scene.lanes[0 if relative< -18 else 2 if relative>18 else 1]
  if lane.edge>=.02:
   other=scene.lanes[2 if self.side<0 else 0]
   if other.edge>=.02:self.phase=None;return None
   self.side*=-1;self.switched=True;lane=other
   self.bypass_bearing=(radar.heading+desired+self.side*70)%360;relative=angle_delta(self.bypass_bearing,radar.heading)
  # A long, unsuccessful leg is not a reason to run a stale command forever.
  if now-self.started>=18 or self.walk>=16 or self.walk>=4 and stalled and scene.lanes[1].solid>=.30:
   wall=all(l.edge<.02 for l in scene.lanes) and graph.drop_support<.015 and scene.lanes[1].solid>=.30
   self.failed_side=self.side;self.phase=None
   return RouteAction(Drive(),'обход не дал прохода: проверяю короткий подъём либо другую точку',skip=True,wall_escape=wall)
  routes=[r for r in graph.routes if r.confidence>=.4 and r.clearance>=.5
          and abs(angle_delta(near_route_angle(r,scene),relative))<55 and scene.lanes[0 if near_route_angle(r,scene)< -18 else 2 if near_route_angle(r,scene)>18 else 1].edge<.02]
  if routes:
   route=max(routes,key=lambda r:r.confidence+.1*min(r.clearance,3)-abs(angle_delta(near_route_angle(r,scene),relative))*.015)
   forward,strafe=near_route_vector(route,scene)
   return RouteAction(Drive(forward,strafe,lifetime=.65),('память обхода: текущий проход к следующей сохранённой точке' if waypoint is not None else 'обход '+('слева' if self.side<0 else 'справа')+': держу связный проход, цель сохранена'),detour=True)
  if lane.free>=.30 and lane.solid<.25 and lane.edge<.015:
   angle=math.radians(max(-80,min(80,relative)))
   return RouteAction(Drive(.82*math.cos(angle),.82*math.sin(angle),lifetime=.65),'обход '+('слева' if self.side<0 else 'справа')+': смещаюсь вдоль препятствия без поворота камеры',detour=True)
  if not self.switched and self.walk>=3 and stalled:
   self.failed_side=self.side;self.side*=-1;self.switched=True
   self.bypass_bearing=(radar.heading+desired+self.side*70)%360;relative=angle_delta(self.bypass_bearing,radar.heading)
  yaw=math.copysign(.38,relative) if abs(relative)>15 else 0
  return RouteAction(Drive(yaw=yaw,lifetime=.25,yaw_lifetime=.12 if yaw else None),'обход: '+self.obstacle_kind+'; проверяю землю вдоль выбранной стороны',detour=True)
