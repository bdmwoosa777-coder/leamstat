"""Caption-relative probes for the small aether hitbox; no body-colour guesses."""
def ether_click_points(candidate,width,height):
    x,y,w,h=candidate.box
    cx=round(x+w/2);bottom=round(y+h)
    near=max(4,min(12,round(h*.45)));mid=max(8,min(20,round(h*.85)))
    far=max(12,min(30,round(h*1.3)));side=max(2,min(5,round(h*.18)))
    points=((candidate.click_x,candidate.click_y),(cx,bottom+near),(cx,bottom+2),
            (cx,bottom+mid),(cx-side,bottom+near),(cx+side,bottom+near),(cx,bottom+far))
    return tuple(dict.fromkeys((max(0,min(width-1,round(px))),max(0,min(height-1,round(py)))) for px,py in points))
