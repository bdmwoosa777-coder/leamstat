"""Passive Global telemetry state; it never sends game input.

Wire facts cross-checked with a2kit (MIT), CubeRadar and the public
Aion-2-Helper resource observations. An old position or selection-clear is
not proof that a resource is exhausted. No fixed actor IDs or HP maxima.
"""
from dataclasses import dataclass,field,replace
import copy
import math
import struct


class Invalid(ValueError):pass
class Cursor:
    def __init__(self,data):self.data=data;self.at=0
    def take(self,count):
        if count<0 or self.at+count>len(self.data):raise Invalid('truncated')
        result=self.data[self.at:self.at+count];self.at+=count;return result
    def u8(self):return self.take(1)[0]
    def u32(self):return int.from_bytes(self.take(4),'little')
    def var(self):
        value=0
        for shift in range(0,35,7):
            byte=self.u8();value|=(byte&127)<<shift
            if not byte&128:
                if value>0xffffffff:raise Invalid('overflow')
                return value
        raise Invalid('overflow')
    def end(self):
        if self.at!=len(self.data):raise Invalid('unexpected tail')


def stats(data):
    c=Cursor(data);actor=c.var();flags=c.u8();rows={}
    if not actor or flags>3:raise Invalid('stats variant')
    for bit,width in ((1,4),(2,8)):
        if not flags&bit:continue
        count=c.var()
        if count>64:raise Invalid('stats count')
        for _ in range(count):
            kind=c.u8();value=int.from_bytes(c.take(width),'little',signed=True)
            if value<0 or (width,kind) in rows:raise Invalid('invalid stat')
            rows[width,kind]=value
    c.end();return actor,rows


def own_profile(data):
    c=Cursor(data);actor=c.var();c.take(4);flags=c.u8()
    if not actor or not flags&1:raise Invalid('self profile identity')
    size=c.u8()
    if not 2<=size<=24:raise Invalid('name length')
    c.take(size).decode('utf-8');c.take(2)
    shared=c.at;role=c.u32();faction=c.u8()
    if not 5<=role<=36 or faction not in (1,2):raise Invalid('self profile class')
    matches=[]
    for at in (shared+160,shared+161):
        try:
            r=Cursor(data);r.take(at);mask=int.from_bytes(r.take(2),'little')
            xyz=struct.unpack('<ffff',r.take(16));r.take(2)
            if not all(math.isfinite(v) and abs(v)<(1000000 if i<3 else 720) for i,v in enumerate(xyz)):continue
            for bit,size in ((1,12),(2,4),(4,2),(8,12),(16,12),(32,4)):
                if mask&bit:r.take(size)
            if r.u8()>3:continue
            hp,maximum=r.var(),r.var();base=r.at;mp,mpmax=r.u32(),r.u32()
            if not 0<=hp<=maximum<=1000000000 or maximum==0 or not 0<=mp<=mpmax<=10000000 or mpmax==0:continue
            if len(data)<base+52:continue
            fp,fm=struct.unpack_from('<II',data,base+44)
            if not 0<=fp<=fm<=100000000 or fm==0:continue
            matches.append(dict(actor=actor,hp=hp,maximum=maximum,flight=fp,flight_maximum=fm,xyz=tuple(xyz[:3])))
        except (Invalid,struct.error):continue
    if len(matches)!=1:raise Invalid('ambiguous self profile')
    return matches[0]


@dataclass
class Node:
    actor:int
    template:int|None=None
    xyz:tuple|None=None
    used:int|None=None
    visible:bool=True
    time:int=0
    gather_time:int|None=None
    generation:int=0
    removed_reason:int|None=None


@dataclass
class Flow:
    own:int|None=None
    identity_source:str='unknown'
    map_id:int|None=None
    xyz:tuple|None=None
    position_at:int|None=None
    position_source:str='unknown'
    profile_at:int|None=None
    selected:int=0
    selection_time:int=0
    collecting:int|None=None
    started:int|None=None
    attempt_active:bool=False
    attempt_ordinal:int|None=None
    last_own_result:tuple|None=None
    hp:int|None=None
    maximum:int|None=None
    flight:int|None=None
    flight_maximum:int|None=None
    flight_at:int|None=None
    last_packet:int|None=None
    nodes:dict=field(default_factory=dict)
    falls:list=field(default_factory=list)
    pending_attempts:dict=field(default_factory=dict)
    identity_interactions:dict=field(default_factory=dict)
    own_candidates:dict=field(default_factory=dict)
    npcs:dict=field(default_factory=dict)
    attacks:dict=field(default_factory=dict)
    deaths:dict=field(default_factory=dict)
    players:dict=field(default_factory=dict)
    outgoing:dict=field(default_factory=dict)

    def snapshot(self):
        """Isolated flat state copy without recursively traversing immutable data.

        Called under the capture lock. Readers must never share a mutable node,
        NPC dictionary or identity bootstrap dictionary with the live decoder.
        """
        result=copy.copy(self)
        for attr,value in vars(self).items():
            if isinstance(value,dict):
                setattr(result,attr,{key:replace(item) if isinstance(item,Node)
                        else item.copy() if isinstance(item,dict) else item for key,item in value.items()})
            elif isinstance(value,list):setattr(result,attr,value.copy())
        return result


class Telemetry:
    def __init__(self,resource_ids=()):
        self.resource_ids=set(resource_ids);self.flows={};self.events=[];self.rejected=0
    def emit(self,kind,time,flow,**fields):
        item=dict(kind=kind,t=time,flow=flow,**fields);self.events.append(item)
        self.new_events.append(item)
        if len(self.events)>4096:del self.events[:2048]
        return item
    def feed(self,flow,op,data,time):
        if (not isinstance(time,int) or isinstance(time,bool) or not isinstance(data,bytes)
            or len(data)>65536):return []
        self.new_events=[]
        f=self.flows.setdefault(flow,Flow())
        if f.last_packet is not None and time<f.last_packet:return []
        if f.last_packet is not None and time-f.last_packet>30000:
            f=Flow();self.flows[flow]=f
        f.last_packet=time
        try:self._feed(f,flow,op.lower(),data,time)
        except (Invalid,struct.error,UnicodeDecodeError,IndexError):self.rejected+=1
        return self.new_events
    def _feed(self,f,key,op,data,time):
        c=Cursor(data)
        if op=='3336':
            profile=own_profile(data);actor=profile.pop('actor')
            if f.own is not None and f.own!=actor:
                f.nodes.clear();f.collecting=None;f.selected=0;f.hp=f.maximum=None
                f.flight=f.flight_maximum=None
                f.attacks.clear();f.falls.clear();f.pending_attempts.clear()
                f.deaths.clear();f.players.clear();f.outgoing.clear()
            f.own=actor;f.identity_source='self-profile';f.profile_at=time
            for attr,value in profile.items():setattr(f,attr,value)
            f.position_at=time;f.position_source='self-profile';f.flight_at=time
            self.emit('self_identity',time,key,actor=actor)
            self.emit('own_stats',time,key,actor=actor,**profile)
        elif op=='2136':
            if len(data)!=46:return
            c.u32();map_id=c.u32()
            if not 0<map_id<10000000:return
            if f.map_id is not None and map_id!=f.map_id:
                f.nodes.clear();f.npcs.clear();f.attacks.clear();f.pending_attempts.clear()
                f.deaths.clear();f.players.clear();f.outgoing.clear()
                f.collecting=None;f.started=None;f.attempt_active=False;f.selected=0
                if f.profile_at is None or not 0<=time-f.profile_at<=2000:
                    f.own=None;f.identity_source='map-change';f.own_candidates.clear()
                    f.hp=f.maximum=f.flight=f.flight_maximum=None
            f.map_id=map_id
            f.xyz=None;f.position_at=None;f.position_source='unknown'
            self._position(f,key,struct.unpack_from('<fff',data,16),time,'zone-spawn')
        elif op=='2336':
            # Own teleport: zero entity marker, five fixed bytes, then XYZ.
            if c.var()!=0 or len(data)<18:return
            c.take(5)
            self._position(f,key,struct.unpack('<fff',c.take(12)),time,'own-teleport')
        elif op=='008d':
            actor,rows=stats(data)
            # Global stamina is an own-only row in the supported observations.
            if (4,3) in rows and f.own is None:
                f.own=actor;f.identity_source='own-stamina'
            if (4,6) in rows and f.own is None:
                previous=f.own_candidates.get(actor)
                f.own_candidates={a:t for a,t in f.own_candidates.items() if time-t<=3000}
                f.own_candidates[actor]=time
                if previous is not None and 50<=time-previous<=2000 and len(f.own_candidates)==1:
                    f.own=actor;f.identity_source='repeated-own-flight'
            if (4,6) in rows and f.own is not None and actor!=f.own and f.identity_source=='repeated-own-flight':
                f.own=None;f.identity_source='ambiguous-own-flight'
                f.own_candidates[actor]=time
            if actor in f.npcs and (8,0) in rows:
                f.npcs[actor]['hp']=rows[8,0]
                if rows[8,0]==0:f.npcs[actor]['dead']=True
            if (8,0) in rows and rows[8,0]==0 and actor!=f.own and (actor in f.attacks or actor in f.npcs):
                f.deaths[actor]=time
                self.emit('actor_death',time,key,actor=actor,proof='zero-hp')
            if actor!=f.own:return
            values={}
            for slot,attr in (((8,0),'hp'),((8,7),'maximum'),((4,6),'flight'),((4,13),'flight_maximum')):
                if slot in rows:values[attr]=rows[slot]
            if 'maximum' in values and values['maximum']==0:raise Invalid('zero maximum')
            for attr,value in values.items():setattr(f,attr,value)
            if 'flight' in values:f.flight_at=time
            if values:self.emit('own_stats',time,key,actor=actor,**values)
        elif op=='3436':
            actor=c.var();p=c.at
            if len(data)-p!=52:return
            kind=int.from_bytes(c.take(2),'little');template=c.u32()
            if kind!=4 or template not in self.resource_ids:return
            xyz=struct.unpack('<fff',c.take(12));used=struct.unpack_from('<I',data,p+37)[0]
            if used>3 or not all(math.isfinite(v) and abs(v)<1000000 for v in xyz):raise Invalid('node')
            old=f.nodes.get(actor);generation=int.from_bytes(data[p+29:p+37],'little')
            if not 1600000000000<=generation<=2600000000000:generation=0
            reused=old and (old.template!=template or generation and old.generation and generation!=old.generation
                           or not old.visible and old.used is not None and used<old.used)
            if reused:
                if f.collecting==actor:f.collecting=None;f.started=None;f.attempt_active=False
                old=None
            if old and old.template==template and old.used is not None:used=max(used,old.used)
            f.nodes[actor]=Node(actor,template,xyz,used,True,time,old.gather_time if old else None,generation)
            f.npcs.pop(actor,None);f.players.pop(actor,None);f.deaths.pop(actor,None);f.attacks.pop(actor,None)
            if len(f.nodes)>1024:
                for aid in list(f.nodes)[:256]:
                    if aid!=f.collecting and aid!=f.selected:f.nodes.pop(aid,None)
            self.emit('resource_profile',time,key,actor=actor,template=template,used=used)
        elif op=='3438':
            if c.take(3)!=b'\0\0\0':return
            actor=c.var();c.end();f.selected=actor;f.selection_time=time
            self.emit('selection',time,key,actor=actor)
            # A zero selection is observed BETWEEN ordinary attempts. Keep the
            # collection lease until its own counter says three / removal.
            if actor and actor!=f.collecting:
                f.collecting=None;f.started=None;f.attempt_active=False
                f.identity_interactions.clear();f.pending_attempts.clear()
        elif op=='3836':
            actor,source=c.var(),c.var()
            if c.take(1)!=b'\1':raise Invalid('interaction marker')
            c.end()
            if f.own is None:
                typed=actor in f.nodes and f.nodes[actor].template in self.resource_ids
                if (actor!=f.selected and not (not f.selected and typed)) or not source or source==actor or source in f.npcs:return
                peers=f.identity_interactions.setdefault(actor,{})
                peers={p:t for p,t in peers.items() if 0<=time-t<=1500}
                peers[source]=time;f.identity_interactions[actor]=peers
                self._bootstrap_gather_identity(f,key,actor,time)
                return
            if f.own is None or source!=f.own or actor==source:return
            if actor in f.npcs or actor in f.players:return
            if actor not in f.nodes and actor!=f.selected:
                if f.selected:return
                f.identity_interactions[actor]={f.own:time}
                self._pair_unselected_own(f,key,actor,time)
                return
            if actor not in f.nodes:f.nodes[actor]=Node(actor,time=time)
            f.collecting=actor;f.started=time;f.attempt_active=True
            known=f.nodes[actor].template in self.resource_ids
            self.emit('own_interaction_start',time,key,actor=actor,known_resource=known)
            pending=f.pending_attempts.pop(actor,None)
            if pending and 0<=time-pending[0]<=1500:
                self._attempt(f,key,actor,pending[1],time)
        elif op=='318d':
            if c.take(2)!=b'\0\0':return
            actor=c.var();ordinal=c.u32()
            if not 1<=ordinal<=3 or len(data)-c.at<20:return
            if f.own is None and (actor==f.selected or not f.selected and actor in f.nodes and f.nodes[actor].template in self.resource_ids):
                f.pending_attempts[actor]=(time,ordinal)
                self._bootstrap_gather_identity(f,key,actor,time)
                return
            if actor==f.collecting and f.started is not None and 0<=time-f.started<=1500:
                self._attempt(f,key,actor,ordinal,time)
            elif f.own is not None and (actor==f.selected or not f.selected) and actor not in f.npcs and actor not in f.players:
                f.pending_attempts={a:p for a,p in f.pending_attempts.items() if 0<=time-p[0]<=1500}
                f.pending_attempts[actor]=(time,ordinal)
                self._pair_unselected_own(f,key,actor,time)
        elif op=='3a36':
            actor,source=c.var(),c.var();used,tail=c.u32(),c.u32();c.end()
            if used>3 or tail!=0:return
            node=f.nodes.get(actor)
            if node is None:return
            if node.used is None or used>=node.used:node.used=used;node.time=time
            if (source==f.own and f.collecting==actor and used==node.used
                and (f.attempt_ordinal is None or used>=f.attempt_ordinal)):
                if (used>0 and actor not in f.npcs and actor not in f.players
                    and node.gather_time is None and f.started is not None
                    and 0<=time-f.started<=120000):
                    node.gather_time=f.started
                    self.emit('own_gather_confirmed_by_result',time,key,actor=actor,used=used)
                f.last_own_result=(actor,time)
                f.attempt_active=False
                self.emit('own_attempt_ended',time,key,actor=actor,used=used,remaining=3-used)
                if used==3:
                    self.emit('own_resource_exhausted',time,key,actor=actor)
                    f.collecting=None;f.started=None;f.attempt_active=False
        elif op=='3536':
            actor=c.var();reason,variant,zero=c.u8(),c.u8(),c.u8();c.end()
            if (reason,variant,zero) not in ((1,1,0),(4,3,0)):return
            node=f.nodes.get(actor)
            if node is None:
                if actor!=f.selected:return
                node=Node(actor);f.nodes[actor]=node
            node.visible=False;node.time=time;node.removed_reason=reason
            if f.collecting==actor:
                self.emit('resource_unavailable',time,key,actor=actor,reason=reason,
                          exhausted=node.used==3)
                f.collecting=None;f.started=None;f.attempt_active=False
        elif op=='4536':
            # A typed server player profile is negative evidence for mob defense.
            # Names/account fields are deliberately not retained.
            actor=c.var()
            if actor and len(data)-c.at>=32:
                f.players[actor]=time
                f.npcs.pop(actor,None);f.nodes.pop(actor,None)
                if len(f.players)>2048:
                    for old in list(f.players)[:512]:f.players.pop(old,None)
        elif op=='4136':
            actor=c.var();c.take(2);ownerflag=c.var()
            if ownerflag not in (0,1):return
            if ownerflag:c.take(c.u8()).decode('utf-8')
            template=c.u32();flags=c.u8()
            if c.u8()!=2:return
            xyz=struct.unpack('<ffff',c.take(16));c.take(2)
            if flags&8:c.take(12)
            alive=c.u8();hp,maximum=c.var(),c.var()
            if alive>1 or maximum==0 or hp>maximum or not all(math.isfinite(v) for v in xyz):return
            previous=f.npcs.get(actor)
            reborn=bool(actor in f.deaths or previous and (previous.get('dead') or previous.get('template')!=template)
                        or actor in f.players or actor in f.nodes)
            born_at=(time if reborn else previous.get('born_at',previous.get('time',time)) if previous
                     else min(time,f.attacks.get(actor,time)))
            f.npcs[actor]=dict(template=template,hp=hp,maximum=maximum,dead=not alive,
                               summoned=bool(ownerflag),time=time,born_at=born_at,xyz=tuple(xyz[:3]))
            f.players.pop(actor,None)
            f.nodes.pop(actor,None)
            if reborn:f.attacks.pop(actor,None);f.outgoing.pop(actor,None)
            if alive and hp>0:f.deaths.pop(actor,None)
            if len(f.npcs)>2048:
                for old in list(f.npcs)[:512]:f.npcs.pop(old,None)
        elif op=='0438':
            actor,target,damage=damage_hit(data)
            if actor==f.own:
                f.outgoing[target]=(time,damage)
                self.emit('own_outgoing_hit',time,key,actor=actor,target=target,damage=damage)
                if len(f.outgoing)>1024:
                    for old in list(f.outgoing)[:256]:f.outgoing.pop(old,None)
            if target==f.own and damage>0:
                f.attacks[actor]=time
                self.emit('own_combat_damage',time,key,actor=actor,target=target,damage=damage)
        elif op=='4236':
            actor=c.var();zero=c.u8();flag=c.var();c.end()
            if actor and zero==0 and flag==3:
                f.deaths[actor]=time
                if len(f.deaths)>2048:
                    for old in list(f.deaths)[:512]:f.deaths.pop(old,None)
                if actor in f.npcs:
                    f.npcs[actor]['dead']=True
                    self.emit('npc_death',time,key,actor=actor)
                else:self.emit('actor_death',time,key,actor=actor,proof='server-death')
        elif op=='1738':
            actor,damage=c.var(),c.var();c.end()
            if actor!=f.own:return
            f.falls.append((time,damage));f.falls=f.falls[-16:]
            self.emit('own_fall_damage',time,key,actor=actor,damage=damage)

    def _position(self,f,key,xyz,time,source):
        if not all(math.isfinite(v) and abs(v)<1000000 for v in xyz):raise Invalid('position')
        f.xyz=tuple(xyz);f.position_at=time;f.position_source=source
        self.emit('own_position',time,key,source=source)

    def _attempt(self,f,key,actor,ordinal,time):
        node=f.nodes[actor]
        if node.used is not None and node.used>ordinal-1:return
        node.used=ordinal-1;node.gather_time=time;node.time=time;f.attempt_active=True;f.attempt_ordinal=ordinal
        self.emit('own_gather_started',time,key,actor=actor,attempt=ordinal)

    def _pair_unselected_own(self,f,key,actor,time):
        # Missing 34 38 must not discard an actual private minigame paired
        # with an interaction from an ALREADY known own character.
        if f.own is None or f.selected or actor in f.npcs or actor in f.players:return
        pending=f.pending_attempts.get(actor);start=f.identity_interactions.get(actor,{}).get(f.own)
        if pending is None or start is None or not 0<=time-min(start,pending[0])<=1500:return
        if actor not in f.nodes:f.nodes[actor]=Node(actor,time=start)
        f.collecting=actor;f.started=start;f.attempt_active=True
        f.pending_attempts.pop(actor,None);f.identity_interactions.pop(actor,None)
        self.emit('own_interaction_start',start,key,actor=actor,known_resource=False)
        self._attempt(f,key,actor,pending[1],pending[0])

    def _bootstrap_gather_identity(self,f,key,actor,time):
        """Client's private minigame + selected node + unique paired interaction.

        A broadcast interaction alone, nearby HP, pet target or a missing OCR
        panel cannot identify self. 31 8D is the minigame sent to its gatherer.
        Existing self identity is never replaced by an inference here.
        """
        typed=actor in f.nodes and f.nodes[actor].template in self.resource_ids
        if f.own is not None or f.identity_source=='ambiguous-own-flight' or (actor!=f.selected and not (not f.selected and typed)):return
        attempt=f.pending_attempts.get(actor)
        peers=f.identity_interactions.get(actor,{})
        peers={p:t for p,t in peers.items() if 0<=time-t<=1500}
        if not attempt or not 0<=time-attempt[0]<=1500 or len(peers)!=1:return
        source,start=next(iter(peers.items()))
        if min(start,attempt[0])<f.selection_time or not source or source in f.npcs:return
        f.own=source;f.identity_source='own-gather-dialog'
        f.collecting=actor;f.started=start;f.attempt_active=True
        if actor not in f.nodes:f.nodes[actor]=Node(actor,time=time)
        f.pending_attempts.clear();f.identity_interactions.clear()
        self.emit('self_identity',time,key,actor=source)
        self.emit('own_interaction_start',start,key,actor=actor,
                  known_resource=f.nodes[actor].template in self.resource_ids)
        self._attempt(f,key,actor,attempt[1],attempt[0])


def damage_hit(data):
    """Full 04 38 hit layout from MIT a2kit; reject unknown/truncated tails."""
    c=Cursor(data);target=c.var();switch=c.var();form=c.var()
    if form&~0x15 or switch&15 not in (0,4,6):raise Invalid('hit variant')
    actor=c.var();c.u32();c.take(1)
    if c.var()>255:raise Invalid('hit type')
    if switch&15==6:c.take(1);c.var();c.take(1)
    c.u32()
    if c.u32()>255:raise Invalid('hit count')
    c.var();damage=c.var() if switch&15 else 0
    if switch&31==20:c.take(1)
    if switch&32:
        n=c.var()
        if n>1024:raise Invalid('hit extra')
        for _ in range(n):c.var()
    for present in (form&1,switch&64):
        if present:c.take(c.u8()*4)
    c.take(1)
    if c.u8()!=0:raise Invalid('hit tail')
    if form&4:c.var()
    if form&16 and switch&15==4:c.take(1)
    c.end();return actor,target,damage
