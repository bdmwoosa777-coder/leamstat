"""Occluded resource after combat, bounded camera views, and camera settings."""
import copy,json,tempfile,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import gather_engine as ge
import app
from flight import FlightReading
from vision import caption_candidate
from camera_working_view import working_view_ms,WORKING_VIEW_PRESETS
from resource_view_recovery import VIEW_PULSES
from test_navigation import GatherFixture,obs
from test_network_control import Source
from test_control_regressions import caption_frame

GROUND=FlightReading(None,False)

class ViewRecoveryTests(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(resource_click_interaction=True,defense_during_approach=False)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.attempt_active=False;self.f.collecting=None;self.f.selection_time=1100
        self.e.network_target=(1,99);self.e.network_claimed_at=900;self.e.network_owner=7
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='APPROACH'
        self.frame,box=caption_frame();self.e.candidate=caption_candidate(self.frame,'Сапфир',box,95)
        self.clock=100.;self.wall=1100;self.clicks=0;self.drives=[]
        def wait(seconds,*args):self.clock+=seconds;return True
        for p in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),
                  patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),
                  patch.object(ge.GamepadInput,'wait',side_effect=wait)):
            p.start();self.addCleanup(p.stop)
        drive=self.input.drive
        def record(*args,**kwargs):self.drives.append(args);return drive(*args,**kwargs)
        self.input.drive=record
        def click(*args,**kwargs):self.clicks+=1;return True
        self.input.tap_a=click

    def arm(self):self.e._begin_reacquire('return after defense')

    def tick(self):return self.e._view_recovery_tick(self.frame,GROUND,self.clock)

    def test_occluded_body_becomes_clickable_after_nudge_and_resumes_same_node(self):
        self.arm();original=self.e.network_target
        # Caption stays visible; the model accepts clicks only after changing view.
        def click(*args,**kwargs):
            self.clicks+=1
            if self.drives:
                self.f.collecting=99;self.f.attempt_active=True;self.f.nodes[99].gather_time=self.wall
            return True
        self.input.tap_a=click
        self.assertTrue(self.e.click_candidate(self.e.candidate,(0,0),retry=True))
        self.assertIsNone(self.f.collecting)
        self.clock=self.e.view_recovery.next_at+.01;self.tick();self.clock+=.21
        self.e._approach_fast_tick(self.frame,(0,0),GROUND,self.clock)
        self.assertEqual(self.f.collecting,99)
        self.e._resource_fast_tick(self.frame,GROUND,self.clock)
        self.assertEqual(self.e.network_target,original);self.assertEqual(self.e.mode,'GATHER')
        self.assertIsNone(self.e.view_recovery);self.assertEqual(self.e.resource_retry_after,{})
        self.assertNotIn('TAP_F',self.commands)

    def test_expired_actor_is_also_excluded_from_xyz_navigation(self):
        self.e.resource_retry_after[(1,99)]=145
        self.source.atlas=SimpleNamespace(objects={'1550020':{'names':{'ru':'Сапфир'}}})
        self.f.xyz=(0,0,0);self.f.position_at=1100;self.f.nodes[99].xyz=(0,1000,0)
        from test_navigation import radar
        view=radar();view.markers=[]
        self.e._spatial_route(view)
        self.assertFalse(self.e.spatial_route_active)

    def test_after_combat_missing_point_gets_camera_only_views(self):
        self.arm();self.frame[:]=0;self.clock=101.1
        self.assertTrue(self.tick());self.assertEqual(len(self.drives),1)
        self.assertEqual(self.drives[0][:2],(0,0));self.assertEqual(self.pad.axes,(0,0,0,0))
        self.assertFalse({'TAP_F','F_ON','V','TAB'}&set(self.commands))
        self.assertEqual(self.e.network_target,(1,99))

    def test_view_sequence_checks_both_horizontal_and_vertical_directions(self):
        self.arm()
        for i in range(len(VIEW_PULSES)):
            self.clock=self.e.view_recovery.next_at+.01;self.tick()
        yaw=[v[2] for v in self.drives];pitch=[v[3] for v in self.drives]
        self.assertTrue(any(x>0 for x in yaw));self.assertTrue(any(x<0 for x in yaw))
        self.assertTrue(any(x>0 for x in pitch));self.assertTrue(any(x<0 for x in pitch))
        self.assertAlmostEqual(sum(y*t for y,p,t in VIEW_PULSES),0)
        self.assertAlmostEqual(sum(p*t for y,p,t in VIEW_PULSES),0)
        self.assertEqual(self.e.view_recovery.until,112)

    def test_repeated_begin_does_not_extend_total_deadline(self):
        self.arm();deadline=self.e.view_recovery.until
        self.clock+=5;self.e._begin_reacquire('another unsuccessful click')
        self.assertEqual(self.e.view_recovery.until,deadline)
        self.assertEqual(self.e.reacquire_until,deadline)

    def test_selected_but_occluded_body_cannot_reset_budget_to_approach_forever(self):
        self.arm();deadline=self.e.view_recovery.until
        self.clock+=1
        # The game retains the resource target, but A hits the obstructing rock.
        self.assertTrue(self.e.click_candidate(self.e.candidate,(0,0),retry=True))
        self.assertTrue(self.e.target_confirmed);self.assertEqual(self.e.mode,'APPROACH')
        self.assertEqual(self.e.view_recovery.until,deadline)
        self.clock=deadline+.1
        self.assertTrue(self.tick());self.assertEqual(self.e.mode,'SEARCH')
        self.assertFalse(self.e.target_confirmed);self.assertFalse(self.e.stop_event.is_set())
        self.assertGreater(self.e.resource_retry_after[(1,99)],self.clock)

    def test_fresh_start_after_changed_view_ends_camera_retries(self):
        self.arm();self.clock=101.1;self.tick()
        self.f.collecting=99;self.f.attempt_active=True;self.f.nodes[99].gather_time=1100
        self.e._resource_fast_tick(self.frame,GROUND,self.clock)
        self.assertIsNone(self.e.view_recovery);self.assertEqual(self.e.mode,'GATHER')
        count=len(self.drives);self.clock+=20;self.tick();self.assertEqual(len(self.drives),count)
        self.assertFalse(self.e.stop_event.is_set())

    def test_attempt_arriving_at_timeout_wins_over_abandonment(self):
        self.arm();self.clock=112.1
        self.f.collecting=99;self.f.attempt_active=True;self.f.nodes[99].gather_time=1100
        self.assertFalse(self.tick());self.assertIsNone(self.e.view_recovery)
        self.assertEqual(self.e.resource_retry_after,{})
        self.assertNotIn('END_AIR',self.commands)

    def test_no_nudge_in_active_or_between_owned_attempts(self):
        for active in (True,False):
            self.arm();self.clock+=2
            self.f.collecting=99;self.f.attempt_active=active;self.f.nodes[99].gather_time=1100
            self.assertFalse(self.tick());self.assertIsNone(self.e.view_recovery)
            self.f.collecting=None;self.f.attempt_active=False
        self.assertEqual(self.drives,[])

    def test_near_selected_resource_that_never_started_arms_repair(self):
        self.e.native_route_started_at=97;self.e.last_progress=97
        self.e.distance_live=2;self.e.distance_live_at=100
        self.tick();self.assertIsNotNone(self.e.view_recovery)

    def test_moving_approach_does_not_start_camera_repair(self):
        self.e.native_route_started_at=97;self.e.last_progress=99.8
        self.e.distance_live=7;self.e.distance_live_at=100
        self.tick();self.assertIsNone(self.e.view_recovery);self.assertEqual(self.drives,[])

    def test_new_camera_view_can_click_without_waiting_two_more_seconds(self):
        self.arm();self.clock=101.1;self.tick()
        # Already reselected; the previous click did not start the native route.
        self.e.target_confirmed=True;self.e.mode='APPROACH';self.e.route_f_sent=True
        self.e.last_progress=self.clock;self.e.native_route_started_at=self.clock
        self.clock+=.21
        self.e._approach_fast_tick(self.frame,(0,0),GROUND,self.clock)
        self.assertEqual(self.clicks,1);self.assertFalse(self.e.view_click_pending)

    def test_settle_interval_prevents_click_on_pre_turn_snapshot(self):
        self.arm();self.clock=101.1;self.tick();self.clock+=.1
        self.assertTrue(self.tick());self.assertEqual(self.clicks,0)
        self.assertGreater(self.e.identity_valid_after,100)

    def test_timeout_reacquire_releases_and_quarantines_only_that_actor(self):
        self.arm();self.clock=112.1;self.tick()
        self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.view_recovery)
        self.assertFalse(self.e._selected_resource(self.source.view(),'Сапфир'))
        self.f.nodes[100]=copy.deepcopy(self.f.nodes[99]);self.f.nodes[100].actor=100;self.f.selected=100
        self.assertTrue(self.e._selected_resource(self.source.view(),'Сапфир'))
        self.f.selected=99;self.clock+=46
        self.assertTrue(self.e._selected_resource(self.source.view(),'Сапфир'))

    def test_abandon_does_not_let_live_resource_header_cancel_the_skip(self):
        self.arm();self.e.target_confirmed=True;self.e.mode='APPROACH';self.clock=112.1
        with patch.object(ge,'segment_count',return_value=3),patch.object(ge,'resource_header_visible',return_value=True):self.tick()
        self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.target_confirmed)

    def test_timeout_folds_owned_flight_then_searches(self):
        self.arm();self.e.resource_flight_owned=True;self.clock=112.1
        self.e._view_recovery_tick(self.frame,FlightReading(50,True),self.clock)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIn('END_AIR',self.commands)

    def test_deadline_is_paused_for_a_second_real_attacker(self):
        self.arm();self.e.network_attacker=55
        self.f.attacks[55]=1050;self.f.npcs[55]={'time':900}
        self.clock=103;self.e._begin_network_defense(True)
        self.clock=108;self.e._finish_network_defense(True)
        self.assertEqual(self.e.view_recovery.until,117)
        self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.e.mode,'REACQUIRE')

    def test_no_focus_or_disconnected_network_does_not_nudge(self):
        self.arm();self.clock=102;self.e.screen.focused=lambda:False;self.tick()
        self.e.screen.focused=lambda:True;self.source.ready=False;self.tick()
        self.assertEqual(self.drives,[])

    def test_calibration_and_recovery_cannot_drive_camera_at_the_same_time(self):
        self.arm();self.clock=102;self.e.camera_in_progress=True;self.tick()
        self.assertEqual(self.drives,[])

    def test_pending_actual_damage_does_not_get_a_camera_nudge(self):
        self.arm();self.clock=102;self.f.attacks[55]=1050;self.f.npcs[55]={'time':900}
        self.tick();self.assertEqual(self.drives,[])


class CameraSettingTests(GatherFixture,unittest.TestCase):
    def test_default_and_extended_choices_are_valid(self):
        self.assertEqual(working_view_ms({}),770);self.assertEqual(app.DEFAULT['camera_working_view_ms'],770)
        for value in (770,800,850,900,1000,1100,1200):
            self.assertIn(value,WORKING_VIEW_PRESETS);self.assertEqual(working_view_ms({'camera_working_view_ms':str(value)}),value)
        self.assertEqual(working_view_ms({'camera_working_view_ms':775}),775)
        for bad in (1201,640,800.5,'bad',None,float('nan'),float('inf')):
            self.assertEqual(working_view_ms({'camera_working_view_ms':bad}),770)

    def test_down_hold_delivers_distinct_770_1000_and_1200ms_without_long_lease(self):
        clock=[100.];reports=[];listener=self.input.motion_listener
        def record(pitch,now,lease):reports.append((pitch,lease));listener(pitch,now,lease)
        self.input.motion_listener=record
        def wait(seconds):clock[0]+=seconds;return True
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(self.e,'_camera_wait',side_effect=wait):
            for requested in (.770,1.000,1.200):
                before=self.e.pitch.offset(clock[0])
                self.assertTrue(self.e._hold_pitch_down(requested))
                actual=(before-self.e.pitch.offset(clock[0]))/.45
                self.assertAlmostEqual(actual,requested,delta=.006)
        self.assertTrue(all(lease<=.15 for pitch,lease in reports if pitch<0))
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_saved_choice_reaches_running_engine_for_next_calibration(self):
        ui=SimpleNamespace(cfg={},vars={},backend=SimpleNamespace(get=lambda:'gamepad'),
                           working_ms=SimpleNamespace(get=lambda:'1100'),engine=SimpleNamespace(cfg={}),log=lambda s:None)
        with tempfile.TemporaryDirectory() as d,patch.object(app,'CONF',Path(d)/'settings.json'):
            app.UI.save(ui)
            saved=json.loads((Path(d)/'settings.json').read_text())
        self.assertEqual(saved['camera_working_view_ms'],1100)
        self.assertEqual(ui.engine.cfg['camera_working_view_ms'],1100)

if __name__=='__main__':unittest.main()
