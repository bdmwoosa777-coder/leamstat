"""Fast navigation loop with independent OCR, heartbeat and dialog watchers."""
from pathlib import Path
from dataclasses import replace
import threading
import time
import traceback
import math
import cv2
from bridge import GHubBridge
from gamepad_input import GamepadInput,TranslationKeeper
from screen_capture import ScreenCapture
from minimap import MinimapVision
from navigation import Navigator,Drive
from camera_pitch import PitchLedger
from camera_control import PITCH_STRENGTH
from camera_working_view import working_view_ms
from flight_probe import FlightProbe
from patrol_escape import PatrolStall,PatrolEscape
from network_state import Node
from spatial import geometry,resource_names
from resource_policy import ResourcePolicy
from resource_view_recovery import ResourceViewRecovery,VIEW_PULSES
from resource_clicks import ether_click_points
from receiver_check import check_receiver
from network_defense import NetworkDefense,attack_reason,dead
from health import HealthMonitor,read_hp
from view_guard import ViewGuard
from map_reference import MapReference
from defense import ThreatDetector,GatherInterrupts,enemy_hp
from flight import read_flight,FlightBudget
from vision import (WorldVision,find_world_resource,selected_target,segment_count,
                    gathering_panel,gathering_panel_pair,gather_result_full,resource_header_visible,Observation,find_resource_near,read_target_distance,selected_resource_name)
from captcha_watchdog import CenterDialogDetector,AudioAlarm
from death_watchdog import DeathDialogDetector,DeathAudioAlarm

ROOT=Path(__file__).resolve().parent
OWN_RESOURCE='Собственный ресурс (имя уточняется)'


class GatherEngine:
    def __init__(self,cfg,emit,gamepad=None,network=None):
        self.cfg,self.emit=cfg,emit
        self.halt_reason=None;self.receiver_ready=False
        self.policy=ResourcePolicy(cfg)
        self.network=network;self.network_target=None;self.network_claimed_at=0;self.network_owner=None;self.network_slots_seen=None
        self.network_note_at=0;self.network_wait_since=None;self.network_exhausted=False
        self.network_hit_handled=0;self.network_attacker=None;self.network_selection_after=0;self.network_slots_seen=None
        self.network_defense=None;self.defense_motion=None;self.defense_camera_until=None
        self.attacker_retry_after={};self.attacker_handled={}
        self.visual_selection=None;self.acquisition_clicked_at=None;self.claimed_names={}
        self.network_bound_at=0
        self.resume_resource_id=None
        self.view_recovery=None;self.view_click_pending=False;self.resource_retry_after={}
        self.ether_click_index=0;self.abandoning_binding=None;self.abandoned_lease=None
        self.visual_route=None
        self.stop_event=threading.Event();self.screen=ScreenCapture()
        self.bridge=GHubBridge(dry_run=cfg.get('dry_run',False),logger=emit)
        self.gamepad=gamepad
        self.vision=WorldVision(tuple(cfg['target_names']))
        self.minimap=MinimapVision(cfg);self.nav=Navigator(cfg)
        self.pitch=PitchLedger()
        self.pitch_observed=isinstance(gamepad,GamepadInput)
        if self.pitch_observed:gamepad.motion_listener=self.pitch.report
        self.health=HealthMonitor();self.hp_handled_event=0;self.hp_next_defense=0
        self.probe=None;self.pending_probe=None
        self.patrol_stall=PatrolStall();self.patrol_escape=None;self.patrol_escape_side=1
        self.view_guard=ViewGuard()
        self.camera_scheduler_active=False;self.camera_last_calibrated=None
        self.camera_search_revision=0;self.camera_aligned_revision=0;self.camera_gather_tried_revision=-1
        self.camera_alignment_due=None;self.camera_requested_at=0
        self.calibration_resource_ended=False;self.camera_in_progress=False
        self.click_busy=False;self.click_wait_since=None;self.click_retry_at=0
        self.route_click_tries=0;self.route_click_sent_at=None
        self.fast_header_seen=False;self.fast_last_slots=None;self.fast_gather_seen=False
        self.fast_absent_since=None;self.last_flight_seen_at=None;self.last_flight_energy=None
        self.wing_close_pending=None;self.wing_close_retries=0;self.wing_absent_since=None
        self.wing_close_started=None
        self.arrival_camera_corrected=False
        self.resource_flight_owned=False;self.reacquire_until=None;self.reacquire_next=0
        self.acquire_failures=0;self.panel_last_seen=None;self.repeat_rearmed=False
        self.collection_activity_at=None;self.wing_block_note=-1e9
        self.distance_check_at=0;self.distance_live=None;self.distance_live_at=None;self.approach_recovery_at=0;self.approach_note_at=0
        self.f_repeat_allowed=False;self.route_active=False;self.last_path_motion=None
        self.real_gather_panel_seen=False;self.route_f_sent=False;self.route_f_pending=False
        self.wing_route_restart_pending=False;self.wing_route_restart_authorized=False;self.native_route_started_at=None
        self.calibration_defense_interrupted=False
        self.region=MapReference(cfg);self.map_active=False
        self.threat=ThreatDetector(cfg);self.interrupts=GatherInterrupts()
        self.collecting_visible=False;self.resource_hold=False;self.panel_cleared=False
        self.defense_cycles=0;self.next_defense=0;self.post_gather_until=0
        self.last_hold_note=0
        self.budget=FlightBudget(cfg.get('flight_low_percent',8),cfg.get('flight_resume_percent',18),
                                 retry_delay=cfg.get('flight_retry_delay',3))
        self.cap=CenterDialogDetector(template_dir=ROOT);self.death=DeathDialogDetector(template_dir=ROOT)
        self.cap_alarm=AudioAlarm(logger=emit);self.death_alarm=DeathAudioAlarm(logger=emit)
        self.cap_alarm.device_match=self.death_alarm.device_match=cfg.get('audio_device','AG271QG4')
        self.mode='SEARCH';self.started=time.monotonic();self.target=None;self.target_confirmed=False
        self.f_on=False;self.folded=False;self.flight_attempted=False;self.jump_attempted=False;self.reselected=False
        self.f_renewed_at=None;self.ocr_wait_note=0
        self.next_attempt_pending=None;self.next_attempt_sent_used=None;self.next_attempt_wait_at=None;self.next_attempt_click_tries=0
        self.network_managed_f=False
        self.spatial_route_active=False
        self.last_distance=None;self.last_progress=self.started;self.missing_since=None
        self.last_segments=None;self.one_segment_armed=False;self.node_count=0
        self.candidate=None;self.candidate_since=None;self.candidate_sequence=None
        self.cooldowns=[];self.last_note=0;self.last_energy_note=0
        self.snapshot_lock=threading.Lock();self.snapshot=None;self.sequence=0
        self.observation_captured_at=0
        self.identity_valid_after=0
        self.safety_threads=[];self.release_thread=None;self.release_lock=threading.Lock()
        self.alert=None;self.alert_lock=threading.Lock();self.current_size=None
        self.screenshot_path=ROOT/'debug_gather'
        if cfg.get('debug_screenshots'):self.screenshot_path.mkdir(exist_ok=True)

    def say(self,text):self.emit('['+self.mode+'] '+text)

    def change_mode(self,mode):self.mode=mode;self.started=time.monotonic()

    def _net_view(self):
        return self.network.view() if self.network is not None else None

    def _net_node(self,view=None):
        view=view or self._net_view()
        if not view or not view['ready'] or self.network_target is None:return None
        flow,actor=self.network_target
        if view['flow']!=flow or self.network_owner is not None and view['state'].own!=self.network_owner:return None
        return view['state'].nodes.get(actor) or Node(actor,time=self.network_claimed_at)

    def _gather_panel(self,frame):
        if self.network is None:return gathering_panel_pair(frame)
        view=self._net_view()
        return bool(self._net_gather_proof() and view['state'].attempt_active)

    def _net_gather_proof(self):
        view=self._net_view();node=self._net_node(view)
        return bool(node is not None and node.gather_time is not None
                    and node.gather_time>=self.network_claimed_at and node.used is not None and node.used<3
                    and node.visible and not self._inactive_lease_ignored(view,node)
                    and view['state'].collecting==node.actor
                    and view['state'].selected in (0,node.actor))

    def _net_claim(self):
        until=time.monotonic()+2.5
        while self._focus_ok():
            view=self._net_view()
            if self._selected_resource(view,self.target):
                self.network_target=(view['flow'],view['state'].selected);self.network_owner=view['state'].own
                self.network_claimed_at=self.network_selection_after
                self.network_bound_at=time.monotonic()
                self.claimed_names[self.network_target]=self.target
                self.say('Сеть подтвердила выбранный ресурс; ожидаю начало собственного сбора')
                return True
            if time.monotonic()>=until:break
            if not GamepadInput.wait(.04,self.stop_event,self.screen.focused):return False
        self.say('За 2.5 с ресурс не подтверждён профилем или свежей верхней плашкой: F запрещён, продолжаю поиск');return False

    def _selected_resource(self,view,expected):
        if not view or not view['ready']:return False
        state=view['state'];node=state.nodes.get(state.selected)
        if time.monotonic()<self.resource_retry_after.get((view['flow'],state.selected),0):return False
        if self.resume_resource_id is not None and self.resume_resource_id!=(view['flow'],state.selected):return False
        if not state.selected or state.selection_time<self.network_selection_after:return False
        if state.selected in state.npcs or state.selected in state.players or state.selected in state.deaths:return False
        if node and (not node.visible or node.used==3):return False
        if node and node.template is not None:
            return bool(node.visible and node.used is not None and node.used<3 and resource_names().get(node.template)==expected)
        # A spawn can predate capture. An UNKNOWN actor needs a NEW resource
        # HUD reading, bound to that exact selected ID, after this A press.
        proof=self.visual_selection
        return bool(proof and self.acquisition_clicked_at is not None and proof[:3]==(view['flow'],state.selected,expected)
                    and proof[3]>=self.acquisition_clicked_at)

    def _inactive_lease_ignored(self,view,node):
        if view['state'].attempt_active:return False
        binding=(view['flow'],node.actor)
        return (time.monotonic()<self.resource_retry_after.get(binding,0)
                or self.abandoned_lease==(*binding,node.gather_time))

    def _own_collection(self,view=None):
        view=view or self._net_view()
        if not view or not view['ready'] or view['state'].own is None:return None
        state=view['state'];node=state.nodes.get(state.collecting)
        if node is not None and self._inactive_lease_ignored(view,node):return None
        if state.collecting in state.npcs or state.collecting in state.players:return None
        if (node and node.gather_time is not None and node.visible and node.used is not None
            and node.used<3 and state.selected in (0,node.actor)):return node
        return None

    def _adopt_network_collection(self):
        if self.network is None or self.mode=='DEFENSE':return False
        view=self._net_view();node=self._own_collection(view)
        if (node is None and view and view['ready'] and self.mode in ('APPROACH','REACQUIRE')
            and self.target is not None and view['state'].last_own_result):
            actor,ended=view['state'].last_own_result
            candidate=view['state'].nodes.get(actor)
            if (self.network_target!=(view['flow'],actor) and ended>=self.network_claimed_at
                and actor not in view['state'].npcs and actor not in view['state'].players
                and 0<=time.time()*1000-ended<=2500 and candidate and candidate.used==3
                and candidate.gather_time is not None):node=candidate
        if node is None:return False
        label=resource_names().get(node.template) or self.claimed_names.get((view['flow'],node.actor))
        route=self.visual_route
        if (not label and route and route['flow']==view['flow'] and node.gather_time>=route['selection_after']):
            label=route['name'];self.claimed_names[(view['flow'],node.actor)]=label
        proof=self.visual_selection
        if (not label and proof and proof[:2]==(view['flow'],node.actor)
            and proof[2] in self.cfg['target_names'] and proof[3]>=self.network_bound_at):label=proof[2]
        same=self.network_target==(view['flow'],node.actor)
        if self.target_confirmed and same:
            if label and label!=self.target:
                self.target=label;self.say('Фактически собираемый ресурс уточнён: '+label)
            return False
        self._release_visual_route()
        previous=self.target if self.target_confirmed else None
        label=label or OWN_RESOURCE
        self._neutral()
        sent_used=self.next_attempt_sent_used if same else None
        sent_at=self.next_attempt_wait_at if same else None
        click_tries=self.next_attempt_click_tries if same else 0
        self._reset_resource_watch(True)
        self.next_attempt_sent_used=sent_used;self.next_attempt_wait_at=sent_at;self.next_attempt_click_tries=click_tries
        self.target=label;self.target_confirmed=True;self.resource_hold=True
        self.network_target=(view['flow'],node.actor);self.network_owner=view['state'].own
        self.network_claimed_at=node.gather_time
        self.network_bound_at=time.monotonic()
        self.reacquire_until=None;self.missing_since=None
        if not same:
            self.resume_resource_id=None
            self.candidate=None;self.nav.goal=None
        self.probe=None;self.pending_probe=None;self.patrol_escape=None
        self.change_mode('APPROACH')
        self.say(('После F игра начала другой собственный сбор вместо '+previous+': ' if previous and not same else 'Собственный сбор подтверждён сетью: ')+label+'; принимаю его без нового стартового F и без движения')
        return True

    def _budget_update(self,reading,now):
        view=self._net_view()
        fresh_energy=False
        if view and view['ready']:
            state=view['state']
            fresh_energy=state.flight_at is not None and 0<=time.time()*1000-state.flight_at<=2000
            if (fresh_energy and state.flight is not None and state.flight_maximum is not None and state.flight_maximum>0
                and state.flight<=state.flight_maximum):
                reading=replace(reading,energy=100*state.flight/state.flight_maximum)
        self.budget.update(reading,now)
        if view and view['ready'] and fresh_energy:
            state=view['state']
            if state.flight is not None and state.flight_maximum and state.flight<=state.flight_maximum:
                self.budget.energy=100*state.flight/state.flight_maximum
                if now<self.budget.retry_after or self.budget.energy<self.budget.low:self.budget.blocked=True
                elif self.budget.energy>=self.budget.resume:self.budget.blocked=False
        self.policy.update(self.budget)


    def _network_guard(self,now):
        if self.network is None:return False
        view=self._net_view()
        if not view['ready']:
            self._neutral();self.f_disable()
            if self.network_wait_since is None:self.network_wait_since=now
            if now-self.network_note_at>3:
                self.say('Сеть: '+(view.get('reason') or view['error'] or 'ожидаю подтверждение игрового потока'))
                self.network_note_at=now
            if view['error'] or now-self.network_wait_since>30:
                self.say('Данные сети не подтверждены: остановка ввода. Подробности в network_diagnostics.');self.stop()
            return True
        self.network_wait_since=None
        if self.network_owner is None and self.network_target is not None and view['state'].own is not None:
            self.network_owner=view['state'].own
        if (self.network_target is not None and (view['flow']!=self.network_target[0]
            or self.network_owner is not None and view['state'].own!=self.network_owner)):
            self._neutral();self.f_disable();self.say('Сетевое подключение/персонаж сменились: остановка до нового запуска');self.stop();return True
        return False

    def _net_resource(self,frame,reading,now):
        if self.network is None or not self.target_confirmed:return False
        view=self._net_view();node=self._net_node(view)
        if node is None:return False
        if node.used is not None and node.used!=self.network_slots_seen:
            self.say(f'Сеть: осталось попыток {3-node.used}/3 у текущего ресурса')
            self.network_slots_seen=node.used
        if node.used==3 or not node.visible and node.removed_reason==4:
            self.network_exhausted=True
            try:self.return_to_search('Сеть: ресурс полностью израсходован или удалён сервером',frame,exhausted=True,reading=reading)
            finally:self.network_exhausted=False
            return True
        if not node.visible:
            self._begin_reacquire('Сеть: ресурс вышел из видимости; повтор F выключен');return True
        selected=view['state'].selected
        if selected and selected!=node.actor:
            self._begin_reacquire('Сеть подтвердила смену цели: F выключен, возвращаюсь к ресурсу');return True
        if self.real_gather_panel_seen and view['state'].collecting!=node.actor:
            self._begin_reacquire('Сеть больше не подтверждает своё взаимодействие с ресурсом: F выключен');return True
        if self._net_gather_proof():
            if not self.real_gather_panel_seen:
                self.real_gather_panel_seen=True;self.route_f_sent=True;self.wing_route_restart_pending=False
                self.fast_gather_seen=True;self.f_repeat_allowed=True;self.route_active=False
                self.change_mode('GATHER');self.say('Сеть подтвердила начало МОЕГО сбора: жду окончания попытки, фонового F нет')
            self.fast_last_slots=3-node.used;self.collection_activity_at=now-max(0,(time.time()*1000-node.time)/1000)
            self.fast_absent_since=None;self.f_enable()
            if (self._click_interaction_enabled() and not view['state'].attempt_active
                and self.next_attempt_sent_used==node.used and self.next_attempt_wait_at is not None
                and self.next_attempt_click_tries>=3 and time.monotonic()-self.next_attempt_wait_at>3
                and not self._net_view()['state'].attempt_active):
                self._arm_view_recovery(now)
                self.say('Следующая попытка не началась: меняю точки клика и ракурс, сохраняя общий срок восстановления')
        return False

    def bridge_cmd(self,command):
        if self._click_interaction_enabled() and command in ('TAP_F','F_ON'):return False
        release=command in ('STOP','F_OFF','ALT_UP')
        if not release and (self.stop_event.is_set() or not self.screen.focused()):return False
        if self.network is not None and command not in ('STOP','F_OFF','ALT_UP','PING','END_AIR'):
            view=self._net_view()
            if not view['ready']:return False
            if command=='F_ON' and not self._net_gather_proof():return False
            if command=='TAP_F' and self.network_target is None:return False
            if command=='ATTACK_PAIR' and not self._net_selected_aggressor():return False
        if command=='TAP_F' and self.next_attempt_pending is None and (not self.route_f_pending or self.route_f_sent and not self.wing_route_restart_authorized):
            self.say('TAP_F заблокирован: один F для выбранного ресурса уже отправлен либо нет нового выбора');return False
        if command=='F_ON' and not (self.target_confirmed and self.real_gather_panel_seen):
            self.say('F_ON заблокирован: нижняя плашка этого ресурса ещё не подтверждена');return False
        if command in ('V','END_AIR') and not self._wing_action_allowed(command):return False
        if command=='TAP_F' and self.next_attempt_pending is not None:
            if not self._net_next_attempt_ready():return False
            if hasattr(self.bridge,'send_guarded'):return self.bridge.send_guarded(command,self._net_next_attempt_ready)
            return self.bridge.send(command) is not False
        if hasattr(self.bridge,'send_guarded') and (command=='V' or command=='TAP_F' and self.wing_route_restart_authorized):
            if command=='V':authorize=self._wing_send_still_allowed
            else:authorize=lambda:self._wing_restart_ready() and (self.network is None or self._resource_route_still_valid())
            return self.bridge.send_guarded(command,authorize)
        if self.network is not None and hasattr(self.bridge,'send_guarded'):
            if command=='END_AIR':return self.bridge.send_guarded(command,self._end_air_still_allowed)
            if command=='TAP_F':return self.bridge.send_guarded(command,self._resource_route_still_valid)
            if command=='F_ON':return self.bridge.send_guarded(command,self._net_gather_proof)
            if command=='ATTACK_PAIR':return self.bridge.send_guarded(command,self._net_selected_aggressor)
        return self.bridge.send(command) is not False

    def _end_air_still_allowed(self):
        if not self._focus_ok():return False
        view=self._net_view()
        if not view or not view['ready']:return False
        if self.abandoning_binding is not None:return self._can_abandon_resource()
        if self.network_exhausted:
            node=self._net_node(view)
            return bool(node and (node.used==3 or not node.visible and node.removed_reason==4))
        return self._own_collection(view) is None and not view['state'].attempt_active

    def _resource_route_still_valid(self):
        view=self._net_view()
        return bool(self._focus_ok() and view and view['ready'] and self.network_target
                    and view['flow']==self.network_target[0] and view['state'].selected==self.network_target[1]
                    and self._selected_resource(view,self.target)
                    and self._own_collection(view) is None and not self._urgent_damage_pending())

    def _net_next_attempt_ready(self):
        view=self._net_view();node=self._net_node(view)
        return bool(self._focus_ok() and self._net_gather_proof() and node
                    and self.next_attempt_pending in (1,2) and node.used==self.next_attempt_pending
                    and (self._next_click_due(node.used) if self._click_interaction_enabled() else self.next_attempt_sent_used!=node.used)
                    and not view['state'].attempt_active
                    and not self._urgent_damage_pending())

    def _wing_send_still_allowed(self):
        # Keep the final-strobe check fast: full distance OCR was checked
        # before encoding; only current collection/flight can revoke this V.
        if (not self._focus_ok() or self.real_gather_panel_seen
            or self.network is not None and self._net_gather_proof()):return False
        frame,_=self.screen.frame()
        return not (self._gather_panel(frame) or read_flight(frame).confirmed)

    def _wing_action_allowed(self,command,announce=True):
        if command=='END_AIR' and self.abandoning_binding is not None:return self._can_abandon_resource()
        # Exhaustion is tied to THIS claimed actor/flow by _net_resource.
        # Do not launch several OCR passes before releasing a depleted node.
        if command=='END_AIR' and self.network_exhausted:
            if announce:self.say('Крылья END_AIR: собственный ресурс израсходован по сети; OCR не требуется')
            return True
        if command=='V' and self.network is not None and self._own_collection() is not None:return False
        frame,_=self.screen.frame()
        panel=self._gather_panel(frame)
        header=segment_count(frame) is not None or resource_header_visible(frame)
        started=self.target_confirmed and (self.fast_gather_seen or self.mode=='GATHER')
        near=False
        if command=='V' and self.target_confirmed and header and not started:
            distance=(self.distance_live if self.distance_live_at is not None and time.monotonic()-self.distance_live_at<2 else None) if self.network is not None else read_target_distance(frame)
            if distance is None and self.network is None:
                name,distance=selected_target(frame,tuple(self.cfg['target_names']),require_track=False)
                near=name==self.target and distance is not None and distance<=3
            else:near=distance is not None and distance<=3
        title_alive=False
        if command=='END_AIR' and started and not panel and not header:
            name,_=selected_target(frame,tuple(self.cfg['target_names']),require_track=False)
            title_alive=name==self.target
        already_air=command=='V' and read_flight(frame).confirmed
        blocked=already_air or panel or near or (started and (command=='V' or header or title_alive))
        if command=='END_AIR' and self.network_exhausted:blocked=False
        if blocked:
            now=time.monotonic()
            if now-self.wing_block_note>2:
                self.say(f'Блокировка {command}: ресурс={self.target}, сбор={started}, нижняя плашка={panel}, верхняя={header}')
                self.wing_block_note=now
            return False
        if announce:self.say(f'Крылья {command}: ресурс={self.target}, режим={self.mode}, нижняя плашка={panel}, верхняя={header}')
        return True

    def _accept_gather_panel(self,frame):
        if self.network is not None and not self._net_gather_proof():return False
        if not self.target_confirmed or not self._gather_panel(frame):return False
        self.real_gather_panel_seen=True;self.route_f_sent=True;self.wing_route_restart_pending=False
        self.f_repeat_allowed=True;self.route_active=False
        self.save_debug(frame,'first_gather_panel')
        self.say('ПЕРВАЯ нижняя плашка Успех/Неудача подтверждена: повтор F разрешён до исчезновения этого таргета')
        return True

    def f_enable(self):
        # Only an actual paired lower panel can grant repeats for THIS target.
        # Once seen, its permission survives the gaps between attempts.
        if not self.target_confirmed:return False
        if not self.real_gather_panel_seen:
            frame,_=self.screen.frame()
            if not self._accept_gather_panel(frame):return False
        if self.network is not None:
            # No background F timer. One completed attempt grants ONE request
            # for the next attempt; its pending native path must not be toggled.
            view=self._net_view();node=self._net_node(view)
            if node is None or not self._net_gather_proof():return False
            if not self.f_on:self.say('Сбор подтверждён: следующая попытка запускается после окончания текущей, без таймера взаимодействия')
            self.f_on=True
            self.network_managed_f=True
            if view['state'].attempt_active:
                self.next_attempt_wait_at=None;self.ether_click_index=0
            elif node.used in (1,2) and (self._next_click_due(node.used) if self._click_interaction_enabled() else self.next_attempt_sent_used!=node.used):
                self.next_attempt_pending=node.used
                try:
                    sent=(self._activate_resource_click(next_attempt=True) if self._click_interaction_enabled() else self.bridge_cmd('TAP_F'))
                    if sent:
                        self.next_attempt_sent_used=node.used;self.next_attempt_wait_at=time.monotonic()
                        self.say(f'Попытка завершена ({node.used}/3): '+(f'клик {self.next_attempt_click_tries}/3; при ожидании можно повторить клик, он не отменяет путь' if self._click_interaction_enabled() else 'один F для следующей; F до нового события не повторяю'))
                finally:self.next_attempt_pending=None
            return self.f_on
        now=time.monotonic()
        if not self.f_on and self.bridge_cmd('F_ON'):
            first=not self.f_on
            self.f_on=True;self.f_renewed_at=time.monotonic()
            if first:self.say('F включено после начала сбора: повтор между попытками этого ресурса')
        return self.f_on

    def f_disable(self):
        if self.f_on:
            if not self.network_managed_f:self.bridge_cmd('F_OFF')
            self.f_on=False
        self.network_managed_f=False

    def save_debug(self,frame,label):
        if self.cfg.get('debug_screenshots'):
            self.screenshot_path.mkdir(exist_ok=True)
            # Preserve full resolution: the old 1280 resize damaged short Ether text.
            cv2.imwrite(str(self.screenshot_path/(time.strftime('%H%M%S')+'_'+label+'.jpg')),frame,[cv2.IMWRITE_JPEG_QUALITY,94])

    def _release_inputs(self):
        try:self.bridge.send('STOP');self.bridge.restore_locks()
        except Exception as exc:self.emit('Ошибка освобождения Lua: '+str(exc))

    def stop(self):
        self.stop_event.set()
        self._stop_defense_motion()
        if self.gamepad:self.gamepad.reset()
        with self.release_lock:
            if self.release_thread is None:
                self.release_thread=threading.Thread(target=self._release_inputs,daemon=True)
                self.release_thread.start()

    def silence(self):self.cap_alarm.stop();self.death_alarm.stop()

    def trigger_alarm(self,kind,frame):
        with self.alert_lock:
            if self.alert is not None or self.stop_event.is_set():return
            self.alert=kind
        self.stop();self.save_debug(frame,kind.lower())
        self.say('ТРЕВОГА '+kind+' — остановлено, требуется ручное продолжение')
        alarm=self.cap_alarm if kind=='CAPTCHA' else self.death_alarm
        try:alarm.start(self.cfg.get('audio_device','AG271QG4'),error_cb=self.emit)
        except Exception as exc:self.emit('Ошибка звука: '+str(exc))

    def _dialog_loop(self,kind,detector,interval):
        hits=0
        while not self.stop_event.is_set():
            if self.screen.focused():
                try:
                    frame,_=self.screen.frame();present,_=detector.check(frame)
                    hits=hits+1 if present else 0
                    if hits>=2:self.trigger_alarm(kind,frame);return
                except Exception as exc:self.emit(kind+' / проверка: '+str(exc));hits=0
            else:hits=0
            if self.stop_event.wait(interval):return

    def _heartbeat_loop(self):
        while not self.stop_event.is_set():
            try:
                if self._focus_ok():self.bridge.ping_if_idle()
            except Exception as exc:self.emit('Ошибка heartbeat: '+str(exc));self.stop();return
            if self.stop_event.wait(2):return

    def _vision_names(self):
        if self.mode=='REACQUIRE' and self.target in self.cfg['target_names']:
            return (self.target,)
        return self.policy.names(self.cfg['target_names'])

    def _vision_loop(self):
        failures=0
        while not self.stop_event.is_set():
            if self.map_active:
                if self.stop_event.wait(.1):return
                continue
            if not self.screen.focused():
                if self.stop_event.wait(.15):return
                continue
            try:
                captured=time.monotonic();frame,_=self.screen.frame()
                if self.network is not None and self.mode in ('ACQUIRE','VERIFY_NATIVE'):
                    before=self._net_view()
                    name=selected_resource_name(frame,self.cfg['target_names']);distance=read_target_distance(frame) if self.mode=='VERIFY_NATIVE' else None
                    after=self._net_view()
                    if (name and before and after and before['ready'] and after['ready']
                        and before['flow']==after['flow'] and before['state'].selected==after['state'].selected):
                        self.visual_selection=(after['flow'],after['state'].selected,name,captured)
                    obs=Observation(None,name,distance,False,0,False,None,'HIDDEN')
                elif self.network is not None and self.target_confirmed:
                    # Network already supplies the resource identity. Read only
                    # distance in this worker; no synchronous OCR in approach.
                    distance=read_target_distance(frame) if not self.real_gather_panel_seen else None
                    if self.target==OWN_RESOURCE:
                        before=self._net_view();owned=self._own_collection(before)
                        name=selected_resource_name(frame,self.cfg['target_names']) if owned else None
                        after=self._net_view();current=self._own_collection(after)
                        if name and owned and current and before['flow']==after['flow'] and owned.actor==current.actor:
                            self.visual_selection=(after['flow'],current.actor,name,captured)
                    candidate=None
                    if (self._click_interaction_enabled() and self.target!=OWN_RESOURCE and not self.camera_in_progress
                        and (self.mode=='GATHER' or not self.route_f_sent or self.mode=='TAKEOFF'
                             or self.mode=='APPROACH' and time.monotonic()-self.last_progress>=2)):
                        candidate=find_world_resource(frame,(self.target,))
                    obs=Observation(candidate,self.target,distance,False,0,False,None,'HIDDEN')
                else:
                    obs=self.vision.scan(frame,candidates=self.mode in ('SEARCH','ACQUIRE_WAIT','REACQUIRE','PROBE') and not self.target_confirmed,target=self.network is None,names=self._vision_names())
                if obs.candidate and obs.candidate.name=='Эфир' and not self.budget.can_start() and self.mode in ('SEARCH','ACQUIRE_WAIT'):
                    names=tuple(n for n in self.cfg['target_names'] if n!='Эфир')
                    obs.candidate=find_world_resource(frame,names)
                with self.snapshot_lock:
                    completed=time.monotonic()
                    self.sequence+=1;self.snapshot=(obs,captured,self.sequence,completed)
                if completed-captured>3 and completed-self.ocr_wait_note>=5:
                    self.say(f'Медленный OCR: кадр обрабатывался {completed-captured:.2f} с; сетевой сбор и закрытие крыльев обслуживаются отдельно')
                    self.ocr_wait_note=completed
                failures=0
            except Exception as exc:
                failures+=1;self.emit('OCR / ошибка: '+str(exc))
                if failures>=3:self.stop();return
            if self.stop_event.wait(.08):return

    def _health_fast_loop(self):
        while not self.stop_event.is_set():
            if self.network is None and self.cfg.get('protect_player',True) and self.screen.focused() and not self.map_active:
                try:
                    frame,_=self.screen.frame();self.health.fast(frame,time.monotonic())
                except Exception:pass
            if self.stop_event.wait(max(.02,min(.05,self.cfg.get('hp_fast_seconds',.05)))):return

    def _health_numeric_loop(self):
        last_error=0
        while not self.stop_event.is_set():
            if self.network is None and self.cfg.get('protect_player',True) and self.screen.focused() and not self.map_active:
                try:
                    suspect=self.health.take_suspect()
                    if suspect is None:
                        frame,_=self.screen.frame();captured=time.monotonic()
                    else:frame,captured=suspect
                    value=read_hp(frame,self.cfg.get('hp_roi'));verified=False
                    if value is not None and value.current<value.maximum:
                        other=read_hp(frame,self.cfg.get('hp_roi'),alternate=True)
                        verified=(other is not None and other.current==value.current and other.maximum==value.maximum)
                    previous=self.health.state()['damage_sequence']
                    self.health.numeric(frame,value,captured,verified=verified)
                    if self.health.state()['damage_sequence']>previous:
                        self.say(f'HP подтверждено двумя вариантами OCR: {value.current}/{value.maximum}')
                except Exception as exc:
                    if time.monotonic()-last_error>10:self.say('HP OCR: '+str(exc));last_error=time.monotonic()
            self.health.suspect_ready.wait(max(.10,min(.20,self.cfg.get('hp_ocr_seconds',.20))))

    def _focus_ok(self):return not self.stop_event.is_set() and self.screen.focused()

    def _reset_resource_watch(self,verified_header=False):
        self.click_wait_since=None;self.click_retry_at=0;self.route_click_tries=0;self.route_click_sent_at=None;self.ether_click_index=0
        self.fast_header_seen=verified_header;self.fast_last_slots=None;self.fast_gather_seen=False
        self.fast_absent_since=None;self.last_flight_seen_at=None;self.last_flight_energy=None
        self.arrival_camera_corrected=False
        self.panel_last_seen=None;self.repeat_rearmed=False;self.collection_activity_at=None
        self.f_repeat_allowed=False;self.route_active=False;self.last_path_motion=None
        self.real_gather_panel_seen=False;self.route_f_sent=False;self.route_f_pending=False
        self.wing_route_restart_pending=False;self.wing_route_restart_authorized=False;self.native_route_started_at=None
        self.distance_check_at=0;self.distance_live=None;self.distance_live_at=None;self.approach_recovery_at=0
        self.network_target=None;self.network_claimed_at=0;self.network_owner=None;self.network_slots_seen=None
        self.next_attempt_pending=None;self.next_attempt_sent_used=None;self.next_attempt_wait_at=None;self.next_attempt_click_tries=0

    def _wing_restart_ready(self):
        if (not self._focus_ok() or not self.target_confirmed or not self.wing_route_restart_pending
            or self.mode!='TAKEOFF' or self.real_gather_panel_seen or self.fast_gather_seen):return False
        frame,_=self.screen.frame()
        return not (self._gather_panel(frame)) and read_flight(frame).confirmed

    def _next_click_due(self,used):
        if self.next_attempt_sent_used!=used:return True
        return (self.next_attempt_wait_at is not None and self.next_attempt_click_tries<3
                and time.monotonic()-self.next_attempt_wait_at>=2)

    def _click_interaction_enabled(self):
        return self.network is not None and self.cfg.get('resource_click_interaction',True)

    def _defer_route_defense(self,now):
        if self.mode=='VERIFY_NATIVE' and self.visual_route is not None:
            distance=self.visual_route['distance']
            return distance is None or distance>self.cfg.get('defense_arrival_distance',10)
        if (self.cfg.get('defense_during_approach',False) or not self.target_confirmed
            or self.real_gather_panel_seen or self.mode not in ('APPROACH','TAKEOFF','JUMP_RETRY')):return False
        view=self._net_view()
        if view and view['ready'] and view['state'].attempt_active and self.network_target and view['state'].collecting==self.network_target[1]:return False
        relative=geometry(view['state'],self._net_node(view)) if view and view['ready'] else None
        distance=relative['distance_m'] if relative else None
        if distance is None and self.distance_live_at is not None and 0<=now-self.distance_live_at<=2:
            distance=self.distance_live
        if distance is None:
            with self.snapshot_lock:snapshot=self.snapshot
            if (snapshot is not None and 0<=now-snapshot[1]<=2 and snapshot[1]>=self.identity_valid_after
                and snapshot[0].target_name==self.target):distance=snapshot[0].distance_m
        # No HP threshold: intercept the confirmed attacker before arrival.
        # If distance is unavailable, allow only a short travel grace period.
        if distance is None:
            return self.native_route_started_at is not None and now-self.native_route_started_at<3
        return distance>self.cfg.get('defense_arrival_distance',10)

    def _click_ready(self,binding,next_attempt,reserved=False):
        view=self._net_view();node=self._net_node(view)
        if (not self._focus_ok() or self.camera_in_progress or self.network_target!=binding
            or not view or not view['ready'] or view['flow']!=binding[0] or node is None
            or not node.visible or node.used==3 or view['state'].selected not in (0,binding[1])
            or self.network_owner is not None and view['state'].own!=self.network_owner
            or self._urgent_damage_pending() or view['state'].attempt_active):return False
        if next_attempt:
            if reserved:return self._net_gather_proof() and node.used==self.next_attempt_pending
            return self._net_next_attempt_ready()
        return self.target_confirmed and self.route_f_pending and not self._net_gather_proof()

    def _fresh_click_candidate(self,frame):
        # A fresh local glyph is cheap. Full OCR runs only in the vision worker.
        previous=self.candidate
        if previous is not None and previous.name==self.target and previous.glyph is not None:
            fresh=find_resource_near(frame,previous)
            if fresh is not None:
                # Keep the hitbox offset that actually selected this actor.
                return replace(fresh,click_x=fresh.box[0]+previous.click_x-previous.box[0],
                               click_y=fresh.box[1]+previous.click_y-previous.box[1])
        with self.snapshot_lock:snapshot=self.snapshot
        now=time.monotonic()
        if (snapshot is not None and 0<=now-snapshot[1]<=2.5 and snapshot[1]>=self.identity_valid_after
            and snapshot[0].candidate is not None and snapshot[0].candidate.name==self.target
            and snapshot[0].candidate.glyph is not None):
            return find_resource_near(frame,snapshot[0].candidate)
        return None

    def _activate_resource_click(self,next_attempt=False,optional_repeat=False):
        binding=self.network_target
        if binding is None or self.click_busy or time.monotonic()<self.click_retry_at:return False
        if not self._click_ready(binding,next_attempt):return False
        self.click_busy=True
        attempted=False;opened_alt=not self.bridge.alt_is_down()
        try:
            self._neutral()
            if opened_alt:self.bridge_cmd('ALT_DOWN')
            if not self._wait_alt_state(True):return False
            frame,origin=self.screen.frame();candidate=self._fresh_click_candidate(frame)
            if candidate is None:return False
            if not self._click_ready(binding,next_attempt):return False
            self.bridge.cursor(origin[0]+int(candidate.click_x),origin[1]+int(candidate.click_y))
            if not GamepadInput.wait(.10,self.stop_event,self.screen.focused):return False
            if not self._wait_alt_state(True) or not self._click_ready(binding,next_attempt):return False
            # Selection may clear normally between attempts. First select,
            # verify EXACT actor ID, then activate; never double-click blindly.
            if self._net_view()['state'].selected==0:
                if not self.gamepad.tap_a(self.stop_event,self.screen.focused):return False
                until=time.monotonic()+.65
                while self._focus_ok():
                    view=self._net_view()
                    if not view or not view['ready'] or view['flow']!=binding[0]:return False
                    if view['state'].selected==binding[1]:break
                    if view['state'].selected or time.monotonic()>=until:return False
                    if not GamepadInput.wait(.03,self.stop_event,self.screen.focused):return False
                # A can already have started an owned attempt; do not activate twice.
                if self._net_view()['state'].attempt_active:return True
                if not self._click_ready(binding,next_attempt):return False
            if self._net_view()['state'].selected!=binding[1]:return False
            # Reserve the request BEFORE pressing A. A partial delivery must
            # not be retried as though no input had reached the game.
            burst=3 if candidate.name=='Эфир' else 1
            sent=0;tried_offsets=set()
            for index in range(burst):
                if index:
                    if not GamepadInput.wait(.08,self.stop_event,self.screen.focused):break
                    if not self._click_ready(binding,next_attempt,reserved=attempted):break
                    frame,origin=self.screen.frame();fresh=self._fresh_click_candidate(frame)
                    if fresh is None:break
                    candidate=fresh
                if candidate.name=='Эфир':
                    points=ether_click_points(candidate,frame.shape[1],frame.shape[0])
                    cx=round(candidate.box[0]+candidate.box[2]/2);bottom=round(candidate.box[1]+candidate.box[3])
                    for _ in range(len(points)):
                        px,py=points[self.ether_click_index%len(points)];self.ether_click_index+=1
                        offset=(px-cx,py-bottom)
                        if offset not in tried_offsets:break
                    tried_offsets.add(offset)
                    candidate=replace(candidate,click_x=px,click_y=py)
                    self.bridge.cursor(origin[0]+px,origin[1]+py)
                    if not GamepadInput.wait(.06,self.stop_event,self.screen.focused):break
                    # The target can move on screen during native flight.
                    # Re-anchor after cursor settling, immediately before A.
                    frame,origin=self.screen.frame();probe=find_resource_near(frame,candidate)
                    if probe is None:break
                    px+=probe.box[0]-candidate.box[0];py+=probe.box[1]-candidate.box[1]
                    candidate=replace(probe,click_x=px,click_y=py)
                    self.bridge.cursor(origin[0]+int(px),origin[1]+int(py))
                if not self._wait_alt_state(True) or not self._click_ready(binding,next_attempt,reserved=attempted):break
                # Any changed ID ends the burst. One caption must never
                # activate a neighbouring resource/NPC after a miss.
                if self._net_view()['state'].selected!=binding[1]:break
                if not attempted:
                    attempted=True
                    if next_attempt:
                        if self.next_attempt_sent_used!=self.next_attempt_pending:self.next_attempt_click_tries=0
                        self.next_attempt_click_tries+=1
                        self.next_attempt_sent_used=self.next_attempt_pending;self.next_attempt_wait_at=time.monotonic()
                    else:
                        self.route_click_tries+=1;self.route_click_sent_at=time.monotonic()
                        self.route_f_sent=True;self.route_active=True
                        if self.native_route_started_at is None:self.native_route_started_at=time.monotonic()
                self.candidate=candidate
                if not self.gamepad.tap_a(self.stop_event,self.screen.focused):
                    self.halt_reason='Клик начат, но отпускание/фокус не подтверждены';self.stop();return False
                sent+=1
            if sent:self.click_wait_since=None
            self.say(f'CLICK_RESOURCE: ID={binding[1]}, '+('следующая попытка' if next_attempt else 'запуск/повтор пути')+f'; кликов {sent}; контекстный F не используется')
            return bool(sent or self._own_collection() is not None)
        finally:
            if opened_alt:
                self.bridge_cmd('ALT_UP')
                if self._focus_ok():self._wait_alt_state(False)
            self.click_busy=False
            self.click_retry_at=time.monotonic()+.35
            if not attempted and not optional_repeat and self._focus_ok():
                now=time.monotonic()
                if self.click_wait_since is None:self.click_wait_since=now
                elif now-self.click_wait_since>6:
                    self._begin_reacquire('Нет свежей точки ресурса для клика: возвращаю сохранённый ID вместо ожидания в воздухе')

    def _start_resource_route(self,restart_after_wings=False,repeat_click=False):
        if self.network is not None and self.target_confirmed and self._net_gather_proof():
            frame,_=self.screen.frame();self._net_resource(frame,read_flight(frame),time.monotonic());return True
        if not self.target_confirmed or self.fast_gather_seen or self.collecting_visible or not self._focus_ok():return False
        if restart_after_wings:
            if not self._wing_restart_ready():return False
        elif self.route_f_sent or self.route_active:
            if not (repeat_click and self._click_interaction_enabled() and self.route_click_tries<3):return False
        if repeat_click and not self._click_interaction_enabled():return False
        if restart_after_wings:self.route_click_tries=0
        self.f_disable();self.f_repeat_allowed=False
        self.route_f_pending=True;self.wing_route_restart_authorized=restart_after_wings
        try:
            if self._click_interaction_enabled():
                if not self._activate_resource_click(optional_repeat=repeat_click):return False
            elif not self.bridge_cmd('TAP_F'):return False
        finally:
            self.route_f_pending=False;self.wing_route_restart_authorized=False
        self.route_f_sent=True;self.route_active=True;self.wing_route_restart_pending=False;self.view_click_pending=False
        if not repeat_click:self.native_route_started_at=time.monotonic()
        action='Клик по выбранному ресурсу' if self._click_interaction_enabled() else 'Один F'
        self.say(action+(' после подтверждённого V: автопуть перезапущен' if restart_after_wings else ': штатный путь запущен')+('; при задержке допустим повтор клика' if self._click_interaction_enabled() else '; повтор до начала сбора запрещён'))
        return True

    def _check_route_damage(self,frame,now,panel=None,slots=None):
        if self.network is not None:return self._net_defense(now)
        resource=self.target_confirmed and self.target in self.cfg['target_names']
        roaming=(self.mode in ('SEARCH','ACQUIRE_WAIT') and self.cfg.get('ground_walk',True)
                 and self.probe is None and self.wing_close_pending is None)
        if (not self.cfg.get('protect_player',True) or not (resource or roaming)
            or self.mode not in ('SEARCH','ACQUIRE_WAIT','APPROACH','TAKEOFF','JUMP_RETRY','GATHER')
            or now<self.hp_next_defense or self.defense_cycles>=self.cfg.get('defense_max_cycles',6)
            or not self.health.pending(self.hp_handled_event,now)):return False
        if panel is None:panel=self._gather_panel(frame)
        if slots is None:slots=segment_count(frame)
        remaining=resource and (self.mode!='GATHER' or panel or slots is not None or resource_header_visible(frame))
        if resource and not remaining:
            name,_=selected_target(frame,tuple(self.cfg['target_names']),require_track=False)
            remaining=name==self.target
        state=self.health.state()
        if state['verified_at'] is None:return False
        self.say(f'Подтверждённое снижение HP во время {self.mode}: {state["damage_current"]}/{state["damage_maximum"]}, сейчас {state["current"]}/{state["maximum"]}; Tab и проверка агрессора')
        self._defend_and_resume(resume=remaining)
        return True

    def _service_wing_close(self,reading,now):
        if self.wing_close_pending is None:return False
        self._neutral()
        if self.wing_close_started is None:self.wing_close_started=self.wing_close_pending
        if now-self.wing_close_started>=6:
            self.say('За 6 с закрытие крыльев не подтверждено: остановка с явной ошибкой вместо ожидания');self.stop();return True
        if not reading.confirmed:
            if self.wing_absent_since is None:self.wing_absent_since=now
            if now-self.wing_absent_since>=.2:
                self.wing_close_pending=None;self.wing_close_started=None;self.resource_flight_owned=False
                self.say('Закрытие крыльев подтверждено отсутствием дуги');return False
            return True
        self.wing_absent_since=None
        elapsed=now-self.wing_close_pending
        if elapsed>=1.5 and self.wing_close_retries==0:
            # Retry only on a NEW still-visible flight arc, never blindly V.
            if self.bridge_cmd('END_AIR'):
                self.f_on=False;self.wing_close_retries=1;self.wing_close_pending=time.monotonic()
                self.say('Дуга всё ещё видна: один повтор закрытия крыльев')
        elif elapsed>=2.5 and self.wing_close_retries:
            self.say('Крылья всё ещё открыты после двух команд: остановка ввода вместо зависания');self.stop()
        return True

    def _resource_fast_tick(self,frame,reading,now,panel=None,slots=None):
        """Live resource UI must run even when OCR is slow or camera is moving."""
        self._adopt_network_collection()
        if self.mode=='VERIFY_NATIVE':return self._verify_visual_route(frame,reading,now)
        if self.network is not None:
            view=self._net_view();state=view['state'] if view and view['ready'] else None
            if (state and state.attempt_active and state.collecting is not None and state.started is not None
                and 0<=time.time()*1000-state.started<=2000 and self._own_collection(view) is None):
                self._neutral();return True
        if panel is None:panel=self._gather_panel(frame)
        if panel and not self.real_gather_panel_seen:panel=self._gather_panel(frame)
        if slots is None:slots=segment_count(frame)
        header=slots is not None or resource_header_visible(frame)
        if self.wing_close_pending is not None and (panel or self.target_confirmed and header):
            self.wing_close_pending=None;self.wing_close_retries=0;self.folded=False
            self.say('Плашка ресурса снова видна: отменён отложенный повтор закрытия крыльев')
        if self._service_wing_close(reading,now):return True
        if (self.network is not None and self.mode in ('SEARCH','ACQUIRE_WAIT')
            and not self.target_confirmed and self.probe is None and self.pending_probe is None
            and self.patrol_escape is None and reading.confirmed):
            view=self._net_view()
            if (view and view['ready'] and view['state'].collecting is None and not view['state'].attempt_active
                and not gathering_panel_pair(frame)):
                self._neutral()
                if self.bridge_cmd('END_AIR'):
                    self.f_on=False;self.resource_flight_owned=True
                    self.wing_close_pending=time.monotonic();self.wing_close_started=self.wing_close_pending
                    self.wing_close_retries=0;self.wing_absent_since=None
                    self.candidate=None;self.change_mode('SEARCH')
                    self.say('Крылья открыты вне сбора/манёвра: закрываю до ходьбы и выбора наземного ресурса')
                return True
        if self._view_recovery_tick(frame,reading,now):return True
        if self.mode=='REACQUIRE':
            self._neutral()
            if self.reacquire_until is not None and now>=self.reacquire_until:
                self.collecting_visible=False
                self.return_to_search('Повторный выбор ресурса не удался за 8 секунд: следующая цель',reading=reading)
                return True
            return False
        if (not self.target_confirmed or self.target not in self.cfg['target_names'] and self._net_node() is None
            or self.mode not in ('APPROACH','TAKEOFF','JUMP_RETRY','GATHER')):return False
        if self.network is None and enemy_hp(frame)[0]:
            self._begin_reacquire('Красная плашка вместо ресурса: выключаю F, повторно выбираю ресурс без Tab')
            return True
        if self._net_resource(frame,reading,now):return True
        if self.network is not None and self._net_gather_proof():
            node=self._net_node();slots=3-node.used;header=True
        self.collecting_visible=panel
        if reading.confirmed:
            self.last_flight_seen_at=now;self.last_flight_energy=reading.energy
            self.flight_attempted=True;self.resource_flight_owned=True
        if header:self.fast_header_seen=True
        if slots is not None:
            if self.real_gather_panel_seen and self.fast_last_slots is not None and slots<self.fast_last_slots:
                self.collection_activity_at=now
            self.fast_last_slots=slots
        paired=panel and not self.real_gather_panel_seen and self._accept_gather_panel(frame)
        valid_panel=panel and self.real_gather_panel_seen
        if not panel:self.panel_cleared=True
        if valid_panel:
            self.panel_last_seen=now;self.repeat_rearmed=False;self.collection_activity_at=now
            self.fast_gather_seen=True;self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
            self.f_enable()
        self.interrupts.update(valid_panel,slots,now,gather_result_full(frame) if valid_panel else None)
        if valid_panel or self.fast_gather_seen:
            self.probe=None;self.pending_probe=None
            if self.mode!='GATHER':
                self.change_mode('GATHER');self.missing_since=None
                self.say('Свежий кадр подтверждает сбор независимо от OCR дистанции')
        if self.network is not None and self._net_node() is not None:
            self.fast_absent_since=None;return False
        if panel or header:
            self.fast_absent_since=None;return False
        if not (self.fast_header_seen or self.fast_gather_seen or self.mode=='GATHER'):return False
        if self.fast_absent_since is None:self.fast_absent_since=now
        if now-self.fast_absent_since>=self.cfg.get('target_missing_seconds',.6):
            fresh,_=self.screen.frame()
            name,_=selected_target(fresh,tuple(self.cfg['target_names']),require_track=False)
            if name==self.target:
                self.fast_absent_since=None
                return False
            if name is not None:
                self._begin_reacquire('Свежая верхняя подпись сменилась: повторный выбор без закрытия крыльев')
                return True
            self.return_to_search('Свежий кадр: плашка/полоски и окно сбора исчезли',
                                  exhausted=True,reading=reading,frame_time=now)
            return True
        return False

    def _approach_fast_tick(self,frame,origin,reading,now):
        if (not self.target_confirmed or self.real_gather_panel_seen
            or self.mode not in ('APPROACH','TAKEOFF','JUMP_RETRY')):return False
        if self._gather_panel(frame):
            self._resource_fast_tick(frame,reading,now,panel=True);return True
        if self._click_interaction_enabled() and not self.route_f_sent:
            if self._start_resource_route():
                self.last_progress=now
                if self.resume_resource_id==self.network_target:self.resume_resource_id=None
            return True
        if (self.view_click_pending and self.view_recovery is not None
            and now>=self.view_recovery.settle_until and self._start_resource_route(repeat_click=True)):
            self.view_click_pending=False;return True
        if now>=self.distance_check_at:
            self.distance_check_at=now+.5
            view=self._net_view()
            relative=geometry(view['state'],self._net_node(view)) if view and view['ready'] else None
            if relative:value=relative['distance_m']
            elif self.network is None:value=read_target_distance(frame)
            else:
                with self.snapshot_lock:snapshot=self.snapshot
                valid=(snapshot is not None and now-snapshot[1]<=2 and snapshot[1]>=self.identity_valid_after
                       and snapshot[0].target_name==self.target)
                value=snapshot[0].distance_m if valid else None
            if relative and now-self.approach_note_at>2:
                self.say(f'Свежие XYZ: до ресурса {value:.1f} м, по высоте {relative["height_m"]:+.1f} м, возраст {relative["age"]:.2f} с')
            if value is not None:
                self.distance_live=value;self.distance_live_at=now
                if self.last_distance is None or value<self.last_distance-.3:
                    self.last_distance=value;self.last_progress=now
        distance=self.distance_live if self.distance_live_at is not None and now-self.distance_live_at<2 else self.last_distance
        if self.mode=='TAKEOFF':
            if reading.confirmed:
                if self._start_resource_route(restart_after_wings=True):
                    self.last_progress=now;self.change_mode('APPROACH')
            elif now-self.started>3.5:
                self.budget.failed_takeoff(now)
                self.return_to_search('Крылья не подтвердились: повтор V не отправляю',reading=reading)
            return True
        if self.mode=='JUMP_RETRY':
            if now-self.started>1.5:self.last_progress=now;self.change_mode('APPROACH')
            return True
        route_since=self.native_route_started_at if self.native_route_started_at is not None else self.started
        stalled=now-self.last_progress
        if now-self.approach_note_at>2:
            self.say(f'Контроль подхода: {distance} м, без сближения {stalled:.1f} с; нижней плашки ещё не было; '+self.budget.describe(now))
            self.approach_note_at=now
        if (self._click_interaction_enabled() and stalled>=2 and self.route_click_tries<3
            and self.route_click_sent_at is not None and now-self.route_click_sent_at>=2):
            if self._start_resource_route(repeat_click=True):
                self.say('Нет сближения: повторил безопасный клик по тому же ресурсу; таймер застревания сохранён')
                return True
        if now-route_since>max(60,self.cfg.get('approach_timeout',60)):
            self.return_to_search('Таймаут штатного подхода',reading=reading);return True
        threshold=max(1,self.cfg.get('approach_stall_seconds',6))
        if distance is not None and distance>6:threshold=max(12,threshold*2)
        due=(distance is not None and distance>3 and stalled>=threshold
             or now-route_since>=10 and stalled>2)
        if due and now>=self.approach_recovery_at:
            self.approach_recovery_at=now+1
            current=Observation(None,self.target,distance,False,0,False,None,'HIDDEN')
            self._recover(frame,origin,current,reading,now)
            return True
        return False

    def _patrol_escape_tick(self,frame,reading,now):
        if self.patrol_escape is None:return False
        if self.target_confirmed or self._gather_panel(frame):
            self._neutral();self.say('Сбор/выбор ресурса во время выхода: остановка манёвра без V');self.stop();return True
        action=self.patrol_escape.step(now,reading)
        if action.failed_takeoff:self.budget.failed_takeoff(now)
        if action.command:
            self._neutral()
            if not self.bridge_cmd(action.command):
                self.say('Манёвр отменён проверкой свежего кадра');self.patrol_escape=None;self.change_mode('SEARCH');return True
            if action.command=='END_AIR':self.f_on=False
        elif action.drive:self._motion(action.drive)
        else:self._neutral()
        if action.stop:self.say(action.reason);self.stop();return True
        if action.done:
            self.say(action.reason);self.patrol_escape=None;self.change_mode('SEARCH')
            self.nav.pause(now);self.patrol_stall.reset(now)
        elif action.command:self.say(action.reason)
        return True

    def _check_world_map(self):
        self._neutral();self.f_disable();self.map_active=True
        try:
            frame,_=self.screen.frame();fix=self.region.locate(frame)
            if fix is None:
                if not self.bridge_cmd('MAP'):return
                if not GamepadInput.wait(.65,self.stop_event,self.screen.focused):return
                frame,_=self.screen.frame();fix=self.region.locate(frame)
            if fix is None:
                self.say('Карта/стрелка не подтверждена: остановка. Проверьте M, новый Lua v0.5 и эталон зоны; закройте карту вручную.')
                self.stop();return
            if not self.bridge_cmd('MAP'):return
            if not GamepadInput.wait(.55,self.stop_event,self.screen.focused):return
            frame,_=self.screen.frame()
            if self.region.matcher.register(frame) is not None:
                self.say('Большая карта осталась открытой: остановка ввода, закройте M вручную.')
                self.stop();return
            distance=((fix.goal[0]-fix.position[0])**2+(fix.goal[1]-fix.position[1])**2)**.5
            interval=min(4 if fix.outside else self.cfg.get('world_map_check_seconds',12),max(1.5,distance/30))
            self.region.next_check=time.monotonic()+interval
            bearing=fix.bearing if self.region.spec.get('north_up',True) else None
            self.nav.route(bearing,'возврат в зону по карте' if fix.outside else 'точка маршрута по карте',fix.outside or bearing is None)
            self.say(f'Карта: положение ({fix.position[0]:.0f},{fix.position[1]:.0f}), персонаж {fix.character_heading:.0f}°, '+
                     ('снаружи, возвращаюсь в зону' if fix.outside else 'внутри зоны, продолжаю маршрут'))
            self.minimap.previous=None;self.minimap.previous_points=None
            self.identity_valid_after=time.monotonic()
            with self.snapshot_lock:self.snapshot=None
        finally:
            self.map_active=False;self.nav.pause(time.monotonic())

    def _motion(self,plan):
        if self.cfg.get('dry_run'):return
        if self.gamepad and self._focus_ok():
            if self.network is not None:
                view=self._net_view()
                if (not view or not view['ready'] or self._own_collection(view) is not None
                    or view['state'].attempt_active and view['state'].collecting is not None):
                    self._neutral();return
            if self.collecting_visible or (self.resource_hold and self.mode=='GATHER'):
                if any(abs(v)>.01 for v in (plan.forward,plan.strafe,plan.yaw,plan.pitch)) and time.monotonic()-self.last_hold_note>2:
                    self.say('Блокировка: окно/режим сбора запрещает команды стиков');self.last_hold_note=time.monotonic()
                self._neutral();return
            if self.resource_hold:
                plan=replace(plan,forward=0,strafe=0,yaw=0)
            if (not plan.tilted_motion and math.hypot(plan.forward,plan.strafe)>.01
                and abs(self.pitch.offset(time.monotonic()))>.009):
                self._neutral();self._restore_pitch();return
            self.gamepad.drive(plan.forward,plan.strafe,plan.yaw,plan.pitch,lifetime=plan.lifetime,yaw_lifetime=plan.yaw_lifetime)
            if (abs(plan.pitch)>.01 and not self.pitch.returning
                and self.mode in ('SEARCH','ACQUIRE_WAIT','PROBE')):
                self.camera_search_revision+=1
            if not self.pitch_observed:self.pitch.apply(plan.pitch,time.monotonic(),plan.lifetime)
            return True

    def _neutral(self):
        if self.gamepad:self.gamepad.reset()
        self.pitch.neutral(time.monotonic())

    def _restore_pitch(self):
        self.nav.air_since=None;self.nav.scan_kind=None
        self.pitch.restore(time.monotonic())

    def _request_probe(self,now):
        self._neutral()
        if (self.nav.goal is None or not self.cfg.get('flight_probe_enabled',True)
            or not self.cfg.get('ground_walk',True) or not self.cfg.get('camera_scan',True)
            or not self.budget.can_probe(self.cfg.get('flight_probe_min_percent',18))):
            self.nav.abandon_goal(now,60);self._restore_pitch();return
        self.pending_probe=self.nav.goal
        self._restore_pitch()

    def _probe_step(self,frame,origin,obs,radar,reading,now):
        probe=self.probe
        if probe is None:return
        if self.collecting_visible:
            self._neutral()
            if obs.target_name in self.cfg['target_names']:
                self.target=obs.target_name;self.target_confirmed=True;self.resource_hold=True
                self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                self.probe=None;self.change_mode('GATHER');self.f_enable();self._restore_pitch()
            else:
                if not hasattr(probe,'panel_since'):probe.panel_since=now
                if now-probe.panel_since>5:
                    self.say('Окно сбора видно, но имя не подтверждено: остановка без движения');self.stop()
            return
        if radar.motion_valid:
            probe.goal.x+=radar.displacement[0];probe.goal.y+=radar.displacement[1]
        matches=[m for m in radar.markers if m.kind==probe.goal.kind and math.hypot(m.x-probe.goal.x,m.y-probe.goal.y)<35]
        if matches:probe.goal=min(matches,key=lambda m:math.hypot(m.x-probe.goal.x,m.y-probe.goal.y))
        if (probe.phase not in ('CLOSE','WAIT_CLOSE') and obs.candidate
            and self._allowed(obs.candidate,now)):
            if obs.candidate.name!='Эфир' and reading.confirmed:
                probe.ground_candidate=obs.candidate
                self._neutral();probe.phase_to('CLOSE',now)
                self.say('Наземный ресурс найден после подъёма: сначала завершаю пробный полёт, затем выбираю ресурс')
                return
            self._neutral()
            if self.click_candidate(obs.candidate,origin):
                self.probe=None;self.pending_probe=None;return
            self.target_confirmed=False;self.resource_hold=False;probe.phase_to('CLOSE',now)
            self.change_mode('PROBE')
        desired=math.degrees(math.atan2(probe.goal.x-radar.center[0],radar.center[1]-probe.goal.y))%360
        heading=self.nav._heading(radar,now)
        if math.hypot(probe.goal.x-radar.center[0],probe.goal.y-radar.center[1])<5:desired=heading if heading is not None else desired
        action=probe.step(now,reading,self.pitch.offset(time.monotonic()),heading,desired)
        if action.failed_takeoff:self.budget.failed_takeoff(now)
        if action.command:
            self._neutral();self.bridge_cmd(action.command)
            if action.command=='END_AIR':self.f_on=False
        elif action.drive:self._motion(action.drive)
        else:self._neutral()
        if action.stop:
            self.say(action.reason);self.stop();return
        if action.done:
            ground=getattr(probe,'ground_candidate',None)
            if ground is not None:
                fresh=find_resource_near(frame,ground)
                self.probe=None;self.pending_probe=None;self.change_mode('SEARCH')
                if fresh is not None:
                    self.say('Крылья закрыты: выбираю наземный ресурс, найденный во время подъёма')
                    if not self.click_candidate(fresh,origin):self._acquire_miss(fresh,time.monotonic())
                    return
            self.say(action.reason+'; закрытие/возврат наклона, затем отход')
            self.nav.goal=probe.goal;self.nav.abandon_goal(now,60)
            self.probe=None;self.pending_probe=None;self.target=None;self.target_confirmed=False;self.resource_hold=False
            self.change_mode('SEARCH');self._restore_pitch()
        elif action.reason and now-self.last_note>.7:
            self.say(action.reason);self.last_note=now

    def _allowed(self,candidate,now):
        if candidate.name not in self.cfg['target_names']:return False
        if not self.policy.allows(candidate.name):return False
        if candidate.name=='Эфир' and not self.budget.can_start():
            if now-self.last_energy_note>4:
                self.say(self.budget.describe(now)+'; эфир отложен, ищу доступный наземный ресурс')
                self.last_energy_note=now
            return False
        self.cooldowns=[p for p in self.cooldowns if p[3]>now]
        return not any(n==candidate.name and abs(candidate.click_x-x)<80 and abs(candidate.click_y-y)<80 for n,x,y,until in self.cooldowns)

    def _wait_alt_state(self,desired,seconds=.6):
        check=getattr(self.bridge,'alt_is_down',None)
        if not callable(check):
            self.say('Нет проверки фактического Alt: A/F не отправляю');self.stop();return False
        until=time.monotonic()+seconds
        while self._focus_ok():
            if bool(check())==desired:return True
            if time.monotonic()>=until:break
            if not GamepadInput.wait(.04,self.stop_event,self.screen.focused):return False
        if self._focus_ok():
            sync=getattr(self.bridge,'resync_receiver',None)
            if callable(sync):
                self._neutral()
                self.say('Alt не подтвердился: один повтор команды состояния после синхронизации Lua; A/F/V не повторяю')
                if sync(self.stop_event,self.screen.focused):
                    command='ALT_DOWN' if desired else 'ALT_UP'
                    if self.bridge_cmd(command):
                        until=time.monotonic()+seconds
                        while self._focus_ok():
                            if bool(check())==desired:
                                self.say('Состояние Alt восстановлено после одного повтора');return True
                            if time.monotonic()>=until:break
                            if not GamepadInput.wait(.04,self.stop_event,self.screen.focused):return False
            self.receiver_ready=False
            self.halt_reason='Lua: фактический Alt не '+('зажат' if desired else 'отпущен')+'; проверь G9 и активный профиль G HUB'
            self.say('Alt фактически не '+('зажат' if desired else 'отпущен')+
                     ': A/F заблокированы. Проверьте приёмник Lua, физический G9 и активный профиль AION2.')
            self.stop()
        return False

    def _preflight_receiver(self):
        if self.cfg.get('dry_run'):return True
        self._neutral()
        until=time.monotonic()+10
        if not self.screen.focused():self.say('Переключись в AION2: сначала проверю Lua, движение ещё не начинается')
        while not self.stop_event.is_set() and not self.screen.focused():
            if time.monotonic()>=until:
                self.halt_reason='Проверка Lua не началась: окно AION2 не активно';self.say(self.halt_reason);return False
            if self.stop_event.wait(.05):return False
        result=check_receiver(self.bridge,self.stop_event,self.screen.focused,self.say)
        self.receiver_ready=result.ok
        if not result.ok:
            self.halt_reason=result.reason
            self.say('СТАРТ ОТМЕНЁН: '+result.reason+'. Патруль, камера, F и V не запускались')
            return False
        self.say('Lua готов: фактическое нажатие и отпускание Alt подтверждены. Это не ACK для остальных команд')
        return True

    def _visual_route_allowed(self,candidate):
        if not self.network or not self.cfg.get('visual_route_hold',False):return False
        view=self._net_view();proof=self.visual_selection
        return bool(view and view['ready'] and not view['state'].selected and proof
                    and (self.resume_resource_id is None or self.resume_resource_id[0]==view['flow'])
                    and proof[:3]==(view['flow'],0,candidate.name) and self.acquisition_clicked_at is not None
                    and proof[3]>=self.acquisition_clicked_at and 0<=time.monotonic()-proof[3]<=3)

    def _start_visual_route(self,candidate,origin):
        if not self._visual_route_allowed(candidate) or not self._focus_ok():return False
        frame,origin=self.screen.frame();fresh=find_resource_near(frame,candidate) if candidate.glyph is not None else None
        if fresh is None or not self._wait_alt_state(True):return False
        self.bridge.cursor(origin[0]+int(fresh.click_x),origin[1]+int(fresh.click_y))
        if not GamepadInput.wait(.1,self.stop_event,self.screen.focused) or not self._visual_route_allowed(candidate):return False
        if not self.gamepad.tap_a(self.stop_event,self.screen.focused):return False
        now=time.monotonic();view=self._net_view()
        self.visual_route=dict(flow=view['flow'],until=now+12,maximum=now+35,distance=None,name=candidate.name,selection_after=self.network_selection_after,note_at=now)
        self.pitch.pause_return(now)
        self.target=candidate.name;self.candidate=fresh;self.target_confirmed=False;self.resource_hold=True
        self.probe=None;self.pending_probe=None;self.change_mode('VERIFY_NATIVE')
        self.say('Свежая верхняя плашка ресурса подтверждена, сетевого ID ещё нет: клик активации отправлен; сохраняю штатный путь без стиков/крыльев')
        return True

    def _release_visual_route(self):
        if self.visual_route is not None:
            self.visual_route=None;self.pitch.resume_return(time.monotonic())

    def _verify_visual_route(self,frame,reading,now):
        lease=self.visual_route
        if lease is None:self.change_mode('SEARCH');self.resource_hold=False;return False
        self._neutral();view=self._net_view()
        if not view or not view['ready']:return True
        if view['flow']!=lease['flow']:
            self.halt_reason='Соединение сменилось при подтверждении подхода';self.stop();return True
        with self.snapshot_lock:snapshot=self.snapshot
        if snapshot is not None and 0<=now-snapshot[1]<=2 and snapshot[0].target_name==self.target:
            distance=snapshot[0].distance_m
            if distance is not None and (lease['distance'] is None or distance<lease['distance']-.3):
                lease['distance']=distance;lease['until']=max(lease['until'],min(lease['maximum'],now+8))
        if now<lease['until']:
            if now-lease.get('note_at',now)>=2:
                lease['note_at']=now
                self.say(f'Штатный подход сохраняю: дистанция {lease["distance"]} м; ожидаю свой сбор, не включаю патруль')
            return True
        # A genuine own start is handled before this method by adoption.
        if not self._cancel_autopath():return True
        self._release_visual_route()
        if reading.confirmed and self.bridge_cmd('END_AIR'):
            self.resource_flight_owned=True;self.wing_close_pending=now;self.wing_close_started=now
            self.wing_close_retries=0;self.wing_absent_since=None
        candidate=self.candidate;self.resource_hold=False;self.target_confirmed=False
        self.target=None;self.candidate=None;self.nav.abandon_goal(now,45);self._restore_pitch();self.change_mode('SEARCH')
        if candidate:self.cooldowns.append((candidate.name,candidate.click_x,candidate.click_y,now+30))
        self.say('Подход по визуальному ресурсу не подтвердился: ограниченный отказ от цели, продолжаю поиск')
        return True

    def _bind_resource_candidate(self,candidate):
        self.target=candidate.name;self.candidate=candidate;self.target_confirmed=True;self.missing_since=None
        self.reacquire_until=None;self.acquire_failures=0
        self.patrol_stall.reset(time.monotonic(),clear_used=True)
        self.resource_hold=True;self._reset_resource_watch(verified_header=True)
        return self.network is None or self._net_claim()

    def click_candidate(self,candidate,origin,refresh=True,retry=False):
        self.pitch.pause_return(time.monotonic())
        try:return self._click_candidate_impl(candidate,origin,refresh,retry)
        finally:self.pitch.resume_return(time.monotonic())

    def _click_candidate_impl(self,candidate,origin,refresh=True,retry=False):
        if self.cfg.get('dry_run'):
            self.say(f'НАБЛЮДЕНИЕ: {candidate.name}, точка ({candidate.click_x},{candidate.click_y})');return False
        if not self.gamepad:raise RuntimeError('Виртуальный Xbox не подключён')
        if self.network is not None and self._own_collection() is not None:
            self._adopt_network_collection();return self.target_confirmed
        if self._urgent_damage_pending():return False
        self._neutral();self.f_disable()
        self.real_gather_panel_seen=False;self.f_repeat_allowed=False;self.wing_route_restart_pending=False
        if not self._focus_ok():return False
        if not retry:
            self.target=candidate.name;self.target_confirmed=False;self.folded=False
            self.flight_attempted=False;self.jump_attempted=False;self.reselected=False
            self.last_distance=None;self.last_segments=None;self.one_segment_armed=False
            self.interrupts.reset();self.panel_cleared=False
            self.defense_cycles=0
            self.health.begin_gather()
        self.change_mode('ACQUIRE')
        self.network_selection_after=int(time.time()*1000)
        self.bridge_cmd('ALT_DOWN')
        selected=False;prepared_click_route=False;launched=False;activated_on_select=False;visual_started=False
        try:
            if not self._wait_alt_state(True):return False
            if not GamepadInput.wait(.16,self.stop_event,self.screen.focused):return False
            frame=None
            if refresh:
                fresh=None
                for attempt in range(3):
                    if self._urgent_damage_pending():return False
                    frame,origin=self.screen.frame()
                    self.panel_cleared=not gathering_panel(frame)
                    fresh=find_resource_near(frame,candidate)
                    if fresh is None and candidate.glyph is None:
                        fresh=find_world_resource(frame,(candidate.name,))
                    if fresh is not None:break
                    if attempt<2 and not GamepadInput.wait(.12,self.stop_event,self.screen.focused):return False
                if fresh is None:
                    self.say('Три свежих кадра после Alt без подписи: откладываю клик, продолжаю сближение');return False
                candidate=fresh
            h=self.current_size[1] if self.current_size else 1440
            offsets=(0,round(h*.010),-round(h*.008)) if candidate.name=='Эфир' else (0,round(h*.009))
            points=[(candidate.click_x,candidate.click_y)]
            bx,by,bw,bh=map(int,candidate.box)
            caption=(bx+bw//2,by+bh+max(18,round(h*(.035 if candidate.name=='Эфир' else .010))))
            if abs(caption[0]-candidate.click_x)+abs(caption[1]-candidate.click_y)>4:
                points.append(caption)
            points.extend((candidate.click_x,candidate.click_y+offset) for offset in offsets[1:])
            if self.network is not None:
                gaps=[max(6,min(12,round(bh*.6))),max(14,round(h*.022)),max(18,round(h*.035))] if candidate.name=='Эфир' else [max(6,min(12,round(bh*.6))),max(18,round(h*.010))]
                points=(list(ether_click_points(candidate,self.current_size[0] if self.current_size else 2560,h)[:3]) if candidate.name=='Эфир' and self._click_interaction_enabled()
                        else list(dict.fromkeys((bx+bw//2,by+bh+gap) for gap in gaps)))
            owned_during_select=False
            for index,(px,py) in enumerate(points):
                if not self._focus_ok() or self._urgent_damage_pending():return False
                if self.network is not None and index:
                    if self._own_collection() is not None:owned_during_select=True;break
                    current=self._net_view()
                    if self._selected_resource(current,candidate.name):selected=True;break
                    if current and current['ready'] and current['state'].selected and current['state'].selection_time>=self.network_selection_after:
                        self.say('Клик выбрал другой/неподтверждённый ID: повтор на нём запрещён');break
                    fresh_frame,origin=self.screen.frame()
                    fresh=find_resource_near(fresh_frame,candidate)
                    if fresh is None:break
                    px+=fresh.box[0]-candidate.box[0];py+=fresh.box[1]-candidate.box[1]
                x=origin[0]+int(px);y=origin[1]+int(py)
                self.bridge.cursor(x,y)
                if not GamepadInput.wait(.12,self.stop_event,self.screen.focused):return False
                if not self._wait_alt_state(True):return False
                if not index:
                    if self.network is not None:self.network_selection_after=int(time.time()*1000)
                    self.acquisition_clicked_at=time.monotonic()
                before_click=self._net_view() if self._click_interaction_enabled() else None
                if not self.gamepad.tap_a(self.stop_event,self.screen.focused):return False
                if not GamepadInput.wait(.20,self.stop_event,self.screen.focused):return False
                if self.network is not None:
                    until=time.monotonic()+2.5
                    miss_until=time.monotonic()+.6
                    header_hint=False
                    if self.cfg.get('visual_route_hold',False):
                        current_frame,_=self.screen.frame()
                        header_hint=resource_header_visible(current_frame) or segment_count(current_frame) is not None
                    while self._focus_ok() and not self._urgent_damage_pending():
                        view=self._net_view()
                        if self._own_collection(view) is not None:owned_during_select=True;break
                        if before_click and before_click['ready'] and before_click['flow']==view['flow']:
                            prior=before_click['state'];node=prior.nodes.get(prior.selected)
                            if (prior.selected and prior.selected==view['state'].selected and node and node.visible
                                and node.used!=3 and resource_names().get(node.template)==candidate.name
                                and (self.resume_resource_id is None or self.resume_resource_id==(view['flow'],prior.selected))):
                                # A on an already-selected node is the route command.
                                # The game need not emit a second selection event.
                                activated_on_select=True;selected=True
                                self.network_selection_after=min(self.network_selection_after,prior.selection_time)
                                break
                        if self._selected_resource(view,candidate.name):selected=True;break
                        if self._visual_route_allowed(candidate):break
                        if time.monotonic()>=miss_until:
                            state=view['state'] if view and view['ready'] else None
                            fresh_id=state and state.selected and state.selection_time>=self.network_selection_after
                            node=state.nodes.get(state.selected) if state else None
                            unknown=fresh_id and state.selected not in state.npcs and state.selected not in state.players and (node is None or node.template is None)
                            if not unknown and not (header_hint and state and not state.selected):break
                        if time.monotonic()>=until:break
                        if not GamepadInput.wait(.03,self.stop_event,self.screen.focused):return False
                elif refresh:
                    frame,_=self.screen.frame();name,_=selected_target(frame,tuple(self.cfg['target_names']))
                    if name is not None:
                        if name not in self.cfg['target_names']:
                            self.say('Верхняя плашка не подтверждает разрешённый ресурс');break
                        confirmed=replace(candidate,name=name)
                        if not self._allowed(confirmed,time.monotonic()):break
                        if name!=candidate.name:
                            self.say(f'Дальняя подпись: {candidate.name}; верхняя плашка уточнила: {name}')
                        candidate=confirmed;selected=True
                else:selected=True
                if selected or owned_during_select:
                    candidate=replace(candidate,click_x=px,click_y=py);break
                if self._visual_route_allowed(candidate):break
            if not selected and not owned_during_select:
                visual_started=self._start_visual_route(candidate,origin)
                if not visual_started:
                    view=self._net_view();state=view['state'] if view and view['ready'] else None
                    self.say(f'Выбор не подтверждён: ID={state.selected if state else None}, профиль={bool(state and state.selected in state.nodes)}, свежая верхняя плашка={self.visual_selection[2] if self.visual_selection else None}; ввода движения нет до нового поиска')
                    return False
            if self._click_interaction_enabled() and not owned_during_select and not visual_started:
                if not self._bind_resource_candidate(candidate):return False
                prepared_click_route=True
                if activated_on_select and candidate.name!='Эфир':
                    self.route_f_sent=True;self.route_active=True;self.native_route_started_at=time.monotonic();launched=True
                    self.route_click_tries=1;self.route_click_sent_at=time.monotonic()
                    self.say('CLICK_RESOURCE: первый клик по выбранному ID отправлен; при задержке возможны повторы')
                else:launched=self._start_resource_route()
        finally:self.bridge_cmd('ALT_UP')
        if not self._focus_ok() or not self._wait_alt_state(False):return False
        if visual_started:return True
        if owned_during_select:
            self._adopt_network_collection()
            return self.target_confirmed
        if not prepared_click_route:
            # Legacy F is only sent after Alt has actually been released.
            if not self._bind_resource_candidate(candidate):return False
            launched=self._start_resource_route()
        if not launched and (not self._click_interaction_enabled() or not self._focus_ok()):return False
        if self.mode=='REACQUIRE':return True
        if launched and self.resume_resource_id==self.network_target:self.resume_resource_id=None
        self.identity_valid_after=time.monotonic()
        self.last_progress=time.monotonic();self.change_mode('GATHER' if self.real_gather_panel_seen else 'APPROACH')
        self.say(f'{candidate.name}: цель подтверждена; '+('штатный подход запущен один раз' if launched else 'жду свежую точку для единственного запуска кликом'))
        self._restore_pitch()
        return True

    def _can_abandon_resource(self):
        view=self._net_view();binding=self.abandoning_binding
        return bool(self._focus_ok() and binding and view and view['ready']
                    and binding==self.network_target and view['flow']==binding[0]
                    and (self.network_owner is None or view['state'].own==self.network_owner)
                    and not view['state'].attempt_active and view['state'].collecting in (None,binding[1]))

    def return_to_search(self,reason,frame=None,exhausted=False,reading=None,frame_time=None,abandon=False):
        if not abandon:return self._return_to_search_impl(reason,frame,exhausted,reading,frame_time)
        self.abandoning_binding=self.network_target
        try:return self._return_to_search_impl(reason,frame,exhausted,reading,frame_time,True)
        finally:self.abandoning_binding=None

    def _return_to_search_impl(self,reason,frame=None,exhausted=False,reading=None,frame_time=None,abandon=False):
        node=self._net_node() if self.network is not None else None
        if abandon and not self._can_abandon_resource():
            self._adopt_network_collection();return
        if not abandon and self.target_confirmed and node is not None and node.visible and (node.used is None or node.used<3):
            if not self.real_gather_panel_seen and self.native_route_started_at is not None and time.monotonic()-self.native_route_started_at>60:
                self.say('За 60 с сбор не начался: остановка с сохранением выбранного ресурса, без повторного F');self.stop();return
            self._neutral();self.change_mode('GATHER' if self.real_gather_panel_seen else 'APPROACH')
            self.say('Сеть ещё показывает оставшиеся попытки: ресурс сохранён, поиск камерой не запускаю')
            if self.real_gather_panel_seen:self.f_enable()
            return
        if not abandon and self.target_confirmed and not self.network_exhausted:
            fresh,_=self.screen.frame()
            live_panel=self._gather_panel(fresh)
            started=self.fast_gather_seen or self.mode=='GATHER' or self.collecting_visible
            alive=live_panel or started and (segment_count(fresh) is not None or resource_header_visible(fresh))
            if alive:
                if live_panel:
                    self.collecting_visible=True;self.fast_gather_seen=True
                    self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                self._neutral();self.change_mode('GATHER');self.f_enable()
                self.say('Возврат отменён: свежий кадр всё ещё показывает ресурс/сбор; крылья сохраняю')
                return
        if not abandon and self.collecting_visible and self.target_confirmed and not exhausted:
            self._neutral();self.change_mode('GATHER');self.f_enable()
            self.say('Окно сбора видно: возврат к патрулю и движение запрещены');return
        was_aether=self.target=='Эфир'
        stamp=time.monotonic() if frame_time is None else frame_time
        recent_air=(self.last_flight_seen_at is not None and stamp-self.last_flight_seen_at<=1.2
                    and (self.last_flight_energy is None or self.last_flight_energy>1))
        collected_air=self.network is None and was_aether and (self.mode=='GATHER' or self.fast_gather_seen)
        self._neutral()
        # A full result stripe is not depletion. Keep aether wings open until
        # the resource itself disappears; never toggle V from sky colours.
        ended_air=False
        known_air=(reading is not None and reading.confirmed) or recent_air or collected_air
        if known_air and (self.target_confirmed or self.resource_flight_owned) and not self.folded and (exhausted or was_aether or self.resource_flight_owned):
            if self.bridge_cmd('END_AIR'):
                self.folded=True;self.f_on=False;ended_air=True
                self.wing_close_pending=time.monotonic();self.wing_close_started=self.wing_close_pending;self.wing_close_retries=0
                self.wing_absent_since=(self.wing_close_pending if reading is not None and not reading.confirmed else None)
            else:
                self._neutral();return
        if not ended_air:self.f_disable()
        if not exhausted and (self.mode in ('APPROACH','JUMP_RETRY','TAKEOFF') or abandon):
            if not self._cancel_autopath(allow_inactive_collection=abandon):return
        self.say(reason)
        now=time.monotonic()
        if abandon and self.network_target is not None:
            self.resource_retry_after={b:t for b,t in self.resource_retry_after.items() if t>now}
            self.resource_retry_after[self.network_target]=now+45
            if node and node.gather_time is not None:self.abandoned_lease=(*self.network_target,node.gather_time)
        self._clear_view_recovery()
        if exhausted:self.node_count+=1
        if self.candidate:
            self.cooldowns.append((self.candidate.name,self.candidate.click_x,self.candidate.click_y,now+(12 if exhausted else 30)))
        if exhausted:self.nav.exclude_goal(now,30)
        else:self.nav.abandon_goal(now,60)
        if frame is not None and not exhausted:self.save_debug(frame,'failed')
        self.target=None;self.candidate=None;self.target_confirmed=False;self.reacquire_until=None
        self.resource_hold=False;self.collecting_visible=False;self.interrupts.reset();self.resume_resource_id=None
        self._reset_resource_watch()
        if exhausted:self.post_gather_until=time.monotonic()+.8
        if exhausted and self._automatic_camera_enabled() and (self.pitch.returning or self.pitch.failed or abs(self.pitch.offset(time.monotonic()))>.009):
            self.camera_alignment_due='после сбора эфира';self.camera_requested_at=time.monotonic()
        self.missing_since=None;self.change_mode('SEARCH')
        self._restore_pitch()

    def _clear_view_recovery(self):
        self.view_recovery=None;self.view_click_pending=False

    def _arm_view_recovery(self,now):
        if self.network_target is None:return
        if self.view_recovery is None or self.view_recovery.binding!=self.network_target:
            self.view_recovery=ResourceViewRecovery(self.network_target,now+12,now+1)
            self.say('Нет результата кликов: до 12 с на смену точек/ракурса; срок не сбрасывается новым выбором')

    def _view_recovery_tick(self,frame,reading,now):
        if not self._click_interaction_enabled() or self.camera_in_progress or self.mode=='DEFENSE':return False
        view=self._net_view()
        if not view or not view['ready'] or not self._focus_ok():return False
        own=self._own_collection(view);state=view['state']
        if own is not None:
            pending=self.next_attempt_wait_at is not None or self.click_wait_since is not None
            repairing=self.view_recovery is not None and self.mode=='GATHER'
            if state.attempt_active or own.used not in (1,2) or not (pending or repairing):
                self._clear_view_recovery();return False
        if self.mode not in ('REACQUIRE','APPROACH','GATHER'):return False
        if self.mode=='GATHER' and own is None:return False
        if self.view_recovery is None and self.target_confirmed:
            if own is not None:
                pending_at=self.next_attempt_wait_at if self.next_attempt_wait_at is not None else self.click_wait_since
                if own.used in (1,2) and pending_at is not None and now-pending_at>=2:self._arm_view_recovery(now)
            elif self.native_route_started_at is not None:
                relative=geometry(state,self._net_node(view))
                distance=relative['distance_m'] if relative else None
                if distance is None and self.distance_live_at is not None and 0<=now-self.distance_live_at<=2:distance=self.distance_live
                elapsed=now-self.native_route_started_at;stalled=now-self.last_progress
                near=distance is not None and distance<=8 and elapsed>=2 and stalled>=2
                unresponsive=elapsed>=5 and stalled>=4
                if near or unresponsive:self._arm_view_recovery(now)
        recovery=self.view_recovery
        if recovery is None:return False
        if recovery.binding!=self.network_target:
            self._clear_view_recovery();return False
        if now>=recovery.until:
            self.return_to_search('Ракурс/клики не помогли за 12 с: пропускаю этот ресурс на 45 с',frame,reading=reading,abandon=True)
            return True
        if now<recovery.settle_until:return True
        if now<recovery.next_at or recovery.step>=len(VIEW_PULSES) or self.click_busy or self._urgent_damage_pending():return False
        yaw,pitch,seconds=VIEW_PULSES[recovery.step]
        self._neutral()
        try:
            self.gamepad.drive(0,0,yaw,pitch,lifetime=seconds)
            if pitch:self.camera_search_revision+=1
            if not GamepadInput.wait(seconds,self.stop_event,self.screen.focused):return True
        finally:self._neutral()
        stamp=time.monotonic();recovery.step+=1;recovery.next_at=stamp+.7;recovery.settle_until=stamp+.20
        self.identity_valid_after=stamp;self.reacquire_next=stamp+.20
        # A click is harmless during native travel. Each new viewpoint may
        # immediately try it again without resetting path/stall deadlines.
        self.route_click_tries=min(self.route_click_tries,1)
        self.route_click_sent_at=stamp-2;self.click_retry_at=stamp+.20;self.view_click_pending=True
        if own is not None:
            self.next_attempt_click_tries=0;self.next_attempt_wait_at=stamp-2
        self.say(f'Небольшой сдвиг камеры {recovery.step}/{len(VIEW_PULSES)}: ищу свежую точку того же ресурса, затем клик')
        return True

    def _begin_reacquire(self,reason):
        if self.network_target is not None:self.resume_resource_id=self.network_target
        self._neutral();self.f_disable()
        self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
        self.f_repeat_allowed=False;self.route_active=False;self.real_gather_panel_seen=False;self.wing_route_restart_pending=False;self.interrupts.reset()
        self.identity_valid_after=time.monotonic();self.reacquire_until=self.identity_valid_after+8
        if self._click_interaction_enabled() and self.network_target is not None:
            self._arm_view_recovery(self.identity_valid_after)
            self.reacquire_until=self.view_recovery.until
        self.reacquire_next=self.identity_valid_after;self.change_mode('REACQUIRE');self.say(reason)

    def _reacquire_step(self,frame,origin,obs,now):
        self._neutral()
        if self._view_recovery_tick(frame,read_flight(frame),now):return
        if self.reacquire_until is not None and now>=self.reacquire_until:
            self.return_to_search('Ресурс после смены цели не найден',reading=read_flight(frame));return
        if now<self.reacquire_next:return
        self.reacquire_next=now+.4
        candidate=find_resource_near(frame,self.candidate) if self.candidate is not None else None
        if candidate is None and obs.candidate is not None and obs.candidate.name==self.target:
            candidate=obs.candidate
        if candidate is None:return
        deadline=self.reacquire_until
        if not self.click_candidate(candidate,origin,retry=True):
            self.change_mode('REACQUIRE');self.reacquire_until=deadline
            self.reacquire_next=time.monotonic()+.5

    def _acquire_miss(self,candidate,now):
        self.f_disable();self.real_gather_panel_seen=False;self.wing_route_restart_pending=False
        self.acquire_failures+=1
        self.target=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
        self.f_repeat_allowed=False;self.route_active=False
        if self.acquire_failures>=3:
            self.cooldowns.append((candidate.name,candidate.click_x,candidate.click_y,now+3))
            self.acquire_failures=0
        self.candidate=None;self.change_mode('SEARCH');self.nav.pause(now)
        self.say('Выбор не подтверждён: цель миникарты сохранена, продолжаю подход и повторное распознавание')

    def _cancel_autopath(self,allow_inactive_collection=False):
        # Neutral reports alone do not cancel a route already owned by the game.
        # A short manual movement requests cancellation before the next patrol.
        if allow_inactive_collection and not self._can_abandon_resource():return False
        if not allow_inactive_collection and self.network is not None and self._own_collection() is not None:
            self._neutral();return False
        fresh,_=self.screen.frame()
        panel=self._gather_panel(fresh)
        if panel or self.fast_gather_seen and not allow_inactive_collection:
            self._neutral();self.collecting_visible=panel;self.change_mode('GATHER')
            if panel:
                self.fast_gather_seen=True;self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
            self.f_enable();return False
        if self.cfg.get('dry_run') or not self.gamepad or not self._focus_ok():return False
        try:
            if allow_inactive_collection and not self._can_abandon_resource():return False
            if not allow_inactive_collection and self.network is not None and self._own_collection() is not None:return False
            self.gamepad.drive(-.35,0,0,0,lifetime=.25)
            if GamepadInput.wait(.20,self.stop_event,self.screen.focused):
                self.route_active=False;return True
            return False
        finally:self._neutral()

    def _net_selected_aggressor(self):
        view=self._net_view()
        if not view or not view['ready'] or self.network_attacker is None:return False
        state=view['state']
        return attack_reason(state,self.network_attacker,int(time.time()*1000)) is None

    def _stop_defense_motion(self):
        keeper=self.defense_motion;self.defense_motion=None
        if keeper:keeper.close()

    def _defense_motion_allowed(self):
        if not self._focus_ok() or self.network_defense is None:return False
        view=self._net_view();episode=self.network_defense
        return bool(view and view['ready'] and view['flow']==episode.flow
                    and view['state'].own==episode.owner and not view['state'].attempt_active
                    and self._own_collection(view) is None)

    def _begin_network_defense(self,resume):
        if self.network_defense is not None or not self._focus_ok() or self.cfg.get('dry_run'):return
        view=self._net_view()
        if not view or not view['ready'] or self.network_attacker is None:return
        now=time.monotonic();resource=self.target if resume and (self.target in self.cfg['target_names'] or self._net_node(view) is not None) else None
        resource_id=self.network_target[1] if resource and self.network_target else None
        self._release_visual_route()
        translation=(0.,0.)
        frame,_=self.screen.frame()
        keep=(not resume and self.mode=='SEARCH' and not self.collecting_visible
              and not read_flight(frame).confirmed and self.gamepad is not None)
        if keep and hasattr(self.gamepad,'current_translation'):
            translation=self.gamepad.current_translation()
        if self.view_recovery is not None and self.view_recovery.paused_at is None:self.view_recovery.paused_at=now
        self.network_defense=NetworkDefense(self.network_attacker,view['flow'],view['state'].own,
                                           now,bool(resource),resource,resource_id)
        self.defense_camera_until=now+2 if abs(self.pitch.offset(now))>.05 else None
        if self.defense_camera_until is not None:
            self._restore_pitch();self._stop_defense_motion()
            self.say('Перед Tab возвращаю рабочий наклон: при взгляде в небо наземный моб может не выбираться')
        self.pitch.pause_return(now)
        self.defense_cycles+=1
        self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
        self.f_repeat_allowed=False;self.real_gather_panel_seen=False;self.wing_route_restart_pending=False
        self.route_active=False;self.identity_valid_after=now;self.interrupts.reset();self.change_mode('DEFENSE')
        if sum(abs(x) for x in translation)>.05 and self.defense_camera_until is None:
            self.defense_motion=TranslationKeeper(self.gamepad,translation,self._defense_motion_allowed)
            self.defense_motion.start()
            self.say('Защита на ходу: сохраняю уже начатое наземное движение; камеру не кручу')
        else:self._neutral()
        self.f_disable()
        if self.bridge.alt_is_down():self.bridge_cmd('ALT_UP')
        profile='получен' if self.network_attacker in view['state'].npcs else 'не попал в захват; используем подтверждённый удар'
        self.say(f'Агрессор ID={self.network_attacker}; профиль: {profile}. Проверяю совпадение выбранного ID, не HP/плашку духа')

    def _finish_network_defense(self,success,reason=''):
        episode=self.network_defense
        if episode is None:return
        self._stop_defense_motion();self.network_defense=None;self.defense_camera_until=None
        view=self._net_view()
        if view and view['ready']:
            stamp=view['state'].attacks.get(episode.attacker,0)
            self.attacker_handled[episode.attacker]=max(self.attacker_handled.get(episode.attacker,0),stamp)
            self.network_hit_handled=max(self.network_hit_handled,stamp)
        now=time.monotonic();self.pitch.resume_return(now)
        if self.view_recovery is not None and self.view_recovery.paused_at is not None:
            self.view_recovery.until+=max(0,now-self.view_recovery.paused_at)
            self.view_recovery.paused_at=None;self.view_recovery.next_at=now+.3
        self.hp_next_defense=now+(1 if success else 8)
        self.attacker_retry_after[episode.attacker]=self.hp_next_defense
        self.next_defense=self.hp_next_defense;self.hp_handled_event=self.health.state()['damage_sequence']
        if not self._focus_ok():return
        if not success:
            self.say('Защита прервана: '+reason+'. Восемь секунд без повторного Tab, продолжаю поиск')
            if episode.resource:
                frame,_=self.screen.frame()
                self.return_to_search('После неудачной защиты пропускаю этот ресурс',frame,reading=read_flight(frame))
                self.defense_cycles=0
                return
            self.target=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
            self._reset_resource_watch();self.change_mode('SEARCH');self.nav.pause(now);self.defense_cycles=0
            return
        self.say('Смерть агрессора подтверждена сервером')
        node=view['state'].nodes.get(episode.resource_id) if view and view['ready'] else None
        if episode.resume and node and (node.used==3 or node.removed_reason==4):
            frame,_=self.screen.frame()
            self.return_to_search('Ресурс уже исчерпан за время защиты',exhausted=True,reading=read_flight(frame));return
        if episode.resume:
            self.target=episode.resource
            self.resume_resource_id=(episode.flow,episode.resource_id) if episode.resource_id is not None else None
            self._begin_reacquire('Защита закончена: заново выбираю сохранённый ресурс '+str(episode.resource))
        else:
            self.target=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
            self._reset_resource_watch();self.change_mode('SEARCH');self.nav.pause(now);self.defense_cycles=0
            self.say('Защита патруля закончена: продолжаю поиск ресурса')

    def _network_defense_tick(self,now):
        episode=self.network_defense
        if episode is None:return False
        if not self._focus_ok():self._stop_defense_motion();return True
        view=self._net_view()
        if not view or not view['ready']:
            self._stop_defense_motion();return True
        state=view['state']
        if view['flow']!=episode.flow or state.own!=episode.owner:
            self._finish_network_defense(False,'сменились соединение или ID персонажа');return True
        if self.defense_camera_until is not None:
            offset=self.pitch.offset(now)
            if abs(offset)<.009:
                self._neutral();self.defense_camera_until=None
            elif now<self.defense_camera_until:
                self.gamepad.drive(0,0,0,-PITCH_STRENGTH if offset>0 else PITCH_STRENGTH,lifetime=min(.12,abs(offset)/PITCH_STRENGTH))
                return True
            else:
                self._neutral();self.defense_camera_until=None
                self.say('Коррекция перед Tab не успела завершиться: проверяю реальный выбранный ID без угадывания')
        if view['flow']!=episode.flow or state.own!=episode.owner:
            self._finish_network_defense(False,'сменились соединение или ID персонажа');return True
        wall=int(time.time()*1000)
        hit=state.outgoing.get(episode.attacker)
        if hit and episode.first_attack is not None and hit[0]>=episode.first_attack and hit[0]>episode.outgoing_seen:
            episode.outgoing_seen=hit[0]
            self.say(f'Сеть подтверждает наш удар по агрессору ID={episode.attacker}, урон={hit[1]}')
        action=episode.plan(state,wall,now)
        if action=='DONE':self._finish_network_defense(True)
        elif action=='ABORT':self._finish_network_defense(False,episode.reason)
        elif action=='TAB':
            self.say(f'Проверка Tab {episode.tabs+1}/3: выбран ID={state.selected}, нужен ударивший ID={episode.attacker}')
            requested=wall
            if self.bridge_cmd('TAB'):episode.sent_tab(requested,time.monotonic())
            else:self._finish_network_defense(False,'команда Tab отменена проверкой ввода')
        elif action=='PAIR':
            profile='NPC' if episode.attacker in state.npcs else 'источник подтверждённого урона без начального профиля'
            self.say(f'Атака {episode.pairs+1}/3: выбран ID={state.selected}, агрессор ID={episode.attacker}; {profile}')
            requested=wall
            if self.bridge_cmd('ATTACK_PAIR'):
                episode.sent_pair(requested,time.monotonic())
                self.say('Команда двух нажатий ] отправлена; ожидаю сетевое попадание или смерть цели')
            else:
                fresh=self._net_view()
                reason=attack_reason(fresh['state'],episode.attacker,int(time.time()*1000)) if fresh and fresh['ready'] else 'нет свежей сети'
                if fresh and fresh['ready'] and dead(fresh['state'],episode.attacker):
                    self._finish_network_defense(True)
                else:self._finish_network_defense(False,'атака отменена: '+str(reason))
        return True

    def _pending_network_hits(self,now):
        if not self.cfg.get('protect_player',True) or self.defense_cycles>=self.cfg.get('defense_max_cycles',6):return []
        if self._defer_route_defense(now):return []
        view=self._net_view()
        if not view or not view['ready']:return []
        wall=int(time.time()*1000);state=view['state']
        return [(stamp,actor) for actor,stamp in state.attacks.items()
              if stamp>self.attacker_handled.get(actor,0) and 0<=wall-stamp<=4000
              and now>=self.attacker_retry_after.get(actor,0)
              and attack_reason(state,actor,wall) in (None,'выбран другой ID')]

    def _urgent_damage_pending(self):
        return self.network is not None and bool(self._pending_network_hits(time.monotonic()))

    def _net_defense(self,now):
        if self.mode not in ('SEARCH','ACQUIRE_WAIT','APPROACH','TAKEOFF','JUMP_RETRY','GATHER','REACQUIRE','VERIFY_NATIVE'):return False
        hits=self._pending_network_hits(now)
        if not hits:return False
        view=self._net_view()
        if not view or not view['ready']:return False
        state=view['state'];wall=int(time.time()*1000)
        stamp,actor=next((hit for hit in hits if hit[1]==state.selected),max(hits))
        self.network_hit_handled=stamp;self.attacker_handled[actor]=stamp;self.network_attacker=actor
        self.say(f'Сеть: подтверждён удар по персонажу; от захвата пакета до реакции {max(0,wall-stamp)} мс. Проверяю именно нанёсшего его моба; цель моба может быть духом.')
        resume=(self.target_confirmed or self.mode=='VERIFY_NATIVE' and self.visual_route is not None or self.mode=='REACQUIRE' and self.target is not None
                and (self.resume_resource_id is not None or self.network_target is not None))
        self._defend_and_resume(resume=resume)
        return True

    def _confirmed_aggressor(self):
        if self.network is not None:
            if not self._net_selected_aggressor():return False
            return GamepadInput.wait(.18,self.stop_event,self.screen.focused) and self._net_selected_aggressor()
        first,_=self.screen.frame();a=self.threat.check(first)
        if not(a.matches and a.hp):return False
        if not GamepadInput.wait(.18,self.stop_event,self.screen.focused):return False
        second,_=self.screen.frame();b=self.threat.check(second)
        return b.matches and b.hp

    def _defend_and_resume(self,resume=True):
        if self.network is not None:return self._begin_network_defense(resume)
        if not self._focus_ok() or self.cfg.get('dry_run'):return
        resource=self.target;self.defense_cycles+=1
        self._neutral()
        if not resume and not self.folded:
            frame,_=self.screen.frame()
            if read_flight(frame).confirmed and self.bridge_cmd('END_AIR'):
                self.folded=True;self.f_on=False
        self.f_disable();self.route_active=False
        self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False;self.f_repeat_allowed=False
        self.real_gather_panel_seen=False;self.wing_route_restart_pending=False
        self.identity_valid_after=time.monotonic();self.interrupts.reset();self.change_mode('DEFENSE')
        self.say('Проверяю агрессора через Tab: смена цели останавливает путь к ресурсу')
        try:
            for index in range(min(3,self.cfg.get('defense_max_tabs',8)) if self.network is not None else self.cfg.get('defense_max_tabs',8)):
                if self.network is not None and not self._net_view()['ready']:break
                if self.network is None and index>=3 and not self.health.ongoing(time.monotonic()):break
                if self.network is None or not self._net_selected_aggressor():
                    requested=int(time.time()*1000)
                    if not self.bridge_cmd('TAB'):return
                    if not GamepadInput.wait(.25,self.stop_event,self.screen.focused):return
                    if self.network is not None:
                        until=time.monotonic()+1.5
                        while self._focus_ok() and time.monotonic()<until:
                            fresh=self._net_view()
                            if fresh['ready'] and fresh['state'].selection_time>=requested:break
                            if not GamepadInput.wait(.05,self.stop_event,self.screen.focused):return
                        else:
                            self.say('Сеть не подтвердила смену цели: следующие Tab отменены');break
                if not self._confirmed_aggressor():
                    if self.health.ongoing(time.monotonic()):self.say('Чужой/неподтверждённый таргет, HP ещё снижен: проверяю следующий Tab')
                    continue
                if not self.bridge_cmd('ATTACK_PAIR'):return
                self.say('Агрессор подтверждён дважды: два нажатия ], жду завершения боя')
                until=time.monotonic()+6;absent=None;defeated=False
                while self._focus_ok() and time.monotonic()<until:
                    frame,_=self.screen.frame();evidence=self.threat.check(frame) if self.network is None else None
                    net_dead=False
                    if self.network is not None:
                        view=self._net_view();npc=view['state'].npcs.get(self.network_attacker) if view['ready'] else None
                        net_dead=bool(npc and npc['dead'])
                    if (self.network is None and not evidence.matches and not evidence.hp) or net_dead:
                        if absent is None:absent=time.monotonic()
                        if time.monotonic()-absent>.6:defeated=True;break
                    else:absent=None
                    if not GamepadInput.wait(.25,self.stop_event,self.screen.focused):return
                if not defeated:
                    self.say('Исчезновение обеих боевых плашек не подтверждено: остановка перед возвратом к сбору')
                    self.stop();return
                break
            if not self._focus_ok():return
            if not resume:
                if resource not in self.cfg['target_names']:
                    self.target=None;self.target_confirmed=False;self.resource_hold=False
                    self.defense_cycles=0
                    self._reset_resource_watch();self.change_mode('SEARCH');self.nav.pause(time.monotonic())
                    self.say('Защита патруля закончена: продолжаю поиск ресурса');return
                frame,_=self.screen.frame();self.collecting_visible=False
                self.return_to_search('Последняя попытка ресурса уже потрачена: следующая цель',
                                      exhausted=True,reading=read_flight(frame))
                return
            self._begin_reacquire('Защита закончена: заново выбираю сохранённый ресурс '+str(resource))
        finally:
            self.next_defense=time.monotonic()+8
            self.hp_handled_event=self.health.state()['damage_sequence'];self.hp_next_defense=time.monotonic()+1

    def _recover(self,frame,origin,obs,reading,now):
        fresh,_=self.screen.frame()
        live_panel=self._gather_panel(fresh)
        if live_panel or self.real_gather_panel_seen:
            self._neutral();self.collecting_visible=live_panel
            self.change_mode('GATHER')
            if live_panel:
                self.fast_gather_seen=True;self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                self.collection_activity_at=now
            self.f_enable()
            self.say('Восстановление пути запрещено: сбор уже начался; остаюсь у ресурса без V/движения')
            return
        if self.mode=='TAKEOFF':
            self._neutral();return
        if obs.target_name==self.target and obs.distance_m is not None and obs.distance_m<=3:
            self._neutral()
            self.say('Ресурс ближе 3 м: V не открываю, жду штатное начало сбора')
            return
        self._neutral()
        if reading.confirmed:
            if reading.confirmed:self.flight_attempted=True
            if now-self.last_note>2:
                self.say('Штатный путь к ресурсу ещё ожидает начало сбора: F не повторяю, движение не отменяю')
                self.last_note=now
            return
        if not reading.confirmed and not self.flight_attempted and self.budget.can_start():
            if not self.bridge_cmd('V'):return
            self.flight_attempted=True;self.wing_route_restart_pending=True;self.route_active=False
            self.change_mode('TAKEOFF')
            self.say('Упор в препятствие: V, проверка раскрытых крыльев, затем F по выбранному таргету')
            return
        if not self.jump_attempted and self.target!='Эфир' and not reading.confirmed and not self.flight_attempted:
            self.jump_attempted=True;self.bridge_cmd('JUMP')
            self.change_mode('JUMP_RETRY');self.say('Энергии для облёта мало: одна попытка перепрыгнуть препятствие')
            return
        if self.target=='Эфир' and not reading.confirmed and not self.flight_attempted:
            self.budget.failed_takeoff(now)
        self.return_to_search('Нет сближения с ресурсом: пропускаю и патрулирую дальше',frame,reading=reading)

    def step(self,frame,origin,obs,radar,reading,now,sequence=0):
        if self.stop_event.is_set():return
        if self._network_guard(now):return
        self._adopt_network_collection()
        self.current_size=(frame.shape[1],frame.shape[0])
        self._budget_update(reading,now)
        if not self.screen.focused():
            self._neutral();self.f_disable();self.nav.pause(now);return
        if self._network_defense_tick(now):return
        plate=segment_count(frame)
        panel=self._gather_panel(frame)
        self.collecting_visible=panel
        if self._check_route_damage(frame,now,panel,plate):return
        if (self.network is not None and self.mode=='SEARCH' and self.target is None
            and gathering_panel_pair(frame) and obs.target_name in self.cfg['target_names']):
            view=self._net_view();state=view['state'] if view['ready'] else None
            node=state.nodes.get(state.collecting) if state else None
            if node and node.gather_time is not None and node.visible and node.used is not None and node.used<3:
                self._reset_resource_watch(True)
                self.target=obs.target_name;self.target_confirmed=True;self.resource_hold=True
                self.network_target=(view['flow'],node.actor);self.network_owner=state.own;self.network_claimed_at=node.gather_time
                self.change_mode('APPROACH')
                self.say('Подхватил уже начавшийся собственный сбор по сети; новый стартовый F не нужен')
        if self._resource_fast_tick(frame,reading,now,panel,plate):return
        if self._patrol_escape_tick(frame,reading,now):return
        if (self.mode=='APPROACH' and not self.real_gather_panel_seen and obs.target_name==self.target
            and obs.distance_m is not None and (self.distance_live_at is None or now-self.distance_live_at>=2)):
            if self.last_distance is None or obs.distance_m<self.last_distance-.3:
                self.last_distance=obs.distance_m;self.last_progress=now
        if self._approach_fast_tick(frame,origin,reading,now):return
        panel=self.collecting_visible
        if self.mode=='REACQUIRE':
            self._reacquire_step(frame,origin,obs,now);return
        if panel and self.mode=='SEARCH' and self.target is None and self.probe is None:
            returning=self.cfg.get('world_map_enabled') and self.region.ready and self.region.returning
            if ((self.cfg.get('assist_manual_target') and self.network is None) and obs.target_name in self.cfg['target_names']
                and plate is not None and not self.nav.is_retreating(now) and not returning
                and self.policy.allows(obs.target_name)):
                self.target=obs.target_name;self.target_confirmed=True;self.resource_hold=True
                self.defense_cycles=0;self.interrupts.reset();self.missing_since=None
                self.folded=False;self.health.begin_gather();self.change_mode('GATHER')
                self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                self.say('Уже идёт сбор выбранного ресурса: принимаю управление независимо от старой дистанции OCR')
            else:
                self._neutral();return
        if not panel:self.panel_cleared=True
        if panel and self.target_confirmed and (self.panel_cleared or self.mode=='GATHER'):
            self._neutral()
            if self.mode!='GATHER':self.change_mode('GATHER');self.missing_since=None
            self.f_enable()
        if now<self.post_gather_until:
            self._neutral();return
        if (self.camera_scheduler_active and self._automatic_camera_enabled()
            and self.camera_alignment_due and self.mode=='SEARCH' and not panel
            and not self.resource_hold and self.probe is None):
            if reading.confirmed:
                self._neutral()
                if now-self.camera_requested_at>5:
                    self.say(f'Калибровка {self.camera_alignment_due} ожидает закрытых крыльев: энергия={reading.energy}, признаки дуги={reading.evidence}. Остановка ввода, состояние полёта требует проверки');self.stop()
                return
            if not self._calibrate_camera(self.camera_alignment_due):self.stop()
            return
        if self.pitch.failed and not self.resource_hold and not panel:
            safe=(self.mode=='SEARCH' and not self.resource_hold and self.probe is None) or (self.mode=='GATHER' and panel)
            if self.camera_scheduler_active and self._automatic_camera_enabled() and safe:
                if not self._calibrate_camera('нет подтверждённого возврата наклона',allow_gather=panel):self.stop()
            else:
                self.say('Возврат наклона не подтверждён: остановка ввода');self.stop()
            return
        if self.probe is not None:
            self._probe_step(frame,origin,obs,radar,reading,now);return
        if self.pitch.returning and not panel and self.mode!='GATHER' and not self.resource_hold:
            correction=self.pitch.correction(time.monotonic())
            if correction:
                self._motion(Drive(pitch=correction,lifetime=self.pitch.correction_lifetime(),reason='возвращаю прежний наклон камеры той же силой стика'))
            else:
                self._neutral();self.nav.pause(now);self.last_progress=now
                self.identity_valid_after=time.monotonic()
                if self.pitch.failed:
                    self.halt_reason='Возврат наклона камеры не подтверждён';self.say('Не удалось вернуть наклон камеры: остановка');self.stop()
            return
        if self.pending_probe is not None:
            goal=self.pending_probe;self.pending_probe=None
            if self.budget.can_probe(self.cfg.get('flight_probe_min_percent',18)):
                self.probe=FlightProbe(goal,now,self.cfg);self.change_mode('PROBE')
            else:self.nav.abandon_goal(now,60)
            self._neutral();return
        if (self.mode=='SEARCH' and not self.resource_hold and self.cfg.get('auto_view_recovery',True)
            and self.nav.air_since is None and (self.view_guard.active or abs(self.pitch.offset(time.monotonic()))<.009)):
            action,accepted,failed=self.view_guard.update(frame,now)
            if failed:
                recent=self.camera_last_calibrated is not None and now-self.camera_last_calibrated<10
                if self.camera_scheduler_active and self._automatic_camera_enabled() and not recent:
                    if not self._calibrate_camera('земля в поле зрения не найдена'):self.stop()
                else:
                    self.say('Земля не подтверждена после коррекции камеры: остановка ввода');self.stop()
                return
            if accepted:
                self._neutral();self.pitch.accept_visible_ground(time.monotonic());self.nav.pause(now)
                self.identity_valid_after=time.monotonic();return
            if action is not None:
                self._motion(action);return
        near=(obs.distance_m is not None and obs.distance_m<=3)
        # Being two metres from a node can still mean being behind a rock.
        # Near distance enables F, but does not disable obstacle recovery.
        gather_ready=obs.f_prompt or (panel and (obs.distance_m is None or near))
        if self.target_confirmed and self.mode in ('APPROACH','JUMP_RETRY','TAKEOFF') and plate is not None:
            if self.last_segments is not None and plate<self.last_segments:
                gather_ready=True
                self.say('Счётчик изменился; начало сбора всё ещё требует нижнюю плашку')
            self.last_segments=plate
        if reading.confirmed and self.target_confirmed and self.mode in ('APPROACH','TAKEOFF','GATHER'):
            self.flight_attempted=True
        if self.mode in ('SEARCH','ACQUIRE_WAIT'):
            returning=self.cfg.get('world_map_enabled') and self.region.ready and self.region.returning
            if (not returning and not self.nav.is_retreating(now)
                and (self.cfg.get('assist_manual_target') and self.network is None) and obs.target_name in self.cfg['target_names']
                and plate is not None
                and self.policy.allows(obs.target_name)
                and gather_ready):
                self.target=obs.target_name;self.target_confirmed=True;self.missing_since=None
                self.resource_hold=True
                self.defense_cycles=0;self.interrupts.reset()
                self.folded=False;self._neutral()
                if panel:
                    self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                    self.f_enable();self.change_mode('GATHER')
                else:
                    self._reset_resource_watch(verified_header=True)
                    self.route_active=True;self.route_f_sent=True;self.change_mode('APPROACH')
                    self.say('Уже выбран ручной таргет: F не повторяю, наблюдаю текущий подход')
                return
            candidate=obs.candidate
            if (not returning and not self.nav.is_retreating(now) and candidate
                and self.cfg.get('allow_click',True) and self._allowed(candidate,now)):
                self._neutral();self.nav.pause(now)
                if self.mode=='SEARCH':
                    self.candidate=candidate;self.candidate_sequence=sequence
                    self.candidate_since=now;self.change_mode('ACQUIRE_WAIT')
                    self.say('Вижу '+candidate.name+'; остановил движение, уточняю координаты')
                elif sequence!=self.candidate_sequence and candidate.name==self.candidate.name:
                    if not self.click_candidate(candidate,origin):
                        self._acquire_miss(candidate,time.monotonic())
                return
            if self.mode=='ACQUIRE_WAIT':
                if sequence!=self.candidate_sequence and self.candidate is not None:
                    fresh=find_resource_near(frame,self.candidate)
                    if fresh is not None:
                        if not self.click_candidate(fresh,origin):self._acquire_miss(fresh,time.monotonic())
                        return
                if now-self.candidate_since<2.5:return
                self.candidate=None;self.change_mode('SEARCH')
            if not self.cfg.get('minimap_search',True):radar.markers=[]
            radar=replace(radar,markers=[m for m in radar.markers if self.policy.allows('Эфир' if m.kind=='aether' else 'Самоцвет')])
            if self.nav.goal and not self.policy.allows('Эфир' if self.nav.goal.kind=='aether' else 'Самоцвет'):self.nav.goal=None
            self._spatial_route(radar)
            if self.cfg.get('world_map_enabled') and self.region.ready:
                bearing=self.region.terrain_bearing(frame,radar,now)
                if bearing is not None:
                    self.nav.route(bearing,'курс по сопоставлению рельефа миникарты',self.region.returning)
            plan=self.nav.update(radar,now,self.budget.can_start())
            if plan.flight_probe:
                self._request_probe(now);return
            if plan.restore_pitch:
                self._neutral();self._restore_pitch();return
            if not self.cfg.get('ground_walk',True):plan.forward=0;plan.strafe=0
            if not self.cfg.get('camera_scan',True):plan.yaw=0;plan.pitch=0
            sent=self._motion(plan)
            walking=bool(sent and math.hypot(plan.forward,plan.strafe)>.2 and self.nav.goal is None and self.probe is None)
            search_walking=bool(sent and math.hypot(plan.forward,plan.strafe)>.2 and self.probe is None)
            if self.nav.track_walk(radar,search_walking,now):
                self.say('Рельеф смещается, но маршрут возвращается к прежнему месту: 12 с прямого выхода без поворотов')
            stuck=self.patrol_stall.update(radar,walking,now)
            if (stuck and self.budget.can_start() and not reading.confirmed
                and self.cfg.get('patrol_escape_enabled',True) and not self.cfg.get('dry_run')):
                self._neutral();self.patrol_stall.consume();self.patrol_escape=PatrolEscape(now,self.patrol_escape_side)
                self.patrol_escape_side*=-1;self.change_mode('PATROL_ESCAPE')
                self.say('10 секунд рельеф миникарты не смещается при ходьбе: один короткий выход крыльями')
                return
            if now-self.last_note>1.5:
                self.say(f'{plan.reason}; ресурсы на карте: {len(radar.markers)}, ход={plan.forward:.2f}, бок={plan.strafe:.2f}, камера={plan.yaw:.2f}, наклон={plan.pitch:.2f}')
                self.last_note=now
            return
        if self.mode in ('APPROACH','JUMP_RETRY','TAKEOFF'):
            if obs.target_name and obs.target_name!=self.target:
                self.return_to_search('В таргете другой ресурс',frame,reading=reading);return
            if obs.distance_m is not None and obs.target_name==self.target:
                # Track a new best distance, not alternating OCR values such
                # as 12/13/12/13 which otherwise reset the wall timer forever.
                if self.last_distance is None or obs.distance_m<self.last_distance-.3:
                    self.last_progress=now;self.last_distance=obs.distance_m
            if self.target_confirmed and panel and (self.panel_cleared or self.fast_gather_seen):
                self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                self._neutral();self.f_enable();self.missing_since=None;self.change_mode('GATHER')
                self.say('Сбор доступен; F работает независимо от OCR');return
            if self.mode=='TAKEOFF':
                if reading.confirmed:
                    if self._start_resource_route(restart_after_wings=True):
                        self.last_distance=obs.distance_m;self.last_progress=now;self.change_mode('APPROACH')
                    return
                if now-self.started>3.5:
                    self.budget.failed_takeoff(now)
                    self.say(self.budget.describe(now))
                    self.return_to_search('Крылья не подтверждены дугой; повторно V не переключаю',frame,reading=reading)
                return
            if self.mode=='JUMP_RETRY':
                if now-self.started>1.5:
                    self.last_distance=obs.distance_m;self.last_progress=now;self.change_mode('APPROACH')
                return
            if plate is None and obs.target_name is None:
                if self.missing_since is None:self.missing_since=now
                if now-self.missing_since>2:
                    self.return_to_search('Плашка выбранного ресурса исчезла до сбора',frame,reading=reading);return
            else:self.missing_since=None
            if radar.motion_valid and math.hypot(*radar.displacement)>.15:
                self.last_path_motion=now
            progress=max(self.last_progress,self.last_path_motion or self.last_progress)
            stall=max(1,self.cfg.get('approach_stall_seconds',6))
            distance_stale=(obs.target_name==self.target and obs.distance_m is not None
                and obs.distance_m>3 and now-self.last_progress>
                (stall if obs.distance_m<=6 else max(12,stall*2)))
            route_since=self.native_route_started_at if self.native_route_started_at is not None else self.started
            delayed=(now-route_since>10 and now-self.last_progress>2)
            if now-self.started>max(60,self.cfg.get('approach_timeout',60)):
                self.return_to_search('Таймаут подхода',frame,reading=reading)
            elif distance_stale or now-progress>stall or delayed:
                self._recover(frame,origin,obs,reading,now)
            return
        if self.mode=='GATHER':
            if (panel and self.real_gather_panel_seen and self.target_confirmed and self.camera_scheduler_active
                and self._automatic_camera_enabled() and self._gather_camera_needed()
                and not self.health.pending(self.hp_handled_event,now)):
                if not self._calibrate_camera('один раз после поискового движения камеры',allow_gather=True):self.stop()
                return
            # Cached OCR cannot terminate a live resource. Red target changes
            # and resource depletion are handled from fresh frames above.
            if not self.f_on:self.f_enable()
            remaining=plate is not None or resource_header_visible(frame)
            if self.cfg.get('protect_player',True) and not panel and self.interrupts.ready(radar.hostiles_near,now):
                # A missed last frame of a normal attempt is not proof of a hit.
                # Ask the HP reader; never change the resource target on this alone.
                self.health.request_check(frame,now)
            if plate is not None and plate!=self.last_segments:
                self.last_segments=plate;self.last_progress=now;self.say(f'Осталось попыток: {plate}/3')
            # A missing panel BETWEEN attempts never re-enters approach recovery.
            # Keep the same target and F timer; depletion is owned by the live UI tick.
            activity=self.collection_activity_at if self.collection_activity_at is not None else self.last_progress
            if not panel and now-activity>20:
                self.say('20 секунд без нижней плашки/расхода попытки: остановка ввода с сохранением ресурса, без V')
                self.stop();return
            if now-self.started>self.cfg.get('gather_timeout',55):
                if panel:
                    self.say('Окно сбора не исчезло за отведённое время: остановка ввода без движения')
                    self.stop()
                else:self.return_to_search('Сбор не завершился за отведённое время',frame,reading=reading)

    def process(self,frame,origin,now):
        if self.stop_event.is_set():return
        obs=self.vision.scan(frame)
        self.observation_captured_at=now
        self.sequence+=1
        self.step(frame,origin,obs,self.minimap.observe(frame),read_flight(frame),now,self.sequence)

    def current_observation(self,obs,captured):
        if captured>=self.identity_valid_after:return obs
        # OCR started before A may finish later; it must not undo the new selection.
        return Observation(None,None,None,False,0,False,None,'HIDDEN')

    def _navigation_observation(self,snapshot,now):
        """OCR may delay acquisition, never completion or ordinary patrol.

        A missing observation grants no click/target/F authority. Native paths
        and own collection remain stationary here and are serviced above.
        """
        if snapshot is not None and now-snapshot[3]<=3 and snapshot[1]>=self.identity_valid_after:
            obs,captured,sequence,_=snapshot
            return self.current_observation(obs,captured),captured,sequence
        if self.mode!='SEARCH' or self.target_confirmed or self.resource_hold or self.collecting_visible:
            return None
        view=self._net_view()
        if view and (not view['ready'] or self._own_collection(view) is not None or view['state'].attempt_active):return None
        if now-self.ocr_wait_note>=5:
            self.say('OCR ещё обрабатывает кадр: патруль по свежей миникарте продолжается; выбор ресурса ждёт распознавания')
            self.ocr_wait_note=now
        return Observation(None,None,None,False,0,False,None,'HIDDEN'),now,-1

    def _spatial_route(self,radar):
        # The current camera heading still comes from the north-up minimap.
        # Fresh XYZ may supply a bearing, never a collision-free path or click.
        if self.spatial_route_active:
            if self.nav.route_reason.startswith('свежие XYZ:'):self.nav.route(None)
            self.spatial_route_active=False
        atlas=getattr(self.network,'atlas',None)
        if radar.markers or atlas is None:return
        view=self._net_view()
        if not view or not view['ready']:return
        options=[]
        for node in view['state'].nodes.values():
            if time.monotonic()<self.resource_retry_after.get((view['flow'],node.actor),0):continue
            label=atlas.objects.get(str(node.template),{}).get('names',{}).get('ru')
            if label not in self.cfg['target_names'] or not self.policy.allows(label):continue
            relative=geometry(view['state'],node)
            if relative and 3<relative['planar_m']<=100:options.append((relative['distance_m'],relative,label))
        if options:
            _,relative,label=min(options,key=lambda item:item[0])
            self.nav.route(relative['bearing'],f'свежие XYZ: {label}, высота {relative["height_m"]:+.1f} м')
            self.spatial_route_active=True

    def _gather_camera_needed(self):
        return (self.camera_search_revision>self.camera_aligned_revision
                and self.camera_gather_tried_revision!=self.camera_search_revision)

    def _automatic_camera_enabled(self):
        return (not self.cfg.get('dry_run') and self.cfg.get('camera_scan',True)
                and self.cfg.get('camera_auto_calibrate',True) and self.gamepad is not None)

    def _camera_wait(self,seconds):
        """Camera-only motion cannot postpone depletion or wing closure."""
        until=time.monotonic()+seconds
        while self._focus_ok():
            if self.target_confirmed:
                frame,_=self.screen.frame();now=time.monotonic()
                if self._check_route_damage(frame,now):
                    self.calibration_defense_interrupted=True
                    self.camera_alignment_due='после защиты от моба'
                    self.camera_requested_at=time.monotonic();self._neutral();return False
                self._resource_fast_tick(frame,read_flight(frame),now)
                if not self.target_confirmed:
                    self.calibration_resource_ended=True
                    self.camera_alignment_due='ресурс закончился во время коррекции камеры'
                    self.camera_requested_at=time.monotonic();self._neutral();return False
            remaining=until-time.monotonic()
            if remaining<=0:return True
            if not GamepadInput.wait(min(.06,remaining),self.stop_event,self.screen.focused):return False
        return False

    def _hold_pitch_up(self,seconds):
        return self._hold_calibration_pitch(seconds,1)

    def _hold_pitch_down(self,seconds):
        return self._hold_calibration_pitch(seconds,-1)

    def _hold_calibration_pitch(self,seconds,direction):
        if not self.pitch_observed:return False
        before=self.pitch.offset(time.monotonic());end=time.monotonic()+seconds+2
        try:
            while self._focus_ok() and time.monotonic()<end:
                delivered=direction*(self.pitch.offset(time.monotonic())-before)/PITCH_STRENGTH
                remaining=seconds-delivered
                if remaining<=.005:return True
                self.gamepad.drive(0,0,0,direction*PITCH_STRENGTH,lifetime=min(.15,remaining))
                if not self._camera_wait(min(.08,remaining)):return False
            return False
        finally:self._neutral()

    def _calibrate_camera(self,reason,allow_gather=False):
        self.camera_in_progress=True
        try:return self._calibrate_camera_impl(reason,allow_gather)
        finally:self.camera_in_progress=False

    def _calibrate_camera_impl(self,reason,allow_gather=False):
        if not self._automatic_camera_enabled():return True
        self.calibration_resource_ended=False
        self.calibration_defense_interrupted=False
        self._neutral()
        if not self._focus_ok():return False
        frame,_=self.screen.frame()
        panel=self._gather_panel(frame)
        selected=self.resource_hold or self.target_confirmed or panel
        gather_exception=(allow_gather and panel and self.real_gather_panel_seen and self.target_confirmed
                          and self.mode=='GATHER' and self._gather_camera_needed())
        if selected and not gather_exception:
            if self.camera_search_revision>self.camera_aligned_revision:
                self.camera_alignment_due=reason;self.camera_requested_at=time.monotonic()
            self.say('Калибровка не запущена: нет нового поискового отклонения либо ещё идёт подход')
            return True
        for kind,detector in (('CAPTCHA',self.cap),('DEATH',self.death)):
            if detector.check(frame)[0]:self.trigger_alarm(kind,frame);return False
        if not self._focus_ok():return False
        revision=self.camera_search_revision
        if gather_exception:self.camera_gather_tried_revision=revision
        seconds=2.0
        milliseconds=working_view_ms(self.cfg)
        self.say(f'Калибровка камеры ({reason}): около {seconds:.0f} с вверх до предполагаемого упора, затем {milliseconds} мс вниз; только вертикальная ось')
        if not self._hold_pitch_up(seconds):
            if self.calibration_resource_ended or self.calibration_defense_interrupted:return True
            self.say('Подъём камеры прерван; частичная калибровка не принята');return False
        if not self._camera_wait(.10):return self.calibration_resource_ended or self.calibration_defense_interrupted
        before=self.pitch.offset(time.monotonic());completed=False
        try:completed=self._hold_pitch_down(milliseconds/1000)
        finally:self._neutral()
        if not completed or not self._focus_ok():
            if self.calibration_resource_ended or self.calibration_defense_interrupted:return True
            self.say('Опускание камеры прервано; частичная калибровка не принята');return False
        delivered=(before-self.pitch.offset(time.monotonic()))/PITCH_STRENGTH*1000
        self.say(f'Камера: вниз задано {milliseconds} мс; фактически передано около {delivered:.1f} мс')
        if not self.pitch_observed or abs(delivered-milliseconds)>25:
            self.say('Длительность импульса не подтверждена: калибровка не принята');return False
        self.pitch.set_working_baseline(time.monotonic())
        self.camera_last_calibrated=time.monotonic();self.camera_alignment_due=None
        self.camera_aligned_revision=revision
        self.identity_valid_after=self.camera_last_calibrated;self.nav.pause(self.identity_valid_after)
        self.nav.air_since=None;self.nav.scan_kind=None;self.view_guard=ViewGuard()
        with self.snapshot_lock:self.snapshot=None
        self.say('Рабочий наклон камеры восстановлен по временному ориентиру; угол непосредственно не измеряется')
        return True

    def _prepare_working_view(self):
        if not self._automatic_camera_enabled():return True
        if not self._focus_ok():return False
        frame,_=self.screen.frame();panel=self._gather_panel(frame)
        if panel:
            self.camera_alignment_due='после текущего сбора при запуске'
            self.camera_requested_at=time.monotonic()
            self.say('При запуске уже идёт сбор: калибровка отложена, ввод камеры запрещён')
            return True
        if not panel:
            name,distance=selected_target(frame,tuple(self.cfg['target_names']))
            reading=read_flight(frame)
            if reading.confirmed or name in self.cfg['target_names']:
                self.camera_alignment_due='после текущего подхода/полёта'
                self.camera_requested_at=time.monotonic()
                if name in self.cfg['target_names'] and (self.cfg.get('assist_manual_target') and self.network is None):
                    self.target=name;self.target_confirmed=True;self.resource_hold=True
                    self.last_distance=distance;self.last_progress=time.monotonic()
                    self.flight_attempted=reading.confirmed;self.change_mode('APPROACH')
                    self._reset_resource_watch(verified_header=True)
                    self.route_active=True;self.route_f_sent=True
                    self.say('Путь к уже выбранному ресурсу принят без второго F')
                self.say('Калибровка отложена до сбора или остановки: текущий подход/полёт продолжается')
                return True
        return self._calibrate_camera('при запуске',allow_gather=panel)

    def run(self,offline=None):
        try:
            if offline:
                for file in offline:
                    if self.stop_event.is_set():break
                    frame=cv2.imread(str(file))
                    if frame is not None:self.process(frame,(0,0),time.monotonic())
                return
            if self.screen.pick() is None:raise RuntimeError('Окно AION2 не найдено')
            if not self.cfg.get('dry_run') and self.gamepad is None:raise RuntimeError('Нажмите «Подключить Xbox»')
            if self.cfg.get('network_enabled',False) and self.network is None and not self.cfg.get('dry_run'):
                raise RuntimeError('Встроенный сетевой режим не подключён')
            if not self._preflight_receiver():return
            if self.network is not None:self.network.start()
            self.bridge_cmd('F_OFF');self.f_on=False
            self.say('Навигация стиками; миникарта включена с готовыми цветами/формами, отдельный OCR-поток')
            self.safety_threads=[
                threading.Thread(target=self._vision_loop,daemon=True),
                threading.Thread(target=self._health_fast_loop,daemon=True),
                threading.Thread(target=self._health_numeric_loop,daemon=True),
                threading.Thread(target=self._heartbeat_loop,daemon=True),
                threading.Thread(target=self._dialog_loop,args=('CAPTCHA',self.cap,1.0),daemon=True),
                threading.Thread(target=self._dialog_loop,args=('DEATH',self.death,3.0),daemon=True)]
            for worker in self.safety_threads:worker.start()
            self.camera_scheduler_active=True
            prepared=False
            if self.network is None:
                if not self._prepare_working_view():return
                prepared=True
            while not self.stop_event.is_set():
                frame,origin=self.screen.frame();now=time.monotonic()
                if not self.screen.focused():
                    self._neutral();self.f_disable();self.nav.pause(now)
                    self.stop_event.wait(.1);continue
                if self._network_guard(now):
                    self.stop_event.wait(.06);continue
                self._adopt_network_collection()
                if not prepared:
                    if not self._prepare_working_view():return
                    prepared=True
                reading=read_flight(frame);self._budget_update(reading,now)
                if self._network_guard(now):
                    self.stop_event.wait(.06);continue
                if self._network_defense_tick(now):
                    self.stop_event.wait(.06);continue
                if self._check_route_damage(frame,now):
                    self.stop_event.wait(.06);continue
                if self._resource_fast_tick(frame,reading,now):
                    self.stop_event.wait(.06);continue
                if self._patrol_escape_tick(frame,reading,now):
                    self.stop_event.wait(.06);continue
                if self._approach_fast_tick(frame,origin,reading,now):
                    self.stop_event.wait(.06);continue
                if (self.cfg.get('world_map_enabled') and self.region.ready and not self.cfg.get('dry_run')
                    and self.mode=='SEARCH' and not self.resource_hold and not self.collecting_visible
                    and not self.nav.is_retreating(now)
                    and now>=self.post_gather_until and not self.pitch.returning and self.nav.air_since is None
                    and self.probe is None and self.pending_probe is None and not self.view_guard.active
                    and self.camera_alignment_due is None
                    and self.wing_close_pending is None
                    and now>=self.region.next_check):
                    self._check_world_map();continue
                with self.snapshot_lock:snapshot=self.snapshot
                navigation=self._navigation_observation(snapshot,now)
                if navigation is None:
                    self._neutral();self.stop_event.wait(.08);continue
                obs,captured,sequence=navigation
                self.observation_captured_at=captured
                radar=self.minimap.observe(frame)
                if not self.cfg.get('minimap_search',True):radar.markers=[]
                self.step(frame,origin,obs,radar,reading,now,sequence)
                if self.stop_event.wait(.09):break
        except Exception as exc:self.emit('ОШИБКА: '+repr(exc)+'\n'+traceback.format_exc())
        finally:
            self.stop()
            if self.release_thread:self.release_thread.join(timeout=5)
            if self.network is not None:self.network.close()
            self.emit(('Сканер остановлен: '+self.halt_reason+'; A и стики сброшены') if self.halt_reason else 'Сканер остановлен; A и стики сброшены')
