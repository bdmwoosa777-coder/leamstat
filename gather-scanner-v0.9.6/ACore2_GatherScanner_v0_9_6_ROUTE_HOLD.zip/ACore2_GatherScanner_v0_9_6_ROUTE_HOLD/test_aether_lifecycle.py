import time,unittest
from contextlib import ExitStack
from unittest.mock import patch
from flight import FlightReading
from camera_working_view import WORKING_VIEW_PRESETS,working_view_ms
from test_navigation import GatherFixture,obs
import gather_engine as ge

AIR=FlightReading(50,True)
HIDDEN=FlightReading(None,False)


class AetherLifecycleTests(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.stack=ExitStack();self.addCleanup(self.stack.close)
        self.stack.enter_context(patch.object(ge,'resource_header_visible',return_value=False))
        self.stack.enter_context(patch.object(ge,'gather_result_full',return_value=False))

    def selected(self,mode='APPROACH'):
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode=mode;self.e.f_on=True;self.e.started=99;self.e.last_progress=99
        self.e._reset_resource_watch(verified_header=True)

    def fast(self,now,slots=None,panel=False,reading=AIR):
        with patch.object(ge,'segment_count',return_value=slots),patch.object(ge,'gathering_panel',return_value=panel),patch.object(ge,'gathering_panel_pair',return_value=panel):
            return self.e._resource_fast_tick(self.frame,reading,now,panel,slots)

    def test_more_working_views_keep_legacy_values_and_include_700_to_800(self):
        self.assertEqual(working_view_ms({}),770)
        for number in (650,660,670,680,690,700,710,750,800):
            self.assertIn(number,WORKING_VIEW_PRESETS)
            self.assertEqual(working_view_ms({'camera_working_view_ms':number}),number)

    def test_one_slot_completion_in_approach_closes_even_without_any_ocr_result_or_gather_panel(self):
        self.selected();self.assertIsNone(self.e.snapshot)
        self.fast(100,slots=1)
        self.assertFalse(self.fast(100.1))
        self.assertTrue(self.fast(100.8))
        self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.target_confirmed)
        self.assertFalse(self.e.f_on);self.assertEqual(self.commands.count('END_AIR'),1)
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_fresh_ocr_name_cannot_keep_a_depleted_ui_alive(self):
        self.selected('GATHER')
        self.step(obs('Эфир',distance=1),100,plate=1,panel=True,reading=AIR)
        self.e.observation_captured_at=101
        self.step(obs('Эфир',distance=1),101,reading=AIR)
        self.e.observation_captured_at=101.8
        self.step(obs('Эфир',distance=1),101.8,reading=AIR)
        self.assertIsNone(self.e.target);self.assertEqual(self.commands.count('END_AIR'),1)

    def test_hidden_arc_at_depletion_uses_confirmed_aether_collection_to_fold(self):
        self.selected('GATHER');self.fast(100,slots=1,panel=True)
        self.fast(100.1,reading=HIDDEN);self.fast(100.8,reading=HIDDEN)
        self.assertEqual(self.commands.count('END_AIR'),1)

    def test_short_header_gap_or_visible_gather_panel_does_not_fold(self):
        self.selected('GATHER');self.fast(100,slots=1,panel=True)
        self.fast(100.1);self.fast(100.4,slots=1)
        self.fast(101,panel=True);self.fast(102,panel=True)
        self.assertEqual(self.commands,[]);self.assertEqual(self.e.mode,'GATHER')

    def test_generic_resource_frame_protects_a_bad_slot_count(self):
        self.selected('GATHER')
        with patch.object(ge,'resource_header_visible',return_value=True):
            self.fast(100);self.fast(102)
        self.assertEqual(self.commands,[]);self.assertTrue(self.e.target_confirmed)

    def test_direct_calibration_request_cannot_move_camera_during_collection(self):
        self.selected('GATHER')
        with patch.object(self.input,'drive') as drive,patch.object(self.e.pitch,'set_working_baseline') as baseline:
            self.assertTrue(self.e._calibrate_camera('legacy request',allow_gather=True))
        drive.assert_not_called();baseline.assert_not_called()
        self.assertTrue(self.e.target_confirmed);self.assertEqual(self.commands,[])

    def test_calibration_request_cannot_complete_or_reset_a_remaining_resource(self):
        self.selected('GATHER');self.e.fast_last_slots=2
        with patch.object(self.input,'drive') as drive:
            self.assertTrue(self.e._calibrate_camera('during down',allow_gather=True))
        drive.assert_not_called();self.assertEqual(self.e.fast_last_slots,2)
        self.assertEqual(self.e.target,'Эфир');self.assertNotIn('END_AIR',self.commands)

    def test_confirmed_still_open_wings_get_only_one_retry_then_a_bounded_stop(self):
        self.e.wing_close_pending=100;self.e.wing_close_retries=0
        with patch.object(ge.time,'monotonic',return_value=101.6):
            self.assertTrue(self.e._service_wing_close(AIR,101.6))
        self.assertEqual(self.commands,['END_AIR']);self.assertEqual(self.e.wing_close_retries,1)
        self.e._service_wing_close(AIR,102)
        with patch.object(self.e,'stop') as stop:self.e._service_wing_close(AIR,104.2)
        stop.assert_called_once();self.assertEqual(self.commands,['END_AIR'])

    def test_absent_arc_confirms_close_without_a_second_toggle(self):
        self.e.wing_close_pending=100
        self.assertTrue(self.e._service_wing_close(HIDDEN,100.1))
        self.assertFalse(self.e._service_wing_close(HIDDEN,100.4))
        self.assertIsNone(self.e.wing_close_pending);self.assertEqual(self.commands,[])

    def test_waiting_for_close_blocks_motion_even_without_ocr(self):
        self.e.wing_close_pending=100;self.input.drive(.8,0,.3,0)
        self.fast(100.1,reading=AIR)
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertIsNone(self.e.snapshot)

    def test_stalled_selected_aether_keeps_camera_unchanged_while_f_keeps_running(self):
        self.selected();self.e.last_distance=2;self.e.last_progress=98
        self.e.camera_scheduler_active=True
        with patch.object(self.e,'_calibrate_camera',return_value=True) as calibrate:
            self.step(obs('Эфир',distance=2),100,plate=1,reading=AIR)
            self.e.last_progress=100
            self.step(obs('Эфир',distance=2),101,plate=1,reading=AIR)
        calibrate.assert_not_called()
        self.assertTrue(self.e.f_on);self.assertFalse(self.e.arrival_camera_corrected)
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertNotIn('F_OFF',self.commands)

    def test_new_distance_progress_does_not_trigger_arrival_camera_recovery(self):
        self.selected();self.e.last_distance=20;self.e.last_progress=95;self.e.camera_scheduler_active=True
        with patch.object(self.e,'_calibrate_camera') as calibrate:
            self.step(obs('Эфир',distance=10),100,plate=3,reading=AIR)
        calibrate.assert_not_called()

    def test_800ms_working_view_is_not_cut_by_the_old_700ms_transport_limit(self):
        self.e.cfg['camera_working_view_ms']=800;reports=[];listener=self.input.motion_listener
        def record(pitch,now,lease):reports.append((pitch,now));listener(pitch,now,lease)
        self.input.motion_listener=record
        with patch.object(self.e,'_hold_pitch_up',return_value=True),patch.object(ge,'gathering_panel',return_value=False),patch.object(self.e.cap,'check',return_value=(False,0)),patch.object(self.e.death,'check',return_value=(False,0)):
            self.assertTrue(self.e._calibrate_camera('800ms'))
        delivered=sum((b[1]-a[1]) for a,b in zip(reports,reports[1:]) if a[0]<0)
        self.assertAlmostEqual(delivered,.8,delta=.025)
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_live_loop_finishes_one_slot_with_no_ocr_snapshot_at_all(self):
        self.selected('GATHER');clock=[100.0];self.e.screen.pick=lambda:'game'
        def wait(seconds):
            clock[0]+=seconds
            if clock[0]>=101.2:self.e.stop_event.set()
            return self.e.stop_event.is_set()
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(ge.threading,'Thread'),patch.object(self.e,'_prepare_working_view',return_value=True),patch.object(self.e.stop_event,'wait',side_effect=wait),patch.object(ge,'segment_count',side_effect=lambda frame:1 if clock[0]<100.1 else None),patch.object(ge,'gathering_panel',return_value=False),patch.object(ge,'read_flight',return_value=AIR):
            self.e.run()
        self.assertIsNone(self.e.snapshot);self.assertIsNone(self.e.target)
        self.assertEqual(self.e.node_count,1);self.assertEqual(self.commands.count('END_AIR'),1)
        self.assertEqual(self.pad.axes,(0,0,0,0))


if __name__=='__main__':unittest.main()
