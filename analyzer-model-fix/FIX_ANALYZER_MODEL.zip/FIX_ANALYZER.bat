@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Put both FIX_ANALYZER files in the bot folder after SETUP.bat.
 pause
 exit /b 1
)
".venv\Scripts\python.exe" FIX_ANALYZER.py
