from pathlib import Path
import json
r=Path(__file__).resolve().parent
required=['app.py','route_analyzer.py','setup_analyzer.py','settings_gather.json']
if not all((r/n).is_file() for n in required):
 print('Put FIX_ANALYZER.py into the bot folder beside app.py.');input('Enter to close');raise SystemExit(1)
for n in required:
 p=r/n;raw=p.read_bytes();backup=p.with_name(p.name+'.before_model_fix')
 if not backup.exists():backup.write_bytes(raw)
 p.write_bytes(raw.replace(b'qwen3-vl:4b',b'qwen2.5vl:3b'))
p=r/'settings_gather.json';cfg=json.loads(p.read_text(encoding='utf-8'));cfg['analyzer_model']='qwen2.5vl:3b';p.write_text(json.dumps(cfg,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('Model changed to qwen2.5vl:3b. Close bot, run SETUP_ANALYZER.bat, then START.bat. No Lua changes.')
input('Enter to close')
