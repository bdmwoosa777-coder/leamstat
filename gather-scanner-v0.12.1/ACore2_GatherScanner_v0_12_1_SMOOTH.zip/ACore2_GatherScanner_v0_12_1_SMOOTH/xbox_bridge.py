"""Controller actions confirmed by the user; no keyboard/lock-key injection.

ALT_DOWN/UP are internal compatibility names for LB+LT, not Windows Alt.
World A stays in GamepadInput.tap_a; menu A has its own verified UI path.
"""
import os,threading,time
from gamepad_input import GamepadInput

class PointerPosition:
 def __init__(self,dry_run=False,logger=lambda _:None):
  self.dry_run=dry_run or os.name!='nt';self.log=logger;self.last_cursor_target=None;self.last_cursor_actual=None
  if not self.dry_run:
   import ctypes
   from ctypes import wintypes
   self.win=ctypes.windll.user32;self.point_type=wintypes.POINT;self.byref=ctypes.byref
   self.win.SetCursorPos.argtypes=[ctypes.c_int,ctypes.c_int];self.win.SetCursorPos.restype=wintypes.BOOL
   self.win.GetCursorPos.argtypes=[ctypes.POINTER(wintypes.POINT)];self.win.GetCursorPos.restype=wintypes.BOOL
 def cursor(self,x,y):
  self.last_cursor_target=(int(x),int(y))
  if not self.dry_run and not self.win.SetCursorPos(*self.last_cursor_target):raise OSError('Не удалось установить курсор Windows')
 def cursor_matches(self,tolerance=6):
  if self.last_cursor_target is None:return False
  if self.dry_run:self.last_cursor_actual=self.last_cursor_target;return True
  p=self.point_type()
  if not self.win.GetCursorPos(self.byref(p)):return False
  self.last_cursor_actual=(p.x,p.y)
  return max(abs(a-b) for a,b in zip(self.last_cursor_target,self.last_cursor_actual))<=tolerance

class XboxBridge:
 controller_native=True
 BUTTONS={'TAB':0x0080,'V':0x8000,'END_AIR':0x8000,'JUMP':0x4000,'MAP':0x0010,'MOUNT':0x0040}
 def __init__(self,control,stop,focused,map_ready=lambda:False,dry_run=False,logger=lambda _:None):
  self.control=control;self.stop=stop;self.focused=focused;self.map_ready=map_ready;self.dry_run=dry_run;self.log=logger
  self.lock=threading.RLock();self.pointer=PointerPosition(dry_run,logger);self.map_armed_until=0
 @property
 def last_cursor_target(self):return self.pointer.last_cursor_target
 @property
 def last_cursor_actual(self):return self.pointer.last_cursor_actual
 def cursor(self,x,y):self.pointer.cursor(x,y)
 def cursor_matches(self,tolerance=6):return self.pointer.cursor_matches(tolerance)
 def alt_is_down(self):return self.control.cursor_held
 def ping_if_idle(self):pass
 def restore_locks(self):pass # This transport never changes lock keys.
 def send_guarded(self,command,authorize):return self.send(command,authorize)
 def send(self,command,authorize=None):
  if command not in (*self.BUTTONS,'PING','STOP','F_OFF','F_ON','ALT_DOWN','ALT_UP','ATTACK_PAIR','TAP_F','MAP_UI_ARM','MAP_SCROLL_UP','MAP_SCROLL_DOWN'):raise ValueError(command)
  if command=='PING':return True
  if command=='STOP':self.map_armed_until=0;self.control.reset();return True
  if command=='F_OFF':return True # No autonomous B/F repeat worker exists.
  if command=='ALT_UP':self.control.release_cursor();return True
  def allowed():return not self.stop.is_set() and self.focused() and (authorize is None or bool(authorize()))
  with self.lock:
   if not allowed():return False
   if self.dry_run:self.log('СИМУЛЯЦИЯ Xbox '+command);return True
   if command=='ALT_DOWN':return self.control.begin_cursor(self.stop,self.focused)
   if command=='F_ON':
    self.log('XBOX_ACTION: постоянный B запрещён; повторы сбора обслуживает сетевой контроллер кликов');return False
   if command=='MAP_UI_ARM':
    if authorize is None or not self.map_ready():return False
    self.map_armed_until=time.monotonic()+120;return True
   if command in ('MAP_SCROLL_UP','MAP_SCROLL_DOWN','TAP_F'):
    def ui_allowed():return allowed() and authorize is not None and self.map_ready() and time.monotonic()<self.map_armed_until
    if not ui_allowed():return False
    if command=='TAP_F':result=self.control.tap_button(0x2000,self.stop,self.focused,ui_allowed)
    else:result=self.control.scroll_map_list(1 if command=='MAP_SCROLL_UP' else -1,self.stop,self.focused,ui_allowed)
   elif command=='ATTACK_PAIR':
    result=self.control.tap_button(0x0200,self.stop,self.focused,allowed)
    if result and GamepadInput.wait(.16,self.stop,allowed):result=self.control.tap_button(0x0200,self.stop,self.focused,allowed)
    else:result=False
   else:result=self.control.tap_button(self.BUTTONS[command],self.stop,self.focused,allowed)
   self.log('XBOX_ACTION: '+command+'; отчёт передан='+str(result)+'; выполнение проверяется по сети/кадру')
   return result
