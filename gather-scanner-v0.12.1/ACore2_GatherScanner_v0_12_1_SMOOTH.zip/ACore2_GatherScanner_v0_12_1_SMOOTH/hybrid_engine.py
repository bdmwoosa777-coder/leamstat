"""Classic resource state machine + fast minimap driver + asynchronous detours."""
from dataclasses import replace
import math,time
import cv2
from gather_engine import GatherEngine
from hybrid_navigation import RouteAdvisor,HybridPlanner
from navigation import Drive
from vision import gathering_panel_pair,find_resource_near,find_world_resource,Observation
from return_exit import purple_anchor
from xbox_bridge import XboxBridge

class HybridGatherEngine(GatherEngine):
 def _make_bridge(self,gamepad,cfg,emit):
  if cfg.get('control_transport','xbox')=='lua' or gamepad is None:return super()._make_bridge(gamepad,cfg,emit)
  return XboxBridge(gamepad,self.stop_event,lambda:self.screen.focused(),lambda:self.map_active and self.map_teleport is not None,cfg.get('dry_run',False),emit)
 def _wait_keyboard_alt_state(self,desired,seconds=.6):
  if not getattr(self.bridge,'controller_native',False):return super()._wait_keyboard_alt_state(desired,seconds)
  if self._focus_ok() and bool(self.bridge.alt_is_down())==desired:return True
  self.halt_reason='Режим курсора Xbox LB+LT не подтверждён в отчёте';self.say(self.halt_reason);self.stop();return False
 def _preflight_receiver(self):
  if not getattr(self.bridge,'controller_native',False):return super()._preflight_receiver()
  until=time.monotonic()+10
  while not self.stop_event.is_set() and not self.screen.focused():
   if time.monotonic()>=until:self.halt_reason='Окно AION2 не активно';return False
   if self.stop_event.wait(.05):return False
  if not self._focus_ok():return False
  self._neutral();self.receiver_ready=False
  try:
   if not self.bridge.send('ALT_DOWN') or not self._wait_alt_state(True):return False
   self.bridge.send('ALT_UP')
   if not self._wait_alt_state(False):return False
   self.receiver_ready=True;self.say('Xbox готов: отчёты LB+LT вниз/вверх переданы без A. Lua/G9 не нужны; реакция игры проверяется по кадру, это не игровой ACK')
   return True
  finally:self.bridge.send('ALT_UP')
 def __init__(self,cfg,*args,**kwargs):
  enabled=cfg.get('analyzer_enabled',True)
  super().__init__({**cfg,'analyzer_enabled':False},*args,**kwargs)
  self.cfg['analyzer_enabled']=enabled
  self.analyzer=RouteAdvisor(self.cfg,self.say) if enabled and self.scene_host is not None else None
  self.hybrid=HybridPlanner(cfg.get('camera_yaw_sign',1));self.hybrid_note=-1e9;self.hybrid_camp_check=-1e9;self.hybrid_identity_note=-1e9;self.hybrid_camp_pending=False;self.caption_latch=None;self.caption_after=0
  if self.gamepad is not None:self.gamepad.translation_lease_floor=float(self.cfg.get('smooth_translation_seconds',.75))
  # One progress watchdog owns detours. The legacy one stores screen-band IDs,
  # which are unsuitable for avoidance across camera changes.
  self.scene_pilot.follower.observe_progress=lambda *a:False
  self.say('HYBRID 0.12.1: плавные стики и мелкий поиск эфира; миникарта и сбор без ожидания модели; Qwen выбирает обход, текущая карта проходов проверяет его')
 def save_debug(self,frame,label):
  if not self.cfg.get('debug_screenshots'):return
  try:
   self.screenshot_path.mkdir(exist_ok=True)
   safe=''.join(c for c in label if c.isalnum() or c=='_')[:80]
   file=self.screenshot_path/('hybrid_'+str(time.time_ns())+'_'+safe+'.jpg')
   if not cv2.imwrite(str(file),frame,[cv2.IMWRITE_JPEG_QUALITY,90]):return
   files=sorted(self.screenshot_path.glob('hybrid_*.jpg'),key=lambda p:p.name);total=sum(p.stat().st_size for p in files)
   while files and (len(files)>60 or total>64*1024*1024):
    old=files.pop(0);total-=old.stat().st_size;old.unlink()
  except (OSError,cv2.error) as exc:self.say('DEBUG_SAVE: '+str(exc)+'; управление продолжается')

 def _needs_visual_hp(self):
  if self.network is None:return True
  if not hasattr(self.network,'confirm_own_hp'):return False
  view=self._net_view();return bool(view and view['ready'] and view['state'].own is None)
 def _health_identity_sample(self,value,captured,verified):
  if self.network is None or not hasattr(self.network,'confirm_own_hp') or not verified or value is None or value.current>=value.maximum or not self._focus_ok() or not self._needs_visual_hp():return
  self.network.confirm_own_hp(value.current,value.maximum,int((time.time()-time.monotonic()+captured)*1000))
 def _network_world_observation(self,frame):
  if self.mode=='RESCUE' and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE':
   return Observation(find_world_resource(frame,('Эфир',)),None,None,False,0,False,None,'HIDDEN')
  return super()._network_world_observation(frame)
 def _candidate_observed(self,candidate,captured,pose):
  now=time.monotonic()
  rescue=self.mode=='RESCUE' and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE'
  if (candidate.name!='Эфир' or self.caption_latch is not None or self.mode not in ('SEARCH','ACQUIRE_WAIT') and not rescue
      or self.target_confirmed or self.resource_hold or self.click_busy or self.camera_in_progress
      or self.map_active or self.hybrid_camp_pending or self.pitch.returning or self.pitch.failed or not self.cfg.get('allow_click',True)
      or now<self.caption_after or now<self.camp_exit_until or now<self.defense_evade_until
      or not self.policy.allows(candidate.name) or not self.budget.can_start()
      or not self._focus_ok() or not 0<=now-captured<=.8):return
  if any(n==candidate.name and until>now and abs(candidate.click_x-x)<80 and abs(candidate.click_y-y)<80 for n,x,y,until in self.cooldowns):return
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None or view['state'].attempt_active):return
  self.caption_latch={'candidate':candidate,'pose':pose,'until':time.monotonic()+2.5,'restored':False,'settle':0}
  self._neutral() # Stop as soon as recognition completes, not after the next full navigation tick.
  self.say('ETHER_SIGHT: подпись замечена; остановил обзор, проверяю ромбик на свежем кадре')
 def _search_caption_priority(self,obs,now):
  # A fresh world caption over sky is actionable. A ground-view repair is
  # useful for walking, but must not turn away from a verified airborne node.
  return bool(self.caption_latch is not None and now<self.caption_latch['until']
              and obs.candidate is not None and obs.candidate.name=='Эфир' and self._allowed(obs.candidate,now))
 def _motion(self,plan):
  # A recognition callback can arrive after navigation has planned a turn.
  # Do not let that pending turn sweep a newly seen caption out of view.
  if getattr(self,'caption_latch',None) is not None and self.mode in ('SEARCH','ACQUIRE_WAIT'):
   self._neutral();return True
  return super()._motion(plan)
 def _terrain_recovery_tick(self,frame,reading,now,radar=None):
  if (self.caption_latch is not None and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE'
      and not self.target_confirmed and not self.resource_hold and self._own_collection() is None):
   self._neutral();self.terrain_recovery=None;self.pitch.resume_return(now);self.change_mode('SEARCH');self.nav.pause(now)
   self.say('ETHER_SIGHT: спасательный перелёт прерван свежей подписью; проверяю ресурс без закрытия крыльев')
   return False
  return super()._terrain_recovery_tick(frame,reading,now,radar)
 def _caption_frame(self,frame,obs,now):
  latch=self.caption_latch
  if latch is None:return obs,False
  if (self.target_confirmed or self.resource_hold or self.mode not in ('SEARCH','ACQUIRE_WAIT')
      or self.map_active or not self._focus_ok() or self._own_collection() is not None):
   self.caption_latch=None;return obs,False
  if now>=latch['until']:
   self.caption_latch=None;self.caption_after=now+1;self.nav.air_since=None;self.nav.scan_kind=None
   return obs,False
  if not latch['restored']:
   self._neutral();error=latch['pose']-self.pitch.offset(now);latch['restored']=True
   if abs(error)>.006:
    seconds=min(.12,abs(error)/.45)
    self.gamepad.drive(0,0,0,.45 if error>0 else -.45,lifetime=seconds)
    latch['settle']=now+seconds+.2
    return obs,True
  if now<latch['settle']:return obs,True
  fresh=find_resource_near(frame,latch['candidate'])
  if fresh is not None:return replace(obs,candidate=fresh),False
  self._neutral();return obs,True
 def _camp_update(self,frame,radar,now):
  if not self.cfg.get('hybrid_camp_exit',True):return
  if now-self.hybrid_camp_check>=.5:
   self.hybrid_camp_check=now;anchor=purple_anchor(frame,radar.bounds)
   if anchor is not None:
    self.camp_last_seen=now
    if now>=self.camp_exit_retry_after:
     self.camp_exit_until=now+35;self.camp_exit_retry_after=now+65;self.camp_motion=0;self.hybrid_camp_pending=True
     self.say('HYBRID_CAMP_EXIT: сначала наземный выход из области кибелиска, затем ресурсы')
  if self.hybrid_camp_pending:
   self.camp_exit_until=max(self.camp_exit_until,now+.3)
   if radar.motion_valid:self.camp_motion+=math.hypot(*radar.displacement)
   if now-self.camp_last_seen>1.5 and self.camp_motion>8:
    self.camp_exit_until=0;self.hybrid_camp_pending=False;self.say('HYBRID_CAMP_EXIT: удалился по миникарте; возвращаю поиск ресурсов')
 def step(self,frame,origin,obs,radar,reading,now,sequence=0):
  if self.stop_event.is_set():return
  if self.caption_latch is not None:
   obs,waiting=self._caption_frame(frame,obs,now)
   if waiting:return
  if self.mode=='SEARCH' and not self.target_confirmed and not self.resource_hold and not reading.confirmed and not self.map_active:
   self._camp_update(frame,radar,now)
   if now<self.camp_exit_until:
    obs=replace(obs,candidate=None);radar=replace(radar,markers=[])
   if self.hybrid.active:
    # The local detour, not progress directly toward a wall-hidden goal,
    # owns the short stall timer. Keep the actual resource goal intact.
    self.nav.progress_at=now;self.nav.motion_since=now;self.nav.motion_sum=0;self.nav.motion_samples=0
  return super().step(frame,origin,obs,radar,reading,now,sequence)
 def _scene_plan(self,frame,radar,reading,plan,now):
  if (self.scene_host is None or self.cfg.get('dry_run') or self.mode!='SEARCH' or self.target_confirmed
      or self.resource_hold or self.collecting_visible or self.map_active or reading.confirmed or self.budget.airborne
      or self.camera_alignment_due or self.pitch.returning or abs(self.pitch.offset(now))>.015
      or not self._focus_ok() or abs(plan.pitch)>.001 or plan.restore_pitch or plan.flight_probe):return plan
  if gathering_panel_pair(frame):return plan
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None):return plan
  heading=radar.heading if radar.confidence>=.30 else None;pitch=self.pitch.offset(now)
  captured=time.monotonic()
  self.scene_host.offer(frame,captured,heading,pitch,self.scene_camera_epoch)
  result=self.scene_host.current(captured,heading,pitch,self.scene_camera_epoch)
  exit_mode=now<self.camp_exit_until
  if exit_mode:plan=Drive(.6,reason='ищу наземный выход из области кибелиска')
  goal=self.nav.goal
  goal_bearing=math.degrees(math.atan2(goal.x-radar.center[0],radar.center[1]-goal.y))%360 if goal else None
  context={'mode':'camp_exit' if exit_mode else 'resources','kind':goal.kind if goal else None,
           'goal_bearing':round(goal_bearing) if goal_bearing is not None else None,
           'goal_relative':round((goal_bearing-heading+180)%360-180) if goal_bearing is not None and heading is not None else None,
           'failed_bearings':[round(b) for b,t in self.hybrid.avoid if now<t]}
  hint=None;warning=None
  if self.analyzer is not None and result is not None and result.ground is not None:
   self.analyzer.offer(result.source if result.source is not None else frame,result.ground,result.captured,result.heading,result.pitch,context)
   hint=self.analyzer.recommend(result.ground,frame,captured,heading,pitch,context)
   warning=self.analyzer.warning(captured,heading,pitch,context)
  action=self.hybrid.choose(plan,result,radar,now,hint,exit_mode,warning)
  if action.recalibrate:
   if now>=self.scene_view_retry_after:
    self.scene_view_retry_after=now+3;self.scene_view_repair=True;self.nav.air_since=None;self.nav.scan_kind=None;self.view_guard.force(now)
   return Drive()
  if action.skip:
   self.nav.exclude_goal(now,25);self.nav.air_since=None;self.nav.scan_kind=None
   self.say('HYBRID_REPLAN: недоступная цель отложена; выбираю другой ресурс/наземный выход')
  if now-self.hybrid_note>=1.5:
   self.hybrid_note=now
   state='нет' if self.analyzer is None else 'занят' if self.analyzer.busy else 'ошибка' if self.analyzer.error else 'готов' if self.analyzer.ready else 'ожидание'
   self.say('HYBRID_NAV: '+action.reason+'; Qwen='+state+'; локальному кадру '+(str(round(captured-result.captured,2))+' с' if result else 'нет данных'))
  return action.drive
