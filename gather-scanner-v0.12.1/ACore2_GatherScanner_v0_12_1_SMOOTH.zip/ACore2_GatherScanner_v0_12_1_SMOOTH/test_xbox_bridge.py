"""Verified native bindings; no Lua receiver, keyboard input or bare world A."""
import threading,unittest
from types import SimpleNamespace
from unittest.mock import patch,Mock
from app import DEFAULT
from gamepad_input import GamepadInput
from hybrid_engine import HybridGatherEngine
from xbox_bridge import XboxBridge
from test_navigation import Pad

class Reports(Pad):
 def __init__(self):super().__init__();self.reports=[]
 def update(self):self.reports.append((self.buttons,self.lt,self.axes));super().update()

class NativeBindings(unittest.TestCase):
 def setUp(self):
  self.pad=Reports();self.control=GamepadInput(factory=lambda:self.pad,a_button=0x1000);self.control.native_cursor=True
  self.control.motion_worker=object();self.stop=threading.Event();self.focus=True;self.menu=False;self.log=[]
  self.bridge=XboxBridge(self.control,self.stop,lambda:self.focus,lambda:self.menu,logger=self.log.append)
  self.addCleanup(self.control.close)
 def send(self,name,authorize=None):
  with patch.object(GamepadInput,'wait',return_value=True):return self.bridge.send(name,authorize)
 def pressed(self):return [b for b,lt,axes in self.pad.reports if b]
 def test_confirmed_plain_bindings_have_no_cursor_modifiers(self):
  for name,button in [('TAB',0x80),('V',0x8000),('END_AIR',0x8000),('JUMP',0x4000),('MAP',0x10),('MOUNT',0x40)]:
   with self.subTest(name=name):
    self.pad.reports=[];self.assertTrue(self.send(name));self.assertEqual(self.pressed(),[button])
    self.assertTrue(all(lt==0 and axes==(0,0,0,0) for b,lt,axes in self.pad.reports))
    self.assertEqual(self.pad.buttons,0)
 def test_attack_pair_uses_only_single_target_rb_twice(self):
  self.assertTrue(self.send('ATTACK_PAIR',lambda:True));self.assertEqual(self.pressed(),[0x200,0x200])
  self.assertTrue(all(lt==0 for b,lt,axes in self.pad.reports));self.assertEqual(self.pad.presses,0)
 def test_aggressor_authorization_is_checked_again_before_second_attack(self):
  count=[0]
  def allowed():return count[0]==0
  original=self.control.tap_button
  def attack(*a,**kw):
   sent=original(*a,**kw);count[0]+=1;return sent
  with patch.object(self.control,'tap_button',side_effect=attack):self.assertFalse(self.send('ATTACK_PAIR',allowed))
  self.assertEqual(self.pressed(),[0x200])
 def test_internal_alt_names_hold_lb_lt_without_windows_alt_or_a(self):
  self.assertTrue(self.send('ALT_DOWN'));self.assertTrue(self.bridge.alt_is_down())
  self.assertEqual(self.pad.buttons,0x100);self.assertEqual(self.pad.lt,1);self.assertEqual(self.pad.presses,0)
  self.assertTrue(self.send('ALT_UP'));self.assertFalse(self.bridge.alt_is_down());self.assertEqual(self.pad.buttons,0)
 def test_world_a_remains_blocked_without_cursor_chord(self):
  self.assertFalse(self.control.tap_a(self.stop,lambda:True));self.assertEqual(self.pad.presses,0)
  with self.assertRaises(ValueError):self.control.tap_button(0x1000,self.stop,lambda:True)
 def test_a_in_cursor_mode_has_lb_lt_in_every_down_report(self):
  self.send('ALT_DOWN')
  with patch.object(GamepadInput,'wait',return_value=True):self.assertTrue(self.control.tap_a(self.stop,lambda:True))
  reports=[(b,lt) for b,lt,axes in self.pad.reports if b&0x1000]
  self.assertTrue(reports);self.assertTrue(all(b&0x100 and lt==1 for b,lt in reports))
 def test_world_f_and_unguarded_map_f_do_not_press_b(self):
  for name in ('F_ON','TAP_F'):self.assertFalse(self.send(name,lambda:True))
  self.menu=True;self.assertFalse(self.send('TAP_F',lambda:True));self.assertEqual(self.pressed(),[])
 def test_b_confirm_requires_armed_current_map_and_fresh_authorization(self):
  self.menu=True;self.assertTrue(self.send('MAP_UI_ARM',lambda:True))
  self.assertFalse(self.send('TAP_F'));self.assertFalse(self.send('TAP_F',lambda:False))
  self.assertEqual(self.pressed(),[]);self.assertTrue(self.send('TAP_F',lambda:True));self.assertEqual(self.pressed(),[0x2000])
  self.menu=False;self.assertFalse(self.send('TAP_F',lambda:True))
 def test_confirmation_closing_its_own_dialog_is_not_reported_as_failed_delivery(self):
  self.menu=True;self.send('MAP_UI_ARM',lambda:True)
  def accepted(hold,stop,focused):self.menu=False;return focused()
  with patch.object(GamepadInput,'wait',side_effect=accepted):self.assertTrue(self.bridge.send('TAP_F',lambda:self.menu))
  self.assertEqual(self.pressed(),[0x2000]);self.assertEqual(self.pad.buttons,0)
 def test_ui_a_accepts_expected_menu_change_after_the_authorized_down_report(self):
  self.menu=True
  def changed(hold,stop,focused):self.menu=False;return focused()
  with patch.object(GamepadInput,'wait',side_effect=changed):self.assertTrue(self.control.tap_ui_a(self.stop,lambda:self.focus,lambda:self.menu))
  self.assertEqual(self.pressed(),[0x1000]);self.assertEqual(self.pad.buttons,0)
 def test_list_scroll_is_lt_plus_right_stick_without_lb_or_a(self):
  self.menu=True;self.send('MAP_UI_ARM',lambda:True)
  for name,sign in [('MAP_SCROLL_UP',1),('MAP_SCROLL_DOWN',-1)]:
   self.pad.reports=[];self.assertTrue(self.send(name,lambda:True))
   moves=[(b,lt,axes) for b,lt,axes in self.pad.reports if abs(axes[3])>.1]
   self.assertEqual(len(moves),1);b,lt,axes=moves[0]
   self.assertEqual((b,lt,axes[:3]),(0,1,(0,0,0)));self.assertGreater(axes[3]*sign,0)
   self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.lt,0)
 def test_failed_ui_check_sends_no_list_scroll(self):
  self.menu=True;self.send('MAP_UI_ARM',lambda:True)
  self.assertFalse(self.send('MAP_SCROLL_DOWN',lambda:False));self.assertEqual(self.pressed(),[]);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_stop_releases_cursor_and_revokes_map_confirmation(self):
  self.menu=True;self.send('MAP_UI_ARM',lambda:True);self.send('ALT_DOWN');self.stop.set()
  self.assertTrue(self.send('STOP'));self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.lt,0)
  self.assertEqual(self.bridge.map_armed_until,0);self.assertFalse(self.send('V'))
 def test_focus_loss_and_withdrawn_authorization_cannot_press_actions(self):
  self.focus=False;self.assertFalse(self.send('JUMP'))
  self.focus=True;self.assertFalse(self.send('V',lambda:False));self.assertEqual(self.pressed(),[])
 def test_button_and_list_scroll_always_release_after_interruption(self):
  def interrupted(*a):self.stop.set();return False
  with patch.object(GamepadInput,'wait',side_effect=interrupted):self.assertFalse(self.bridge.send('JUMP'))
  self.assertEqual(self.pad.buttons,0);self.stop.clear();self.menu=True;self.send('MAP_UI_ARM',lambda:True)
  with patch.object(GamepadInput,'wait',side_effect=interrupted):self.assertFalse(self.bridge.send('MAP_SCROLL_UP',lambda:True))
  self.assertEqual(self.pad.lt,0);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_unknown_command_and_aoe_trigger_are_not_exposed(self):
  for name in ('RT','ATTACK_AOE','A'):
   with self.assertRaises(ValueError):self.send(name)
 def test_movement_renewal_cannot_extend_a_held_action_past_its_watchdog(self):
  def stalled_wait(*args):
   end=self.control.action_deadline;self.control.drive(.6,lifetime=.85)
   with self.control.lock:self.control._expire_motion(end+.01)
   self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.axes,(0,0,0,0));return False
  with patch.object(GamepadInput,'wait',side_effect=stalled_wait):self.assertFalse(self.bridge.send('JUMP'))
 def test_pointer_position_does_not_press_any_controller_button(self):
  self.bridge.cursor(234,456);self.assertTrue(self.bridge.cursor_matches())
  self.assertEqual(self.bridge.last_cursor_target,(234,456));self.assertEqual(self.pressed(),[])

class NativeEngine(unittest.TestCase):
 def setUp(self):
  self.pad=Reports();self.control=GamepadInput(factory=lambda:self.pad,a_button=0x1000);self.control.motion_worker=object();self.addCleanup(self.control.close)
  cfg={**DEFAULT,'scene_navigation_enabled':False,'analyzer_enabled':False,'network_enabled':False}
  self.log=[]
  with patch('gather_engine.GHubBridge',side_effect=AssertionError('Lua bridge constructed')):
   self.engine=HybridGatherEngine(cfg,self.log.append,self.control)
  self.engine.screen=SimpleNamespace(focused=lambda:True)
 def test_default_engine_creates_no_ghub_transport(self):
  self.assertIsInstance(self.engine.bridge,XboxBridge);self.assertTrue(self.control.native_cursor)
 def test_preflight_only_sends_cursor_chord_reports_not_gameplay_actions(self):
  with patch.object(GamepadInput,'wait',return_value=True):self.assertTrue(self.engine._preflight_receiver())
  self.assertTrue(self.engine.receiver_ready);self.assertEqual(self.pad.presses,0)
  self.assertTrue(all(b in (0,0x100) for b,lt,axes in self.pad.reports));self.assertEqual(self.pad.lt,0)
 def test_native_a_gate_uses_cursor_report_instead_of_physical_alt(self):
  self.engine.bridge.cursor(123,234)
  self.assertFalse(self.engine._a_input_ready())
  with patch.object(GamepadInput,'wait',return_value=True):self.engine.bridge.send('ALT_DOWN')
  self.assertTrue(self.engine._a_input_ready())
 def test_camera_entry_releases_native_cursor_without_any_keyboard_action(self):
  with patch.object(GamepadInput,'wait',return_value=True):self.engine.bridge.send('ALT_DOWN')
  self.assertTrue(self.engine._camera_input_ready());self.assertFalse(self.engine.bridge.alt_is_down())
  self.assertEqual(self.pad.lt,0);self.assertEqual(self.pad.buttons,0)

if __name__=='__main__':unittest.main()
