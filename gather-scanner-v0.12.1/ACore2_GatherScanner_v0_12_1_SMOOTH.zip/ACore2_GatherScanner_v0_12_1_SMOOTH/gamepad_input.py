"""Virtual Xbox A transport. Keyboard actions stay on the existing G HUB bridge."""
import os
import threading
import time


class GamepadInput:
    def __init__(self, dry_run=False, logger=None, factory=None, a_button=None):
        self.dry_run = dry_run
        self.log = logger or (lambda _: None)
        self.lock = threading.RLock()
        self.pad = None
        self.motion_deadline=None;self.action_deadline=None
        self.translation_deadline=None;self.camera_deadline=None;self.translation_lease_floor=0.
        self.translation=(0.,0.)
        self.yaw_deadline=None;self.right_pitch=0
        self.motion_worker=None
        self.motion_listener=None
        self.camera_gate=None;self.translation_gate=None;self.motion_audit=None;self.a_gate=None
        self.native_cursor=False;self.cursor_held=False;self.cursor_deadline=None;self.cursor_button=0x0100
        self.a_down_count=0
        self.closing=threading.Event()
        self.button = a_button
        if dry_run:
            return
        if factory is None:
            if os.name != 'nt':
                raise RuntimeError('Виртуальный Xbox требует Windows и ViGEmBus')
            try:
                import vgamepad as vg
            except Exception as exc:
                raise RuntimeError('Не удалось подключить vgamepad/ViGEmBus: ' + str(exc)) from exc
            factory, self.button = vg.VX360Gamepad, vg.XUSB_BUTTON.XUSB_GAMEPAD_A
            self.cursor_button=vg.XUSB_BUTTON.XUSB_GAMEPAD_LEFT_SHOULDER
        self.pad = factory()
        self.reset()
        self.log('Виртуальный Xbox подключён; F710 и мышь с макросом не нужны')

    def reset(self):
        with self.lock:
            self.motion_deadline=None;self.action_deadline=None;self.translation_deadline=None;self.camera_deadline=None;self.yaw_deadline=None;self.right_pitch=0
            self.cursor_held=False;self.cursor_deadline=None
            self.translation=(0.,0.)
            if self.pad is not None:
                self.pad.reset()
                self.pad.update()
                if self.motion_listener:self.motion_listener(0,time.monotonic(),0)

    def drive(self,forward=0.0,strafe=0.0,yaw=0.0,pitch=0.0,lifetime=.4,yaw_lifetime=None):
        """Short renewable motion lease; a stalled vision loop cannot hold a stick forever."""
        if self.dry_run or self.closing.is_set():return False
        if (abs(forward)>.001 or abs(strafe)>.001) and self.translation_gate is not None:
            if not self.translation_gate():
                self.reset();return False
        if (abs(yaw)>.001 or abs(pitch)>.001) and self.camera_gate is not None:
            if not self.camera_gate():
                self.reset();return False
        with self.lock:
            if self.closing.is_set():return False
            self.pad.left_joystick_float(x_value_float=max(-1,min(1,strafe)),y_value_float=max(-1,min(1,forward)))
            self.pad.right_joystick_float(x_value_float=max(-1,min(1,yaw)),y_value_float=max(-1,min(1,pitch)))
            self.pad.update()
            now=time.monotonic();lease=max(.02,min(.85,lifetime))
            self.translation=(max(-1,min(1,forward)),max(-1,min(1,strafe)))
            translation_lease=max(lease,min(.8,self.translation_lease_floor)) if abs(forward)+abs(strafe)>.001 else lease
            self.translation_deadline=now+translation_lease;self.camera_deadline=now+lease
            self.motion_deadline=now+max(lease,translation_lease)
            self.right_pitch=max(-1,min(1,pitch))
            self.yaw_deadline=(now+max(.02,min(lease,yaw_lifetime))
                               if yaw_lifetime is not None and abs(yaw)>.001 else None)
            if self.motion_listener:self.motion_listener(pitch,now,lease)
            if self.motion_audit:self.motion_audit(forward,strafe,yaw,pitch,lease)
            if self.motion_worker is None:
                self.motion_worker=threading.Thread(target=self._motion_watchdog,daemon=True)
                self.motion_worker.start()

    def current_translation(self):
        with self.lock:
            if self.translation_deadline is None or time.monotonic()>=self.translation_deadline:return (0.,0.)
            return self.translation

    def stop_camera(self):
        """Stop look immediately without extending or dropping the walking lease."""
        with self.lock:
            self.camera_deadline=None;self.yaw_deadline=None;self.right_pitch=0
            if self.pad is not None:
                self.pad.right_joystick_float(x_value_float=0,y_value_float=0);self.pad.update()
            if self.motion_listener:self.motion_listener(0,time.monotonic(),0)

    def _expire_motion(self,now):
        # Invoked under lock; camera, translation and yaw have separate ends.
        if self.action_deadline is not None and now>=self.action_deadline:self.reset();return
        if self.cursor_deadline is not None and now>=self.cursor_deadline:
            self.reset();self.log('NATIVE_CURSOR: срок удержания LB+LT истёк; всё отпущено');return
        if self.motion_deadline is not None and now>=self.motion_deadline:self.reset();return
        if self.translation_deadline is not None and now>=self.translation_deadline:
            self.translation_deadline=None;self.translation=(0.,0.)
            self.pad.left_joystick_float(x_value_float=0,y_value_float=0);self.pad.update()
        if self.camera_deadline is not None and now>=self.camera_deadline:self.stop_camera()
        elif self.yaw_deadline is not None and now>=self.yaw_deadline:
            self.yaw_deadline=None
            self.pad.right_joystick_float(x_value_float=0,y_value_float=self.right_pitch);self.pad.update()

    def _motion_watchdog(self):
        while not self.closing.wait(.005):
            with self.lock:
                try:self._expire_motion(time.monotonic())
                except Exception as exc:
                    self.reset();self.log('Не удалось завершить ввод: '+str(exc))

    def close(self):
        self.closing.set()
        self.reset()

    def tap_button(self,button,stop,focused,authorize=lambda:True,hold=.12):
        """Plain action report. A is deliberately excluded: use cursor/UI A."""
        if button not in (0x0002,0x0010,0x0040,0x0080,0x0200,0x2000,0x4000,0x8000):raise ValueError('Unsupported plain Xbox action')
        if stop.is_set() or not focused() or not authorize() or self.closing.is_set():return False
        if self.dry_run:return True
        hold=max(.02,min(.25,hold))
        try:
            with self.lock:
                self.reset()
                if stop.is_set() or not focused() or not authorize() or self.closing.is_set():return False
                self.pad.press_button(button=button);self.pad.update()
                self.action_deadline=time.monotonic()+hold+.15
                if self.motion_worker is None:
                    self.motion_worker=threading.Thread(target=self._motion_watchdog,daemon=True);self.motion_worker.start()
            # A discrete press may close its own dialog or kill its target.
            # Revalidate before DOWN, then guard the hold by focus/stop only.
            return self.wait(hold,stop,lambda:focused() and not self.closing.is_set())
        finally:self.reset()

    def scroll_map_list(self,direction,stop,focused,authorize):
        """Verified map list only: LT + right stick; never flight/camera input."""
        if direction not in (-1,1):raise ValueError(direction)
        if stop.is_set() or not focused() or not authorize() or self.closing.is_set():return False
        if self.dry_run:return True
        try:
            with self.lock:
                self.reset()
                if stop.is_set() or not focused() or not authorize() or self.closing.is_set():return False
                self.pad.left_trigger_float(value_float=1.)
                self.pad.right_joystick_float(x_value_float=0,y_value_float=.65*direction);self.pad.update()
                self.action_deadline=time.monotonic()+.37
                if self.motion_worker is None:
                    self.motion_worker=threading.Thread(target=self._motion_watchdog,daemon=True);self.motion_worker.start()
            return self.wait(.22,stop,lambda:focused() and authorize())
        finally:self.reset()

    def begin_cursor(self,stop,focused):
        """The game's flight UI requires LB+LT for controller cursor mode."""
        if not self.native_cursor:return True
        if stop.is_set() or not focused() or self.closing.is_set():return False
        if self.dry_run:return True
        with self.lock:
            if self.cursor_held:
                self.cursor_deadline=time.monotonic()+2
                return True
            self.reset()
            try:
                self.pad.press_button(button=self.cursor_button)
                self.pad.left_trigger_float(value_float=1.)
                self.pad.update()
                self.cursor_held=True;self.cursor_deadline=time.monotonic()+2
                if self.motion_worker is None:
                    self.motion_worker=threading.Thread(target=self._motion_watchdog,daemon=True);self.motion_worker.start()
            except Exception:
                self.reset();raise
        self.log('NATIVE_CURSOR: LB+LT нажаты; A ещё не нажата')
        if not self.wait(.14,stop,focused):self.reset();return False
        return self.cursor_held and not stop.is_set() and focused()

    def release_cursor(self):
        if self.cursor_held:
            self.reset();self.log('NATIVE_CURSOR: LB+LT отпущены')

    @staticmethod
    def wait(seconds, stop, focused):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if stop.is_set() or not focused():
                return False
            if stop.wait(min(.02, max(0, end-time.monotonic()))):
                return False
        return not stop.is_set() and focused()

    def tap_a(self, stop, focused, hold=.18):
        if stop.is_set() or not focused():
            return False
        if self.dry_run:
            self.log('СИМУЛЯЦИЯ Xbox A')
            return True
        completed=False
        try:
            def allowed():return focused() and (self.a_gate is None or self.a_gate())
            with self.lock:
                if stop.is_set() or not allowed():
                    return False
                if self.native_cursor:
                    if not self.cursor_held:
                        self.log('NATIVE_CURSOR: голый A запрещён; сначала требуется LB+LT');return False
                    self.cursor_deadline=time.monotonic()+max(2.,hold+.3)
                else:self.reset()
                self.pad.press_button(button=self.button)
                self.a_down_count+=1
                self.pad.update()
            completed = self.wait(hold, stop, allowed)
        finally:
            # Also reset when update failed after partially delivering a report.
            keep=False
            try:
                if self.native_cursor and self.cursor_held and not stop.is_set() and focused():
                    with self.lock:
                        self.pad.release_button(button=self.button);self.pad.update()
                    keep=completed and self.wait(.04,stop,focused)
            finally:
                if not keep:self.reset()
        if completed:
            self.log(('Xbox TX: LB+LT+A; A нажата/отпущена в режиме курсора' if self.native_cursor
                      else 'Xbox TX: A нажата/отпущена; подтверждение цели — по изображению'))
        return completed

    def tap_ui_a(self,stop,focused,authorize,hold=.12):
        """Plain A in a verified menu. Never inherits flight cursor modifiers."""
        if stop.is_set() or not focused() or not authorize():return False
        if self.dry_run:return True
        completed=False
        try:
            with self.lock:
                self.reset()
                if stop.is_set() or not focused() or not authorize():return False
                self.pad.press_button(button=self.button);self.a_down_count+=1;self.pad.update()
            completed=self.wait(hold,stop,lambda:focused() and not self.closing.is_set())
        finally:self.reset()
        if completed:self.log('MAP_UI: обычная A нажата/отпущена; успех проверяется по следующему кадру')
        return completed

    def double_a(self, stop, focused, gap=.32, before_second=None):
        if not self.tap_a(stop, focused):
            return False
        if not self.wait(gap, stop, focused):
            return False
        if before_second is not None:
            before_second()
        return self.tap_a(stop, focused)

    def tap_dpad_down(self,stop,focused,authorize=lambda:True,hold=.12):
        """One plain D-pad Down; never inherits LB/LT or cursor modifiers."""
        if stop.is_set() or not focused() or not authorize():return False
        if self.dry_run:return True
        completed=False
        try:
            with self.lock:
                self.reset()
                if stop.is_set() or not focused() or not authorize():return False
                self.pad.press_button(button=0x0002);self.pad.update()
            completed=self.wait(hold,stop,lambda:focused() and authorize())
        finally:self.reset()
        self.log('Xbox TX: D-pad Down нажата/отпущена; результат свитка ещё не подтверждён')
        return completed


class TranslationKeeper:
    """Renew an ALREADY ACTIVE ground patrol translation during G HUB writes.

    Never invents forward movement, never renews yaw/pitch, and expires even
    if its caller stalls. The predicate is checked under the gamepad lock so
    a concurrent Stop/reset cannot be followed by another motion report.
    """
    def __init__(self,pad,translation,allowed):
        self.pad=pad;self.translation=translation;self.allowed=allowed
        self.cancel=threading.Event();self.deadline=time.monotonic()+16.5
        self.worker=threading.Thread(target=self._run,daemon=True)
    def start(self):self.worker.start()
    def _run(self):
        try:
            while True:
                with self.pad.lock:
                    if (self.cancel.is_set() or self.pad.closing.is_set()
                        or time.monotonic()>=self.deadline or not self.allowed()):return
                    self.pad.drive(self.translation[0],self.translation[1],0,0,lifetime=.35)
                if self.cancel.wait(.08):return
        except Exception as exc:self.pad.log('Продление движения в защите остановлено: '+str(exc))
    def close(self):
        self.cancel.set()
        if self.worker.ident is not None and self.worker is not threading.current_thread():self.worker.join(timeout=.5)
        self.pad.reset()
