"""Named map teleport. Relative UI regions, fresh OCR, finite commands; no world XY guesses."""
from dataclasses import dataclass
import re
import cv2,numpy as np,pytesseract
from vision import _ocr_text

DEFAULT_DESTINATION='Временный приют'

def canonical(text):
 s=text.lower().replace('ё','е').translate(str.maketrans({'e':'е','o':'о','p':'р','c':'с','a':'а','x':'х','k':'к','m':'м','t':'т','b':'в','h':'н'}))
 return re.sub(r'[\W_]+','',s)

def exact_name(text,name,index=False):
 if index:text=re.sub(r'^\s*\d+\s*[.)]?\s*','',text)
 return canonical(text)==canonical(name)

@dataclass(frozen=True)
class Line:
 text:str
 box:tuple
 @property
 def point(self):
  x,y,w,h=self.box;return (round(x+w/2),round(y+h/2))

def lines(frame,region,threshold=150,hide_gold=False):
 h,w=frame.shape[:2];x0,y0,x1,y1=[round(v*size) for v,size in zip(region,(w,h,w,h))]
 crop=frame[y0:y1,x0:x1];gray=cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY)
 if hide_gold and crop.size:
  gold=cv2.inRange(cv2.cvtColor(crop,cv2.COLOR_BGR2HSV),(12,100,140),(40,255,255));gray[gold>0]=0
 if gray.size==0:return []
 image=cv2.resize(cv2.threshold(gray,threshold,255,cv2.THRESH_BINARY)[1],None,fx=1.5,fy=1.5)
 try:data=pytesseract.image_to_data(image,lang='rus',config='--oem 3 --psm 11',output_type=pytesseract.Output.DICT,timeout=1.2)
 except RuntimeError as exc:
  if 'timeout' in str(exc).lower():return []
  raise
 groups={}
 for i,word in enumerate(data['text']):
  if not word.strip() or float(data['conf'][i])<25:continue
  key=(data['block_num'][i],data['par_num'][i],data['line_num'][i])
  groups.setdefault(key,[]).append((word,data['left'][i]/1.5+x0,data['top'][i]/1.5+y0,data['width'][i]/1.5,data['height'][i]/1.5))
 out=[]
 for words in groups.values():
  words.sort(key=lambda item:item[1]);left=min(a[1] for a in words);top=min(a[2] for a in words)
  right=max(a[1]+a[3] for a in words);bottom=max(a[2]+a[4] for a in words)
  out.append(Line(' '.join(a[0] for a in words),(left,top,right-left,bottom-top)))
 return out

def is_map(frame):
 h,w=frame.shape[:2]
 if h<100 or w<200:return False
 # The world-map title and its own tab must both be present.
 top=lines(frame,(0,0,.46,.12));text=canonical(' '.join(l.text for l in top))
 return 'карта' in text and 'кибелиск' in text

@dataclass
class MapObservation:
 opened:bool=False
 row:tuple|None=None
 icon:tuple|None=None
 popup:bool=False
 destination:str=''
 confirm:tuple|None=None
 popup_box:tuple|None=None
 list_first:int|None=None
 list_last:int|None=None
 list_signature:object=None
 loading:bool=False
 arrived:bool=False
 usable:bool=False
 dialog:bool=False

def confirmation_dialog(frame,destination):
 # The voucher option opens a SECOND, central confirmation modal.
 # Exclude the voucher picture/count below the question from exact-name OCR.
 title=lines(frame,(.24,.38,.77,.445),140)
 wanted=canonical('Телепортироваться в зону '+destination)
 if canonical(' '.join(l.text for l in title))!=wanted:return None
 cancel=lines(frame,(.33,.55,.50,.64),140)
 if not any(canonical(l.text)=='отмена' for l in cancel):return None
 buttons=lines(frame,(.50,.55,.65,.64),140,hide_gold=True)
 ok=next((l for l in buttons if canonical(l.text).endswith('ок') and len(canonical(l.text))<=4),None)
 if ok is None:return None
 h,w=frame.shape[:2];crop=frame[round(h*.57):round(h*.62),round(w*.51):round(w*.63)]
 gold=cv2.inRange(cv2.cvtColor(crop,cv2.COLOR_BGR2HSV),(12,100,140),(40,255,255))
 if np.mean(gold>0)<.18:return None
 return MapObservation(opened=True,popup=True,destination=destination,confirm=ok.point,popup_box=title[0].box,dialog=True)

def observe(frame,destination,phase,loading=False,arrived=False,usable=False):
 dialog=confirmation_dialog(frame,destination)
 if dialog is not None:return dialog
 opened=is_map(frame);out=MapObservation(opened=opened,loading=loading,arrived=arrived,usable=usable)
 if not opened or phase=='WAIT_TRANSFER':return out
 h,w=frame.shape[:2]
 popup=lines(frame,(.70,.28,.995,.88),110,hide_gold=True)
 titles=[l for l in popup if exact_name(l.text,destination)]
 active=any(canonical(l.text)=='активирован' for l in popup)
 buttons=[l for l in popup if canonical(l.text).startswith(('переместиться','переместить'))]
 if titles and active and buttons:
  title=titles[0];button=next((l for l in buttons if h*.15<l.point[1]-title.point[1]<h*.35),None)
  if button:
   out.popup=True;out.destination=destination;out.popup_box=title.box
   # F is the gold teleport-voucher option shown by the game. The ordinary
   # blue button alone does not prove that the F option is available.
   cy=button.point[1];crop=frame[max(0,round(cy-h*.035)):min(h,round(cy+h*.035)),round(w*.865):round(w*.99)]
   if crop.size:
    hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV);gold=cv2.inRange(hsv,(12,100,140),(40,255,255))
    if np.mean(gold>0)>.10:out.confirm=button.point
   return out
 if phase in ('FIND','WAIT_ROW','WAIT_SCROLL','OPEN','WAIT_OPEN'):
  listing=lines(frame,(0,.13,.225,.97),110);numbers=[]
  for l in listing:
   match=re.match(r'^\s*(\d+)\s*[.)]',l.text)
   if match:numbers.append(int(match[1]))
   if exact_name(l.text,destination,True):out.row=l.point
  if numbers:out.list_first=min(numbers);out.list_last=max(numbers)
  crop=frame[round(h*.15):round(h*.96),:round(w*.23)]
  out.list_signature=cv2.resize(cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY),(24,40))
 if phase=='FIND_ICON':
  names=[l for l in lines(frame,(.235,.13,.99,.96),190) if exact_name(l.text,destination)]
  hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV);mask=cv2.inRange(hsv,(125,65,95),(168,255,255));mask[:,:round(w*.24)]=0
  count,_,stats,centers=cv2.connectedComponentsWithStats(mask)
  for label in names:
   candidates=[]
   for i in range(1,count):
    x,y=centers[i];area=stats[i,cv2.CC_STAT_AREA]
    if w*h*.00001<area<w*h*.012 and abs(x-label.point[0])<w*.12 and -h*.14<y-label.point[1]<0:
     candidates.append(((x-label.point[0])**2+(y-label.point[1]+h*.06)**2,(round(x),round(y))))
   if candidates:out.icon=min(candidates)[1];break
 return out

@dataclass
class MapAction:
 kind:str='WAIT'
 point:tuple|None=None
 direction:int=0
 reason:str=''

class MapTeleport:
 def __init__(self,now,destination=DEFAULT_DESTINATION,index=13):
  self.destination=destination;self.index=index;self.phase='OPEN';self.started=now;self.since=now
  self.scrolls=0;self.clicks=0;self.icon_clicks=0;self.unchanged=0;self.signature=None
  self.loading_seen=False;self.arrival_since=None;self.used=False;self.failure='';self.dialog_used=False
 def to(self,phase,now):self.phase=phase;self.since=now
 def sent(self,now):self.since=now
 def fail(self,reason):self.phase='FAILED';self.failure=reason;return MapAction('FAILED',reason=reason)
 def step(self,now,o):
  if self.phase=='FAILED':return MapAction('FAILED',reason=self.failure)
  if self.phase=='DONE':return MapAction('DONE')
  if now-self.started>75:return self.fail('за 75 с безопасный телепорт не подтверждён; повтор свитка запрещён')
  if self.phase=='WAIT_TRANSFER':
   if o.dialog and not self.dialog_used and o.confirm is not None and exact_name(o.destination,self.destination):
    self.dialog_used=True;self.since=now;return MapAction('CONFIRM_DIALOG',o.confirm)
   self.loading_seen|=o.loading
   if not o.opened and o.usable and (o.arrived or self.loading_seen and now-self.since>=5):
    if self.arrival_since is None:self.arrival_since=now
    if now-self.arrival_since>=.7:self.phase='DONE';return MapAction('DONE',reason='выбранный телепорт и прибытие подтверждены')
   else:self.arrival_since=None
   if now-self.since>20:return self.fail('20 с после подтверждения: прибытие не доказано, повторного нажатия нет')
   return MapAction()
  if self.phase=='OPEN':
   if o.opened:self.to('FIND',now)
   else:self.to('WAIT_OPEN',now);return MapAction('OPEN')
  if self.phase=='WAIT_OPEN':
   if o.opened:self.to('FIND',now)
   elif now-self.since>5:return self.fail('карта не распознана после M; проверьте G HUB')
   else:return MapAction()
  if not o.opened:return self.fail('карта исчезла до подтверждения; клик отменён')
  if o.popup:
   if not exact_name(o.destination,self.destination) or o.confirm is None:return self.fail('название назначения или доступная золотая кнопка F не подтверждены')
   self.used=True;self.dialog_used=o.dialog;self.to('WAIT_TRANSFER',now);return MapAction('CONFIRM_DIALOG' if o.dialog else 'CONFIRM',o.confirm)
  if self.phase=='WAIT_ROW':
   if now-self.since<2:return MapAction()
   self.to('FIND_ICON',now)
  if self.phase=='WAIT_ICON':
   if now-self.since<3:return MapAction()
   return self.fail('окно назначения не открылось после клика по значку')
  if self.phase=='FIND_ICON':
   if o.icon is not None and self.icon_clicks==0:
    self.icon_clicks+=1;self.to('WAIT_ICON',now);return MapAction('ICON',o.icon)
   if now-self.since>5:return self.fail('после выбора строки не найден подписанный значок нужного кибелиска')
   return MapAction()
  if self.phase=='WAIT_SCROLL':
   if now-self.since<.6:return MapAction()
   if self.signature is not None and o.list_signature is not None:
    same=float(np.mean(np.abs(o.list_signature.astype(float)-self.signature.astype(float))))<2
    self.unchanged=self.unchanged+1 if same else 0
   if self.unchanged>=2:return self.fail('список не прокручивается: проверьте курсор над списком и управление прокруткой')
   self.to('FIND',now)
  if self.phase=='FIND':
   if o.row is not None:
    self.clicks+=1;self.to('WAIT_ROW',now);return MapAction('ROW',o.row)
   if self.scrolls>=12:return self.fail('нужное имя не найдено в списке за 12 прокруток')
   direction=1 if o.list_first is not None and o.list_first>self.index else -1
   self.signature=o.list_signature;self.scrolls+=1;self.to('WAIT_SCROLL',now)
   return MapAction('SCROLL',direction=direction)
  return MapAction()


def menu_stamp(frame):
 h,w=frame.shape[:2]
 return tuple(cv2.resize(cv2.threshold(cv2.cvtColor(frame[round(h*a):round(h*b),round(w*c):round(w*d)],cv2.COLOR_BGR2GRAY),175,255,cv2.THRESH_BINARY)[1],(120,30)) for a,b,c,d in ((.01,.06,.025,.24),(.067,.105,.35,.44)))

def same_stamp(frame,reference):
 if reference is None:return False
 current=menu_stamp(frame)
 return all(np.count_nonzero(a)>8 and np.count_nonzero(b)>8 and np.count_nonzero((a>0)&(b>0))/max(1,np.count_nonzero((a>0)|(b>0)))>.60 for a,b in zip(current,reference))

def title_stamp(frame,box):
 x,y,w,h=map(round,box);crop=frame[max(0,y):y+h,max(0,x):x+w]
 if crop.size==0:return None
 return cv2.resize(cv2.threshold(cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY),150,255,cv2.THRESH_BINARY)[1],(160,32))
