"""A boss card opened by OUR resource map click; one ordinary move-button A."""
from dataclasses import dataclass
import cv2,numpy as np
from map_teleport import lines,canonical,title_stamp
from map_surface import card_open

@dataclass(frozen=True)
class BossCard:
 name:str
 title_box:tuple
 button_box:tuple
 title:object
 button:object
 shape:tuple
 @property
 def point(self):
  x,y,w,h=self.button_box;return round(x+w/2),round(y+h/2)

def observe(frame):
 if not card_open(frame):return None
 title=lines(frame,(.755,.16,.985,.225),125)
 body=canonical(' '.join(l.text for l in lines(frame,(.755,.25,.985,.355),125)))
 if not title or 'оставшеесявремя' not in body or 'основныхтрофеях' not in body:return None
 buttons=lines(frame,(.79,.81,.96,.925),125)
 button=next((l for l in buttons if canonical(l.text) in ('переместиться','fпереместиться')),None)
 if button is None:return None
 left=min(l.box[0] for l in title);top=min(l.box[1] for l in title)
 right=max(l.box[0]+l.box[2] for l in title);bottom=max(l.box[1]+l.box[3] for l in title)
 box=(left,top,right-left,bottom-top);a=title_stamp(frame,box);b=title_stamp(frame,button.box)
 if a is None or b is None or np.count_nonzero(a)<8 or np.count_nonzero(b)<8:return None
 return BossCard(' '.join(l.text for l in title),box,button.box,a,b,frame.shape)

def same(frame,card):
 if frame.shape!=card.shape:return False
 for box,old in ((card.title_box,card.title),(card.button_box,card.button)):
  current=title_stamp(frame,box)
  if current is None or np.count_nonzero(current)<8:return False
  if np.count_nonzero((current>0)&(old>0))/max(1,np.count_nonzero((current>0)|(old>0)))<.75:return False
 return True
