"""Temporary, resource-specific negative observations; never depletion.

Only misses and own positive proof write state. Planning reads frozen records.
"""
from dataclasses import dataclass
from pathlib import Path
import json,logging,math

@dataclass(frozen=True)
class Miss:
 name:str
 reference:tuple
 radius:float
 count:int
 until:float
 observed:float
 wall:float

def blocked(goal,records,now):
 for m in records:
  if m.name!=goal.name or now>=m.until or math.dist(goal.reference,m.reference)>m.radius:continue
  key=goal.key
  if (goal.live and isinstance(key,tuple) and len(key)>=4 and key[0]=='node'
      and isinstance(key[3],(int,float)) and key[3]>m.wall):continue
  return True
 return False

class MissCache:
 def __init__(self,path=None):
  self.records=();self.scope=None;self.path=Path(path) if path is not None else None;self.rows=[]
  try:
   if self.path is not None and self.path.exists() and self.path.stat().st_size<=262144:
    data=json.loads(self.path.read_text(encoding='utf-8'))
    if data.get('version')==1 and isinstance(data.get('records'),list):
     for row in data['records'][:512]:
      if not isinstance(row,dict):continue
      name,point,radius,count,wall,expiry,scope=(row.get(k) for k in ('name','reference','radius','count','wall','expiry','scope'))
      numeric=(radius,wall,expiry)
      if (not isinstance(name,str) or len(name)>100 or not isinstance(scope,str) or len(scope)>1000
          or not isinstance(point,list) or len(point)!=2 or not all(isinstance(v,(int,float)) and math.isfinite(v) and abs(v)<1e7 for v in point)
          or not all(isinstance(v,(int,float)) and math.isfinite(v) for v in numeric)
          or not 0<radius<=1000 or type(count) is not int or not 1<=count<=3 or not 0<expiry-wall<=900001):continue
      self.rows.append(row)
  except (OSError,ValueError,TypeError,AttributeError):self.rows=[]
 def context(self,scope,now,wall):
  scope=json.dumps(scope,separators=(',',':'),ensure_ascii=False)
  if scope==self.scope:return
  self.scope=scope;records=[]
  for row in self.rows:
   age=(wall-row['wall'])/1000;remaining=(row['expiry']-wall)/1000
   if row['scope']==scope and 0<=age<1800 and remaining<=900:
    records.append(Miss(row['name'],tuple(row['reference']),row['radius'],row['count'],now+remaining,now-age,row['wall']))
  self.records=tuple(records)
 def _save(self,now,wall):
  if self.path is None or self.scope is None:return
  self.rows=[r for r in self.rows if r['scope']!=self.scope and 0<=wall-r['wall']<1800000]
  self.rows.extend(dict(scope=self.scope,name=m.name,reference=list(m.reference),radius=m.radius,count=m.count,
                        wall=m.wall,expiry=wall+(m.until-now)*1000) for m in self.records if 0<=now-m.observed<1800)
  self.rows=self.rows[-512:]
  temp=self.path.with_suffix('.tmp')
  try:
   temp.write_text(json.dumps(dict(version=1,records=self.rows),ensure_ascii=False),encoding='utf-8');temp.replace(self.path)
  except OSError as ex:logging.warning('MAP_SKIP_STATE: не удалось сохранить временные пропуски: %s',ex)
 def fail(self,goal,now,wall,scale):
  radius=max(1,abs(scale)*300)
  old=next((m for m in self.records if m.name==goal.name and math.dist(goal.reference,m.reference)<=max(m.radius,radius) and now-m.observed<1800),None)
  count=min(3,old.count+1 if old else 1);seconds=300*count
  self.records=(tuple(m for m in self.records if 0<=now-m.observed<1800 and m is not old)+(Miss(goal.name,tuple(goal.reference),radius,count,now+seconds,now,wall),))[-128:]
  self._save(now,wall);return seconds
 def success(self,goal,now=None,wall=None):
  records=tuple(m for m in self.records if m.name!=goal.name or math.dist(goal.reference,m.reference)>m.radius)
  if records==self.records:return
  self.records=records
  if now is not None and wall is not None:self._save(now,wall)
 def blocked(self,goal,now):return blocked(goal,self.records,now)
