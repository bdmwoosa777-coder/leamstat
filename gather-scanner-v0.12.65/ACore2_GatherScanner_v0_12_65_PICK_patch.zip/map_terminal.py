"""Bounded final approach AFTER game path arrival, using a current minimap.

No map clicks or resource actions here. A visible caption immediately gives
control to the existing native selection/collection state machine.
"""
from dataclasses import replace
import math
from navigation import Drive,Navigator
from minimap import angle_delta
from camera_control import PITCH_STRENGTH

class FinalApproach:
 def __init__(self,goal,position=None,destination_check=False):
  self.goal=goal;self.position=position;self.marker=None;self.authorized_until=0.
  self.walked=0.;self.turns=0.;self.next_action=0.;self.last_sent=None
  self.best=None;self.stalls=0;self.heading_search=0;self.ground_sweep_pending=False
  # Preserve the old full vertical scan, but approach and face the CURRENT
  # minimap icon before starting it. No random patrol steering.
  self.sky=Navigator({'ether_quick_search':True}) if 'эфир' in goal.name.lower() else None
  self.sky_stage='SCAN';self.sky_round=0;self.finished=False
  self.destination_scan=bool(destination_check and self.sky is not None);self.destination_done=False
  self.finished_reason='полный вертикальный осмотр завершён'
  self.adjust_turns=0;self.adjust_steps=0;self.adjust_side=0
  self.steering=Navigator({'camera_settle_seconds':.30});self.last_plan_yaw=0.;self.last_plan_seconds=0.
  self.destination_absent_since=None;self.destination_absent_frames=0;self.destination_verified=False
  self.close_done=False;self.close_heading=None;self.close_heading_at=0;self.close_best=None;self.close_stalls=0;self.close_steps=0;self.close_evaluated=0

 def permits_translation(self,now):return now<=self.authorized_until and self.authorized_until>0 and self.walked<self.walk_limit
 @property
 def walk_limit(self):return 10. if self.sky is not None else 2.2
 def revoke(self):self.authorized_until=0.
 def marker_for(self,radar):
  if radar is None:return None
  kind='aether' if 'эфир' in self.goal.name.lower() else 'gem'
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  options=[m for m in radar.markers if m.kind==kind and m.distance<=90*scale]
  if not options:return None
  if self.marker is not None:
   dx,dy=radar.displacement if radar.motion_valid else (0,0)
   near=[m for m in options if math.hypot(m.x-self.marker.x-dx,m.y-self.marker.y-dy)<=15*scale]
   if not near:return None # Do not jump between neighbouring resource marks.
   chosen=min(near,key=lambda m:math.hypot(m.x-self.marker.x-dx,m.y-self.marker.y-dy))
  else:
   chosen=min(options,key=lambda m:m.distance)
  self.marker=replace(chosen);return chosen
 def plan(self,radar,now,pitch,working_ms=1200):
  self.revoke()
  ether='эфир' in self.goal.name.lower()
  if ether:return self._ether_plan(radar,now,pitch,working_ms)
  self.ground_sweep_pending=False
  if radar is None:return Drive(reason='MAP_FINAL_WAIT: жду свежую миникарту')
  if now<self.next_action:return Drive(reason='MAP_FINAL_HOLD: выдерживаю ракурс для распознавания')
  # An absent/overlapped ground mark must not lock an upward Ether pose.
  if abs(pitch)>.02:
   return Drive(pitch=-math.copysign(PITCH_STRENGTH,pitch),lifetime=min(.30,abs(pitch)/PITCH_STRENGTH),
                local_approach=True,reason='MAP_FINAL_GROUND_VIEW: возвращаю наземный ресурс в обзор')
  marker=self.marker_for(radar)
  if marker is None:
   if self.heading_search>=4:
    self.finished=True;self.finished_reason='наземная точка осмотрена без подписи и свежей отметки'
    return Drive(reason='MAP_GROUND_DONE: '+self.finished_reason)
   self.ground_sweep_pending=True
   return Drive(yaw=.48,lifetime=.40,yaw_lifetime=.40,local_approach=True,
                reason='MAP_GROUND_SCAN: нет отметки; осматриваю подпись/значок в мире, без движения вслепую')
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  distance=math.hypot(marker.x-radar.center[0],marker.y-radar.center[1])/scale
  if self.best is None or distance<self.best-1:self.best=distance;self.stalls=0
  if now<self.next_action:return Drive(reason='MAP_FINAL_HOLD: сохраняю ракурс для распознавания')
  heading=radar.heading if radar.confidence>=.30 else None
  bearing=math.degrees(math.atan2(marker.x-radar.center[0],radar.center[1]-marker.y))%360
  error=angle_delta(bearing,heading) if heading is not None else None
  if distance>5 and (error is None or abs(error)>18):
   if self.turns>=4:return Drive(reason='MAP_FINAL_WAIT: предел поворота, жду новое распознавание')
   if error is None:
    if self.heading_search>=2:return Drive(reason='MAP_FINAL_WAIT: конус камеры не подтверждён')
    yaw=.48;seconds=.35
   else:yaw=math.copysign(.48,error);seconds=min(.65,max(.18,abs(error)/130))
   return Drive(yaw=yaw,lifetime=seconds,yaw_lifetime=seconds,local_approach=True,
                reason='MAP_FINAL_AIM: поворачиваю камеру к отметке наземного ресурса')
  if abs(pitch)>.02:
   return Drive(pitch=-math.copysign(PITCH_STRENGTH,pitch),lifetime=min(.30,abs(pitch)/PITCH_STRENGTH),
                local_approach=True,reason='MAP_FINAL_GROUND_VIEW: возвращаю наземный ресурс в обзор')
  if distance>5 and self.walked<2.2 and self.stalls<3 and error is not None:
   seconds=min(.45,2.2-self.walked);self.authorized_until=now+.45
   return Drive(forward=.5,lifetime=seconds,tilted_motion=True,local_approach=True,
                reason='MAP_FINAL_CLOSE: коротко сближаюсь с отметкой наземного ресурса')
  return Drive(reason='MAP_FINAL_HOLD: держу ресурс в секторе камеры, жду подпись')
 @property
 def scan_pending(self):return self.sky is not None and not self.finished
 def _restart_sky(self,now):
  self.sky.scan_last_pulse=-1;self.sky.scan_next_at=now
  self.sky.scan_pitch=0;self.sky.scan_pulse_end=now;self.sky_stage='SCAN'
 def needs_steering(self,radar):
  if self.destination_scan:return False # Inspect the actual destination before walking to another icon.
  marker=self.marker_for(radar)
  if marker is None or self.finished:return False
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  error,half,_=self.steering.cone_view(radar,marker)
  return (not self.close_done and marker.distance>10*scale) or marker.distance>3*scale and error is not None and abs(error)>min(18,half-6)
 def _close_to_marker(self,radar,now,pitch):
  marker=self.marker_for(radar)
  if marker is None:return Drive(reason='MAP_NEAR_WAIT: нет свежей иконки; вертикальный поиск без направления запрещён')
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  distance=math.hypot(marker.x-radar.center[0],marker.y-radar.center[1])/scale
  if self.close_best is None or distance<self.close_best-1:self.close_best=distance;self.close_stalls=0
  elif self.close_steps>self.close_evaluated:self.close_stalls+=1
  self.close_evaluated=self.close_steps
  # Real approach, then FACE the current icon before looking up. The previous
  # strafe-only controller never changed camera direction.
  if radar.heading is None or radar.confidence<.30:
   return Drive(reason='MAP_NEAR_WAIT: конус камеры не подтверждён; движения вслепую нет')
  if self.close_heading is not None and abs(angle_delta(radar.heading,self.close_heading))>35:
   self.close_heading=radar.heading;self.close_heading_at=now+.15
   return Drive(reason='MAP_NEAR_WAIT: скачок конуса; подтверждаю следующим кадром')
  self.close_heading=radar.heading
  if now<self.close_heading_at:return Drive(reason='MAP_NEAR_WAIT: жду новый кадр конуса')
  bearing=math.degrees(math.atan2(marker.x-radar.center[0],radar.center[1]-marker.y))%360
  error,half,_=self.steering.cone_view(radar,marker)
  aligned=distance<=3 or abs(error)<=min(18,half-6)
  if distance<=10 and aligned:self.close_done=True;return None
  if self.walked>=self.walk_limit or self.close_stalls>=30:
   # Exhausting WALKING must not suppress LOOKING once the icon is near.
   # This reproduces the live 64 -> 13 px / 10 s case from the user log.
   if distance<=30 and aligned:self.close_done=True;return None
   self.finished=True;self.finished_reason='лимит подхода; свежая иконка ещё далеко или вне направления камеры'
   return Drive(reason='MAP_NEAR_BLOCKED: '+self.finished_reason)
  plan=self.steering._move_to(bearing,radar.heading,now,'MAP_NEAR_CLOSE: к текущей иконке '+str(round(distance,1))+' px и камера к ресурсу')
  if distance<=10:plan=replace(plan,forward=0,strafe=0,reason='MAP_NEAR_AIM: разворачиваю камеру к эфиру перед подъёмом')
  self.authorized_until=now+.45
  return replace(plan,lifetime=min(.45,self.walk_limit-self.walked),tilted_motion=True,local_approach=True)
 def _ether_plan(self,radar,now,pitch,working_ms):
  if self.finished:return Drive(reason='MAP_ETHER_DONE: '+self.finished_reason)
  if self.destination_scan:
   if not self.destination_verified:
    marker=self.marker_for(radar)
    scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313) if radar is not None else 1.
    if not self.goal.live and marker is not None and marker.distance>30*scale:
     marker=None;self.marker=None # A distant Ether does not confirm this destination.
    if marker is None and not self.goal.live and not getattr(radar,'center_obscured',False):
     if radar is not None:
      if self.destination_absent_since is None:self.destination_absent_since=now
      self.destination_absent_frames+=1
      if self.destination_absent_frames>=3 and now-self.destination_absent_since>=.6:
       self.finished=True;self.destination_scan=False;self.finished_reason='в справочной точке нет текущей отметки эфира'
       return Drive(reason='MAP_DESTINATION_ABSENT: '+self.finished_reason+'; пропускаю пустой осмотр')
     return Drive(reason='MAP_DESTINATION_VERIFY: проверяю наличие эфира на миникарте до подъёма камеры')
    self.destination_absent_since=None;self.destination_absent_frames=0
    if marker is not None and marker.distance>3*max(.5,(radar.bounds[2]-radar.bounds[0])/313):
     error,half,_=self.steering.cone_view(radar,marker)
     if error is None:return Drive(reason='MAP_DESTINATION_AIM_WAIT: жду направление камеры перед подъёмом')
     if abs(error)>min(18,half-6):
      if self.heading_search>=24:
       self.finished=True;self.finished_reason='не удалось направить конус к эфиру';return Drive(reason='MAP_DESTINATION_AIM_LIMIT')
      seconds=min(.4,max(.10,abs(error)/160))
      return Drive(yaw=math.copysign(.48,error),lifetime=seconds,yaw_lifetime=seconds,local_approach=True,
                   reason='MAP_DESTINATION_AIM: сначала поворачиваю камеру к эфиру, затем осмотр вверх')
    self.destination_verified=True
   if now<self.next_action:return Drive(reason='MAP_DESTINATION_HOLD: сохраняю ракурс в точке прибытия')
   self.sky.scan_quick_total=max(.65,min(2.,working_ms/1000))
   plan=self.sky._wide_air_scan(now)
   if not plan.restore_pitch:return replace(plan,local_approach=True,reason='MAP_DESTINATION_SCAN: осмотр в точке автопути; '+plan.reason)
   self.destination_scan=False;self.destination_done=True;self.sky_round=1;self._restart_sky(now)
   return replace(plan,flight_probe=False,local_approach=True,reason='MAP_DESTINATION_EMPTY: полный осмотр точки выполнен; проверяю возможность местного подхода')
  if self.marker_for(radar) is None or radar.heading is None or radar.confidence<.30:
   if self.destination_done:
    self.finished=True;self.finished_reason='точка осмотрена; свежая отметка/конус для продолжения не появились'
   return Drive(reason='MAP_NEAR_WAIT: нет текущей иконки или направления камеры; не осматриваю пустой сектор')
  if now<self.next_action:return Drive(reason='MAP_ETHER_HOLD: сохраняю кадр для прежнего сканера')
  if not self.close_done or self.needs_steering(radar):
   nearby=self._close_to_marker(radar,now,pitch)
   if nearby is not None:return nearby
  if self.sky_stage=='SCAN':
   # Use the user's whole working-view interval, not the old far-search cap
   # of 0.70/0.88 s. At 1200 ms the UP reports total 1200 ms at strength .45.
   self.sky.scan_quick_total=max(.65,min(2.,working_ms/1000))
   plan=self.sky._wide_air_scan(now)
   if not plan.restore_pitch:
    return replace(plan,local_approach=True,reason='MAP_ETHER_SCAN: '+plan.reason)
   self.sky_round+=1
   if self.sky_round>=2:
    self.finished=True
    return Drive(reason='MAP_ETHER_DONE: два полных осмотра без подписи; следующая цель')
   self.sky_stage='ADJUST'
   return Drive(reason='MAP_ETHER_HOLD: полный обзор вверх-вниз выполнен; проверяю свежую отметку')
  marker=self.marker_for(radar)
  at_goal=False # World/catalogue arrival alone does not prove icon proximity.
  error=None;distance=0
  if marker is not None:
   scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
   distance=math.hypot(marker.x-radar.center[0],marker.y-radar.center[1])/scale
   if self.best is None or distance<self.best-1:self.best=distance;self.stalls=0
   if radar.heading is not None and radar.confidence>=.30:
    bearing=math.degrees(math.atan2(marker.x-radar.center[0],radar.center[1]-marker.y))%360
    error=angle_delta(bearing,radar.heading)
  if (not at_goal and marker is not None and distance>5 and error is not None
      and abs(error)<=18 and self.adjust_steps<5 and self.walked<self.walk_limit and self.stalls<3):
   self.authorized_until=now+.45
   return Drive(forward=.5,lifetime=min(.45,self.walk_limit-self.walked),tilted_motion=True,local_approach=True,
                reason='MAP_FINAL_CLOSE: после полного осмотра коротко подхожу по свежей отметке')
  if self.adjust_turns<3:
   side=1 if error is None or error>=0 else -1
   if not self.adjust_side:self.adjust_side=side
   # Stop on overshoot or cone jitter; never alternate left/right commands.
   if self.adjust_turns and error is not None and (side!=self.adjust_side or abs(error)<=18):
    self._restart_sky(now)
   elif error is None or abs(error)>18 or at_goal:
    return Drive(yaw=.30*self.adjust_side,lifetime=.18,yaw_lifetime=.18,local_approach=True,
                 reason='MAP_ETHER_SECTOR: один ограниченный поворот перед повторным полным осмотром')
   else:self._restart_sky(now)
  else:self._restart_sky(now)
  return self._ether_plan(radar,now,pitch,working_ms)
 def delivered(self,forward,strafe,yaw,pitch,seconds,now):
  if abs(forward)+abs(strafe)+abs(yaw)+abs(pitch)<=.001:return
  if abs(forward)+abs(strafe)>.001:
   self.walked+=min(seconds,max(0,now-self.last_sent)) if self.last_sent is not None else seconds;self.stalls+=1
   if self.sky is not None:
    self.adjust_steps+=1;self.close_steps+=1
  if abs(yaw)>.001:
   self.turns+=seconds;self.heading_search+=1
   if self.sky is not None:self.adjust_turns+=1
   self.steering.camera_delivered(now,seconds)
  self.last_sent=now
  self.next_action=now+seconds+.20 if abs(pitch)>.001 or self.ground_sweep_pending and abs(yaw)>.001 else now
