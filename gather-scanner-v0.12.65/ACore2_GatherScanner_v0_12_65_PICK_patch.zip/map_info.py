"""Descriptive zone cards are not routes. Close only a detected card X."""
from dataclasses import dataclass
import math
import cv2,numpy as np
from map_teleport import lines,canonical,title_stamp

def panel_visible(frame):
 h,w=frame.shape[:2];crop=frame[round(h*.22):round(h*.87),round(w*.77):round(w*.97)]
 if not crop.size:return False
 v=crop.max(axis=2);chroma=crop.max(axis=2).astype(np.int16)-crop.min(axis=2)
 return np.mean((v>20)&(v<105)&(chroma<65))>=.62

@dataclass(frozen=True)
class InfoCard:
 box:tuple
 signature:object
 shape:tuple
 close:tuple|None

def cross(frame):
 h,w=frame.shape[:2];x0,y0=round(w*.925),round(h*.16);x1,y1=round(w*.98),round(h*.235)
 crop=frame[y0:y1,x0:x1];unit=w/2048
 if not crop.size:return None
 gray=cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY);mask=cv2.threshold(gray,170,255,cv2.THRESH_BINARY)[1]
 segments=cv2.HoughLinesP(mask,1,np.pi/180,max(5,round(8*unit)),minLineLength=max(5,round(10*unit)),maxLineGap=max(2,round(3*unit)))
 if segments is None:return None
 diagonals=[]
 for x,y,a,b in segments[:,0]:
  dx,dy=a-x,b-y
  if abs(dx)<4*unit or not .55<abs(dy/dx)<1.8:continue
  if math.hypot(dx,dy)>55*unit:continue
  diagonals.append(((x+a)/2,(y+b)/2,1 if dx*dy>0 else -1))
 points=[((p[0]+q[0])/2,(p[1]+q[1])/2) for p in diagonals for q in diagonals if p[2]!=q[2] and math.dist(p[:2],q[:2])<=5*unit]
 if not points:return None
 x,y=max(points,key=lambda p:p[0]);return round(x0+x),round(y0+y)

def observe(frame):
 if not panel_visible(frame):return None
 labels=lines(frame,(.76,.25,.985,.675),125);text=canonical(' '.join(l.text for l in labels))
 if 'описаниезоны' not in text or not ('орегионе' in text or 'исследованиезоны' in text):return None
 label=next((l for l in labels if 'описаниезоны' in canonical(l.text)),None)
 if label is None:return None
 sig=title_stamp(frame,label.box)
 if sig is None or np.count_nonzero(sig)<8:return None
 return InfoCard(label.box,sig,frame.shape,cross(frame))

def same(frame,card):
 if frame.shape!=card.shape:return False
 current=title_stamp(frame,card.box)
 if current is None:return False
 return np.count_nonzero((current>0)&(card.signature>0))/max(1,np.count_nonzero((current>0)|(card.signature>0)))>.75 and cross(frame)==card.close
