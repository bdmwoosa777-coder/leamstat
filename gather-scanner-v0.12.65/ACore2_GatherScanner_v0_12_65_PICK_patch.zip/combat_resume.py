"""Private resource identity across combat; no input authority in this module."""
from dataclasses import dataclass

@dataclass
class CombatResource:
 flow:int
 owner:int
 actor:int
 generation:int
 template:int|None
 map_id:int|None
 name:str
 marker_key:tuple|None
 view:object=None
 pending:dict|None=None
 until:float=0
 after:float=0
 pause_at:float|None=None
 misses:int=0
 view_returned:bool=False
 view_return_at:float|None=None
 def node(self,view):
  if not view or not view['ready'] or view['flow']!=self.flow:return None
  s=view['state'];node=s.nodes.get(self.actor)
  if (s.own!=self.owner or self.map_id is not None and s.map_id is not None and s.map_id!=self.map_id
      or self.actor in s.npcs or self.actor in s.players or self.actor in s.deaths or node is None
      or not node.visible or node.used not in (0,1,2) or node.removed_reason==4
      or self.generation and node.generation and node.generation!=self.generation
      or self.template is not None and node.template is not None and node.template!=self.template):return None
  return node
 def arm(self,now):self.pending=None;self.until=now+8;self.after=now;self.pause_at=None;self.view_returned=False;self.view_return_at=None
 def pause(self,now):
  if self.pause_at is None:self.pause_at=now
 def resume(self,now):
  if self.pause_at is not None:
   gap=max(0,now-self.pause_at);self.until+=gap;self.after+=gap
   if self.pending:self.pending['until']+=gap
   self.pause_at=None

class UnownedFlightGate:
 def __init__(self):self.reset()
 def reset(self):self.since=None;self.last=None;self.hits=0;self.counted=None
 def observe(self,reading,now):
  if (not reading.confirmed or reading.swimming or reading.evidence<150
      or reading.energy is None or reading.energy<=1):self.reset();return False
  if self.last is None or not 0<=now-self.last<=.8:self.since=now;self.hits=0;self.counted=None
  if self.counted is None or now-self.counted>=.10:self.hits+=1;self.counted=now
  self.last=now
  return self.hits>=3 and now-self.since>=.6
