"""Map terrain lease outside the cursor hover; no keyboard or gameplay actions."""
import math
from dataclasses import dataclass
import cv2,numpy as np
from map_teleport import menu_stamp,same_stamp,lines,canonical

@dataclass
class TerrainLease:
 shape:tuple
 header:object
 tiles:tuple
 @classmethod
 def capture(cls,frame,point):
  h,w=frame.shape[:2];tiles=[];radius=max(55,round(w*.045))
  for fy in np.linspace(.22,.82,5):
   for fx in np.linspace(.28,.91,6):
    x,y=round(w*fx),round(h*fy)
    if math.hypot(x-point[0],y-point[1])<radius:continue
    patch=frame[y-12:y+13,x-12:x+13]
    if patch.shape[:2]!=(25,25):continue
    tiles.append((x,y,cv2.cvtColor(patch,cv2.COLOR_BGR2GRAY)))
  return cls(frame.shape,menu_stamp(frame),tuple(tiles))
 def matches(self,frame):
  if frame.shape!=self.shape or not same_stamp(frame,self.header) or len(self.tiles)<12:return False
  stable=0
  for x,y,old in self.tiles:
   fresh=cv2.cvtColor(frame[y-12:y+13,x-12:x+13],cv2.COLOR_BGR2GRAY)
   stable+=float(np.abs(fresh.astype(np.int16)-old).mean())<5
  return stable>=max(12,math.ceil(len(self.tiles)*.88))

def card_open(frame):
 h,w=frame.shape[:2];crop=frame[round(h*.22):round(h*.87),round(w*.77):round(w*.97)]
 if not crop.size:return False
 v=crop.max(axis=2);chroma=crop.max(axis=2).astype(np.int16)-crop.min(axis=2)
 if np.mean((v>20)&(v<105)&(chroma<65))<.62:return False
 return any('перемест' in canonical(l.text) for l in lines(frame,(.76,.76,.98,.94),125))

def map_title_matches(frame,reference):
 current=menu_stamp(frame)[0];old=reference[0]
 return current.shape==old.shape and np.count_nonzero(current)>8 and np.count_nonzero((current>0)&(old>0))/max(1,np.count_nonzero((current>0)|(old>0)))>.70

def kibelisk_tab(frame):
 return next((l for l in lines(frame,(.31,.055,.455,.115),105) if canonical(l.text)=='кибелиск'),None)

def icon_at(frame,point):
 """Conservative hit-test for a compact dark/coloured POI under a map click."""
 h,w=frame.shape[:2];unit=w/2048;r=round(65*unit);px,py=point
 x0,y0=max(0,px-r),max(0,py-r);crop=frame[y0:min(h,py+r+1),x0:min(w,px+r+1)]
 if not crop.size:return True
 hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV);gray=cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY)
 dark=np.where((gray>8)&(gray<70),255,0).astype(np.uint8)
 colour=cv2.inRange(hsv,(115,105,95),(175,255,255)) # Purple UI wings/boss badges, not terrain.
 mask=cv2.morphologyEx(dark|colour,cv2.MORPH_CLOSE,np.ones((3,3),np.uint8))
 contours,_=cv2.findContours(mask,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
 for c in contours:
  x,y,rw,rh=cv2.boundingRect(c);area=cv2.contourArea(c)
  if not (12*unit<=max(rw,rh)<=100*unit and min(rw,rh)>=8*unit and area>=60*unit*unit):continue
  if x0+x-3*unit<=px<=x0+x+rw+3*unit and y0+y-3*unit<=py<=y0+y+rh+3*unit:return True
 return False
