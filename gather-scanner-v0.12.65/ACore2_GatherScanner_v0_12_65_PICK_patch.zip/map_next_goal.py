"""Read-only preparation during OWN gathering; no engine/input/screen access."""
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
import math
import numpy as np
from map_coordinates import MapGoal
from map_reference import transform
from map_misses import blocked as missed_goal

@dataclass(frozen=True)
class LivePoint:
 actor:int
 generation:int
 template:int|None
 name:str|None
 xyz:tuple|None
 visible:bool
 used:int|None
 removed:int|None
 excluded:bool=False

@dataclass(frozen=True)
class PlanRequest:
 context:tuple
 origin:tuple
 anchor:tuple
 created:float
 names:frozenset
 prefer_air:bool
 allow_air:bool
 live:tuple
 cooldown:tuple=()
 locations:tuple=()
 farm_center:tuple|None=None
 farm_radius:float=450.
 misses:tuple=()
 observed_names:frozenset=frozenset()

@dataclass(frozen=True)
class PlanResult:
 context:tuple
 origin:tuple
 anchor:tuple
 created:float
 catalogue:tuple
 ranked:tuple

class NextGoalPlanner:
 def __init__(self,sources,matrix):
  self.sources=tuple(sources);self.matrix=np.array(matrix,dtype=float,copy=True)
  self.matrix.setflags(write=False)
  self.catalogue=None;self.future=None;self.closed=False
  self.executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='next-resource')
 def submit(self,request):
  if self.closed or self.future is not None:return False
  self.future=self.executor.submit(self.calculate,request);return True
 def poll(self):
  if self.closed or self.future is None or not self.future.done():return None
  future=self.future;self.future=None
  return future.result()
 def close(self):
  if self.closed:return
  self.closed=True
  if self.future is not None:self.future.cancel()
  self.executor.shutdown(wait=False,cancel_futures=True)
 def calculate(self,r):
  if self.catalogue is None:
   self.catalogue=tuple(MapGoal(('spawn',str(t),*xyz[:2]),name,transform(xyz[:2],self.matrix),xyz)
                        for t,name,xyz in self.sources)
  k=float(self.matrix[0,0]);center=transform(r.anchor,self.matrix)
  cooldown=dict(r.cooldown);known=[n for n in r.live if n.xyz is not None]
  current=next((n for n in r.live if (n.actor,n.generation)==r.origin),None)
  def allowed(g):
   if missed_goal(g,r.misses,r.created):return False
   names=r.observed_names if g.live and r.observed_names else r.names
   if g.name not in names or not r.allow_air and 'эфир' in g.name.lower():return False
   if cooldown.get(g.key,0)>r.created:return False
   if any(until>r.created and math.dist(g.reference,point)<max(4,abs(k)*300) for point,until in r.locations):return False
   farm=r.farm_center or center
   return math.dist(g.reference,farm)<=r.farm_radius*100*k
  goals=[]
  for n in known:
   if (n.excluded or not n.visible or n.used==3 or n.removed==4 or (n.actor,n.generation)==r.origin):continue
   goal=MapGoal(('node',r.context[2],n.actor,n.generation),n.name,transform(n.xyz[:2],self.matrix),n.xyz,True)
   if allowed(goal):goals.append(goal)
  for g in self.catalogue:
   template=int(g.key[1])
   if current and current.name==g.name and math.dist(current.xyz[:2] if current.xyz is not None else r.anchor,g.xyz[:2])<200:continue
   if any(n.template==template and (n.visible or n.used==3 or n.removed==4) and math.dist(n.xyz,g.xyz)<200 for n in known):continue
   if allowed(g):goals.append(g)
  observed=[g for g in goals if g.live]
  if observed:goals=observed
  goals.sort(key=lambda g:(0 if not r.prefer_air or 'эфир' in g.name.lower() else 1,
                           math.dist(g.reference,center),0 if g.live else 1))
  return PlanResult(r.context,r.origin,r.anchor,r.created,self.catalogue,tuple(goals[:8]))
