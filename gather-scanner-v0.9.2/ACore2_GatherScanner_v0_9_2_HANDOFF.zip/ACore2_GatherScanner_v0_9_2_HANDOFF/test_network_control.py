import copy,json,threading,time,unittest
from pathlib import Path
from unittest.mock import patch
from network_state import Flow,Node,Telemetry
from network_feed import NetworkFeed
from test_navigation import GatherFixture,obs
from flight import FlightReading
import gather_engine as ge

class Source:
 def __init__(self):
  self.state=Flow(own=7,selected=99,last_packet=1000,collecting=99,attempt_active=True)
  self.state.nodes[99]=Node(99,1550020,used=0,time=1000)
  self.ready=True
 def view(self):return dict(ready=self.ready,state=copy.deepcopy(self.state),flow=1,age=0,error=None)

class NetworkControls(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.clockpatch=patch.object(ge.time,'time',return_value=1.05);self.clockpatch.start();self.addCleanup(self.clockpatch.stop)
  self.source=Source();self.e.network=self.source
  self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='APPROACH'
  self.e._reset_resource_watch(True);self.e.network_target=(1,99);self.e.network_claimed_at=900
 def test_collection_started_during_selection_does_not_get_another_route_f(self):
  self.source.state.nodes[99].gather_time=1000
  self.assertTrue(self.e._start_resource_route());self.assertEqual(self.commands,[]);self.assertTrue(self.e.f_on)
 def test_received_zero_energy_on_ground_cannot_be_replaced_by_regen_estimate(self):
  self.source.state.flight=0;self.source.state.flight_maximum=10000;self.source.state.flight_at=1000
  self.e.budget.energy=50
  self.e._budget_update(FlightReading(None,False),100)
  self.assertEqual(self.e.budget.energy,0);self.assertFalse(self.e.budget.can_start())
 def test_known_ground_energy_does_not_remove_failed_takeoff_backoff(self):
  self.source.state.flight=10000;self.source.state.flight_maximum=10000;self.source.state.flight_at=1000
  self.e.budget.failed_takeoff(99)
  self.e._budget_update(FlightReading(None,False),100)
  self.assertFalse(self.e.budget.can_start())
 def test_resource_selected_before_its_profile_arrives_keeps_native_route(self):
  self.source.state.nodes.clear();self.e._start_resource_route()
  with patch.object(ge,'selected_target',return_value=(None,None)):
   self.step(obs(),100,plate=None)
   self.step(obs(),103,plate=None)
  self.assertEqual(self.e.mode,'APPROACH');self.assertEqual(self.commands,['TAP_F'])
 def test_character_change_stops_old_resource_controls(self):
  self.e.network_owner=7;self.source.state.own=8;self.e.f_on=True
  self.step(obs('Сапфир',distance=1),100,plate=3,panel=True)
  self.assertTrue(self.e.stop_event.is_set());self.assertIn('F_OFF',self.commands);self.assertNotIn('F_ON',self.commands)
 def test_old_selection_before_a_is_not_a_fresh_confirmation(self):
  self.e.network_selection_after=2000;self.source.state.selection_time=1000
  clock=[0]
  def tick():clock[0]+=1;return clock[0]
  with patch.object(ge.time,'monotonic',side_effect=tick),patch.object(ge.GamepadInput,'wait',return_value=True):
   self.assertFalse(self.e._net_claim())
  self.assertFalse(self.e.stop_event.is_set());self.assertNotIn('TAP_F',self.commands)
 def test_dead_attacker_does_not_trigger_more_tabs(self):
  self.source.state.attacks[55]=1000;self.source.state.npcs[55]=dict(dead=True,time=900)
  with patch.object(ge.time,'time',return_value=1.1),patch.object(self.e,'_defend_and_resume') as defense:
   self.assertFalse(self.e._check_route_damage(self.frame,100))
  defense.assert_not_called()
 def test_observation_mode_does_not_require_a_live_recorder(self):
  self.e.network=None;self.e.cfg.update(dry_run=True,network_enabled=True)
  self.e.screen.pick=lambda:'game'
  def prepared():self.e.stop_event.set();return True
  with patch.object(ge.threading,'Thread'),patch.object(self.e,'_prepare_working_view',side_effect=prepared):
   self.e.run()
  self.assertFalse(any('ОШИБКА:' in line for line in self.log))
 def test_false_visual_panel_cannot_repeat_f_before_network_start(self):
  self.e._start_resource_route()
  self.step(obs('Сапфир',distance=1),100,plate=3,panel=True)
  self.assertEqual(self.commands,['TAP_F']);self.assertFalse(self.e.real_gather_panel_seen)
 def test_native_route_sends_only_one_f_until_own_gather_proof(self):
  self.e._start_resource_route()
  for now in range(100,104):self.step(obs('Сапфир',distance=10),now,plate=3)
  self.assertEqual(self.commands,['TAP_F'])
  node=self.source.state.nodes[99];node.gather_time=1000
  self.step(obs('Сапфир',distance=1),104,plate=3)
  self.assertEqual(self.commands,['TAP_F']);self.assertEqual(self.e.mode,'GATHER')
 def test_regular_clear_selection_does_not_end_or_close_wings(self):
  node=self.source.state.nodes[99];node.gather_time=1000;node.used=1
  self.source.state.selected=0
  self.step(obs(),100,plate=None,reading=FlightReading(50,True))
  self.step(obs(),102,plate=None,reading=FlightReading(49,True))
  self.assertEqual(self.e.mode,'GATHER');self.assertNotIn('END_AIR',self.commands)
  self.assertEqual(self.commands,[]);self.assertTrue(self.e.f_on)
 def test_used_three_closes_owned_flight_once_even_when_old_header_is_visible(self):
  self.e.target='Эфир';self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
  self.e.mode='GATHER';self.e.resource_flight_owned=True
  node=self.source.state.nodes[99];node.used=3;node.gather_time=1000
  with patch.object(ge,'gathering_panel_pair',return_value=True),patch.object(ge,'segment_count',return_value=1):
   self.e._resource_fast_tick(self.frame,FlightReading(40,True),100)
  self.assertEqual(self.commands,['END_AIR']);self.assertEqual(self.e.mode,'SEARCH')
 def test_destroyed_last_attempt_ends_without_a_missing_completion_packet(self):
  self.e.mode='GATHER';self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
  node=self.source.state.nodes[99];node.used=2;node.visible=False;node.removed_reason=4
  self.step(obs(),100,plate=None)
  self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.target_confirmed)
 def test_running_own_gather_can_be_adopted_without_an_initial_route_f(self):
  self.e.mode='SEARCH';self.e.target=None;self.e.target_confirmed=False;self.e.resource_hold=False
  self.source.state.nodes[99].gather_time=1000
  self.step(obs('Сапфир',distance=1),100,plate=3,panel=True)
  self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.commands,[]);self.assertTrue(self.e.f_on)
 def test_stale_feed_releases_repeat_and_never_falls_back_to_visual_defense(self):
  self.e.f_on=True;self.source.ready=False
  self.step(obs('Сапфир',distance=1),100,plate=3,panel=True)
  self.assertEqual(self.commands,['F_OFF']);self.assertFalse(self.e.f_on)
 def test_missing_new_attempt_for_twenty_seconds_stops_instead_of_hovering_forever(self):
  node=self.source.state.nodes[99];node.gather_time=1000;self.source.state.attempt_active=False
  self.clockpatch.stop()
  with patch.object(ge.time,'time',return_value=31):
   self.step(obs('Сапфир',distance=1),130,plate=2)
  self.assertTrue(self.e.stop_event.is_set());self.assertNotIn('V',self.commands)
 def test_intermediate_foreign_selection_cannot_be_hidden_by_later_zero(self):
  node=self.source.state.nodes[99];node.gather_time=1000
  self.e.real_gather_panel_seen=True;self.e.f_on=True;self.source.state.selected=0;self.source.state.collecting=None
  self.step(obs('Сапфир',distance=1),100,plate=3)
  self.assertEqual(self.commands,['F_OFF']);self.assertEqual(self.e.mode,'REACQUIRE')
 def test_old_collection_lease_cannot_enable_f_after_reacquisition(self):
  node=self.source.state.nodes[99];node.gather_time=800
  self.e.f_enable();self.assertEqual(self.commands,[])
 def test_different_selected_actor_revokes_resource_repeats(self):
  self.e.f_on=True;self.source.state.selected=77
  self.step(obs('Сапфир',distance=1),100,plate=3)
  self.assertEqual(self.commands,['F_OFF']);self.assertEqual(self.e.mode,'REACQUIRE')
 def test_hp_fall_or_regeneration_does_not_authorize_tab(self):
  from health import HPReading
  self.e.health.numeric(self.frame,HPReading(20000,20000),99)
  self.e.health.numeric(self.frame,HPReading(19720,20000),99.1)
  self.e.health.numeric(self.frame,HPReading(20000,20000),99.2)
  with patch.object(self.e,'_defend_and_resume') as defense:self.step(obs('Сапфир',distance=10),100,plate=3)
  defense.assert_not_called();self.assertNotIn('TAB',self.commands)
 def test_actual_hit_still_authorizes_defense_after_hp_regeneration(self):
  self.source.state.attacks[55]=1000
  with patch.object(ge.time,'time',return_value=1.1),patch.object(self.e,'_defend_and_resume') as defense:
   self.e._check_route_damage(self.frame,100)
  defense.assert_called_once_with(resume=True);self.assertEqual(self.e.network_attacker,55)
 def test_targeting_own_spirit_is_not_required_to_match_player_name(self):
  self.e.network_attacker=55;self.source.state.selected=55
  self.source.state.attacks[55]=1000
  self.source.state.npcs[55]=dict(dead=False,summoned=False,hp=200)
  with patch.object(ge.GamepadInput,'wait',return_value=True):self.assertTrue(self.e._confirmed_aggressor())
  self.source.state.selected=56
  self.assertFalse(self.e._confirmed_aggressor())
 def test_only_fresh_network_maximum_sets_flight_budget(self):
  self.source.state.flight=1000;self.source.state.flight_maximum=10000;self.source.state.flight_at=1000
  self.e._budget_update(FlightReading(80,True),100)
  self.assertAlmostEqual(self.e.budget.energy,10)

class FeedTests(unittest.TestCase):
 def test_fresh_flow_permits_search_without_self_identity_but_old_data_blocks_it(self):
  feed=NetworkFeed()
  feed.ingest(dict(type='frame',flow=1,op='008d',t=1000,hex='0701010664000000'))
  self.assertTrue(feed.view(1100)['ready']);self.assertFalse(feed.view(1100)['identity_ready'])
  feed.ingest(dict(type='frame',flow=1,op='008d',t=1100,hex='0701010664000000'))
  self.assertTrue(feed.view(1150)['ready']);self.assertTrue(feed.view(1150)['identity_ready']);self.assertFalse(feed.view(5000)['ready'])
 def test_conflicting_flight_entities_revoke_a_guessed_identity(self):
  feed=NetworkFeed()
  for stamp in (1000,1100):feed.ingest(dict(type='frame',flow=1,op='008d',t=stamp,hex='0701010664000000'))
  self.assertTrue(feed.view(1150)['ready'])
  feed.ingest(dict(type='frame',flow=1,op='008d',t=1200,hex='0801010664000000'))
  self.assertFalse(feed.view(1250)['ready'])

if __name__=='__main__':unittest.main()

class TailTests(unittest.TestCase):
 def test_partial_pipe_line_waits_for_newline_then_updates_before_process_exit(self):
  import tempfile,sys,subprocess
  with tempfile.TemporaryDirectory() as directory:
   script='import sys;sys.stdout.write(\'{"type":"hello","protocol":1}\\n\');sys.stdout.flush();sys.stdin.readline();sys.stdout.write(\'{"type":"frame","flow":1,"op":"008d","t":1000,"hex":"0701010664000000"}\');sys.stdout.flush();sys.stdin.readline();sys.stdout.write("\\n");sys.stdout.flush();sys.stdin.readline()'
   feed=NetworkFeed(command=[sys.executable,'-u','-c',script]);feed.directory=Path(directory)
   feed.start()
   try:
    feed.process.stdin.write(b'next\n');feed.process.stdin.flush();time.sleep(.1)
    self.assertFalse(feed.view(1100)['ready'])
    feed.process.stdin.write(b'newline\n');feed.process.stdin.flush()
    limit=time.monotonic()+2
    while not feed.view(1100)['ready'] and time.monotonic()<limit:time.sleep(.01)
    self.assertTrue(feed.view(1100)['ready']);self.assertIsNone(feed.process.poll())
   finally:feed.close()
   self.assertFalse(feed.worker.is_alive());self.assertIsNotNone(feed.process.poll())
