import unittest,math
from unittest.mock import patch
from types import SimpleNamespace
import numpy as np,cv2
from ground_routes import build_ground_map,GroundFollower,GroundRoute,avatar_foot
from scene import interpret
from scene_navigation import SceneReading,ScenePilot,Lane
from navigation import Drive
from flight import FlightReading
from test_navigation import GatherFixture,radar
from test_network_control import Source
import gather_engine as ge

def passage():
 g=np.full((180,320),2,np.uint8)
 cv2.fillConvexPoly(g,np.array([(125,179),(195,179),(173,65),(147,65)]),1)
 d=np.repeat(np.linspace(1,10,180,dtype=np.float32)[:,None],320,axis=1)
 return g,d

class ConnectedGround(unittest.TestCase):
 def test_narrow_road_through_rock_remains_connected(self):
  g,d=passage();m=build_ground_map(g,d)
  self.assertTrue(m.routes);self.assertGreater(m.reachable,20)
  self.assertLess(min(r.endpoint[1] for r in m.routes),.48)
 def test_wall_outline_is_not_a_sector_wide_cliff(self):
  g,d=passage();d[:,:125]=50;d[:,195:]=50
  m=build_ground_map(g,d);self.assertTrue(m.routes);self.assertLess(m.drop_support,.04)
 def test_disconnected_far_floor_is_not_reached_through_a_wall(self):
  g=np.ones((180,320),np.uint8);g[107:131]=2;d=np.ones_like(g,dtype=np.float32)
  m=build_ground_map(g,d)
  self.assertTrue(all(r.endpoint[1]>.70 for r in m.routes))
 def test_depth_jump_blocks_only_that_crossing(self):
  g=np.ones((180,320),np.uint8);d=np.ones_like(g,dtype=np.float32);d[117:]=10
  m=build_ground_map(g,d)
  self.assertTrue(all(r.endpoint[1]>.64 for r in m.routes))
 def test_wall_or_sky_has_no_invented_ground_seed(self):
  for cls in (2,4):self.assertFalse(build_ground_map(np.full((180,320),cls,np.uint8),np.ones((180,320),np.float32)).routes)
 def test_level_water_remains_traversable(self):
  g,d=passage();g[:]=3;m=build_ground_map(g,d)
  self.assertTrue(m.routes);self.assertEqual(m.drop_support,0)
 def test_every_route_starts_on_the_same_near_ground_component(self):
  g,d=passage();m=build_ground_map(g,d)
  for r in m.routes:
   self.assertEqual(r.points[0],m.seed)
   self.assertTrue(all(math.isfinite(x) and math.isfinite(y) for x,y in r.points))
 def test_invalid_depth_is_not_used(self):
  with self.assertRaises(ValueError):build_ground_map(np.ones((30,40),np.uint8),np.full((30,40),np.nan))
 def test_stairs_connect_to_ground_but_rock_does_not(self):
  labels=np.zeros((180,320),np.uint8);labels[100:120]=1
  confidence=np.full(labels.shape,.8,np.float32);names={0:'road',1:'stairs'}
  groups=interpret(labels,confidence,names).groups
  self.assertTrue(build_ground_map(groups,np.ones(labels.shape,np.float32)).routes)
  groups=interpret(labels,confidence,{0:'road',1:'rock'}).groups
  self.assertFalse(any(r.endpoint[1]<.60 for r in build_ground_map(groups,np.ones(labels.shape,np.float32)).routes))
 def test_weak_surface_is_a_slow_proposal_without_analyzer_confirmation(self):
  g,d=passage();m=build_ground_map(g,d,confidence=np.full(g.shape,.3,np.float32))
  self.assertTrue(m.routes);self.assertLess(max(r.confidence for r in m.routes),.31)
  reading=SceneReading(100,0,0,1,(Lane(.5,.2,.1,0),)*3,ground=m)
  a=ScenePilot().decide(Drive(.7),reading,100,80,exit_mode=True)
  self.assertLessEqual(a.drive.forward,.35)
 def test_avatar_anchor_reports_measured_or_estimated_honestly(self):
  labels=np.zeros((180,320),np.uint8);labels[95:132,155:166]=1
  measured=avatar_foot(labels,{0:'road',1:'person'})
  self.assertIsNotNone(measured);self.assertAlmostEqual(measured[1],132/180)
  g,d=passage()
  self.assertTrue(build_ground_map(g,d,measured).anchor_measured)
  self.assertFalse(build_ground_map(g,d).anchor_measured)
  self.assertIsNone(avatar_foot(np.zeros_like(labels),{0:'road',1:'person'}))
 def test_no_connected_ground_decision_is_bounded_and_can_request_probe(self):
  wall=np.full((180,320),2,np.uint8);m=build_ground_map(wall,np.ones(wall.shape,np.float32))
  p=ScenePilot();r=SceneReading(100,0,0,1,(Lane(.1,.8,0,.1),)*3,ground=m)
  self.assertFalse(p.decide(Drive(.7),r,100,80,resource_nearby=True).fly)
  self.assertTrue(p.decide(Drive(.7),r,105,80,resource_nearby=True).fly)
  p=ScenePilot();p.decide(Drive(.7),r,100,80,exit_mode=True)
  self.assertTrue(p.decide(Drive(.7),r,105,80,exit_mode=True).abandon)
 def test_connected_road_overrides_false_lane_average_retreat(self):
  g,d=passage();m=build_ground_map(g,d);bad=Lane(.1,.8,.2,0)
  reading=SceneReading(100,0,0,1,(bad,bad,bad),ground=m)
  a=ScenePilot().decide(Drive(.7),reading,100,80,exit_mode=True)
  self.assertGreater(a.drive.forward,0);self.assertFalse(a.escape);self.assertFalse(a.fly)
 def test_analyzer_wall_warning_has_a_bounded_effect_instead_of_blind_forward_motion(self):
  g,d=passage();m=build_ground_map(g,d);p=ScenePilot()
  r=SceneReading(100,0,0,1,(Lane(.5,.2,.1,0),)*3,ground=m)
  a=p.decide(Drive(.7),r,100,80,scene_hint='wall')
  self.assertEqual(a.drive.forward,0);self.assertFalse(a.abandon)
  self.assertTrue(p.decide(Drive(.7),r,102,80,scene_hint='wall').abandon)
  self.assertGreater(p.decide(Drive(.7),r,103,80).drive.forward,0)
 def test_current_dense_route_owns_one_report_instead_of_combining_yaws(self):
  g,d=passage();m=build_ground_map(g,d);r=SceneReading(100,0,0,1,(Lane(.5,.2,.1,0),)*3,ground=m)
  a=ScenePilot().decide(Drive(.7,.1,.62),r,100,80,exit_mode=True)
  self.assertEqual(a.drive.yaw,0);self.assertGreater(a.drive.forward,0)
 def test_explicit_analyzer_route_must_still_exist(self):
  g,d=passage();m=build_ground_map(g,d);f=GroundFollower()
  selected=f.choose(m,Drive(.6),100,hint=999)
  self.assertIn(selected.id,[r.id for r in m.routes])
 def test_stationary_valid_optical_flow_excludes_failed_route(self):
  f=GroundFollower();f.route_id=2;r=radar();r.motion_valid=True
  self.assertFalse(f.observe_progress(r,100,True));self.assertTrue(f.observe_progress(r,106,True))
  self.assertGreater(f.avoid[2],110)
 def test_unknown_flow_is_not_proof_of_stagnation(self):
  f=GroundFollower();f.route_id=2
  for t in (100,106,120):self.assertFalse(f.observe_progress(radar(),t,True))
 def test_stagnation_requests_a_real_view_change_on_next_ground_decision(self):
  p=ScenePilot();p.follower.route_id=2;r=radar();r.motion_valid=True
  p.follower.observe_progress(r,100,True);p.follower.observe_progress(r,106,True)
  g,d=passage();reading=SceneReading(106,0,0,1,(Lane(.5,.2,.1,0),)*3,ground=build_ground_map(g,d))
  self.assertTrue(p.decide(Drive(.7),reading,106,80).abandon)

class GroundEngine(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e.network=self.source;self.e.mode='SEARCH';self.e.cfg['ground_route_navigation']=True
  g,d=passage();self.ground=build_ground_map(g,d)
  self.e.scene_host=SimpleNamespace(offer=lambda *a:None,current=lambda *a:SceneReading(100,0,0,1,(Lane(.1,.8,.2,0),)*3,ground=self.ground),error=None,close=lambda:None)
 def test_spawn_near_kibelisk_prioritizes_ground_exit_over_probe(self):
  with patch.object(ge,'purple_anchor',return_value=(100,100)),patch.object(ge.time,'monotonic',return_value=100):
   self.e._scene_plan(self.frame,radar(),FlightReading(None,False),Drive(.7),100)
  with patch.object(ge,'purple_anchor',return_value=(100,100)),patch.object(ge.time,'monotonic',return_value=101):
   a=self.e._scene_plan(self.frame,radar(),FlightReading(None,False),Drive(flight_probe=True),101)
  self.assertGreater(a.forward,0);self.assertFalse(a.flight_probe);self.assertGreater(self.e.camp_exit_until,120)
 def test_short_yaw_does_not_invalidate_frames_for_the_whole_walk_lease(self):
  with patch.object(ge.time,'monotonic',return_value=100):self.input.drive(.5,0,.3,0,lifetime=.65,yaw_lifetime=.07)
  self.assertLess(self.e.scene_settle_until,100.3)
 def test_failed_camp_exit_actually_changes_view_without_blind_retreat(self):
  self.e.camp_exit_until=125;self.e.camp_last_seen=100
  self.e.nav.retreat_pending=True;self.e.nav.retreat_until=130
  self.e.analyzer=SimpleNamespace(offer=lambda *a:None,current=lambda *a:SimpleNamespace(answer={'route_id':-1,'scene':'wall','reason':'no exit','aether':[]},elapsed_ms=100))
  with patch.object(ge,'purple_anchor',return_value=None),patch.object(ge.time,'monotonic',return_value=100):
   self.e._scene_plan(self.frame,radar(),FlightReading(None,False),Drive(.7),100)
  with patch.object(ge,'purple_anchor',return_value=None),patch.object(ge.time,'monotonic',return_value=102):
   a=self.e._scene_plan(self.frame,radar(),FlightReading(None,False),Drive(.7),102)
  self.assertEqual(a.forward,0);self.assertNotEqual(a.yaw,0)
  self.assertEqual(self.e.camp_exit_until,0);self.assertFalse(self.e.nav.is_retreating(102))
 def test_collection_still_has_priority_over_connected_route(self):
  self.e.target_confirmed=True;self.e.resource_hold=True
  with patch.object(ge,'purple_anchor') as anchor:
   self.e._scene_plan(self.frame,radar(),FlightReading(None,False),Drive(.7),100);anchor.assert_not_called()
 def test_vlm_box_alone_cannot_create_a_resource_click(self):
  self.e.analyzer=SimpleNamespace(current=lambda *a:SimpleNamespace(answer={'aether':[[300,300,200,100]]}))
  self.assertIsNone(self.e._analyzer_aether(self.frame));self.assertEqual(self.pad.presses,0)

if __name__=='__main__':unittest.main()
