"""User-side Ollama/GPU check. Synthetic picture only; no game capture/input."""
from pathlib import Path
import json,time
import cv2,numpy as np
from route_analyzer import LocalOllama
from ground_routes import GroundMap,GroundRoute

def main():
 root=Path(__file__).resolve().parent
 cfg=json.loads((root/'settings_gather.json').read_text(encoding='utf-8'))
 client=LocalOllama(cfg.get('analyzer_url','http://127.0.0.1:11434'),cfg.get('analyzer_model','qwen2.5vl:3b'))
 data={'model':client.model,'synthetic_image':True};started=time.monotonic()
 try:
  data['version']=client.call('/api/version',timeout=3)
  data['capabilities']=client.probe().get('capabilities',[])
  image=np.full((360,640,3),65,np.uint8)
  cv2.fillConvexPoly(image,np.array([(260,150),(380,150),(560,359),(80,359)]),(130,145,150))
  ground=GroundMap(tuple(GroundRoute(i,((.5,.75),(.25+i*.125,.43)),1,.8,2) for i in range(5)),100)
  data['answer']=client.analyze(image,ground,'test: choose the road through the central opening',timeout=30)
  data['valid_answer']=True
 except Exception as exc:data['valid_answer']=False;data['error']=str(exc)
 data['elapsed_seconds']=round(time.monotonic()-started,2)
 try:data['running_models']=client.call('/api/ps',timeout=3)
 except Exception as exc:data['gpu_check_error']=str(exc)
 path=root/'analyzer_check.json';path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(data,ensure_ascii=False,indent=2));print('Result:',path)
 print('This checks the API and GPU residency, not navigation quality in AION2.')
 return 0 if data['valid_answer'] else 1

if __name__=='__main__':raise SystemExit(main())
