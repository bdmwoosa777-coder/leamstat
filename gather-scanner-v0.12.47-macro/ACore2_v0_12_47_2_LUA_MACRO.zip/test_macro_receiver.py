from pathlib import Path
from unittest.mock import patch
import unittest
import test_map_wire47 as previous
ROOT=Path(__file__).parent
class MacroReceiver(unittest.TestCase):
 def link(self,fail=False):
  with patch.object(previous,'ROOT',ROOT):link=previous.Link()
  link.macros=[];link.aborts=[]
  def play(name):
   if fail:raise RuntimeError('macro unavailable')
   link.macros.append((link.now,name))
   for key in ('numminus','num5'):link.press(key);link.release(key)
  link.lua.globals().PlayMacro=play
  link.lua.globals().AbortMacro=lambda:link.aborts.append(link.now)
  link.lua.globals().PressAndReleaseKey=lambda key:(_ for _ in ()).throw(AssertionError('numeric keys must come from named macro'))
  return link
 def test_complete_python_to_macro_to_map_close(self):
  link=self.link()
  with link.patch():
   self.assertTrue(link.tr.ping(lambda:True).acknowledged)
   self.assertTrue(link.tr.map_toggle(lambda:True).acknowledged)
   self.assertTrue(link.tr.click(lambda:True).acknowledged)
   self.assertTrue(link.route);self.assertTrue(link.tr.map_toggle(lambda:True).acknowledged);link.tr.close()
  self.assertEqual([name for _,name in link.macros],['AION_MAP_RMB']);self.assertFalse(link.map);self.assertFalse(link.held)
  self.assertFalse(any(k in (144,'numlock') for _,_,k in link.events))
 def test_ping_does_not_start_a_macro(self):
  link=self.link()
  with link.patch():self.assertTrue(link.tr.ping(lambda:True).acknowledged)
  self.assertEqual(link.macros,[])
 def test_three_separate_click_commands_dispatch_three_one_shots(self):
  link=self.link();link.map=True
  with link.patch():
   link.tr.ping(lambda:True)
   for _ in range(3):self.assertTrue(link.tr.click(lambda:True).acknowledged)
  self.assertEqual(len(link.macros),3)
 def test_ack_is_sent_after_macro_settle_and_within_python_timeout(self):
  link=self.link();link.map=True
  with link.patch():
   link.tr.ping(lambda:True);result=link.tr.click(lambda:True)
  self.assertTrue(result.acknowledged)
  started=link.macros[0][0];ack=next(t for t,a,k in link.events if t>=started and a=='down' and k=='capslock')
  self.assertGreaterEqual(ack-started,.5);self.assertLess(ack-started,.85)
 def test_macro_exception_has_no_ack_and_no_retry(self):
  link=self.link(True)
  with link.patch():
   link.tr.ping(lambda:True);result=link.tr.click(lambda:True)
  self.assertTrue(result.attempted);self.assertFalse(result.acknowledged);self.assertFalse(link.tr.ready)
 def test_revocation_during_macro_settle_aborts_macro(self):
  link=self.link()
  with link.patch():
   link.tr.ping(lambda:True);result=link.tr.click(lambda:not link.macros)
  self.assertFalse(result.acknowledged);self.assertEqual(len(link.macros),1);self.assertEqual(len(link.aborts),1)
 def test_numlock_off_does_not_get_enabled(self):
  link=self.link();link.flags[144]=False
  with link.patch():result=link.tr.ping(lambda:True)
  self.assertFalse(result.attempted);self.assertEqual(link.events,[]);self.assertEqual(link.macros,[])
if __name__=='__main__':unittest.main()
