"""Virtual Xbox A transport. Keyboard actions stay on the existing G HUB bridge."""
import os
import threading
import time


class GamepadInput:
    def __init__(self, dry_run=False, logger=None, factory=None, a_button=None):
        self.dry_run = dry_run
        self.log = logger or (lambda _: None)
        self.lock = threading.RLock()
        self.pad = None
        self.motion_deadline=None
        self.motion_worker=None
        self.closing=threading.Event()
        self.button = a_button
        if dry_run:
            return
        if factory is None:
            if os.name != 'nt':
                raise RuntimeError('Виртуальный Xbox требует Windows и ViGEmBus')
            try:
                import vgamepad as vg
            except Exception as exc:
                raise RuntimeError('Не удалось подключить vgamepad/ViGEmBus: ' + str(exc)) from exc
            factory, self.button = vg.VX360Gamepad, vg.XUSB_BUTTON.XUSB_GAMEPAD_A
        self.pad = factory()
        self.reset()
        self.log('Виртуальный Xbox подключён; F710 и мышь с макросом не нужны')

    def reset(self):
        with self.lock:
            self.motion_deadline=None
            if self.pad is not None:
                self.pad.reset()
                self.pad.update()

    def drive(self,forward=0.0,strafe=0.0,yaw=0.0,pitch=0.0,lifetime=.4):
        """Short renewable motion lease; a stalled vision loop cannot hold a stick forever."""
        if self.dry_run:return
        with self.lock:
            self.pad.left_joystick_float(x_value_float=max(-1,min(1,strafe)),y_value_float=max(-1,min(1,forward)))
            self.pad.right_joystick_float(x_value_float=max(-1,min(1,yaw)),y_value_float=max(-1,min(1,pitch)))
            self.pad.update()
            self.motion_deadline=time.monotonic()+max(.05,min(.6,lifetime))
            if self.motion_worker is None:
                self.motion_worker=threading.Thread(target=self._motion_watchdog,daemon=True)
                self.motion_worker.start()

    def _motion_watchdog(self):
        while not self.closing.wait(.025):
            with self.lock:
                if self.motion_deadline is not None and time.monotonic()>=self.motion_deadline:
                    try:self.reset()
                    except Exception as exc:self.log('Не удалось сбросить стики: '+str(exc))

    def close(self):
        self.closing.set()
        self.reset()

    @staticmethod
    def wait(seconds, stop, focused):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if stop.is_set() or not focused():
                return False
            if stop.wait(min(.02, max(0, end-time.monotonic()))):
                return False
        return not stop.is_set() and focused()

    def tap_a(self, stop, focused, hold=.18):
        if stop.is_set() or not focused():
            return False
        if self.dry_run:
            self.log('СИМУЛЯЦИЯ Xbox A')
            return True
        try:
            with self.lock:
                if stop.is_set() or not focused():
                    return False
                self.reset()
                self.pad.press_button(button=self.button)
                self.pad.update()
            completed = self.wait(hold, stop, focused)
        finally:
            # Also reset when update failed after partially delivering a report.
            self.reset()
        if completed:
            self.log('Xbox TX: A нажата/отпущена; подтверждение цели — по изображению')
        return completed

    def double_a(self, stop, focused, gap=.32, before_second=None):
        if not self.tap_a(stop, focused):
            return False
        if not self.wait(gap, stop, focused):
            return False
        if before_second is not None:
            before_second()
        return self.tap_a(stop, focused)
