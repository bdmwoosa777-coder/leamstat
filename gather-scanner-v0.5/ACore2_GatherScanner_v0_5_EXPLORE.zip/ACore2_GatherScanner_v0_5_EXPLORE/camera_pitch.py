"""Account for delivered right-stick pitch; restore the prior viewing level.

No absolute camera angle is exposed by the game. This is a bounded relative
return, not a claim to measure the horizon or undo the game's own camera motion.
"""
class PitchLedger:
    def __init__(self):
        self.balance=0.0;self.command=0.0;self.at=None;self.deadline=0;self.returning=False;self.return_end=0

    def _integrate(self,now):
        if self.at is not None:
            elapsed=max(0,min(now,self.deadline)-self.at)
            self.balance+=self.command*elapsed
        self.at=now

    def apply(self,pitch,now,lifetime=.45):
        self._integrate(now);self.command=float(pitch);self.deadline=now+lifetime

    def neutral(self,now):self.apply(0,now)

    def restore(self,now):
        self.neutral(now);self.returning=abs(self.balance)>.015
        self.return_end=now+min(3,abs(self.balance)/.6+.8)

    def correction(self,now):
        self._integrate(now)
        if not self.returning:return None
        if abs(self.balance)<.018 or now>=self.return_end:
            self.balance=0;self.returning=False;return 0.0
        # Ease the last step so one control tick cannot overshoot and oscillate.
        return max(-.65,min(.65,-self.balance/.14))
