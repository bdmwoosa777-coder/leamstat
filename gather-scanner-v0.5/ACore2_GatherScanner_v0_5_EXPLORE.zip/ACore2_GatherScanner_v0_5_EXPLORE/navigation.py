"""Straight patrol legs, pulsed camera steering, and a separate sky search."""
from collections import deque
from dataclasses import dataclass
import math
from minimap import angle_delta


@dataclass
class Drive:
    forward:float=0.0
    strafe:float=0.0
    yaw:float=0.0
    pitch:float=0.0
    reason:str=''
    restore_pitch:bool=False


class Navigator:
    def __init__(self,cfg):
        self.cfg=cfg;self.goal=None;self.best_distance=None;self.goal_seen=0
        self.progress_at=None;self.last_time=None;self.last_heading=None;self.heading_at=None
        self.headings=deque(maxlen=3);self.proposed_heading=None;self.proposed_at=None
        self.yaw_sign=cfg.get('camera_yaw_sign',1);self.last_yaw=0
        self.excluded=[];self.recovery_until=0;self.motion_since=None
        self.motion_sum=0;self.motion_samples=0
        self.pulse_until=0;self.pulse_value=0;self.next_pulse=0;self.last_turn_sign=0
        self.reverse_sign=0;self.reverse_since=0
        self.leg_since=None;self.leg_number=0;self.leg_turn_until=0
        self.air_since=None;self.air_key=None;self.air_finished=False
        self.position=[0.0,0.0];self.trail=deque();self.escape_until=0
        self.route_bearing=None;self.route_reason='';self.route_priority=False

    def pause(self,now):
        self.progress_at=now;self.motion_since=now;self.motion_sum=0;self.motion_samples=0
        self.last_yaw=0;self.pulse_until=0;self.next_pulse=now+.3
        self.leg_since=now

    def exclude_goal(self,now,seconds=35):
        if self.goal:self.excluded.append([self.goal.kind,self.goal.x,self.goal.y,now+seconds])
        self.goal=None;self.best_distance=None;self.air_since=None;self.air_key=None;self.pause(now)

    def route(self,bearing,reason='',priority=False):
        self.route_bearing=bearing;self.route_reason=reason;self.route_priority=priority

    def _heading(self,radar,now):
        value=radar.heading
        if value is not None and radar.confidence>=self.cfg.get('heading_min_confidence',.30):
            if self.last_heading is not None and abs(angle_delta(value,self.last_heading))>65:
                # One misidentified road must not reverse camera steering.
                if self.proposed_heading is None or abs(angle_delta(value,self.proposed_heading))>20:
                    self.proposed_heading=value;self.proposed_at=now
                    value=None
                elif now-self.proposed_at<.20:value=None
                else:self.headings.clear();self.proposed_heading=None
            else:self.proposed_heading=None
            if value is not None:
                self.headings.append(value)
                anchor=self.headings[0]
                ordered=sorted(angle_delta(v,anchor) for v in self.headings)
                self.last_heading=(anchor+ordered[len(ordered)//2])%360;self.heading_at=now
        if self.heading_at is not None and now-self.heading_at<1.5:return self.last_heading
        return None

    def _yaw(self,error,now):
        # A pulse is followed by a settling interval. Do not reverse it every
        # video frame when the heading fluctuates around the desired bearing.
        if abs(error)<self.cfg.get('steering_deadband_degrees',16):
            self.pulse_until=0;return 0.0
        if now<self.pulse_until:return self.pulse_value
        if now<self.next_pulse:return 0.0
        sign=1 if error>0 else -1
        if self.last_turn_sign and sign!=self.last_turn_sign:
            if abs(error)<28:return 0.0
            if self.reverse_sign!=sign:
                self.reverse_sign=sign;self.reverse_since=now;return 0.0
            if now-self.reverse_since<.40:return 0.0
        else:self.reverse_sign=0
        self.pulse_value=sign*(.42 if abs(error)<55 else .62)*self.yaw_sign
        self.pulse_until=now+self.cfg.get('camera_pulse_seconds',.12)
        self.next_pulse=self.pulse_until+self.cfg.get('camera_settle_seconds',.55)
        self.last_turn_sign=sign
        return self.pulse_value

    def _move_to(self,desired,heading,now,reason):
        if heading is None:
            return Drive(.55,0,0,0,reason+'; направление камеры временно не читается, короткий прямой проход')
        error=angle_delta(desired,heading);r=math.radians(error)
        # Camera-relative 2-D stick vector: a large camera error no longer
        # forces the character to stand still. Camera turns are only pulses.
        speed=self.cfg.get('resource_walk_speed',.78)
        return Drive(speed*math.cos(r),speed*math.sin(r),self._yaw(error,now),0,
                     reason+f'; курс {desired:.0f}°, камера {heading:.0f}°, ошибка {error:.0f}°')

    def _air(self,goal,now):
        if self.air_since is None:self.air_since=now;self.air_key=(goal.x,goal.y)
        elapsed=now-self.air_since
        # Three 0.30 s upward steps, each followed by OCR time. Stop walking
        # under the airborne node, where its horizontal bearing is unstable.
        period=1.40;level=int(elapsed/period)
        if level<3:
            pitch=self.cfg.get('air_pitch_strength',.60) if elapsed%period<.30 else 0.0
            return Drive(0,0,0,pitch,f'эфир над персонажем: поиск вверх, уровень {level+1}/3')
        if elapsed<5.4:return Drive(0,0,0,0,'эфир: выдержка для распознавания на верхнем угле')
        self.exclude_goal(now,45)
        return Drive(reason='подпись эфира не найдена за проход; возврат наклона и новая цель',restore_pitch=True)

    def _odometry(self,radar,now):
        if radar.motion_valid:
            dx,dy=radar.displacement;self.position[0]-=dx;self.position[1]-=dy
        self.trail.append((now,*self.position))
        while self.trail and now-self.trail[0][0]>35:self.trail.popleft()
        if self.trail and now-self.trail[0][0]>30 and now>=self.escape_until:
            first=self.trail[0];net=math.hypot(self.position[0]-first[1],self.position[1]-first[2])
            path=sum(math.hypot(b[1]-a[1],b[2]-a[2]) for a,b in zip(self.trail,list(self.trail)[1:]))
            if path>80 and net<path*.20:
                self.escape_until=now+20;self.trail.clear();self.leg_since=now

    def update(self,radar,now,allow_air=True):
        self.last_time=now;self._odometry(radar,now)
        scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
        self.excluded=[g for g in self.excluded if g[3]>now]
        if radar.motion_valid:
            dx,dy=radar.displacement
            for g in self.excluded:g[1]+=dx;g[2]+=dy
        candidates=[m for m in radar.markers if (allow_air or m.kind!='aether') and
                    not any(e[0]==m.kind and math.hypot(m.x-e[1],m.y-e[2])<14*scale for e in self.excluded)]
        if self.route_priority:candidates=[];self.goal=None
        if self.goal:
            dx,dy=radar.displacement if radar.motion_valid else (0,0)
            matches=[m for m in candidates if m.kind==self.goal.kind and math.hypot(m.x-self.goal.x-dx,m.y-self.goal.y-dy)<22*scale]
            if matches:
                self.goal=min(matches,key=lambda m:math.hypot(m.x-self.goal.x-dx,m.y-self.goal.y-dy));self.goal_seen=now
            elif now-self.goal_seen>(6 if self.air_since is not None else 1.2):
                self.goal=None;self.best_distance=None
        if self.goal is None and candidates:
            self.goal=min(candidates,key=lambda m:m.distance);self.goal_seen=now
            self.best_distance=self.goal.distance;self.progress_at=now
            self.air_since=None
        heading=self._heading(radar,now)
        if self.route_priority and self.route_bearing is None:
            return Drive(reason='ориентация маршрута по карте не подтверждена; движение приостановлено')
        if self.air_since is not None and (not allow_air or self.goal is None or self.goal.kind!='aether'):
            self.air_since=None
            return Drive(reason='возвращаю прежний наклон после поиска эфира',restore_pitch=True)
        if now<self.recovery_until:
            remaining=self.recovery_until-now
            return Drive(-.35,.5,0,0,'обход упора: назад/вбок') if remaining>.6 else Drive(.5,0,.55*self.yaw_sign,0,'обход упора: короткий поворот и движение')
        if self.goal:
            goal=self.goal
            if self.best_distance is None or goal.distance<self.best_distance-1.5*scale:
                self.best_distance=goal.distance;self.progress_at=now
            desired=math.degrees(math.atan2(goal.x-radar.center[0],radar.center[1]-goal.y))%360
            if goal.kind=='aether':
                if self.air_since is not None:return self._air(goal,now)
                near=goal.distance<self.cfg.get('air_search_map_radius',34)*scale
                aligned=heading is not None and abs(angle_delta(desired,heading))<30
                if near and (aligned or goal.distance<12*scale):return self._air(goal,now)
            plan=self._move_to(desired,heading,now,'к '+goal.name)
            if self.progress_at is not None and now-self.progress_at>self.cfg.get('navigation_stall_seconds',6):
                self.exclude_goal(now);self.recovery_until=now+1.5
                return Drive(-.35,.5,0,0,'нет сближения с иконкой; ограниченный обход')
        elif self.route_bearing is not None:
            plan=self._move_to(self.route_bearing,heading,now,self.route_reason or 'маршрут по большой карте')
        else:
            if self.leg_since is None:self.leg_since=now
            duration=self.cfg.get('patrol_leg_seconds',24)
            if now-self.leg_since>=duration and now>=self.escape_until:
                self.leg_number+=1;self.leg_since=now
                self.leg_turn_until=now+.24
            yaw=0.0
            if now<self.leg_turn_until:
                yaw=(.55 if self.leg_number%3 else -.65)*self.yaw_sign
            plan=Drive(self.cfg.get('patrol_walk_speed',.78),0,yaw,0,
                       'патруль: длинный прямой проход' if not yaw else 'патруль: короткая смена направления')
        if self.motion_since is None:self.motion_since=now
        if radar.motion_valid and math.hypot(plan.forward,plan.strafe)>.2:
            self.motion_sum+=math.hypot(*radar.displacement);self.motion_samples+=1
        if now-self.motion_since>=4:
            if self.motion_samples>=12 and self.motion_sum<1.5 and math.hypot(plan.forward,plan.strafe)>.2:
                self.recovery_until=now+1.5;self.pause(now)
                return Drive(-.35,.5,0,0,'местность на миникарте не смещается: выхожу из упора')
            self.motion_since=now;self.motion_sum=0;self.motion_samples=0
        self.last_yaw=plan.yaw
        return plan
