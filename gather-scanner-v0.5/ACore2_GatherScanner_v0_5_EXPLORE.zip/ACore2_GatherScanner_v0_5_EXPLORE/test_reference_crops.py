"""Regressions from isolated UI crops; no game connection or input.

Full PDF/screenshots, player names, and chat are not included in the package.
Run with Tesseract rus+eng installed: python -m unittest test_reference_crops -v
"""
from pathlib import Path
import unittest
import cv2
import numpy as np
from minimap import MinimapVision,angle_delta
from vision import find_world_resource,selected_target,gathering_panel

ROOT=Path(__file__).resolve().parent/'testdata'


def canvas(file,x,y):
    image=np.full((1395,2480,3),(90,95,100),np.uint8)
    crop=cv2.imread(str(ROOT/file))
    if crop is None:raise FileNotFoundError(file)
    h,w=crop.shape[:2];image[y:y+h,x:x+w]=crop
    return image


class ReferenceCropTests(unittest.TestCase):
    def test_faint_far_caption_and_point_on_blue_crystal(self):
        found=find_world_resource(canvas('far_sapphire_crop.png',1160,335))
        self.assertIsNotNone(found)
        self.assertEqual(found.name,'Сапфир')
        self.assertLess(abs(found.click_x-1202),5)
        self.assertLess(abs(found.click_y-462),8)

    def test_selected_sapphire_is_read_at_49_metres(self):
        name,distance=selected_target(canvas('sapphire_target_49m_crop.png',950,40))
        self.assertEqual(name,'Сапфир');self.assertEqual(distance,49)

    def test_faded_gather_emblem_does_not_bypass_resource_allowlist(self):
        found=find_world_resource(canvas('far_sapphire_crop.png',1160,335),('Эфир',))
        self.assertIsNone(found)

    def test_real_white_gems_and_faded_cone_ignore_diagonal_road(self):
        radar=MinimapVision({}).observe(canvas('minimap_ground_crop.png',2071,152))
        gems=[m for m in radar.markers if m.kind=='gem']
        self.assertEqual(len(gems),2)
        self.assertTrue(any(abs(m.x-2244)<4 and abs(m.y-298)<4 for m in gems))
        self.assertTrue(any(abs(m.x-2318)<4 and abs(m.y-310)<4 for m in gems))
        self.assertLess(abs(angle_delta(radar.heading,212)),5)

    def test_two_coloured_sides_do_not_duplicate_aether_marker(self):
        radar=MinimapVision({}).observe(canvas('minimap_air_crop.png',2071,152))
        self.assertEqual(len(radar.markers),1)
        self.assertEqual(radar.markers[0].kind,'aether')
        self.assertLess(abs(angle_delta(radar.heading,311)),5)

    def test_no_window_from_simple_blue_or_orange_horizontal_stripes(self):
        image=np.full((720,1280,3),70,np.uint8)
        cv2.rectangle(image,(520,540),(800,555),(230,170,30),-1)
        cv2.rectangle(image,(520,565),(800,580),(0,140,240),-1)
        self.assertFalse(gathering_panel(image))

    def test_gather_window_when_only_one_track_has_filled(self):
        image=cv2.imread(str(ROOT/'orihalkon_example.jpg'))
        self.assertFalse(gathering_panel(image))
        image=cv2.imread(str(ROOT/'air_gather_example.jpg'))
        self.assertTrue(gathering_panel(image))
        # Hide the success track completely. The other track and its label
        # still identify the panel; two coloured rows are not required.
        h,w=image.shape[:2]
        image[round(h*.750):round(h*.773),round(w*.40):round(w*.64)]=25
        self.assertTrue(gathering_panel(image))


if __name__=='__main__':unittest.main()
