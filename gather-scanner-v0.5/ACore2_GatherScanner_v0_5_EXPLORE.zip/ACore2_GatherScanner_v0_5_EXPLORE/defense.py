"""Bounded defence of an interrupted resource gather.

Player-name matching and the target-of-target ROI follow TargetScanner v26.
Only two fresh confirmations of Darkleam AND an anchored enemy HP strip allow
an attack. Red minimap dots alone never authorize attacking a selected target.
"""
from dataclasses import dataclass
from collections import deque
import re
import cv2
import numpy as np
import pytesseract


def player_matches(read_name,player_name):
    def norm(value):return ''.join(c for c in value.casefold() if c.isalnum())
    def glyphs(value):return value.replace('rn','m').replace('nn','m').replace('1','l').replace('i','l')
    expected=glyphs(norm(player_name))
    if not expected:return False
    for raw in re.findall(r'[A-Za-z0-9]+',read_name):
        token=glyphs(norm(raw))
        if token==expected:return True
        if token.startswith(expected):
            suffix=token[len(expected):]
            if 1<=len(suffix)<=3 and any(c.isdigit() for c in suffix):return True
    return False


def enemy_hp(frame):
    h,w=frame.shape[:2]
    roi=frame[round(h*.045):round(h*.095),round(w*.391):round(w*.605)]
    if not roi.size:return False,0
    hsv=cv2.cvtColor(roi,cv2.COLOR_BGR2HSV)
    red=cv2.inRange(hsv,(0,115,75),(10,255,255))|cv2.inRange(hsv,(137,115,75),(179,255,255))
    anchor=red[:,max(2,round(w*.008)):max(8,round(w*.025))]
    rows=(anchor>0).mean(axis=1)>.52
    if rows.sum()<max(2,round(h*.002)):return False,0
    # The dark metal left border must accompany the same coloured rows.
    left=roi[:,:max(2,round(w*.0065))]
    if (left[rows].max(axis=2)<95).mean()<.28:return False,0
    return True,int((red[rows]>0).sum())


@dataclass
class Threat:
    matches:bool
    name:str
    hp:bool
    pixels:int


class ThreatDetector:
    def __init__(self,cfg):self.cfg=cfg

    def check(self,frame):
        hp,pixels=enemy_hp(frame)
        if not hp:return Threat(False,'',False,pixels)
        h,w=frame.shape[:2];x0,y0,x1,y1=self.cfg.get('threat_roi',[.665,.028,.752,.054])
        roi=frame[round(y0*h):round(y1*h),round(x0*w):round(x1*w)]
        if not roi.size:return Threat(False,'',hp,pixels)
        hsv=cv2.cvtColor(roi,cv2.COLOR_BGR2HSV);expected=self.cfg.get('player_name','Darkleam')
        raw=''
        for low,high in [((28,45,110),(102,255,255)),((25,25,85),(105,255,255))]:
            mask=cv2.inRange(hsv,low,high)
            if np.count_nonzero(mask)<max(40,int(mask.size*.008)):continue
            enlarged=cv2.resize(mask,None,fx=4,fy=4,interpolation=cv2.INTER_CUBIC)
            _,enlarged=cv2.threshold(enlarged,120,255,cv2.THRESH_BINARY)
            raw=pytesseract.image_to_string(enlarged,lang='eng',config='--psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-').strip()
            if player_matches(raw,expected):return Threat(True,raw,hp,pixels)
        return Threat(False,raw,hp,pixels)


class GatherInterrupts:
    def __init__(self):
        self.visible=False;self.since=None;self.segments=None;self.absent_since=None;self.aborts=deque()

    def reset(self):self.__init__()

    def update(self,panel,segments,now):
        while self.aborts and now-self.aborts[0]>10:self.aborts.popleft()
        if panel:
            if not self.visible:self.since=now;self.segments=segments
            self.absent_since=None
        else:
            if self.visible:
                if (self.since is not None and .10<now-self.since<1.6 and segments is not None
                    and self.segments is not None and segments>=self.segments):self.aborts.append(now)
            if self.absent_since is None:self.absent_since=now
        self.visible=panel

    def ready(self,hostiles,now):
        return bool(hostiles and len(self.aborts)>=2 and self.absent_since is not None and now-self.absent_since>=.25)
