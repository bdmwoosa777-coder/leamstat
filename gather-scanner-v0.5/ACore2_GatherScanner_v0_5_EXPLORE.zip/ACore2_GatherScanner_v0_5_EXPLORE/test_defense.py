from pathlib import Path
import unittest
from unittest.mock import patch
import cv2
import numpy as np
from PIL import Image,ImageDraw,ImageFont
from defense import ThreatDetector,Threat,GatherInterrupts,player_matches,enemy_hp
from vision import color_mask,resource_header_visible
from test_navigation import GatherFixture,obs
from navigation import Drive
from minimap import Radar
from flight import FlightReading
import gather_engine as ge

ROOT=Path(__file__).resolve().parent


def enemy_frame(name):
    fonts=[Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'),Path('C:/Windows/Fonts/arial.ttf')]
    font=next((p for p in fonts if p.exists()),None)
    if font is None:raise unittest.SkipTest('A test font is not installed')
    image=np.full((1395,2480,3),(80,95,110),np.uint8)
    bar=cv2.imread(str(ROOT/'testdata/sapphire_target_49m_crop.png'))
    red=color_mask(bar)>0;bar[red]=(30,25,235)
    image[40:130,950:1540]=bar
    rgb=Image.fromarray(cv2.cvtColor(image,cv2.COLOR_BGR2RGB));draw=ImageDraw.Draw(rgb)
    draw.text((1670,51),name,font=ImageFont.truetype(str(font),24),fill=(120,210,65))
    return cv2.cvtColor(np.array(rgb),cv2.COLOR_RGB2BGR)


class DefenseVisionTests(unittest.TestCase):
    def test_player_name_matching_from_v26_rejects_other_player_suffix(self):
        for text in ['Darkleam','Darkleam773','Darkleam3e_-','Darkieam']:
            self.assertTrue(player_matches(text,'Darkleam'),text)
        for text in ['DarkleamOther','OtherDarkleam','Dark','']:
            self.assertFalse(player_matches(text,'Darkleam'),text)

    def test_two_rapid_abortions_without_segment_progress_trigger_check(self):
        detector=GatherInterrupts()
        for panel,now in [(True,0),(False,.4),(True,1),(False,1.4)]:detector.update(panel,3,now)
        self.assertTrue(detector.ready(1,1.8));self.assertFalse(detector.ready(0,1.8))

    def test_successful_segment_decrease_is_not_an_attack_interruption(self):
        detector=GatherInterrupts();detector.update(True,3,0);detector.update(False,2,.4)
        detector.update(True,2,1);detector.update(False,1,1.4)
        self.assertFalse(detector.ready(2,1.8))

    def test_own_right_hud_and_enemy_hp_are_required_together(self):
        image=enemy_frame('Darkleam');self.assertTrue(enemy_hp(image)[0])
        self.assertTrue(ThreatDetector({'player_name':'Darkleam'}).check(image).matches)
        image[60:135,950:1540]=70
        self.assertFalse(ThreatDetector({'player_name':'Darkleam'}).check(image).matches)

    def test_other_player_panel_does_not_authorize_attack(self):
        self.assertFalse(ThreatDetector({'player_name':'Darkleam'}).check(enemy_frame('DarkleamOther')).matches)

    def test_resource_track_is_visible_without_relying_on_ocr_or_slot_count(self):
        image=np.full((1395,2480,3),70,np.uint8)
        image[40:130,950:1540]=cv2.imread(str(ROOT/'testdata/sapphire_target_49m_crop.png'))
        self.assertTrue(resource_header_visible(image))
        self.assertFalse(resource_header_visible(np.full_like(image,100)))


class DefenseStateTests(GatherFixture,unittest.TestCase):
    def test_segment_progress_confirms_gather_when_panel_and_distance_ocr_miss(self):
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='APPROACH'
        self.step(obs('Эфир',distance=20),100,plate=3,panel=False)
        self.step(obs('Эфир',distance=20),101,plate=2,panel=False)
        self.assertEqual(self.e.mode,'GATHER');self.assertTrue(self.e.f_on)
        self.e._motion(Drive(.8,0,0,0));self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_real_air_gather_with_hidden_header_never_returns_to_patrol(self):
        frame=cv2.imread(str(ROOT/'testdata/air_gather_example.jpg'))
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode='APPROACH';self.e.panel_cleared=True
        info=Radar([], (100,100),90,1,(0,0),False,(0,0,200,200))
        self.e.step(frame,(0,0),obs(distance=30),info,FlightReading(80,True),100)
        self.e.step(frame,(0,0),obs(),info,FlightReading(79,True),102)
        self.assertEqual(self.e.mode,'GATHER');self.assertTrue(self.e.resource_hold)
        self.e._motion(Drive(.8,0,0,.6))
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertNotIn('END_AIR',self.commands)

    def test_stalled_near_gather_can_check_threat_even_if_bar_was_cancelled_too_fast(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode='APPROACH';self.e.f_on=True
        info=Radar([], (100,100),90,1,(0,0),False,(0,0,200,200),hostiles_near=1)
        with patch.object(ge,'segment_count',return_value=3),patch.object(ge,'gathering_panel',return_value=False),patch.object(self.e,'_defend_and_resume') as defense:
            self.e.step(self.frame,(0,0),obs('Сапфир',distance=1),info,self.sky,100)
            self.e.step(self.frame,(0,0),obs('Сапфир',distance=1),info,self.sky,105)
        defense.assert_called_once();self.assertNotIn('V',self.commands)

    def test_gather_window_cannot_emit_walk_or_pitch_even_after_mode_mismatch(self):
        self.e.collecting_visible=True;self.e.mode='SEARCH'
        self.e._motion(Drive(.8,.3,.5,.6))
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_selected_resource_blocks_left_stick_between_gather_frames(self):
        self.e.resource_hold=True;self.e.mode='APPROACH'
        self.e._motion(Drive(.8,.3,.5,0))
        self.assertEqual(self.pad.axes[:3],(0,0,0))

    def test_real_gather_panel_overrides_delayed_far_distance(self):
        self.e.mode='APPROACH';self.e.target='Эфир';self.e.target_confirmed=True;self.e.panel_cleared=True
        self.e.resource_hold=True
        self.step(obs('Эфир',distance=30),100,plate=3,panel=True)
        self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_abandon_command_cannot_cancel_a_visible_gather(self):
        self.e.collecting_visible=True;self.e.target='Эфир';self.e.target_confirmed=True
        self.e.return_to_search('stale OCR',self.frame)
        self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_defense_attacks_only_after_two_confirmations_then_reselects_resource(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True
        own=Threat(True,'Darkleam',True,400);gone=Threat(False,'',False,0)
        self.e.threat=type('D',(),{'check':lambda _,frame:own})()
        clock=[100.0]
        def wait(seconds,*args):clock[0]+=seconds;return True
        readings=[own,own]+[gone]*10
        with patch.object(self.e.threat,'check',side_effect=readings),patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(ge.GamepadInput,'wait',side_effect=wait),patch.object(ge,'find_world_resource',return_value=self.c),patch.object(self.e,'click_candidate',return_value=True) as click:
            self.e._defend_and_resume()
            click.assert_called_once_with(self.c,(0,0),retry=True)
        self.assertEqual(self.commands.count('ATTACK_PAIR'),1);self.assertEqual(self.commands.count('TAB'),1)
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_one_positive_owner_reading_followed_by_miss_does_not_attack(self):
        self.e.target='Сапфир';self.e.target_confirmed=True
        own=Threat(True,'Darkleam',True,400);miss=Threat(False,'Other',True,400)
        clock=[100.0]
        def wait(seconds,*args):clock[0]+=seconds;return True
        with patch.object(self.e.threat,'check',side_effect=[own,miss,miss,miss]),patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(ge.GamepadInput,'wait',side_effect=wait),patch.object(ge,'find_world_resource',return_value=self.c),patch.object(self.e,'click_candidate',return_value=True):
            self.e._defend_and_resume()
        self.assertNotIn('ATTACK_PAIR',self.commands);self.assertEqual(self.commands.count('TAB'),3)


if __name__=='__main__':unittest.main()
