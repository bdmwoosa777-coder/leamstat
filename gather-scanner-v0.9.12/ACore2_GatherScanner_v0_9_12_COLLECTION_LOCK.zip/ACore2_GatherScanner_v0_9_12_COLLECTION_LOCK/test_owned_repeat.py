"""Harmless A repeats must not wait indefinitely on attempt_active or used."""
import struct,unittest
from unittest.mock import patch
import gather_engine as ge
from app import DEFAULT
from network_state import Telemetry
from test_navigation import GatherFixture
from test_network_control import Source
from test_ether_emblem import scene,ether
from test_network_state import profile,v,gauge

class OwnedRepeat(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(resource_click_interaction=True,repeat_owned_clicks=True,collection_cursor_hold=True,calibrate_during_collection=False)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.nodes[99].template=1500000;self.f.nodes[99].gather_time=1000
        self.f.collecting=99;self.f.attempt_active=True;self.f.nodes[99].used=0
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
        self.frame=scene();self.e.candidate=ether(self.frame);self.e.current_size=(2480,1395)
        self.alt_held=True;self.e.collection_cursor_owned=True
        self.clock=100.;self.wall=1100;self.clicks=[];self.callback=lambda:None
        def wait(seconds,*args):self.clock+=seconds;return True
        def click(*args,**kwargs):self.clicks.append((self.clock,self.positions[-1]));self.callback();return True
        self.input.tap_a=click
        for q in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),patch.object(ge.GamepadInput,'wait',side_effect=wait)):
            q.start();self.addCleanup(q.stop)

    def test_enabled_by_default(self):self.assertTrue(DEFAULT['repeat_owned_clicks'])

    def test_active_first_attempt_with_zero_used_still_gets_one_click(self):
        self.e.f_enable();self.assertEqual(len(self.clicks),1)
        self.assertTrue(self.f.attempt_active);self.assertEqual(self.f.nodes[99].used,0)
        self.assertEqual(self.e.owned_click_count,1)

    def test_unchanged_active_and_counter_for_26_seconds_do_not_stall_clicks(self):
        for _ in range(26):self.e.f_enable();self.clock+=1
        self.assertEqual(len(self.clicks),26);self.assertTrue(self.f.attempt_active)
        self.assertEqual(self.f.nodes[99].used,0)
        self.assertFalse({'F_ON','TAP_F','V','END_AIR','TAB'}&set(self.commands))
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_remaining_one_with_stale_active_also_repeats(self):
        self.f.nodes[99].used=2
        for _ in range(4):self.e.f_enable();self.clock+=1
        self.assertEqual(len(self.clicks),4);self.assertTrue(self.f.attempt_active)

    def test_high_frequency_ticks_do_not_spam_a(self):
        for _ in range(50):self.e.f_enable();self.clock+=.01
        self.assertEqual(len(self.clicks),1)
        self.clock+=.5;self.e.f_enable();self.assertEqual(len(self.clicks),2)

    def test_old_exhausted_retry_counter_no_longer_blocks_owned_clicks(self):
        self.f.nodes[99].used=1;self.f.attempt_active=False
        self.e.next_attempt_sent_used=1;self.e.next_attempt_click_tries=10;self.e.next_attempt_wait_at=None
        self.e.f_enable();self.assertEqual(len(self.clicks),1)
        self.clock+=1;self.e.f_enable();self.assertEqual(len(self.clicks),2)

    def test_counter_changes_do_not_reset_cadence_and_create_extra_clicks(self):
        self.e.f_enable();self.f.nodes[99].used=1;self.f.attempt_active=False
        self.e.f_enable();self.assertEqual(len(self.clicks),1)
        self.clock+=1;self.e.f_enable();self.assertEqual(len(self.clicks),2)

    def test_zero_selection_gets_select_and_activate_even_if_active_was_already_true(self):
        self.f.selected=0;self.e.f_enable()
        self.assertEqual(len(self.clicks),2);self.assertEqual(self.f.selected,0)
        self.assertTrue(self.f.attempt_active)

    def test_selecting_foreign_actor_between_two_clicks_blocks_activation(self):
        self.f.selected=0;self.callback=lambda:setattr(self.f,'selected',55)
        self.e.f_enable();self.assertEqual(len(self.clicks),1)
        self.assertEqual(self.e.owned_click_count,0)

    def test_no_own_lease_cannot_use_active_flag_to_authorize_click(self):
        self.f.collecting=None
        for _ in range(5):self.e.f_enable();self.clock+=1
        self.assertEqual(self.clicks,[])

    def test_new_approach_before_own_collection_is_not_a_repeat_target(self):
        self.f.nodes[99].gather_time=None;self.f.collecting=None
        self.e.real_gather_panel_seen=False;self.e.fast_gather_seen=False;self.e.mode='APPROACH'
        self.e.f_enable();self.assertEqual(self.clicks,[])

    def test_resource_depletion_immediately_stops_all_further_clicks(self):
        self.e.f_enable();self.f.nodes[99].used=3;self.f.collecting=None
        for _ in range(5):self.clock+=1;self.e.f_enable()
        self.assertEqual(len(self.clicks),1)

    def test_target_change_stops_periodic_clicks(self):
        self.e.f_enable();self.f.selected=55
        self.clock+=1;self.e.f_enable();self.assertEqual(len(self.clicks),1)

    def test_flow_loss_stops_periodic_clicks(self):
        self.e.f_enable();self.source.ready=False
        self.clock+=1;self.e.f_enable();self.assertEqual(len(self.clicks),1)

    def test_lost_resource_point_cannot_be_clicked_from_old_coordinates(self):
        self.frame[:]=35
        self.e.f_enable();self.assertEqual(self.clicks,[])
        self.assertEqual(self.e.owned_click_count,0);self.assertTrue(self.f.attempt_active)

    def test_cursor_readback_failure_is_not_a_successful_repeat(self):
        self.e.bridge.cursor_matches=lambda:False
        self.e.f_enable();self.assertEqual(self.clicks,[])
        self.assertEqual(self.e.owned_click_count,0);self.assertIsNone(self.e.next_attempt_sent_used)

    def test_caption_and_badge_disappearing_before_press_are_not_a_sent_repeat(self):
        cursor=self.e.bridge.cursor
        def move(x,y):cursor(x,y);self.frame[:]=35
        self.e.bridge.cursor=move;self.e.f_enable()
        self.assertEqual(self.clicks,[]);self.assertEqual(self.e.owned_click_count,0)

    def test_camera_mode_blocks_owned_repeat(self):
        self.e.camera_in_progress=True;self.e.f_enable();self.assertEqual(self.clicks,[])

    def test_focus_loss_blocks_owned_repeat(self):
        self.e.screen.focused=lambda:False;self.e.f_enable();self.assertEqual(self.clicks,[])

    def test_damage_requiring_defense_blocks_owned_repeat(self):
        self.f.attacks[55]=self.wall;self.f.npcs[55]={'time':900}
        self.e.f_enable();self.assertEqual(self.clicks,[])

    def test_bound_resource_badge_is_preferred_on_every_periodic_click(self):
        c=self.e.candidate
        for _ in range(4):self.e.f_enable();self.clock+=1
        self.assertTrue(all(point==(c.click_x,c.click_y) for t,point in self.clicks))
        self.assertEqual(len(self.clicks),4)

    def test_repeat_does_not_reset_or_fold_the_resource_between_attempts(self):
        self.f.nodes[99].used=1;self.f.attempt_active=False
        for _ in range(5):self.e.f_enable();self.clock+=1
        self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.e.mode,'GATHER')
        self.assertIsNone(self.e.view_recovery);self.assertNotIn('END_AIR',self.commands)

    def test_reentrant_tick_during_delivery_does_not_duplicate_request(self):
        self.callback=self.e.f_enable
        self.e.f_enable();self.assertEqual(len(self.clicks),1)

    def test_foreign_counter_update_cannot_hold_clicks_via_stale_active_flag(self):
        t=Telemetry({1500000});t.feed(1,'008d',gauge(),0)
        t.feed(1,'3436',profile(kind=1500000),900)
        t.feed(1,'3438',bytes(3)+v(99),950)
        t.feed(1,'3836',v(99)+v(7)+b'\1',990)
        t.feed(1,'318d',bytes(2)+v(99)+struct.pack('<I',1)+bytes(25),1000)
        t.feed(1,'3a36',v(99)+v(8)+struct.pack('<II',1,0),1100)
        self.source.state=t.flows[1];self.f=self.source.state
        self.assertTrue(self.f.attempt_active);self.assertEqual(self.f.nodes[99].used,1)
        self.e.f_enable();self.clock+=1;self.e.f_enable()
        self.assertEqual(len(self.clicks),2);self.assertTrue(self.f.attempt_active)


if __name__=='__main__':unittest.main()
