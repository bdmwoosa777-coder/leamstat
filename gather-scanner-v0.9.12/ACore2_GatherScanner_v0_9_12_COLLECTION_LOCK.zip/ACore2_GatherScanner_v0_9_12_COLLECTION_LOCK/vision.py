# -*- coding: utf-8 -*-
"""AION 2 visual-only helpers, first prototype. No game memory access."""
from __future__ import annotations
from dataclasses import dataclass,replace
from pathlib import Path
import os
import re
import time
import cv2
import numpy as np
import pytesseract

# Multiple game/vision workers must not each launch an all-core native pool.
cv2.setNumThreads(1)
os.environ.setdefault('OMP_THREAD_LIMIT','1')
from flight import read_flight

ROOT=Path(__file__).resolve().parent
if os.name=='nt':
    _tess=Path(r'C:\Program Files\Tesseract-OCR\tesseract.exe')
    if _tess.is_file():pytesseract.pytesseract.tesseract_cmd=str(_tess)

@dataclass
class Candidate:
    name: str
    click_x: int
    click_y: int
    confidence: float
    box: tuple
    glyph: tuple | None = None
    glyph_mode: str = 'strict'
    emblem: tuple | None = None

@dataclass
class Observation:
    candidate: Candidate | None
    target_name: str | None
    distance_m: float | None
    f_prompt: bool
    prompt_score: float
    gathering: bool
    flight_energy: float | None
    flight_state: str

DEFAULT_NAMES=('Эфир','Сапфир','Рубин','Алмаз')


def norm(text):
    return re.sub(r'[^а-яё]', '', text.lower().translate(str.maketrans({'e':'е','o':'о','p':'р','c':'с','a':'а','x':'х','k':'к','m':'м','t':'т','b':'в','h':'н'})))


def clean_match(text, names):
    t=norm(text)
    for name in names:
        n=norm(name)
        if t==n or (len(n)>=5 and n in t and len(t)<=len(n)+3):
            return name
    return None


def color_mask(bgr):
    hsv=cv2.cvtColor(bgr,cv2.COLOR_BGR2HSV)
    # Cyan-to-green text from Russian Global UI; restrict saturation and brightness.
    lower=np.array([32,43,65],np.uint8)
    upper=np.array([96,255,255],np.uint8)
    mask=cv2.inRange(hsv,lower,upper)
    b,g,r=cv2.split(bgr.astype(np.int16))
    mask[(g<b*.97)|(g-r<18)]=0
    return mask


def relaxed_caption_mask(bgr):
    """Distance fading mixes green letters with brown terrain. Proposals need
    either a separately matched emblem or a stricter whole-word shape score.
    """
    b,g,r=cv2.split(bgr.astype(np.int16))
    return np.where((g-r>7)&(g-b>-5),255,0).astype(np.uint8)

def _world_bounds(frame):
    h,w=frame.shape[:2]
    return int(w*.02),int(h*.08),int(w*.98),int(h*.84)

def _world_mask(frame,bounds):
    x0,y0,x1,y1=bounds;h,w=frame.shape[:2]
    mask=color_mask(frame[y0:y1,x0:x1])
    # The larger lower field must not read resource names from chat.
    mask[max(0,int(h*.69)-y0):,:max(0,int(w*.34)-x0)]=0
    mask[:max(0,int(h*.44)-y0),max(0,int(w*.81)-x0):]=0
    return mask


def resource_click_point(frame,box,name):
    x,y,rw,rh=map(int,box);h,w=frame.shape[:2]
    # The game accepts the hitbox immediately under the resource caption.
    # A nearby blue crystal/flag/pet is NOT identity evidence for this caption.
    return x+rw//2,min(h-1,y+rh+max(6,min(12,round(rh*.6))))


def caption_candidate(frame,name,box,confidence,mode='strict'):
    x,y,w,h=map(int,box);patch=frame[y:y+h,x:x+w]
    mask=relaxed_caption_mask(patch) if mode=='relaxed' else color_mask(patch)
    glyph=(mask.shape,mask.tobytes()) if mask.size and np.count_nonzero(mask)>=8 else None
    cx,cy=resource_click_point(frame,box,name)
    emblem=locate_resource_emblem(frame,box)
    if emblem is not None:cx=emblem[0]+emblem[2]//2;cy=emblem[1]+emblem[3]//2
    return Candidate(name,cx,cy,confidence,box,glyph,mode,emblem)


def _ocr_text(image,deadline=None,**kwargs):
    remaining=.8 if deadline is None else min(.8,deadline-time.monotonic())
    if remaining<.05:return ''
    try:return pytesseract.image_to_string(image,timeout=remaining,**kwargs)
    except RuntimeError as exc:
        if 'timeout' in str(exc).lower():return ''
        raise


def _trim(mask):
    y,x=np.nonzero(mask)
    return mask[y.min():y.max()+1,x.min():x.max()+1] if len(x) else None


_name_library=None
def visual_name(mask,names):
    global _name_library
    if _name_library is None:
        _name_library=[]
        for file in (ROOT/'assets/name_masks').glob('*.png'):
            label='Эфир' if file.stem=='ether' or file.stem.startswith('ether_') else {'sapphire':'Сапфир'}.get(file.stem)
            image=cv2.imread(str(file),0)
            if label and image is not None:_name_library.append((label,_trim(image)))
    sample=_trim(mask)
    if sample is None:return None,0
    best=(None,0)
    for label,template in _name_library:
        if label not in names or template is None:continue
        ratio=(sample.shape[1]/sample.shape[0])/(template.shape[1]/template.shape[0])
        if not .76<ratio<1.30:continue
        a=cv2.resize(sample,(template.shape[1]*3,template.shape[0]*3))>100
        b=cv2.resize(template,(template.shape[1]*3,template.shape[0]*3))>100
        kernel=np.ones((3,3),np.uint8)
        da=cv2.dilate(a.astype('uint8'),kernel)>0;db=cv2.dilate(b.astype('uint8'),kernel)>0
        score=float(((a&db).sum()+(b&da).sum())/max(1,a.sum()+b.sum()))
        if score>best[1]:best=(label,score)
    return best if best[1]>=.86 else (None,best[1])


def local_world_candidates(frame,names,deadline=None):
    h,w=frame.shape[:2];scale=w/2048
    x0,y0,x1,y1=_world_bounds(frame)
    mask=_world_mask(frame,(x0,y0,x1,y1))
    grouped=cv2.dilate(mask,np.ones((max(1,round(scale*2)),max(2,round(scale*6))),np.uint8))
    _,_,stats,_=cv2.connectedComponentsWithStats(grouped)
    proposals=[]
    for x,y,rw,rh,area in stats[1:]:
        if not (12*scale<rw<210*scale and 5*scale<rh<35*scale and area>30*scale*scale):continue
        ax,ay=x0+x,y0+y
        above=frame[max(0,ay-round(65*scale)):max(0,ay-round(5*scale)),
                    max(0,ax-round(12*scale)):min(w,ax+rw+round(12*scale))]
        if above.size==0:continue
        ah=cv2.cvtColor(above,cv2.COLOR_BGR2HSV)
        white=cv2.inRange(ah,np.array([0,0,175]),np.array([179,90,255]))
        evidence=int(np.count_nonzero(white))
        if evidence<max(15,35*scale*scale):continue
        proposals.append((evidence,ax,ay,rw,rh))
    result=[]
    for _,x,y,rw,rh in sorted(proposals,reverse=True)[:4]:
        patch=frame[max(0,y-3):min(h,y+rh+3),max(0,x-3):min(w,x+rw+3)]
        name,score=visual_name(color_mask(patch),names)
        if name is None:
            # OCR only the resource-colour letters, never yellow NPC titles.
            text=_ocr_text(cv2.resize(255-color_mask(patch),None,fx=4,fy=4),deadline,lang='rus',config='--psm 7')
            name=clean_match(text,names);score=.85 if name else score
        if name:
            box=(x,y,rw,rh)
            result.append(caption_candidate(frame,name,box,score*100))
    return result


_emblem=None

def locate_resource_emblem(frame,box):
    """Locate the clickable gather badge directly above THIS resource caption."""
    global _emblem
    if _emblem is None:_emblem=cv2.imread(str(ROOT/'assets/resource_emblem_mask.png'),0)
    if _emblem is None:return None
    h,w=frame.shape[:2];x,y,rw,rh=map(int,box);center=x+rw/2
    margin=max(32,round(rw*.9));x0=max(0,round(center-margin));x1=min(w,round(center+margin))
    y0=max(0,y-max(70,round(rh*6)));y1=max(0,y-2)
    if x1<=x0 or y1<=y0:return None
    gray=cv2.cvtColor(frame[y0:y1,x0:x1],cv2.COLOR_BGR2GRAY);best=None
    for factor in (.65,.8,.95,1.1,1.25,1.45,1.7,2):
        scale=w/2480*factor;tpl=cv2.resize(_emblem,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
        th,tw=tpl.shape
        if th<9 or th>gray.shape[0] or tw>gray.shape[1]:continue
        _,score,_,(xx,yy)=cv2.minMaxLoc(cv2.matchTemplate(gray,tpl,cv2.TM_CCOEFF_NORMED))
        if score<.62 or abs(x0+xx+tw/2-center)>max(12,rw*.40):continue
        if best is None or score>best[0]:best=(score,x0+xx,y0+yy,tw,th)
    return tuple(map(int,best[1:])) if best is not None else None

def find_selected_resource_badge(frame,name,previous=None):
    """Find paired world-selection chevrons and the gather emblem above them.
    For continuation of an already-owned interaction; not new-name authority.
    No OCR. Global matching stays in the background vision worker.
    """
    template=cv2.imread(str(ROOT/'assets/selected_resource_arrow.png'),0)
    if template is None:return None
    H,W=frame.shape[:2];ratio=min(1.,1280/W)
    small=cv2.resize(frame,None,fx=ratio,fy=ratio,interpolation=cv2.INTER_AREA)
    b,g,r=cv2.split(small.astype(np.int16))
    mask=np.where((b-r>25)&(g-r>20)&(b>130)&(g>130),255,0).astype(np.uint8)
    h,w=mask.shape;mask[:round(h*.10)]=0
    mask[:round(h*.44),round(w*.81):]=0;mask[round(h*.69):,:round(w*.34)]=0
    deadline=time.monotonic()+.30;found=[]
    for factor in (.65,.8,1,1.2,1.45,1.75,2.1):
        if time.monotonic()>=deadline:break
        scale=W/2480*ratio*factor
        tpl=cv2.resize(template,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA);th,tw=tpl.shape
        if th<6 or th>=h or tw>=w:continue
        scores=cv2.matchTemplate(mask,tpl,cv2.TM_CCOEFF_NORMED)
        for _ in range(3):
            if time.monotonic()>=deadline:break
            _,left,_,(x,y)=cv2.minMaxLoc(scores)
            if left<.60:break
            scores[max(0,y-th):y+th,max(0,x-tw):x+tw]=-1
            x0=x+round(th*1.5);x1=min(w,x+round(th*10))
            y0=max(0,y-round(th*.25));y1=min(h,y+round(th*1.3))
            roi=mask[y0:y1,x0:x1]
            if roi.shape[0]<th or roi.shape[1]<tw:continue
            _,right,_,(rx,ry)=cv2.minMaxLoc(cv2.matchTemplate(roi,cv2.flip(tpl,1),cv2.TM_CCOEFF_NORMED))
            if right<.60:continue
            lx=(x+tw)/ratio;right_x=(x0+rx)/ratio
            box=(round(lx),round((y+th*.15)/ratio),round(right_x-lx),round(th*.7/ratio))
            if not _caption_allowed(frame,box):continue
            emblem=locate_resource_emblem(frame,box)
            if emblem is None:continue
            ex,ey,ew,eh=emblem
            if any(abs(ex-c.emblem[0])<ew*.5 and abs(ey-c.emblem[1])<eh*.5 for c in found):continue
            found.append(Candidate(name,ex+ew//2,ey+eh//2,min(left,right)*100,box,None,'strict',emblem))
    if not found:return None
    if previous is not None:
        return min(found,key=lambda c:(c.click_x-previous.click_x)**2+(c.click_y-previous.click_y)**2)
    return max(found,key=lambda c:c.confidence)


def distant_world_candidates(frame,names,deadline=None):
    """Locate the gather emblem first, then OCR ONLY the faded caption below it.
    An emblem alone never authorizes F: a resource name is still required here
    and the selected top header must subsequently confirm it in GatherEngine.
    """
    global _emblem
    if _emblem is None:_emblem=cv2.imread(str(ROOT/'assets/resource_emblem_mask.png'),0)
    if _emblem is None:return []
    h,w=frame.shape[:2];x0,y0,x1,y1=_world_bounds(frame)
    gray=cv2.cvtColor(frame[y0:y1,x0:x1],cv2.COLOR_BGR2GRAY)
    proposals=[]
    for factor in (.65,.75,.85,1,1.15):
        scale=w/2480*factor
        tpl=cv2.resize(_emblem,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
        th,tw=tpl.shape
        scores=cv2.matchTemplate(gray,tpl,cv2.TM_CCOEFF_NORMED)
        for _ in range(3):
            _,score,_,(x,y)=cv2.minMaxLoc(scores)
            if score<.58:break
            proposals.append((score,x+x0,y+y0,tw,th))
            scores[max(0,y-th):y+th,max(0,x-tw):x+tw]=-1
    results=[];seen=[]
    for score,x,y,tw,th in sorted(proposals,reverse=True):
        if len(seen)>=4:break
        if any(abs(x-a)<tw and abs(y-b)<th for a,b in seen):continue
        seen.append((x,y))
        ax,bx=max(0,x-round(tw*.65)),min(w,x+round(tw*1.65))
        ay,by=y+round(th*1.15),min(h,y+round(th*2.25))
        patch=frame[ay:by,ax:bx]
        if not patch.size:continue
        mask=relaxed_caption_mask(patch)
        if np.count_nonzero(mask)<12:continue
        name,similarity=visual_name(mask,names)
        if name is None:
            text=_ocr_text(cv2.resize(255-mask,None,fx=5,fy=5),deadline,lang='rus',config='--psm 7')
            name=clean_match(text,names)
        if name is None:continue
        # Trim to the actual letters, not to the entire emblem search box.
        yy,xx=np.nonzero(mask);box=(ax+int(xx.min()),ay+int(yy.min()),int(xx.max()-xx.min()+1),int(yy.max()-yy.min()+1))
        results.append(caption_candidate(frame,name,box,float(score*100),'relaxed'))
    return results


def _text_words(mask, psm=11,deadline=None):
    # 255 background, dark glyphs. Upscale for Cyrillic Tesseract.
    bw=cv2.resize(255-mask,None,fx=1.55,fy=1.55,interpolation=cv2.INTER_NEAREST)
    remaining=.8 if deadline is None else min(.8,deadline-time.monotonic())
    if remaining<.05:return
    try:data=pytesseract.image_to_data(bw,lang='rus',config=f'--oem 3 --psm {psm}',output_type=pytesseract.Output.DICT,timeout=remaining)
    except RuntimeError as exc:
        if 'timeout' in str(exc).lower():return
        raise
    for i,s in enumerate(data['text']):
        s=s.strip()
        if not s: continue
        try: conf=float(data['conf'][i])
        except (TypeError, ValueError): conf=-1
        if conf<35: continue
        yield (s,conf,float(data['left'][i])/1.55,float(data['top'][i])/1.55,
               float(data['width'][i])/1.55,float(data['height'][i])/1.55)


def _caption_allowed(frame,box):
    h,w=frame.shape[:2];x,y,rw,rh=box;cx=x+rw/2;cy=y+rh/2
    return not (cx>=w*.81 and cy<h*.44 or cx<w*.34 and cy>=h*.69)


def fast_ether_candidates(frame,names=DEFAULT_NAMES,deadline=None):
    """Read the four-letter word by shape before the large-image OCR budget.

    Join letters as a whole word: a suffix of Sapphire must not become Ether.
    The dim mask has a stricter shape threshold; an emblem is not mandatory.
    """
    if 'Эфир' not in names:return []
    deadline=time.monotonic()+.35 if deadline is None else deadline
    examined=0
    h,w=frame.shape[:2];x0,y0,x1,y1=_world_bounds(frame);region=frame[y0:y1,x0:x1]
    result=[];seen=[];scale=max(.5,w/2048)
    for mode,fn,threshold in (('strict',color_mask,.93),('relaxed',relaxed_caption_mask,.935)):
        if time.monotonic()>=deadline:break
        mask=fn(region)
        mask[:max(0,int(h*.44)-y0),max(0,int(w*.81)-x0):]=0
        mask[max(0,int(h*.69)-y0):,:max(0,int(w*.34)-x0)]=0
        grouped=cv2.dilate(mask,np.ones((1,max(5,round(6*scale))),np.uint8))
        _,_,stats,_=cv2.connectedComponentsWithStats(grouped)
        for x,y,rw,rh,area in stats[1:]:
            if examined>=96 or len(result)>=8 or time.monotonic()>=deadline:break
            if not (5*scale<=rh<=42*scale and 12*scale<=rw<=170*scale and 1.8<rw/rh<5):continue
            sample=mask[y:y+rh,x:x+rw]
            if not .12<np.count_nonzero(sample)/max(1,sample.size)<.75:continue
            examined+=1
            name,score=visual_name(sample,('Эфир',))
            if name is None or score<threshold:continue
            box=(int(x0+x),int(y0+y),int(rw),int(rh))
            if not _caption_allowed(frame,box):continue
            if any(abs(box[0]-a)<rw*.5 and abs(box[1]-b)<rh for a,b in seen):continue
            seen.append(box[:2]);result.append(caption_candidate(frame,name,box,score*100,mode))
    return sorted(result,key=lambda c:c.confidence,reverse=True)


def find_world_resource(frame,names=DEFAULT_NAMES):
    """Detect an allowed world caption by shape first, then bounded OCR.
    The name alone does not prove an unobstructed clickable object.
    """
    h,w=frame.shape[:2]
    quick=fast_ether_candidates(frame,names)
    if quick:return quick[0]
    deadline=time.monotonic()+1.8
    x0,y0,x1,y1=_world_bounds(frame)
    mask=_world_mask(frame,(x0,y0,x1,y1))
    results=[]
    for txt,conf,x,y,tw,th in _text_words(mask,deadline=deadline):
        name=clean_match(txt,names)
        if not name: continue
        cx=int(x0+x+tw*.5)
        offset=max(18,h*.035) if name=='Эфир' else max(18,h*.010)
        cy=int(y0+y+th+offset)
        # Avoid target panel region and character names when a target is highlighted.
        if cy<int(h*.10): continue
        box=(int(x0+x),int(y0+y),int(tw),int(th))
        if _caption_allowed(frame,box):results.append(caption_candidate(frame,name,box,conf))
    if not results:results=local_world_candidates(frame,names,deadline)
    if not results:results=distant_world_candidates(frame,names,deadline)
    results=[c for c in results if _caption_allowed(frame,c.box)]
    results.sort(key=lambda c:c.confidence,reverse=True)
    return results[0] if results else None

def find_resource_near(frame,previous):
    """Re-read the stopped resource locally; no old coordinate authorizes a click."""
    h,w=frame.shape[:2];x,y,tw,th=map(int,previous.box)
    mx=max(40,round(w*.035));my=max(30,round(h*.035))
    x0=max(0,x-mx);x1=min(w,x+tw+mx)
    y0=max(0,y-max(my,round(h*.07)));y1=min(h,y+th+my)
    if previous.glyph is not None:
        shape,data=previous.glyph;template=np.frombuffer(data,np.uint8).reshape(shape)
        region=frame[y0:y1,x0:x1]
        mask=relaxed_caption_mask(region) if previous.glyph_mode=='relaxed' else color_mask(region)
        best=None
        for factor in (.6,.75,.9,1,1.1,1.3,1.6,2,2.4):
            glyph=cv2.resize(template,None,fx=factor,fy=factor,interpolation=cv2.INTER_NEAREST)
            gh,gw=glyph.shape
            if gh>mask.shape[0] or gw>mask.shape[1] or np.std(glyph)<5:continue
            _,score,_,(gx,gy)=cv2.minMaxLoc(cv2.matchTemplate(mask,glyph,cv2.TM_CCOEFF_NORMED))
            if score>=.76 and (best is None or score>best[0]):best=(score,gx,gy,gw,gh)
        if best is None:return None
        score,gx,gy,gw,gh=best;box=(x0+gx,y0+gy,gw,gh)
        cx,cy=resource_click_point(frame,box,previous.name)
        emblem=locate_resource_emblem(frame,box)
        if emblem is not None:cx=emblem[0]+emblem[2]//2;cy=emblem[1]+emblem[3]//2
        return replace(previous,box=box,click_x=cx,click_y=cy,emblem=emblem)
    isolated=np.zeros_like(frame);isolated[y0:y1,x0:x1]=frame[y0:y1,x0:x1]
    found=find_world_resource(isolated,(previous.name,))
    if found and x0<=found.box[0]<x1 and y0<=found.box[1]<y1:
        cx,cy=resource_click_point(frame,found.box,found.name)
        if found.emblem is not None:cx=found.emblem[0]+found.emblem[2]//2;cy=found.emblem[1]+found.emblem[3]//2
        return replace(found,click_x=cx,click_y=cy)
    return None


def selected_resource_name(frame,names=DEFAULT_NAMES):
    """One bounded background read of the resource HUD, without distance OCR."""
    if segment_count(frame) is None:return None
    h,w=frame.shape[:2]
    band=frame[int(.035*h):int(.09*h),int(.39*w):int(.62*w)]
    bm=color_mask(band)
    solid=cv2.morphologyEx(bm,cv2.MORPH_OPEN,np.ones((1,max(8,round(w*.035))),np.uint8))
    rows=np.flatnonzero((solid>0).sum(axis=1)>w*.035)
    bottom=(int(.035*h)+int(rows[0])-2) if len(rows) else int(.055*h)
    patch=frame[max(int(.020*h),bottom-int(.033*h)):bottom,int(.425*w):int(.57*w)]
    if not patch.size:return None
    mask=color_mask(patch);trimmed=_trim(mask)
    if trimmed is None:return None
    name,_=visual_name(trimmed,names)
    if name:return name
    text=_ocr_text(cv2.resize(patch,None,fx=3,fy=3),lang='rus',config='--oem 3 --psm 7')
    return clean_match(text,names)


def selected_target(frame,names=DEFAULT_NAMES,require_track=True):
    """Read selected resource title in the fixed TOP CENTRE overlay.
    Text-only colour segmentation fails against the teal HP bar, so use
    a narrowly cropped RGB title row + single-line Cyrillic OCR instead.
    """
    h,w=frame.shape[:2]
    if require_track and segment_count(frame) is None:return None,None
    # Crop above the actual green track, so the track cannot merge with the letters.
    band=frame[int(.035*h):int(.09*h),int(.39*w):int(.62*w)]
    bm=color_mask(band)
    solid=cv2.morphologyEx(bm,cv2.MORPH_OPEN,np.ones((1,max(8,round(w*.035))),np.uint8))
    rows=np.flatnonzero((solid>0).sum(axis=1)>w*.035)
    name_bottom=(int(.035*h)+int(rows[0])-2) if len(rows) else int(.055*h)
    name_top=max(int(.020*h),name_bottom-int(.033*h))
    a=frame[name_top:name_bottom,int(.425*w):int(.57*w)]
    if a.size==0:return None,None
    a=cv2.resize(a,None,fx=3,fy=3,interpolation=cv2.INTER_CUBIC)
    mask=color_mask(a)
    trimmed=_trim(mask)
    text=pytesseract.image_to_string(a,lang='rus',config='--oem 3 --psm 7')
    selected=None
    clean=norm(text)
    for name in names:
        if norm(name) in clean:
            selected=name
            break
    if selected is None and trimmed is not None:
        selected,_=visual_name(trimmed,names)
        if selected is None:
            text=pytesseract.image_to_string(cv2.resize(255-trimmed,None,fx=3,fy=3),lang='rus',config='--psm 7')
            selected=clean_match(text,names)
    if selected is None:
        old=frame[int(.034*h):int(.055*h),int(.45*w):int(.54*w)]
        if old.size:
            text=pytesseract.image_to_string(cv2.resize(old,None,fx=3,fy=3),lang='rus',config='--psm 7')
            clean=norm(text)
            selected=next((name for name in names if norm(name) in clean),None)
    if selected is None:return None,None
    try:
        sub=frame[int(.027*h):int(.060*h),int(.57*w):int(.595*w)]
        gray=cv2.resize(cv2.cvtColor(sub,cv2.COLOR_BGR2GRAY),None,fx=4,fy=4)
        s=pytesseract.image_to_string(gray,lang='eng+rus',config='--psm 7 -c tessedit_char_whitelist=0123456789.,mMмМ')
        if not re.search(r'\d',s):
            s=pytesseract.image_to_string(gray,lang='eng+rus',config='--psm 8 -c tessedit_char_whitelist=0123456789.,mMмМ')
        number=re.search(r'(\d{1,3}(?:[.,]\d)?)\s*[мmMМ]',s)
        if number:return selected,float(number.group(1).replace(',','.'))
        bare=re.search(r'\d{1,3}(?:[.,]\d)?',s)
        # White digits are separable from the beige terrain and cyan height
        # icon. The old RGB crop often read that icon as a zero at 49 metres.
        sub=frame[int(.030*h):int(.055*h),int(.56*w):int(.60*w)]
        white=cv2.inRange(cv2.cvtColor(sub,cv2.COLOR_BGR2HSV),np.array([0,0,190]),np.array([179,25,255]))
        trimmed=_trim(white)
        if trimmed is not None:
            digits=cv2.copyMakeBorder(cv2.resize(255-trimmed,None,fx=5,fy=5),15,15,15,15,cv2.BORDER_CONSTANT,value=255)
            text=pytesseract.image_to_string(digits,lang='eng+rus',config='--psm 7 -c tessedit_char_whitelist=0123456789.,mMмМ')
            number=re.search(r'(\d{1,3}(?:[.,]\d)?)\s*[мmMМ]',text)
            if number:return selected,float(number.group(1).replace(',','.'))
        return selected,float(bare.group().replace(',','.')) if bare else None
    except Exception:return selected,None


def read_target_distance(frame):
    """Top-HUD metres without waiting for world/name OCR."""
    h,w=frame.shape[:2]
    roi=frame[int(h*.027):int(h*.060),int(w*.57):int(w*.595)]
    if not roi.size:return None
    def parse(text):
        match=re.search(r'(\d{1,3}(?:[.,]\d)?)\s*[mMмМ]',text)
        if match:
            value=float(match.group(1).replace(',','.'))
            return value if value<=250 else None
        return None
    if roi.max()-roi.min()<15:return None
    gray=cv2.resize(cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY),None,fx=6,fy=6)
    config='--psm 7 -c tessedit_char_whitelist=0123456789.,mM'
    first=_ocr_text(gray,lang='eng',config=config)
    value=parse(first)
    if value is not None:return value
    roi=frame[int(h*.030):int(h*.055),int(w*.56):int(w*.60)]
    mask=cv2.inRange(cv2.cvtColor(roi,cv2.COLOR_BGR2HSV),(0,0,190),(179,25,255))
    trimmed=_trim(mask)
    if trimmed is None or np.count_nonzero(trimmed)<8:return None
    a=cv2.copyMakeBorder(cv2.resize(255-trimmed,None,fx=6,fy=6),15,15,15,15,cv2.BORDER_CONSTANT,value=255)
    second=_ocr_text(a,lang='eng',config=config)
    value=parse(second)
    if value is not None:return value
    one=re.fullmatch(r'\s*(\d{1,3}(?:[.,]\d)?)\s*',first)
    two=re.fullmatch(r'\s*(\d{1,3}(?:[.,]\d)?)\s*',second)
    if one and two and one.group(1).replace(',','.')==two.group(1).replace(',','.'):
        value=float(one.group(1).replace(',','.'))
        return value if value<=250 else None
    return None


_failure_label=None
_success_label=None
def gathering_panel(frame):
    """Recognize the fixed 'Неудача' label, even when just one bar is filled.
    Coloured terrain, pets' health bars and particle effects are not sufficient.
    """
    global _failure_label
    if _failure_label is None:_failure_label=cv2.imread(str(ROOT/'assets/gather_failure_label.png'),0)
    if _failure_label is None:return False
    h,w=frame.shape[:2]
    region=frame[int(h*.690):int(h*.856),int(w*.345):int(w*.685)]
    if region.size==0:return False
    hsv=cv2.cvtColor(region,cv2.COLOR_BGR2HSV)
    white=cv2.inRange(hsv,np.array([0,0,175]),np.array([179,65,255]))
    for factor in (.8,.9,1,1.1,1.2):
        scale=w/2558*factor
        tpl=cv2.resize(_failure_label,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
        if tpl.shape[0]>=white.shape[0] or tpl.shape[1]>=white.shape[1]:continue
        _,score,_,_=cv2.minMaxLoc(cv2.matchTemplate(white,tpl,cv2.TM_CCOEFF_NORMED))
        if score>=.65:return True
    return False

def gathering_panel_pair(frame):
    """Fallback for UI scales/positions missed by the old single-label crop.
    Both 'Успех' and 'Неудача' must be aligned as two neighbouring rows.
    """
    global _failure_label,_success_label
    if _failure_label is None:_failure_label=cv2.imread(str(ROOT/'assets/gather_failure_label.png'),0)
    if _success_label is None:_success_label=cv2.imread(str(ROOT/'assets/gather_success_label.png'),0)
    if _failure_label is None or _success_label is None:return False
    h,w=frame.shape[:2];roi=frame[round(h*.60):round(h*.92),round(w*.28):round(w*.80)]
    if not roi.size:return False
    white=cv2.inRange(cv2.cvtColor(roi,cv2.COLOR_BGR2HSV),(0,0,175),(179,65,255))
    for factor in (.65,.75,.85,1,1.15,1.3,1.5):
        scale=w/2558*factor
        fail=cv2.resize(_failure_label,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
        success=cv2.resize(_success_label,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
        if min(fail.shape)<3 or fail.shape[0]>=white.shape[0] or fail.shape[1]>=white.shape[1]:continue
        _,a,_,(fx,fy)=cv2.minMaxLoc(cv2.matchTemplate(white,fail,cv2.TM_CCOEFF_NORMED))
        if a<.58:continue
        y0=max(0,fy-round(60*scale));y1=max(0,fy-round(5*scale))
        x0=max(0,fx-round(12*scale));x1=min(white.shape[1],fx+success.shape[1]+round(14*scale))
        region=white[y0:y1,x0:x1]
        if region.shape[0]<=success.shape[0] or region.shape[1]<=success.shape[1]:continue
        _,b,_,_=cv2.minMaxLoc(cv2.matchTemplate(region,success,cv2.TM_CCOEFF_NORMED))
        if b>=.58:return True
    return False


class PromptDetector:
    def __init__(self,reference=None):
        p=reference or ROOT/'assets/f_prompt_reference.png'
        self.template=cv2.imread(str(p),cv2.IMREAD_GRAYSCALE)
        if self.template is None:raise FileNotFoundError(p)
        # Cross-resolution template scale is relative to source 2558-wide video.
    def detect(self,frame):
        h,w=frame.shape[:2]
        # Searching center world instead of entire window reduces false matches.
        roi=frame[int(h*.27):int(h*.75),int(w*.33):int(w*.72)]
        gray=cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY)
        best=-1
        for f in (0.80,0.90,1.0,1.10,1.20):
            scale=f*w/2558
            if scale<.2:continue
            tpl=cv2.resize(self.template,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
            if tpl.shape[0]>=gray.shape[0] or tpl.shape[1]>=gray.shape[1]:continue
            # Edge maps reduce sensitivity to background under semi-transparent UI.
            a=cv2.Canny(gray,50,120);t=cv2.Canny(tpl,50,120)
            if np.std(t)<2:continue
            _,score,_,_=cv2.minMaxLoc(cv2.matchTemplate(a,t,cv2.TM_CCOEFF_NORMED))
            best=max(best,float(score))
        return best>=.57,round(max(0,best),3)


def flight_gauge(frame):
    reading=read_flight(frame)
    return reading.energy,('CYAN' if reading.confirmed else 'HIDDEN')


def flight_mode_hint(frame):
    """Fallback state only (not energy measurement): contextual fly controls."""
    h,w=frame.shape[:2]
    roi=frame[int(.76*h):int(.95*h),int(.79*w):int(.99*w)]
    if roi.size==0:return False
    txt=pytesseract.image_to_string(roi,lang='rus',config='--psm 11').lower()
    return 'парение' in txt and ('режим' in txt or 'пол' in txt)


class WorldVision:
    def __init__(self,names=DEFAULT_NAMES):
        self.names=names
        self.prompt=PromptDetector()
    def scan(self,frame,world=True,candidates=True,target=True,names=None):
        names=self.names if names is None else names
        name,dist=selected_target(frame,names) if world and target else (None,None)
        candidate=find_world_resource(frame,names) if world and candidates and names else None
        f,score=self.prompt.detect(frame) if world and (name or candidate) else (False,0.0)
        g=gathering_panel(frame) if world else False
        e,st=flight_gauge(frame) if world else (None,'UNKNOWN')
        # Context help and cyan scenery alone do not prove that wings are open.
        return Observation(candidate,name,dist,bool(f),score,g,e,st)


def segment_count(frame):
    """Initial THREE-slot resource gauge model calibrated from t63/t276.
    Returns 1/2/3 or None. Doesn't invent count if upper panel is hidden.
    """
    h,w=frame.shape[:2]
    # A resource track has a dark horizontal frame around its green fill.
    # Green scenery/aurora in the same fixed rectangle is not a target panel.
    hud=frame[int(h*.05):int(h*.085),int(w*.405):int(w*.595)]
    if hud.size==0:return None
    hh=cv2.cvtColor(hud,cv2.COLOR_BGR2HSV)
    hm=cv2.inRange(hh,np.array([32,45,55]),np.array([95,255,255]))
    green=(hm>0).mean(axis=1)>.20
    dark=(hud.max(axis=2)<70).mean(axis=1)>.60
    margin=max(2,round(h*5/1440));framed=False
    starts=np.flatnonzero(green & ~np.r_[False,green[:-1]])
    ends=np.flatnonzero(green & ~np.r_[green[1:],False])
    for a,b in zip(starts,ends):
        if b-a+1<max(2,round(h/720)):continue
        if dark[max(0,a-margin):a].any() and dark[b+1:min(len(dark),b+1+margin)].any():
            framed=True;break
    if not framed:return None
    # Sample inside the three equal-sized coloured portions of upper HP/resource bar.
    rect=frame[int(h*84/1438):int(h*112/1438),int(w*1040/2558):int(w*1505/2558)]
    if rect.size==0:return None
    hsv=cv2.cvtColor(rect,cv2.COLOR_BGR2HSV)
    mask=cv2.inRange(hsv,np.array([32,45,55]),np.array([95,255,255]))
    scores=[]
    for i in range(3):
        tile=mask[:,round(mask.shape[1]*i/3):round(mask.shape[1]*(i+1)/3)]
        scores.append(float((tile>0).mean()))
    # Distinguish a valid 1/2/3-fill from random target bars / backgrounds.
    slots=[v>.31 for v in scores]
    if not slots[0]:return None
    if slots==[True,False,False]:return 1
    if slots==[True,True,False]:return 2
    if slots==[True,True,True]:return 3
    return None


def resource_header_visible(frame):
    """Fast resource-track presence independent of OCR and exact slot count.
    A title/track can remain visible while one of the three slot samples fails.
    Coloured sky without a pair of dark frame edges is not a resource track.
    """
    h,w=frame.shape[:2]
    roi=frame[round(h*.035):round(h*.105),round(w*.405):round(w*.595)]
    if not roi.size:return False
    green=cv2.morphologyEx(color_mask(roi),cv2.MORPH_OPEN,np.ones((1,max(8,round(w*.025))),np.uint8))
    rows=(green>0).sum(axis=1)>w*.025
    dark=(roi.max(axis=2)<90).mean(axis=1)>.55
    margin=max(3,round(h*.006))
    for a in np.flatnonzero(rows & ~np.r_[False,rows[:-1]]):
        ends=np.flatnonzero(~rows[a:])
        b=a+int(ends[0])-1 if len(ends) else len(rows)-1
        if b-a+1<max(2,round(h*.002)):continue
        if dark[max(0,a-margin):a].any() and dark[b+1:min(len(dark),b+1+margin)].any():return True
    return False


def gather_result_full(frame):
    """Either success/failure track reached the far right on any attempt.
    Call while the gathering panel is visible. Slot loss alone is not completion.
    """
    h,w=frame.shape[:2]
    # Learned from original 2560x1440 footage, bars at x~1034..1605 y~1086/1129.
    x1,x2=round(w*1540/2558),round(w*1602/2558)
    y1,y2=round(h*1080/1438),round(h*1154/1438)
    a=frame[y1:y2,x1:x2]
    if a.size==0:return False
    hsv=cv2.cvtColor(a,cv2.COLOR_BGR2HSV)
    cy=cv2.inRange(hsv,np.array([80,45,90]),np.array([113,255,255]))
    orange=cv2.inRange(hsv,np.array([5,80,80]),np.array([29,255,255]))
    for mask in (cy,orange):
        if ((mask>0).sum(axis=1)>a.shape[1]*.7).sum()>=max(2,round(6*h/1438)):return True
    return False
