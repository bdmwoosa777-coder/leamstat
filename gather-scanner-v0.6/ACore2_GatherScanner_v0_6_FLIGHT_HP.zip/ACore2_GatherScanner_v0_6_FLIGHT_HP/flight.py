"""Validate the curved HUD track before measuring flight energy (sky is not a gauge)."""
from dataclasses import dataclass
import numpy as np


@dataclass
class FlightReading:
    energy: float | None
    confirmed: bool
    evidence: int = 0


def read_flight(frame):
    h,w=frame.shape[:2]
    if w<900 or h<600:return FlightReading(None,False)
    yy=np.arange(476,727,dtype=float)
    xx=1047+46*((yy-597)/123)**2
    # Search small HUD shifts, but require an entire curved track with contrast.
    best=None
    offset=max(3,round(12*w/2560))
    for dy in range(-40,33,6):
        ys=np.rint((yy+180+dy)*h/1440).astype(int)
        if ys.min()<0 or ys.max()>=h:continue
        for dx in range(-12,15,3):
            xs=np.rint((xx+dx)*w/2560).astype(int)
            if xs.min()<offset or xs.max()+offset>=w:continue
            c=frame[ys,xs].astype(np.int16)
            l=frame[ys,xs-offset].astype(np.int16)
            r=frame[ys,xs+offset].astype(np.int16)
            b,g,red=c.T
            cyan=(g-red>22)&(b-red>15)&(g>145)&(b>130)
            low=(red-g>45)&(red-b>35)&(red>130)
            v=c.max(axis=1)
            fill=(cyan|low)&(v-np.maximum(l.max(axis=1),r.max(axis=1))>18)
            track=v<np.minimum(l.max(axis=1),r.max(axis=1))-18
            score=int((fill|track).sum())
            if best is None or score>best[0]:best=(score,fill)
    if best is None or best[0]<110:return FlightReading(None,False,0 if best is None else best[0])
    score,fill=best
    smooth=np.convolve(fill.astype(int),np.ones(5,dtype=int),mode='same')>=2
    positions=np.flatnonzero(smooth)
    if len(positions)<2:
        # A visible empty track is genuinely empty; an absent track never means zero.
        return FlightReading(0.0,True,score)
    if smooth[-25:].sum()<2:return FlightReading(None,True,score)
    energy=round(float((len(fill)-positions[0])/len(fill)*100),1)
    return FlightReading(energy,True,score)


class FlightBudget:
    def __init__(self,low=8.0,resume=18.0,recovery=.55,retry_delay=3.0):
        self.low,self.resume,self.recovery=low,resume,recovery
        self.retry_delay=max(1.0,retry_delay)
        self.energy=None;self.last_time=None;self.airborne=False;self.ground_since=None
        self.blocked=False;self.retry_after=0.0;self.failures=0;self.reason=''

    def failed_takeoff(self,now):
        # Missing confirmation is not proof of zero energy. Back off globally,
        # rather than toggling V again as soon as a different node is selected.
        self.failures=min(5,self.failures+1)
        self.retry_after=max(self.retry_after,now+min(30,self.retry_delay*2**(self.failures-1)))
        self.blocked=True;self.ground_since=now
        self.reason='раскрытие крыльев не подтверждено'

    def update(self,reading,now):
        if reading.confirmed:
            self.airborne=True;self.ground_since=None
            if reading.energy is not None:
                self.energy=reading.energy
                if self.energy<self.low:self.blocked=True;self.reason='мало энергии'
                elif self.energy>=self.resume:
                    self.failures=0;self.retry_after=0;self.blocked=False;self.reason=''
        else:
            if self.ground_since is None:self.ground_since=now
            if now-self.ground_since>1.5:
                self.airborne=False
                if self.energy is not None and self.last_time is not None:
                    # A long pause cannot prove uninterrupted regeneration.
                    self.energy=min(100,self.energy+max(0,min(1.0,now-self.last_time))*self.recovery)
        self.last_time=now
        if now<self.retry_after:self.blocked=True
        elif self.energy is None or self.energy>=self.resume:
            self.blocked=False;self.reason=''
        elif self.energy<self.low:self.blocked=True

    def can_start(self):return not self.blocked

    def can_probe(self,minimum=18):
        return self.can_start() and (self.energy is None or self.energy>=minimum)

    def describe(self,now):
        value='не измерена' if self.energy is None else f'{self.energy:.1f}% (измерение/оценка)'
        wait=max(0,self.retry_after-now)
        rule=f'возврат от {self.resume:.0f}%' if self.energy is not None else 'затем одна проверочная попытка'
        return f'энергия {value}; {self.reason or "ожидание восстановления"}; защитная задержка {wait:.0f} с, {rule}'
