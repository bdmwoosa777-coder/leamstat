from pathlib import Path
import threading,time,unittest
from unittest.mock import patch
import cv2
import numpy as np
from camera_pitch import PitchLedger
from flight import FlightReading,FlightBudget
from flight_probe import FlightProbe
from health import HealthMonitor,HPReading,parse_hp,read_hp
from view_guard import ViewGuard,scene_view
from gamepad_input import GamepadInput
from minimap import Marker
from navigation import Drive,Navigator
from defense import Threat
from test_navigation import GatherFixture,Pad,obs
from test_exploration import radar
import gather_engine as ge

ROOT=Path(__file__).parent
HIDDEN=FlightReading(None,False)


class HealthTests(unittest.TestCase):
    def test_real_hud_reads_the_right_number_as_maximum(self):
        for name in ('orihalkon_example.jpg','air_gather_example.jpg'):
            image=cv2.imread(str(ROOT/'testdata'/name));hp=read_hp(image)
            self.assertIsNotNone(hp,name)
            self.assertEqual((hp.current,hp.maximum),(18406,18406))

    def test_different_maximum_and_malformed_ocr(self):
        self.assertEqual(parse_hp('19 990 / 20 000').maximum,20000)
        for value in ('20001/20000','18431','/18431','0/0','1/9999999'):
            self.assertIsNone(parse_hp(value))

    def test_damage_is_latched_after_autoregen_and_maximum_can_change(self):
        health=HealthMonitor();image=np.zeros((40,120,3),np.uint8)
        health.numeric(image,HPReading(20000,20000),0);health.begin_gather()
        health.numeric(image,HPReading(19990,20000),.1)
        health.numeric(image,HPReading(20000,20000),.2)
        self.assertTrue(health.pending(0,.3));self.assertFalse(health.pending(0,5))
        health.numeric(image,HPReading(25000,25000),6);health.begin_gather()
        self.assertEqual(health.gather_maximum,25000)

    def test_fast_digit_change_survives_return_to_healthy_and_hidden_hud_is_ignored(self):
        image=np.zeros((40,120,3),np.uint8)
        cv2.putText(image,'18431',(0,28),cv2.FONT_HERSHEY_SIMPLEX,.7,(255,255,255),1)
        health=HealthMonitor();health.numeric(image,HPReading(18431,18431,(0,0,85,35)),0)
        health.fast(np.zeros_like(image),.05);self.assertEqual(health.sequence,0)
        damaged=image.copy();damaged[5:30,3:15]=255
        health.fast(damaged,.1);health.fast(image,.2)
        self.assertTrue(health.pending(0,.3));self.assertTrue(health.visually_full)


class PitchDeliveryTests(unittest.TestCase):
    def test_watchdog_reports_real_short_pulse_release(self):
        ledger=PitchLedger();pad=GamepadInput(factory=Pad,a_button=1)
        pad.motion_listener=ledger.report
        try:
            pad.drive(pitch=.4,lifetime=.04);time.sleep(.10)
            delivered=ledger.offset(time.monotonic())
            self.assertEqual(ledger.command,0)
            self.assertGreater(delivered,.010);self.assertLess(delivered,.030)
        finally:pad.close()

    def test_timeout_retains_residual_instead_of_allowing_tilted_walk(self):
        ledger=PitchLedger();ledger.balance=.5;ledger.restore(0);ledger.correction(20)
        self.assertTrue(ledger.failed);self.assertEqual(ledger.balance,.5)

    def test_ground_search_uses_both_small_directions_and_never_walks(self):
        nav=Navigator({});node=Marker('Самоцвет',110,100,.9,10)
        plans=[nav.update(radar([node]),i*.1) for i in range(25)]
        active=[p for p in plans if p.pitch]
        self.assertTrue(any(p.pitch>0 for p in active));self.assertTrue(any(p.pitch<0 for p in active))
        self.assertTrue(all(p.forward==p.strafe==0 and p.lifetime<=.05 for p in active))


class ProbeTests(unittest.TestCase):
    def probe(self):return FlightProbe(Marker('Эфир',110,100,.9,10,'aether'),0,{})

    def test_no_movement_before_flight_and_reserve_confirmation(self):
        p=self.probe();p.step(0,HIDDEN,0,90,90)
        self.assertEqual(p.step(.1,HIDDEN,.22,90,90).command,'V')
        for t in (.2,.4,1):self.assertIsNone(p.step(t,HIDDEN,.22,90,90).drive)
        action=p.step(1.1,FlightReading(10,True),.22,90,90)
        self.assertIsNone(action.drive);self.assertEqual(p.phase,'CLOSE')
        self.assertEqual(p.step(1.2,FlightReading(10,True),.22,90,90).command,'END_AIR')
        self.assertIsNone(p.step(1.3,FlightReading(10,True),.22,90,90).command)
        self.assertTrue(p.step(4,FlightReading(10,True),.22,90,90).stop)

    def test_rise_is_bounded_and_not_extended_by_slow_processing(self):
        p=self.probe();p.phase_to('WAIT_ARC',0)
        action=p.step(.1,FlightReading(50,True),.22,90,90)
        self.assertGreater(action.drive.forward,0);self.assertTrue(action.drive.tilted_motion)
        action=p.step(2,FlightReading(49,True),.22,90,90)
        self.assertIsNone(action.drive);self.assertEqual(p.phase,'PEEK')
        p.step(4,FlightReading(48,True),.22,90,90)
        self.assertEqual(p.step(4.1,FlightReading(48,True),.22,90,90).command,'END_AIR')
        self.assertTrue(p.step(4.2,HIDDEN,.22,90,90).done)

    def test_failed_takeoff_does_not_toggle_v_repeatedly(self):
        p=self.probe();p.phase_to('WAIT_ARC',0)
        a=p.step(4,HIDDEN,.22,90,90);self.assertTrue(a.failed_takeoff)
        self.assertTrue(p.step(4.1,HIDDEN,.22,90,90).done)

    def test_ten_percent_can_start_normal_flight_but_not_an_exploratory_probe(self):
        b=FlightBudget();b.update(FlightReading(10,True),0)
        self.assertTrue(b.can_start());self.assertFalse(b.can_probe())


class EngineHealthTests(GatherFixture,unittest.TestCase):
    def test_damage_even_after_heal_requests_tab_verification(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.mode='GATHER';self.e.resource_hold=True
        self.e.health.numeric(self.frame,HPReading(20000,20000),99)
        self.e.health.begin_gather();self.e.health.numeric(self.frame,HPReading(19999,20000),99.8)
        self.e.health.numeric(self.frame,HPReading(20000,20000),99.9)
        with patch.object(self.e,'_defend_and_resume') as defend:
            self.step(obs('Сапфир',distance=1),100,plate=3,panel=True)
        defend.assert_called_once_with(resume=True)

    def test_unrelated_tab_targets_are_never_attacked_even_if_hp_falls(self):
        self.e.target='Сапфир';self.e.target_confirmed=True
        self.e.health.numeric(self.frame,HPReading(19990,20000),time.monotonic())
        self.e.cfg['defense_max_tabs']=5
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(self.e,'_confirmed_aggressor',return_value=False):
            self.e._defend_and_resume(resume=False)
        self.assertEqual(self.commands.count('TAB'),5);self.assertNotIn('ATTACK_PAIR',self.commands)

    def test_fourth_tab_can_find_own_attacker_when_health_is_still_low(self):
        self.e.target='Сапфир';self.e.target_confirmed=True
        self.e.health.numeric(self.frame,HPReading(19990,20000),time.monotonic())
        clock=[100.0]
        def wait(*args):clock[0]+=.3;return True
        with patch.object(GamepadInput,'wait',side_effect=wait),patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(self.e,'_confirmed_aggressor',side_effect=[False,False,False,True]),patch.object(self.e.threat,'check',return_value=Threat(False,'',False,0)):
            self.e._defend_and_resume(resume=False)
        self.assertEqual(self.commands.count('TAB'),4);self.assertEqual(self.commands.count('ATTACK_PAIR'),1)

    def test_tilted_walk_is_blocked_until_camera_returns(self):
        self.e.pitch.balance=.2;self.e._motion(Drive(forward=.8))
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertTrue(self.e.pitch.returning)

    def test_defense_never_resumes_before_both_combat_panels_disappear(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;clock=[100.0]
        def wait(*args):clock[0]+=.3;return True
        with patch.object(GamepadInput,'wait',side_effect=wait),patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(self.e,'_confirmed_aggressor',return_value=True),patch.object(self.e.threat,'check',return_value=Threat(True,'Darkleam',True,100)),patch.object(self.e,'click_candidate') as click:
            self.e._defend_and_resume()
        if self.e.release_thread:self.e.release_thread.join(timeout=1)
        click.assert_not_called();self.assertTrue(self.e.stop_event.is_set())

    def test_visible_collection_blocks_probe_lift(self):
        self.e.probe=FlightProbe(Marker('Эфир',110,100,.9,10,'aether'),100,{})
        self.e.probe.phase='RISE';self.step(obs('Эфир'),100,plate=3,panel=True,reading=FlightReading(50,True))
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.e.mode,'GATHER')
        self.assertIsNone(self.e.probe)

    def test_low_energy_probe_request_skips_goal_and_retreats(self):
        self.e.nav.update(radar([Marker('Эфир',110,100,.9,10,'aether')]),100)
        self.e.budget.update(FlightReading(10,True),100);self.e._request_probe(100)
        self.assertIsNone(self.e.pending_probe);self.assertIsNone(self.e.nav.goal)
        self.assertTrue(self.e.nav.is_retreating(101))

    def test_disappeared_caption_after_alt_never_clicks_stale_coordinates(self):
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(ge,'find_world_resource',return_value=None):
            self.assertFalse(self.e.click_candidate(self.c,(0,0)))
        self.assertEqual(self.pad.presses,0);self.assertEqual(self.commands[-1],'ALT_UP')


class SceneGuardTests(unittest.TestCase):
    def test_ambiguous_uniform_scene_does_not_guess_an_absolute_horizon(self):
        guard=ViewGuard();frame=np.full((720,1280,3),150,np.uint8)
        self.assertEqual(scene_view(frame),'unknown')
        self.assertEqual(guard.update(frame,0),(None,False,False))

    def test_ground_must_be_seen_twice_before_accepting_a_new_baseline(self):
        guard=ViewGuard()
        with patch('view_guard.scene_view',side_effect=['sky','sky','ground','ground']):
            guard.update(None,0);a,ok,fail=guard.update(None,.4)
            self.assertLess(a.pitch,0);self.assertEqual(a.forward,0);self.assertFalse(ok)
            self.assertFalse(guard.update(None,.5)[1]);self.assertTrue(guard.update(None,.6)[1])

    def test_sky_recovery_stops_if_ground_never_appears(self):
        guard=ViewGuard()
        with patch('view_guard.scene_view',return_value='sky'):
            guard.update(None,0);guard.update(None,.4)
            self.assertTrue(guard.update(None,6)[2])


if __name__=='__main__':unittest.main()
