"""Independent player-HP reader plus fast glyph-change latch.

The right number is learned from the actual HUD, never hard-coded. Numeric
samples teach a full-HP digit patch; 80 ms comparisons latch short losses even
when autoregeneration restores the full value before the main OCR loop runs.
"""
from dataclasses import dataclass
import re,threading
import cv2
import numpy as np
import pytesseract


@dataclass
class HPReading:
    current:int
    maximum:int
    box:tuple|None=None


def text_mask(image):
    return cv2.inRange(cv2.cvtColor(image,cv2.COLOR_BGR2HSV),(0,0,180),(179,65,255))


def parse_hp(text):
    clean=re.sub(r'\s+','',text)
    found=re.fullmatch(r'(\d{1,7})/(\d{2,7})',clean)
    if not found:return None
    current,maximum=map(int,found.groups())
    if not 100<=maximum<=2000000 or not 0<=current<=maximum:return None
    return HPReading(current,maximum)


def read_hp(frame,roi=None):
    h,w=frame.shape[:2];x0,y0,x1,y1=roi or [.405,.858,.477,.888]
    ax,ay,bx,by=round(x0*w),round(y0*h),round(x1*w),round(y1*h)
    patch=frame[ay:by,ax:bx]
    if not patch.size:return None
    mask=text_mask(patch)
    if np.count_nonzero(mask)<25:return None
    enlarged=cv2.resize(mask,None,fx=4,fy=4,interpolation=cv2.INTER_CUBIC)
    data=pytesseract.image_to_data(enlarged,lang='eng',config='--psm 7 -c tessedit_char_whitelist=0123456789/',output_type=pytesseract.Output.DICT)
    indices=[i for i,t in enumerate(data['text']) if t.strip()]
    result=parse_hp(''.join(data['text'][i] for i in indices))
    if result is None:return None
    left=min(data['left'][i] for i in indices)/4;top=min(data['top'][i] for i in indices)/4
    right=max(data['left'][i]+data['width'][i] for i in indices)/4
    bottom=max(data['top'][i]+data['height'][i] for i in indices)/4
    # At full health both strings have the same width. Only the CURRENT half
    # is monitored, so a change to the maximum is not mistaken for damage.
    middle=(left+right)/2
    result.box=(max(0,ax+int(left)-1),max(0,ay+int(top)-1),
                min(w,ax+int(middle)-1),min(h,ay+int(bottom)+2))
    return result


class HealthMonitor:
    def __init__(self):
        self.lock=threading.RLock();self.current=None;self.maximum=None;self.gather_maximum=None
        self.sequence=0;self.last_damage=-1e9;self.numeric_at=0
        self.full_patch=None;self.full_box=None;self.shape=None;self.visually_full=True

    def _damage(self,now):
        if now-self.last_damage>=.12:self.sequence+=1
        self.last_damage=now

    def begin_gather(self):
        with self.lock:self.gather_maximum=self.maximum

    def numeric(self,frame,reading,now):
        if reading is None:return
        with self.lock:
            previous=self.current;self.current=reading.current;self.maximum=reading.maximum;self.numeric_at=now
            maximum=self.gather_maximum or self.maximum
            if reading.current<maximum and (previous is None or reading.current<previous):self._damage(now)
            if reading.current==reading.maximum:
                self.gather_maximum=reading.maximum
                if reading.box is not None:
                    x0,y0,x1,y1=reading.box;patch=frame[y0:y1,x0:x1]
                    if patch.size:
                        mask=text_mask(patch)
                        if np.count_nonzero(mask)>=20:
                            self.full_patch=mask>0;self.full_box=reading.box;self.shape=frame.shape[:2]
                            self.visually_full=True

    def fast(self,frame,now):
        with self.lock:
            if self.full_patch is None or frame.shape[:2]!=self.shape:return
            x0,y0,x1,y1=self.full_box;mask=text_mask(frame[y0:y1,x0:x1])>0
            total=max(1,int(self.full_patch.sum()))
            if mask.shape!=self.full_patch.shape or mask.sum()<total*.35:return
            changed=np.count_nonzero(mask!=self.full_patch)
            full=changed<=max(8,total*.055)
            if self.visually_full and not full:self._damage(now)
            self.visually_full=full

    def pending(self,handled,now):
        with self.lock:return self.sequence>handled and now-self.last_damage<4

    def ongoing(self,now):
        with self.lock:
            maximum=self.gather_maximum or self.maximum
            return now-self.last_damage<4 or (self.current is not None and maximum is not None and self.current<maximum)

    def state(self):
        with self.lock:return {'current':self.current,'maximum':self.maximum,'gather_maximum':self.gather_maximum,
                               'damage_sequence':self.sequence,'last_damage':self.last_damage}
