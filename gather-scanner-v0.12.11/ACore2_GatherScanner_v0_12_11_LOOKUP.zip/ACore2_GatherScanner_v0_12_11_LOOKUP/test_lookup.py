"""Early upward looks and a read-only, freshly revalidated neighbour handoff."""
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import math,unittest
import cv2,numpy as np
import app,vision,gather_engine as ge,hybrid_engine as he
from navigation import Navigator
from minimap import Marker
from flight import FlightReading
from ether_neighbors import EtherNeighbors,same_caption
from hybrid_engine import HybridGatherEngine
from test_navigation import GatherFixture,radar,obs
from test_network_control import Source
from test_ether_emblem import scene,ether,ROOT

GROUND=FlightReading(80,False)

def point(x=120,y=200):
 return vision.Candidate('Эфир',x+15,y+15,99,(x,y+40,54,18),emblem=(x,y,30,30))

def marker(x=130,y=100):return Marker('Эфир',x,y,.95,math.hypot(x-100,y-100),'aether')

class QuickLook(unittest.TestCase):
 def nav(self):return Navigator({'ether_quick_search':True,'air_search_wide':True,'air_search_map_radius':22})
 def test_lookup_starts_from_a_farther_minimap_marker_instead_of_walking_under_it(self):
  n=self.nav();d=n.update(radar([marker()]),100)
  self.assertGreater(d.pitch,0);self.assertEqual((d.forward,d.strafe),(0,0));self.assertGreaterEqual(d.lifetime,.20)
 def test_almost_overhead_marker_does_not_require_precise_yaw_before_looking_up(self):
  d=self.nav().update(radar([marker(105)],heading=270),100)
  self.assertGreater(d.pitch,0);self.assertEqual(d.yaw,0)
 def test_outer_upward_bracket_has_six_delivered_steps_and_balanced_return(self):
  n=self.nav();r=radar([marker()]);d=n.update(r,100);plans=[];now=100
  while not d.restore_pitch:
   plans.append(d);now=n.scan_next_at+.001;d=n.update(r,now);self.assertLess(len(plans),15)
  self.assertEqual(len(plans),13);self.assertTrue(all(p.pitch>0 for p in plans[:6]));self.assertEqual(plans[6].pitch,0)
  self.assertGreater(plans[0].lifetime,plans[1].lifetime);self.assertAlmostEqual(sum(p.pitch*p.lifetime for p in plans),0)
  self.assertFalse(d.flight_probe);self.assertTrue(n.air_outer_scanned)
 def test_close_bracket_is_finite_and_keeps_the_timed_pitch_balance(self):
  n=self.nav();r=radar([marker(105)]);d=n.update(r,100);plans=[];now=100
  while not d.restore_pitch:
   plans.append(d);now=max(now+1.2,n.scan_next_at+.001);d=n.update(r,now);self.assertLess(len(plans),28)
  self.assertEqual(len(plans),26);self.assertAlmostEqual(sum(p.pitch*p.lifetime for p in plans),0)
  self.assertLess(sum(p.lifetime for p in plans[:6]),.90)
 def test_delayed_ocr_does_not_skip_upward_steps(self):
  n=self.nav();r=radar([marker()]);n.update(r,100);n.update(r,101)
  d=n.update(r,130);self.assertEqual(n.scan_last_pulse,2);self.assertGreater(d.pitch,0)
 def test_failed_outer_look_closes_distance_without_excluding_or_flying(self):
  n=self.nav();r=radar([marker()]);d=n.update(r,100);now=100
  while not d.restore_pitch:now=n.scan_next_at+.001;d=n.update(r,now)
  d=n.update(r,now+1);self.assertGreater(d.forward,.5);self.assertEqual(d.pitch,0);self.assertFalse(d.flight_probe);self.assertFalse(n.excluded)
 def test_far_behind_marker_is_still_faced_before_the_outer_look(self):
  d=self.nav().update(radar([marker()],heading=270),100)
  self.assertEqual(d.pitch,0);self.assertNotEqual(d.yaw,0)
 def test_new_switch_is_enabled_in_production_defaults(self):
  self.assertTrue(app.DEFAULT['ether_quick_search']);self.assertTrue(app.DEFAULT['ether_neighbor_handoff'])

class NeighborMemory(unittest.TestCase):
 def test_owned_caption_is_not_a_neighbour_and_distinct_nearby_caption_is_retained(self):
  m=EtherNeighbors();a=point();b=point(160)
  m.observe((1,7,None),[a,b],a,100);self.assertEqual(m.current((1,7,None),101),(b,))
 def test_duplicate_sightings_refresh_one_entry_and_capacity_is_bounded(self):
  m=EtherNeighbors();a=point()
  for t in range(100,110):m.observe(1,[point(300)],a,t)
  self.assertEqual(len(m.current(1,110)),1)
  m.observe(1,[point(500+i*90) for i in range(12)],a,110);self.assertEqual(len(m.current(1,110)),6)
 def test_old_or_different_map_or_different_player_sightings_are_unusable(self):
  m=EtherNeighbors();a=point();b=point(300);m.observe((1,7,4),[b],a,100)
  for key,t in (((2,7,4),101),((1,8,4),101),((1,7,5),101),((1,7,4),106)):
   self.assertEqual(m.current(key,t),())
 def test_a_missing_owned_anchor_cannot_save_the_current_node_as_a_neighbour(self):
  m=EtherNeighbors();m.observe(1,[point()],None,100);self.assertEqual(m.entries,())
 def test_only_ether_with_an_emblem_is_saved(self):
  m=EtherNeighbors();a=point();m.observe(1,[replace(point(300),name='Морфа'),replace(point(400),emblem=None)],a,100)
  self.assertEqual(m.current(1,100),())
 def test_same_caption_matches_actual_boxes_not_an_eighty_pixel_circle(self):
  self.assertTrue(same_caption(point(),point(122)));self.assertFalse(same_caption(point(),point(160)))
 def test_overlapping_names_with_distinct_emblems_remain_distinct_neighbours(self):
  self.assertFalse(same_caption(point(),point(145)))

class HandoffEngine(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();old=self.e;self.source=Source();self.source.state.attempt_active=False
  self.e=HybridGatherEngine({**old.cfg,'ether_neighbor_handoff':True,'ether_quick_search':True,'analyzer_enabled':False,'hybrid_camp_exit':False},self.log.append,self.input,network=self.source)
  self.e.screen=old.screen;self.e.bridge=old.bridge;self.e.mode='GATHER';self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True
  self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
  self.source.state.nodes[99].used=3;self.source.state.nodes[99].gather_time=1000
  self.own=point();self.other=point(160);self.e.candidate=self.own;self.e.pitch.balance=.18
  self.clock=100.;timer=patch.object(he.time,'monotonic',side_effect=lambda:self.clock);timer.start();self.addCleanup(timer.stop)
  self.e.ether_neighbors.observe(self.e._neighbor_key(self.source.view()),[self.other],self.own,100)
  p=patch.object(he,'find_resource_near',side_effect=lambda f,c:c);p.start();self.addCleanup(p.stop)
 def prepare(self):return self.e._prepare_next_ether_view(self.frame,self.clock)
 def search(self):
  self.e.mode='SEARCH';self.e.target=None;self.e.target_confirmed=False;self.e.resource_hold=False;self.e.post_gather_until=0
 def test_fresh_neighbour_preserves_view_only_after_the_last_attempt(self):
  self.assertTrue(self.prepare());self.assertGreater(self.e.ether_handoff_until,100)
  self.source.state.nodes[99].used=2;self.assertFalse(self.prepare())
 def test_prepare_itself_never_clicks_or_moves_or_changes_owned_target(self):
  self.assertTrue(self.prepare());self.assertEqual(self.commands,[]);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.presses,0)
  self.assertEqual(self.e.network_target,(1,99));self.assertTrue(self.e.target_confirmed)
 def test_server_depletion_removal_is_also_a_valid_final_end(self):
  node=self.source.state.nodes[99];node.used=None;node.visible=False;node.removed_reason=4
  self.assertTrue(self.prepare())
 def test_passive_observer_retains_owned_observation_without_actions(self):
  self.source.state.nodes[99].used=1;self.source.state.attempt_active=True;self.source.state.started=1000
  ownobs=vision.Observation(self.own,'Эфир',None,False,0,False,None,'HIDDEN')
  self.e.ether_neighbors.clear()
  with patch.object(ge.GatherEngine,'_network_world_observation',return_value=ownobs),patch.object(he,'fast_ether_candidates',return_value=[self.own,self.other]):
   result=self.e._network_world_observation(self.frame)
  self.assertIs(result,ownobs);self.assertEqual(self.e.ether_neighbors.current(self.e._neighbor_key(self.source.view()),100),(self.other,))
  self.assertEqual(self.commands,[]);self.assertEqual(self.pad.presses,0);self.assertIsNone(self.e.caption_latch)
 def test_final_resource_transition_does_not_call_pitch_restore_when_neighbour_is_fresh(self):
  self.e.network_exhausted=True;self.e.fast_gather_seen=True
  with patch.object(self.e,'_restore_pitch') as restore:
   self.e.return_to_search('done',self.frame,exhausted=True,reading=GROUND)
  restore.assert_not_called();self.assertEqual(self.e.mode,'SEARCH');self.assertEqual(self.e.node_count,1)
  self.assertIsNone(self.e.camera_alignment_due);self.assertLess(self.e.post_gather_until,100.3)
 def test_after_depletion_fresh_neighbor_enters_acquire_without_a_new_scan(self):
  self.assertTrue(self.prepare());self.search();self.clock=100.3
  result=self.e._handoff_frame(self.frame,obs(),self.clock)
  self.assertEqual(result.candidate,self.other);self.assertIsNotNone(self.e.caption_latch)
  self.assertFalse(self.e.pitch.returning);self.assertEqual(self.e.ether_handoff_until,0)
 def test_different_close_neighbour_is_not_blocked_by_the_completed_nodes_cooldown(self):
  self.assertTrue(self.prepare());self.search();self.e.cooldowns=[('Эфир',self.own.click_x,self.own.click_y,110)]
  self.assertTrue(self.e._allowed(self.other,100));self.assertFalse(self.e._allowed(self.own,100))
 def test_other_failure_cooldowns_remain_active(self):
  self.assertTrue(self.prepare());self.search();self.e.cooldowns=[('Эфир',self.other.click_x,self.other.click_y,110)]
  self.assertFalse(self.e._allowed(self.other,100))
 def test_missing_or_expired_neighbour_restores_normal_camera_handling(self):
  self.assertTrue(self.prepare());self.search();self.clock=103
  result=self.e._handoff_frame(self.frame,obs(),103)
  self.assertIsNone(result.candidate);self.assertTrue(self.e.pitch.returning);self.assertIsNotNone(self.e.camera_alignment_due)
 def test_old_coordinates_cannot_authorize_a_click_after_resource_disappears(self):
  self.assertTrue(self.prepare());self.search()
  with patch.object(he,'find_resource_near',return_value=None):self.e._handoff_frame(self.frame,obs(),100)
  self.assertIsNone(self.e.caption_latch);self.assertEqual(self.pad.presses,0);self.assertTrue(self.e.pitch.returning)
 def test_a_new_own_attempt_revokes_handoff(self):
  self.assertTrue(self.prepare());self.search();self.source.state.attempt_active=True
  self.e._handoff_frame(self.frame,obs(),100);self.assertIsNone(self.e.caption_latch);self.assertEqual(self.pad.presses,0)
 def test_stop_focus_loss_map_or_low_energy_cannot_prepare_handoff(self):
  for attr,value in (('map_active',True),('stop_event',SimpleNamespace(is_set=lambda:True))):
   previous=getattr(self.e,attr);setattr(self.e,attr,value);self.assertFalse(self.prepare());setattr(self.e,attr,previous)
  self.e.screen.focused=lambda:False;self.assertFalse(self.prepare())
  self.e.screen.focused=lambda:True;self.e.budget.blocked=True;self.assertFalse(self.prepare())
 def test_wrong_rejected_word_cannot_prepare_neighbour(self):
  with patch.object(self.e,'_caption_rejected',return_value=True):self.assertFalse(self.prepare())
 def test_neighbour_must_still_have_its_caption_on_a_fresh_frame(self):
  with patch.object(he,'find_resource_near',return_value=None):self.assertFalse(self.prepare())
 def test_read_only_sightings_are_bound_to_the_current_map(self):
  self.source.state.map_id=55
  with patch.object(he,'fast_ether_candidates',return_value=[]):self.assertFalse(self.prepare())

class RealNeighbourFrames(unittest.TestCase):
 def test_two_real_caption_emblem_crops_yield_a_distinct_refreshable_neighbour(self):
  f=scene(x=800,y=250);crop=cv2.imread(str(ROOT/'ether_near_caption_crop.png'));h,w=crop.shape[:2]
  f[320:320+h,1250:1250+w]=crop
  candidates=vision.fast_ether_candidates(f);self.assertGreaterEqual(len(candidates),2)
  own=min(candidates,key=lambda c:c.box[0]);other=max(candidates,key=lambda c:c.box[0]);self.assertFalse(same_caption(own,other))
  memory=EtherNeighbors();memory.observe(1,candidates,own,100);self.assertEqual(len(memory.current(1,100)),1)
  fresh=vision.find_resource_near(f,other);self.assertIsNotNone(fresh);self.assertIsNotNone(fresh.emblem)
  f[320:320+h,1250:1250+w]=35
  self.assertIsNone(vision.find_resource_near(f,other))

if __name__=='__main__':unittest.main()
