"""Straight patrol legs, pulsed camera steering, and a separate sky search."""
from collections import deque
from dataclasses import dataclass
import math
from minimap import angle_delta
from camera_control import PITCH_STRENGTH
from camera_working_view import working_view_ms


@dataclass
class Drive:
    forward:float=0.0
    strafe:float=0.0
    yaw:float=0.0
    pitch:float=0.0
    reason:str=''
    restore_pitch:bool=False
    lifetime:float=.45
    flight_probe:bool=False
    tilted_motion:bool=False
    yaw_lifetime:float|None=None


class Navigator:
    def __init__(self,cfg):
        self.cfg=cfg;self.goal=None;self.best_distance=None;self.goal_seen=0
        self.progress_at=None;self.last_time=None;self.last_heading=None;self.heading_at=None
        self.headings=deque(maxlen=3);self.proposed_heading=None;self.proposed_at=None
        self.yaw_sign=cfg.get('camera_yaw_sign',1);self.last_yaw=0
        self.excluded=[];self.recovery_until=0;self.motion_since=None
        self.motion_sum=0;self.motion_samples=0
        self.pulse_until=0;self.pulse_value=0;self.next_pulse=0;self.last_turn_sign=0
        self.reverse_sign=0;self.reverse_since=0
        self.leg_since=None;self.leg_number=0;self.leg_turn_until=0
        self.air_since=None;self.air_key=None;self.air_finished=False
        self.position=[0.0,0.0];self.trail=deque();self.escape_until=0
        self.walk_at=None;self.was_walking=False
        self.route_bearing=None;self.route_reason='';self.route_priority=False
        self.retreat_until=0;self.retreat_bearing=None;self.retreat_pending=False
        self.kind_until={};self.last_center=(0,0);self.last_scale=1
        self.scan_last_pulse=-1;self.scan_kind=None;self.scan_next_at=0;self.scan_pulse_end=0;self.scan_pitch=0
        self.goal_started=None;self.goal_motion_at=None
        self.ground_detours=0;self.ground_detour_pending=False;self.ground_detour_until=0
        self.air_outer_scanned=False
        self.scan_outer=False

    def pause(self,now):
        self.progress_at=now;self.motion_since=now;self.motion_sum=0;self.motion_samples=0
        self.last_yaw=0;self.pulse_until=0;self.next_pulse=now+.3
        self.leg_since=now
        if self.retreat_pending:
            self.retreat_until=now+self.cfg.get('retreat_seconds',5);self.retreat_pending=False

    def finish_goal(self,now):
        # Successful collection retires this goal, never a circle containing
        # other live Ether markers. Server depletion and post-gather settling
        # handle the short-lived old caption/marker.
        self.goal=None;self.best_distance=None;self.air_since=None;self.air_key=None;self.scan_kind=None;self.pause(now)
        self.ground_detour_pending=False;self.ground_detour_until=0

    def exclude_goal(self,now,seconds=35):
        if self.goal:self.excluded.append([self.goal.kind,self.goal.x,self.goal.y,now+seconds,24*self.last_scale])
        self.finish_goal(now)

    def _ground_detour(self,now):
        self.ground_detours+=1;self.ground_detour_pending=True
        self.air_since=None;self.scan_kind=None;self.progress_at=now
        self.motion_since=None;self.motion_sum=0;self.motion_samples=0
        return Drive(restore_pitch=True,reason='подпись скрыта рельефом: возвращаю наклон и меняю точку обзора на земле')

    def abandon_goal(self,now,seconds=60):
        goal=self.goal;cx,cy=self.last_center
        if goal is not None:
            if goal.kind!='aether':self.kind_until[goal.kind]=now+12
            bearing=math.degrees(math.atan2(goal.x-cx,cy-goal.y))%360
            self.retreat_bearing=(bearing+180)%360 if goal.distance>3*self.last_scale else None
        else:self.retreat_bearing=None
        self.exclude_goal(now,seconds)
        self.retreat_pending=True;self.retreat_until=now+self.cfg.get('retreat_seconds',5)

    def is_retreating(self,now):return self.retreat_pending or now<self.retreat_until

    def _retreat(self,heading,now):
        if self.retreat_bearing is None and heading is not None:self.retreat_bearing=(heading+180)%360
        if heading is None:return Drive(-.65,.15,0,0,'отхожу от недоступной цели назад; камера не читается')
        return self._move_to(self.retreat_bearing,heading,now,'недоступная цель пропущена: ухожу в противоположную сторону')

    def route(self,bearing,reason='',priority=False):
        self.route_bearing=bearing;self.route_reason=reason;self.route_priority=priority

    def _heading(self,radar,now):
        value=radar.heading
        if value is not None and radar.confidence>=self.cfg.get('heading_min_confidence',.30):
            if self.last_heading is not None and abs(angle_delta(value,self.last_heading))>35:
                # A road can mimic a cone edge by 40–60 degrees, too. Require
                # a stable new reading before reversing the movement vector.
                if self.proposed_heading is None or abs(angle_delta(value,self.proposed_heading))>20:
                    self.proposed_heading=value;self.proposed_at=now
                    value=None
                elif now-self.proposed_at<.20:value=None
                else:self.headings.clear();self.proposed_heading=None
            else:self.proposed_heading=None
            if value is not None:
                self.headings.append(value)
                anchor=self.headings[0]
                ordered=sorted(angle_delta(v,anchor) for v in self.headings)
                self.last_heading=(anchor+ordered[len(ordered)//2])%360;self.heading_at=now
        if self.heading_at is not None and now-self.heading_at<1.5:return self.last_heading
        return None

    def _yaw(self,error,now):
        # A pulse is followed by a settling interval. Do not reverse it every
        # video frame when the heading fluctuates around the desired bearing.
        if abs(error)<self.cfg.get('steering_deadband_degrees',16):
            self.pulse_until=0;return 0.0
        if now<self.pulse_until:return self.pulse_value
        if now<self.next_pulse:return 0.0
        sign=1 if error>0 else -1
        if self.last_turn_sign and sign!=self.last_turn_sign:
            if abs(error)<28:return 0.0
            if self.reverse_sign!=sign:
                self.reverse_sign=sign;self.reverse_since=now;return 0.0
            if now-self.reverse_since<.40:return 0.0
        else:self.reverse_sign=0
        self.pulse_value=sign*(.42 if abs(error)<55 else .62)*self.yaw_sign
        duration=max(.03,min(.25,self.cfg.get('camera_pulse_seconds',.12))*min(1,abs(error)/55))
        self.pulse_until=now+duration
        self.next_pulse=self.pulse_until+self.cfg.get('camera_settle_seconds',.55)
        self.last_turn_sign=sign
        return self.pulse_value

    def _move_to(self,desired,heading,now,reason):
        if heading is None:
            return Drive(.55,0,0,0,reason+'; направление камеры временно не читается, короткий прямой проход')
        error=angle_delta(desired,heading);r=math.radians(error)
        # Camera-relative 2-D stick vector: a large camera error no longer
        # forces the character to stand still. Camera turns are only pulses.
        speed=self.cfg.get('resource_walk_speed',.78)
        return Drive(speed*math.cos(r),speed*math.sin(r),self._yaw(error,now),0,
                     reason+f'; курс {desired:.0f}°, камера {heading:.0f}°, ошибка {error:.0f}°',
                     yaw_lifetime=max(.02,self.pulse_until-now))

    def _scan(self,goal,now):
        air=goal.kind=='aether'
        if self.air_since is None:
            self.air_since=now;self.air_key=(goal.x,goal.y);self.scan_last_pulse=-1;self.scan_kind=goal.kind
            self.scan_outer=air and goal.distance>18*self.last_scale and not self.air_outer_scanned
        elapsed=now-self.air_since
        if air and self.cfg.get('air_search_wide',False):return self._wide_air_scan(now)
        directions=([1]*9+[-1]*10+[1]) if air else [-1]*4+[1]*6+[-1]*2
        phase_seconds=.38 if air else .25
        index=int(elapsed/phase_seconds)
        if index>=len(directions):
            self.air_since=None;self.scan_kind=None
            if not air and self.ground_detours==0:return self._ground_detour(now)
            return Drive(reason='подпись не найдена после короткого обзора; проверяю возможность подъёма',
                         restore_pitch=True,flight_probe=True)
        pitch=0.0
        if index!=self.scan_last_pulse:
            self.scan_last_pulse=index
            pitch=directions[index]*PITCH_STRENGTH
        return Drive(pitch=pitch,lifetime=.065*1.15 if air else .045,
                     reason=('эфир' if air else 'наземный ресурс')+f': короткий обзор вверх-вниз {index+1}/{len(directions)}')

    def _wide_air_scan(self,now):
        # Advance by delivered commands, never by skipped wall-clock phases.
        # Each step gives the fast glyph detector a stationary view. The
        # search brackets the initial tilt instead of sweeping past the name.
        pulse=min(.078,max(.02,(working_view_ms(self.cfg)-20)/1000/(8 if self.scan_outer else 10)))
        # A farther marker gets a short first look, not a full stationary
        # near-resource search. If unseen, close in before the wider bracket.
        phases=([(1,pulse)]*8+[(0,.75)]+[(-1,pulse)]*8 if self.scan_outer else
                [(1,pulse)]*10+[(0,.50)]+[(-1,pulse)]*20+[(0,.50)]+[(1,pulse)]*10)
        if self.cfg.get('ether_quick_search',False):
            # Get the sky into view early. Inspect after each delivered pulse;
            # subsequent fine steps can stop immediately on a visible caption.
            total=min(max(.12,(working_view_ms(self.cfg)-20)/1000),.70 if self.scan_outer else .88)
            first=min(.24,total*.4);rest=(total-first)/5
            up=[(1,first)]+[(1,rest)]*5;down=[(-1,s) for _,s in reversed(up)]
            phases=up+[(0,.25)]+down if self.scan_outer else up+[(0,.25)]+down+down+[(0,.25)]+up
        # Finite delivered steps own this scan. OCR/defense pauses must not
        # spend its wall-clock allowance and cut it off after one up pulse.
        if self.scan_last_pulse+1>=len(phases) and now>=self.scan_next_at:
            self.air_since=None;self.scan_kind=None
            if self.scan_outer and self.goal is not None:
                self.air_outer_scanned=True;self.progress_at=now;self.goal_started=now
                return Drive(restore_pitch=True,reason='дальний обзор эфира завершён: подпись не найдена, подхожу ближе по миникарте')
            return Drive(restore_pitch=True,flight_probe=True,reason='расширенный обзор эфира завершён; возвращаю наклон')
        if self.scan_last_pulse>=0 and now<self.scan_next_at:
            if self.scan_pitch and now<self.scan_pulse_end:
                return Drive(pitch=self.scan_pitch,lifetime=self.scan_pulse_end-now,reason='эфир: завершаю короткий подъём/опускание камеры')
            return Drive(reason='эфир: выдерживаю ракурс для распознавания')
        self.scan_last_pulse+=1;direction,seconds=phases[self.scan_last_pulse]
        self.scan_next_at=now+seconds+.30;self.scan_pulse_end=now+seconds;self.scan_pitch=direction*PITCH_STRENGTH
        return Drive(pitch=direction*PITCH_STRENGTH,lifetime=seconds,
                     reason=f'эфир: расширенный обзор {self.scan_last_pulse+1}/{len(phases)}, '+('выше' if direction>0 else 'ниже' if direction<0 else 'пауза'))

    def _air(self,goal,now):return self._scan(goal,now)

    def track_walk(self,radar,walking,now):
        """Only delivered search movement and consecutive valid terrain frames.

        A short net displacement despite a long travelled path is a loop, not
        progress. Standstill belongs to PatrolStall's separate flight recovery.
        """
        previous=self.walk_at;self.walk_at=now
        measured=(self.was_walking and walking and previous is not None
                  and 0<now-previous<=1.2 and radar.motion_valid)
        self.was_walking=walking
        if not measured or now<self.escape_until:
            self.trail.clear()
            return False
        scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
        dx,dy=radar.displacement
        self.position[0]-=dx/scale;self.position[1]-=dy/scale
        self.trail.append((now,*self.position,min(.5,now-previous)))
        while self.trail and now-self.trail[0][0]>20:self.trail.popleft()
        if len(self.trail)<12 or now-self.trail[0][0]<12:return False
        measured_seconds=sum(p[3] for p in self.trail)
        first=self.trail[0];net=math.dist(self.position,first[1:3])
        path=sum(math.dist(a[1:3],b[1:3]) for a,b in zip(self.trail,list(self.trail)[1:]))
        if measured_seconds<8 or path<30 or net>=path*.28:return False
        # Exclude only the unselected minimap hint. The engine calls this solely
        # during SEARCH; a selected resource/native auto-path never enters here.
        self.exclude_goal(now,35)
        self.retreat_until=0;self.retreat_pending=False;self.retreat_bearing=None
        self.escape_until=now+12;self.leg_turn_until=0;self.leg_since=now+12
        self.trail.clear()
        return True

    def update(self,radar,now,allow_air=True):
        dt=0 if self.last_time is None else max(0,min(.5,now-self.last_time))
        self.last_time=now
        scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
        self.last_scale=scale;self.last_center=radar.center
        if self.retreat_pending:
            self.retreat_until=now+self.cfg.get('retreat_seconds',5);self.retreat_pending=False
        self.excluded=[g for g in self.excluded if g[3]>now]
        if radar.motion_valid:
            dx,dy=radar.displacement
            for g in self.excluded:g[1]+=dx;g[2]+=dy
        else:
            for g in self.excluded:g[4]=min(70*scale,g[4]+dt*4*scale)
        rejected=set()
        for e in self.excluded:
            matches=[(math.hypot(m.x-e[1],m.y-e[2]),i) for i,m in enumerate(radar.markers)
                     if e[0]==m.kind and math.hypot(m.x-e[1],m.y-e[2])<e[4]]
            if e[0]=='aether':
                # A minimap hint has no actor ID. Match only its nearest
                # rendered marker, never blacklist every Ether in that area.
                if matches:rejected.add(min(matches)[1])
            else:rejected.update(i for _,i in matches)
        candidates=[m for i,m in enumerate(radar.markers) if (allow_air or m.kind!='aether') and
                    now>=self.kind_until.get(m.kind,0) and i not in rejected]
        if self.is_retreating(now) or now<self.escape_until:candidates=[];self.goal=None
        if self.route_priority:candidates=[];self.goal=None
        if self.goal is not None and self.goal.kind=='aether' and not allow_air:self.goal=None
        if self.goal:
            dx,dy=radar.displacement if radar.motion_valid else (0,0)
            matches=[m for m in candidates if m.kind==self.goal.kind and math.hypot(m.x-self.goal.x-dx,m.y-self.goal.y-dy)<22*scale]
            if matches:
                self.goal=min(matches,key=lambda m:math.hypot(m.x-self.goal.x-dx,m.y-self.goal.y-dy));self.goal_seen=now
            else:
                if radar.motion_valid:
                    self.goal.x+=dx;self.goal.y+=dy
                    self.goal.distance=math.hypot(self.goal.x-radar.center[0],self.goal.y-radar.center[1])
                lifetime=11 if self.air_since is not None else (6 if self.goal.distance<14*scale else 1.2)
                if now-self.goal_seen>lifetime:self.goal=None;self.best_distance=None
        if self.goal is None and candidates:
            self.goal=min(candidates,key=lambda m:m.distance);self.goal_seen=now
            self.best_distance=self.goal.distance;self.progress_at=now
            self.goal_started=now;self.goal_motion_at=None
            self.ground_detours=0;self.ground_detour_pending=False;self.ground_detour_until=0
            self.air_outer_scanned=False
            self.air_since=None;self.scan_kind=None
        heading=self._heading(radar,now)
        if self.is_retreating(now):return self._retreat(heading,now)
        if self.ground_detour_pending:
            self.ground_detour_pending=False;self.ground_detour_until=now+1.2
        if self.goal is not None and now<self.ground_detour_until:
            return Drive(.15,.5,0,0,'короткий проход вбок: заглядываю за край/камень без крыльев')
        if self.route_priority and self.route_bearing is None:
            return Drive(reason='ориентация маршрута по карте не подтверждена; движение приостановлено')
        if self.air_since is not None and (self.goal is None or self.goal.kind!=self.scan_kind
                                           or (self.scan_kind=='aether' and not allow_air)):
            self.air_since=None
            return Drive(reason='возвращаю прежний наклон после поиска эфира',restore_pitch=True)
        if now<self.escape_until:
            return Drive(self.cfg.get('patrol_walk_speed',.78),reason='выход из петли: прямой проход 12 с без поворота камеры')
        if now<self.recovery_until:
            remaining=self.recovery_until-now
            return Drive(-.35,.5,0,0,'обход упора: назад/вбок') if remaining>.6 else Drive(.5,0,.55*self.yaw_sign,0,'обход упора: короткий поворот и движение')
        if self.goal:
            goal=self.goal
            if goal.kind=='aether' and self.air_since is not None:return self._air(goal,now)
            if radar.motion_valid and math.hypot(*radar.displacement)>.15*scale:
                self.goal_motion_at=now
            if self.goal_started is not None and now-self.goal_started>self.cfg.get('minimap_goal_timeout_seconds',45):
                return Drive(reason='длительный подход не открыл ресурс: проверяю ограниченный облёт',restore_pitch=True,flight_probe=True)
            if self.best_distance is None or goal.distance<self.best_distance-1.5*scale:
                self.best_distance=goal.distance;self.progress_at=now
            desired=math.degrees(math.atan2(goal.x-radar.center[0],radar.center[1]-goal.y))%360
            if goal.kind=='aether':
                if self.air_since is not None:return self._air(goal,now)
                radius=min(30,max(8,self.cfg.get('air_search_map_radius',30)))
                if self.cfg.get('ether_quick_search',False):radius=max(radius,60)
                if self.air_outer_scanned:radius=min(18,radius)
                near=goal.distance<radius*scale
                aligned=heading is not None and abs(angle_delta(desired,heading))<(65 if self.cfg.get('ether_quick_search',False) else 30)
                if self.cfg.get('ether_quick_search',False) and goal.distance<16*scale:aligned=True
                if near and aligned:return self._air(goal,now)
                if near and heading is not None and not aligned:
                    error=angle_delta(desired,heading)
                    return Drive(yaw=self._yaw(error,now),lifetime=max(.02,self.pulse_until-now),
                                 reason='эфир: сначала поворачиваю обзор к его отметке, затем ищу выше',
                                 yaw_lifetime=max(.02,self.pulse_until-now))
            else:
                if self.air_since is not None:return self._scan(goal,now)
                aligned=heading is not None and abs(angle_delta(desired,heading))<25
                if goal.distance<min(10,self.cfg.get('ground_search_map_radius',8))*scale and (aligned or goal.distance<4*scale):
                    return self._scan(goal,now)
            plan=self._move_to(desired,heading,now,'к '+goal.name)
            if self.progress_at is not None and now-self.progress_at>self.cfg.get('navigation_stall_seconds',6):
                moving=self.goal_motion_at is not None and now-self.goal_motion_at<1
                unknown=not radar.motion_valid and now-self.progress_at<self.cfg.get('navigation_unknown_stall_seconds',12)
                if moving or unknown:return plan
                if goal.kind=='gem' and self.ground_detours==0:return self._ground_detour(now)
                return Drive(reason='нет сближения с ресурсом: пробую ограниченный подъём',restore_pitch=True,flight_probe=True)
        elif self.route_bearing is not None:
            plan=self._move_to(self.route_bearing,heading,now,self.route_reason or 'маршрут по большой карте')
        else:
            if self.leg_since is None:self.leg_since=now
            duration=self.cfg.get('patrol_leg_seconds',24)
            if now-self.leg_since>=duration and now>=self.escape_until:
                self.leg_number+=1;self.leg_since=now
                self.leg_turn_until=now+.24
            yaw=0.0
            if now<self.leg_turn_until:
                yaw=(.55 if self.leg_number%3 else -.65)*self.yaw_sign
            plan=Drive(self.cfg.get('patrol_walk_speed',.78),0,yaw,0,
                       'патруль: длинный прямой проход' if not yaw else 'патруль: короткая смена направления',
                       yaw_lifetime=max(.02,self.leg_turn_until-now) if yaw else None)
        if self.motion_since is None:self.motion_since=now
        if radar.motion_valid and math.hypot(plan.forward,plan.strafe)>.2:
            self.motion_sum+=math.hypot(*radar.displacement);self.motion_samples+=1
        if now-self.motion_since>=4:
            if self.motion_samples>=12 and self.motion_sum<1.5 and math.hypot(plan.forward,plan.strafe)>.2:
                if self.goal is not None:
                    if self.goal.kind=='gem' and self.ground_detours==0:return self._ground_detour(now)
                    return Drive(reason='упор перед ресурсом: пробую ограниченный подъём',restore_pitch=True,flight_probe=True)
                # Do not chain four-second 180-degree retreats around trees.
                # The engine's measured ten-second PatrolStall owns this case.
                pass
            self.motion_since=now;self.motion_sum=0;self.motion_samples=0
        self.last_yaw=plan.yaw
        return plan
