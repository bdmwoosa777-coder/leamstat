"""Before gameplay: load resident weights and require a usable visual response.
Synthetic images only. This function has no capture, gamepad or game state.
"""
import time
from dataclasses import replace
import cv2
from qwen_experiment import validate

class PreflightFailure(RuntimeError):pass

def prepare(client,stop,emit,phase=lambda value:None,clock=None):
 if clock is None:clock=time.monotonic
 from check_qwen_experiment import synthetic_views
 views=tuple(replace(v,world=cv2.resize(v.world,(768,432))) for v in synthetic_views())
 started=clock();phase('загрузка модели');emit('QWEN_PRELOAD: загружаю модель до начала управления')
 client.warmup(timeout=90);load_seconds=clock()-started
 if stop.is_set():return None
 attempts=[]
 for compact in (False,True):
  phase('проверка ответа: '+('компактный' if compact else 'обычный'))
  client.compact=compact;began=clock()
  try:
   answer=validate(client.analyze_views(views,timeout=12));elapsed=clock()-began
   attempt={'profile':'compact' if compact else 'balanced','seconds':round(elapsed,3),'valid_answer':True}
   attempts.append(attempt)
   if stop.is_set():return None
   if elapsed<=6.5:
    return {'load_seconds':round(load_seconds,3),'seconds':round(clock()-started,3),'profile':attempt['profile'],
            'visual_seconds':round(elapsed,3),'attempts':attempts,'game_frames_analyzed':False}
  except Exception as exc:
   attempts.append({'profile':'compact' if compact else 'balanced','seconds':round(clock()-began,3),'error':str(exc)})
   if stop.is_set():return None
  emit('QWEN_PREFLIGHT_RETRY: '+str(attempts[-1])+'; проверяю более лёгкий профиль' if not compact else 'QWEN_PREFLIGHT_FAILED: '+str(attempts[-1]))
 raise PreflightFailure('Оба профиля не дали проверенный ответ за 6.5 с: '+str(attempts))
