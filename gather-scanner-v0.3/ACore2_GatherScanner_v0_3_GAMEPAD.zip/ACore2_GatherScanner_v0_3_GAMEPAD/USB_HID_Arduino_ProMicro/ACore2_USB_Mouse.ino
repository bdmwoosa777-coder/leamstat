/* ACore2 USB HID mouse proof of concept for Arduino Leonardo/Micro/Pro Micro (ATmega32U4).
 * Requires Arduino IDE's bundled Mouse.h and a NATIVE USB HID-capable board.
 * DO NOT flash to Arduino Uno/Nano with CH340: their USB interface is not native HID.
 * This code does not bypass or modify any game process.
 * A physical arm switch between PIN 4 and GND is REQUIRED for clicks.
 * Disconnect the jumper to disarm, or unplug USB to immediately stop.
 */
#include <Mouse.h>
const uint8_t ARM_PIN = 4;
String rx;
unsigned long lastDoubleMs = 0;
void setup() {
  pinMode(ARM_PIN, INPUT_PULLUP);
  Serial.begin(115200);
  Mouse.begin();
  rx.reserve(48);
}
void doCommand(String cmd) {
  cmd.trim();
  if (cmd == "ACORE2 PING") {
    Serial.println("PONG");
    return;
  }
  if (cmd == "ACORE2 DOUBLE") {
    if (digitalRead(ARM_PIN) != LOW) {
      Serial.println("ERR DISARMED");
      return;
    }
    if (lastDoubleMs && millis() - lastDoubleMs < 950) {
      Serial.println("ERR RATE_LIMIT");
      return;
    }
    lastDoubleMs = millis();
    Mouse.press(MOUSE_LEFT);
    delay(85);
    Mouse.release(MOUSE_LEFT);
    delay(145);
    Mouse.press(MOUSE_LEFT);
    delay(85);
    Mouse.release(MOUSE_LEFT);
    Serial.println("DONE DOUBLE");
    return;
  }
  Serial.println("ERR UNKNOWN_COMMAND");
}
void loop() {
  while (Serial.available()) {
    char c = (char)Serial.read();
    if (c == '\n') {
      doCommand(rx);
      rx = "";
    } else if (c != '\r') {
      if (rx.length() < 48) rx += c;
      else rx = "";
    }
  }
}
