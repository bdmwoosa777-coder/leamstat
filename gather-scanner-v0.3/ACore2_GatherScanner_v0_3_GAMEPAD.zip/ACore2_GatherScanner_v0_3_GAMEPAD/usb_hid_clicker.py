# -*- coding: utf-8 -*-
"""Optional separate USB HID mouse (Arduino Micro / Leonardo / Pro Micro).

Not Logitech, and NOT a software click. No compatibility guarantee with AION 2.
This module only provides a transport to the user's own physical USB device.
"""
import time


class USBHIDClicker:
    def __init__(self, port, logger=None, serial_factory=None):
        self.port = port
        self.log = logger or (lambda _msg: None)
        if serial_factory is None:
            try:
                import serial
            except ImportError as ex:
                raise RuntimeError('Нужен pyserial: python -m pip install pyserial') from ex
            serial_factory = serial.Serial
        self.ser = serial_factory(port=port, baudrate=115200, timeout=1.6, write_timeout=1.6)
        # Leonardo/Pro Micro may auto-reset when CDC serial is opened.
        time.sleep(2.3)
        self.ser.reset_input_buffer()
        self.send('PING', allowed={'PONG'})
        self.log('USB HID: микроконтроллер отвечает на PING')

    def send(self, cmd, allowed):
        self.ser.write(('ACORE2 '+cmd+'\n').encode('ascii'))
        self.ser.flush()
        deadline=time.monotonic()+2.5
        while time.monotonic()<deadline:
            response=self.ser.readline().decode('ascii',errors='replace').strip()
            if response in allowed:return response
            if response.startswith('ERR'):
                raise RuntimeError('USB HID: '+response)
        raise TimeoutError('USB HID: нет подтверждения '+cmd)

    def double_click(self):
        result=self.send('DOUBLE',{'DONE DOUBLE'})
        self.log('USB HID: устройство подтвердило завершение двойного ЛКМ (игра ещё не подтверждена)')
        return result

    def close(self):
        try:self.ser.close()
        except Exception:pass
