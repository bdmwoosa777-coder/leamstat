# -*- coding: utf-8 -*-
"""AION 2 visual-only helpers, first prototype. No game memory access."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import os
import re
import cv2
import numpy as np
import pytesseract

ROOT=Path(__file__).resolve().parent
if os.name=='nt':
    _tess=Path(r'C:\Program Files\Tesseract-OCR\tesseract.exe')
    if _tess.is_file():pytesseract.pytesseract.tesseract_cmd=str(_tess)

@dataclass
class Candidate:
    name: str
    click_x: int
    click_y: int
    confidence: float
    box: tuple

@dataclass
class Observation:
    candidate: Candidate | None
    target_name: str | None
    distance_m: float | None
    f_prompt: bool
    prompt_score: float
    gathering: bool
    flight_energy: float | None
    flight_state: str

DEFAULT_NAMES=('Эфир','Сапфир','Рубин','Алмаз')


def norm(text):
    return re.sub(r'[^а-яё]', '', text.lower().replace('e','е').replace('o','о'))


def clean_match(text, names):
    t=norm(text)
    for name in names:
        n=norm(name)
        if t==n or (len(n)>=5 and n in t and len(t)<=len(n)+3):
            return name
    return None


def color_mask(bgr):
    hsv=cv2.cvtColor(bgr,cv2.COLOR_BGR2HSV)
    # Cyan-to-green text from Russian Global UI; restrict saturation and brightness.
    lower=np.array([32,43,65],np.uint8)
    upper=np.array([100,255,255],np.uint8)
    return cv2.inRange(hsv,lower,upper)


def _text_words(mask, psm=11):
    # 255 background, dark glyphs. Upscale for Cyrillic Tesseract.
    bw=cv2.resize(255-mask,None,fx=1.55,fy=1.55,interpolation=cv2.INTER_NEAREST)
    data=pytesseract.image_to_data(bw,lang='rus',config=f'--oem 3 --psm {psm}',output_type=pytesseract.Output.DICT)
    for i,s in enumerate(data['text']):
        s=s.strip()
        if not s: continue
        try: conf=float(data['conf'][i])
        except (TypeError, ValueError): conf=-1
        if conf<35: continue
        yield (s,conf,float(data['left'][i])/1.55,float(data['top'][i])/1.55,
               float(data['width'][i])/1.55,float(data['height'][i])/1.55)


def find_world_resource(frame,names=DEFAULT_NAMES):
    """Detect cyan world name in a large scene ROI. Strict allowlist.

    MVP restriction: expects OCR to read a resource name as one contiguous token;
    the name is not itself proof of a clickable object in an obstructed scene.
    """
    h,w=frame.shape[:2]
    x0,y0,x1,y1=int(w*.12),int(h*.10),int(w*.85),int(h*.70)
    roi=frame[y0:y1,x0:x1]
    mask=color_mask(roi)
    results=[]
    for txt,conf,x,y,tw,th in _text_words(mask):
        name=clean_match(txt,names)
        if not name: continue
        cx=int(x0+x+tw*.5); cy=int(y0+y+th+max(18,h*.010))
        # Avoid target panel region and character names when a target is highlighted.
        if cy<int(h*.12): continue
        results.append(Candidate(name,cx,cy,conf,(int(x0+x),int(y0+y),int(tw),int(th))))
    results.sort(key=lambda c:(c.name=='Эфир',c.confidence),reverse=True)
    return results[0] if results else None


def selected_target(frame,names=DEFAULT_NAMES):
    """Read selected resource title in the fixed TOP CENTRE overlay.
    Text-only colour segmentation fails against the teal HP bar, so use
    a narrowly cropped RGB title row + single-line Cyrillic OCR instead.
    """
    h,w=frame.shape[:2]
    a=frame[int(.034*h):int(.055*h),int(.45*w):int(.54*w)]
    if a.size==0:return None,None
    a=cv2.resize(a,None,fx=3,fy=3,interpolation=cv2.INTER_CUBIC)
    text=pytesseract.image_to_string(a,lang='rus',config='--oem 3 --psm 7')
    selected=None
    clean=norm(text)
    for name in names:
        if norm(name) in clean:
            selected=name
            break
    if selected is None:return None,None
    try:
        sub=frame[int(.027*h):int(.066*h),int(.55*w):int(.64*w)]
        gray=cv2.cvtColor(sub,cv2.COLOR_BGR2GRAY)
        gray=cv2.resize(gray,None,fx=2,fy=2)
        s=pytesseract.image_to_string(gray,config='--psm 11 -c tessedit_char_whitelist=0123456789.,mMмМ')
        m=re.search(r'(\d{1,3})(?:[.,](\d))?\s*[мmMМ]',s)
        dist=(float(m.group(1))+float('0.'+m.group(2)) if m and m.group(2) else float(m.group(1))) if m else None
        return selected,dist
    except Exception:return selected,None


def gathering_panel(frame):
    """Two parallel coloured horizontal bars in lower-center gather UI.
    Returns true only when both identifiable blue/cyan and orange stripes exist.
    """
    h,w=frame.shape[:2]
    region=frame[int(h*.690):int(h*.856),int(w*.345):int(w*.685)]
    if region.size==0:return False
    hsv=cv2.cvtColor(region,cv2.COLOR_BGR2HSV)
    cyan=cv2.inRange(hsv,np.array([80,45,90]),np.array([113,255,255]))
    orange=cv2.inRange(hsv,np.array([5,80,80]),np.array([29,255,255]))
    # Ignore nearby UI/buffs: require reasonably wide runs in DIFFERENT rows.
    def horizontal_rows(m):
        row=(m>0).sum(axis=1)
        return set(np.flatnonzero(row>max(55,region.shape[1]*.16)).tolist())
    cr,orr=horizontal_rows(cyan),horizontal_rows(orange)
    return bool(cr and orr and min(abs(a-b) for a in cr for b in orr)<100)


class PromptDetector:
    def __init__(self,reference=None):
        p=reference or ROOT/'assets/f_prompt_reference.png'
        self.template=cv2.imread(str(p),cv2.IMREAD_GRAYSCALE)
        if self.template is None:raise FileNotFoundError(p)
        # Cross-resolution template scale is relative to source 2558-wide video.
    def detect(self,frame):
        h,w=frame.shape[:2]
        # Searching center world instead of entire window reduces false matches.
        roi=frame[int(h*.27):int(h*.75),int(w*.33):int(w*.72)]
        gray=cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY)
        best=-1
        for f in (0.80,0.90,1.0,1.10,1.20):
            scale=f*w/2558
            if scale<.2:continue
            tpl=cv2.resize(self.template,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
            if tpl.shape[0]>=gray.shape[0] or tpl.shape[1]>=gray.shape[1]:continue
            # Edge maps reduce sensitivity to background under semi-transparent UI.
            a=cv2.Canny(gray,50,120);t=cv2.Canny(tpl,50,120)
            if np.std(t)<2:continue
            _,score,_,_=cv2.minMaxLoc(cv2.matchTemplate(a,t,cv2.TM_CCOEFF_NORMED))
            best=max(best,float(score))
        return best>=.57,round(max(0,best),3)


def flight_gauge(frame):
    """Measured energy arc at calibrated position (no invented values on shift)."""
    h,w=frame.shape[:2]
    if w<1000 or h<650:return None,'UNKNOWN'
    yy=np.arange(476,727,dtype=float)
    xx=797+46*((yy-597)/123)**2
    yy=np.rint((yy+180)*h/1440).astype(int)
    xx=np.rint((xx+250)*w/2560).astype(int)
    rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB).astype(np.int16)
    cyan=np.zeros(len(xx),np.int16);red=np.zeros(len(xx),np.int16)
    for i,(x,y) in enumerate(zip(xx,yy)):
        if x<6 or x>=w-7 or y<0 or y>=h:continue
        a=rgb[y,x-5:x+6];R,G,B=a[:,0],a[:,1],a[:,2]
        cyan[i]=((G-R>16)&(B-R>10)&(G>126)).sum()
        red[i]=((R-G>55)&(R-B>55)&(R>128)).sum()
    mask=(cyan>=2)|(red>=2)
    if mask.sum()<35:return None,'HIDDEN'
    smooth=np.convolve(mask.astype(int),np.ones(9,dtype=int),mode='same')>=3
    if smooth[-22:].sum()<8:return None,'UNKNOWN'
    a=np.flatnonzero(smooth)
    if not len(a):return None,'UNKNOWN'
    pct=float(np.clip((len(xx)-a[0])/len(xx)*100,0,100))
    return round(pct,1),('RED' if red.sum()>cyan.sum() else 'CYAN')


def flight_mode_hint(frame):
    """Fallback state only (not energy measurement): contextual fly controls."""
    h,w=frame.shape[:2]
    roi=frame[int(.76*h):int(.95*h),int(.79*w):int(.99*w)]
    if roi.size==0:return False
    txt=pytesseract.image_to_string(roi,lang='rus',config='--psm 11').lower()
    return 'парение' in txt and ('режим' in txt or 'пол' in txt)


class WorldVision:
    def __init__(self,names=DEFAULT_NAMES):
        self.names=names
        self.prompt=PromptDetector()
    def scan(self,frame,world=True,candidates=True):
        name,dist=selected_target(frame,self.names) if world else (None,None)
        candidate=find_world_resource(frame,self.names) if world and candidates else None
        f,score=self.prompt.detect(frame) if world and (name or candidate) else (False,0.0)
        g=gathering_panel(frame) if world else False
        e,st=flight_gauge(frame) if world else (None,'UNKNOWN')
        if world and e is None and (name=='Эфир' or g) and flight_mode_hint(frame):
            st='AIR_HINT'
        return Observation(candidate,name,dist,bool(f),score,g,e,st)


def segment_count(frame):
    """Initial THREE-slot resource gauge model calibrated from t63/t276.
    Returns 1/2/3 or None. Doesn't invent count if upper panel is hidden.
    """
    h,w=frame.shape[:2]
    # Sample inside the three equal-sized coloured portions of upper HP/resource bar.
    rect=frame[int(h*84/1438):int(h*112/1438),int(w*1040/2558):int(w*1505/2558)]
    if rect.size==0:return None
    hsv=cv2.cvtColor(rect,cv2.COLOR_BGR2HSV)
    mask=cv2.inRange(hsv,np.array([32,45,55]),np.array([95,255,255]))
    scores=[]
    for i in range(3):
        tile=mask[:,round(mask.shape[1]*i/3):round(mask.shape[1]*(i+1)/3)]
        scores.append(float((tile>0).mean()))
    # Distinguish a valid 1/2/3-fill from random target bars / backgrounds.
    slots=[v>.31 for v in scores]
    if not slots[0]:return None
    if slots==[True,False,False]:return 1
    if slots==[True,True,False]:return 2
    if slots==[True,True,True]:return 3
    return None


def gather_result_full(frame):
    """For the LAST remaining segment only: cyan/orange bar reached far right.
    One matching frame is a visual clue, not an infallible game event.
    """
    h,w=frame.shape[:2]
    # Learned from original 2560x1440 footage, bars at x~1034..1605 y~1086/1129.
    x1,x2=round(w*1540/2558),round(w*1602/2558)
    y1,y2=round(h*1080/1438),round(h*1154/1438)
    a=frame[y1:y2,x1:x2]
    if a.size==0:return False
    hsv=cv2.cvtColor(a,cv2.COLOR_BGR2HSV)
    cy=cv2.inRange(hsv,np.array([80,45,90]),np.array([113,255,255]))
    orange=cv2.inRange(hsv,np.array([5,80,80]),np.array([29,255,255]))
    for mask in (cy,orange):
        if ((mask>0).sum(axis=1)>a.shape[1]*.7).sum()>=6:return True
    return False
