# -*- coding: utf-8 -*-
"""ACore2 Gather Scanner v0.1: standalone visual gather prototype.

First phase only: nearby resources already VISIBLE in the world screen, not
complete map navigation. No reading game memory, no CAPTCHA solving.
"""
from __future__ import annotations
import collections,json,logging,os,queue,threading,time,traceback
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
import cv2
import numpy as np
from bridge import GHubBridge
from vision import WorldVision,DEFAULT_NAMES,segment_count,gather_result_full
from captcha_watchdog import CenterDialogDetector,AudioAlarm
from death_watchdog import DeathDialogDetector,DeathAudioAlarm
from win_hotkeys import SystemHotkeys
from usb_hid_clicker import USBHIDClicker
from gamepad_input import GamepadInput
from minimap import MinimapVision
from minimap_setup import MinimapSetup

ROOT=Path(__file__).resolve().parent
CONF=ROOT/'settings_gather.json'
DEFAULT={"only_aether":False,"allow_click":True,"camera_scan":True,"dry_run":False,"assist_manual_target":True,
         "scan_seconds":3.5,"approach_timeout":22,
         "gather_timeout":55,"audio_device":"AG271QG4",
         "target_names":list(DEFAULT_NAMES),"debug_screenshots":True, "click_backend":"gamepad",
         "usb_hid_port":"COM5", "ground_walk":True,"patrol_steps_max":16,
         "minimap_search":True,"minimap_roi":[],"minimap_templates":[],
         "minimap_threshold":.80,"minimap_timeout":22,"minimap_stall_seconds":9,
         "target_missing_seconds":1.8,"cursor_alt":True,"a_gap_seconds":.32}


def read_config():
    try:r=json.loads(CONF.read_text(encoding='utf-8'))
    except Exception:r={}
    return {**DEFAULT,**r}

class ScreenCapture:
    def __init__(self):
        self.hwnd=None
        self.title=''
        if os.name=='nt':
            import win32gui
            self.win32gui=win32gui
        # Each capture uses its own MSS instance; mss is thread-local on Windows.
        self.mss=None
    def pick(self):
        if os.name!='nt':return 'OFFLINE'
        options=[]
        def cb(h,_):
            if self.win32gui.IsWindowVisible(h):
                name=self.win32gui.GetWindowText(h)
                if 'aion2' in name.lower() or 'aion 2' in name.lower():options.append((h,name))
        self.win32gui.EnumWindows(cb,None)
        if not options:return None
        self.hwnd,self.title=options[0];return self.title
    def focused(self):
        return os.name!='nt' or self.hwnd is not None and self.win32gui.GetForegroundWindow()==self.hwnd
    def frame(self):
        if os.name!='nt':raise RuntimeError('Захват игры доступен только на Windows')
        if not self.hwnd or not self.win32gui.IsWindow(self.hwnd):raise RuntimeError('Окно AION2 не найдено')
        left,top=self.win32gui.ClientToScreen(self.hwnd,(0,0))
        _,_,w,h=self.win32gui.GetClientRect(self.hwnd)
        import mss
        with mss.mss() as capture:
            frame=np.array(capture.grab({'left':left,'top':top,'width':w,'height':h}))[:,:,:3].copy()
        return frame,(left,top)

class GatherEngine:
    def __init__(self,cfg,emit,gamepad=None):
        self.cfg=cfg;self.emit=emit;self.stop_event=threading.Event()
        self.vision=WorldVision(tuple(cfg['target_names']))
        self.screen=ScreenCapture()
        self.bridge=GHubBridge(dry_run=cfg.get('dry_run',True),logger=self.emit)
        self.usb_clicker=None
        self.gamepad=gamepad
        self.minimap=MinimapVision(cfg)
        self.map_goal=None;self.map_cooldowns=[];self.map_last_click=0
        self.map_best_distance=None;self.patrol_pause_until=0
        self.target_missing_since=None;self.target_misses=0;self.last_segments=None
        self.cap=CenterDialogDetector(template_dir=ROOT)
        self.death=DeathDialogDetector(template_dir=ROOT)
        self.cap_alarm=AudioAlarm(logger=self.emit)
        self.death_alarm=DeathAudioAlarm(logger=self.emit)
        self.cap_alarm.device_match=cfg.get('audio_device','AG271QG4')
        self.death_alarm.device_match=cfg.get('audio_device','AG271QG4')
        self.mode='SEARCH';self.target=None;self.f_on=False;self.started=time.monotonic()
        self.last_seen=time.monotonic();self.last_ping=0;self.last_camera=0
        self.last_safety=0;self.last_death=0;self.cap_hits=0;self.death_hits=0
        self.stable_candidate=None;self.stable_count=0
        self.last_distance=None;self.last_progress=time.monotonic()
        self.in_flight=False;self.last_energy=None;self.node_count=0
        self.flight_misses=0
        self.last_walking=0;self.walk_steps=0;self.scan_turns=0;self.search_note=0
        self.one_segment_armed=False;self.folded_for_target=False
        self.target_confirmed=False
        self.bad_until={};self.screenshot_path=ROOT/'debug_gather'
        self.alert=None
        self.alert_lock=threading.Lock()
        self.safety_threads=[]
        if cfg.get('debug_screenshots'):self.screenshot_path.mkdir(exist_ok=True)

    def say(self,msg):self.emit(f'[{self.mode}] {msg}')
    def bridge_cmd(self,command):
        if self.stop_event.is_set() and command not in ('STOP','F_OFF','ALT_UP'):return
        self.bridge.send(command)
    def f_enable(self):
        if not self.f_on:
            self.bridge_cmd('F_ON');self.f_on=True;self.say('F включено, период 1000 мс (Lua)')
    def f_disable(self):
        if self.f_on:
            self.bridge_cmd('F_OFF');self.f_on=False
    def change_mode(self,new_mode):self.mode=new_mode;self.started=time.monotonic()
    def save_debug(self,frame,label):
        if self.cfg.get('debug_screenshots'):
            path=self.screenshot_path/(time.strftime('%H%M%S')+'_'+label+'.jpg')
            cv2.imwrite(str(path),cv2.resize(frame,(1280,720)))
    def safety(self,frame,now):
        if now-self.last_safety>=.8:
            self.last_safety=now
            ok,sc=self.cap.check(frame)
            self.cap_hits=self.cap_hits+1 if ok else 0
            if self.cap_hits>=2:
                self.trigger_alarm('CAPTCHA',frame);return True
        if now-self.last_death>=3:
            self.last_death=now
            ok,sc=self.death.check(frame)
            self.death_hits=self.death_hits+1 if ok else 0
            if self.death_hits>=2:
                self.trigger_alarm('DEATH',frame);return True
        return False
    def trigger_alarm(self,kind,frame):
        with self.alert_lock:
            if self.stop_event.is_set() or self.alert is not None:return
            self.alert=kind
            self.stop_event.set()
        if self.gamepad:self.gamepad.reset()
        self.save_debug(frame,kind.lower())
        self.say('ТРЕВОГА '+kind+' — ввод остановлен, только ручное продолжение')
        self.bridge_cmd('STOP')
        try:
            al=self.cap_alarm if kind=='CAPTCHA' else self.death_alarm
            al.start(self.cfg.get('audio_device','AG271QG4'),error_cb=self.emit)
        except Exception as ex:self.emit('Не удалось запустить звук: '+str(ex))
    def captcha_watch_loop(self):
        """Same active-only independent watchdog design as TargetScanner v26."""
        hits=0
        while not self.stop_event.is_set():
            if not self.screen.focused():
                hits=0
                self.stop_event.wait(.15)
                continue
            try:
                frame,_=self.screen.frame()
                present,score=self.cap.check(frame)
                hits=hits+1 if present else 0
                if hits>=2:
                    self.trigger_alarm('CAPTCHA',frame)
                    break
            except Exception as exc:
                hits=0
                self.emit('CAPTCHA / ошибка проверки: '+str(exc))
                if self.stop_event.wait(1.2):break
            if self.stop_event.wait(1.0):break

    def death_watch_loop(self):
        """Check every ~5 s, second confirm after 0.35 s, while running only."""
        while not self.stop_event.is_set():
            if not self.screen.focused():
                if self.stop_event.wait(.20):break
                continue
            try:
                frame,_=self.screen.frame()
                present,score=self.death.check(frame)
                if present and not self.stop_event.wait(.35):
                    check_frame,_=self.screen.frame()
                    confirmed,score2=self.death.check(check_frame)
                    if confirmed:
                        self.trigger_alarm('DEATH',check_frame)
                        break
            except Exception as exc:
                self.emit('DEATH / ошибка проверки: '+str(exc))
            if self.stop_event.wait(5.0):break

    def click_candidate(self,candidate,origin):
        if self.cfg.get('dry_run',True):
            self.say('НАБЛЮДЕНИЕ: клик подавлен, включая внешний USB HID')
            return
        # The G HUB Lua mouse-click path is known NOT to work for this user's
        # AION 2 client. USB HID is an optional, separately connected device.
        backend=self.cfg.get('click_backend','ghub')
        if backend=='usb_hid' and self.usb_clicker is None:
            self.usb_clicker=USBHIDClicker(self.cfg.get('usb_hid_port','COM5'),logger=self.emit)
        self.f_disable()
        if self.stop_event.is_set() or not self.screen.focused():return
        if self.cfg.get('cursor_alt',True):self.bridge_cmd('ALT_DOWN')
        try:
            if self.stop_event.wait(.16):return
            self.bridge.cursor(origin[0]+candidate.click_x,origin[1]+candidate.click_y)
            if self.stop_event.wait(.15):return
            if self.stop_event.is_set():return
            if not self.screen.focused():return
            if backend=='gamepad':
                if self.gamepad is None:raise RuntimeError('Сначала подключите виртуальный Xbox кнопкой в окне программы')
                aim=lambda:self.bridge.cursor(origin[0]+candidate.click_x,origin[1]+candidate.click_y)
                if not self.gamepad.double_a(self.stop_event,self.screen.focused,
                                             gap=self.cfg.get('a_gap_seconds',.32),before_second=aim):return
            elif backend=='usb_hid':
                self.usb_clicker.double_click()
            elif backend=='ghub':
                self.bridge_cmd('DOUBLE_CLICK')
            else:
                raise ValueError('Неизвестный click_backend: '+repr(backend))
        finally:
            # Also release Alt if HID port opening, clicking or stopping fails.
            if self.cfg.get('cursor_alt',True):self.bridge_cmd('ALT_UP')
        if self.stop_event.is_set():return
        self.target=candidate.name
        self.one_segment_armed=False;self.folded_for_target=False;self.target_confirmed=False
        self.last_distance=None
        self.target_missing_since=None;self.target_misses=0;self.last_segments=None
        self.last_progress=time.monotonic()
        self.say(f'Отправлено 2 A ({backend}): {candidate.name}, x={candidate.click_x}, y={candidate.click_y}; жду подтверждение таргета')
        self.change_mode('APPROACH')

    def map_excluded(self,marker,now):
        self.map_cooldowns=[c for c in self.map_cooldowns if c[3]>now]
        return any(c[0]==marker.name and abs(c[1]-marker.x)<24 and abs(c[2]-marker.y)<24 for c in self.map_cooldowns)

    def map_navigate(self,marker,origin,now):
        if self.cfg.get('dry_run'):
            self.say(f'МИНИКАРТА: {marker.name} ({marker.x},{marker.y}), score={marker.score:.2f}; наблюдение')
            return
        if not self.gamepad:raise RuntimeError('Для миникарты подключите виртуальный Xbox')
        if self.cfg.get('cursor_alt',True):self.bridge_cmd('ALT_DOWN')
        try:
            if not GamepadInput.wait(.18,self.stop_event,self.screen.focused):return
            aim=lambda:self.bridge.cursor(origin[0]+marker.x,origin[1]+marker.y)
            aim()
            if not GamepadInput.wait(.15,self.stop_event,self.screen.focused):return
            if not self.gamepad.double_a(self.stop_event,self.screen.focused,before_second=aim):return
        finally:
            if self.cfg.get('cursor_alt',True):self.bridge_cmd('ALT_UP')
        if self.stop_event.is_set():return
        self.map_goal=marker;self.map_best_distance=marker.distance
        self.last_progress=time.monotonic();self.map_last_click=now
        self.change_mode('MAP_TRAVEL')
        self.say(f'Миникарта: 2 A на {marker.name} ({marker.x},{marker.y}); ищу название в мире')

    def map_travel(self,frame,origin,obs,now):
        # A world resource always takes priority over further map travel.
        if obs.candidate and (not self.cfg['only_aether'] or obs.candidate.name=='Эфир'):
            self.change_mode('SEARCH');self.stable_candidate=None;self.stable_count=0
            return
        markers=self.minimap.scan(frame)
        goal=self.map_goal
        matches=[m for m in markers if goal and m.name==goal.name and abs(m.x-goal.x)<70 and abs(m.y-goal.y)<70]
        if matches:
            marker=min(matches,key=lambda m:(m.x-goal.x)**2+(m.y-goal.y)**2)
            if self.map_best_distance is None or marker.distance<self.map_best_distance-2:
                self.last_progress=now
                self.map_best_distance=marker.distance
            self.map_goal=marker
        if now-self.last_camera>=self.cfg['scan_seconds'] and self.cfg.get('camera_scan'):
            self.bridge_cmd('TURN_RIGHT');self.last_camera=now
        if now-self.started>self.cfg['minimap_timeout'] or now-self.last_progress>self.cfg['minimap_stall_seconds']:
            if self.map_goal:
                g=self.map_goal;self.map_cooldowns.append((g.name,g.x,g.y,now+30))
            self.say('Переход по миникарте без видимого прогресса: ищу другую иконку/название')
            self.map_goal=None;self.change_mode('SEARCH')
    def return_to_search(self,reason,frame=None,exhausted=False):
        # Time-critical: release the wings BEFORE queued F_OFF transport.
        # F and V are independent, as verified by the player.
        if self.in_flight and self.target=='Эфир' and not self.folded_for_target:
            self.bridge_cmd('V')
            self.say('V: сложить крылья (одна команда; проверить результат в игре)')
            self.in_flight=False
        self.f_disable()
        self.say(reason)
        if exhausted:self.node_count+=1
        if self.target and not exhausted:
            self.bad_until[self.target]=time.monotonic()+8
        if frame is not None and not exhausted:self.save_debug(frame,'failed')
        self.target=None;self.change_mode('SEARCH')
        if self.map_goal:
            g=self.map_goal;self.map_cooldowns.append((g.name,g.x,g.y,time.monotonic()+30))
        self.map_goal=None;self.target_missing_since=None;self.target_misses=0
        self.walk_steps=0;self.scan_turns=0;self.last_walking=time.monotonic()
        self.one_segment_armed=False;self.folded_for_target=False;self.target_confirmed=False
        self.stable_candidate=None;self.stable_count=0
    def process(self,frame,origin,now):
        if self.stop_event.is_set():return
        if not self.safety_threads and self.safety(frame,now):return
        if now-self.last_ping>2.4 and self.mode not in ('STOP','ALERT'):
            self.bridge_cmd('PING');self.last_ping=now
        # Only observe when game is active. When focus is lost: F OFF immediately.
        if not self.screen.focused():
            if self.f_on:self.f_disable()
            if self.gamepad:self.gamepad.reset()
            return
        obs=self.vision.scan(frame,candidates=self.mode in ('SEARCH','MAP_TRAVEL','WALK_TO_RESOURCE'))
        if obs.flight_energy is not None:
            self.in_flight=True;self.last_energy=obs.flight_energy;self.flight_misses=0
        elif obs.flight_state=='AIR_HINT':
            self.in_flight=True;self.flight_misses=0
        elif self.in_flight and obs.flight_state=='HIDDEN':
            self.flight_misses+=1
            if self.flight_misses>=3:self.in_flight=False
        if self.mode=='SEARCH':
            # Useful first-stage functionality: manual click/navigation but
            # automatic repeat-F and V while resource is already selected.
            if (self.cfg.get('assist_manual_target') and obs.target_name
                and (obs.f_prompt or obs.gathering)
                and (not self.cfg['only_aether'] or obs.target_name=='Эфир')):
                self.target=obs.target_name;self.target_confirmed=True
                self.last_seen=now;self.one_segment_armed=False;self.folded_for_target=False
                self.f_enable();self.change_mode('GATHER')
                self.say('Ручная цель подтверждена, авто-F включено: '+self.target)
                return
            if obs.candidate and (not self.cfg['only_aether'] or obs.candidate.name=='Эфир'):
                c=obs.candidate
                if now<self.bad_until.get(c.name,0):return
                # Same name, nearly same location in two consecutive captures.
                stable=self.stable_candidate
                if stable and stable.name==c.name and abs(stable.click_x-c.click_x)<65 and abs(stable.click_y-c.click_y)<55:
                    self.stable_count+=1
                else:self.stable_count=1
                self.stable_candidate=c
                if self.stable_count>=2:
                    if self.cfg['allow_click']:
                        self.click_candidate(c,origin)
                    elif self.cfg.get('ground_walk') and c.name!='Эфир' and not self.cfg.get('dry_run'):
                        self.target=c.name
                        self.walk_steps=0
                        self.last_walking=0
                        self.last_progress=now
                        self.change_mode('WALK_TO_RESOURCE')
                        self.say('Наземное визуальное сближение через W/камеру: '+c.name)
                    else:
                        self.say('Наведение отключено: режим наблюдения')
                        self.stable_count=0
            else:
                self.stable_candidate=None;self.stable_count=0
                if self.cfg.get('minimap_search') and self.minimap.ready:
                    markers=[m for m in self.minimap.scan(frame) if not self.map_excluded(m,now)]
                    if markers and now-self.map_last_click>3:
                        self.map_navigate(markers[0],origin,now)
                        return
                if self.cfg.get('camera_scan') and now-self.last_camera>=self.cfg['scan_seconds']:
                    self.bridge_cmd('TURN_RIGHT');self.last_camera=now
                    self.scan_turns+=1
                if (self.cfg.get('ground_walk') and not self.cfg.get('dry_run')
                    and not self.cfg.get('only_aether') and not self.in_flight and self.scan_turns>=4
                    and now>=self.patrol_pause_until
                    and self.walk_steps<self.cfg.get('patrol_steps_max',16)
                    and now-self.last_walking>=self.cfg['scan_seconds']*2.5):
                    # Bounded patrol step; cannot claim terrain awareness.
                    self.bridge_cmd('W_STEP');self.walk_steps+=1
                    self.last_walking=now;self.scan_turns=0
                    self.say('Патруль: короткий шаг вперёд '+str(self.walk_steps))
                elif (self.cfg.get('ground_walk') and self.walk_steps>=self.cfg.get('patrol_steps_max',16)
                    and now-self.search_note>=15):
                    self.say('Цикл поиска завершён: 12 секунд обзора, затем новый цикл шагов')
                    self.walk_steps=0;self.scan_turns=0;self.patrol_pause_until=now+12
                    self.search_note=now
        elif self.mode=='MAP_TRAVEL':
            self.map_travel(frame,origin,obs,now)
        elif self.mode=='WALK_TO_RESOURCE':
            # Experimental ground-only visual steering: no mouse click needed.
            # Progress is limited by short steps and OCR; no claim of fully
            # reliable obstacle avoidance or safe cliff traversal.
            c=obs.candidate
            if obs.target_name==self.target and (obs.f_prompt or obs.gathering):
                self.f_enable();self.change_mode('GATHER');self.target_confirmed=True
                self.say('Наземная цель в радиусе F')
                return
            if c and c.name==self.target:
                # WorldVision will search the F prompt even without selected
                # top-center target on this branch (see vision.py patch).
                if obs.f_prompt or obs.gathering:
                    self.f_enable();self.change_mode('GATHER');self.target_confirmed=True
                    self.say('F найден возле наземного ресурса')
                    return
                if now-self.last_walking>=1.35:
                    xoff=(c.click_x/frame.shape[1])-.5
                    if xoff>.080:self.bridge_cmd('TURN_RIGHT')
                    elif xoff<-.080:self.bridge_cmd('TURN_LEFT')
                    elif self.walk_steps<18:
                        self.bridge_cmd('W_STEP');self.walk_steps+=1
                    else:
                        self.return_to_search('Наземный подход: исчерпано 18 шагов',frame)
                        return
                    self.last_walking=now
                    self.last_progress=now
            elif now-self.last_progress>4.5:
                self.return_to_search('Наземная цель потеряна из поля зрения',frame)
                return
            if now-self.started>self.cfg['approach_timeout']:
                self.return_to_search('Наземный визуальный подход: таймаут',frame)
                return
        elif self.mode=='APPROACH':
            # F trigger: visible contextual prompt OR already-started gathering UI.
            # Distance alone is NOT sufficient, especially on cliffs.
            if obs.target_name and obs.target_name!=self.target:
                self.return_to_search('После клика выбрана не та цель',frame);return
            if obs.target_name==self.target:
                if not self.target_confirmed:self.say('Таргет подтверждён изображением: '+self.target)
                self.target_confirmed=True;self.last_seen=now
            elif not self.target_confirmed and now-self.started>5:
                self.return_to_search('После 2 A таргет не подтверждён; повторный поиск',frame);return
            if obs.target_name==self.target and obs.distance_m is not None:
                if self.last_distance is None or obs.distance_m<self.last_distance-.3:
                    self.last_progress=now
                self.last_distance=obs.distance_m
            if (obs.f_prompt and self.target_confirmed) or (obs.gathering and obs.target_name in (None,self.target)):
                self.f_enable()
                self.last_seen=now
                self.change_mode('GATHER')
                self.say('Первый сбор доступен: '+('панель добычи' if obs.gathering else 'подсказка F'))
            elif now-self.started>self.cfg['approach_timeout'] or (self.last_distance is not None and now-self.last_progress>8):
                self.return_to_search('Автоподход не удался / застревание',frame)
        elif self.mode=='GATHER':
            if obs.target_name is not None and obs.target_name!=self.target:
                self.return_to_search('Таргет сменился: останавливаю F',frame);return
            if not self.f_on and (obs.gathering or obs.f_prompt):self.f_enable()
            # If ONE upper segment is left and final attempt has visibly filled
            # its success OR failure bar, V may fold immediately, without
            # waiting for the world node to disappear. F continues independently.
            cnt=segment_count(frame) if obs.target_name==self.target else None
            if cnt is not None and cnt!=self.last_segments:
                self.say(f'Попыток ресурса осталось: {cnt}/3');self.last_segments=cnt
            if cnt==1 and obs.gathering:self.one_segment_armed=True
            if (self.target=='Эфир' and self.in_flight and not self.folded_for_target
                and self.one_segment_armed and obs.gathering and gather_result_full(frame)):
                self.bridge_cmd('V');self.folded_for_target=True;self.in_flight=False
                self.say('Последняя попытка завершилась: V сразу, F остаётся активным')
            if obs.target_name==self.target:
                self.last_seen=now
                self.target_missing_since=None;self.target_misses=0
            else:
                self.target_misses+=1
                if self.target_missing_since is None:self.target_missing_since=now
            # Don't stop F between attempts due to brief panel transition.
            if (self.target_missing_since is not None and self.target_misses>=3
                and now-self.target_missing_since>=self.cfg.get('target_missing_seconds',1.8)
                and not obs.gathering):
                self.return_to_search('Ресурс больше не виден / вероятно истощён',frame,True)
            elif now-self.started>self.cfg['gather_timeout']:
                self.return_to_search('Сбор слишком долгий, прекращаем',frame)
    def run(self,offline=None):
        self.say('Запуск '+('OFFLINE' if offline else 'LIVE'))
        try:
            if offline:
                for f in offline:
                    if self.stop_event.is_set():break
                    frame=cv2.imread(str(f))
                    if frame is None:continue
                    self.process(frame,(0,0),time.monotonic())
                    self.emit(repr(self.vision.scan(frame)))
                    time.sleep(.2)
            else:
                if self.screen.pick() is None:raise RuntimeError('Окно AION2 не найдено')
                self.say('Окно: '+self.screen.title+'. Lua запускается физической G9 в G HUB.')
                if self.cfg.get('click_backend')=='gamepad' and not self.cfg.get('dry_run') and self.gamepad is None:
                    raise RuntimeError('Виртуальный Xbox не подключён. Нажмите «Подключить Xbox» перед стартом.')
                self.say('Миникарта: '+('эталоны загружены' if self.minimap.ready else 'нужна однократная настройка; поиск названий уже доступен'))
                self.safety_threads=[
                    threading.Thread(target=self.captcha_watch_loop,daemon=True,name='CaptchaWatch'),
                    threading.Thread(target=self.death_watch_loop,daemon=True,name='DeathWatch'),
                ]
                for thread in self.safety_threads:thread.start()
                self.say('CAPTCHA/DEATH: активны вместе со сканом, остановятся при паузе/стопе')
                while not self.stop_event.is_set():
                    frame,origin=self.screen.frame()
                    self.process(frame,origin,time.monotonic())
                    time.sleep(.18)
        except Exception as exc:
            self.emit('ОШИБКА: '+repr(exc)+'\n'+traceback.format_exc())
        finally:
            if self.gamepad:self.gamepad.reset()
            try:self.stop_event.set();self.bridge.send('STOP');self.bridge.restore_locks()
            except Exception as ex:self.emit('Ошибка STOP: '+str(ex))
            if self.usb_clicker:self.usb_clicker.close()
            self.emit('Сканер остановлен')
    def stop(self):
        self.stop_event.set()
        if self.gamepad:self.gamepad.reset()
    def silence(self):self.cap_alarm.stop();self.death_alarm.stop()

class UI:
    def __init__(self):
        self.root=tk.Tk();self.root.title('ACore2 Gather Scanner v0.3 — автосбор через Xbox A')
        self.root.geometry('1050x760')
        self.cfg=read_config();self.q=queue.Queue();self.worker=None;self.engine=None
        self.file_log=logging.getLogger('gather_scanner')
        self.file_log.setLevel(logging.INFO)
        try:
            handler=logging.FileHandler(ROOT/'gather.log',encoding='utf-8')
            handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
            self.file_log.addHandler(handler)
        except OSError:pass
        self.gamepad=None
        self.vars={}
        self._start_token=0
        self._start_pending=False
        self._closing=False
        row=ttk.Frame(self.root,padding=10);row.pack(fill='x')
        for key,label in [('dry_run','Только наблюдение (НЕ нажимать)'),('allow_click','Выбирать ресурс двумя A и запускать автоподход'),('minimap_search','Искать иконки ресурсов на миникарте и включать автопереход'),('assist_manual_target','Продолжать сбор уже выбранного ресурса'),('only_aether','Только эфир'),('camera_scan','Поворачивать камеру при поиске'),('ground_walk','Если иконок/названий нет: ограниченные шаги W при поиске')]:
            v=tk.BooleanVar(value=bool(self.cfg.get(key)))
            self.vars[key]=v
            ttk.Checkbutton(row,text=label,variable=v).pack(anchor='w')
        connection=ttk.Frame(self.root,padding=5);connection.pack(fill='x')
        ttk.Label(connection,text='Выбор ресурса:').pack(side='left')
        self.backend=tk.StringVar(value=self.cfg.get('click_backend','gamepad'))
        ttk.Combobox(connection,textvariable=self.backend,values=['gamepad','ghub','usb_hid'],width=12,state='readonly').pack(side='left',padx=5)
        ttk.Button(connection,text='Подключить Xbox',command=self.connect_gamepad).pack(side='left',padx=5)
        ttk.Button(connection,text='Настроить миникарту / добавить иконку',command=self.setup_minimap).pack(side='left',padx=5)
        ttk.Label(connection,text='USB COM:').pack(side='left')
        self.hid_port=tk.StringVar(value=self.cfg.get('usb_hid_port','COM5'))
        ttk.Entry(connection,textvariable=self.hid_port,width=9).pack(side='left',padx=5)
        ttk.Label(self.root,text='Основной режим: gamepad. Xbox отправляет A; G HUB Lua — Alt, F раз в секунду, V и поворот камеры. G9 запускает Lua.',foreground='#245').pack(anchor='w',padx=10)
        buttons=ttk.Frame(self.root,padding=10);buttons.pack(fill='x')
        ttk.Button(buttons,text='Сохранить настройки',command=self.save).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F8 Старт/пауза',command=self.toggle).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F9 СТОП',command=self.stop).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F10 Заглушить сигнал',command=self.silence).pack(side='left',padx=3)
        ttk.Button(buttons,text='ТЕСТ по двум кадрам',command=self.offline).pack(side='left',padx=3)
        journal=ttk.Frame(self.root,padding=5);journal.pack(fill='x')
        ttk.Button(journal,text='Скопировать журнал',command=self.copy_log).pack(side='left',padx=4)
        ttk.Button(journal,text='Сохранить журнал...',command=self.save_log).pack(side='left',padx=4)
        self.status=ttk.Label(self.root,text='Не запущено');self.status.pack(anchor='w',padx=10)
        self.box=tk.Text(self.root,height=23,wrap='word');self.box.pack(fill='both',expand=True,padx=10,pady=10)
        self.root.after(180,self.pump)
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.hotkeys=SystemHotkeys(self.q)
        self.root.after(150,self.connect_gamepad)

    def connect_gamepad(self):
        if self.gamepad:return True
        try:
            self.gamepad=GamepadInput(logger=self.log)
            self.log('Xbox готов. Оставьте программу открытой; приёмник F710 можно отключить.')
            return True
        except Exception as exc:
            self.log('Xbox не подключён: '+str(exc))
            return False

    def setup_minimap(self):
        self.stop('НАСТРОЙКА МИНИКАРТЫ')
        self.log('Снимок через 4 секунды: переключитесь в игру, откройте миникарту с видимой иконкой ресурса.')
        self.root.iconify()
        self.root.after(4000,self._capture_minimap)

    def _capture_minimap(self):
        if self._closing:return
        if self.worker and self.worker.is_alive():
            self.root.after(250,self._capture_minimap);return
        try:
            screen=ScreenCapture()
            if not screen.pick():raise RuntimeError('Окно AION2 не найдено')
            frame,_=screen.frame()
            self.root.deiconify()
            MinimapSetup(self.root,frame,self.cfg,self._minimap_saved)
        except Exception as exc:
            self.root.deiconify();self.log('Не удалось настроить миникарту: '+str(exc))

    def _minimap_saved(self):
        self.vars['minimap_search'].set(True)
        self.save()
        self.log('Миникарта сохранена. Иконок-эталонов: '+str(len(self.cfg['minimap_templates'])))
    def log(self,t):
        self.file_log.info(str(t));self.q.put(str(t))

    def copy_log(self):
        value=(ROOT/'gather.log').read_text(encoding='utf-8') if (ROOT/'gather.log').exists() else self.box.get('1.0','end')
        self.root.clipboard_clear();self.root.clipboard_append(value)
        self.log('Журнал скопирован в буфер обмена')

    def save_log(self):
        destination=filedialog.asksaveasfilename(parent=self.root,title='Сохранить журнал',
            defaultextension='.txt',initialfile='gather_log.txt',filetypes=[('Текст','*.txt'),('Все','*.*')])
        if destination:
            try:
                value=(ROOT/'gather.log').read_text(encoding='utf-8') if (ROOT/'gather.log').exists() else self.box.get('1.0','end')
                Path(destination).write_text(value,encoding='utf-8');self.log('Журнал сохранён: '+destination)
            except Exception as exc:messagebox.showerror('Журнал',str(exc),parent=self.root)
    def pump(self):
        for _ in range(40):
            try:s=self.q.get_nowait()
            except queue.Empty:break
            if isinstance(s,tuple) and s[0]=='hotkey':
                {'toggle':self.toggle,'stop':self.stop,'silence':self.silence}[s[1]]()
                continue
            s=str(s)
            self.box.insert('end',s+'\n');self.box.see('end')
            self.status.config(text=s[:110])
        self.root.after(180,self.pump)
    def save(self):
        for k,v in self.vars.items():self.cfg[k]=bool(v.get())
        self.cfg['click_backend']=self.backend.get()
        self.cfg['usb_hid_port']=self.hid_port.get().strip()
        CONF.write_text(json.dumps(self.cfg,ensure_ascii=False,indent=2),encoding='utf-8')
        self.log('Настройки сохранены')
    def toggle(self):
        active=(self._start_pending or
                (self.worker is not None and self.worker.is_alive() and
                 self.engine is not None and not self.engine.stop_event.is_set()))
        if active:
            self.stop('ПАУЗА Ctrl+F8')
        else:
            self.start()

    def start(self):
        if self._closing:return
        if self._start_pending:return
        if self.worker and self.worker.is_alive() and self.engine and not self.engine.stop_event.is_set():
            self.log('Скан уже запущен')
            return
        self._start_token+=1
        token=self._start_token
        self._start_pending=True
        self.log('Ctrl+F8: запрос запуска, после завершения прежнего цикла')
        self.root.after(10,lambda:self._launch_if_ready(token))

    def _launch_if_ready(self,token):
        if self._closing or not self._start_pending or token!=self._start_token:return
        if self.worker and self.worker.is_alive():
            self.root.after(150,lambda:self._launch_if_ready(token))
            return
        self.save()
        if not self.cfg['dry_run'] and not (self.cfg['allow_click'] or self.cfg.get('assist_manual_target') or self.cfg.get('ground_walk')):
            self._start_pending=False
            messagebox.showwarning('Режим','Для ввода включите «Автоподход» или используйте режим наблюдения.')
            return
        if self.engine:self.engine.silence() # stop prior alarm before explicit manual restart
        if not self.cfg['dry_run'] and self.cfg.get('click_backend')=='gamepad' and not self.connect_gamepad():
            self._start_pending=False;return
        self.engine=GatherEngine(dict(self.cfg),self.log,gamepad=None if self.cfg['dry_run'] else self.gamepad)
        self.log('Переключитесь в AION2. G9 включает приёмник Lua; через 3 с начнётся скан.')
        self.root.after(3000,lambda:self._go(token))

    def _go(self,token):
        if self._closing or not self._start_pending or token!=self._start_token:return
        self._start_pending=False
        if not self.engine or self.engine.stop_event.is_set():return
        self.worker=threading.Thread(target=self.engine.run,daemon=True)
        self.worker.start()

    def stop(self,reason='СТОП Ctrl+F9'):
        self._start_token+=1
        self._start_pending=False
        if self.engine:self.engine.stop()
        self.log(reason+': скан/CAPTCHA/смерть остановлены')

    def silence(self):
        if self.engine:self.engine.silence()
        self.log('Ctrl+F10: прекращён текущий звук CAPTCHA/смерти; состояние скана не изменено')

    def offline(self):
        if self._start_pending or (self.worker and self.worker.is_alive()):return
        cfg={**self.cfg,'dry_run':True,'allow_click':False,'camera_scan':False}
        self.engine=GatherEngine(cfg,self.log)
        samples=[ROOT/'testdata/orihalkon_example.jpg',ROOT/'testdata/air_gather_example.jpg']
        self.worker=threading.Thread(target=lambda:self.engine.run(offline=samples),daemon=True)
        self.worker.start()
    def close(self):
        self._closing=True
        self.stop('ЗАКРЫТИЕ')
        self.silence()
        self.hotkeys.stop()
        if self.gamepad:self.gamepad.reset()
        self.root.after(500,self.root.destroy)
    def run(self):self.root.mainloop()

if __name__=='__main__':UI().run()
