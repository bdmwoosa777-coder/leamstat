"""Virtual Xbox A transport. Keyboard actions stay on the existing G HUB bridge."""
import os
import threading
import time


class GamepadInput:
    def __init__(self, dry_run=False, logger=None, factory=None, a_button=None):
        self.dry_run = dry_run
        self.log = logger or (lambda _: None)
        self.lock = threading.RLock()
        self.pad = None
        self.button = a_button
        if dry_run:
            return
        if factory is None:
            if os.name != 'nt':
                raise RuntimeError('Виртуальный Xbox требует Windows и ViGEmBus')
            try:
                import vgamepad as vg
            except Exception as exc:
                raise RuntimeError('Не удалось подключить vgamepad/ViGEmBus: ' + str(exc)) from exc
            factory, self.button = vg.VX360Gamepad, vg.XUSB_BUTTON.XUSB_GAMEPAD_A
        self.pad = factory()
        self.reset()
        self.log('Виртуальный Xbox подключён; F710 и мышь с макросом не нужны')

    def reset(self):
        with self.lock:
            if self.pad is not None:
                self.pad.reset()
                self.pad.update()

    @staticmethod
    def wait(seconds, stop, focused):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if stop.is_set() or not focused():
                return False
            if stop.wait(min(.02, max(0, end-time.monotonic()))):
                return False
        return not stop.is_set() and focused()

    def tap_a(self, stop, focused, hold=.18):
        if stop.is_set() or not focused():
            return False
        if self.dry_run:
            self.log('СИМУЛЯЦИЯ Xbox A')
            return True
        try:
            with self.lock:
                if stop.is_set() or not focused():
                    return False
                self.pad.press_button(button=self.button)
                self.pad.update()
            completed = self.wait(hold, stop, focused)
        finally:
            # Also reset when update failed after partially delivering a report.
            self.reset()
        if completed:
            self.log('Xbox TX: A нажата/отпущена; подтверждение цели — по изображению')
        return completed

    def double_a(self, stop, focused, gap=.32, before_second=None):
        if not self.tap_a(stop, focused):
            return False
        if not self.wait(gap, stop, focused):
            return False
        if before_second is not None:
            before_second()
        return self.tap_a(stop, focused)
