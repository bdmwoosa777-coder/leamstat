"""Screen-calibrated resource markers; no assumption that every map dot is a resource."""
from dataclasses import dataclass
from pathlib import Path
import math
import cv2
import numpy as np

ROOT = Path(__file__).resolve().parent


@dataclass
class Marker:
    name: str
    x: int
    y: int
    score: float
    distance: float


class MinimapVision:
    def __init__(self, cfg):
        self.cfg = cfg
        self.templates = []
        for item in cfg.get('minimap_templates', []):
            path = (ROOT/item['file']).resolve()
            if not path.is_relative_to(ROOT):
                continue
            gray = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
            if gray is not None:
                self.templates.append((item.get('name', 'Ресурс'), gray))

    @property
    def ready(self):
        return len(self.cfg.get('minimap_roi', [])) == 4 and bool(self.templates)

    def bounds(self, frame):
        h, w = frame.shape[:2]
        x, y, rw, rh = self.cfg['minimap_roi']
        x0, y0 = round(x*w), round(y*h)
        x1, y1 = round((x+rw)*w), round((y+rh)*h)
        return max(0,x0), max(0,y0), min(w,x1), min(h,y1)

    def player(self, frame):
        x0,y0,x1,y1 = self.bounds(frame)
        cx,cy = self.cfg.get('minimap_player', [.5,.5])
        return x0+(x1-x0)*cx, y0+(y1-y0)*cy

    def scan(self, frame):
        if not self.ready:
            return []
        x0,y0,x1,y1 = self.bounds(frame)
        roi = frame[y0:y1,x0:x1]
        if min(roi.shape[:2], default=0) < 10:
            return []
        gray = cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY)
        edges = cv2.Canny(gray,55,135)
        scale = frame.shape[1]/self.cfg.get('minimap_reference_size',[frame.shape[1],frame.shape[0]])[0]
        px,py = self.player(frame)
        threshold = float(self.cfg.get('minimap_threshold',.80))
        found = []
        for name,template in self.templates:
            if self.cfg.get('only_aether') and name not in ('Эфир','Ресурс'):
                continue
            for f in (.95,1.0,1.05):
                tpl = cv2.resize(template,None,fx=scale*f,fy=scale*f)
                th,tw = tpl.shape
                if th>=gray.shape[0] or tw>=gray.shape[1] or min(th,tw)<4:
                    continue
                te = cv2.Canny(tpl,55,135)
                if np.count_nonzero(te)<8:
                    continue
                scores = cv2.matchTemplate(edges,te,cv2.TM_CCOEFF_NORMED)
                # Extract bounded local peaks and suppress repeated matches/scales.
                for _ in range(24):
                    _,score,_,(x,y) = cv2.minMaxLoc(scores)
                    if score<threshold:
                        break
                    cx,cy = x0+x+tw//2,y0+y+th//2
                    distance = math.hypot(cx-px,cy-py)
                    if distance>max(12, min(roi.shape[:2])*.035):
                        if all(math.hypot(cx-m.x,cy-m.y)>max(8,tw*.7) for m in found):
                            found.append(Marker(name,cx,cy,float(score),distance))
                    scores[max(0,y-th//2):min(scores.shape[0],y+th//2+1),
                           max(0,x-tw//2):min(scores.shape[1],x+tw//2+1)] = -1
        return sorted(found,key=lambda m:(m.distance,-m.score))
