"""Offline, no game input, no hardware: python test_offline.py"""
from pathlib import Path
import cv2
from bridge import frame_codes,COMMANDS
from vision import WorldVision,segment_count,gathering_panel,gather_result_full,flight_gauge
from captcha_watchdog import CenterDialogDetector
from death_watchdog import DeathDialogDetector
ROOT=Path(__file__).parent
v=WorldVision(('Орихаркон','Эфир','Сапфир','Рубин','Алмаз'));cap=CenterDialogDetector(ROOT);death=DeathDialogDetector(ROOT)
for cmd,num in COMMANDS.items():
    c=frame_codes(cmd)
    assert len(c)==4 and c[0]==3
    assert (c[1]*4+c[2])==num
    assert c[3]==(c[1]+2*c[2]+1)%4
print('Lua command protocol:',len(COMMANDS),'commands OK')
ground=cv2.imread(str(ROOT/'testdata/orihalkon_example.jpg'))
air=cv2.imread(str(ROOT/'testdata/air_gather_example.jpg'))
assert ground is not None and air is not None
obs=v.scan(ground)
assert obs.target_name=='Орихаркон',obs
assert abs(obs.distance_m-10.0)<1,obs
assert obs.candidate is not None and obs.candidate.name=='Орихаркон',obs
assert segment_count(ground)==3
assert not obs.gathering
assert v.prompt.detect(air)[0]
assert gathering_panel(air)
assert segment_count(air)==2
assert gather_result_full(air)
for frame in (ground,air):
    assert not cap.check(frame)[0]
    assert not death.check(frame)[0]
print('Resource UI and negative CAPTCHA/death:', 'PASS')
# Optional control images, if the wing research package exists in this workspace.
p=Path('/mnt/data/ACore2_reference/ACore2_Wings_Analysis_2026-11-03/control_frames')
if p.exists():
    cases=[('frame_005s.jpg',100,4),('frame_020s.jpg',82.3,4),('frame_049s.jpg',46.7,4),('frame_050s.jpg',None,0),('frame_128s.jpg',19.7,4)]
    for file,expected,tol in cases:
        im=cv2.imread(str(p/file));val,state=flight_gauge(im)
        assert (expected is None and val is None) or (val is not None and abs(val-expected)<=tol),(file,val)
    print('Flight gauge vs reference frames:',len(cases),'PASS')
print('OFFLINE TESTS PASS; no live G HUB or gameplay key tested')
