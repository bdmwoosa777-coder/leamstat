# -*- coding: utf-8 -*-
"""Windows lock-key -> dedicated G HUB Lua command transport.

No SendInput gameplay keys. The Python -> G HUB bridge is best-effort: there is
NO acknowledge from Lua. All stateful Lua operations have an independent watchdog.
"""
import os,time,threading

COMMANDS={
    'PING':0,'ALT_DOWN':1,'DOUBLE_CLICK':2,'ALT_UP':3,
    'F_ON':4,'F_OFF':5,'V':6,'STOP':7,
    'TURN_RIGHT':8,'TURN_LEFT':9,'TAP_F':10,
    'W_STEP':11, 'LEFT_STEP':12, 'RIGHT_STEP':13,
}

def frame_codes(command):
    if command not in COMMANDS:raise ValueError(command)
    v=COMMANDS[command];hi=v//4;lo=v%4
    # SOF, 2-bit high, 2-bit low, 2-bit parity/checksum
    return [3,hi,lo,(hi+2*lo+1)%4]

class GHubBridge:
    def __init__(self,dry_run=False,logger=None):
        self.dry_run=dry_run or os.name!='nt'
        self.log=logger or (lambda _:None)
        self.lock=threading.RLock()
        self.sent=[]
        self._saved=None
        if not self.dry_run:
            import ctypes
            from ctypes import wintypes
            self.win=ctypes.windll.user32
            self.win.GetKeyState.argtypes=[ctypes.c_int]
            self.win.GetKeyState.restype=ctypes.c_short
            self.win.keybd_event.argtypes=[wintypes.BYTE,wintypes.BYTE,wintypes.DWORD,ctypes.c_size_t]
            self.win.keybd_event.restype=None
            self.win.SetCursorPos.argtypes=[ctypes.c_int,ctypes.c_int]
            self.win.SetCursorPos.restype=wintypes.BOOL
            self._saved={20:bool(self.win.GetKeyState(20)&1),144:bool(self.win.GetKeyState(144)&1),145:bool(self.win.GetKeyState(145)&1)}

    def _toggle(self,key,desired):
        # Scan codes and short down/up separation follow the working v26 bridge.
        scan={20:0x3A,144:0x45,145:0x46}[key]
        for _ in range(3):
            if bool(self.win.GetKeyState(key)&1)==bool(desired):return
            self.win.keybd_event(key,scan,0,0)
            time.sleep(.008)
            self.win.keybd_event(key,scan,2,0)
            time.sleep(.034)
        if bool(self.win.GetKeyState(key)&1)!=bool(desired):
            raise RuntimeError('Не удалось переключить lock-key '+hex(key))

    def send(self,command):
        data=frame_codes(command)
        with self.lock:
            if self.dry_run:
                self.sent.append((time.monotonic(),command,data))
                self.log('СИМУЛЯЦИЯ '+command)
                return
            # G HUB samples lock state at ScrollLock positive edge. A pulse
            # should be long enough for POLL_MS=12ms. No >3 commands in 2-bit mode.
            for v in data:
                self._toggle(20,bool(v&2))
                self._toggle(144,bool(v&1))
                self._toggle(145,False)
                time.sleep(.018)
                self._toggle(145,True)
                time.sleep(.078)
                self._toggle(145,False)
                time.sleep(.040)
            self.log('Python TX (lock-key frame sent; Lua ACK absent): '+command)

    def cursor(self,x,y):
        if self.dry_run:
            self.log(f'СИМУЛЯЦИЯ курсор ({x},{y})');return
        # SetCursorPos is not a gameplay keypress. Mouse clicks are made by Lua.
        if not self.win.SetCursorPos(int(x),int(y)):
            raise OSError('Не удалось установить позицию курсора')

    def restore_locks(self):
        if self.dry_run:return
        with self.lock:
            self._toggle(145,False)
            for k,v in self._saved.items():self._toggle(k,v)
