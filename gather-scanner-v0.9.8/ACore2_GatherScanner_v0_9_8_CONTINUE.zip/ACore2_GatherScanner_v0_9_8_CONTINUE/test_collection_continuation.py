"""Own attempt result -> immediate fresh click, including missing selection echo."""
import unittest
from unittest.mock import patch
import numpy as np
import cv2
import gather_engine as ge
import vision
from flight import FlightReading
from test_navigation import GatherFixture
from test_network_control import Source
from test_ether_emblem import scene,ether

AIR=FlightReading(50,True)
GROUND=FlightReading(None,False)

class CollectionContinuation(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(resource_click_interaction=True,collection_cursor_hold=True)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.nodes[99].template=1500000;self.f.nodes[99].gather_time=1000
        self.f.selection_time=1000;self.f.collecting=99;self.f.attempt_active=True
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
        self.frame=scene();self.e.candidate=ether(self.frame)
        self.clock=100.;self.wall=1100;self.clicks=[];self.callback=lambda:None
        self.e.current_size=(self.frame.shape[1],self.frame.shape[0])
        send=self.e.bridge.send
        def transport(command):
            # The real lock-key transport costs around 1.1s per command.
            self.clock+=1.1;return send(command)
        self.e.bridge.send=transport
        def wait(seconds,*args):self.clock+=seconds;return True
        def click(*args,**kwargs):self.clicks.append((self.clock,self.positions[-1]));self.callback();return True
        self.input.tap_a=click
        for q in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),patch.object(ge.GamepadInput,'wait',side_effect=wait)):
            q.start();self.addCleanup(q.stop)

    def ended(self,used=1):
        self.f.nodes[99].used=used;self.f.attempt_active=False

    def start(self):
        self.f.attempt_active=True;self.f.nodes[99].gather_time=self.wall

    def prepared(self):
        self.e.f_enable();self.assertTrue(self.alt_held);self.assertEqual(self.clicks,[])

    def test_cursor_prepared_during_active_attempt_without_any_click(self):
        self.prepared();self.e.f_enable()
        self.assertEqual(self.commands,['ALT_DOWN']);self.assertTrue(self.e.collection_cursor_owned)
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_first_result_click_has_no_lua_round_trip_or_multi_second_delay(self):
        self.prepared();self.ended();before=self.clock;self.callback=self.start
        self.e.f_enable()
        self.assertEqual(len(self.clicks),1);self.assertLess(self.clicks[0][0]-before,.3)
        self.assertEqual(self.commands,['ALT_DOWN']);self.assertTrue(self.alt_held)
        self.assertFalse({'TAP_F','F_ON','V','END_AIR','TAB'}&set(self.commands))

    def test_second_result_continues_same_resource_without_search_or_calibration(self):
        self.prepared();self.callback=self.start
        for used in (1,2):
            self.ended(used);before=self.clock;self.e.f_enable()
            self.assertLess(self.clicks[-1][0]-before,.3)
            self.e.f_enable();self.clock+=.5
        self.assertEqual(len(self.clicks),2);self.assertEqual(self.e.network_target,(1,99))
        self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.commands,['ALT_DOWN'])

    def test_zero_selected_without_3438_gets_activation_instead_of_wait_loop(self):
        self.prepared();self.f.selected=0;self.ended();before=self.clock
        self.e.f_enable()
        self.assertEqual(len(self.clicks),2);self.assertLess(self.clicks[-1][0]-before,.4)
        self.assertEqual(self.f.selected,0);self.assertEqual(self.e.next_attempt_click_tries,1)
        self.assertEqual(self.e.next_attempt_sent_used,1);self.assertTrue(self.alt_held)

    def test_first_zero_selection_click_starting_attempt_stops_second_click(self):
        self.prepared();self.f.selected=0;self.ended();self.callback=self.start
        self.e.f_enable();self.assertEqual(len(self.clicks),1)

    def test_wrong_positive_id_after_selection_blocks_activation(self):
        self.prepared();self.f.selected=0;self.ended()
        self.callback=lambda:setattr(self.f,'selected',55)
        self.e.f_enable();self.assertEqual(len(self.clicks),1)
        self.assertIsNone(self.e.next_attempt_sent_used)

    def test_missing_echo_exception_is_not_available_to_a_new_route(self):
        self.f.selected=0;self.f.collecting=None;self.f.attempt_active=False
        self.f.nodes[99].gather_time=None;self.e.real_gather_panel_seen=False;self.e.fast_gather_seen=False
        self.e.mode='APPROACH';self.e._start_resource_route()
        self.assertEqual(len(self.clicks),1);self.assertFalse(self.e.route_active)

    def test_no_candidate_does_not_spend_two_commands_toggling_alt(self):
        self.ended();self.frame[:]=0;self.e.candidate=None
        self.e.f_enable();self.assertEqual(self.commands,[]);self.assertEqual(self.clicks,[])

    def test_caption_shifted_after_calibration_is_found_without_snapshot(self):
        old=self.e.candidate;self.prepared();self.ended()
        self.frame=scene(x=1100,y=450);self.e.snapshot=None
        self.e.identity_valid_after=self.clock
        self.e.f_enable();self.assertEqual(len(self.clicks),1)
        self.assertGreater(self.clicks[-1][1][1],old.click_y+150)

    def test_twice_enlarged_selected_caption_tracks_without_background_ocr(self):
        self.prepared();self.ended();old=self.e.candidate
        x,y,w,h=old.box;label=self.frame[y:y+h,x:x+w].copy();self.frame[:]=35
        label=cv2.resize(label,None,fx=2,fy=2);self.frame[350:350+h*2,1100:1100+w*2]=label
        self.e.snapshot=None;self.e.f_enable()
        self.assertGreater(len(self.clicks),0);self.assertGreater(self.e.candidate.box[2],w*1.5)

    def test_fresh_own_start_during_cursor_settle_stops_activation(self):
        self.prepared();self.ended();cursor=self.e.bridge.cursor
        def move(x,y):cursor(x,y);self.start()
        self.e.bridge.cursor=move;self.e.f_enable();self.assertEqual(self.clicks,[])

    def test_invisible_caption_keeps_gather_identity_and_original_recovery_deadline(self):
        self.prepared();self.ended();self.frame[:]=0
        self.e.click_wait_since=self.clock-7;self.e.f_enable()
        self.assertEqual(self.e.mode,'GATHER');self.assertTrue(self.e.target_confirmed)
        self.assertEqual(self.e.network_target,(1,99));deadline=self.e.view_recovery.until
        for _ in range(3):self.clock+=.5;self.e.f_enable()
        self.assertEqual(self.e.view_recovery.until,deadline);self.assertEqual(self.clicks,[])

    def test_recovery_deadline_really_expires_instead_of_readopting_forever(self):
        self.prepared();self.ended();self.frame[:]=0
        self.e.click_wait_since=self.clock-7;self.e.f_enable()
        self.clock=self.e.view_recovery.until+.1
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e._own_collection())
        self.assertFalse(self.e._adopt_network_collection());self.assertFalse(self.e.stop_event.is_set())

    def test_defense_releases_alt_before_tab_is_possible(self):
        self.prepared();self.ended();self.f.npcs[55]={'time':900};self.f.attacks[55]=self.wall
        self.e.network_attacker=55;self.e._begin_network_defense(True)
        self.assertFalse(self.alt_held);self.assertFalse(self.e.collection_cursor_owned)
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP']);self.assertEqual(self.e.mode,'DEFENSE')

    def test_depletion_releases_cursor_and_preserves_counter(self):
        self.prepared();self.ended(3);self.f.collecting=None
        self.e._net_resource(self.frame,GROUND,self.clock)
        self.assertFalse(self.alt_held);self.assertFalse(self.e.collection_cursor_owned)
        self.assertEqual(self.e.mode,'SEARCH');self.assertEqual(self.f.nodes[99].used,3)

    def test_stop_releases_owned_cursor(self):
        self.prepared();self.e._release_inputs()
        self.assertFalse(self.e.collection_cursor_owned);self.assertFalse(self.alt_held)

    def test_same_binding_recovery_does_not_lose_known_ether_name(self):
        self.f.nodes[99].template=None;self.e.target_confirmed=False
        self.assertTrue(self.e._adopt_network_collection());self.assertEqual(self.e.target,'Эфир')

    def test_duplicate_ticks_do_not_click_during_active_attempt(self):
        self.prepared()
        for _ in range(10):self.e.f_enable();self.clock+=.02
        self.assertEqual(self.clicks,[]);self.assertEqual(self.commands,['ALT_DOWN'])

    def test_network_failure_never_warms_cursor(self):
        self.source.ready=False;self.e.f_enable();self.assertEqual(self.commands,[])

    def test_camera_busy_defers_preparation_and_preserves_attempt(self):
        self.e.camera_in_progress=True;self.e.f_enable()
        self.assertEqual(self.commands,[]);self.assertTrue(self.f.attempt_active)

    def test_calibration_does_not_start_in_the_gap_before_continuation(self):
        self.ended();self.e.camera_search_revision=2;self.e.camera_aligned_revision=1
        with patch.object(self.e,'_gather_panel',return_value=True),patch.object(self.e,'_hold_pitch_up') as up:
            self.assertTrue(self.e._calibrate_camera('test',allow_gather=True))
        up.assert_not_called();self.assertEqual(self.e.camera_aligned_revision,1)


if __name__=='__main__':unittest.main()
