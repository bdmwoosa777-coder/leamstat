# Built-in Altgard reference

Input: 34 original game map JPG tiles under `Client/assets/aion2/maps/altgard/` in
[SkeeveAN/Aion-DPS-Meter](https://github.com/SkeeveAN/Aion-DPS-Meter/tree/d9babccbaf037f9dc54c77d24f19198b234cb1f1),
commit d9babccbaf037f9dc54c77d24f19198b234cb1f1. Software MIT notice is already
preserved in LICENSE-MIT.txt; original game imagery remains NCSOFT / NC Corporation.

Each native 1024px tile col_row.jpg was verified against its Git blob SHA and
resized to 512px, then placed at (col*512,row*512) in a 4096px reference.
altgard_reference_sources.json preserves input paths, byte counts and SHA-256.
The native-to-reference factor is .5; world-to-native scale/offset come from
unchanged maps.json. No marker locations were guessed from screenshot pixels.

altgard_reference.jpg is the derived compressed atlas. altgard_features.npz
contains locally computed SIFT feature coordinates/descriptors and the source
image SHA-256, for quick initialization. It is not a neural model or a record
of user gameplay. Source matching and runtime input logic are independent local
implementations; no competitor executable, process-memory reader or session key
is included. No user screenshot, position, private calibration or log is shipped.
