"""Game-owned travel with actual hybrid input gates, virtual time/device/network."""
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import unittest
import numpy as np
import map_autopath as mp
from map_autopath import MapAutopath,PathRun
from map_coordinates import MapGoal
from map_mousekeys import Dispatch
from auto_route_hud import AutoRouteHUD
from map_flight_dialog import FlightDialog
from flight import FlightReading
import test_hybrid as fx
import test_tp_exit37 as tpfx

class Coordinates:
 ready=True
 spec={'air_points':[[400,400]]}
 inverse=np.eye(3)
 def __init__(self):
  self.goal=MapGoal(('node',1),'Алмаз',(200,200),(5000,0,0),True)
  self.fix={'matrix':np.eye(3),'world':(0,0),'position':(100,100),'viewport':(0,0,1280,720)}
  self.deferred=[];self.layer=True;self.visible=True;self.point=(200,200)
 def valid_layer(self,state):return self.layer
 def register(self,frame):return self.fix if self.visible else None
 def pixel(self,goal,fix):return self.point
 def goals(self,*a):return [self.goal]
 def defer(self,*args):self.deferred.append(args)

class Transport:
 ready=True
 def __init__(self,case):self.c=case;self.clicks=0;self.maps=0;self.consents=0;self.ack=True;self.before=lambda:None;self.closed=False
 def ping(self,authorize):return Dispatch(True,self.ack)
 def map_toggle(self,authorize):
  if not authorize():return Dispatch(False,False)
  self.maps+=1;self.c.opened=not self.c.opened;return Dispatch(True,True)
 def click(self,authorize):
  self.before()
  if not authorize():return Dispatch(False,False,'revoked')
  self.clicks+=1;return Dispatch(True,self.ack,'dispatched')
 def confirm_flight(self,authorize):
  if not authorize():return Dispatch(False,False)
  self.consents+=1;return Dispatch(True,True)
 def close(self):self.closed=True;self.ready=False

class Travel(unittest.TestCase):
 def setUp(self):
  self.f=fx.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e;self.clock=100.;self.opened=False;self.focus=True;self.damage=False
  self.e.cfg.update(map_mousekeys_enabled=True,map_autopath_required=False,map_mousekeys_fly_long=True,map_mousekeys_flight_distance_m=80)
  self.path=MapAutopath.__new__(MapAutopath)
  self.path.cfg=self.e.cfg;self.path.emit=self.f.log.append;self.path.coordinates=Coordinates();self.path.transport=Transport(self)
  for key,value in dict(run=None,next_at=0,ping_after=0,stopping=False,force_camp=False,escape_next=False,last_goal=None,last_note=-1e9,cancelling=False).items():setattr(self.path,key,value)
  self.e.map_autopath=self.path;self.e.screen.focused=lambda:self.focus;self.picture=self.f.frame.copy();self.origin=(0,0)
  h,w=self.picture.shape[:2]
  for a,b,c,d in ((.01,.06,.025,.24),(.067,.105,.35,.44)):self.picture[round(h*a):round(h*b),round(w*c):round(w*d)]=210
  self.e.screen.frame=lambda:(self.picture.copy(),self.origin);self.e.bridge.cursor_matches=lambda:True
  self.e._urgent_damage_pending=lambda:self.damage;self.e.budget.energy=80
  self.hud=AutoRouteHUD(True,40);self.flight=FlightReading(None,False);self.dialog=None
  self.e.gamepad.motion_worker=object()
  self.axes=[];base=self.f.pad.left_joystick_float
  self.f.pad.left_joystick_float=lambda x_value_float,y_value_float:(self.axes.append((x_value_float,y_value_float)),base(x_value_float,y_value_float))[-1]
  for p in (patch('map_autopath.time.monotonic',side_effect=lambda:self.clock),patch('map_autopath.GamepadInput.wait',return_value=True),patch('map_autopath.is_map',side_effect=lambda f:self.opened),patch('map_autopath.read_flight',side_effect=lambda f:self.flight),patch('map_autopath.route_hud',side_effect=lambda f:self.hud),patch('map_autopath.flight_dialog',side_effect=lambda f:self.dialog),patch('map_autopath.same_flight_dialog',side_effect=lambda f,s:self.dialog is not None)):
   p.start();self.addCleanup(p.stop)
 def tick(self,t=None):
  self.clock=self.clock+.7 if t is None else t
  return self.path.tick(self.e,self.picture,self.clock)
 def activate(self,phase='TRAVEL',air=False,goal=True):
  self.e.change_mode('MAP_PATH');self.path.run=PathRun(phase,self.clock,self.clock,'resources',1,7,goal=self.path.coordinates.goal if goal else None,attempted=True,progress=self.clock,check_at=self.clock+5,pending_air=air)
  return self.path.run
 def arrive_travel(self):
  self.tick(100);self.assertEqual(self.path.run.phase,'MAP')
  self.tick();self.assertEqual(self.path.run.phase,'CLICK')
  self.tick();self.assertEqual(self.path.transport.clicks,1)
  self.tick();self.assertEqual(self.path.run.phase,'CLOSE_WAIT')
  self.tick();self.assertEqual(self.path.run.phase,'TRAVEL')
 def test_full_map_click_close_travel_and_two_near_samples(self):
  self.arrive_travel();self.hud=AutoRouteHUD(True,2)
  self.tick();self.assertIsNotNone(self.path.run)
  self.tick();self.assertTrue(self.path.run.finishing)
  self.tick();self.assertIsNone(self.path.run);self.assertEqual(self.path.transport.clicks,1)
  self.assertTrue(self.e.wing_close_pending is None);self.assertFalse(any(x!=(0,0) for x in self.axes))
 def test_unknown_lua_ack_still_needs_game_banner_and_never_double_clicks(self):
  self.path.transport.ack=False;self.arrive_travel();self.tick()
  self.assertTrue(self.path.run.hud_seen);self.assertEqual(self.path.transport.clicks,1)
 def test_left_stick_is_blocked_but_camera_remains_available(self):
  self.activate();self.e.gamepad.drive(.7,.4,0,0,lifetime=.1)
  self.e.gamepad.drive(0,0,.3,0,lifetime=.1)
  self.assertEqual(self.f.pad.axes[:2],(0,0));self.assertGreater(abs(self.f.pad.axes[2]),0)
 def test_sprint_a_context_action_jump_and_wing_fold_are_blocked(self):
  self.activate()
  for cmd in ('V','END_AIR','JUMP','ATTACK_PAIR','TAB','TAP_F','F_ON'):self.assertFalse(self.e.bridge_cmd(cmd),cmd)
  self.assertFalse(self.e._a_input_ready());self.assertEqual(self.f.commands,[])
 def test_explicit_cancel_is_the_only_allowed_motion_during_upgrade(self):
  self.activate();self.path._cancel_motion(self.e)
  self.assertTrue(any(y<0 for x,y in self.axes));self.assertFalse(self.path.cancelling)
 def test_own_collection_releases_route_without_stick_or_wing_toggle(self):
  self.activate();self.f.source.state.collecting=99;self.f.source.state.attempt_active=True
  self.assertFalse(self.tick());self.assertIsNone(self.path.run)
  self.assertFalse(any(x!=(0,0) for x in self.axes));self.assertEqual(self.f.commands,[])
 def test_current_resource_hold_prevents_start(self):
  self.e.resource_hold=True;self.assertFalse(self.tick());self.assertIsNone(self.path.run)
 def test_confirmed_hit_during_autopath_does_not_stop_for_a_mob(self):
  run=self.activate();self.damage=True;self.assertTrue(self.tick())
  self.assertIs(self.path.run,run);self.assertFalse(any(x!=(0,0) for x in self.axes))
 def test_priority_defense_is_deferred_while_game_autopath_owns_movement(self):
  self.activate();self.damage=True
  with patch('gather_engine.GatherEngine._priority_network_defense',return_value=True) as defense:
   self.assertFalse(self.e._priority_network_defense(self.clock));defense.assert_not_called()
  self.assertIsNotNone(self.path.run)
 def test_no_damage_does_not_give_background_defense_a_route(self):
  self.activate()
  with patch('gather_engine.GatherEngine._priority_network_defense') as defense:
   self.assertFalse(self.e._priority_network_defense(self.clock));defense.assert_not_called()
 def test_focus_loss_never_sends_click_or_cancellation_to_other_app(self):
  self.activate();self.focus=False;self.tick();self.assertIsNotNone(self.path.run)
  self.assertEqual(self.path.transport.clicks,0);self.assertFalse(any(x!=(0,0) for x in self.axes))
 def test_flow_change_revokes_route(self):
  self.activate();self.path.run.flow=2;self.tick();self.assertIsNone(self.path.run)
 def test_character_change_revokes_route(self):
  self.activate();self.f.source.state.own=8;self.tick();self.assertIsNone(self.path.run)
 def test_total_time_limit_is_not_extended_by_phase_changes(self):
  run=self.activate();self.path.phase('OPEN',169);self.tick(171)
  self.assertIsNone(self.path.run);self.assertEqual(run.started,100)
 def test_three_missing_banners_require_position_check(self):
  run=self.activate();run.hud_seen=True;self.hud=AutoRouteHUD(False)
  self.tick(101);self.tick(102);self.tick(103)
  self.assertEqual(run.phase,'CHECK_MAP');self.assertFalse(run.finishing)
  self.tick(104);self.assertTrue(run.failed);self.assertIn('вдали',run.result)
 def test_three_missing_banners_and_near_position_confirm_arrival(self):
  run=self.activate();run.hud_seen=True;self.hud=AutoRouteHUD(False);self.path.coordinates.fix['world']=(4900,0)
  for t in (101,102,103,104):self.tick(t)
  self.assertTrue(run.finishing);self.assertFalse(run.failed)
 def test_ocr_exception_unknown_is_not_an_arrival(self):
  run=self.activate();run.hud_seen=True;self.hud=AutoRouteHUD(None)
  self.tick(101);self.tick(102);self.tick(103);self.assertEqual(run.missing,0);self.assertFalse(run.finishing)
 def test_unconfirmed_click_has_finite_five_second_wait(self):
  run=self.activate();self.hud=AutoRouteHUD(False);self.tick(106)
  self.assertTrue(run.failed);self.assertIn('нет игрового',run.result)
 def test_stationary_distance_cannot_hold_forever(self):
  run=self.activate();self.tick(101);self.tick(108);self.assertTrue(run.failed)
 def test_failed_registration_closes_map_and_does_not_click(self):
  self.tick(100);run=self.path.run;self.path.coordinates.visible=False;self.tick(105)
  self.assertTrue(run.failed);self.tick();self.tick();self.assertIsNone(self.path.run);self.assertEqual(self.path.transport.clicks,0)
 def test_wrong_layer_prevents_start_without_input(self):
  self.path.coordinates.layer=False;self.assertFalse(self.tick());self.assertEqual(self.path.transport.maps,0)
 def test_window_moves_during_wire_revokes_numeric_click(self):
  self.tick(100);self.tick();self.path.transport.before=lambda:setattr(self,'origin',(20,20));self.tick()
  self.assertEqual(self.path.transport.clicks,0);self.assertTrue(self.path.run.failed)
 def test_cursor_changes_during_wire_revokes_numeric_click(self):
  self.tick(100);self.tick();self.path.transport.before=lambda:setattr(self.e.bridge,'cursor_matches',lambda:False);self.tick()
  self.assertEqual(self.path.transport.clicks,0)
 def test_map_pixels_change_during_wire_revokes_numeric_click(self):
  self.tick(100);self.tick();self.path.transport.before=lambda:self.picture.fill(255);self.tick()
  self.assertEqual(self.path.transport.clicks,0)
 def test_resource_starts_during_wire_revokes_numeric_click(self):
  self.tick(100);self.tick();self.path.transport.before=lambda:setattr(self.f.source.state,'attempt_active',True);self.tick()
  self.assertEqual(self.path.transport.clicks,0)
 def test_long_route_opens_wings_before_click_without_camera_calibration(self):
  self.path.coordinates.goal=replace(self.path.coordinates.goal,xyz=(10000,0,0))
  with patch.object(self.e,'_calibrate_camera',side_effect=AssertionError('not per trip')):
   self.tick(100);self.tick();self.assertEqual(self.path.run.phase,'CLOSE_FOR_WINGS')
   self.tick();self.assertEqual(self.path.run.phase,'WINGS');self.assertFalse(self.opened)
   with patch.object(self.e,'_wing_action_allowed',return_value=True):self.tick()
   self.assertEqual(self.f.commands,['V']);self.assertEqual(self.path.transport.clicks,0)
   self.flight=FlightReading(80,True);self.tick();self.tick();self.tick();self.tick()
  self.assertEqual(self.path.transport.clicks,1);self.assertTrue(self.path.run.pending_air)
 def test_unknown_energy_does_not_force_long_flight(self):
  self.path.coordinates.goal=replace(self.path.coordinates.goal,xyz=(10000,0,0));self.e.budget.energy=None
  self.tick(100);self.tick();self.assertEqual(self.path.run.phase,'CLICK')
 def test_camp_exit_stays_ground_even_beyond_eighty_metres(self):
  self.path.force_camp=True;self.path.coordinates.goal=replace(self.path.coordinates.goal,xyz=(10000,0,0))
  self.tick(100);self.tick();self.assertEqual(self.path.run.reason,'camp');self.assertEqual(self.path.run.phase,'CLICK')
 def test_large_confirmed_ground_detour_upgrades_only_once(self):
  run=self.activate();run.straight=50;self.hud=AutoRouteHUD(True,200);self.tick(101)
  self.assertEqual(run.phase,'WINGS');self.assertEqual(run.switches,1)
  self.path.phase('TRAVEL',102);self.tick(103);self.assertEqual(run.phase,'TRAVEL');self.assertEqual(run.switches,1)
 def test_airborne_distance_does_not_trigger_ground_detour_upgrade(self):
  run=self.activate(air=True);run.straight=50;self.flight=FlightReading(80,True);self.hud=AutoRouteHUD(True,200);self.tick(101)
  self.assertEqual(run.phase,'TRAVEL');self.assertEqual(run.switches,0)
 def test_exact_flight_modal_sends_f_once_without_jump(self):
  run=self.activate('CLOSE');run.map_open=True;self.opened=True;self.dialog=FlightDialog((700,400),(500,400),np.zeros((90,180)))
  self.tick(101);self.assertEqual(run.phase,'FLIGHT_WAIT');self.tick(102)
  self.assertEqual(self.path.transport.consents,1);self.assertNotIn('JUMP',self.f.commands)
  self.dialog=None;self.tick(103);self.assertEqual(run.phase,'CLOSE')
 def test_unknown_modal_never_sends_contextual_f(self):
  self.activate('CLOSE');self.tick(101);self.assertEqual(self.path.transport.consents,0)
 def test_low_energy_modal_is_declined_without_f_or_b(self):
  run=self.activate('CLOSE');self.opened=True;run.map_open=True;self.e.budget.energy=10
  self.dialog=FlightDialog((700,400),(500,400),np.zeros((90,180)))
  with patch.object(self.e.gamepad,'tap_ui_a',return_value=True) as tap:self.tick(101);tap.assert_called_once()
  self.assertEqual(self.path.transport.consents,0);self.assertTrue(run.failed)
 def test_flight_modal_that_does_not_close_is_not_reconfirmed(self):
  run=self.activate('CLOSE');self.dialog=FlightDialog((700,400),(500,400),np.zeros((90,180)))
  self.tick(101)
  with patch.object(self.e.gamepad,'tap_ui_a',return_value=True):self.tick(105)
  self.assertEqual(self.path.transport.consents,1);self.assertTrue(run.failed)
 def test_gem_arrival_queues_wing_close_only_after_two_near_samples(self):
  self.activate(air=True);self.flight=FlightReading(80,True);self.hud=AutoRouteHUD(True,2)
  self.tick(101);self.assertIsNone(self.e.wing_close_pending)
  self.tick(102);self.assertIsNone(self.e.wing_close_pending)
  self.tick(103);self.assertEqual(self.e.wing_close_pending,103)
 def test_ether_arrival_keeps_wings_for_gathering(self):
  self.path.coordinates.goal=replace(self.path.coordinates.goal,name='Эфир');self.activate(air=True)
  self.flight=FlightReading(80,True);self.hud=AutoRouteHUD(True,2)
  for t in (101,102,103):self.tick(t)
  self.assertIsNone(self.path.run);self.assertIsNone(self.e.wing_close_pending)
 def test_failed_map_close_keeps_menu_recovery_guard(self):
  run=self.activate('CLOSE_WAIT');run.map_open=True;run.close_retries=1;self.opened=True
  self.path.transport.map_toggle=lambda a:Dispatch(True,False)
  self.tick(103);self.assertIsNone(self.path.run);self.assertTrue(self.e.map_active);self.assertIsNotNone(self.e.map_exit_failure)
  self.assertFalse(any(x!=(0,0) for x in self.axes))
 def test_stop_cancels_native_route_and_restores_locks(self):
  self.activate();self.path.stop(self.e)
  self.assertIsNone(self.path.run);self.assertTrue(self.path.transport.closed);self.assertTrue(any(y<0 for x,y in self.axes))

class PostTP(unittest.TestCase):
 def setUp(self):
  self.f=tpfx.BackwardExitEngine('test_initial_backward_right_stick_with_zero_camera_stick');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.p=SimpleNamespace(enabled=True,transport=SimpleNamespace(ready=True),force_camp=False,next_at=0,owns=False)
  self.e.map_autopath=self.p
 def test_ready_map_lua_replaces_blind_backward_macro_after_loading(self):
  self.f.arm();self.f.tick(100);self.f.tick(103.5)
  self.assertIsNone(self.e.post_tp_exit);self.assertTrue(self.p.force_camp);self.assertEqual(self.f.f.pad.axes,(0,0,0,0))
 def test_no_lua_ack_retains_existing_working_backward_right_exit(self):
  self.p.transport.ready=False;self.f.start_motion();self.assertEqual(self.f.f.pad.axes,(1,-1,0,0));self.assertFalse(self.p.force_camp)

if __name__=='__main__':unittest.main()
