"""Virtual Xbox A transport. Keyboard actions stay on the existing G HUB bridge."""
import os
import threading
import time


class GamepadInput:
    def __init__(self, dry_run=False, logger=None, factory=None, a_button=None):
        self.dry_run = dry_run
        self.log = logger or (lambda _: None)
        self.lock = threading.RLock()
        self.pad = None
        self.motion_deadline=None
        self.translation=(0.,0.)
        self.yaw_deadline=None;self.right_pitch=0
        self.motion_worker=None
        self.motion_listener=None
        self.camera_gate=None
        self.closing=threading.Event()
        self.button = a_button
        if dry_run:
            return
        if factory is None:
            if os.name != 'nt':
                raise RuntimeError('Виртуальный Xbox требует Windows и ViGEmBus')
            try:
                import vgamepad as vg
            except Exception as exc:
                raise RuntimeError('Не удалось подключить vgamepad/ViGEmBus: ' + str(exc)) from exc
            factory, self.button = vg.VX360Gamepad, vg.XUSB_BUTTON.XUSB_GAMEPAD_A
        self.pad = factory()
        self.reset()
        self.log('Виртуальный Xbox подключён; F710 и мышь с макросом не нужны')

    def reset(self):
        with self.lock:
            self.motion_deadline=None;self.yaw_deadline=None;self.right_pitch=0
            self.translation=(0.,0.)
            if self.pad is not None:
                self.pad.reset()
                self.pad.update()
                if self.motion_listener:self.motion_listener(0,time.monotonic(),0)

    def drive(self,forward=0.0,strafe=0.0,yaw=0.0,pitch=0.0,lifetime=.4,yaw_lifetime=None):
        """Short renewable motion lease; a stalled vision loop cannot hold a stick forever."""
        if self.dry_run or self.closing.is_set():return False
        if (abs(yaw)>.001 or abs(pitch)>.001) and self.camera_gate is not None:
            if not self.camera_gate():
                self.reset();return False
        with self.lock:
            if self.closing.is_set():return False
            self.pad.left_joystick_float(x_value_float=max(-1,min(1,strafe)),y_value_float=max(-1,min(1,forward)))
            self.pad.right_joystick_float(x_value_float=max(-1,min(1,yaw)),y_value_float=max(-1,min(1,pitch)))
            self.pad.update()
            now=time.monotonic();lease=max(.02,min(.85,lifetime))
            self.translation=(max(-1,min(1,forward)),max(-1,min(1,strafe)))
            self.motion_deadline=now+lease
            self.right_pitch=max(-1,min(1,pitch))
            self.yaw_deadline=(now+max(.02,min(lease,yaw_lifetime))
                               if yaw_lifetime is not None and abs(yaw)>.001 else None)
            if self.motion_listener:self.motion_listener(pitch,now,lease)
            if self.motion_worker is None:
                self.motion_worker=threading.Thread(target=self._motion_watchdog,daemon=True)
                self.motion_worker.start()

    def current_translation(self):
        with self.lock:
            if self.motion_deadline is None or time.monotonic()>=self.motion_deadline:return (0.,0.)
            return self.translation

    def _motion_watchdog(self):
        while not self.closing.wait(.005):
            with self.lock:
                if self.motion_deadline is not None and time.monotonic()>=self.motion_deadline:
                    try:self.reset()
                    except Exception as exc:self.log('Не удалось сбросить стики: '+str(exc))
                elif self.yaw_deadline is not None and time.monotonic()>=self.yaw_deadline:
                    try:
                        self.yaw_deadline=None
                        self.pad.right_joystick_float(x_value_float=0,y_value_float=self.right_pitch)
                        self.pad.update()
                    except Exception as exc:
                        self.reset();self.log('Не удалось завершить поворот камеры: '+str(exc))

    def close(self):
        self.closing.set()
        self.reset()

    @staticmethod
    def wait(seconds, stop, focused):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            if stop.is_set() or not focused():
                return False
            if stop.wait(min(.02, max(0, end-time.monotonic()))):
                return False
        return not stop.is_set() and focused()

    def tap_a(self, stop, focused, hold=.18):
        if stop.is_set() or not focused():
            return False
        if self.dry_run:
            self.log('СИМУЛЯЦИЯ Xbox A')
            return True
        try:
            with self.lock:
                if stop.is_set() or not focused():
                    return False
                self.reset()
                self.pad.press_button(button=self.button)
                self.pad.update()
            completed = self.wait(hold, stop, focused)
        finally:
            # Also reset when update failed after partially delivering a report.
            self.reset()
        if completed:
            self.log('Xbox TX: A нажата/отпущена; подтверждение цели — по изображению')
        return completed

    def double_a(self, stop, focused, gap=.32, before_second=None):
        if not self.tap_a(stop, focused):
            return False
        if not self.wait(gap, stop, focused):
            return False
        if before_second is not None:
            before_second()
        return self.tap_a(stop, focused)


class TranslationKeeper:
    """Renew an ALREADY ACTIVE ground patrol translation during G HUB writes.

    Never invents forward movement, never renews yaw/pitch, and expires even
    if its caller stalls. The predicate is checked under the gamepad lock so
    a concurrent Stop/reset cannot be followed by another motion report.
    """
    def __init__(self,pad,translation,allowed):
        self.pad=pad;self.translation=translation;self.allowed=allowed
        self.cancel=threading.Event();self.deadline=time.monotonic()+16.5
        self.worker=threading.Thread(target=self._run,daemon=True)
    def start(self):self.worker.start()
    def _run(self):
        try:
            while True:
                with self.pad.lock:
                    if (self.cancel.is_set() or self.pad.closing.is_set()
                        or time.monotonic()>=self.deadline or not self.allowed()):return
                    self.pad.drive(self.translation[0],self.translation[1],0,0,lifetime=.35)
                if self.cancel.wait(.08):return
        except Exception as exc:self.pad.log('Продление движения в защите остановлено: '+str(exc))
    def close(self):
        self.cancel.set()
        if self.worker.ident is not None and self.worker is not threading.current_thread():self.worker.join(timeout=.5)
        self.pad.reset()
