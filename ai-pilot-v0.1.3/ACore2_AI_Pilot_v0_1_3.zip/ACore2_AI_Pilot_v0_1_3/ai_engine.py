"""Fork controller: AI owns SEARCH; proven native collection/defense/map tools remain."""
import math,time
from dataclasses import replace
import cv2,numpy as np
from ai_policy import PolicyHost,available_actions
from gather_engine import GatherEngine
from navigation import Drive
from gamepad_input import GamepadInput
from vision import Candidate,gathering_panel_pair

FORCED={'scene_navigation_enabled':False,'analyzer_enabled':False,'ground_route_navigation':False,
 'area_search_rescue':False,'terrain_rescue_enabled':False,'patrol_escape_enabled':False,
 'no_yield_return_enabled':False,'world_map_enabled':False,'flight_probe_enabled':False,
 'calibrate_during_collection':False,'auto_view_recovery':False}

def unchanged(a,b):
 # Reject stale points after large view change; uniform views are compared by
 # absolute difference rather than a correlation with a zero denominator.
 def crop(f):
  h,w=f.shape[:2];return cv2.resize(cv2.cvtColor(f[round(.24*h):round(.8*h),round(.2*w):round(.8*w)],cv2.COLOR_BGR2GRAY),(64,36)).astype(float)
 x,y=crop(a),crop(b)
 return float(np.mean(np.abs(x-y)))<12

class AIGatherEngine(GatherEngine):
 def __init__(self,cfg,*a,**kw):
  super().__init__({**cfg,**FORCED},*a,**kw)
  self.ai=PolicyHost(self.cfg,self.say);self.ai_until=0;self.ai_active=None;self.ai_history=[];self.ai_goal='none'
  self.ai_drive=None;self.ai_settle_until=0;self.ai_inspections=0;self.ai_identity_note=-1e9
  self.ai_motion=[0.,0.];self.ai_samples=0;self.ai_last_flow=None;self.ai_last_note=0;self.ai_energy_at=-1e9;self.ai_takeoff_at=-1e9
  self.say('AI_PILOT 0.1.3: HTTP без потока; HP bootstrap; сначала сцена/ориентир, не более двух осмотров без продвижения; модель '+self.cfg.get('analyzer_model','qwen2.5vl:3b'))
 def _needs_visual_hp(self):
  if self.network is None:return True
  if not hasattr(self.network,'confirm_own_hp'):return False
  view=self._net_view()
  return bool(view and view['ready'] and view['state'].own is None)
 def _health_identity_sample(self,value,captured,verified):
  if self.network is None or not hasattr(self.network,'confirm_own_hp') or not verified or value is None or value.current>=value.maximum or not self._focus_ok() or not self._needs_visual_hp():return
  stamp=int((time.time()-time.monotonic()+captured)*1000)
  self.network.confirm_own_hp(value.current,value.maximum,stamp)
 def stop(self):
  if hasattr(self,'ai'):self.ai.close()
  super().stop()
 def _no_yield_tick(self,*a,**kw):return False
 def _return_exit_tick(self,*a,**kw):return False
 def _return_exit_scan(self,*a,**kw):return False
 def _start_terrain_recovery(self,*a,**kw):return False
 def _terrain_recovery_tick(self,*a,**kw):return False
 def _patrol_escape_tick(self,*a,**kw):return False
 def _defend_and_resume(self,*a,**kw):
  if hasattr(self,'ai'):self.ai.invalidate();self.ai_until=0;self.ai_active=None;self.ai_drive=None
  return super()._defend_and_resume(*a,**kw)
 def _map_teleport_tick(self,*a,**kw):
  trip=self.map_teleport
  if trip is not None and hasattr(self,'ai'):self.ai.invalidate();self.ai_until=0;self.ai_active=None;self.ai_drive=None
  result=super()._map_teleport_tick(*a,**kw)
  if trip is not None and trip.phase=='DONE':self.ai_inspections=0;self.ai_history=[]
  return result
 def _resource_fast_tick(self,*a,**kw):
  self._adopt_network_collection()
  if self.mode in ('SEARCH','ACQUIRE_WAIT') and not self.target_confirmed and not self.resource_hold:return False
  self.ai.invalidate();self.ai_until=0;self.ai_active=None;self.ai_drive=None;self.ai_active=None
  return super()._resource_fast_tick(*a,**kw)
 def _finish_ai_action(self,now):
  if self.ai_active is None:return
  self._neutral();self.pitch.set_working_baseline(now)
  a=self.ai_active
  self.ai_history.append({'action':a['action'],'direction':a['direction'],'resource':a['resource'],
   'reason':a['reason'],'map_net_pixels':round(math.hypot(*self.ai_motion),2) if self.ai_samples else None,
   'flow_samples':self.ai_samples,'feedback':'command lease ended; displacement is relative minimap evidence, not world meters'})
  self.ai_history[-1]['tool_result']=a.get('tool_result','observation/wait')
  self.ai_history[-1]['perception']=a.get('perception')
  if a['action']=='look':self.ai_inspections+=1
  elif a['action']=='move' and a.get('tool_result')=='input sent' and self.ai_samples and math.hypot(*self.ai_motion)>=1:self.ai_inspections=0
  self.ai_history=self.ai_history[-8:];self.ai_active=None;self.ai_drive=None;self.ai_settle_until=now+.3
 def _ai_acquire(self,a,frame,origin,now):
  if self.network is None or not self.cfg.get('allow_click',True) or a['resource'] not in self.cfg['target_names']:return False
  x=round(a['x']*frame.shape[1]/1000);y=round(a['y']*frame.shape[0]/1000)
  # Keep clicks out of fixed HUD regions; identity comes from the network.
  if y<frame.shape[0]*.12 or y>frame.shape[0]*.82 or x>frame.shape[1]*.81 and y<frame.shape[0]*.44:return False
  self._neutral();self.network_selection_after=int(time.time()*1000)
  try:
   if not self.bridge_cmd('ALT_DOWN') or not self._wait_alt_state(True):return False
   if self.gamepad.native_cursor and not self.gamepad.begin_cursor(self.stop_event,self.screen.focused):return False
   self.bridge.cursor(origin[0]+x,origin[1]+y)
   if not GamepadInput.wait(.12,self.stop_event,self.screen.focused) or not self._cursor_click_ready():return False
   self.acquisition_clicked_at=time.monotonic()
   if not self.gamepad.tap_a(self.stop_event,self.screen.focused):return False
   if not GamepadInput.wait(.35,self.stop_event,self.screen.focused):return False
   self._adopt_network_collection()
   if self._own_collection() is not None:return True
   if not self._selected_resource(self._net_view(),a['resource']):
    self.say('AI_CLICK_REJECT: сервер не подтвердил ресурс '+a['resource']+'; второй клик запрещён');return False
   c=Candidate(a['resource'],x,y,90,(max(0,x-10),max(0,y-10),20,20))
   if not self._bind_resource_candidate(c):
    self.target_confirmed=False;self.resource_hold=False;self.target=None;self.network_target=None;return False
   self.route_active=True;self.route_f_sent=True;self.native_route_started_at=time.monotonic()
   self.route_click_sent_at=time.monotonic();self.route_click_tries=1;self.change_mode('APPROACH')
   self.say('AI_CLICK: один A, ресурс подтверждён; подход/сбор передан проверенному контроллеру');return True
  finally:
   self.gamepad.release_cursor();self.bridge_cmd('ALT_UP')
 def step(self,frame,origin,obs,radar,reading,now,sequence=0):
  if self.stop_event.is_set():return
  self._adopt_network_collection()
  if self.mode not in ('SEARCH','ACQUIRE_WAIT') or self.target_confirmed or self.resource_hold:
   self.ai.invalidate();self.ai_until=0;self.ai_active=None;self.ai_drive=None;self.ai_active=None
   return super().step(frame,origin,obs,radar,reading,now,sequence)
  if self._network_guard(now):self.ai.invalidate();self.ai_active=None;self.ai_drive=None;self._neutral();return
  if not self._focus_ok():self.ai.invalidate();self.ai_until=0;self.ai_active=None;self.ai_drive=None;self._neutral();return
  self.current_size=(frame.shape[1],frame.shape[0]);self._budget_update(reading,now)
  if self._needs_visual_hp() and now-self.ai_identity_note>=10:
   self.ai_identity_note=now;hp=self.health.state();net=self._net_view();state=net['state'] if net else None
   self.say('DEFENSE_WAIT_ID: собственный ID пока не подтверждён; HP HUD='+str(hp['current'])+'/'+str(hp['maximum'])+'; сетевых HP-кандидатов='+str(len(getattr(state,'unbound_stats',{})))+'; попаданий до определения ID='+str(len(getattr(state,'unbound_hits',[])))+'; Tab/атака ждут подтверждения агрессора')
  if reading.energy is not None:self.ai_energy_at=now
  if self._map_teleport_tick(frame,reading,now) or self._network_defense_tick(now) or self._check_route_damage(frame,now):return
  if gathering_panel_pair(frame):self.ai.invalidate();self.ai_active=None;self.ai_drive=None;self._neutral();return
  if now<self.post_gather_until:self._neutral();return
  if self.ai_active is not None:
   if radar.motion_valid and self.ai_last_flow!=now:
    self.ai_motion[0]-=radar.displacement[0];self.ai_motion[1]-=radar.displacement[1];self.ai_samples+=1;self.ai_last_flow=now
   if now<self.ai_until:
    if self.ai_drive is not None and not self.cfg.get('dry_run'):
     self._motion(replace(self.ai_drive,lifetime=min(.35,self.ai_until-now)))
    return
   self._finish_ai_action(now)
  self._neutral();decision=self.ai.take()
  if decision is not None:
   if now-decision.captured>20 or decision.answer['action'] in ('move','acquire') and not unchanged(decision.frame,frame):
    self.say('AI_STALE: '+decision.answer['action']+'; возраст '+str(round(now-decision.captured,2))+' с; изменившийся вид/старый ответ')
   else:
    a=decision.answer
    if a['action'] not in available_actions(self.ai_history,{'inspections_without_progress':self.ai_inspections}):
     self.say('AI_INSPECTION_LIMIT: повторный осмотр без продвижения отклонён; новый запрос с доступными инструментами')
     self.ai.invalidate();return
    if a['action']=='look' and a['duration_ms']>800:a={**a,'duration_ms':800}
    self.ai_goal=a['resource'];self.say('AI_DECISION: '+str(a)+'; анализ '+str(round(decision.elapsed*1000))+' мс')
    if not self.cfg.get('dry_run'):
     if a['action']=='acquire':
      ok=self._ai_acquire(a,frame,origin,now)
      if ok:self.ai_inspections=0
      self.ai_history.append({'action':'acquire','resource':a['resource'],'confirmed':bool(ok)})
      self.ai_history=self.ai_history[-8:];self.ai.invalidate();return
     if a['action']=='return_map':
      self.ai.invalidate();ok=self._start_map_teleport(now)
      self.ai_history.append({'action':'return_map','started':bool(ok),'cooldown_seconds':max(0,round(self.map_return_after-now))});self.ai_history=self.ai_history[-8:];return
     if a['action']=='takeoff':
      if not reading.confirmed and not self.budget.airborne and now-self.ai_energy_at<30 and self.budget.energy is not None and self.budget.energy>=50 and now-self.ai_takeoff_at>15:
       self.ai_takeoff_at=now;a={**a,'tool_result':'V sent' if self.bridge_cmd('V') else 'V denied'}
      else:
       self.say('AI_TOOL_DENIED: взлёт не подтверждён условиями энергии/состояния');a={**a,'tool_result':'takeoff denied: energy/flight/cooldown'}
     drive=Drive(lifetime=a['duration_ms']/1000,tilted_motion=reading.confirmed)
     if a['action']=='move':
      f,s={'forward':(.55,0),'back':(-.4,0),'left':(0,-.45),'right':(0,.45),'forward_left':(.4,-.35),'forward_right':(.4,.35)}[a['direction']]
      drive.forward=f;drive.strafe=s
     elif a['action']=='look':
      if a['direction'] in ('left','right'):drive.yaw=(-.32 if a['direction']=='left' else .32)*self.cfg.get('camera_yaw_sign',1)
      else:drive.pitch=.45 if a['direction']=='up' else -.45
     if a['action'] in ('move','look'):
      sent=self._motion(replace(drive,lifetime=min(.8,drive.lifetime)))
      self.ai_drive=drive if a['action']=='move' and sent else None
      a={**a,'tool_result':'input sent' if sent else 'input denied'}
    self.ai_active=a;self.ai_until=time.monotonic()+a['duration_ms']/1000;self.ai_motion=[0.,0.];self.ai_samples=0;return
  if now<self.ai_settle_until:return
  view=self._net_view();state=view['state'] if view and view['ready'] else None
  def marker(m):
   dx,dy=m.x-radar.center[0],m.y-radar.center[1];bearing=math.degrees(math.atan2(dx,-dy))%360
   return {'kind':m.kind,'bearing':round(bearing),'camera_error_degrees':round((bearing-radar.heading+180)%360-180) if radar.heading is not None else None}
  inputs={'inspections_without_progress':self.ai_inspections,'goal':self.ai_goal,'flight_confirmed':reading.confirmed,'flight_energy':self.budget.energy,'energy_recent':now-self.ai_energy_at<30,
   'teleport_cooldown_seconds':max(0,round(self.map_return_after-now)),
   'camera_heading':radar.heading,'map_id':getattr(state,'map_id',None),
   'xyz':getattr(state,'xyz',None),'xyz_timestamp':getattr(state,'position_at',None),
   'xyz_age_seconds':round((time.time()*1000-state.position_at)/1000,2) if state is not None and state.position_at is not None else None,
   'minimap_resources':[marker(m) for m in radar.markers[:8]],
   'resource_hint':{'name':obs.candidate.name,'x':round(obs.candidate.click_x/frame.shape[1]*1000),'y':round(obs.candidate.click_y/frame.shape[0]*1000)} if obs.candidate else None,
   'detected_resource':obs.candidate.name if obs.candidate else None,'gathering':False,'goal_policy':'prefer aether, ground gems while energy recovers' if self.cfg.get('only_aether') else 'gather available resources'}
  self.ai.offer(frame.copy(),inputs,list(self.ai_history),now)
  if now-self.ai_last_note>4:self.say('AI_WAIT: ожидаю решение; стики отпущены');self.ai_last_note=now
