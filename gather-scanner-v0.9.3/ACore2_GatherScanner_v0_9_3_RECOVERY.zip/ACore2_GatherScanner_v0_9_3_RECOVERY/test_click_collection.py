"""Default direct-click backend: modeled loot, route, attempt and combat events.

No Windows/game connection: tests verify decisions and the input/event sequence.
Legacy F transport remains separately covered by GatherFixture's opt-out.
"""
import copy
import unittest
from unittest.mock import patch
import numpy as np
import gather_engine as ge
from vision import caption_candidate
from flight import FlightReading
from network_state import Node
from network_defense import NetworkDefense
from test_navigation import GatherFixture,obs
from test_network_control import Source
from test_control_regressions import caption_frame


class ClickCollection(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp()
        self.e.cfg.update(resource_click_interaction=True,defense_during_approach=False)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.selected=99;self.f.selection_time=1100;self.f.attempt_active=False;self.f.collecting=None
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='APPROACH'
        self.frame,box=caption_frame();self.e.candidate=caption_candidate(self.frame,'Сапфир',box,95)
        self.clock=100.;self.wall=1100;self.clicks=0;self.route_starts=0;self.loot=3
        self.on_click=lambda:None
        def click(*args,**kwargs):
            self.clicks+=1
            if self.f.selected==0:self.f.selected=99;self.f.selection_time=self.wall
            else:self.route_starts+=1
            self.on_click();return True
        self.input.tap_a=click
        for item in (patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),
                     patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),
                     patch.object(ge.GamepadInput,'wait',return_value=True)):
            item.start();self.addCleanup(item.stop)

    def own(self,used=0,active=True):
        self.f.collecting=99;self.f.attempt_active=active
        self.f.nodes[99].gather_time=1000;self.f.nodes[99].used=used
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True;self.e.mode='GATHER'

    def test_initial_selection_and_activation_use_same_alt_session(self):
        self.e.target=None;self.e.target_confirmed=False;self.e.network_target=None
        self.f.selected=0
        self.assertTrue(self.e.click_candidate(self.e.candidate,(0,0)))
        self.assertEqual(self.clicks,2);self.assertEqual(self.route_starts,1)
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP'])
        self.assertEqual(self.e.mode,'APPROACH');self.assertTrue(self.e.route_active)

    def test_pending_initial_click_keeps_confirmed_target_until_fresh_caption(self):
        self.e.target=None;self.e.target_confirmed=False;self.e.network_target=None
        self.f.selected=0
        with patch.object(self.e,'_fresh_click_candidate',return_value=None):
            self.assertTrue(self.e.click_candidate(self.e.candidate,(0,0)))
        self.assertTrue(self.e.target_confirmed);self.assertFalse(self.e.route_f_sent)
        self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.clicks,1)
        self.clock+=1
        self.e._approach_fast_tick(self.frame,(0,0),FlightReading(None,False),self.clock)
        self.assertEqual(self.clicks,2);self.assertTrue(self.e.route_active)

    def test_after_defense_resource_id_and_consumed_attempt_are_preserved(self):
        self.own(1,False)
        self.e.network_defense=NetworkDefense(55,1,7,99,True,'Сапфир',99)
        self.f.selected=55;self.f.collecting=None
        self.e._finish_network_defense(True)
        # Game model: first A selects the saved node, second starts its route.
        def tap(*args,**kwargs):
            self.clicks+=1
            if self.f.selected!=99:self.f.selected=99;self.f.selection_time=self.wall
            else:self.route_starts+=1
            return True
        self.input.tap_a=tap
        self.assertTrue(self.e.click_candidate(self.e.candidate,(0,0),retry=True))
        self.assertEqual(self.e.network_target,(1,99));self.assertIsNone(self.e.resume_resource_id)
        self.assertEqual(self.f.nodes[99].used,1);self.assertEqual(self.clicks,2)
        self.wall=1200;self.f.collecting=99;self.f.attempt_active=True;self.f.nodes[99].gather_time=1200
        self.e._net_resource(self.frame,FlightReading(None,False),101)
        self.assertEqual(self.clicks,2);self.assertEqual(self.e.mode,'GATHER')
        self.clock+=1;self.f.nodes[99].used=2;self.f.attempt_active=False
        self.e.f_enable();self.assertEqual(self.clicks,3)
        self.assertNotIn('TAP_F',self.commands)

    def test_actual_hit_between_attempts_prevents_next_click(self):
        self.own(1,False);self.attack()
        self.e.f_enable();self.assertEqual(self.clicks,0)
        self.assertTrue(self.e._net_defense(100))

    def test_wings_remain_open_after_first_and_second_attempt(self):
        self.own(1,False);self.e.resource_flight_owned=True
        for used in (1,2):
            self.clock+=1;self.f.nodes[99].used=used;self.f.attempt_active=False
            self.e._net_resource(self.frame,FlightReading(50,True),self.clock)
        self.assertEqual(self.clicks,2);self.assertNotIn('END_AIR',self.commands)
        self.assertNotIn('V',self.commands)

    def test_last_attempt_closes_wings_without_another_click(self):
        self.own(2,True);self.e.target='Эфир';self.e.resource_flight_owned=True
        self.f.nodes[99].used=3;self.f.attempt_active=False;self.f.collecting=None
        self.e._net_resource(self.frame,FlightReading(50,True),100)
        self.assertEqual(self.clicks,0);self.assertEqual(self.commands,['END_AIR'])
        self.assertEqual(self.e.mode,'SEARCH')

    def test_preselected_same_resource_is_activated_once_without_new_selection_event(self):
        self.e.target_confirmed=False;self.e.network_target=None;self.f.selection_time=900
        self.assertTrue(self.e.click_candidate(self.e.candidate,(0,0)))
        self.assertEqual(self.clicks,1);self.assertEqual(self.route_starts,1)
        self.assertTrue(self.e.route_active)

    def test_wrong_same_name_id_after_defense_never_gets_second_click(self):
        self.e.target_confirmed=False;self.e.network_target=None;self.f.selected=0
        self.e.resume_resource_id=(1,99)
        self.f.nodes[100]=Node(100,1550020,used=0,time=1000)
        def wrong(*args,**kwargs):
            self.clicks+=1;self.f.selected=100;self.f.selection_time=self.wall;return True
        self.input.tap_a=wrong
        def advance(seconds,*args):self.clock+=seconds;return True
        with patch.object(ge.GamepadInput,'wait',side_effect=advance):
            self.assertFalse(self.e.click_candidate(self.e.candidate,(0,0),retry=True))
        self.assertEqual(self.clicks,1);self.assertNotIn('TAP_F',self.commands)

    def test_stalled_native_approach_can_retry_click_without_v_or_f(self):
        self.e._start_resource_route();initial=self.e.native_route_started_at
        self.e.last_progress=100;self.e.distance_live=6;self.e.distance_live_at=102.2
        self.clock=102.2
        self.e._approach_fast_tick(self.frame,(0,0),FlightReading(None,False),self.clock)
        self.assertEqual(self.clicks,2);self.assertEqual(self.e.native_route_started_at,initial)
        self.assertNotIn('V',self.commands);self.assertNotIn('TAP_F',self.commands)

    def test_optional_route_retry_missing_caption_preserves_native_path(self):
        self.e._start_resource_route();self.frame[:]=0
        self.clock+=7;self.e._start_resource_route(repeat_click=True)
        self.assertEqual(self.clicks,1);self.assertEqual(self.e.mode,'APPROACH')
        self.assertTrue(self.e.route_active);self.assertIsNone(self.e.click_wait_since)

    def test_route_retry_is_bounded_before_existing_obstacle_recovery(self):
        self.e._start_resource_route()
        for i in range(8):self.clock+=2.1;self.e._start_resource_route(repeat_click=True)
        self.assertEqual(self.clicks,3);self.assertEqual(self.e.route_click_tries,3)

    def test_fresh_gather_start_cancels_optional_route_retry(self):
        self.e._start_resource_route();self.clock+=2.1;self.own()
        self.e._start_resource_route(repeat_click=True)
        self.assertEqual(self.clicks,1)

    def test_second_attacker_during_return_does_not_discard_saved_resource(self):
        self.e.network_defense=NetworkDefense(55,1,7,99,True,'Сапфир',99)
        self.e._finish_network_defense(True)
        self.assertFalse(self.e.target_confirmed);self.assertEqual(self.e.mode,'REACQUIRE')
        self.f.attacks[56]=1050;self.f.npcs[56]={'time':900}
        self.assertTrue(self.e._net_defense(100))
        self.assertEqual(self.e.network_defense.attacker,56)
        self.assertTrue(self.e.network_defense.resume)
        self.assertEqual(self.e.network_defense.resource_id,99)
        self.e._finish_network_defense(True)
        self.assertEqual(self.e.mode,'REACQUIRE');self.assertEqual(self.e.resume_resource_id,(1,99))

    def test_no_hit_during_return_does_not_trigger_more_tabs(self):
        self.e._begin_reacquire('saved resource')
        self.assertFalse(self.e._net_defense(100));self.assertEqual(self.commands,[])

    def test_ship_default_is_direct_click(self):
        from app import DEFAULT
        self.assertTrue(DEFAULT['resource_click_interaction'])

    def test_corpse_loot_cannot_steal_initial_route(self):
        self.assertTrue(self.e._start_resource_route())
        self.assertEqual((self.clicks,self.route_starts,self.loot),(1,1,3))
        self.assertNotIn('TAP_F',self.commands);self.assertNotIn('F_ON',self.commands)
        self.assertFalse(self.alt_held)

    def test_no_second_activation_during_long_approach(self):
        self.e._start_resource_route()
        for i in range(50):
            self.clock+=.2;self.e._start_resource_route()
        self.assertEqual(self.clicks,1)

    def test_active_gather_sends_no_click(self):
        self.own()
        for i in range(50):self.e.f_enable()
        self.assertEqual(self.clicks,0);self.assertEqual(self.commands,[])

    def test_three_attempts_with_loot_use_two_clicks_and_no_f(self):
        self.own()
        self.e.f_enable();self.assertEqual(self.clicks,0)
        for used in (1,2):
            self.clock+=1;self.f.nodes[99].used=used;self.f.attempt_active=False
            for i in range(20):self.e.f_enable()
            self.assertEqual(self.clicks,used)
            self.f.attempt_active=True;self.e.f_enable()
        self.f.nodes[99].used=3;self.f.attempt_active=False;self.e.f_enable()
        self.assertEqual((self.clicks,self.route_starts,self.loot),(2,2,3))
        self.assertFalse({'TAP_F','F_ON'}&set(self.commands))

    def test_selection_clear_gets_select_then_activate_same_id(self):
        self.own(1,False);self.f.selected=0
        self.e.f_enable()
        self.assertEqual(self.clicks,2);self.assertEqual(self.route_starts,1)
        self.assertEqual(self.e.next_attempt_sent_used,1)

    def test_own_start_during_selection_does_not_get_another_click(self):
        self.own(1,False);self.f.selected=0
        self.on_click=lambda:setattr(self.f,'attempt_active',True)
        self.e.f_enable();self.assertEqual(self.clicks,1)

    def test_same_name_neighbor_selected_instead_does_not_get_activation(self):
        self.own(1,False);self.f.selected=0
        self.f.nodes[100]=copy.deepcopy(self.f.nodes[99]);self.f.nodes[100].actor=100
        self.on_click=lambda:setattr(self.f,'selected',100)
        self.e.f_enable();self.assertEqual(self.clicks,1)
        self.assertIsNone(self.e.next_attempt_sent_used)

    def test_foreign_target_blocks_click(self):
        self.own(1,False);self.f.selected=55;self.e.f_enable()
        self.assertEqual(self.clicks,0);self.assertEqual(self.commands,[])

    def test_resource_disappears_before_press_blocks_click(self):
        def move_cursor(x,y):self.f.nodes[99].visible=False
        self.e.bridge.cursor=move_cursor
        self.assertFalse(self.e._start_resource_route());self.assertEqual(self.clicks,0)

    def test_own_start_while_alt_is_being_sent_blocks_activation(self):
        send=self.e.bridge.send
        def command(c):
            result=send(c)
            if c=='ALT_DOWN':self.f.attempt_active=True;self.f.nodes[99].gather_time=1100;self.f.collecting=99
            return result
        self.e.bridge.send=command
        self.assertFalse(self.e._start_resource_route());self.assertEqual(self.clicks,0)
        self.assertFalse(self.alt_held)

    def test_flow_changes_before_press_blocks_click(self):
        self.e.bridge.cursor=lambda x,y:setattr(self.source,'ready',False)
        self.assertFalse(self.e._start_resource_route());self.assertEqual(self.clicks,0)
        self.assertFalse(self.alt_held)

    def test_no_stale_coordinate_click_when_caption_is_gone(self):
        self.frame[:]=0
        with patch.object(ge,'find_world_resource',side_effect=AssertionError('No synchronous OCR')):
            self.assertFalse(self.e._start_resource_route())
        self.assertEqual(self.clicks,0);self.assertFalse(self.e.route_f_sent)

    def test_background_caption_can_replace_old_local_position(self):
        self.e.candidate=None
        frame,box=caption_frame();self.e.snapshot=(obs(candidate=caption_candidate(frame,'Сапфир',box,95)),100,1,100)
        self.assertTrue(self.e._start_resource_route());self.assertEqual(self.clicks,1)

    def test_stale_background_caption_cannot_authorize_click(self):
        self.e.candidate=None;frame,box=caption_frame()
        self.e.snapshot=(obs(candidate=caption_candidate(frame,'Сапфир',box,95)),90,1,90)
        self.assertFalse(self.e._start_resource_route());self.assertEqual(self.clicks,0)

    def test_actual_successful_hitbox_offset_is_retained(self):
        from dataclasses import replace
        old=self.e.candidate;self.e.candidate=replace(old,click_y=old.click_y+11)
        self.e._start_resource_route()
        self.assertAlmostEqual(self.positions[-1][1],old.click_y+11,delta=2)

    def test_camera_calibration_defers_click_without_consuming_attempt_token(self):
        self.own(1,False);self.e.camera_in_progress=True;self.e.f_enable()
        self.assertEqual(self.clicks,0);self.assertIsNone(self.e.next_attempt_sent_used)
        self.e.camera_in_progress=False;self.e.f_enable();self.assertEqual(self.clicks,1)

    def test_click_failure_cannot_replay_an_uncertain_activation(self):
        def cancelled(*args,**kwargs):self.clicks+=1;return False
        self.input.tap_a=cancelled
        self.assertFalse(self.e._start_resource_route())
        self.assertTrue(self.e.stop_event.is_set());self.assertTrue(self.e.route_f_sent)
        self.assertFalse(self.e._start_resource_route());self.assertEqual(self.clicks,1)

    def test_missing_caption_enters_bounded_reacquisition_with_exact_id(self):
        self.frame[:]=0
        self.e._start_resource_route();self.clock+=7;self.e._start_resource_route()
        self.assertEqual(self.e.mode,'REACQUIRE');self.assertEqual(self.e.resume_resource_id,(1,99))
        self.assertEqual(self.clicks,0)

    def test_wing_restart_is_once_after_confirmed_flight(self):
        self.e._start_resource_route();self.clock+=1
        self.e.mode='TAKEOFF';self.e.wing_route_restart_pending=True;self.e.route_active=False
        with patch.object(ge,'read_flight',return_value=FlightReading(50,True)):
            self.assertTrue(self.e._start_resource_route(restart_after_wings=True))
            self.assertFalse(self.e._start_resource_route(restart_after_wings=True))
        self.assertEqual(self.clicks,2);self.assertNotIn('TAP_F',self.commands)

    def test_own_gather_prohibits_wing_route_restart(self):
        self.own();self.e.wing_route_restart_pending=True
        self.e._start_resource_route(restart_after_wings=True)
        self.assertEqual(self.clicks,0)

    def test_default_backend_rejects_accidental_legacy_f(self):
        self.e.route_f_pending=True
        self.assertFalse(self.e.bridge_cmd('TAP_F'))
        self.e.real_gather_panel_seen=True
        self.assertFalse(self.e.bridge_cmd('F_ON'));self.assertEqual(self.commands,[])

    def attack(self):
        self.f.attacks[55]=1050;self.f.npcs[55]={'time':900}

    def test_distant_harmless_hit_keeps_resource_route(self):
        self.attack();self.e.distance_live=25;self.e.distance_live_at=self.clock
        self.assertFalse(self.e._net_defense(self.clock));self.assertEqual(self.e.mode,'APPROACH')
        self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.commands,[])

    def test_arrival_checks_aggressor_even_after_hp_regenerated(self):
        self.attack();self.f.hp=self.f.maximum=18431
        self.e.distance_live=8;self.e.distance_live_at=self.clock
        self.assertTrue(self.e._net_defense(self.clock));self.assertEqual(self.e.mode,'DEFENSE')
        self.assertEqual(self.e.network_defense.resource_id,99)

    def test_unknown_distance_grace_is_bounded(self):
        self.attack();self.e.native_route_started_at=99
        self.assertFalse(self.e._net_defense(100))
        self.clock=103
        self.assertTrue(self.e._net_defense(103))

    def test_recent_hit_before_first_gather_is_not_discarded(self):
        self.attack();self.own()
        self.assertTrue(self.e._net_defense(self.clock));self.assertEqual(self.e.network_defense.attacker,55)

    def test_no_damage_never_tabs_just_because_mobs_exist(self):
        self.f.npcs[55]={'time':900};self.own()
        self.assertFalse(self.e._net_defense(self.clock));self.assertEqual(self.commands,[])

    def test_dead_attacker_does_not_cancel_approach_at_arrival(self):
        self.attack();self.f.deaths[55]=1090
        self.e.distance_live=6;self.e.distance_live_at=100
        self.assertFalse(self.e._net_defense(100))

    def test_defense_finish_pins_original_actor_not_same_name_neighbor(self):
        self.e.network_defense=NetworkDefense(55,1,7,99,True,'Сапфир',99)
        self.e._finish_network_defense(True)
        self.assertEqual(self.e.mode,'REACQUIRE');self.assertEqual(self.e.resume_resource_id,(1,99))
        self.f.nodes[100]=Node(100,1550020,used=0,time=1000);self.f.selected=100
        self.assertFalse(self.e._selected_resource(self.source.view(),'Сапфир'))
        self.f.selected=99
        self.assertTrue(self.e._selected_resource(self.source.view(),'Сапфир'))

    def test_mob_can_be_targeting_own_spirit_when_real_hit_arrives(self):
        self.attack();self.f.npcs[55]['target']=500;self.own()
        self.assertTrue(self.e._net_defense(100))

    def test_inactive_next_attempt_retries_safe_click_before_explicit_failure(self):
        self.own(1,False)
        for i in range(3):
            self.e.f_enable();self.clock+=2.1
        self.assertEqual(self.clicks,3);self.assertFalse(self.e.stop_event.is_set())
        self.clock+=2
        self.e._net_resource(self.frame,FlightReading(50,True),self.clock)
        self.assertTrue(self.e.stop_event.is_set());self.assertIn('трёх кликов',self.e.halt_reason)

    def test_retry_click_is_allowed_while_native_route_is_still_running(self):
        self.own(1,False);self.e.route_active=True
        self.e.f_enable();self.clock+=2.1;self.e.f_enable()
        self.assertEqual(self.clicks,2);self.assertNotIn('TAP_F',self.commands)

    def test_start_of_attempt_revokes_retry_click_even_after_timeout(self):
        self.own(1,False);self.e.f_enable();self.clock+=2.1
        self.f.attempt_active=True;self.e.f_enable()
        self.assertEqual(self.clicks,1);self.assertIsNone(self.e.next_attempt_wait_at)

    def test_new_attempt_count_gets_its_own_retry_budget(self):
        self.own(1,False)
        for i in range(3):self.e.f_enable();self.clock+=2.1
        self.f.nodes[99].used=2;self.e.f_enable()
        self.assertEqual(self.e.next_attempt_click_tries,1);self.assertEqual(self.clicks,4)

    def test_mode_lag_cannot_defer_hit_after_actual_gather_start(self):
        self.attack();self.f.collecting=99;self.f.attempt_active=True
        self.e.distance_live=25;self.e.distance_live_at=100
        self.assertTrue(self.e._net_defense(100))


if __name__=='__main__':unittest.main()
