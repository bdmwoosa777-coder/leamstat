"""Multi-frame camera/scene coordination with the real freshness contract."""
import math,unittest
from dataclasses import replace
from types import SimpleNamespace
from unittest.mock import patch
import gather_engine as ge,hybrid_engine as he
import test_camp_departure as old
from camp_departure import CampDeparture
from navigation import Drive
from scene_navigation import SceneHost
from hybrid_navigation import RouteAction
from ground_routes import GroundMap
from test_hybrid import scene,route
from test_navigation import radar
from test_patrol import GROUND

class DelayedScene(SceneHost):
 def __init__(self,delay=.65,available=100,cliff=False):
  super().__init__({});self.delay=delay;self.available=available;self.cliff=cliff
  self.job=None;self.accepted=0
 def offer(self,frame,now,heading,pitch,revision=0):
  if self.job is not None and self.job[0]<=now:self.latest=self.job[1];self.job=None
  if self.job is None and now>=self.available:
   self.sequence+=1;s=scene(t=now,free=.95)
   if self.cliff:s=replace(s,ground=GroundMap(drop_support=.15))
   self.job=(now+self.delay,replace(s,heading=heading,pitch=pitch,revision=revision,sequence=self.sequence))
 def current(self,*a):
  s=super().current(*a)
  if s is not None:self.accepted+=1
  return s

class StableCamera(unittest.TestCase):
 def camp(self,bearing=236):
  c=CampDeparture((90,100),(100,100),313,100);c.bearing=bearing;return c
 def test_large_turn_keeps_its_direction_without_a_scene(self):
  c=self.camp();turns=[]
  for i,heading in enumerate((162,182,202)):
   d=c.view_plan(heading,False,100+i*.85);turns.append(d.yaw)
  self.assertTrue(all(t>0 for t in turns))
  self.assertEqual(c.view_plan(222,False,102.55).yaw,0)
 def test_camera_hysteresis_finishes_turn_before_holding_stable(self):
  c=self.camp(90);self.assertGreater(c.view_plan(40,True,100).yaw,0)
  self.assertGreater(c.view_plan(60,True,100.85).yaw,0)
  self.assertIsNone(c.view_plan(70,True,101.7))
 def test_pulse_is_followed_by_stable_capture_window(self):
  c=self.camp();c.camera_pulse(100,.42,.16)
  for t in (100.05,100.15,100.25):self.assertEqual(c.view_plan(236,False,t).yaw,0)
 def test_aligned_missing_scene_does_not_start_a_reverse_survey(self):
  c=self.camp();self.assertEqual(c.view_plan(210,False,100).yaw,0)
  self.assertEqual(c.view_plan(210,False,100.85).yaw,0)
 def test_wait_is_finite_but_does_not_rotate_on_every_tick(self):
  c=self.camp();values=[c.view_plan(236,False,100+i*.4).yaw for i in range(12)]
  self.assertEqual(sum(abs(x)>.01 for x in values),1)
 def test_fresh_scene_immediately_ends_the_wait(self):
  c=self.camp();c.view_plan(236,False,100)
  self.assertIsNone(c.view_plan(236,True,100.6))
 def test_yaw_sign_is_respected_for_facing_and_survey(self):
  self.assertLess(self.camp().view_plan(162,False,100,-1).yaw,0)
  c=self.camp();c.view_plan(236,False,100,-1)
  self.assertLess(c.view_plan(236,False,103,-1).yaw,0)
 def test_replanning_does_not_renew_the_camp_recovery_grace(self):
  c=self.camp();c.replan(135);c.replan(170)
  self.assertEqual(c.started,100);self.assertEqual(c.leg,3)

class SceneCooperation(unittest.TestCase):
 def setUp(self):
  self.f=old.DepartureControl('test_existing_map_ether_does_not_prevent_initial_departure')
  self.f.setUp();self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
  self.f.start();self.e=self.f.e
 def plan(self,now=100,heading=90):
  with patch.object(he.time,'monotonic',return_value=now):return self.e._scene_plan(self.f.frame,radar(heading=heading),GROUND,Drive(.78),now)
 def test_post_turn_scene_must_have_been_captured_after_settling(self):
  self.e.camp_route.view_after=100.2
  self.e.scene_host.current=lambda *a:scene(t=100.1,free=.95)
  d=self.plan(100.3);self.assertEqual((d.forward,d.strafe,d.yaw),(0,0,0))
 def test_revision_change_still_revokes_otherwise_fresh_scene(self):
  h=SceneHost({});h.latest=scene(t=100,free=.95)
  self.assertIsNone(h.current(100.2,90,0,1))
 def test_initial_facing_does_not_delegate_to_opposite_missing_frame_survey(self):
  self.e.camp_route.bearing=236;self.e.scene_host.current=lambda *a:None
  for i,heading in enumerate((162,182,202)):
   with patch.object(self.e.hybrid,'choose',side_effect=AssertionError('missing frame survey')):
    d=self.plan(100+i*.85,heading);self.assertGreater(d.yaw,0)
 def test_detour_uses_translation_without_invalidating_following_scene(self):
  self.e.scene_host.current=lambda *a:scene([route(0,.2)],free=.5)
  d=self.plan();self.assertLess(d.strafe,-.5);self.assertEqual(d.yaw,0)
 def test_resource_callback_pauses_exit_without_declaring_it_complete(self):
  with patch.object(he.time,'monotonic',return_value=100):self.e._candidate_observed(self.f.c,100,0)
  self.assertIsNotNone(self.e.caption_latch);self.assertTrue(self.e.hybrid_camp_pending)
  self.assertIsNotNone(self.e.camp_route);self.assertEqual(self.e.camp_exit_until,135)
 def test_old_no_yield_return_cannot_preempt_new_exit(self):
  with patch.object(ge.GatherEngine,'_start_return') as old_return:
   self.assertFalse(self.e._start_return(self.f.frame,GROUND,101,{}))
  old_return.assert_not_called();self.assertTrue(self.e.hybrid_camp_pending)
 def test_terrain_timeout_cannot_replace_exit_with_generic_back_and_forth(self):
  with patch.object(ge.GatherEngine,'_start_terrain_recovery') as recover:
   self.assertFalse(self.e._start_terrain_recovery(101,GROUND))
  recover.assert_not_called();self.assertFalse(self.e._no_yield_rescue_allowed(101))
 def test_proven_short_wall_escape_is_still_allowed_during_grace(self):
  self.e.hybrid.wall_flight_proven_until=102
  with patch.object(ge.GatherEngine,'_start_terrain_recovery',return_value=True) as recover:
   self.assertTrue(self.e._start_terrain_recovery(101,GROUND,short=True))
  recover.assert_called_once_with(101,GROUND,force_ground=False,short=True)
 def test_recovery_grace_expires_and_does_not_fake_collection_results(self):
  initial=(self.e.no_yield.idle,self.e.no_yield.result_stamp)
  self.e.camp_route.replan(180)
  with patch.object(ge.GatherEngine,'_start_return',return_value=True) as old_return:
   self.assertTrue(self.e._start_return(self.f.frame,GROUND,190,{}))
  old_return.assert_called_once();self.assertEqual((self.e.no_yield.idle,self.e.no_yield.result_stamp),initial)
 def test_exact_bridge_is_not_given_a_generic_camp_grace(self):
  self.e.return_exit_guard=True
  self.assertFalse(self.e._camp_departure_owns_recovery(101))
 def test_camera_wait_remains_subordinate_to_verified_collection(self):
  self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
  d=self.plan();self.assertEqual(d.forward,.78)
 def simulate(self,replanned=False,delay=.65,available=100,cliff=False):
  self.e.camp_route.bearing=236;self.e.camp_exit_until=200
  if replanned:self.e.camp_route.replan(100);self.e.camp_exit_until=200
  host=DelayedScene(delay,available,cliff);self.e.scene_host=host;heading=162.;records=[]
  for n in range(32):
   now=100+n*.85;d=self.plan(now,heading)
   if d is None:continue
   if abs(d.yaw)>.001:
    seconds=d.yaw_lifetime or d.lifetime
    self.e.gamepad.yaw_deadline=now+seconds
    with patch.object(he.time,'monotonic',return_value=now):self.e._audit_pad_motion(d.forward,d.strafe,d.yaw,d.pitch,d.lifetime)
    heading=(heading+d.yaw*seconds*180)%360
   records.append((now-100,d))
  return host,records
 def test_multiframe_turn_then_stable_capture_then_sustained_ground_movement(self):
  host,records=self.simulate();moving=[t for t,d in records if math.hypot(d.forward,d.strafe)>.2]
  self.assertGreaterEqual(len(moving),25);self.assertLessEqual(moving[0],4)
  self.assertFalse(any(d.yaw<-.01 for t,d in records));self.assertGreater(host.accepted,20)
 def test_replanned_exit_does_not_reproduce_thirty_two_consecutive_yaw_frames(self):
  host,records=self.simulate(replanned=True)
  self.assertGreaterEqual(sum(math.hypot(d.forward,d.strafe)>.2 for t,d in records),25)
  self.assertLess(sum(abs(d.yaw)>.01 for t,d in records),6);self.assertGreater(host.accepted,20)
 def test_very_slow_scene_does_not_get_a_looser_age_limit_or_blind_translation(self):
  host,records=self.simulate(delay=1.1)
  self.assertEqual(host.accepted,0)
  self.assertFalse(any(math.hypot(d.forward,d.strafe)>.01 for t,d in records))
  self.assertLess(sum(abs(d.yaw)>.01 for t,d in records),14)
 def test_worker_recovering_after_six_seconds_releases_wait_without_restart(self):
  host,records=self.simulate(available=106)
  moving=[t for t,d in records if math.hypot(d.forward,d.strafe)>.2]
  self.assertTrue(moving);self.assertLess(moving[0],9);self.assertGreater(host.accepted,15)
 def test_fresh_cliff_does_not_become_permission_to_leave_camp_blindly(self):
  _,records=self.simulate(cliff=True)
  self.assertFalse(any(math.hypot(d.forward,d.strafe)>.01 for t,d in records))
 def test_measured_fall_can_still_start_recovery_during_camp_grace(self):
  with patch.object(self.e.working_area,'rapid_drop',return_value=True),patch.object(ge.GatherEngine,'_start_terrain_recovery',return_value=True) as recover:
   self.assertTrue(self.e._start_terrain_recovery(101,GROUND))
  recover.assert_called_once_with(101,GROUND,force_ground=False,short=False)
