"""Delivered stick continuity, caption handoff and bounded local service startup."""
import io,tempfile,threading,unittest,urllib.error
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch,Mock
from dataclasses import replace
import numpy as np
import gamepad_input
import hybrid_engine
import ollama_service
from gamepad_input import GamepadInput
from hybrid_engine import HybridGatherEngine
from navigation import Drive
from terrain_recovery import TerrainRecovery
from flight import FlightReading
from test_navigation import Pad,GatherFixture,obs,radar
from test_network_control import Source
from test_ether_emblem import scene,ether

AIR=FlightReading(80,True)

class SmoothReports(unittest.TestCase):
 def setUp(self):
  self.clock=100.;self.pad=Pad();self.control=GamepadInput(factory=lambda:self.pad,a_button=0x1000)
  self.control.motion_worker=object() # Drive watchdog deterministically at frame boundaries.
  self.control.translation_lease_floor=.75
  self.time_patch=patch.object(gamepad_input.time,'monotonic',side_effect=lambda:self.clock);self.time_patch.start()
  self.addCleanup(self.time_patch.stop);self.addCleanup(self.control.close)
 def tick(self,seconds):
  self.clock+=seconds
  with self.control.lock:self.control._expire_motion(self.clock)
 def test_half_second_frame_gaps_do_not_release_walk_but_camera_pulse_ends(self):
  for _ in range(8):
   self.control.drive(.7,.2,.3,.45,lifetime=.06,yaw_lifetime=.03)
   self.tick(.04);self.assertEqual(self.pad.axes,(.2,.7,0,.45))
   self.tick(.46);self.assertEqual(self.pad.axes,(.2,.7,0,0))
   self.assertEqual(self.control.current_translation(),(.7,.2))
  self.tick(.26);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_zero_drive_and_reset_revoke_extended_walk_immediately(self):
  for reset in (lambda:self.control.drive(),self.control.reset):
   self.control.drive(.7,lifetime=.24);self.tick(.1);reset()
   self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.control.current_translation(),(0,0))
 def test_focus_or_collection_gate_failure_revokes_the_existing_walk(self):
  self.control.drive(.7,lifetime=.24);self.control.translation_gate=lambda:False
  self.assertFalse(self.control.drive(.7,lifetime=.24));self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_camera_gate_failure_revokes_translation_too(self):
  self.control.drive(.7);self.control.camera_gate=lambda:False
  self.assertFalse(self.control.drive(.7,0,0,.45));self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_cursor_chord_never_inherits_extended_walking(self):
  self.control.native_cursor=True;self.control.drive(.7)
  with patch.object(self.control,'wait',return_value=True):
   self.assertTrue(self.control.begin_cursor(threading.Event(),lambda:True))
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.lt,1.)
  self.tick(2.1);self.assertEqual(self.pad.lt,0);self.assertEqual(self.pad.buttons,0)
 def test_config_cannot_extend_walk_above_transport_ceiling(self):
  self.control.translation_lease_floor=100;self.control.drive(.7,lifetime=.24)
  self.tick(.81);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_camera_only_does_not_get_the_walking_extension(self):
  self.control.drive(pitch=.45,lifetime=.06);self.tick(.07)
  self.assertEqual(self.pad.axes,(0,0,0,0))

class CaptionHandoff(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();bridge=self.e.bridge;screen=self.e.screen
  cfg={**self.e.cfg,'hybrid_camp_exit':False,'auto_view_recovery':False,'analyzer_enabled':False}
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=HybridGatherEngine(cfg,self.log.append,self.input,network=self.source)
  self.e.bridge=bridge;self.e.screen=screen;self.e.mode='SEARCH';self.e.target=None
  self.clock=100.;self.patch=patch.object(hybrid_engine.time,'monotonic',side_effect=lambda:self.clock);self.patch.start();self.addCleanup(self.patch.stop)
  self.input.motion_worker=object();self.c=replace(self.c,name='Эфир')
 def latch(self,pose=0):self.e._candidate_observed(self.c,self.clock,pose)
 def test_recognition_stops_motion_before_next_navigation_frame(self):
  self.input.drive(.7,0,0,.45,lifetime=.3);self.clock+=.03;self.latch()
  self.assertIsNotNone(self.e.caption_latch);self.assertEqual(self.pad.axes,(0,0,0,0))
  self.e._motion(Drive(.7,0,.4));self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.presses,0)
 def test_stale_frame_does_not_stop_search_or_press_a(self):
  self.input.drive(.7);self.e._candidate_observed(self.c,self.clock-1,0)
  self.assertIsNone(self.e.caption_latch);self.assertEqual(self.pad.axes[1],.7);self.assertEqual(self.pad.presses,0)
 def test_own_collection_blocks_caption_and_caption_pauses_pending_exit(self):
  self.source.state.attempt_active=True;self.latch();self.assertIsNone(self.e.caption_latch)
  self.source.state.attempt_active=False;self.e.hybrid_camp_pending=True;self.latch();self.assertIsNotNone(self.e.caption_latch);self.assertTrue(self.e.hybrid_camp_pending)
 def test_small_camera_return_is_bounded_and_old_click_point_is_never_used(self):
  self.e.pitch.balance=.15;self.latch(0)
  ob,waiting=self.e._caption_frame(self.frame,obs(),self.clock)
  self.assertTrue(waiting);self.assertLessEqual(self.input.camera_deadline-self.clock,.12+.0001)
  self.assertLess(self.pad.axes[3],0);self.assertEqual(self.pad.presses,0)
 def test_missing_current_glyph_cannot_authorize_click_and_wait_is_finite(self):
  self.latch()
  with patch.object(hybrid_engine,'find_resource_near',return_value=None):
   _,waiting=self.e._caption_frame(self.frame,obs(),self.clock);self.assertTrue(waiting)
   self.clock+=2.6;_,waiting=self.e._caption_frame(self.frame,obs(),self.clock)
   self.assertFalse(waiting);self.assertIsNone(self.e.caption_latch);self.assertEqual(self.pad.presses,0)
   self.latch();self.assertIsNone(self.e.caption_latch) # Give navigation a chance before another latch.
 def test_real_visible_ether_is_reanchored_then_passed_to_native_acquisition(self):
  self.frame=scene(scale=.6);self.c=ether(self.frame);self.latch()
  ob,waiting=self.e._caption_frame(self.frame,obs(),self.clock)
  self.assertFalse(waiting);self.assertEqual(ob.candidate.name,'Эфир');self.assertIsNotNone(ob.candidate.emblem)
  self.e.step(self.frame,(0,0),ob,radar(),FlightReading(None,False),self.clock,1)
  self.assertEqual(self.e.mode,'ACQUIRE_WAIT');self.assertEqual(self.pad.axes,(0,0,0,0))
  self.clock+=.3
  with patch.object(self.e,'click_candidate',return_value=True) as click:
   self.e.step(self.frame,(0,0),ob,radar(),FlightReading(None,False),self.clock,2)
   self.assertEqual(click.call_count,1);self.assertIsNotNone(click.call_args.args[0].emblem)
 def test_selected_resource_clears_latch_without_extra_a(self):
  self.latch();self.e.target_confirmed=True
  _,waiting=self.e._caption_frame(self.frame,obs(),self.clock)
  self.assertFalse(waiting);self.assertIsNone(self.e.caption_latch);self.assertEqual(self.pad.presses,0)
 def test_visible_ether_over_sky_has_priority_over_ground_view_repair(self):
  self.e.cfg['auto_view_recovery']=True;self.latch()
  self.e.view_guard=SimpleNamespace(active=True,update=Mock(side_effect=AssertionError('looked away from Ether')))
  with patch.object(hybrid_engine,'find_resource_near',return_value=self.c):
   self.e.step(self.frame,(0,0),obs(),radar(),FlightReading(None,False),self.clock,1)
  self.assertEqual(self.e.mode,'ACQUIRE_WAIT');self.e.view_guard.update.assert_not_called()
 def test_visible_ether_defers_queued_calibration_without_clearing_its_request(self):
  self.e.camera_scheduler_active=True;self.e.camera_alignment_due='after previous resource';self.latch()
  with patch.object(hybrid_engine,'find_resource_near',return_value=self.c),patch.object(self.e,'_calibrate_camera',side_effect=AssertionError('calibration before Ether')):
   self.e.step(self.frame,(0,0),obs(),radar(),FlightReading(None,False),self.clock,1)
  self.assertEqual(self.e.mode,'ACQUIRE_WAIT');self.assertIsNotNone(self.e.camera_alignment_due)
 def test_airborne_caption_ends_cruise_without_folding_wings(self):
  self.e.mode='RESCUE';self.e.terrain_recovery=TerrainRecovery(90,80)
  self.e.terrain_recovery.phase='CRUISE';self.latch()
  self.assertFalse(self.e._terrain_recovery_tick(self.frame,AIR,self.clock,radar()))
  self.assertIsNone(self.e.terrain_recovery);self.assertEqual(self.e.mode,'SEARCH');self.assertEqual(self.commands,[])

class RecoveryReference(unittest.TestCase):
 def test_cruise_direction_is_not_chased_around_a_nearby_minimap_marker(self):
  r=TerrainRecovery(0,80);r.phase='CRUISE'
  first=r.step(.1,AIR,0,0,90).drive
  second=r.step(.5,AIR,0,0,270).drive
  self.assertEqual(first,second);self.assertGreater(second.strafe,0)
 def test_unmoved_camera_has_finite_homing_and_explicit_failure(self):
  r=TerrainRecovery(0,80);r.homed=True;r.phase='LEVEL'
  self.assertGreater(r.step(0,AIR,-.9).drive.pitch,0)
  a=r.step(6.1,AIR,-.9);self.assertTrue(a.done);self.assertTrue(a.camera_failed);self.assertFalse(a.levelled)
 def test_another_recovery_cycle_discards_the_old_top_reference(self):
  r=TerrainRecovery(0,80);r.level_top=.4;r.level_top_at=1;r.level_start=.2;r.phase='RISE'
  r.to('LEVEL',10);self.assertIsNone(r.level_top);self.assertIsNone(r.level_start)

class ServiceStartup(unittest.TestCase):
 def test_refused_is_distinct_from_timeout_and_bad_model_json(self):
  self.assertTrue(ollama_service.refused(urllib.error.URLError(ConnectionRefusedError())))
  self.assertFalse(ollama_service.refused(TimeoutError()));self.assertFalse(ollama_service.refused(ValueError('JSON')))
 def test_installed_service_start_is_rate_limited_and_never_installs_or_downloads(self):
  with tempfile.TemporaryDirectory() as tmp:
   service=ollama_service.OllamaService(tmp,lambda _:None);service.windows=True
   process=SimpleNamespace(stderr=io.BytesIO(b'local server log'),poll=lambda:None)
   with patch.object(ollama_service.shutil,'which',return_value='ollama.exe'),patch.object(ollama_service.subprocess,'Popen',return_value=process) as start:
    self.assertTrue(service.ensure(ConnectionRefusedError()))
    self.assertFalse(service.ensure(ConnectionRefusedError()))
    service.next_start=0;self.assertFalse(service.ensure(ConnectionRefusedError()))
    self.assertEqual(start.call_count,1);self.assertEqual(start.call_args.args[0],['ollama.exe','serve'])
    self.assertEqual(start.call_args.kwargs['env']['OLLAMA_HOST'],'127.0.0.1:11434')
 def test_model_error_does_not_launch_any_process(self):
  service=ollama_service.OllamaService('.',lambda _:None);service.windows=True
  with patch.object(ollama_service.subprocess,'Popen') as start:
   self.assertFalse(service.ensure(ValueError('empty model reply')));start.assert_not_called()

if __name__=='__main__':unittest.main()
