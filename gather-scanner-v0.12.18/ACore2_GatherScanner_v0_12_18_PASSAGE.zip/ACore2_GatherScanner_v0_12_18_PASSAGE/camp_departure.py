"""Persistent landmark-relative departure; minimap resources are not exit proof."""
import math
from minimap import angle_delta
from navigation import Drive

class CampDeparture:
 def __init__(self,anchor,center,width,now):
  self.anchor=anchor;self.width=width;self.scale=max(.5,width/313)
  self.initial=math.dist(anchor,center)/self.scale;self.distance=self.initial
  self.started=now;self.seen=now;self.until=now+35;self.leg=1;self.failed=[]
  self.view_after=-1e9;self.view_wait=None;self.turning=False
  self.bearing=self.away(anchor,center) if self.initial>=6 else None
  self.origin='от кибелиска' if self.bearing is not None else ''
 @staticmethod
 def away(anchor,center):return math.degrees(math.atan2(center[0]-anchor[0],anchor[1]-center[1]))%360
 def observe(self,anchor,center,now):
  if anchor is None:return False
  self.anchor=anchor;self.seen=now;self.distance=math.dist(anchor,center)/self.scale
  return self.distance>=max(45,self.initial+18)
 def replan(self,now):
  if self.bearing is not None:self.failed.append((self.bearing,now+45))
  self.failed=[f for f in self.failed if now<f[1]]
  self.bearing=None;self.origin='';self.until=now+35;self.leg+=1;self.turning=False
 def choose(self,heading,ground,now):
  if self.bearing is not None or heading is None or ground is None or ground.drop_support>=.04:return self.bearing
  from hybrid_navigation import route_angle
  options=[r for r in ground.routes if r.confidence>=.40 and r.clearance>=.5
           and not any(abs(angle_delta(heading+route_angle(r),b))<22 for b,t in self.failed if now<t)]
  if not options:return None
  route=max(options,key=lambda r:r.score+.20*r.clearance-.003*abs(route_angle(r)))
  self.bearing=(heading+route_angle(route))%360;self.origin='по видимому проходу'
  return self.bearing

 def camera_pulse(self,now,yaw,seconds=.18,reason='выход: один поворот, затем проверка неподвижного обзора'):
  self.view_after=now+seconds+.12;self.view_wait=self.view_after
  return Drive(yaw=yaw,lifetime=.35,yaw_lifetime=seconds,reason=reason)
 def view_plan(self,heading,fresh,now,yaw_sign=1):
  # Turning invalidates the scene revision. Do not counter-turn on a missing
  # scene: leave a stable capture window before any further survey pulse.
  if now<self.view_after:return Drive(reason='выход: стабилизирую обзор после поворота')
  if self.bearing is not None and heading is not None:
   error=angle_delta(self.bearing,heading)
   self.turning=abs(error)>40 or self.turning and abs(error)>22
   if self.turning:
    return self.camera_pulse(now,(.62 if error>0 else -.62)*yaw_sign,
                             reason='выход: поворачиваю к выбранному проходу без встречного осмотра')
  self.turning=False
  if fresh:self.view_wait=None;return None
  if self.view_wait is None:self.view_wait=now
  if now-self.view_wait>=2.4:
   # An unavailable worker never causes endless immediate rotation or an
   # unbounded wait. One small view change starts another stable window.
   return self.camera_pulse(now,.38*yaw_sign,.12,'выход: кадр не пришёл; один новый ракурс, затем стабилизация')
  return Drive(reason='выход: жду свежий кадр при неподвижной камере')
