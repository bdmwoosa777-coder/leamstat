"""Fast navigation loop with independent OCR, heartbeat and dialog watchers."""
from pathlib import Path
from dataclasses import replace
import threading
import time
import traceback
import math
import cv2
import numpy as np
from bridge import GHubBridge
from gamepad_input import GamepadInput,TranslationKeeper
from screen_capture import ScreenCapture
from minimap import MinimapVision
from navigation import Navigator,Drive
from camera_pitch import PitchLedger
from camera_control import PITCH_STRENGTH
from camera_working_view import working_view_ms
from flight_probe import FlightProbe
from patrol_escape import PatrolStall,PatrolEscape
from terrain_recovery import RecoveryWatch,TerrainRecovery
from scene_navigation import SceneHost,ScenePilot
from area_recovery import AreaRecovery
from working_area import WorkingAreaMemory
from idle_return import NoYieldWatch,ReturnSequence,map_evidence
from return_exit import BridgeExit,DEFAULT_EXIT,place_title,matches_place,purple_anchor
from network_state import Node
from spatial import geometry,resource_names
from resource_policy import ResourcePolicy
from resource_view_recovery import ResourceViewRecovery,VIEW_PULSES
from resource_clicks import ether_click_points
from input_audit import GameplayInputAudit
from collection_cycle import CollectionCycle
from receiver_check import check_receiver
from network_defense import NetworkDefense,AirDefenseView,attack_reason,dead
from health import HealthMonitor,read_hp
from view_guard import ViewGuard
from route_analyzer import AnalyzerHost
from vision import caption_candidate
from map_teleport import MapTeleport,observe as observe_map,exact_name,is_map,menu_stamp,same_stamp,title_stamp
from map_reference import MapReference
from defense import ThreatDetector,GatherInterrupts,enemy_hp
from flight import read_flight,FlightBudget
from vision import (WorldVision,find_world_resource,selected_target,segment_count,
                    gathering_panel,gathering_panel_pair,gather_result_full,resource_header_visible,Observation,find_resource_near,read_target_distance,selected_resource_name,locate_resource_emblem,find_selected_resource_badge,fast_ether_candidates,find_owned_resource_emblem)
from captcha_watchdog import CenterDialogDetector,AudioAlarm
from death_watchdog import DeathDialogDetector,DeathAudioAlarm

ROOT=Path(__file__).resolve().parent
OWN_RESOURCE='Собственный ресурс (имя уточняется)'


class GatherEngine:
    def __init__(self,cfg,emit,gamepad=None,network=None):
        self.cfg,self.emit=cfg,emit
        self.halt_reason=None;self.receiver_ready=False
        self.policy=ResourcePolicy(cfg)
        self.network=network;self.network_target=None;self.network_claimed_at=0;self.network_owner=None;self.network_slots_seen=None
        self.network_note_at=0;self.network_wait_since=None;self.network_exhausted=False
        self.network_hit_handled=0;self.network_attacker=None;self.network_selection_after=0;self.network_slots_seen=None
        self.network_defense=None;self.defense_motion=None;self.defense_camera_until=None
        self.defense_air_view=None;self.defense_restore_view=None;self.defense_interrupted=None;self.defense_evade_until=0
        self.attacker_retry_after={};self.attacker_handled={}
        self.visual_selection=None;self.acquisition_clicked_at=None;self.claimed_names={}
        self.network_bound_at=0
        self.resume_resource_id=None
        self.view_recovery=None;self.view_click_pending=False;self.resource_retry_after={}
        self.ether_click_index=0;self.abandoning_binding=None;self.abandoned_lease=None;self.ignored_collection_lease=None
        self.visual_route=None
        self.collection_cursor_owned=False;self.collection_cursor_retry_at=0
        self.click_wait_note_at=-1e9;self.spatial_note_at=-1e9
        self.camera_gate_busy=False;self.cursor_note_at=-1e9;self.click_wait_saved=set()
        self.collection_guard_note_at=-1e9;self.audit_motion_note_at=-1e9;self.input_audit=GameplayInputAudit()
        self.owned_click_due_at=0;self.owned_click_binding=None;self.owned_click_count=0
        self.click_sequence=0
        self.collection_cycle=CollectionCycle();self.cycle_authorized=None;self.cycle_request_cancelled=False;self.cycle_ui_note=None
        self.stop_event=threading.Event();self.screen=ScreenCapture()
        self.bridge=self._make_bridge(gamepad,cfg,emit)
        self.gamepad=gamepad
        self.vision=WorldVision(tuple(cfg['target_names']))
        self.minimap=MinimapVision(cfg);self.nav=Navigator(cfg)
        self.pitch=PitchLedger()
        self.pitch_observed=isinstance(gamepad,GamepadInput)
        if self.pitch_observed:
            gamepad.native_cursor=cfg.get('native_cursor_chord',True)
            gamepad.motion_listener=self.pitch.report;gamepad.camera_gate=self._camera_input_ready
            gamepad.translation_gate=self._translation_input_ready;gamepad.motion_audit=self._audit_pad_motion;gamepad.a_gate=self._a_input_ready
        self.health=HealthMonitor();self.hp_handled_event=0;self.hp_next_defense=0
        self.probe=None;self.pending_probe=None
        self.patrol_stall=PatrolStall();self.patrol_escape=None;self.patrol_escape_side=1
        self.terrain_watch=RecoveryWatch(cfg.get('terrain_rescue_seconds',90))
        self.terrain_recovery=None;self.terrain_side=1;self.patrol_escape_after=0
        self.scene_host=SceneHost(cfg,emit) if cfg.get('scene_navigation_enabled',False) else None
        self.analyzer=AnalyzerHost(cfg,emit) if cfg.get('analyzer_enabled',False) and self.scene_host is not None else None
        self.camp_exit_until=0;self.camp_exit_retry_after=0;self.camp_seen_since=None;self.camp_last_seen=0;self.camp_motion=0
        self.analyzer_note=0;self.ground_control_until=0
        self.scene_pilot=ScenePilot(cfg.get('camera_yaw_sign',1));self.scene_note=-1e9
        self.scene_camera_epoch=0;self.scene_settle_until=0
        self.scene_avoid_until=0;self.scene_avoid_bearing=None
        self.working_area=WorkingAreaMemory();self.fall_retry_after=0;self.rescue_selecting=False;self.rescue_click_after=0
        self.no_yield=NoYieldWatch();self.return_sequence=None;self.return_started=0;self.no_yield_wall_start=None
        self.return_panel_absent=None;self.return_note=0;self.return_grace_used=False;self.return_grace_until=0;self.return_exit_guard=False
        self.return_exit_scan_at=0;self.return_exit_next=0
        self.exit_route=None;self.exit_minimap=MinimapVision(cfg);self.exit_place=None;self.exit_place_at=0
        self.exit_route_driving=False
        self.exit_air_since=None;self.exit_fold_at=0;self.exit_folds=0
        self.view_guard=ViewGuard(.12 if cfg.get('scene_navigation_enabled',False) else .035)
        self.camera_scheduler_active=False;self.camera_last_calibrated=None
        self.camera_search_revision=0;self.camera_aligned_revision=0;self.camera_gather_tried_revision=-1
        self.camera_alignment_due=None;self.camera_requested_at=0
        self.calibration_resource_ended=False;self.camera_in_progress=False
        self.click_busy=False;self.click_wait_since=None;self.click_retry_at=0
        self.route_click_tries=0;self.route_click_sent_at=None
        self.fast_header_seen=False;self.fast_last_slots=None;self.fast_gather_seen=False
        self.fast_absent_since=None;self.last_flight_seen_at=None;self.last_flight_energy=None
        self.wing_close_pending=None;self.wing_close_retries=0;self.wing_absent_since=None
        self.wing_close_started=None
        self.arrival_camera_corrected=False
        self.resource_flight_owned=False;self.reacquire_until=None;self.reacquire_next=0
        self.acquire_failures=0;self.panel_last_seen=None;self.repeat_rearmed=False
        self.collection_activity_at=None;self.wing_block_note=-1e9
        self.distance_check_at=0;self.distance_live=None;self.distance_live_at=None;self.approach_recovery_at=0;self.approach_note_at=0
        self.f_repeat_allowed=False;self.route_active=False;self.last_path_motion=None
        self.real_gather_panel_seen=False;self.route_f_sent=False;self.route_f_pending=False
        self.wing_route_restart_pending=False;self.wing_route_restart_authorized=False;self.native_route_started_at=None
        self.calibration_defense_interrupted=False
        self.region=MapReference(cfg);self.map_active=False
        self.map_teleport=None;self.map_return_after=0;self.map_return_note=0;self.map_origin_place=None;self.map_menu_stamp=None;self.map_popup_stamp=None;self.map_popup_box=None
        self.rescue_air_search_until=0;self.scene_view_repair=False;self.scene_view_retry_after=0
        self.threat=ThreatDetector(cfg);self.interrupts=GatherInterrupts()
        self.collecting_visible=False;self.resource_hold=False;self.panel_cleared=False
        self.defense_cycles=0;self.next_defense=0;self.post_gather_until=0
        self.last_hold_note=0
        self.budget=FlightBudget(cfg.get('flight_low_percent',8),cfg.get('flight_resume_percent',18),
                                 retry_delay=cfg.get('flight_retry_delay',3))
        self.cap=CenterDialogDetector(template_dir=ROOT);self.death=DeathDialogDetector(template_dir=ROOT)
        self.cap_alarm=AudioAlarm(logger=emit);self.death_alarm=DeathAudioAlarm(logger=emit)
        self.cap_alarm.device_match=self.death_alarm.device_match=cfg.get('audio_device','AG271QG4')
        self.mode='SEARCH';self.started=time.monotonic();self.target=None;self.target_confirmed=False
        self.f_on=False;self.folded=False;self.flight_attempted=False;self.jump_attempted=False;self.reselected=False
        self.f_renewed_at=None;self.ocr_wait_note=0
        self.next_attempt_pending=None;self.next_attempt_sent_used=None;self.next_attempt_wait_at=None;self.next_attempt_click_tries=0
        self.network_managed_f=False
        self.spatial_route_active=False
        self.last_distance=None;self.last_progress=self.started;self.missing_since=None
        self.last_segments=None;self.one_segment_armed=False;self.node_count=0
        self.candidate=None;self.candidate_since=None;self.candidate_sequence=None
        self.cooldowns=[];self.last_note=0;self.last_energy_note=0
        self.emblem_acquisition=None
        self.snapshot_lock=threading.Lock();self.snapshot=None;self.sequence=0
        self.observation_captured_at=0
        self.identity_valid_after=0
        self.safety_threads=[];self.release_thread=None;self.release_lock=threading.Lock()
        self.alert=None;self.alert_lock=threading.Lock();self.current_size=None
        self.screenshot_path=ROOT/'debug_gather'
        if cfg.get('debug_screenshots'):self.screenshot_path.mkdir(exist_ok=True)

    def say(self,text):self.emit('['+self.mode+'] '+text)

    def change_mode(self,mode):self.mode=mode;self.started=time.monotonic()

    def _net_view(self):
        return self.network.view() if self.network is not None else None

    def _net_node(self,view=None):
        view=view or self._net_view()
        if not view or not view['ready'] or self.network_target is None:return None
        flow,actor=self.network_target
        if view['flow']!=flow or self.network_owner is not None and view['state'].own!=self.network_owner:return None
        return view['state'].nodes.get(actor) or Node(actor,time=self.network_claimed_at)

    def _gather_panel(self,frame):
        if self.network is None:return gathering_panel_pair(frame)
        view=self._net_view()
        return bool(self._net_gather_proof() and view['state'].attempt_active)

    def _net_gather_proof(self):
        view=self._net_view();node=self._net_node(view)
        return bool(node is not None and node.gather_time is not None
                    and node.gather_time>=self.network_claimed_at and node.used is not None and node.used<3
                    and node.visible and not self._inactive_lease_ignored(view,node) and not self._stale_defense_lease(view,node)
                    and view['state'].collecting==node.actor
                    and view['state'].selected in (0,node.actor))

    def _net_claim(self):
        until=time.monotonic()+2.5
        while self._focus_ok():
            view=self._net_view()
            if self._selected_resource(view,self.target):
                self.network_target=(view['flow'],view['state'].selected);self.network_owner=view['state'].own
                self.network_claimed_at=self.network_selection_after
                self.network_bound_at=time.monotonic()
                self.claimed_names[self.network_target]=self.target
                self.say('Сеть подтвердила выбранный ресурс; ожидаю начало собственного сбора')
                return True
            if time.monotonic()>=until:break
            if not GamepadInput.wait(.04,self.stop_event,self.screen.focused):return False
        self.say('За 2.5 с ресурс не подтверждён профилем или свежей верхней плашкой: F запрещён, продолжаю поиск');return False

    def _selected_resource(self,view,expected):
        if not view or not view['ready']:return False
        state=view['state'];node=state.nodes.get(state.selected)
        if time.monotonic()<self.resource_retry_after.get((view['flow'],state.selected),0):return False
        if self.resume_resource_id is not None and self.resume_resource_id!=(view['flow'],state.selected):return False
        if not state.selected or state.selection_time<self.network_selection_after:return False
        if state.selected in state.npcs or state.selected in state.players or state.selected in state.deaths:return False
        if node and (not node.visible or node.used==3):return False
        if node and node.template is not None:
            return bool(node.visible and node.used is not None and node.used<3 and resource_names().get(node.template)==expected)
        # A spawn can predate capture. An UNKNOWN actor needs a NEW resource
        # HUD reading, bound to that exact selected ID, after this A press.
        proof=self.visual_selection
        return bool(proof and self.acquisition_clicked_at is not None and proof[:3]==(view['flow'],state.selected,expected)
                    and proof[3]>=self.acquisition_clicked_at)

    def _inactive_lease_ignored(self,view,node):
        if self._retired_collection(view,node):return True
        if self.ignored_collection_lease==(view['flow'],node.actor,node.gather_time):return True
        if view['state'].attempt_active:return False
        binding=(view['flow'],node.actor)
        return (time.monotonic()<self.resource_retry_after.get(binding,0)
                or self.abandoned_lease==(*binding,node.gather_time))

    def _retired_collection(self,view,node):return False

    def _live_attempt(self,view):
        if not view or not view['ready']:return False
        state=view['state'];node=state.nodes.get(state.collecting)
        return bool(state.attempt_active and not self._retired_collection(view,node))

    def _own_collection(self,view=None):
        view=view or self._net_view()
        if not view or not view['ready'] or view['state'].own is None:return None
        state=view['state'];node=state.nodes.get(state.collecting)
        if node is not None and self._stale_defense_lease(view,node):return None
        if node is not None and self._failed_collection_request(view,node):return None
        if node is not None and self._inactive_lease_ignored(view,node):return None
        if state.collecting in state.npcs or state.collecting in state.players:return None
        if (node and node.gather_time is not None and node.visible and node.used is not None
            and node.used<3 and state.selected in (0,node.actor)):return node
        return None

    def _adopt_network_collection(self):
        if self.network is None or self.mode=='DEFENSE' or self.defense_restore_view is not None:return False
        view=self._net_view();node=self._own_collection(view)
        if (node is None and view and view['ready'] and self.mode in ('APPROACH','REACQUIRE')
            and self.target is not None and view['state'].last_own_result):
            actor,ended=view['state'].last_own_result
            candidate=view['state'].nodes.get(actor)
            if (self.network_target!=(view['flow'],actor) and ended>=self.network_claimed_at
                and actor not in view['state'].npcs and actor not in view['state'].players
                and 0<=time.time()*1000-ended<=2500 and candidate and candidate.used==3
                and candidate.gather_time is not None):node=candidate
        if node is None:return False
        label=resource_names().get(node.template) or self.claimed_names.get((view['flow'],node.actor))
        route=self.visual_route
        if (not label and route and route['flow']==view['flow'] and node.gather_time>=route['selection_after']):
            label=route['name'];self.claimed_names[(view['flow'],node.actor)]=label
        proof=self.visual_selection
        if (not label and proof and proof[:2]==(view['flow'],node.actor)
            and proof[2] in self._owned_resource_names() and proof[3]>=self.network_bound_at):label=proof[2]
        same=self.network_target==(view['flow'],node.actor)
        if not label and same and self.target in self.cfg['target_names']:label=self.target
        if self.target_confirmed and same:
            if label and label!=self.target:
                self.target=label;self.say('Фактически собираемый ресурс уточнён: '+label)
            return False
        self._release_visual_route()
        previous=self.target if self.target_confirmed else None
        label=label or OWN_RESOURCE
        self._neutral()
        sent_used=self.next_attempt_sent_used if same else None
        sent_at=self.next_attempt_wait_at if same else None
        click_tries=self.next_attempt_click_tries if same else 0
        self._reset_resource_watch(True)
        self.next_attempt_sent_used=sent_used;self.next_attempt_wait_at=sent_at;self.next_attempt_click_tries=click_tries
        self.target=label;self.target_confirmed=True;self.resource_hold=True
        self.network_target=(view['flow'],node.actor);self.network_owner=view['state'].own
        self.network_claimed_at=node.gather_time
        self.network_bound_at=time.monotonic()
        self.reacquire_until=None;self.missing_since=None
        if not same:
            self.resume_resource_id=None
            self.candidate=None;self.nav.goal=None
        self.probe=None;self.pending_probe=None;self.patrol_escape=None
        self.change_mode('APPROACH')
        self.say(('После F игра начала другой собственный сбор вместо '+previous+': ' if previous and not same else 'Собственный сбор подтверждён сетью: ')+label+'; принимаю его без нового стартового F и без движения')
        return True

    def _budget_update(self,reading,now):
        view=self._net_view()
        fresh_energy=False
        if view and view['ready']:
            state=view['state']
            fresh_energy=state.flight_at is not None and 0<=time.time()*1000-state.flight_at<=2000
            if (fresh_energy and state.flight is not None and state.flight_maximum is not None and state.flight_maximum>0
                and state.flight<=state.flight_maximum):
                reading=replace(reading,energy=100*state.flight/state.flight_maximum)
        self.budget.update(reading,now)
        if view and view['ready'] and fresh_energy:
            state=view['state']
            if state.flight is not None and state.flight_maximum and state.flight<=state.flight_maximum:
                self.budget.energy=100*state.flight/state.flight_maximum
                if now<self.budget.retry_after or self.budget.energy<self.budget.low:self.budget.blocked=True
                elif self.budget.energy>=self.budget.resume:self.budget.blocked=False
        self.policy.update(self.budget)


    def _network_guard(self,now):
        if self.network is None:return False
        view=self._net_view()
        if not view['ready']:
            self.no_yield.pause()
            self._neutral();self.f_disable()
            if self.network_wait_since is None:self.network_wait_since=now
            if now-self.network_note_at>3:
                self.say('Сеть: '+(view.get('reason') or view['error'] or 'ожидаю подтверждение игрового потока'))
                self.network_note_at=now
            if self.return_sequence is not None and now-self.return_started<30:return True
            if view['error'] or now-self.network_wait_since>30:
                self.say('Данные сети не подтверждены: остановка ввода. Подробности в network_diagnostics.');self.stop()
            return True
        self.network_wait_since=None
        if now-self.spatial_note_at>=10:
            self.spatial_note_at=now;state=view['state']
            live=sum(n.visible and n.used!=3 and n.xyz is not None for n in state.nodes.values())
            age=(time.time()*1000-state.position_at)/1000 if state.position_at is not None else None
            fresh=age is not None and -.1<=age<=.8 and state.own is not None
            self.say(f'Сеть XYZ: живых ресурсов {live}; своя позиция '+(f'{age:.1f} с ({state.position_source})' if age is not None else 'не получена')+'; '+('курс по XYZ доступен' if fresh else 'точное наведение недоступно, использую миникарту'))
        if self.network_owner is None and self.network_target is not None and view['state'].own is not None:
            self.network_owner=view['state'].own
        if (self.network_target is not None and (view['flow']!=self.network_target[0]
            or self.network_owner is not None and view['state'].own!=self.network_owner)):
            self._neutral();self.f_disable();self.say('Сетевое подключение/персонаж сменились: остановка до нового запуска');self.stop();return True
        return False

    def _net_resource(self,frame,reading,now):
        if self.network is None or not self.target_confirmed:return False
        view=self._net_view();node=self._net_node(view)
        if node is None:return False
        if node.used is not None and node.used!=self.network_slots_seen:
            self.say(f'Сеть: осталось попыток {3-node.used}/3 у текущего ресурса')
            self.network_slots_seen=node.used
        if node.used==3 or not node.visible and node.removed_reason==4:
            self.network_exhausted=True
            try:self.return_to_search('Сеть: ресурс полностью израсходован или удалён сервером',frame,exhausted=True,reading=reading)
            finally:self.network_exhausted=False
            return True
        if not node.visible:
            self._begin_reacquire('Сеть: ресурс вышел из видимости; повтор F выключен');return True
        selected=view['state'].selected
        if selected and selected!=node.actor:
            self._begin_reacquire('Сеть подтвердила смену цели: F выключен, возвращаюсь к ресурсу');return True
        if self.real_gather_panel_seen and view['state'].collecting!=node.actor:
            self._begin_reacquire('Сеть больше не подтверждает своё взаимодействие с ресурсом: F выключен');return True
        if self._net_gather_proof():
            if not self.real_gather_panel_seen:
                self.real_gather_panel_seen=True;self.route_f_sent=True;self.wing_route_restart_pending=False
                self.fast_gather_seen=True;self.f_repeat_allowed=True;self.route_active=False
                self.change_mode('GATHER');self.say('Сеть подтвердила начало МОЕГО сбора: жду окончания попытки, фонового F нет')
            self.fast_last_slots=3-node.used;self.collection_activity_at=now-max(0,(time.time()*1000-node.time)/1000)
            self.fast_absent_since=None;self.f_enable()
            if (self._click_interaction_enabled() and not self.cfg.get('repeat_owned_clicks',True) and not view['state'].attempt_active
                and self.next_attempt_sent_used==node.used and self.next_attempt_wait_at is not None
                and self.next_attempt_click_tries>=3 and time.monotonic()-self.next_attempt_wait_at>3
                and not self._net_view()['state'].attempt_active):
                self._arm_view_recovery(now)
                self.say('Следующая попытка не началась: меняю точки клика и ракурс, сохраняя общий срок восстановления')
        return False

    def _make_bridge(self,gamepad,cfg,emit):
        return GHubBridge(dry_run=cfg.get('dry_run',False),logger=emit)

    def bridge_cmd(self,command):
        if self._click_interaction_enabled() and command in ('TAP_F','F_ON'):return False
        if command in ('ALT_UP','STOP','TAB','V','END_AIR','ATTACK_PAIR','JUMP','MAP'):
            release_cursor=getattr(self.gamepad,'release_cursor',None)
            if callable(release_cursor):release_cursor()
        release=command in ('STOP','F_OFF','ALT_UP')
        if not release and (self.stop_event.is_set() or not self.screen.focused()):return False
        if self.network is not None and command not in ('STOP','F_OFF','ALT_UP','PING','END_AIR'):
            view=self._net_view()
            if not view['ready']:return False
            if command=='F_ON' and not self._net_gather_proof():return False
            if command=='TAP_F' and self.network_target is None:return False
            if command=='ATTACK_PAIR' and not self._net_selected_aggressor():return False
        if command=='TAP_F' and self.next_attempt_pending is None and (not self.route_f_pending or self.route_f_sent and not self.wing_route_restart_authorized):
            self.say('TAP_F заблокирован: один F для выбранного ресурса уже отправлен либо нет нового выбора');return False
        if command=='F_ON' and not (self.target_confirmed and self.real_gather_panel_seen):
            self.say('F_ON заблокирован: нижняя плашка этого ресурса ещё не подтверждена');return False
        if command in ('V','END_AIR') and not self._wing_action_allowed(command):return False
        if command=='TAP_F' and self.next_attempt_pending is not None:
            if not self._net_next_attempt_ready():return False
            if hasattr(self.bridge,'send_guarded'):return self.bridge.send_guarded(command,self._net_next_attempt_ready)
            return self.bridge.send(command) is not False
        if hasattr(self.bridge,'send_guarded') and (command=='V' or command=='TAP_F' and self.wing_route_restart_authorized):
            if command=='V':authorize=self._wing_send_still_allowed
            else:authorize=lambda:self._wing_restart_ready() and (self.network is None or self._resource_route_still_valid())
            return self.bridge.send_guarded(command,authorize)
        if self.network is not None and hasattr(self.bridge,'send_guarded'):
            if command=='END_AIR':return self.bridge.send_guarded(command,self._end_air_still_allowed)
            if command=='TAP_F':return self.bridge.send_guarded(command,self._resource_route_still_valid)
            if command=='F_ON':return self.bridge.send_guarded(command,self._net_gather_proof)
            if command=='ATTACK_PAIR':return self.bridge.send_guarded(command,self._net_selected_aggressor)
        return self.bridge.send(command) is not False

    def _end_air_still_allowed(self):
        if not self._focus_ok():return False
        view=self._net_view()
        if not view or not view['ready']:return False
        if self.abandoning_binding is not None:return self._can_abandon_resource()
        if self.network_exhausted:
            node=self._net_node(view)
            return bool(node and (node.used==3 or not node.visible and node.removed_reason==4))
        if self.cfg.get('preserve_owned_resource',True) and self._owned_resource_remaining():return False
        stale_node=self._net_node(view) or view['state'].nodes.get(view['state'].collecting)
        completed=stale_node and (stale_node.used==3 or not stale_node.visible and stale_node.removed_reason==4)
        released=stale_node and self._inactive_lease_ignored(view,stale_node)
        if stale_node and self._retired_collection(view,stale_node):return self._own_collection(view) is None
        if self._stale_defense_lease(view,stale_node) or completed or released:
            frame,_=self.screen.frame()
            return not gathering_panel_pair(frame) and self._own_collection(view) is None
        return self._own_collection(view) is None and not self._live_attempt(view)

    def _resource_route_still_valid(self):
        view=self._net_view()
        return bool(self._focus_ok() and view and view['ready'] and self.network_target
                    and view['flow']==self.network_target[0] and view['state'].selected==self.network_target[1]
                    and self._selected_resource(view,self.target)
                    and self._own_collection(view) is None and not self._urgent_damage_pending())

    def _net_next_attempt_ready(self):
        view=self._net_view();node=self._net_node(view)
        return bool(self._focus_ok() and self._net_gather_proof() and node
                    and self.next_attempt_pending in (1,2) and node.used==self.next_attempt_pending
                    and (self._next_click_due(node.used) if self._click_interaction_enabled() else self.next_attempt_sent_used!=node.used)
                    and not view['state'].attempt_active
                    and not self._urgent_damage_pending())

    def _wing_send_still_allowed(self):
        # Keep the final-strobe check fast: full distance OCR was checked
        # before encoding; only current collection/flight can revoke this V.
        if (not self._focus_ok() or self.real_gather_panel_seen
            or self.network is not None and self._net_gather_proof()):return False
        frame,_=self.screen.frame()
        return not (self._gather_panel(frame) or read_flight(frame).confirmed)

    def _wing_action_allowed(self,command,announce=True):
        if command=='END_AIR' and self.abandoning_binding is not None:return self._can_abandon_resource()
        # Exhaustion is tied to THIS claimed actor/flow by _net_resource.
        # Do not launch several OCR passes before releasing a depleted node.
        if command=='END_AIR' and self.network_exhausted:
            if announce:self.say('Крылья END_AIR: собственный ресурс израсходован по сети; OCR не требуется')
            return True
        if command=='END_AIR' and self.cfg.get('preserve_owned_resource',True) and self._owned_resource_remaining():return False
        if command=='V' and self.network is not None and self._own_collection() is not None:return False
        frame,_=self.screen.frame()
        panel=self._gather_panel(frame)
        header=segment_count(frame) is not None or resource_header_visible(frame)
        started=self.target_confirmed and (self.fast_gather_seen or self.mode=='GATHER')
        near=False
        if command=='V' and self.target_confirmed and header and not started:
            distance=(self.distance_live if self.distance_live_at is not None and time.monotonic()-self.distance_live_at<2 else None) if self.network is not None else read_target_distance(frame)
            if distance is None and self.network is None:
                name,distance=selected_target(frame,tuple(self.cfg['target_names']),require_track=False)
                near=name==self.target and distance is not None and distance<=3
            else:near=distance is not None and distance<=3
        title_alive=False
        if command=='END_AIR' and started and not panel and not header:
            name,_=selected_target(frame,tuple(self.cfg['target_names']),require_track=False)
            title_alive=name==self.target
        already_air=command=='V' and read_flight(frame).confirmed
        blocked=already_air or panel or near or (started and (command=='V' or header or title_alive))
        if command=='END_AIR' and self.network_exhausted:blocked=False
        if blocked:
            now=time.monotonic()
            if now-self.wing_block_note>2:
                self.say(f'Блокировка {command}: ресурс={self.target}, сбор={started}, нижняя плашка={panel}, верхняя={header}')
                self.wing_block_note=now
            return False
        if announce:self.say(f'Крылья {command}: ресурс={self.target}, режим={self.mode}, нижняя плашка={panel}, верхняя={header}')
        return True

    def _accept_gather_panel(self,frame):
        if self.network is not None and not self._net_gather_proof():return False
        if not self.target_confirmed or not self._gather_panel(frame):return False
        self.real_gather_panel_seen=True;self.route_f_sent=True;self.wing_route_restart_pending=False
        self.f_repeat_allowed=True;self.route_active=False
        self.save_debug(frame,'first_gather_panel')
        self.say('ПЕРВАЯ нижняя плашка Успех/Неудача подтверждена: повтор F разрешён до исчезновения этого таргета')
        return True

    def f_enable(self):
        # Only an actual paired lower panel can grant repeats for THIS target.
        # Once seen, its permission survives the gaps between attempts.
        if not self.target_confirmed:return False
        if not self.real_gather_panel_seen:
            frame,_=self.screen.frame()
            if not self._accept_gather_panel(frame):return False
        if self.network is not None:
            # No background F timer. One completed attempt grants ONE request
            # for the next attempt; its pending native path must not be toggled.
            view=self._net_view();node=self._net_node(view)
            if node is None or not self._net_gather_proof():return False
            if not self.f_on:
                self.say('Продолжение по окончанию попытки: во время нижней шкалы повторного A нет' if self._cycle_enabled() else 'Сбор подтверждён: безопасный повтор клика примерно раз в секунду, без ожидания active/counter' if self._click_interaction_enabled() and self.cfg.get('repeat_owned_clicks',True) else 'Сбор подтверждён: следующая попытка запускается после окончания текущей, без таймера взаимодействия')
            self.f_on=True
            self.network_managed_f=True
            if self._cycle_enabled():
                token=self._cycle_observe(view)
                if token is not None:
                    self.cycle_authorized=token
                    try:self._repeat_owned_click()
                    finally:self.cycle_authorized=None
                return self.f_on
            if self._click_interaction_enabled() and self.cfg.get('repeat_owned_clicks',True):
                self._prepare_collection_cursor()
                self._repeat_owned_click();return self.f_on
            if view['state'].attempt_active:
                self.next_attempt_wait_at=None;self.ether_click_index=0
                self._prepare_collection_cursor()
            elif node.used in (1,2) and (self._next_click_due(node.used) if self._click_interaction_enabled() else self.next_attempt_sent_used!=node.used):
                self.next_attempt_pending=node.used
                try:
                    sent=(self._activate_resource_click(next_attempt=True) if self._click_interaction_enabled() else self.bridge_cmd('TAP_F'))
                    if sent:
                        self.next_attempt_sent_used=node.used;self.next_attempt_wait_at=time.monotonic()
                        self.say(f'Попытка завершена ({node.used}/3): '+('клик отправлен или новое начало уже подтверждено; ожидаю событие сбора' if self._click_interaction_enabled() else 'один F для следующей; F до нового события не повторяю'))
                finally:self.next_attempt_pending=None
            return self.f_on
        now=time.monotonic()
        if not self.f_on and self.bridge_cmd('F_ON'):
            first=not self.f_on
            self.f_on=True;self.f_renewed_at=time.monotonic()
            if first:self.say('F включено после начала сбора: повтор между попытками этого ресурса')
        return self.f_on

    def _cycle_enabled(self):
        return self.network is not None and self._click_interaction_enabled() and self.cfg.get('collection_event_driven',True)

    def _cycle_observe(self,view=None,frame=None):
        view=view or self._net_view();node=self._net_node(view)
        if (not view or not view['ready'] or node is None or not self._net_gather_proof()
            or not self.target_confirmed or self.mode!='GATHER'):return None
        if frame is None:frame,_=self.screen.frame()
        panel=gathering_panel_pair(frame);full=gather_result_full(frame,strict=True) if panel else False
        state=view['state'];result=state.last_own_result;used=state.last_own_result_used
        valid=bool(result and result[0]==node.actor and used in (1,2)
                   and result[1]>=max(self.network_claimed_at,node.gather_time or 0,state.started or 0))
        token=self.collection_cycle.observe((self.network_target,self.network_claimed_at),
            (state.started,state.attempt_ordinal),time.monotonic(),panel,full,used,valid,
            state.selected==0 or not state.attempt_active,node.used)
        phase='partial' if panel and not full else 'full_hint' if panel else 'absent'
        note=(self.network_target,state.started,state.attempt_ordinal,phase,token)
        if note!=self.cycle_ui_note:
            self.cycle_ui_note=note
            self.say(f'COLLECTION_UI: ordinal={state.attempt_ordinal}, lower={phase}, own_end={used if valid else None}, permission={token}')
        return token

    def _repeat_owned_click(self):
        """Submit one fresh-point request when its caller authorizes continuation.

        The event-driven policy additionally needs a completed-attempt token;
        its rendered partial panel blocks input. The legacy timer is retained
        only for explicit opt-out. Neither path sends F or translation.
        """
        binding=self.network_target;now=time.monotonic()
        if binding!=self.owned_click_binding:
            self.owned_click_binding=binding;self.owned_click_due_at=0;self.owned_click_count=0
        if binding is None or now<self.owned_click_due_at:return False
        if not self._click_ready(binding,True,owned_repeat=True):return False
        # Reserve the cadence before delivery, including re-entrant callbacks.
        self.owned_click_due_at=now+.8
        node=self._net_node()
        if node is None:return False
        self.next_attempt_pending=node.used
        try:
            sent=self._activate_resource_click(next_attempt=True,owned_repeat=True)
            if sent:self.owned_click_count+=1
            self.owned_click_due_at=time.monotonic()+(.8 if sent else .35)
            return sent
        finally:self.next_attempt_pending=None

    def _owned_resource_remaining(self):
        view=self._net_view();node=self._net_node(view)
        return bool(node and node.visible and node.gather_time is not None
                    and node.gather_time>=self.network_claimed_at and node.used is not None and node.used<3
                    and not self._retired_collection(view,node)
                    and not self._stale_defense_lease(view,node) and not self._failed_collection_request(view,node))

    def _failed_collection_request(self,view,node):
        cycle=self.collection_cycle
        if (not self._cycle_enabled() or self.network_target is None or not cycle.failed(time.monotonic())
            or not view or not view['ready'] or node is None):return False
        state=view['state'];result=state.last_own_result
        if (view['flow']!=self.network_target[0]
            or self.network_owner is not None and state.own!=self.network_owner
            or cycle.binding!=(self.network_target,self.network_claimed_at)
            or cycle.attempt!=(state.started,state.attempt_ordinal) or node.actor!=self.network_target[1]
            or state.collecting!=node.actor or state.selected not in (0,node.actor)
            or cycle.waiting_used!=node.used):return False
        if cycle.waiting_kind=='end':
            if (state.attempt_active or state.last_own_result_used!=node.used or not result or result[0]!=node.actor
                or result[1]<max(self.network_claimed_at,node.gather_time or 0,state.started or 0)):return False
        elif cycle.waiting_kind=='resume':
            if (state.attempt_active and state.selected!=0 or cycle.absent_since is None
                or time.monotonic()-cycle.absent_since<2):return False
        else:return False
        frame,_=self.screen.frame()
        return not gathering_panel_pair(frame)

    def _stale_defense_lease(self,view,node):
        binding=self.defense_interrupted
        if not binding or not view or not view['ready'] or node is None or node.gather_time is None:return False
        flow,actor,cutoff=binding;state=view['state']
        episode=self.network_defense
        if (episode is not None and episode.flow==flow and episode.resource_id==actor
            and view['flow']==flow and node.actor==actor):return True
        new_start=(state.started is not None and state.started>=cutoff and node.gather_time>=cutoff)
        new_result=(state.last_own_result is not None and state.last_own_result[0]==actor
                    and state.last_own_result[1]>=cutoff)
        if view['flow']==flow and node.actor==actor and state.collecting==actor and (new_start or new_result):
            self.defense_interrupted=None;return False
        return bool(view['flow']==flow and node.actor==actor
                    and (state.collecting!=actor or state.started is None or state.started<cutoff or node.gather_time<cutoff))

    def _translation_input_ready(self):
        if not self._focus_ok():return False
        if not self.cfg.get('preserve_owned_resource',True):return True
        view=self._net_view()
        if self.network is not None and (not view or not view['ready']):return False
        owned=self._own_collection(view) if view and view['ready'] else None
        held=self.resource_hold and self.mode=='GATHER'
        if owned is not None or held or self._owned_resource_remaining():
            now=time.monotonic()
            if now-self.collection_guard_note_at>=2:
                self.collection_guard_note_at=now
                self.say(f'COLLECTION_GUARD: левый стик запрещён, ID={self.network_target}, режим={self.mode}')
            return False
        return True

    def _a_input_ready(self):
        # A must remain in cursor mode for its entire down/up interval.
        ready=(self._focus_ok() and self.bridge.alt_is_down()
               and (not getattr(self.gamepad,'native_cursor',False) or self.gamepad.cursor_held))
        if not ready and not self.stop_event.is_set():self.say('A_ABORT: Alt, фокус или LB+LT не подтверждены; A отпускается')
        if ready and self.mode=='ACQUIRE' and self._live_attempt(self._net_view()):return False
        if ready and self.mode=='ACQUIRE' and self.emblem_acquisition is not None:return False
        return ready and self._cursor_click_ready()

    def _audit_pad_motion(self,forward,strafe,yaw,pitch,lifetime):
        now=time.monotonic()
        if abs(yaw)+abs(pitch)>.001:
            self.scene_camera_epoch+=1;self.scene_settle_until=now+min(.85,lifetime)+.1
            yaw_end=getattr(self.gamepad,'yaw_deadline',None)
            if abs(pitch)<.001 and yaw_end is not None:self.scene_settle_until=yaw_end+.1
        if (abs(forward)+abs(strafe)+abs(yaw)+abs(pitch)>.01
            and now-self.audit_motion_note_at>=.3):
            self.audit_motion_note_at=now
            self.say(f'PAD_REPORT: режим={self.mode}, ID={self.network_target}, вперёд={forward:.2f}, бок={strafe:.2f}, поворот={yaw:.2f}, наклон={pitch:.2f}, срок={lifetime:.2f} с')

    def _input_audit_loop(self):
        while not self.stop_event.is_set():
            if self._focus_ok() and self.network_target is not None and self.real_gather_panel_seen:
                for name,down in self.input_audit.sample():
                    self.say(f'INPUT_STATE: {name} '+('DOWN' if down else 'UP')+f'; режим={self.mode}, ID={self.network_target}; фактическое состояние Windows, источник не определяется')
            else:self.input_audit.reset()
            if self.stop_event.wait(.025):return

    def _camera_input_ready(self):
        """No right-stick report while Alt is physically held."""
        if not self._focus_ok():return False
        self.camera_gate_busy=True
        try:
            release=getattr(self.gamepad,'release_cursor',None)
            if callable(release):release()
            if self.bridge.alt_is_down():
                self._neutral();self.collection_cursor_owned=False
                if not self.bridge_cmd('ALT_UP') or not self._wait_alt_state(False):
                    self.halt_reason='Камера заблокирована: Alt не отпущен';self.say(self.halt_reason);self.stop();return False
            return self._focus_ok() and not self.bridge.alt_is_down()
        finally:self.camera_gate_busy=False

    def _cursor_click_ready(self):
        check=getattr(self.bridge,'cursor_matches',None)
        if check is None or check():return True
        now=time.monotonic()
        if now-self.cursor_note_at>=1:
            self.cursor_note_at=now
            self.say(f'CURSOR_MISS: задано={getattr(self.bridge,"last_cursor_target",None)}, фактически={getattr(self.bridge,"last_cursor_actual",None)}; A не отправляю')
        return False

    def _prepare_collection_cursor(self):
        # Prepare Alt during an already-running attempt, not after its result.
        # Xbox camera control remains independent of the visible mouse cursor.
        if (not self._click_interaction_enabled() or not self.cfg.get('collection_cursor_hold',True)
            or self.cfg.get('dry_run') or self.camera_in_progress or self.camera_gate_busy or not self._focus_ok() or time.monotonic()<self.collection_cursor_retry_at
            or not self._net_gather_proof()):return
        if self.bridge.alt_is_down():return
        frame,_=self.screen.frame()
        if self._fresh_click_candidate(frame) is None:return
        self.collection_cursor_retry_at=time.monotonic()+3
        if self.bridge_cmd('ALT_DOWN') and self._wait_alt_state(True):self.collection_cursor_owned=True

    def _release_collection_cursor(self):
        if not self.collection_cursor_owned:return
        self.collection_cursor_owned=False
        if self.bridge.alt_is_down():self.bridge_cmd('ALT_UP')

    def f_disable(self):
        self._release_collection_cursor()
        if self.f_on:
            if not self.network_managed_f:self.bridge_cmd('F_OFF')
            self.f_on=False
        self.network_managed_f=False

    def save_debug(self,frame,label):
        if self.cfg.get('debug_screenshots'):
            self.screenshot_path.mkdir(exist_ok=True)
            # Preserve full resolution: the old 1280 resize damaged short Ether text.
            cv2.imwrite(str(self.screenshot_path/(time.strftime('%H%M%S')+'_'+label+'.jpg')),frame,[cv2.IMWRITE_JPEG_QUALITY,94])

    def _release_inputs(self):
        self.collection_cursor_owned=False
        try:self.bridge.send('STOP');self.bridge.restore_locks()
        except Exception as exc:self.emit('Ошибка освобождения Lua: '+str(exc))

    def stop(self,manual=False,terminal=False):
        if self.scene_host is not None:self.scene_host.close()
        if self.analyzer is not None:self.analyzer.close()
        self.stop_event.set()
        self._stop_defense_motion()
        if self.gamepad:self.gamepad.reset()
        with self.release_lock:
            if self.release_thread is None:
                self.release_thread=threading.Thread(target=self._release_inputs,daemon=True)
                self.release_thread.start()

    def silence(self):self.cap_alarm.stop();self.death_alarm.stop()

    def trigger_alarm(self,kind,frame):
        with self.alert_lock:
            if self.alert is not None or self.stop_event.is_set():return
            self.alert=kind
        self.stop();self.save_debug(frame,kind.lower())
        self.say('ТРЕВОГА '+kind+' — остановлено, требуется ручное продолжение')
        alarm=self.cap_alarm if kind=='CAPTCHA' else self.death_alarm
        try:alarm.start(self.cfg.get('audio_device','AG271QG4'),error_cb=self.emit)
        except Exception as exc:self.emit('Ошибка звука: '+str(exc))

    def _dialog_loop(self,kind,detector,interval):
        hits=0
        while not self.stop_event.is_set():
            if self.screen.focused():
                try:
                    frame,_=self.screen.frame();present,_=detector.check(frame)
                    hits=hits+1 if present else 0
                    if hits>=2:self.trigger_alarm(kind,frame);return
                except Exception as exc:self.emit(kind+' / проверка: '+str(exc));hits=0
            else:hits=0
            if self.stop_event.wait(interval):return

    def _heartbeat_loop(self):
        while not self.stop_event.is_set():
            try:
                if self._focus_ok():self.bridge.ping_if_idle()
            except Exception as exc:self.emit('Ошибка heartbeat: '+str(exc));self.stop();return
            if self.stop_event.wait(2):return

    def _vision_names(self):
        if self.target_confirmed and self.target!=OWN_RESOURCE and self._net_gather_proof():return (self.target,)
        if isinstance(self.terrain_recovery,AreaRecovery) and self.terrain_recovery.phase in ('CRUISE','SCAN'):
            return tuple(self.cfg['target_names'])
        if self.mode=='REACQUIRE' and self.target in self.cfg['target_names']:
            return (self.target,)
        return self.policy.names(self.cfg['target_names'])

    def _owned_resource_names(self):
        # Resolve the actual name only AFTER a private own-collection proof.
        # This never expands which resources may be acquired during SEARCH.
        return tuple(dict.fromkeys((*self.cfg['target_names'],*(n for n in resource_names().values() if n))))

    def _caption_rejected(self,candidate):return False

    def _collection_vision_idle(self):
        if (self.network is None or not self.target_confirmed or self.target==OWN_RESOURCE
            or self.mode!='GATHER'):return False
        view=self._net_view();owned=self._own_collection(view)
        return bool(owned and view['state'].attempt_active)

    def _network_world_observation(self,frame):
        names=self._vision_names();candidate=None
        if self.target_confirmed:
            owned=self._net_gather_proof();active=self._collection_vision_idle()
            previous=self.candidate
            with self.snapshot_lock:snapshot=self.snapshot
            if (snapshot is not None and 0<=time.monotonic()-snapshot[1]<=2.5
                and snapshot[0].candidate is not None and snapshot[0].candidate.name==self.target):previous=snapshot[0].candidate
            if (self._click_interaction_enabled() and not self.camera_in_progress
                and (self.mode=='GATHER' or not self.route_f_sent or self.mode=='TAKEOFF'
                     or self.mode=='APPROACH' and time.monotonic()-self.last_progress>=2)):
                candidate=self._refresh_bound_candidate(frame,previous) if previous and previous.name==self.target else None
                if candidate is None and owned:candidate=find_selected_resource_badge(frame,self.target,previous)
                if candidate is None and owned:candidate=find_owned_resource_emblem(frame,self.target,previous)
                if candidate is None and owned and self.target=='Эфир':
                    # A native flight can move the label beyond the local ROI.
                    # Keep the bounded shape-only pass available while active;
                    # a stale active flag must not disable visible Ether text.
                    options=fast_ether_candidates(frame,('Эфир',))
                    if options:
                        candidate=(min(options,key=lambda c:(c.click_x-previous.click_x)**2+(c.click_y-previous.click_y)**2)
                                   if previous else options[0])
                if candidate is None and not active and self.target!=OWN_RESOURCE:candidate=find_world_resource(frame,(self.target,))
            return Observation(candidate,self.target,None,False,0,False,None,'HIDDEN')
        if self.mode in ('SEARCH','ACQUIRE_WAIT','REACQUIRE','PROBE'):candidate=find_world_resource(frame,names,rejected=self._caption_rejected)
        return Observation(candidate,None,None,False,0,False,None,'HIDDEN')

    def _analyzer_aether(self,frame):
        if self.analyzer is None or self.mode not in ('SEARCH','ACQUIRE_WAIT') or self.map_active:return None
        hint=self.analyzer.current(frame,time.monotonic(),self.scene_camera_epoch,self.nav.last_heading,self.pitch.offset(time.monotonic()))
        if hint is None:return None
        h,w=frame.shape[:2]
        for x,y,rw,rh in hint.answer['aether']:
            x0=max(0,round(x*w/1000)-50);y0=max(0,round(y*h/1000)-40)
            x1=min(w,round((x+rw)*w/1000)+50);y1=min(h,round((y+rh)*h/1000)+40)
            if x1-x0<12 or y1-y0<10:continue
            choices=fast_ether_candidates(frame[y0:y1,x0:x1],('Эфир',),deadline=time.monotonic()+.12)
            for c in choices:
                bx,by,bw,bh=c.box;box=(bx+x0,by+y0,bw,bh)
                cx,cy=box[0]+bw/2,box[1]+bh/2
                if cy<h*.11 or cx>w*.81 and cy<h*.44 or cx<w*.34 and cy>h*.69:continue
                return caption_candidate(frame,'Эфир',box,c.confidence,c.glyph_mode)
        return None

    def _candidate_observed(self,candidate,captured,pose,baseline=None):pass

    def _prepare_next_ether_view(self,frame,now):return False

    def _cooldown_blocks(self,candidate,x,y):
        return abs(candidate.click_x-x)<80 and abs(candidate.click_y-y)<80

    def _search_caption_priority(self,obs,now):return False

    def _vision_loop(self):
        failures=0
        while not self.stop_event.is_set():
            if self.map_active:
                if self.stop_event.wait(.1):return
                continue
            if not self.screen.focused():
                if self.stop_event.wait(.15):return
                continue
            try:
                captured=time.monotonic();pose,baseline=self.pitch.capture(captured);frame,_=self.screen.frame()
                if self.network is not None and self.mode in ('ACQUIRE','VERIFY_NATIVE','VERIFY_EMBLEM'):
                    before=self._net_view()
                    name=selected_resource_name(frame,self.cfg['target_names']);distance=read_target_distance(frame) if self.mode in ('VERIFY_NATIVE','VERIFY_EMBLEM') else None
                    after=self._net_view()
                    if (name and before and after and before['ready'] and after['ready']
                        and before['flow']==after['flow'] and before['state'].selected==after['state'].selected):
                        self.visual_selection=(after['flow'],after['state'].selected,name,captured)
                    obs=Observation(None,name,distance,False,0,False,None,'HIDDEN')
                elif (hinted:=self._analyzer_aether(frame)) is not None:
                    obs=Observation(hinted,None,None,False,0,False,None,'HIDDEN')
                elif self.network is not None and self.target_confirmed:
                    # Network already supplies the resource identity. Read only
                    # distance in this worker; no synchronous OCR in approach.
                    distance=read_target_distance(frame) if not self.real_gather_panel_seen else None
                    if self.target==OWN_RESOURCE:
                        before=self._net_view();owned=self._own_collection(before)
                        name=selected_resource_name(frame,self._owned_resource_names()) if owned else None
                        after=self._net_view();current=self._own_collection(after)
                        if name and owned and current and before['flow']==after['flow'] and owned.actor==current.actor:
                            self.visual_selection=(after['flow'],current.actor,name,captured)
                    obs=self._network_world_observation(frame)
                    obs.distance_m=distance
                elif self.network is not None:
                    obs=self._network_world_observation(frame)
                else:
                    obs=self.vision.scan(frame,candidates=self.mode in ('SEARCH','ACQUIRE_WAIT','REACQUIRE','PROBE') and not self.target_confirmed,target=True,names=self._vision_names())
                if obs.candidate and obs.candidate.name=='Эфир' and not self.budget.can_start() and self.mode in ('SEARCH','ACQUIRE_WAIT'):
                    names=tuple(n for n in self.cfg['target_names'] if n!='Эфир')
                    obs.candidate=find_world_resource(frame,names)
                if obs.candidate is not None:self._candidate_observed(obs.candidate,captured,pose,baseline)
                with self.snapshot_lock:
                    completed=time.monotonic()
                    self.sequence+=1;self.snapshot=(obs,captured,self.sequence,completed)
                if completed-captured>3 and completed-self.ocr_wait_note>=5:
                    self.say(f'Медленный OCR: кадр обрабатывался {completed-captured:.2f} с; сетевой сбор и закрытие крыльев обслуживаются отдельно')
                    self.ocr_wait_note=completed
                failures=0
            except Exception as exc:
                failures+=1;self.emit('OCR / ошибка: '+str(exc))
                if failures>=3:self.stop();return
            if self.stop_event.wait(.35 if self._collection_vision_idle() else .20 if self.network is not None else .08):return

    def _needs_visual_hp(self):return self.network is None

    def _health_identity_sample(self,value,captured,verified):pass

    def _health_fast_loop(self):
        while not self.stop_event.is_set():
            if self._needs_visual_hp() and self.cfg.get('protect_player',True) and self.screen.focused() and not self.map_active:
                try:
                    frame,_=self.screen.frame();self.health.fast(frame,time.monotonic())
                except Exception:pass
            if self.stop_event.wait(max(.02,min(.05,self.cfg.get('hp_fast_seconds',.05)))):return

    def _health_numeric_loop(self):
        last_error=0
        while not self.stop_event.is_set():
            if self._needs_visual_hp() and self.cfg.get('protect_player',True) and self.screen.focused() and not self.map_active:
                try:
                    suspect=self.health.take_suspect()
                    if suspect is None:
                        frame,_=self.screen.frame();captured=time.monotonic()
                    else:frame,captured=suspect
                    value=read_hp(frame,self.cfg.get('hp_roi'));verified=False
                    if value is not None and value.current<value.maximum:
                        other=read_hp(frame,self.cfg.get('hp_roi'),alternate=True)
                        verified=(other is not None and other.current==value.current and other.maximum==value.maximum)
                    previous=self.health.state()['damage_sequence']
                    self.health.numeric(frame,value,captured,verified=verified)
                    self._health_identity_sample(value,captured,verified)
                    if self.health.state()['damage_sequence']>previous:
                        self.say(f'HP подтверждено двумя вариантами OCR: {value.current}/{value.maximum}')
                except Exception as exc:
                    if time.monotonic()-last_error>10:self.say('HP OCR: '+str(exc));last_error=time.monotonic()
            self.health.suspect_ready.wait(max(.10,min(.20,self.cfg.get('hp_ocr_seconds',.20))))

    def _focus_ok(self):return not self.stop_event.is_set() and self.screen.focused()

    def _reset_resource_watch(self,verified_header=False):
        self.click_wait_since=None;self.click_retry_at=0;self.route_click_tries=0;self.route_click_sent_at=None;self.ether_click_index=0
        self.fast_header_seen=verified_header;self.fast_last_slots=None;self.fast_gather_seen=False
        self.fast_absent_since=None;self.last_flight_seen_at=None;self.last_flight_energy=None
        self.arrival_camera_corrected=False
        self.panel_last_seen=None;self.repeat_rearmed=False;self.collection_activity_at=None
        self.f_repeat_allowed=False;self.route_active=False;self.last_path_motion=None
        self.real_gather_panel_seen=False;self.route_f_sent=False;self.route_f_pending=False
        self.wing_route_restart_pending=False;self.wing_route_restart_authorized=False;self.native_route_started_at=None
        self.distance_check_at=0;self.distance_live=None;self.distance_live_at=None;self.approach_recovery_at=0
        self.network_target=None;self.network_claimed_at=0;self.network_owner=None;self.network_slots_seen=None
        self.next_attempt_pending=None;self.next_attempt_sent_used=None;self.next_attempt_wait_at=None;self.next_attempt_click_tries=0

    def _wing_restart_ready(self):
        if (not self._focus_ok() or not self.target_confirmed or not self.wing_route_restart_pending
            or self.mode!='TAKEOFF' or self.real_gather_panel_seen or self.fast_gather_seen):return False
        frame,_=self.screen.frame()
        return not (self._gather_panel(frame)) and read_flight(frame).confirmed

    def _next_click_due(self,used):
        if self.next_attempt_sent_used!=used:return True
        return (self.next_attempt_wait_at is not None and self.next_attempt_click_tries<3
                and time.monotonic()-self.next_attempt_wait_at>=2)

    def _click_interaction_enabled(self):
        return self.network is not None and self.cfg.get('resource_click_interaction',True)

    def _defer_route_defense(self,now):
        if self.mode=='VERIFY_NATIVE' and self.visual_route is not None:
            distance=self.visual_route['distance']
            return distance is None or distance>self.cfg.get('defense_arrival_distance',10)
        if (self.cfg.get('defense_during_approach',False) or not self.target_confirmed
            or self.real_gather_panel_seen or self.mode not in ('APPROACH','TAKEOFF','JUMP_RETRY')):return False
        view=self._net_view()
        if view and view['ready'] and view['state'].attempt_active and self.network_target and view['state'].collecting==self.network_target[1]:return False
        relative=geometry(view['state'],self._net_node(view)) if view and view['ready'] else None
        distance=relative['distance_m'] if relative else None
        if distance is None and self.distance_live_at is not None and 0<=now-self.distance_live_at<=2:
            distance=self.distance_live
        if distance is None:
            with self.snapshot_lock:snapshot=self.snapshot
            if (snapshot is not None and 0<=now-snapshot[1]<=2 and snapshot[1]>=self.identity_valid_after
                and snapshot[0].target_name==self.target):distance=snapshot[0].distance_m
        # No HP threshold: intercept the confirmed attacker before arrival.
        # If distance is unavailable, allow only a short travel grace period.
        if distance is None:
            return self.native_route_started_at is not None and now-self.native_route_started_at<3
        return distance>self.cfg.get('defense_arrival_distance',10)

    def _click_ready(self,binding,next_attempt,reserved=False,owned_repeat=False):
        view=self._net_view();node=self._net_node(view)
        if (not self._focus_ok() or self.camera_in_progress or self.network_target!=binding
            or not view or not view['ready'] or view['flow']!=binding[0] or node is None
            or not node.visible or node.used==3 or view['state'].selected not in (0,binding[1])
            or self.network_owner is not None and view['state'].own!=self.network_owner
            or self._urgent_damage_pending() or self._live_attempt(view) and not owned_repeat):return False
        if self._cycle_enabled() and self._net_gather_proof():
            if self.cycle_authorized is None or self._cycle_observe(view)!=self.cycle_authorized:return False
        if owned_repeat:
            return bool(self.cfg.get('repeat_owned_clicks',True) and self.real_gather_panel_seen
                        and self.target_confirmed and self.mode=='GATHER' and self._net_gather_proof())
        if next_attempt:
            if reserved:return self._net_gather_proof() and node.used==self.next_attempt_pending
            return self._net_next_attempt_ready()
        return self.target_confirmed and self.route_f_pending and not self._net_gather_proof()

    def _refresh_bound_candidate(self,frame,previous):
        # Own collection already establishes identity. Its known clickable badge
        # can continue it even if the four caption letters cannot be re-read.
        if previous.emblem is not None and self._net_gather_proof():
            emblem=locate_resource_emblem(frame,previous.box)
            if emblem is not None:
                ox,oy,ow,oh=previous.emblem;x,y,w,h=emblem
                dx=round(x+w/2-ox-ow/2);dy=round(y+h/2-oy-oh/2)
                bx,by,bw,bh=previous.box
                return replace(previous,box=(bx+dx,by+dy,bw,bh),click_x=x+w//2,click_y=y+h//2,emblem=emblem)
        return find_resource_near(frame,previous) if previous.glyph is not None else None

    def _fresh_click_candidate(self,frame):
        # A fresh local glyph is cheap. Full OCR runs only in the vision worker.
        previous=self.candidate
        if previous is not None and previous.name==self.target and (previous.glyph is not None or previous.emblem is not None and self._net_gather_proof()):
            fresh=self._refresh_bound_candidate(frame,previous)
            if fresh is not None:
                if fresh.emblem is not None or previous.emblem is not None:return fresh
                # Keep the hitbox offset that actually selected this actor.
                return replace(fresh,click_x=fresh.box[0]+previous.click_x-previous.box[0],
                               click_y=fresh.box[1]+previous.click_y-previous.box[1])
        with self.snapshot_lock:snapshot=self.snapshot
        now=time.monotonic()
        if (snapshot is not None and 0<=now-snapshot[1]<=2.5 and snapshot[1]>=self.identity_valid_after
            and snapshot[0].candidate is not None and snapshot[0].candidate.name==self.target
            and (snapshot[0].candidate.glyph is not None or snapshot[0].candidate.emblem is not None and self._net_gather_proof())):
            return self._refresh_bound_candidate(frame,snapshot[0].candidate)
        return None

    def _tap_resource_point(self,frame,candidate,binding,stage):
        """Audit the exact rendered point; never stores a full game frame here."""
        self.cycle_request_cancelled=False
        self.click_sequence+=1;seq=self.click_sequence
        before=self._net_view();node=self._net_node(before)
        state=before['state'] if before and before['ready'] else None
        used=node.used if node else None
        x,y=int(candidate.click_x),int(candidate.click_y)
        self.say(f'CLICK_POINT: seq={seq}, ID={binding[1]}, stage={stage}, point=({x},{y}), caption={candidate.box}, emblem={candidate.emblem}, selected={state.selected if state else None}, used={used}, active={state.attempt_active if state else None}')
        if self.cfg.get('debug_screenshots'):
            try:
                folder=ROOT/'debug_clicks';folder.mkdir(exist_ok=True)
                H,W=frame.shape[:2];mx=min(280,max(90,round(W*.09)));my=min(250,max(90,round(H*.15)))
                x0=max(0,x-mx);x1=min(W,x+mx);y0=max(0,y-my);y1=min(H,y+my)
                crop=frame[y0:y1,x0:x1].copy()
                if crop.size:
                    cv2.drawMarker(crop,(x-x0,y-y0),(0,0,255),cv2.MARKER_CROSS,16,1)
                    path=folder/f'click_{time.time_ns()}_{seq}_{stage}.jpg'
                    if not cv2.imwrite(str(path),crop,[cv2.IMWRITE_JPEG_QUALITY,94]):raise OSError('crop write failed')
                    for old in sorted(folder.glob('click_*.jpg'),key=lambda p:p.name)[:-24]:old.unlink()
            except Exception as exc:self.say('Не удалось сохранить область клика: '+str(exc))
        token=None
        if self._cycle_enabled() and self._net_gather_proof():
            token=self.cycle_authorized
            if (token is None or candidate.emblem is not None and token[0]!='end'
                or self._cycle_observe()!=token or not self.collection_cycle.consume(token,time.monotonic())):
                self.cycle_request_cancelled=True
                release=getattr(self.gamepad,'release_cursor',None)
                if callable(release):release()
                self.say(f'COLLECTION_CANCEL: seq={seq}; новое состояние сбора отменило ещё не отправленный A')
                return False
        before_down=getattr(self.gamepad,'a_down_count',None)
        delivered=self.gamepad.tap_a(self.stop_event,self.screen.focused)
        if token is not None:
            release=getattr(self.gamepad,'release_cursor',None)
            if callable(release):release()
        if token is not None and not delivered and before_down is not None and before_down==getattr(self.gamepad,'a_down_count',None):
            self.collection_cycle.unsent(token)
        if token is not None and delivered:self.say(f'COLLECTION_NEXT: {token}; клик отправлен, новое начало ещё требует подтверждения')
        after=self._net_view();node=self._net_node(after)
        state=after['state'] if after and after['ready'] else None
        self.say(f'CLICK_FEEDBACK: seq={seq}, delivered={bool(delivered)}, selected={state.selected if state else None}, used={node.used if node else None}, active={state.attempt_active if state else None}, cursor={getattr(self.bridge,"last_cursor_actual",None)}')
        return delivered

    def _activate_resource_click(self,next_attempt=False,optional_repeat=False,owned_repeat=False):
        binding=self.network_target
        if binding is None or self.click_busy or time.monotonic()<self.click_retry_at:return False
        if not self._click_ready(binding,next_attempt,owned_repeat=owned_repeat):return False
        self.click_busy=True
        attempted=False;opened_alt=False;selection_clicks=0
        try:
            frame,origin=self.screen.frame();candidate=self._fresh_click_candidate(frame)
            if candidate is None:
                now=time.monotonic()
                if self.cfg.get('debug_screenshots'):
                    node=self._net_node();key=(binding,node.used if node else None)
                    if key not in self.click_wait_saved:
                        if len(self.click_wait_saved)>32:self.click_wait_saved.clear()
                        self.click_wait_saved.add(key);self.save_debug(frame,'click_wait')
                if now-self.click_wait_note_at>=2:
                    self.click_wait_note_at=now;view=self._net_view();node=self._net_node(view)
                    self.say(f'CLICK_WAIT: ID={binding[1]}, осталось={3-node.used if node and node.used is not None else None}, selected={view["state"].selected if view else None}; свежая локальная точка отсутствует, ожидаю фоновое распознавание')
                return False
            if self._cycle_enabled() and candidate.emblem is not None and (optional_repeat
                or owned_repeat and self.cycle_authorized is not None and self.cycle_authorized[0]!='end'):
                self.say('EMBLEM_ONCE: повтор по ромбику запрещён без нового собственного окончания; ожидаю подтверждение или пропуск цели')
                return False
            self._neutral()
            if not self.bridge.alt_is_down():
                opened_alt=True;self.bridge_cmd('ALT_DOWN')
            if not self._wait_alt_state(True):return False
            frame,origin=self.screen.frame();candidate=self._fresh_click_candidate(frame)
            if candidate is None:return False
            if not self._click_ready(binding,next_attempt,owned_repeat=owned_repeat):return False
            self.bridge.cursor(origin[0]+int(candidate.click_x),origin[1]+int(candidate.click_y))
            if not GamepadInput.wait(.10,self.stop_event,self.screen.focused):return False
            if not self._wait_alt_state(True) or not self._click_ready(binding,next_attempt,owned_repeat=owned_repeat):return False
            # A zero selection between own attempts is not a new acquisition:
            # the existing own collection supplies the interaction authority.
            continuation=bool(next_attempt and self._net_gather_proof())
            if self._net_view()['state'].selected==0 and not owned_repeat:
                if not self._cursor_click_ready():return False
                if not self._tap_resource_point(frame,candidate,binding,'select'):return False
                selection_clicks+=1
                until=time.monotonic()+.65
                while self._focus_ok():
                    view=self._net_view()
                    if not view or not view['ready'] or view['flow']!=binding[0]:return False
                    if view['state'].selected==binding[1]:break
                    if view['state'].selected:return False
                    # Between own attempts 3438 selection may remain zero even
                    # after a valid click. A fresh own lease permits the second
                    # click without waiting for this optional selection echo.
                    if continuation and self._net_gather_proof():break
                    if time.monotonic()>=until:return False
                    if not GamepadInput.wait(.03,self.stop_event,self.screen.focused):return False
                # A can already have started an owned attempt; do not activate twice.
                if self._live_attempt(self._net_view()) and not owned_repeat:return True
                if not self._click_ready(binding,next_attempt,owned_repeat=owned_repeat):return False
                # Selection may change the camera/label or start native travel.
                # Never reuse its pre-A point for the activation press.
                frame,origin=self.screen.frame();candidate=self._fresh_click_candidate(frame)
                if candidate is None:return False
                self.bridge.cursor(origin[0]+int(candidate.click_x),origin[1]+int(candidate.click_y))
            if self._net_view()['state'].selected!=binding[1] and not (continuation and self._net_gather_proof()):return False
            # Reserve the request BEFORE pressing A. A partial delivery must
            # not be retried as though no input had reached the game.
            request_count=(self.next_attempt_click_tries if self.next_attempt_sent_used==self.next_attempt_pending else 0) if next_attempt else self.route_click_tries
            badge_first=candidate.emblem is not None and (owned_repeat or request_count==0)
            # The emblem toggles native approach/gather like F. One own result
            # grants one press; selection echo and delivery do not grant another.
            burst=1 if owned_repeat or badge_first or candidate.name!='Эфир' else 4
            sent=0
            for index in range(burst):
                if index:
                    if not GamepadInput.wait(.08,self.stop_event,self.screen.focused):break
                    if not self._click_ready(binding,next_attempt,reserved=attempted,owned_repeat=owned_repeat):break
                    frame,origin=self.screen.frame();fresh=self._fresh_click_candidate(frame)
                    if fresh is None:break
                    candidate=fresh
                if candidate.name=='Эфир' and not badge_first and not owned_repeat:
                    points=ether_click_points(candidate,frame.shape[1],frame.shape[0])
                    px,py=points[min(index,len(points)-1)]
                    candidate=replace(candidate,click_x=px,click_y=py)
                    self.bridge.cursor(origin[0]+px,origin[1]+py)
                    if not GamepadInput.wait(.06,self.stop_event,self.screen.focused):break
                    # The target can move on screen during native flight.
                    # Re-anchor after cursor settling, immediately before A.
                    frame,origin=self.screen.frame();probe=find_resource_near(frame,candidate)
                    if probe is None:break
                    px+=probe.box[0]-candidate.box[0];py+=probe.box[1]-candidate.box[1]
                    candidate=replace(probe,click_x=px,click_y=py)
                    self.bridge.cursor(origin[0]+int(px),origin[1]+int(py))
                if badge_first:
                    frame,origin=self.screen.frame();fresh=self._refresh_bound_candidate(frame,candidate)
                    if fresh is None or fresh.emblem is None:break
                    candidate=fresh;self.bridge.cursor(origin[0]+int(fresh.click_x),origin[1]+int(fresh.click_y))
                elif owned_repeat:
                    frame,origin=self.screen.frame();fresh=self._fresh_click_candidate(frame)
                    if fresh is None:break
                    candidate=fresh
                    self.bridge.cursor(origin[0]+int(fresh.click_x),origin[1]+int(fresh.click_y))
                if owned_repeat:
                    # SetCursorPos readback does not prove that the game has
                    # processed hover at that position. Settle AFTER the final
                    # move, then validate the same point in a new frame. Do not
                    # move it again immediately before the controller press.
                    point=(int(candidate.click_x),int(candidate.click_y));old_origin=origin
                    if not GamepadInput.wait(.06,self.stop_event,self.screen.focused):break
                    current,current_origin=self.screen.frame()
                    fresh=self._refresh_bound_candidate(current,candidate)
                    stable=fresh is not None and current_origin==old_origin
                    if stable and candidate.emblem is not None:
                        badge=fresh.emblem
                        stable=bool(badge and badge[0]+1<=point[0]<badge[0]+badge[2]-1
                                    and badge[1]+1<=point[1]<badge[1]+badge[3]-1)
                    elif stable:
                        stable=all(abs(a-b)<=3 for a,b in zip(candidate.box,fresh.box))
                    if not stable:
                        self.say('CLICK_REANCHOR: ресурс сместился после наведения; A не отправлен, следующая проверка заново найдёт точку')
                        break
                    candidate=replace(fresh,click_x=point[0],click_y=point[1]);frame=current;origin=current_origin
                if not self._wait_alt_state(True) or not self._click_ready(binding,next_attempt,reserved=attempted,owned_repeat=owned_repeat):break
                if self._cycle_enabled() and optional_repeat and candidate.emblem is not None:break
                # Any changed ID ends the burst. One caption must never
                # activate a neighbouring resource/NPC after a miss.
                selected=self._net_view()['state'].selected
                if selected!=binding[1] and not (selected==0 and continuation and self._net_gather_proof()):break
                if not self._cursor_click_ready():break
                if not attempted:
                    attempted=True
                    if next_attempt:
                        if self.next_attempt_sent_used!=self.next_attempt_pending:self.next_attempt_click_tries=0
                        self.next_attempt_click_tries+=1
                        self.next_attempt_sent_used=self.next_attempt_pending;self.next_attempt_wait_at=time.monotonic()
                    else:
                        self.route_click_tries+=1;self.route_click_sent_at=time.monotonic()
                        self.route_f_sent=True;self.route_active=True
                        if self.native_route_started_at is None:self.native_route_started_at=time.monotonic()
                self.candidate=candidate
                if not self._tap_resource_point(frame,candidate,binding,'repeat' if owned_repeat else 'activate'):
                    if self.cycle_request_cancelled:break
                    if self._focus_ok() and self.bridge.alt_is_down() and not self._cursor_click_ready():
                        self.say('Курсор сместился во время A: кнопка отпущена; следующий запрос заново проверит точку')
                        break
                    self.halt_reason='Клик начат, но отпускание/фокус не подтверждены';self.stop();return False
                sent+=1
            if sent:self.click_wait_since=None
            live=self._net_view()
            active=bool(live and live['state'] and live['state'].attempt_active)
            self.say(f'CLICK_RESOURCE: ID={binding[1]}, '+('поддержание собственного сбора' if owned_repeat else 'следующая попытка' if next_attempt else 'запуск/повтор пути')+f'; кликов {sent+selection_clicks}; active={active}; контекстный F не используется')
            return bool(sent or not owned_repeat and self._own_collection(live) is not None and active)
        finally:
            keep_cursor=bool(next_attempt and attempted and self.cfg.get('collection_cursor_hold',True)
                             and self._focus_ok() and self._net_gather_proof() and self.bridge.alt_is_down())
            if keep_cursor:self.collection_cursor_owned=True
            if opened_alt and not keep_cursor:
                self.bridge_cmd('ALT_UP')
                if self._focus_ok():self._wait_alt_state(False)
            self.click_busy=False
            self.click_retry_at=time.monotonic()+.35
            if not attempted and not optional_repeat and self._focus_ok():
                now=time.monotonic()
                if self.click_wait_since is None:self.click_wait_since=now
                elif now-self.click_wait_since>6 and self._net_gather_proof():
                    self._arm_view_recovery(now)
                elif now-self.click_wait_since>6:
                    self._begin_reacquire('Нет свежей точки ресурса для клика: возвращаю сохранённый ID вместо ожидания в воздухе')

    def _start_resource_route(self,restart_after_wings=False,repeat_click=False):
        if self.network is not None and self.target_confirmed and self._net_gather_proof():
            frame,_=self.screen.frame();self._net_resource(frame,read_flight(frame),time.monotonic());return True
        if not self.target_confirmed or self.fast_gather_seen or self.collecting_visible or not self._focus_ok():return False
        if restart_after_wings:
            if not self._wing_restart_ready():return False
        elif self.route_f_sent or self.route_active:
            if not (repeat_click and self._click_interaction_enabled() and self.route_click_tries<3):return False
        if repeat_click and not self._click_interaction_enabled():return False
        if restart_after_wings:self.route_click_tries=0
        self.f_disable();self.f_repeat_allowed=False
        self.route_f_pending=True;self.wing_route_restart_authorized=restart_after_wings
        try:
            if self._click_interaction_enabled():
                if not self._activate_resource_click(optional_repeat=repeat_click):return False
            elif not self.bridge_cmd('TAP_F'):return False
        finally:
            self.route_f_pending=False;self.wing_route_restart_authorized=False
        self.route_f_sent=True;self.route_active=True;self.wing_route_restart_pending=False;self.view_click_pending=False
        if not repeat_click:self.native_route_started_at=time.monotonic()
        action='Клик по выбранному ресурсу' if self._click_interaction_enabled() else 'Один F'
        self.say(action+(' после подтверждённого V: автопуть перезапущен' if restart_after_wings else ': штатный путь запущен')+('; при задержке допустим повтор клика' if self._click_interaction_enabled() else '; повтор до начала сбора запрещён'))
        return True

    def _check_route_damage(self,frame,now,panel=None,slots=None):
        if self.network is not None:return self._net_defense(now)
        resource=self.target_confirmed and self.target in self.cfg['target_names']
        roaming=(self.mode in ('SEARCH','ACQUIRE_WAIT') and self.cfg.get('ground_walk',True)
                 and self.probe is None and self.wing_close_pending is None)
        if (not self.cfg.get('protect_player',True) or not (resource or roaming)
            or self.mode not in ('SEARCH','ACQUIRE_WAIT','APPROACH','TAKEOFF','JUMP_RETRY','GATHER')
            or now<self.hp_next_defense or self.defense_cycles>=self.cfg.get('defense_max_cycles',6)
            or not self.health.pending(self.hp_handled_event,now)):return False
        if panel is None:panel=self._gather_panel(frame)
        if slots is None:slots=segment_count(frame)
        remaining=resource and (self.mode!='GATHER' or panel or slots is not None or resource_header_visible(frame))
        if resource and not remaining:
            name,_=selected_target(frame,tuple(self.cfg['target_names']),require_track=False)
            remaining=name==self.target
        state=self.health.state()
        if state['verified_at'] is None:return False
        self.say(f'Подтверждённое снижение HP во время {self.mode}: {state["damage_current"]}/{state["damage_maximum"]}, сейчас {state["current"]}/{state["maximum"]}; Tab и проверка агрессора')
        self._defend_and_resume(resume=remaining)
        return True

    def _service_wing_close(self,reading,now):
        if self.wing_close_pending is None:return False
        self._neutral()
        if self.wing_close_started is None:self.wing_close_started=self.wing_close_pending
        if now-self.wing_close_started>=6:
            if self.cfg.get('terrain_rescue_enabled',True):
                self.wing_close_pending=None;self.wing_close_started=None
                if self._start_terrain_recovery(now,reading,force_ground=True):return True
            self.say('За 6 с закрытие крыльев не подтверждено: остановка с явной ошибкой вместо ожидания');self.stop();return True
        if not reading.confirmed:
            if self.wing_absent_since is None:self.wing_absent_since=now
            if now-self.wing_absent_since>=.2:
                self.wing_close_pending=None;self.wing_close_started=None;self.resource_flight_owned=False
                self.say('Закрытие крыльев подтверждено отсутствием дуги');return False
            return True
        self.wing_absent_since=None
        elapsed=now-self.wing_close_pending
        if elapsed>=1.5 and self.wing_close_retries==0:
            # Retry only on a NEW still-visible flight arc, never blindly V.
            if self.bridge_cmd('END_AIR'):
                self.f_on=False;self.wing_close_retries=1;self.wing_close_pending=time.monotonic()
                self.say('Дуга всё ещё видна: один повтор закрытия крыльев')
        elif elapsed>=2.5 and self.wing_close_retries:
            if self.cfg.get('terrain_rescue_enabled',True):
                self.wing_close_pending=None;self.wing_close_started=None
                if self._start_terrain_recovery(now,reading,force_ground=True):return True
            self.say('Крылья всё ещё открыты после двух команд: остановка ввода вместо зависания');self.stop()
        return True

    def _resource_fast_tick(self,frame,reading,now,panel=None,slots=None):
        """Live resource UI must run even when OCR is slow or camera is moving."""
        self._adopt_network_collection()
        if self._service_emblem_acquisition(now):return True
        if self.mode=='VERIFY_NATIVE':return self._verify_visual_route(frame,reading,now)
        view=self._net_view() if self.network is not None else None
        if self._failed_collection_request(view,self._net_node(view) if view else None):
            self.return_to_search('COLLECTION_UNCONFIRMED: нет нижней панели и подтверждённого возобновления; пропускаю ресурс вместо остановки',frame,reading=reading,abandon=True)
            return True
        if self.network is not None:
            view=self._net_view();state=view['state'] if view and view['ready'] else None
            if (state and state.attempt_active and state.collecting is not None and state.started is not None
                and 0<=time.time()*1000-state.started<=2000 and self._own_collection(view) is None):
                self._neutral();return True
        if panel is None:panel=self._gather_panel(frame)
        if panel and not self.real_gather_panel_seen:panel=self._gather_panel(frame)
        if slots is None:slots=segment_count(frame)
        header=slots is not None or resource_header_visible(frame)
        if self.wing_close_pending is not None and (panel or self.target_confirmed and header):
            self.wing_close_pending=None;self.wing_close_retries=0;self.folded=False
            self.say('Плашка ресурса снова видна: отменён отложенный повтор закрытия крыльев')
        if self._service_wing_close(reading,now):return True
        if (self.network is not None and self.mode in ('SEARCH','ACQUIRE_WAIT')
            and not self.target_confirmed and self.probe is None and self.pending_probe is None
            and self.patrol_escape is None and reading.confirmed and now>=self.rescue_air_search_until):
            view=self._net_view()
            previous=view['state'].nodes.get(view['state'].collecting) if view and view['ready'] else None
            released=(previous and (self._stale_defense_lease(view,previous) or self._inactive_lease_ignored(view,previous) or previous.used==3
                      or not previous.visible and previous.removed_reason==4))
            if (view and view['ready'] and (released or view['state'].collecting is None and not view['state'].attempt_active)
                and not gathering_panel_pair(frame)):
                self._neutral()
                if self.bridge_cmd('END_AIR'):
                    self.f_on=False;self.resource_flight_owned=True
                    self.wing_close_pending=time.monotonic();self.wing_close_started=self.wing_close_pending
                    self.wing_close_retries=0;self.wing_absent_since=None
                    self.candidate=None;self.change_mode('SEARCH')
                    self.say('Крылья открыты вне сбора/манёвра: закрываю до ходьбы и выбора наземного ресурса')
                return True
        if self._view_recovery_tick(frame,reading,now):return True
        if self.mode=='REACQUIRE':
            self._neutral()
            if self.reacquire_until is not None and now>=self.reacquire_until:
                self.collecting_visible=False
                self.return_to_search('Повторный выбор ресурса не удался за 8 секунд: следующая цель',reading=reading)
                return True
            return False
        if (not self.target_confirmed or self.target not in self.cfg['target_names'] and self._net_node() is None
            or self.mode not in ('APPROACH','TAKEOFF','JUMP_RETRY','GATHER')):return False
        if self.network is None and enemy_hp(frame)[0]:
            self._begin_reacquire('Красная плашка вместо ресурса: выключаю F, повторно выбираю ресурс без Tab')
            return True
        if self._net_resource(frame,reading,now):return True
        if self.network is not None and self._net_gather_proof():
            node=self._net_node();slots=3-node.used;header=True
        self.collecting_visible=panel
        if reading.confirmed:
            self.last_flight_seen_at=now;self.last_flight_energy=reading.energy
            self.flight_attempted=True;self.resource_flight_owned=True
        if header:self.fast_header_seen=True
        if slots is not None:
            if self.real_gather_panel_seen and self.fast_last_slots is not None and slots<self.fast_last_slots:
                self.collection_activity_at=now
            self.fast_last_slots=slots
        paired=panel and not self.real_gather_panel_seen and self._accept_gather_panel(frame)
        valid_panel=panel and self.real_gather_panel_seen
        if not panel:self.panel_cleared=True
        if valid_panel:
            self.panel_last_seen=now;self.repeat_rearmed=False;self.collection_activity_at=now
            self.fast_gather_seen=True;self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
            self.f_enable()
        self.interrupts.update(valid_panel,slots,now,gather_result_full(frame) if valid_panel else None)
        if valid_panel or self.fast_gather_seen:
            self.probe=None;self.pending_probe=None
            if self.mode!='GATHER':
                self.change_mode('GATHER');self.missing_since=None
                self.say('Свежий кадр подтверждает сбор независимо от OCR дистанции')
        if self.network is not None and self._net_node() is not None:
            self.fast_absent_since=None;return False
        if panel or header:
            self.fast_absent_since=None;return False
        if not (self.fast_header_seen or self.fast_gather_seen or self.mode=='GATHER'):return False
        if self.fast_absent_since is None:self.fast_absent_since=now
        if now-self.fast_absent_since>=self.cfg.get('target_missing_seconds',.6):
            fresh,_=self.screen.frame()
            name,_=selected_target(fresh,tuple(self.cfg['target_names']),require_track=False)
            if name==self.target:
                self.fast_absent_since=None
                return False
            if name is not None:
                self._begin_reacquire('Свежая верхняя подпись сменилась: повторный выбор без закрытия крыльев')
                return True
            self.return_to_search('Свежий кадр: плашка/полоски и окно сбора исчезли',
                                  exhausted=True,reading=reading,frame_time=now)
            return True
        return False

    def _approach_fast_tick(self,frame,origin,reading,now):
        if (not self.target_confirmed or self.real_gather_panel_seen
            or self.mode not in ('APPROACH','TAKEOFF','JUMP_RETRY')):return False
        if self._gather_panel(frame):
            self._resource_fast_tick(frame,reading,now,panel=True);return True
        if self._click_interaction_enabled() and not self.route_f_sent:
            if self._start_resource_route():
                self.last_progress=now
                if self.resume_resource_id==self.network_target:self.resume_resource_id=None
            return True
        if (self.view_click_pending and self.view_recovery is not None
            and now>=self.view_recovery.settle_until and self._start_resource_route(repeat_click=True)):
            self.view_click_pending=False;return True
        if now>=self.distance_check_at:
            self.distance_check_at=now+.5
            view=self._net_view()
            relative=geometry(view['state'],self._net_node(view)) if view and view['ready'] else None
            if relative:value=relative['distance_m']
            elif self.network is None:value=read_target_distance(frame)
            else:
                with self.snapshot_lock:snapshot=self.snapshot
                valid=(snapshot is not None and now-snapshot[1]<=2 and snapshot[1]>=self.identity_valid_after
                       and snapshot[0].target_name==self.target)
                value=snapshot[0].distance_m if valid else None
            if relative and now-self.approach_note_at>2:
                self.say(f'Свежие XYZ: до ресурса {value:.1f} м, по высоте {relative["height_m"]:+.1f} м, возраст {relative["age"]:.2f} с')
            if value is not None:
                self.distance_live=value;self.distance_live_at=now
                if self.last_distance is None or value<self.last_distance-.3:
                    self.last_distance=value;self.last_progress=now
        distance=self.distance_live if self.distance_live_at is not None and now-self.distance_live_at<2 else self.last_distance
        if self.mode=='TAKEOFF':
            if reading.confirmed:
                if self._start_resource_route(restart_after_wings=True):
                    self.last_progress=now;self.change_mode('APPROACH')
            elif now-self.started>3.5:
                self.budget.failed_takeoff(now)
                self.return_to_search('Крылья не подтвердились: повтор V не отправляю',reading=reading)
            return True
        if self.mode=='JUMP_RETRY':
            if now-self.started>1.5:self.last_progress=now;self.change_mode('APPROACH')
            return True
        route_since=self.native_route_started_at if self.native_route_started_at is not None else self.started
        stalled=now-self.last_progress
        if now-self.approach_note_at>2:
            self.say(f'Контроль подхода: {distance} м, без сближения {stalled:.1f} с; нижней плашки ещё не было; '+self.budget.describe(now))
            self.approach_note_at=now
        if (self._click_interaction_enabled() and stalled>=2 and self.route_click_tries<3
            and self.route_click_sent_at is not None and now-self.route_click_sent_at>=2):
            if self._start_resource_route(repeat_click=True):
                self.say('Нет сближения: повторил безопасный клик по тому же ресурсу; таймер застревания сохранён')
                return True
        if now-route_since>max(60,self.cfg.get('approach_timeout',60)):
            self.return_to_search('Таймаут штатного подхода',reading=reading);return True
        threshold=max(1,self.cfg.get('approach_stall_seconds',6))
        if distance is not None and distance>6:threshold=max(12,threshold*2)
        due=(distance is not None and distance>3 and stalled>=threshold
             or now-route_since>=10 and stalled>2)
        if due and now>=self.approach_recovery_at:
            self.approach_recovery_at=now+1
            current=Observation(None,self.target,distance,False,0,False,None,'HIDDEN')
            self._recover(frame,origin,current,reading,now)
            return True
        return False

    def _patrol_escape_tick(self,frame,reading,now):
        if self.patrol_escape is None:return False
        if self.target_confirmed or self._gather_panel(frame):
            if self.cfg.get('terrain_rescue_enabled',True):
                self._neutral();self.patrol_escape=None
                self.say('Сбор/выбор ресурса появился: прекращаю только манёвр, крылья не трогаю')
                return False
            self._neutral();self.say('Сбор/выбор ресурса во время выхода: остановка манёвра без V');self.stop();return True
        action=self.patrol_escape.step(now,reading)
        if action.failed_takeoff:self.budget.failed_takeoff(now)
        if action.command:
            self._neutral()
            if not self.bridge_cmd(action.command):
                self.say('Манёвр отменён проверкой свежего кадра');self.patrol_escape=None;self.change_mode('SEARCH');return True
            if self.cfg.get('terrain_rescue_enabled',True):self.patrol_escape.since=time.monotonic()
            if action.command=='END_AIR':self.f_on=False
        elif action.drive:self._motion(action.drive)
        else:self._neutral()
        if action.stop:
            if self.cfg.get('terrain_rescue_enabled',True):
                self.say('Короткий выход не подтвердился: продолжаю восстановление вместо остановки сканера')
                self.patrol_escape=None;self.patrol_escape_after=now+30
                if self._start_terrain_recovery(now,reading,force_ground=True):return True
                self._neutral();self.change_mode('SEARCH');self.nav.abandon_goal(now,60);return True
            self.say(action.reason);self.stop();return True
        if action.done:
            self.say(action.reason);self.patrol_escape=None;self.change_mode('SEARCH')
            self.nav.pause(now);self.patrol_stall.reset(now)
        elif action.command:self.say(action.reason)
        return True

    def _map_input_ready(self,menu=False,popup=False):
        if self.stop_event.is_set() or not self._focus_ok() or self.map_teleport is None:return False
        view=self._net_view()
        if not view or not view['ready'] or self._own_collection(view) is not None:return False
        if self.target_confirmed or self.resource_hold:return False
        frame,_=self.screen.frame()
        if gathering_panel_pair(frame):return False
        if menu and not same_stamp(frame,self.map_menu_stamp):return False
        if popup:
            if self.map_popup_box is None or self.map_popup_stamp is None:return False
            current=title_stamp(frame,self.map_popup_box)
            if current is None:return False
            union=np.count_nonzero((current>0)|(self.map_popup_stamp>0))
            if np.count_nonzero((current>0)&(self.map_popup_stamp>0))/max(1,union)<.85:return False
        return True

    def _start_map_teleport(self,now):
        if self.map_teleport is not None:return True
        if now<self.map_return_after:
            self.no_yield.next_return=self.map_return_after;self.change_mode('SEARCH')
            self.say('MAP_RETURN: повтор отложен до окончания 5 минут; продолжаю поиск/спасение');return False
        if self.stop_event.is_set() or not self._focus_ok() or self.cfg.get('dry_run'):return False
        view=self._net_view();frame,_=self.screen.frame()
        if (not view or not view['ready'] or self._own_collection(view) is not None
            or gathering_panel_pair(frame) or self.resource_hold or self.target_confirmed):return False
        self._neutral();self.f_disable();self._stop_defense_motion()
        self.terrain_recovery=None;self.probe=None;self.pending_probe=None;self.patrol_escape=None
        self.wing_close_pending=None;self.wing_close_started=None;self._clear_view_recovery()
        self._release_collection_cursor()
        if self.bridge.alt_is_down():
            self.bridge_cmd('ALT_UP')
            if not self._wait_alt_state(False):return False
        self.map_teleport=MapTeleport(now,self.cfg.get('map_return_destination','Рабочий лагерь стального молота'),self.cfg.get('map_return_index',48),self.cfg.get('map_return_total',61))
        self.map_active=True;self.map_return_after=now+300;self.map_return_note=0
        self.map_menu_stamp=None;self.map_popup_stamp=None;self.map_popup_box=None
        self.map_origin_place=place_title(frame,self.minimap.bounds(frame))
        self.pitch.pause_return(now);self.change_mode('MAP_RETURN')
        self.say('MAP_RETURN: ищу '+self.map_teleport.destination+' по имени; повтор ближайшего свитка запрещён')
        return True

    def _map_teleport_tick(self,frame,reading,now):
        trip=self.map_teleport
        if trip is None:return False
        if self._map_failure_exit_tick(frame,now):return True
        if not self._focus_ok():self._neutral();return True
        if not self._map_input_ready():
            self.halt_reason='Телепорт отменён: сеть или собственный сбор требуют остановки UI';self.stop();return True
        self._neutral();evidence=map_evidence(frame,self.minimap.bounds(frame))
        arrived=False
        if trip.phase=='WAIT_TRANSFER' and evidence.usable:
            arrived=exact_name(place_title(frame,self.minimap.bounds(frame)),trip.destination)
        verified=same_stamp(frame,self.map_menu_stamp)
        observation=observe_map(frame,trip.destination,trip.phase,evidence.loading,arrived,evidence.usable,index=trip.index,
                                verified_map=verified,list_only=verified and trip.phase in ('FIND','WAIT_SCROLL'))
        if trip.phase=='WAIT_TRANSFER' and same_stamp(frame,self.map_menu_stamp):observation.opened=True
        if observation.opened and self.map_menu_stamp is None:
            self.map_menu_stamp=menu_stamp(frame)
            armed=self.bridge.send_guarded('MAP_UI_ARM',lambda:self._map_input_ready(menu=True)) if hasattr(self.bridge,'send_guarded') else False
            if not armed:trip.fail('не удалось подготовить ввод карты; проверьте транспорт управления')
            return True
        now=time.monotonic();action=trip.step(now,observation)
        sent=True
        if action.kind=='OPEN':
            sent=self.bridge.send_guarded('MAP',lambda:self._map_input_ready()) if hasattr(self.bridge,'send_guarded') else self.bridge_cmd('MAP')
        elif action.kind=='SCROLL':
            if self.gamepad is not None:
                self.gamepad.map_scroll_factor=action.scroll_scale;self.gamepad.map_scroll_strength=action.scroll_strength
                self.gamepad.map_scroll_seconds=action.scroll_seconds
            h,w=frame.shape[:2];origin=self.screen.frame()[1]
            self.bridge.cursor(origin[0]+round(w*.13),origin[1]+round(h*.5))
            command='MAP_SCROLL_UP' if action.direction>0 else 'MAP_SCROLL_DOWN'
            if hasattr(self.bridge,'send_guarded'):sent=self.bridge.send_guarded(command,lambda:self._map_input_ready(menu=True))
            else:sent=False
        elif action.kind in ('ROW','ICON','CONFIRM','CONFIRM_DIALOG'):
            fresh,origin=self.screen.frame();phase='FIND_ICON' if action.kind=='ICON' else 'FIND'
            check=observe_map(fresh,trip.destination,phase,index=trip.index)
            point=check.confirm if action.kind in ('CONFIRM','CONFIRM_DIALOG') else check.icon if action.kind=='ICON' else check.row
            valid=(point is not None and check.opened and math.dist(point,action.point)<=18)
            if action.kind in ('CONFIRM','CONFIRM_DIALOG'):valid=valid and check.popup and exact_name(check.destination,trip.destination)
            if action.kind=='CONFIRM_DIALOG':valid=valid and check.dialog
            if not valid:sent=False
            elif action.kind in ('CONFIRM','CONFIRM_DIALOG'):
                self.map_popup_box=check.popup_box;self.map_popup_stamp=title_stamp(fresh,check.popup_box)
                # Explicit map-only F: resource F guards are not bypassed anywhere else.
                sent=self.bridge.send_guarded('TAP_F',lambda:self._map_input_ready(menu=action.kind!='CONFIRM_DIALOG',popup=True)) if hasattr(self.bridge,'send_guarded') else False
            else:
                self.bridge.cursor(origin[0]+point[0],origin[1]+point[1])
                sent=self._cursor_click_ready() and self.gamepad.tap_ui_a(self.stop_event,self.screen.focused,lambda:self._map_input_ready(menu=True))
        if action.kind in ('OPEN','SCROLL','ROW','ICON','CONFIRM','CONFIRM_DIALOG'):
            detail=('; прокрутка='+action.scroll_mode+'; импульс='+str(round(action.scroll_seconds*action.scroll_scale,3))+' с' if action.kind=='SCROLL' else '')
            trip.sent(time.monotonic());self.say('MAP_RETURN: '+action.kind+'; передача='+str(sent)+'; назначение='+trip.destination+'; точка='+str(action.point)+detail)
            if not sent:
                self.save_debug(frame,'map_return_'+action.kind.lower())
                trip.fail('свежая проверка UI запретила действие; новый клик/свиток не отправляется')
        elif action.kind=='DONE':
            self.map_teleport=None;self.map_active=False;self.pitch.resume_return(now)
            self.bridge_cmd('STOP');self.return_exit_guard=False;self.exit_route=None
            self.no_yield.relocated(now);self.nav=Navigator(self.cfg);self.terrain_watch.reset(now)
            self.camera_alignment_due=None;self.change_mode('SEARCH');self.identity_valid_after=now
            self.say('MAP_RETURN: '+action.reason+'; восстанавливаю обзор перед движением')
            if not self._calibrate_camera('после телепорта в '+trip.destination):self.stop()
        elif action.kind=='FAILED':
            self._map_teleport_failed(observation,action.reason,now)
        elif now-self.map_return_note>=3:
            self.map_return_note=now;self.say('MAP_RETURN: '+trip.phase+'; ищу/проверяю '+trip.destination)
        return True

    def _map_failure_exit_tick(self,frame,now):return False

    def _map_teleport_failed(self,observation,reason,now):
        if observation.opened and self._map_input_ready(menu=True):self.bridge_cmd('MAP')
        self.halt_reason='MAP_RETURN: '+reason
        self.say(self.halt_reason);self.map_teleport=None;self.map_active=False;self.pitch.resume_return(now);self.stop()

    def _return_input_ready(self):
        if not self._focus_ok() or self.return_sequence is None:return False
        view=self._net_view()
        if not view or not view['ready']:return False
        frame,_=self.screen.frame()
        return (not gathering_panel_pair(frame) and not self.target_confirmed and not self.resource_hold
                and self._own_collection(view) is None)

    def _start_return(self,frame,reading,now,view):
        if not self._focus_ok() or self.cfg.get('dry_run') or self.mode=='DEFENSE':return False
        if gathering_panel_pair(frame) or self.return_panel_absent is None or now-self.return_panel_absent<3:return False
        state=view['state'];node=state.nodes.get(state.collecting)
        stamp=node.gather_time if node else state.started
        age=(time.time()*1000-stamp)/1000 if stamp is not None else None
        if state.attempt_active and age is not None and -.5<=age<30:return False
        if node and node.gather_time is not None:self.ignored_collection_lease=(view['flow'],node.actor,node.gather_time)
        self._neutral();self.f_disable();self._stop_defense_motion()
        self.terrain_recovery=None;self.probe=None;self.pending_probe=None;self.patrol_escape=None
        self.wing_close_pending=None;self.wing_close_started=None;self._clear_view_recovery()
        self.target=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False;self.candidate=None
        self.collection_cycle.reset();self._reset_resource_watch()
        self.return_sequence=ReturnSequence(now,reading.confirmed or self.budget.airborne)
        self.return_started=now;self.return_note=0;self.pitch.pause_return(now)
        self.change_mode('RETURN');self.say('NO_YIELD_RETURN: 3 минуты без собственного результата; останавливаю маршрут, посадка, один D-pad Down')
        return True

    def _finish_return(self,now,verified,reason):
        self._neutral();self.return_sequence=None;self.pitch.resume_return(now)
        if verified:self.no_yield.relocated(now)
        self.nav=Navigator(self.cfg);self.minimap.previous=None;self.minimap.previous_points=None
        self.terrain_watch=RecoveryWatch(self.cfg.get('terrain_rescue_seconds',90))
        self.patrol_stall.reset(now,clear_used=True);self.resource_flight_owned=False
        self.camera_alignment_due='после свитка возврата';self.camera_requested_at=now
        self.identity_valid_after=now;self.change_mode('SEARCH')
        self.return_exit_guard=True;self.return_exit_scan_at=now;self.return_exit_next=now
        self.exit_route=None;self.exit_place=None;self.exit_place_at=0
        self.exit_air_since=None;self.exit_fold_at=0;self.exit_folds=0
        self.exit_minimap.previous=None;self.exit_minimap.previous_points=None
        self.say('NO_YIELD_RETURN: '+reason+'; сначала ищу ресурс/безопасный выход, прямой патруль пока запрещён')

    def _return_tick(self,frame,reading,now,view):
        sequence=self.return_sequence
        if sequence is None:return False
        if not self._focus_ok() or not view or not view['ready']:self._neutral();return True
        if not self._return_input_ready():
            self._neutral();self.return_sequence=None;self.ignored_collection_lease=None
            self.pitch.resume_return(now);self.change_mode('SEARCH');self._adopt_network_collection()
            self.say('NO_YIELD_RETURN: появился собственный сбор; телепорт отменён без нового нажатия')
            return True
        evidence=map_evidence(frame,self.minimap.bounds(frame))
        action=sequence.step(now,reading.confirmed,evidence)
        if action.drive:
            if self._return_input_ready():self.gamepad.drive(action.drive.forward,action.drive.strafe,lifetime=action.drive.lifetime)
        elif action.command=='END_AIR':
            self._neutral()
            if self.bridge_cmd('END_AIR'):sequence.sent(time.monotonic())
        elif action.command=='RETURN':
            self._neutral();self._release_collection_cursor()
            if self.bridge.alt_is_down():
                self.bridge_cmd('ALT_UP')
                if not self._wait_alt_state(False):return True
            if not self._return_input_ready():return True
            if self.cfg.get('map_safe_return_enabled',False):
                self.return_sequence=None;self.pitch.resume_return(time.monotonic())
                self._start_map_teleport(time.monotonic());return True
            current,_=self.screen.frame();sequence.baseline=map_evidence(current,self.minimap.bounds(current))
            self.no_yield.attempted(time.monotonic())
            sent=self.gamepad.tap_dpad_down(self.stop_event,self.screen.focused,self._return_input_ready)
            sequence.sent(time.monotonic())
            self.say(f'NO_YIELD_RETURN: D-pad Down, передача={sent}; жду каст и перенос до 15 с, без стиков/A/F/Tab')
        else:self._neutral()
        if action.done:
            if action.failed_landing:
                self.return_sequence=None;self.no_yield.next_return=now+30
                self.pitch.resume_return(now);self.change_mode('SEARCH')
                self._start_terrain_recovery(now,reading,force_ground=True)
                self.say('NO_YIELD_RETURN: '+action.reason+'; продолжаю выход, следующая проверка не раньше 30 с')
            else:self._finish_return(now,action.verified,action.reason)
        elif now-self.return_note>=3:
            self.return_note=now
            self.say(f'NO_YIELD_RETURN: этап {sequence.phase}; ожидание {max(0,now-sequence.since):.1f} с, повтор свитка запрещён')
        return True

    def _no_yield_tick(self,frame,reading,now):
        if not self.cfg.get('no_yield_return_enabled',True) or self.network is None:return False
        view=self._net_view()
        if not self._focus_ok() or not view or not view['ready']:
            self.no_yield.pause();return self._return_tick(frame,reading,now,view)
        state=view['state'];result=state.last_own_result
        if self.no_yield_wall_start is None:self.no_yield_wall_start=int(time.time()*1000)
        credible=(result is not None and state.own is not None and state.last_own_result_used in (1,2,3)
                  and self.no_yield_wall_start-2000<=result[1]<=time.time()*1000+500)
        progress=self.no_yield.observe(now,(view['flow'],state.own),result if credible else None)
        if progress:
            self.return_grace_used=False;self.return_grace_until=0
            self.say('NO_YIELD: собственный результат сбора сбросил таймер отсутствия результата')
        if self.emblem_acquisition is not None and now<self.emblem_acquisition['until']:
            return False
        if gathering_panel_pair(frame):self.return_panel_absent=None
        elif self.return_panel_absent is None:self.return_panel_absent=now
        if self.return_sequence is not None:return self._return_tick(frame,reading,now,view)
        if self.no_yield.return_due(now) and not self.return_exit_guard:
            if not self.return_grace_used:
                self.return_grace_used=True
                route_at=self.native_route_started_at if self.native_route_started_at is not None else self.started
                age=now-route_at
                if self.target_confirmed and self.mode in ('APPROACH','TAKEOFF','VERIFY_NATIVE') and 0<=age<10:
                    self.return_grace_until=now+10-age
                    self.say('NO_YIELD_RETURN: даю только что начатому подходу до 10 секунд; новые выборы не продлевают отсрочку')
            if now<self.return_grace_until:return False
            if self._start_return(frame,reading,now,view):return self._return_tick(frame,reading,now,view)
        if (self.no_yield.rescue_due() and self._no_yield_rescue_allowed(now) and not self.return_exit_guard
            and self.mode in ('SEARCH','ACQUIRE_WAIT','PROBE','PATROL_ESCAPE')):
            if self._start_terrain_recovery(now,reading):
                self.no_yield.rescue_used=True
                self.say('NO_YIELD: 90 с без результата даже при движении; запускаю спасение')
                return True
        return False

    def _no_yield_rescue_allowed(self,now):return True

    def _return_exit_scan(self,now):
        if not self.return_exit_guard:return False
        if now>=self.return_exit_next:
            self.gamepad.drive(0,0,.35,0,lifetime=.12);self.return_exit_next=now+.8
        if now-self.last_note>=3:
            self.last_note=now
            self.say('RETURN_EXIT: проверяю место и ориентир для выхода через мост; прямой бег с площадки запрещён')
        return True

    def _return_exit_tick(self,frame,reading,now):
        if not self.return_exit_guard:return False
        if not self._focus_ok():self._neutral();return True
        view=self._net_view()
        if not view or not view['ready']:self._neutral();return True
        if (self.target_confirmed or self.resource_hold or gathering_panel_pair(frame)
            or self._own_collection(view) is not None):return False
        if reading.confirmed:
            self._neutral()
            self.exit_air_since=now
            if self.exit_folds<2 and now-self.exit_fold_at>=3:
                self.exit_folds+=1;self.exit_fold_at=now
                self.bridge_cmd('END_AIR')
            if now-self.last_note>=3:
                self.last_note=now;self.say('RETURN_EXIT: жду посадку; с открытыми крыльями маршрут мостика не запускаю')
            return True
        if self.exit_air_since is not None and now-self.exit_air_since<2:
            self._neutral();return True
        # Re-establish the working camera before following any ground route.
        if self.camera_alignment_due or self.pitch.returning:return False
        spec=self.cfg.get('return_exit_route',DEFAULT_EXIT)
        if not isinstance(spec,dict):self._return_exit_scan(now);return True
        if self.exit_route is None:
            self._neutral()
            if now>=self.exit_place_at:
                self.exit_place_at=now+5
                self.exit_place=place_title(frame,self.minimap.bounds(frame))
                self.say('RETURN_EXIT: место на миникарте: '+(self.exit_place.strip() or 'не распознано'))
            if not matches_place(self.exit_place or '',spec):
                if self.cfg.get('map_safe_return_enabled',False) and now-self.return_exit_scan_at>=8:
                    self._start_map_teleport(now);return True
                self._return_exit_scan(now);return True
            bounds=self.exit_minimap.bounds(frame);anchor=purple_anchor(frame,bounds)
            if anchor is None:self._return_exit_scan(now);return True
            if not self._camera_input_ready():return True
            self.exit_route=BridgeExit(now,anchor,bounds[2]-bounds[0],spec,self.cfg)
            self.say('RETURN_EXIT: узнал Штаб торговцев и кибелиск; сначала вверх-влево, затем налево через мост')
        radar=self.exit_minimap.observe(frame)
        anchor=purple_anchor(frame,radar.bounds,self.exit_route.anchor)
        action=self.exit_route.step(now,radar,anchor)
        if action.done:
            self._neutral();self.return_exit_guard=False;self.exit_route=None
            self.nav=Navigator(self.cfg);self.minimap.previous=None;self.minimap.previous_points=None
            self.terrain_watch.reset(now);self.patrol_stall.reset(now,clear_used=True)
            self.no_yield.relocated(now);self.identity_valid_after=now
            self.say('RETURN_EXIT: '+action.reason+'; возвращаю обычный поиск ресурсов');return True
        if action.drive:
            try:
                self.exit_route_driving=True;self._motion(action.drive)
            finally:self.exit_route_driving=False
        else:self._neutral()
        if now-self.last_note>=2:
            self.last_note=now;self.say('RETURN_EXIT: '+action.reason)
        return True

    def _scene_plan(self,frame,radar,reading,plan,now):
        host=self.scene_host;original_plan=plan
        if (host is None or self.cfg.get('dry_run') or self.mode!='SEARCH' or self.return_exit_guard
            or self.target_confirmed or self.resource_hold or self.collecting_visible or reading.confirmed
            or self.budget.airborne or self.camera_alignment_due or self.pitch.returning
            or abs(self.pitch.offset(now))>.015 or not self._focus_ok()):return plan
        if gathering_panel_pair(frame):return plan
        view=self._net_view() if self.network is not None else None
        if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None):return plan
        # Vertical resource searches and camera homing are not ground walking.
        exit_mode=False
        if self.cfg.get('ground_route_navigation',False):
            anchor=purple_anchor(frame,radar.bounds)
            if anchor is not None:
                self.camp_last_seen=now
                if self.camp_seen_since is None:self.camp_seen_since=now
                if now>=self.camp_exit_retry_after and now-self.camp_seen_since>=.5:
                    self.camp_exit_until=now+25;self.camp_exit_retry_after=now+55;self.camp_motion=0
                    self.nav.air_since=None;self.nav.scan_kind=None
                    self.say('CAMP_EXIT: рядом кибелиск; сначала ищу связный выход/дорогу, ресурсы за стеной временно не задают курс')
            else:self.camp_seen_since=None
            if now<self.camp_exit_until:
                if radar.motion_valid:self.camp_motion+=math.hypot(*radar.displacement)
                if now-self.camp_last_seen>1.5 and self.camp_motion>8:
                    self.camp_exit_until=0;self.nav=Navigator(self.cfg)
                    self.say('CAMP_EXIT: удалился от кибелиска по смещению миникарты; возвращаю цели ресурсов')
                else:exit_mode=True
            if exit_mode:plan=Drive(.6,reason='выход из области кибелиска')
        heading=radar.heading if radar.confidence>=.30 else None
        if abs(plan.pitch)>.001 or plan.restore_pitch or plan.flight_probe:return plan
        pitch=self.pitch.offset(now)
        if time.monotonic()>=self.scene_settle_until:
            host.offer(frame,time.monotonic(),heading,pitch,self.scene_camera_epoch)
            result=host.current(time.monotonic(),heading,pitch,self.scene_camera_epoch)
        else:result=None
        if self.nav.is_retreating(now) and not (result is not None and result.ground is not None and result.ground.routes):return replace(plan,lifetime=max(.65,plan.lifetime))
        if result is None and (exit_mode or now<self.ground_control_until):
            if self.scene_pilot.follower.missing_since is None:self.scene_pilot.follower.missing_since=now
            if host.error is None and now-self.scene_pilot.follower.missing_since<1.2:
                return Drive(reason='GROUND_ROUTE: короткая проверка нового кадра после поворота')
            if exit_mode:self.camp_exit_until=0
            return original_plan
        if result is not None:self.scene_pilot.follower.missing_since=None
        route_hint=None;scene_hint=None
        if self.analyzer is not None and result is not None and result.ground is not None:
            context='leave the shelter/kibelisk through a visible passage, then find resources' if exit_mode else 'follow an accessible road toward resources; avoid returning to a failed wall'
            self.analyzer.offer(result.source if result.source is not None else frame,result.ground,result.captured,result.revision,result.heading,result.pitch,context)
            hint=self.analyzer.current(frame,time.monotonic(),self.scene_camera_epoch,heading,pitch)
            if hint is not None:
                scene_hint=hint.answer['scene']
                route_hint=hint.answer['route_id'] if hint.answer['route_id']>=0 and hint.answer['scene'] in ('passage','open') else None
                if now-self.analyzer_note>=3:
                    self.analyzer_note=now
                    self.say('ANALYZER_PLAN: '+hint.answer['scene']+'; маршрут '+str(route_hint)+'; '+hint.answer['reason'].replace('\n',' ')+'; анализ '+str(round(hint.elapsed_ms))+' мс')
        energy=self.budget.energy if self.budget.can_start() else None
        action=self.scene_pilot.decide(plan,result,time.monotonic(),energy,host.error is not None,resource_nearby=bool(radar.markers),exit_mode=exit_mode,route_hint=route_hint,scene_hint=scene_hint)
        if result is not None and result.ground is not None and result.ground.routes and action.reason.startswith('GROUND_ROUTE: связный'):
            self.ground_control_until=now+1.2
        if action.reason and now-self.scene_note>=1.5:
            self.scene_note=now
            timing=(f'; анализ {result.elapsed_ms:.0f} мс, кадру {time.monotonic()-result.captured:.2f} с; '
                    + ' '.join(f'{name}=земля:{lane.free:.2f}/объект:{lane.solid:.2f}/край:{lane.edge:.3f}' for name,lane in zip(('L','C','R'),result.lanes))) if result else ''
            self.say('SCENE_NAV: '+action.reason+timing)
        if action.recalibrate and now>=self.scene_view_retry_after:
            self._neutral();self.scene_view_retry_after=now+2;self.scene_view_repair=True
            self.nav.air_since=None;self.nav.scan_kind=None;self.view_guard.force(now)
            self.say('SCENE_VIEW: преобладает небо; сначала возвращаю землю в обзор')
            return Drive()
        if action.escape:
            self._neutral();self.nav.exclude_goal(now,45)
            self.nav.retreat_bearing=(heading+180)%360 if heading is not None else None
            self.nav.retreat_pending=True;self.nav.retreat_until=now+8
            self.scene_avoid_bearing=heading;self.scene_avoid_until=now+30
            self.say('CLIFF_RETREAT: край подтверждён во всех полосах; 8 с отхода от него, опасное направление отложено на 30 с')
            return Drive(-.55,0,0,0,lifetime=.65,reason=action.reason)
        if action.fly:
            if self._start_terrain_recovery(time.monotonic(),reading):return None
        if action.abandon:
            if action.reason.startswith('GROUND_ROUTE:'):
                # A shelter-exit override must not replace the requested new
                # view with the same blocked forward plan on the next tick.
                # Turn in place once; do not retreat blindly at a possible edge.
                self._neutral();self.camp_exit_until=0
                self.nav.exclude_goal(time.monotonic(),60)
                self.nav.retreat_pending=False;self.nav.retreat_until=0;self.nav.retreat_bearing=None
                self.nav.air_since=None;self.nav.scan_kind=None
                return Drive(0,0,.42*self.scene_pilot.yaw_sign,0,lifetime=.45,yaw_lifetime=.45,reason=action.reason)
            self._neutral();self.nav.abandon_goal(time.monotonic(),60)
            return Drive(reason=action.reason)
        return action.drive or plan

    def _start_terrain_recovery(self,now,reading,force_ground=False,short=False):
        if (self.return_exit_guard or not self.cfg.get('terrain_rescue_enabled',True) or self.cfg.get('dry_run')
            or self.stop_event.is_set() or not self._focus_ok()):return False
        view=self._net_view() if self.network is not None else None
        if self.network is not None and (not view or not view['ready']):return False
        frame,_=self.screen.frame()
        view=self._net_view() if self.network is not None else None
        if self.network is not None and (not view or not view['ready']):return False
        if (self.target_confirmed or self.resource_hold or short and getattr(self,'caption_latch',None) is not None or gathering_panel_pair(frame)
            or view and (self._own_collection(view) is not None
                         or self._live_attempt(view))):return False
        self._neutral();self.f_disable();self.probe=None;self.pending_probe=None;self.patrol_escape=None
        self.wing_close_pending=None;self.wing_close_started=None
        self.target=None;self.candidate=None;self.collecting_visible=False
        energy=self.budget.energy if not force_ground and self.budget.can_start() and self._automatic_camera_enabled() else None
        recovery_type=AreaRecovery if self.cfg.get('area_search_rescue',False) and not short else TerrainRecovery
        self.terrain_recovery=recovery_type(now,energy,reading.confirmed,self.terrain_side,working_view_ms(self.cfg))
        self.rescue_click_after=0
        if self.cfg.get('area_search_rescue',False) and not short and self.working_area.area is None:
            self.say('WORKING_AREA: подтверждённой области с XYZ пока нет; ищу другую доступную область по ресурсам, высоту не выдумываю')
        self.terrain_recovery.long_attempt=not force_ground
        self.terrain_side*=-1;self.pitch.pause_return(now);self.view_guard=ViewGuard()
        self.camera_alignment_due=None;self.change_mode('RESCUE')
        if not force_ground:self.terrain_watch.attempted(now)
        self.say('TERRAIN_RESCUE: '+('энергия от 50%; подъём до 5 с, затем короткий перелёт' if self.terrain_recovery.fly
                                   else 'нет подтверждённого запаса 50%/раскрытия; наземный выход без повторных V'))
        return True

    def _track_working_area(self,reading):
        if not self._focus_ok():return
        view=self._net_view() if self.network is not None else None
        state=view['state'] if view and view['ready'] else None
        result=state.last_own_result if state else None
        node=state.nodes.get(result[0]) if result else None
        label=resource_names().get(node.template) if node else None
        ground=bool(label and label!='Эфир' and state.last_own_result_used in (1,2,3))
        if self.working_area.update(view,reading,int(time.time()*1000),ground):
            self.say('WORKING_AREA: сбор и реальное перемещение с устойчивой высотой подтверждены; сохранил рабочую область')
        now=time.monotonic()
        if (self.mode=='SEARCH' and self.terrain_recovery is None and not self.return_exit_guard
            and not reading.confirmed and now>=self.fall_retry_after and self.working_area.rapid_drop(int(time.time()*1000))):
            if self._start_terrain_recovery(now,reading):
                self.fall_retry_after=now+30;self.working_area.motion.clear()
                self.say('AREA_RESCUE: свежая Z быстро снизилась минимум на 8 м за 2 с; начинаю выход без ожидания долгого застревания')

    def _rescue_resource(self,frame,now):
        with self.snapshot_lock:snapshot=self.snapshot
        if snapshot is None or not 0<=now-snapshot[1]<=1.5 or snapshot[0].candidate is None:return False
        candidate=snapshot[0].candidate
        self.rescue_selecting=True
        try:
            if not self._allowed(candidate,now):return False
            self._neutral();self.rescue_click_after=now+2
            fresh,origin=self.screen.frame()
            candidate=find_resource_near(fresh,candidate)
            if candidate is None:return False
            sent=self.click_candidate(candidate,origin)
            pending=(sent or self.target_confirmed or self.resource_hold or self.mode=='VERIFY_NATIVE'
                     or self._own_collection() is not None or self.visual_route is not None)
            if pending:
                self.terrain_recovery=None;self.pitch.resume_return(time.monotonic())
                if self.mode=='RESCUE':self.change_mode('APPROACH' if self.target_confirmed else 'SEARCH')
                self.say('AREA_RESCUE: найден ресурс; передаю штатному подходу без V. Рабочая площадка ещё не объявлена подтверждённой')
                return True
            self.target=None;self.target_confirmed=False;self.resource_hold=False
            self.change_mode('RESCUE')
            self.cooldowns.append((candidate.name,candidate.click_x,candidate.click_y,time.monotonic()+8))
            return True
        finally:self.rescue_selecting=False

    def _terrain_recovery_tick(self,frame,reading,now,radar=None):
        recovery=self.terrain_recovery
        if recovery is None:return False
        if not self._focus_ok():self._neutral();return True
        view=self._net_view() if self.network is not None else None
        if self.network is not None and (not view or not view['ready']):self._neutral();return True
        if (self.target_confirmed or self.resource_hold or gathering_panel_pair(frame)
            or view and (self._own_collection(view) is not None
                         or self._live_attempt(view))):
            self._neutral();self.terrain_recovery=None;self.pitch.resume_return(now)
            if self.mode=='RESCUE':self.change_mode('SEARCH')
            self.say('TERRAIN_RESCUE: появился ресурс/сбор; прекращаю только спасательный манёвр без V')
            return False
        if radar is None:radar=self.minimap.observe(frame)
        heading=self.nav._heading(radar,now);bearing=None
        if isinstance(recovery,AreaRecovery) and recovery.phase=='SCAN' and now>=self.rescue_click_after:
            if self._rescue_resource(frame,now):return True
            now=time.monotonic()
        markers=[m for m in radar.markers if m.kind in ('gem','aether') and m.distance>2]
        if markers:
            marker=min(markers,key=lambda m:m.distance)
            bearing=math.degrees(math.atan2(marker.x-radar.center[0],radar.center[1]-marker.y))%360
        if bearing is None:bearing=self.working_area.bearing(view,int(time.time()*1000))
        if isinstance(recovery,AreaRecovery):
            gap=self.working_area.height_gap(view,int(time.time()*1000))
            action=recovery.step(now,reading,self.pitch.offset(now),heading,bearing,height_gap=gap)
        else:action=recovery.step(now,reading,self.pitch.offset(now),heading,bearing)
        if action.failed_takeoff:self.budget.failed_takeoff(now)
        if action.command:
            self._neutral()
            if self.bridge_cmd(action.command):recovery.sent(action.command,time.monotonic())
            else:recovery.denied(time.monotonic())
        elif action.drive:self._motion(action.drive)
        else:self._neutral()
        if action.levelled:
            self.pitch.set_working_baseline(time.monotonic())
            self.camera_last_calibrated=now;self.camera_aligned_revision=self.camera_search_revision
        if action.done:
            self.terrain_recovery=None;self.pitch.resume_return(now)
            self.change_mode('SEARCH');self.nav.abandon_goal(now,60);self.nav.pause(now)
            self.patrol_stall.reset(now,clear_used=True);self.patrol_escape_after=now+30
            if recovery.long_attempt:self.terrain_watch.attempted(now)
            else:self.terrain_watch.next_at=max(self.terrain_watch.next_at,now+5)
            self.identity_valid_after=now
            if isinstance(recovery,AreaRecovery) and reading.confirmed:
                self.rescue_air_search_until=now+25
                self.say('AIR_SEARCH: 25 с поиска с открытыми крыльями; автоматическое END_AIR после спасения запрещено')
            self.say('TERRAIN_RESCUE: '+action.reason)
            if action.camera_failed:
                if not self._automatic_camera_enabled() or not self._calibrate_camera('ограничение возврата камеры после спасения'):
                    self.halt_reason='Команды возврата камеры не выполнены';self.stop()
        elif action.reason and now-self.last_note>1.5:
            self.say('TERRAIN_RESCUE: '+action.reason);self.last_note=now
        return True

    def _check_world_map(self):
        self._neutral();self.f_disable();self.map_active=True
        try:
            frame,_=self.screen.frame();fix=self.region.locate(frame)
            if fix is None:
                if not self.bridge_cmd('MAP'):return
                if not GamepadInput.wait(.65,self.stop_event,self.screen.focused):return
                frame,_=self.screen.frame();fix=self.region.locate(frame)
            if fix is None:
                self.say('Карта/стрелка не подтверждена: остановка. Проверьте M, новый Lua v0.5 и эталон зоны; закройте карту вручную.')
                self.stop();return
            if not self.bridge_cmd('MAP'):return
            if not GamepadInput.wait(.55,self.stop_event,self.screen.focused):return
            frame,_=self.screen.frame()
            if self.region.matcher.register(frame) is not None:
                self.say('Большая карта осталась открытой: остановка ввода, закройте M вручную.')
                self.stop();return
            distance=((fix.goal[0]-fix.position[0])**2+(fix.goal[1]-fix.position[1])**2)**.5
            interval=min(4 if fix.outside else self.cfg.get('world_map_check_seconds',12),max(1.5,distance/30))
            self.region.next_check=time.monotonic()+interval
            bearing=fix.bearing if self.region.spec.get('north_up',True) else None
            self.nav.route(bearing,'возврат в зону по карте' if fix.outside else 'точка маршрута по карте',fix.outside or bearing is None)
            self.say(f'Карта: положение ({fix.position[0]:.0f},{fix.position[1]:.0f}), персонаж {fix.character_heading:.0f}°, '+
                     ('снаружи, возвращаюсь в зону' if fix.outside else 'внутри зоны, продолжаю маршрут'))
            self.minimap.previous=None;self.minimap.previous_points=None
            self.identity_valid_after=time.monotonic()
            with self.snapshot_lock:self.snapshot=None
        finally:
            self.map_active=False;self.nav.pause(time.monotonic())

    def _motion(self,plan):
        if self.cfg.get('dry_run'):return
        if self.return_exit_guard and not self.exit_route_driving:
            plan=replace(plan,forward=0,strafe=0)
        if self.gamepad and self._focus_ok():
            if self.network is not None:
                view=self._net_view()
                pending=view['state'].nodes.get(view['state'].collecting) if view else None
                ignored=bool(pending and self.ignored_collection_lease==(view['flow'],pending.actor,pending.gather_time))
                if (not view or not view['ready'] or self._own_collection(view) is not None
                    or self._live_attempt(view) and not ignored):
                    self._neutral();return
            if self.collecting_visible or (self.resource_hold and self.mode=='GATHER'):
                if any(abs(v)>.01 for v in (plan.forward,plan.strafe,plan.yaw,plan.pitch)) and time.monotonic()-self.last_hold_note>2:
                    self.say('Блокировка: окно/режим сбора запрещает команды стиков');self.last_hold_note=time.monotonic()
                self._neutral();return
            if self.resource_hold:
                plan=replace(plan,forward=0,strafe=0,yaw=0)
            if (not plan.tilted_motion and math.hypot(plan.forward,plan.strafe)>.01
                and abs(self.pitch.offset(time.monotonic()))>.009):
                self._neutral();self._restore_pitch();return
            self.gamepad.drive(plan.forward,plan.strafe,plan.yaw,plan.pitch,lifetime=plan.lifetime,yaw_lifetime=plan.yaw_lifetime)
            if (abs(plan.pitch)>.01 and not self.pitch.returning
                and self.mode in ('SEARCH','ACQUIRE_WAIT','PROBE')):
                self.camera_search_revision+=1
            if not self.pitch_observed:self.pitch.apply(plan.pitch,time.monotonic(),plan.lifetime)
            return True

    def _neutral(self):
        if self.gamepad:self.gamepad.reset()
        self.pitch.neutral(time.monotonic())

    def _restore_pitch(self):
        self.nav.air_since=None;self.nav.scan_kind=None
        self.pitch.restore(time.monotonic())

    def _request_probe(self,now):
        self._neutral()
        if (self.nav.goal is None or not self.cfg.get('flight_probe_enabled',True)
            or not self.cfg.get('ground_walk',True) or not self.cfg.get('camera_scan',True)
            or not self.budget.can_probe(self.cfg.get('flight_probe_min_percent',18))):
            self.nav.abandon_goal(now,60);self._restore_pitch();return
        self.pending_probe=self.nav.goal
        self._restore_pitch()

    def _probe_step(self,frame,origin,obs,radar,reading,now):
        probe=self.probe
        if probe is None:return
        if self.collecting_visible:
            self._neutral()
            if obs.target_name in self.cfg['target_names']:
                self.target=obs.target_name;self.target_confirmed=True;self.resource_hold=True
                self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                self.probe=None;self.change_mode('GATHER');self.f_enable();self._restore_pitch()
            else:
                if not hasattr(probe,'panel_since'):probe.panel_since=now
                if now-probe.panel_since>5:
                    self.say('Окно сбора видно, но имя не подтверждено: остановка без движения');self.stop()
            return
        if radar.motion_valid:
            probe.goal.x+=radar.displacement[0];probe.goal.y+=radar.displacement[1]
        matches=[m for m in radar.markers if m.kind==probe.goal.kind and math.hypot(m.x-probe.goal.x,m.y-probe.goal.y)<35]
        if matches:probe.goal=min(matches,key=lambda m:math.hypot(m.x-probe.goal.x,m.y-probe.goal.y))
        if (probe.phase not in ('CLOSE','WAIT_CLOSE') and obs.candidate
            and self._allowed(obs.candidate,now)):
            if obs.candidate.name!='Эфир' and reading.confirmed:
                probe.ground_candidate=obs.candidate
                self._neutral();probe.phase_to('CLOSE',now)
                self.say('Наземный ресурс найден после подъёма: сначала завершаю пробный полёт, затем выбираю ресурс')
                return
            self._neutral()
            if self.click_candidate(obs.candidate,origin):
                self.probe=None;self.pending_probe=None;return
            self.target_confirmed=False;self.resource_hold=False;probe.phase_to('CLOSE',now)
            self.change_mode('PROBE')
        desired=math.degrees(math.atan2(probe.goal.x-radar.center[0],radar.center[1]-probe.goal.y))%360
        heading=self.nav._heading(radar,now)
        if math.hypot(probe.goal.x-radar.center[0],probe.goal.y-radar.center[1])<5:desired=heading if heading is not None else desired
        action=probe.step(now,reading,self.pitch.offset(time.monotonic()),heading,desired)
        if action.failed_takeoff:self.budget.failed_takeoff(now)
        if action.command:
            self._neutral();self.bridge_cmd(action.command)
            if action.command=='END_AIR':self.f_on=False
        elif action.drive:self._motion(action.drive)
        else:self._neutral()
        if action.stop:
            if self.cfg.get('terrain_rescue_enabled',True):
                self.probe=None;self.pending_probe=None
                if self._start_terrain_recovery(now,reading,force_ground=True):return
                self._neutral();self.change_mode('SEARCH');return
            self.say(action.reason);self.stop();return
        if action.done:
            ground=getattr(probe,'ground_candidate',None)
            if ground is not None:
                fresh=find_resource_near(frame,ground)
                self.probe=None;self.pending_probe=None;self.change_mode('SEARCH')
                if fresh is not None:
                    self.say('Крылья закрыты: выбираю наземный ресурс, найденный во время подъёма')
                    if not self.click_candidate(fresh,origin):self._acquire_miss(fresh,time.monotonic())
                    return
            self.say(action.reason+'; закрытие/возврат наклона, затем отход')
            self.nav.goal=probe.goal;self.nav.abandon_goal(now,60)
            self.probe=None;self.pending_probe=None;self.target=None;self.target_confirmed=False;self.resource_hold=False
            self.change_mode('SEARCH');self._restore_pitch()
        elif action.reason and now-self.last_note>.7:
            self.say(action.reason);self.last_note=now

    def _allowed(self,candidate,now):
        if self.mode=='SEARCH' and now<self.defense_evade_until:return False
        if now<self.camp_exit_until and not self.rescue_selecting:return False
        if candidate.name not in self.cfg['target_names']:return False
        if not self.rescue_selecting and not self.policy.allows(candidate.name):return False
        if candidate.name=='Эфир' and not self.budget.can_start():
            if now-self.last_energy_note>4:
                self.say(self.budget.describe(now)+'; эфир отложен, ищу доступный наземный ресурс')
                self.last_energy_note=now
            return False
        self.cooldowns=[p for p in self.cooldowns if p[3]>now]
        return not any(n==candidate.name and self._cooldown_blocks(candidate,x,y) for n,x,y,until in self.cooldowns)

    def _wait_alt_state(self,desired,seconds=.6):
        if not self._wait_keyboard_alt_state(desired,seconds):return False
        if desired:
            begin=getattr(self.gamepad,'begin_cursor',None)
            return begin(self.stop_event,self.screen.focused) if callable(begin) else True
        release=getattr(self.gamepad,'release_cursor',None)
        if callable(release):release()
        return True

    def _wait_keyboard_alt_state(self,desired,seconds=.6):
        check=getattr(self.bridge,'alt_is_down',None)
        if not callable(check):
            self.say('Нет проверки фактического Alt: A/F не отправляю');self.stop();return False
        until=time.monotonic()+seconds
        while self._focus_ok():
            if bool(check())==desired:return True
            if time.monotonic()>=until:break
            if not GamepadInput.wait(.04,self.stop_event,self.screen.focused):return False
        if self._focus_ok():
            sync=getattr(self.bridge,'resync_receiver',None)
            if callable(sync):
                self._neutral()
                self.say('Alt не подтвердился: один повтор команды состояния после синхронизации Lua; A/F/V не повторяю')
                if sync(self.stop_event,self.screen.focused):
                    command='ALT_DOWN' if desired else 'ALT_UP'
                    if self.bridge_cmd(command):
                        until=time.monotonic()+seconds
                        while self._focus_ok():
                            if bool(check())==desired:
                                self.say('Состояние Alt восстановлено после одного повтора');return True
                            if time.monotonic()>=until:break
                            if not GamepadInput.wait(.04,self.stop_event,self.screen.focused):return False
            self.receiver_ready=False
            self.halt_reason='Lua: фактический Alt не '+('зажат' if desired else 'отпущен')+'; проверь G9 и активный профиль G HUB'
            self.say('Alt фактически не '+('зажат' if desired else 'отпущен')+
                     ': A/F заблокированы. Проверьте приёмник Lua, физический G9 и активный профиль AION2.')
            self.stop()
        return False

    def _preflight_receiver(self):
        if self.cfg.get('dry_run'):return True
        self._neutral()
        until=time.monotonic()+10
        if not self.screen.focused():self.say('Переключись в AION2: сначала проверю Lua, движение ещё не начинается')
        while not self.stop_event.is_set() and not self.screen.focused():
            if time.monotonic()>=until:
                self.halt_reason='Проверка Lua не началась: окно AION2 не активно';self.say(self.halt_reason);return False
            if self.stop_event.wait(.05):return False
        result=check_receiver(self.bridge,self.stop_event,self.screen.focused,self.say)
        self.receiver_ready=result.ok
        if not result.ok:
            self.halt_reason=result.reason
            self.say('СТАРТ ОТМЕНЁН: '+result.reason+'. Патруль, камера, F и V не запускались')
            return False
        self.say('Lua готов: фактическое нажатие и отпускание Alt подтверждены. Это не ACK для остальных команд')
        return True

    def _visual_route_allowed(self,candidate):
        if not self.network or not self.cfg.get('visual_route_hold',False):return False
        view=self._net_view();proof=self.visual_selection
        return bool(view and view['ready'] and not view['state'].selected and proof
                    and (self.resume_resource_id is None or self.resume_resource_id[0]==view['flow'])
                    and proof[:3]==(view['flow'],0,candidate.name) and self.acquisition_clicked_at is not None
                    and proof[3]>=self.acquisition_clicked_at and 0<=time.monotonic()-proof[3]<=3)

    def _start_visual_route(self,candidate,origin,already_activated=False):
        if not self._visual_route_allowed(candidate) or not self._focus_ok():return False
        if already_activated:
            fresh=candidate;burst=0;sent=1
        else:
            frame,origin=self.screen.frame();fresh=find_resource_near(frame,candidate) if candidate.glyph is not None else None
            if fresh is None or not self._wait_alt_state(True):return False
            burst=1 if fresh.emblem is not None or candidate.name!='Эфир' else 4
            sent=0
        for index in range(burst):
            if index:
                if not GamepadInput.wait(.08,self.stop_event,self.screen.focused):break
                if self._own_collection() is not None or not self._visual_route_allowed(candidate):break
                frame,origin=self.screen.frame();fresh=find_resource_near(frame,fresh)
                if fresh is None:break
                if not (resource_header_visible(frame) or segment_count(frame) is not None):break
            if burst>1:
                px,py=ether_click_points(fresh,frame.shape[1],frame.shape[0])[index]
            else:px,py=fresh.click_x,fresh.click_y
            self.bridge.cursor(origin[0]+int(px),origin[1]+int(py))
            if not GamepadInput.wait(.06,self.stop_event,self.screen.focused) or not self._visual_route_allowed(candidate):break
            if self._own_collection() is not None:break
            current,origin=self.screen.frame();probe=find_resource_near(current,fresh)
            if probe is None:break
            if burst==1 and fresh.emblem is not None:
                if probe.emblem is None:break
                px,py=probe.click_x,probe.click_y
            else:px+=probe.box[0]-fresh.box[0];py+=probe.box[1]-fresh.box[1]
            fresh=probe
            self.bridge.cursor(origin[0]+int(px),origin[1]+int(py))
            if not self._visual_route_allowed(candidate) or self._own_collection() is not None:break
            if not self._cursor_click_ready():return False
            if not self.gamepad.tap_a(self.stop_event,self.screen.focused):return False
            sent+=1
        if self._own_collection() is not None:return self._adopt_network_collection()
        if not sent:return False
        now=time.monotonic();view=self._net_view()
        if not view or not view['ready']:return False
        if view['state'].selected:
            if not self._selected_resource(view,candidate.name) or not self._bind_resource_candidate(fresh):return False
            self.route_f_sent=True;self.route_active=True;self.route_click_tries=1
            self.route_click_sent_at=now;self.native_route_started_at=now;self.last_progress=now
            self.change_mode('APPROACH')
            return True
        if not self._visual_route_allowed(candidate):return False
        self.visual_route=dict(flow=view['flow'],until=now+12,maximum=now+35,distance=None,name=candidate.name,selection_after=self.network_selection_after,note_at=now)
        self.pitch.pause_return(now)
        self.target=candidate.name;self.candidate=fresh;self.target_confirmed=False;self.resource_hold=True
        self.probe=None;self.pending_probe=None;self.change_mode('VERIFY_NATIVE')
        self.say('Свежая верхняя плашка ресурса подтверждена, сетевого ID ещё нет: клик активации отправлен; сохраняю штатный путь без стиков/крыльев')
        return True

    def _release_visual_route(self):
        if self.visual_route is not None:
            self.visual_route=None;self.pitch.resume_return(time.monotonic())

    def _verify_visual_route(self,frame,reading,now):
        lease=self.visual_route
        if lease is None:self.change_mode('SEARCH');self.resource_hold=False;return False
        self._neutral();view=self._net_view()
        if not view or not view['ready']:return True
        if view['flow']!=lease['flow']:
            self.halt_reason='Соединение сменилось при подтверждении подхода';self.stop();return True
        with self.snapshot_lock:snapshot=self.snapshot
        if snapshot is not None and 0<=now-snapshot[1]<=2 and snapshot[0].target_name==self.target:
            distance=snapshot[0].distance_m
            if distance is not None and (lease['distance'] is None or distance<lease['distance']-.3):
                lease['distance']=distance;lease['until']=max(lease['until'],min(lease['maximum'],now+8))
        if now<lease['until']:
            if now-lease.get('note_at',now)>=2:
                lease['note_at']=now
                self.say(f'Штатный подход сохраняю: дистанция {lease["distance"]} м; ожидаю свой сбор, не включаю патруль')
            return True
        # A genuine own start is handled before this method by adoption.
        if not self._cancel_autopath():return True
        self._release_visual_route()
        if reading.confirmed and self.bridge_cmd('END_AIR'):
            self.resource_flight_owned=True;self.wing_close_pending=now;self.wing_close_started=now
            self.wing_close_retries=0;self.wing_absent_since=None
        candidate=self.candidate;self.resource_hold=False;self.target_confirmed=False
        self.target=None;self.candidate=None;self.nav.abandon_goal(now,45);self._restore_pitch();self.change_mode('SEARCH')
        if candidate:self.cooldowns.append((candidate.name,candidate.click_x,candidate.click_y,now+30))
        self.say('Подход по визуальному ресурсу не подтвердился: ограниченный отказ от цели, продолжаю поиск')
        return True

    def _bind_resource_candidate(self,candidate):
        self.target=candidate.name;self.candidate=candidate;self.target_confirmed=True;self.missing_since=None
        self.reacquire_until=None;self.acquire_failures=0
        self.patrol_stall.reset(time.monotonic(),clear_used=True)
        self.resource_hold=True;self._reset_resource_watch(verified_header=True)
        return self.network is None or self._net_claim()

    def click_candidate(self,candidate,origin,refresh=True,retry=False):
        if self.emblem_acquisition is not None:
            self._service_emblem_acquisition(time.monotonic());return True
        self.pitch.pause_return(time.monotonic())
        try:return self._click_candidate_impl(candidate,origin,refresh,retry)
        finally:self.pitch.resume_return(time.monotonic())

    def _acquire_caption_matches(self,frame,candidate):return True

    def _click_candidate_impl(self,candidate,origin,refresh=True,retry=False):
        if self.cfg.get('dry_run'):
            self.say(f'НАБЛЮДЕНИЕ: {candidate.name}, точка ({candidate.click_x},{candidate.click_y})');return False
        if not self.gamepad:raise RuntimeError('Виртуальный Xbox не подключён')
        if self.network is not None and self._own_collection() is not None:
            self._adopt_network_collection();return self.target_confirmed
        if self._urgent_damage_pending():return False
        self._neutral();self.f_disable()
        self.real_gather_panel_seen=False;self.f_repeat_allowed=False;self.wing_route_restart_pending=False
        if not self._focus_ok():return False
        if not retry:
            self.target=candidate.name;self.target_confirmed=False;self.folded=False
            self.flight_attempted=False;self.jump_attempted=False;self.reselected=False
            self.last_distance=None;self.last_segments=None;self.one_segment_armed=False
            self.interrupts.reset();self.panel_cleared=False
            self.defense_cycles=0
            self.health.begin_gather()
        self.change_mode('ACQUIRE')
        self.network_selection_after=int(time.time()*1000)
        self.bridge_cmd('ALT_DOWN')
        selected=False;prepared_click_route=False;launched=False;activated_on_select=False;visual_started=False
        try:
            if not self._wait_alt_state(True):return False
            if not GamepadInput.wait(.16,self.stop_event,self.screen.focused):return False
            frame=None
            if refresh:
                fresh=None
                for attempt in range(3):
                    if self._urgent_damage_pending():return False
                    frame,origin=self.screen.frame()
                    self.panel_cleared=not gathering_panel(frame)
                    fresh=find_resource_near(frame,candidate)
                    if fresh is None and candidate.name=='Эфир':
                        options=fast_ether_candidates(frame,('Эфир',))
                        cx=candidate.box[0]+candidate.box[2]/2;cy=candidate.box[1]+candidate.box[3]/2
                        options=[c for c in options if math.hypot(c.box[0]+c.box[2]/2-cx,c.box[1]+c.box[3]/2-cy)<=frame.shape[0]*.18]
                        if options:fresh=min(options,key=lambda c:(c.box[0]+c.box[2]/2-cx)**2+(c.box[1]+c.box[3]/2-cy)**2)
                    if fresh is None and candidate.glyph is None:
                        fresh=find_world_resource(frame,(candidate.name,))
                    if fresh is not None:break
                    if attempt<2 and not GamepadInput.wait(.12,self.stop_event,self.screen.focused):return False
                if fresh is None:
                    self.say('Три свежих кадра после Alt без подписи: откладываю клик, продолжаю сближение');return False
                candidate=fresh
            h=self.current_size[1] if self.current_size else 1440
            offsets=(0,round(h*.010),-round(h*.008)) if candidate.name=='Эфир' else (0,round(h*.009))
            points=[(candidate.click_x,candidate.click_y)]
            bx,by,bw,bh=map(int,candidate.box)
            caption=(bx+bw//2,by+bh+max(18,round(h*(.035 if candidate.name=='Эфир' else .010))))
            if abs(caption[0]-candidate.click_x)+abs(caption[1]-candidate.click_y)>4:
                points.append(caption)
            points.extend((candidate.click_x,candidate.click_y+offset) for offset in offsets[1:])
            if self.network is not None:
                gaps=[max(6,min(12,round(bh*.6))),max(14,round(h*.022)),max(18,round(h*.035))] if candidate.name=='Эфир' else [max(6,min(12,round(bh*.6))),max(18,round(h*.010))]
                points=(list(ether_click_points(candidate,self.current_size[0] if self.current_size else 2560,h)) if candidate.name=='Эфир' and self._click_interaction_enabled()
                        else list(dict.fromkeys((bx+bw//2,by+bh+gap) for gap in gaps)))
                if candidate.emblem is not None:points.insert(0,(candidate.click_x,candidate.click_y))
            owned_during_select=False
            for index,(px,py) in enumerate(points):
                if not self._focus_ok() or self._urgent_damage_pending():return False
                if self.network is not None and index:
                    if self._own_collection() is not None:owned_during_select=True;break
                    current=self._net_view()
                    if self._selected_resource(current,candidate.name):selected=True;break
                    if current and current['ready'] and current['state'].selected and current['state'].selection_time>=self.network_selection_after:
                        self.say('Клик выбрал другой/неподтверждённый ID: повтор на нём запрещён');break
                    fresh_frame,origin=self.screen.frame()
                    fresh=find_resource_near(fresh_frame,candidate)
                    if fresh is None:break
                    px+=fresh.box[0]-candidate.box[0];py+=fresh.box[1]-candidate.box[1]
                x=origin[0]+int(px);y=origin[1]+int(py)
                self.bridge.cursor(x,y)
                if not GamepadInput.wait(.12,self.stop_event,self.screen.focused):return False
                if not self._wait_alt_state(True):return False
                if self.network is not None and index==0 and candidate.emblem is not None:
                    current_frame,origin=self.screen.frame();probe=find_resource_near(current_frame,candidate)
                    if probe is None or probe.emblem is None:return False
                    candidate=probe;px,py=probe.click_x,probe.click_y
                    self.bridge.cursor(origin[0]+int(px),origin[1]+int(py))
                if not index:
                    if self.network is not None:self.network_selection_after=int(time.time()*1000)
                    self.acquisition_clicked_at=time.monotonic()
                if not index and not self._acquire_caption_matches(frame,candidate):return False
                # OCR/cursor preparation may take a second. A private start
                # received during it supersedes EVERY pending acquisition A.
                before_click=self._net_view() if self.network is not None else None
                if self._own_collection(before_click) is not None or self._live_attempt(before_click):
                    owned_during_select=True;break
                if not self._cursor_click_ready():return False
                if not self.gamepad.tap_a(self.stop_event,self.screen.focused):
                    live=self._net_view()
                    if self._own_collection(live) is not None or self._live_attempt(live):
                        owned_during_select=True;break
                    return False
                if (self._cycle_enabled() and candidate.emblem is not None
                    and candidate.emblem[0]<=px<candidate.emblem[0]+candidate.emblem[2]
                    and candidate.emblem[1]<=py<candidate.emblem[1]+candidate.emblem[3]):
                    activated_on_select=True
                    if self.network is not None:
                        view=self._net_view()
                        self.emblem_acquisition={'candidate':candidate,'flow':view['flow'] if view else None,
                            'owner':view['state'].own if view else None,'clicked':time.monotonic(),
                            'after':self.network_selection_after,'until':time.monotonic()+12}
                    self.say('EMBLEM_ROUTE: один клик по ромбику уже запрашивает подход/сбор; второго клика активации не будет')
                if not GamepadInput.wait(.20,self.stop_event,self.screen.focused):return False
                if self.network is not None:
                    until=time.monotonic()+2.5
                    miss_until=time.monotonic()+.6
                    header_hint=False
                    if self.cfg.get('visual_route_hold',False):
                        current_frame,_=self.screen.frame()
                        header_hint=resource_header_visible(current_frame) or segment_count(current_frame) is not None
                    while self._focus_ok() and not self._urgent_damage_pending():
                        view=self._net_view()
                        if self._own_collection(view) is not None:owned_during_select=True;break
                        if before_click and before_click['ready'] and before_click['flow']==view['flow']:
                            prior=before_click['state'];node=prior.nodes.get(prior.selected)
                            if (prior.selected and prior.selected==view['state'].selected and node and node.visible
                                and node.used!=3 and resource_names().get(node.template)==candidate.name
                                and (self.resume_resource_id is None or self.resume_resource_id==(view['flow'],prior.selected))):
                                # A on an already-selected node is the route command.
                                # The game need not emit a second selection event.
                                activated_on_select=True;selected=True
                                self.network_selection_after=min(self.network_selection_after,prior.selection_time)
                                break
                        if self._selected_resource(view,candidate.name):selected=True;break
                        if self._visual_route_allowed(candidate):break
                        if time.monotonic()>=miss_until:
                            state=view['state'] if view and view['ready'] else None
                            fresh_id=state and state.selected and state.selection_time>=self.network_selection_after
                            node=state.nodes.get(state.selected) if state else None
                            unknown=fresh_id and state.selected not in state.npcs and state.selected not in state.players and (node is None or node.template is None)
                            if not unknown and not (header_hint and state and not state.selected):break
                        if time.monotonic()>=until:break
                        if not GamepadInput.wait(.03,self.stop_event,self.screen.focused):return False
                elif refresh:
                    frame,_=self.screen.frame();name,_=selected_target(frame,tuple(self.cfg['target_names']))
                    if name is not None:
                        if name not in self.cfg['target_names']:
                            self.say('Верхняя плашка не подтверждает разрешённый ресурс');break
                        confirmed=replace(candidate,name=name)
                        if not self._allowed(confirmed,time.monotonic()):break
                        if name!=candidate.name:
                            self.say(f'Дальняя подпись: {candidate.name}; верхняя плашка уточнила: {name}')
                        candidate=confirmed;selected=True
                else:selected=True
                if selected or owned_during_select:
                    candidate=replace(candidate,click_x=px,click_y=py);break
                if self._visual_route_allowed(candidate):break
                if activated_on_select and self.emblem_acquisition is not None:break
            if not selected and not owned_during_select:
                if activated_on_select and self.emblem_acquisition is not None and not self._visual_route_allowed(candidate):
                    self.target_confirmed=False;self.resource_hold=False;self.change_mode('VERIFY_EMBLEM')
                    self.say('EMBLEM_PENDING: A уже отправлена; жду выбор/профиль/свой старт без повторного клика и без отмены маршрута')
                    return True
                visual_started=(self._start_visual_route(candidate,origin,already_activated=True)
                                if self._cycle_enabled() and activated_on_select else self._start_visual_route(candidate,origin))
                if not visual_started:
                    view=self._net_view();state=view['state'] if view and view['ready'] else None
                    self.say(f'Выбор не подтверждён: ID={state.selected if state else None}, профиль={bool(state and state.selected in state.nodes)}, свежая верхняя плашка={self.visual_selection[2] if self.visual_selection else None}; ввода движения нет до нового поиска')
                    return False
            if self._click_interaction_enabled() and not owned_during_select and not visual_started:
                if not self._bind_resource_candidate(candidate):return False
                prepared_click_route=True
                if activated_on_select and (candidate.name!='Эфир' or self._cycle_enabled()):
                    self.route_f_sent=True;self.route_active=True;self.native_route_started_at=time.monotonic();launched=True
                    self.route_click_tries=1;self.route_click_sent_at=time.monotonic()
                    self.say('CLICK_RESOURCE: первый клик по выбранному ID отправлен; при задержке возможны повторы')
                else:launched=self._start_resource_route()
        finally:self.bridge_cmd('ALT_UP')
        if not self._focus_ok() or not self._wait_alt_state(False):return False
        if visual_started:self.emblem_acquisition=None;return True
        if owned_during_select:
            self.emblem_acquisition=None
            self._adopt_network_collection()
            return self.target_confirmed
        if not prepared_click_route:
            # Legacy F is only sent after Alt has actually been released.
            if not self._bind_resource_candidate(candidate):return False
            launched=self._start_resource_route()
        if not launched and (not self._click_interaction_enabled() or not self._focus_ok()):return False
        if self.mode=='REACQUIRE':return True
        if launched and self.resume_resource_id==self.network_target:self.resume_resource_id=None
        self.emblem_acquisition=None
        self.identity_valid_after=time.monotonic()
        self.last_progress=time.monotonic();self.change_mode('GATHER' if self.real_gather_panel_seen else 'APPROACH')
        self.say(f'{candidate.name}: цель подтверждена; '+('штатный подход запущен один раз' if launched else 'жду свежую точку для единственного запуска кликом'))
        self._restore_pitch()
        return True

    def _service_emblem_acquisition(self,now):
        pending=self.emblem_acquisition
        if pending is None:return False
        if self.click_busy:return True
        if self.stop_event.is_set() or not self._focus_ok():self._neutral();return True
        view=self._net_view()
        if not view or not view['ready']:self._neutral();return True
        if (view['flow']!=pending['flow'] or pending['owner'] is not None and view['state'].own!=pending['owner']):
            self.emblem_acquisition=None;self.target_confirmed=False;self.resource_hold=False;self.nav.finish_goal(now);self.change_mode('SEARCH');return False
        if self._own_collection(view) is not None:
            self.emblem_acquisition=None;self._adopt_network_collection();return False
        if self._live_attempt(view):self._neutral();return True
        candidate=pending['candidate'];self.network_selection_after=pending['after']
        if self._selected_resource(view,candidate.name):
            if self._bind_resource_candidate(candidate):
                self.route_f_sent=True;self.route_active=True;self.native_route_started_at=pending['clicked']
                self.route_click_tries=1;self.route_click_sent_at=pending['clicked']
                self.emblem_acquisition=None;self.identity_valid_after=now;self.last_progress=now
                self.change_mode('APPROACH');self._restore_pitch()
                self.say('EMBLEM_PENDING: поздний выбор подтверждён; сохраняю уже запущенный подход, второго A/F нет')
                return True
            self.target_confirmed=False;self.resource_hold=False;self.change_mode('VERIFY_EMBLEM')
        if now<pending['until']:self._neutral();return True
        self.emblem_acquisition=None;self.target=None;self.candidate=None;self.target_confirmed=False;self.resource_hold=False
        self.cooldowns.append((candidate.name,candidate.click_x,candidate.click_y,now+8))
        self.nav.pause(now);self.nav.goal_started=now;self.nav.air_since=None;self.nav.scan_kind=None
        self.change_mode('SEARCH');self._restore_pitch()
        self.say('EMBLEM_PENDING: 12 с без подтверждённого выбора/старта; клик не повторён, возвращаю поиск')
        return True

    def _can_abandon_resource(self):
        if self.cfg.get('preserve_owned_resource',True) and self._owned_resource_remaining():return False
        view=self._net_view();binding=self.abandoning_binding
        stale=self._stale_defense_lease(view,self._net_node(view)) or self._failed_collection_request(view,self._net_node(view))
        if stale:
            frame,_=self.screen.frame()
            if gathering_panel_pair(frame):return False
        return bool(self._focus_ok() and binding and view and view['ready']
                    and binding==self.network_target and view['flow']==binding[0]
                    and (self.network_owner is None or view['state'].own==self.network_owner)
                    and (not view['state'].attempt_active or stale) and view['state'].collecting in (None,binding[1]))

    def return_to_search(self,reason,frame=None,exhausted=False,reading=None,frame_time=None,abandon=False):
        if not abandon:return self._return_to_search_impl(reason,frame,exhausted,reading,frame_time)
        self.abandoning_binding=self.network_target
        try:return self._return_to_search_impl(reason,frame,exhausted,reading,frame_time,True)
        finally:self.abandoning_binding=None

    def _return_to_search_impl(self,reason,frame=None,exhausted=False,reading=None,frame_time=None,abandon=False):
        node=self._net_node() if self.network is not None else None
        if abandon and self.cfg.get('preserve_owned_resource',True) and self._owned_resource_remaining():
            self._neutral();self._clear_view_recovery()
            self.click_wait_since=None;self.next_attempt_wait_at=None
            self.target_confirmed=True;self.resource_hold=True;self.change_mode('GATHER')
            now=time.monotonic()
            if now-self.collection_guard_note_at>=2:
                self.collection_guard_note_at=now
                self.say('COLLECTION_GUARD: ресурс ещё имеет попытки; потеря точки не разрешает END_AIR или отмену пути')
            return
        if abandon and not self._can_abandon_resource():
            self._adopt_network_collection();return
        if not abandon and self.target_confirmed and node is not None and node.visible and (node.used is None or node.used<3) and not self._stale_defense_lease(self._net_view(),node):
            if not self.real_gather_panel_seen and self.native_route_started_at is not None and time.monotonic()-self.native_route_started_at>60:
                if self._recover_resource_wait(frame,reading,time.monotonic(),'approach'):return
                self.say('За 60 с сбор не начался: остановка с сохранением выбранного ресурса, без повторного F');self.stop();return
            self._neutral();self.change_mode('GATHER' if self.real_gather_panel_seen else 'APPROACH')
            self.say('Сеть ещё показывает оставшиеся попытки: ресурс сохранён, поиск камерой не запускаю')
            if self.real_gather_panel_seen:self.f_enable()
            return
        if not abandon and self.target_confirmed and not self.network_exhausted:
            fresh,_=self.screen.frame()
            live_panel=self._gather_panel(fresh)
            started=self.fast_gather_seen or self.mode=='GATHER' or self.collecting_visible
            alive=live_panel or started and (segment_count(fresh) is not None or resource_header_visible(fresh))
            if alive:
                if live_panel:
                    self.collecting_visible=True;self.fast_gather_seen=True
                    self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                self._neutral();self.change_mode('GATHER');self.f_enable()
                self.say('Возврат отменён: свежий кадр всё ещё показывает ресурс/сбор; крылья сохраняю')
                return
        if not abandon and self.collecting_visible and self.target_confirmed and not exhausted:
            self._neutral();self.change_mode('GATHER');self.f_enable()
            self.say('Окно сбора видно: возврат к патрулю и движение запрещены');return
        was_aether=self.target=='Эфир'
        reuse_view=bool(exhausted and was_aether and self._prepare_next_ether_view(frame,time.monotonic()))
        stamp=time.monotonic() if frame_time is None else frame_time
        recent_air=(self.last_flight_seen_at is not None and stamp-self.last_flight_seen_at<=1.2
                    and (self.last_flight_energy is None or self.last_flight_energy>1))
        collected_air=self.network is None and was_aether and (self.mode=='GATHER' or self.fast_gather_seen)
        self._neutral()
        # A full result stripe is not depletion. Keep aether wings open until
        # the resource itself disappears; never toggle V from sky colours.
        ended_air=False
        known_air=(reading is not None and reading.confirmed) or recent_air or collected_air
        if known_air and (self.target_confirmed or self.resource_flight_owned) and not self.folded and (exhausted or was_aether or self.resource_flight_owned):
            if self.bridge_cmd('END_AIR'):
                self.folded=True;self.f_on=False;ended_air=True
                self.wing_close_pending=time.monotonic();self.wing_close_started=self.wing_close_pending;self.wing_close_retries=0
                self.wing_absent_since=(self.wing_close_pending if reading is not None and not reading.confirmed else None)
            else:
                self._neutral();return
        if ended_air:self._release_collection_cursor()
        else:self.f_disable()
        if not exhausted and (self.mode in ('APPROACH','JUMP_RETRY','TAKEOFF') or abandon):
            if not self._cancel_autopath(allow_inactive_collection=abandon):return
        self.say(reason)
        now=time.monotonic()
        if abandon and self.network_target is not None:
            self.resource_retry_after={b:t for b,t in self.resource_retry_after.items() if t>now}
            self.resource_retry_after[self.network_target]=now+45
            if node and node.gather_time is not None:self.abandoned_lease=(*self.network_target,node.gather_time)
            if node and self._failed_collection_request(self._net_view(),node):self.ignored_collection_lease=(*self.network_target,node.gather_time)
        self._clear_view_recovery()
        if exhausted:self.node_count+=1
        if self.candidate:
            self.cooldowns.append((self.candidate.name,self.candidate.click_x,self.candidate.click_y,now+(12 if exhausted else 30)))
        if exhausted:self.nav.finish_goal(now)
        else:self.nav.abandon_goal(now,60)
        if frame is not None and not exhausted:self.save_debug(frame,'failed')
        self.target=None;self.candidate=None;self.target_confirmed=False;self.reacquire_until=None
        self.resource_hold=False;self.collecting_visible=False;self.interrupts.reset();self.resume_resource_id=None
        self._reset_resource_watch()
        if exhausted:self.post_gather_until=time.monotonic()+(.2 if reuse_view else .8)
        if exhausted and not reuse_view and self._automatic_camera_enabled() and (self.pitch.returning or self.pitch.failed or abs(self.pitch.offset(time.monotonic()))>.009):
            self.camera_alignment_due='после сбора эфира';self.camera_requested_at=time.monotonic()
        self.missing_since=None;self.change_mode('SEARCH')
        if not reuse_view:self._restore_pitch()

    def _clear_view_recovery(self):
        self.view_recovery=None;self.view_click_pending=False

    def _arm_view_recovery(self,now):
        if self.network_target is None:return
        if self.view_recovery is None or self.view_recovery.binding!=self.network_target:
            self.view_recovery=ResourceViewRecovery(self.network_target,now+12,now+1)
            self.say('Нет результата кликов: до 12 с на смену точек/ракурса; срок не сбрасывается новым выбором')

    def _view_recovery_tick(self,frame,reading,now):
        if not self._click_interaction_enabled() or self.camera_in_progress or self.mode=='DEFENSE':return False
        view=self._net_view()
        if not view or not view['ready'] or not self._focus_ok():return False
        own=self._own_collection(view);state=view['state']
        if own is not None and self._cycle_enabled() and self._cycle_observe(view,frame) is None:
            self._clear_view_recovery();return False
        if own is not None:
            pending=self.next_attempt_wait_at is not None or self.click_wait_since is not None
            repairing=self.view_recovery is not None and self.mode=='GATHER'
            if state.attempt_active or own.used not in (1,2) or not (pending or repairing):
                self._clear_view_recovery();return False
        if self.mode not in ('REACQUIRE','APPROACH','GATHER'):return False
        if self.mode=='GATHER' and own is None:return False
        if self.view_recovery is None and self.target_confirmed:
            if own is not None:
                pending_at=self.next_attempt_wait_at if self.next_attempt_wait_at is not None else self.click_wait_since
                if own.used in (1,2) and pending_at is not None and now-pending_at>=2:self._arm_view_recovery(now)
            elif self.native_route_started_at is not None:
                relative=geometry(state,self._net_node(view))
                distance=relative['distance_m'] if relative else None
                if distance is None and self.distance_live_at is not None and 0<=now-self.distance_live_at<=2:distance=self.distance_live
                elapsed=now-self.native_route_started_at;stalled=now-self.last_progress
                near=distance is not None and distance<=8 and elapsed>=2 and stalled>=2
                unresponsive=elapsed>=5 and stalled>=4
                if near or unresponsive:self._arm_view_recovery(now)
        recovery=self.view_recovery
        if recovery is None:return False
        if recovery.binding!=self.network_target:
            self._clear_view_recovery();return False
        if now>=recovery.until:
            self.return_to_search('Ракурс/клики не помогли за 12 с: пропускаю этот ресурс на 45 с',frame,reading=reading,abandon=True)
            return True
        if own is not None and self.cfg.get('native_cursor_chord',True):
            if recovery.point_attempt_at is None and self._fresh_click_candidate(frame) is not None:
                before=self.owned_click_count;self.f_enable()
                if self.owned_click_count>before:recovery.point_attempt_at=time.monotonic()
                return True
            if recovery.point_attempt_at is not None and now-recovery.point_attempt_at<1:return True
        if now<recovery.settle_until:return True
        if now<recovery.next_at or recovery.step>=len(VIEW_PULSES) or self.click_busy or self._urgent_damage_pending():return False
        yaw,pitch,seconds=VIEW_PULSES[recovery.step]
        self._neutral()
        try:
            self.gamepad.drive(0,0,yaw,pitch,lifetime=seconds)
            if pitch:self.camera_search_revision+=1
            if not GamepadInput.wait(seconds,self.stop_event,self.screen.focused):return True
        finally:self._neutral()
        stamp=time.monotonic();recovery.step+=1;recovery.next_at=stamp+.7;recovery.settle_until=stamp+.20
        self.identity_valid_after=stamp;self.reacquire_next=stamp+.20
        # A click is harmless during native travel. Each new viewpoint may
        # immediately try it again without resetting path/stall deadlines.
        self.route_click_tries=min(self.route_click_tries,1)
        self.route_click_sent_at=stamp-2;self.click_retry_at=stamp+.20;self.view_click_pending=True
        if own is not None:
            self.next_attempt_click_tries=0;self.next_attempt_wait_at=stamp-2
        self.say(f'Небольшой сдвиг камеры {recovery.step}/{len(VIEW_PULSES)}: ищу свежую точку того же ресурса, затем клик')
        return True

    def _begin_reacquire(self,reason):
        self.collection_cycle.reset();self.cycle_authorized=None;self.cycle_ui_note=None
        if self.network_target is not None:self.resume_resource_id=self.network_target
        self._neutral();self.f_disable()
        self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
        self.f_repeat_allowed=False;self.route_active=False;self.real_gather_panel_seen=False;self.wing_route_restart_pending=False;self.interrupts.reset()
        self.identity_valid_after=time.monotonic();self.reacquire_until=self.identity_valid_after+8
        if self._click_interaction_enabled() and self.network_target is not None:
            self._arm_view_recovery(self.identity_valid_after)
            self.reacquire_until=self.view_recovery.until
        self.reacquire_next=self.identity_valid_after;self.change_mode('REACQUIRE');self.say(reason)

    def _reacquire_step(self,frame,origin,obs,now):
        self._neutral()
        if self._view_recovery_tick(frame,read_flight(frame),now):return
        if self.reacquire_until is not None and now>=self.reacquire_until:
            self.return_to_search('Ресурс после смены цели не найден',reading=read_flight(frame));return
        if now<self.reacquire_next:return
        self.reacquire_next=now+.4
        candidate=find_resource_near(frame,self.candidate) if self.candidate is not None else None
        if candidate is None and obs.candidate is not None and obs.candidate.name==self.target:
            candidate=obs.candidate
        if candidate is None:return
        deadline=self.reacquire_until
        if not self.click_candidate(candidate,origin,retry=True):
            self.change_mode('REACQUIRE');self.reacquire_until=deadline
            self.reacquire_next=time.monotonic()+.5

    def _acquire_miss(self,candidate,now):
        self.f_disable();self.real_gather_panel_seen=False;self.wing_route_restart_pending=False
        self.acquire_failures+=1
        self.target=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
        self.f_repeat_allowed=False;self.route_active=False
        if self.acquire_failures>=3:
            self.cooldowns.append((candidate.name,candidate.click_x,candidate.click_y,now+3))
            self.acquire_failures=0
        self.candidate=None;self.change_mode('SEARCH');self.nav.pause(now)
        self.say('Выбор не подтверждён: цель миникарты сохранена, продолжаю подход и повторное распознавание')

    def _cancel_autopath(self,allow_inactive_collection=False):
        # Neutral reports alone do not cancel a route already owned by the game.
        # A short manual movement requests cancellation before the next patrol.
        if allow_inactive_collection and not self._can_abandon_resource():return False
        if not allow_inactive_collection and self.network is not None and self._own_collection() is not None:
            self._neutral();return False
        fresh,_=self.screen.frame()
        panel=gathering_panel_pair(fresh) if allow_inactive_collection else self._gather_panel(fresh)
        if panel or self.fast_gather_seen and not allow_inactive_collection:
            self._neutral();self.collecting_visible=panel;self.change_mode('GATHER')
            if panel:
                self.fast_gather_seen=True;self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
            self.f_enable();return False
        if self.cfg.get('dry_run') or not self.gamepad or not self._focus_ok():return False
        try:
            if allow_inactive_collection and not self._can_abandon_resource():return False
            if not allow_inactive_collection and self.network is not None and self._own_collection() is not None:return False
            self.gamepad.drive(-.35,0,0,0,lifetime=.25)
            if GamepadInput.wait(.20,self.stop_event,self.screen.focused):
                self.route_active=False;return True
            return False
        finally:self._neutral()

    def _net_selected_aggressor(self):
        view=self._net_view()
        if not view or not view['ready'] or self.network_attacker is None:return False
        state=view['state']
        return attack_reason(state,self.network_attacker,int(time.time()*1000)) is None

    def _stop_defense_motion(self):
        keeper=self.defense_motion;self.defense_motion=None
        if keeper:keeper.close()

    def _defense_motion_allowed(self):
        if not self._focus_ok() or self.network_defense is None:return False
        view=self._net_view();episode=self.network_defense
        return bool(view and view['ready'] and view['flow']==episode.flow
                    and view['state'].own==episode.owner and not view['state'].attempt_active
                    and self._own_collection(view) is None)

    def _begin_network_defense(self,resume):
        if self.network_defense is not None or not self._focus_ok() or self.cfg.get('dry_run'):return
        view=self._net_view()
        if not view or not view['ready'] or self.network_attacker is None:return
        now=time.monotonic();resource=self.target if resume and (self.target in self.cfg['target_names'] or self._net_node(view) is not None) else None
        resource_id=self.network_target[1] if resource and self.network_target else None
        self._release_visual_route()
        translation=(0.,0.)
        frame,_=self.screen.frame()
        keep=(not resume and self.mode=='SEARCH' and not self.collecting_visible
              and not read_flight(frame).confirmed and self.gamepad is not None)
        if keep and hasattr(self.gamepad,'current_translation'):
            translation=self.gamepad.current_translation()
        if self.view_recovery is not None and self.view_recovery.paused_at is None:self.view_recovery.paused_at=now
        self.network_defense=NetworkDefense(self.network_attacker,view['flow'],view['state'].own,
                                           now,bool(resource),resource,resource_id,max_tabs=self.cfg.get('defense_tab_limit',3))
        node=view['state'].nodes.get(resource_id)
        if resource_id is not None and node and node.gather_time is not None:
            self.defense_interrupted=(view['flow'],resource_id,int(time.time()*1000))
        recent_air=(self.last_flight_seen_at is not None and now-self.last_flight_seen_at<2)
        airborne=(read_flight(frame).confirmed or resource=='Эфир' and (self.fast_gather_seen or self.real_gather_panel_seen)
                  or self.resource_flight_owned and recent_air)
        self.defense_air_view=(AirDefenseView(now,self.pitch.offset(now))
            if airborne and self.cfg.get('defense_air_search',True) and self._automatic_camera_enabled() else None)
        self.defense_camera_until=now+2 if self.defense_air_view is None and abs(self.pitch.offset(now))>.05 else None
        if self.defense_air_view is not None:
            self._stop_defense_motion()
            self.say('DEFENSE_VIEW: персонаж в воздухе; перед Tab около 2 с камеры вниз, без движения и V')
        if self.defense_camera_until is not None:
            self._restore_pitch();self._stop_defense_motion()
            self.say('Перед Tab возвращаю рабочий наклон: при взгляде в небо наземный моб может не выбираться')
        self.pitch.pause_return(now)
        self.defense_cycles+=1
        self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
        self.f_repeat_allowed=False;self.real_gather_panel_seen=False;self.wing_route_restart_pending=False
        self.route_active=False;self.identity_valid_after=now;self.interrupts.reset();self.change_mode('DEFENSE')
        if sum(abs(x) for x in translation)>.05 and self.defense_camera_until is None:
            self.defense_motion=TranslationKeeper(self.gamepad,translation,self._defense_motion_allowed)
            self.defense_motion.start()
            self.say('Защита на ходу: сохраняю уже начатое наземное движение; камеру не кручу')
        else:self._neutral()
        self.f_disable()
        if self.bridge.alt_is_down():self.bridge_cmd('ALT_UP')
        profile='получен' if self.network_attacker in view['state'].npcs else 'не попал в захват; используем подтверждённый удар'
        self.say(f'Агрессор ID={self.network_attacker}; профиль: {profile}. Проверяю совпадение выбранного ID, не HP/плашку духа')

    def _finish_network_defense(self,success,reason=''):
        episode=self.network_defense
        if episode is None:return
        air_view=self.defense_air_view
        self._stop_defense_motion();self._neutral()
        self.network_defense=None;self.network_attacker=None;self.defense_camera_until=None;self.defense_air_view=None
        view=self._net_view()
        if episode.resource_id is not None:
            if episode.interrupted_at is not None:
                self.defense_interrupted=(episode.flow,episode.resource_id,episode.interrupted_at)
            elif (self.defense_interrupted and self.defense_interrupted[:2]==(episode.flow,episode.resource_id)
                  and view and view['ready'] and view['flow']==episode.flow and view['state'].own==episode.owner
                  and view['state'].collecting==episode.resource_id and view['state'].attempt_active
                  and view['state'].selected in (0,episode.resource_id)):
                self.defense_interrupted=None
        if view and view['ready']:
            stamp=view['state'].attacks.get(episode.attacker,0)
            self.attacker_handled[episode.attacker]=max(self.attacker_handled.get(episode.attacker,0),stamp)
            self.network_hit_handled=max(self.network_hit_handled,stamp)
        now=time.monotonic();self.pitch.resume_return(now)
        if self.view_recovery is not None and self.view_recovery.paused_at is not None:
            self.view_recovery.until+=max(0,now-self.view_recovery.paused_at)
            self.view_recovery.paused_at=None;self.view_recovery.next_at=now+.3
        self.hp_next_defense=now+(1 if success else 8)
        self.attacker_retry_after[episode.attacker]=self.hp_next_defense
        self.next_defense=self.hp_next_defense;self.hp_handled_event=self.health.state()['damage_sequence']
        if not success:
            self.say('Защита завершена без подтверждённого убийства: '+reason+'; возвращаю рабочее состояние, cooldown не останавливает поиск')
        else:self.say('Смерть агрессора подтверждена сервером')
        node=view['state'].nodes.get(episode.resource_id) if view and view['ready'] else None
        same=view and view['ready'] and view['flow']==episode.flow and view['state'].own==episode.owner
        available=node is None or node.visible and node.used!=3 and node.removed_reason!=4
        retreat=not success and air_view is not None
        if episode.resume and same and available and not retreat:
            self.target=episode.resource
            self.network_target=(episode.flow,episode.resource_id) if episode.resource_id is not None else None
            self.resume_resource_id=self.network_target
            self._begin_reacquire(('Защита закончена: ' if success else 'Агрессор пока не найден: ')
                                  +'возвращаю сохранённый ресурс '+str(episode.resource))
        else:
            self.target=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
            self.candidate=None;self.resume_resource_id=None;self.collection_cycle.reset()
            self._clear_view_recovery()
            self._reset_resource_watch();self.change_mode('SEARCH');self.nav.pause(now)
            if node and (node.used==3 or node.removed_reason==4):self.nav.finish_goal(now)
            if retreat:
                self.defense_evade_until=now+6;air_view.failed=True
                if episode.resource_id is not None:
                    self.resource_retry_after[(episode.flow,episode.resource_id)]=now+45
                    if node and node.gather_time is not None:self.abandoned_lease=(episode.flow,episode.resource_id,node.gather_time)
                self.nav.abandon_goal(now,60)
                self.say('DEFENSE_ESCAPE: агрессор не найден; пропускаю ресурс, после возврата камеры короткий отход без новых Tab')
            self.say('Защита закончена: продолжаю поиск ресурсов')
        self.defense_cycles=0
        if air_view is not None and air_view.moved:self.defense_restore_view=air_view

    def _restore_defense_camera(self):
        view=self.defense_restore_view
        if view is None:return False
        if not self._focus_ok():return True
        network=self._net_view()
        if self.network is not None and (not network or not network['ready']):self._neutral();return True
        began=time.monotonic();completed=False;self.camera_in_progress=True
        try:
            if not self._camera_input_ready():return True
            self.say('DEFENSE_VIEW: возвращаю камеру после поиска снизу — один раз вверх до упора и вниз на '+str(working_view_ms(self.cfg))+' мс')
            if view.turn_seconds:
                try:
                    self.gamepad.drive(0,0,-.62,0,lifetime=min(.85,view.turn_seconds+.05))
                    if not GamepadInput.wait(view.turn_seconds,self.stop_event,self.screen.focused):return True
                finally:self._neutral()
                view.turn_seconds=0
            completed=(self._hold_pitch_up(2) and self._camera_wait(.1)
                       and self._hold_pitch_down(working_view_ms(self.cfg)/1000))
            if completed:
                self.pitch.set_working_baseline(time.monotonic());self.camera_last_calibrated=time.monotonic()
                self.camera_aligned_revision=self.camera_search_revision;self.camera_alignment_due=None
                self.say('DEFENSE_VIEW: рабочий наклон восстановлен; продолжаю '+self.mode)
            elif self._focus_ok():
                self.pitch.returning=False;self.pitch.failed=False
                self.say('DEFENSE_VIEW: полная коррекция не подтвердилась; продолжаю ограниченный поиск вместо зависания')
        finally:
            self._neutral();self.camera_in_progress=False
            if completed or self._focus_ok() or self.stop_event.is_set():self.defense_restore_view=None
            now=time.monotonic();self.identity_valid_after=now
            if view.failed:
                self.defense_evade_until=now+6;self.nav.pause(now)
            with self.snapshot_lock:self.snapshot=None
            if self.reacquire_until is not None:self.reacquire_until+=max(0,now-began)
            if self.view_recovery is not None:
                self.view_recovery.until+=max(0,now-began);self.view_recovery.next_at=now+.2
            self.reacquire_next=now+.2
        return True

    def _recover_orphan_defense(self):
        self._neutral();self._stop_defense_motion();self.network_attacker=None
        view=self._net_view();node=self._net_node(view);frame,_=self.screen.frame()
        if node and gathering_panel_pair(frame) and self._net_gather_proof():
            self.target_confirmed=True;self.resource_hold=True;self.change_mode('GATHER')
            self.say('DEFENSE_RECOVER: активного эпизода нет; нижняя панель видна, возвращаю сбор')
        elif node and node.visible and node.used!=3 and self.target is not None:
            if node.gather_time is not None:self.defense_interrupted=(view['flow'],node.actor,int(time.time()*1000))
            self.resume_resource_id=self.network_target;self._begin_reacquire('DEFENSE_RECOVER: возвращаю сохранённый ресурс из незавершённого состояния защиты')
        else:
            self.target=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
            self.resume_resource_id=None;self.candidate=None;self._clear_view_recovery();self._reset_resource_watch();self.change_mode('SEARCH')
            self.say('DEFENSE_RECOVER: активного эпизода нет; продолжаю патруль')

    def _network_defense_tick(self,now):
        if self.defense_restore_view is not None:return self._restore_defense_camera()
        episode=self.network_defense
        if episode is None:
            if self.mode=='DEFENSE':self._recover_orphan_defense();return True
            return False
        if not self._focus_ok():self._stop_defense_motion();self._neutral();return True
        view=self._net_view()
        if not view or not view['ready']:
            self._stop_defense_motion();return True
        state=view['state']
        if view['flow']!=episode.flow or state.own!=episode.owner:
            self._finish_network_defense(False,'сменились соединение или ID персонажа');return True
        air=self.defense_air_view
        if air is not None and air.phase=='DOWN':
            if dead(state,episode.attacker):self._finish_network_defense(True);return True
            remaining=air.down_remaining(self.pitch.offset(now))
            if remaining>.005 and now-air.started<6:
                self.gamepad.drive(0,0,0,-PITCH_STRENGTH,lifetime=min(.12,remaining));air.moved=True
                return True
            self._neutral();air.phase='READY';self.camera_search_revision+=1
            self.say('DEFENSE_VIEW: обзор вниз завершён; ищу именно источник урона через Tab')
        if self.defense_camera_until is not None:
            offset=self.pitch.offset(now)
            if abs(offset)<.009:
                self._neutral();self.defense_camera_until=None
            elif now<self.defense_camera_until:
                self.gamepad.drive(0,0,0,-PITCH_STRENGTH if offset>0 else PITCH_STRENGTH,lifetime=min(.12,abs(offset)/PITCH_STRENGTH))
                return True
            else:
                self._neutral();self.defense_camera_until=None
                self.say('Коррекция перед Tab не успела завершиться: проверяю реальный выбранный ID без угадывания')
        if view['flow']!=episode.flow or state.own!=episode.owner:
            self._finish_network_defense(False,'сменились соединение или ID персонажа');return True
        wall=int(time.time()*1000)
        hit=state.outgoing.get(episode.attacker)
        if hit and episode.first_attack is not None and hit[0]>=episode.first_attack and hit[0]>episode.outgoing_seen:
            episode.outgoing_seen=hit[0]
            self.say(f'Сеть подтверждает наш удар по агрессору ID={episode.attacker}, урон={hit[1]}')
        action=episode.plan(state,wall,now)
        if action=='DONE':self._finish_network_defense(True)
        elif action=='ABORT':
            if (air is not None and air.rounds<1 and episode.tabs>=episode.max_tabs and not episode.pairs
                and episode.reason=='выбранный ID не совпал с источником урона' and now-episode.started<12):
                self.say('DEFENSE_VIEW: первый проход Tab не нашёл агрессора; один поворот камеры и второй проход')
                self._neutral();began=None
                try:
                    result=self.gamepad.drive(0,0,.62,0,lifetime=.65)
                    if result is not False:
                        began=time.monotonic();GamepadInput.wait(.6,self.stop_event,self.screen.focused)
                finally:
                    if began is not None:air.turn_seconds+=min(.6,max(0,time.monotonic()-began))
                    self._neutral()
                air.rounds+=1;episode.tabs=0;episode.confirm_at=None;episode.tab_requested=None
            else:self._finish_network_defense(False,episode.reason)
        elif action=='TAB':
            self.say(f'Проверка цели {episode.tabs+1}/{episode.max_tabs}: выбран ID={state.selected}, нужен ударивший ID={episode.attacker}')
            requested=wall
            if self.bridge_cmd('TAB'):
                episode.sent_tab(requested,time.monotonic())
                if episode.resource_id is not None:
                    episode.interrupted_at=int(time.time()*1000)
                    self.defense_interrupted=(episode.flow,episode.resource_id,episode.interrupted_at)
            else:self._finish_network_defense(False,'команда Tab отменена проверкой ввода')
        elif action=='PAIR':
            profile='NPC' if episode.attacker in state.npcs else 'источник подтверждённого урона без начального профиля'
            self.say(f'Атака {episode.pairs+1}/3: выбран ID={state.selected}, агрессор ID={episode.attacker}; {profile}')
            requested=wall
            if self.bridge_cmd('ATTACK_PAIR'):
                episode.sent_pair(requested,time.monotonic())
                if episode.resource_id is not None:
                    episode.interrupted_at=int(time.time()*1000)
                    self.defense_interrupted=(episode.flow,episode.resource_id,episode.interrupted_at)
                self.say('Команда двух нажатий ] отправлена; ожидаю сетевое попадание или смерть цели')
            else:
                fresh=self._net_view()
                reason=attack_reason(fresh['state'],episode.attacker,int(time.time()*1000)) if fresh and fresh['ready'] else 'нет свежей сети'
                if fresh and fresh['ready'] and dead(fresh['state'],episode.attacker):
                    self._finish_network_defense(True)
                else:self._finish_network_defense(False,'атака отменена: '+str(reason))
        return True

    def _pending_network_hits(self,now):
        if not self.cfg.get('protect_player',True):return []
        if self.defense_cycles>=self.cfg.get('defense_max_cycles',6) and not (self.cfg.get('continuous_patrol_defense',False) and self.network_target is None):return []
        if self.mode=='SEARCH' and now<self.defense_evade_until:return []
        if self._defer_route_defense(now):return []
        view=self._net_view()
        if not view or not view['ready']:return []
        wall=int(time.time()*1000);state=view['state']
        return [(stamp,actor) for actor,stamp in state.attacks.items()
              if stamp>self.attacker_handled.get(actor,0) and 0<=wall-stamp<=4000
              and now>=self.attacker_retry_after.get(actor,0)
              and attack_reason(state,actor,wall) in (None,'выбран другой ID')]

    def _urgent_damage_pending(self):
        return self.network is not None and bool(self._pending_network_hits(time.monotonic()))

    def _net_defense(self,now):
        if self.mode not in ('SEARCH','ACQUIRE_WAIT','APPROACH','TAKEOFF','JUMP_RETRY','GATHER','REACQUIRE','VERIFY_NATIVE'):return False
        hits=self._pending_network_hits(now)
        if not hits:return False
        view=self._net_view()
        if not view or not view['ready']:return False
        state=view['state'];wall=int(time.time()*1000)
        stamp,actor=next((hit for hit in hits if hit[1]==state.selected),max(hits))
        self.network_hit_handled=stamp;self.attacker_handled[actor]=stamp;self.network_attacker=actor
        self.say(f'Сеть: подтверждён удар по персонажу; от захвата пакета до реакции {max(0,wall-stamp)} мс. Проверяю именно нанёсшего его моба; цель моба может быть духом.')
        resume=(self.target_confirmed or self.mode=='VERIFY_NATIVE' and self.visual_route is not None or self.mode=='REACQUIRE' and self.target is not None
                and (self.resume_resource_id is not None or self.network_target is not None))
        self._defend_and_resume(resume=resume)
        return True

    def _confirmed_aggressor(self):
        if self.network is not None:
            if not self._net_selected_aggressor():return False
            return GamepadInput.wait(.18,self.stop_event,self.screen.focused) and self._net_selected_aggressor()
        first,_=self.screen.frame();a=self.threat.check(first)
        if not(a.matches and a.hp):return False
        if not GamepadInput.wait(.18,self.stop_event,self.screen.focused):return False
        second,_=self.screen.frame();b=self.threat.check(second)
        return b.matches and b.hp

    def _defend_and_resume(self,resume=True):
        if self.network is not None:return self._begin_network_defense(resume)
        if not self._focus_ok() or self.cfg.get('dry_run'):return
        resource=self.target;self.defense_cycles+=1
        self._neutral()
        if not resume and not self.folded:
            frame,_=self.screen.frame()
            if read_flight(frame).confirmed and self.bridge_cmd('END_AIR'):
                self.folded=True;self.f_on=False
        self.f_disable();self.route_active=False
        self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False;self.f_repeat_allowed=False
        self.real_gather_panel_seen=False;self.wing_route_restart_pending=False
        self.identity_valid_after=time.monotonic();self.interrupts.reset();self.change_mode('DEFENSE')
        self.say('Проверяю агрессора через Tab: смена цели останавливает путь к ресурсу')
        try:
            for index in range(min(3,self.cfg.get('defense_max_tabs',8)) if self.network is not None else self.cfg.get('defense_max_tabs',8)):
                if self.network is not None and not self._net_view()['ready']:break
                if self.network is None and index>=3 and not self.health.ongoing(time.monotonic()):break
                if self.network is None or not self._net_selected_aggressor():
                    requested=int(time.time()*1000)
                    if not self.bridge_cmd('TAB'):return
                    if not GamepadInput.wait(.25,self.stop_event,self.screen.focused):return
                    if self.network is not None:
                        until=time.monotonic()+1.5
                        while self._focus_ok() and time.monotonic()<until:
                            fresh=self._net_view()
                            if fresh['ready'] and fresh['state'].selection_time>=requested:break
                            if not GamepadInput.wait(.05,self.stop_event,self.screen.focused):return
                        else:
                            self.say('Сеть не подтвердила смену цели: следующие Tab отменены');break
                if not self._confirmed_aggressor():
                    if self.health.ongoing(time.monotonic()):self.say('Чужой/неподтверждённый таргет, HP ещё снижен: проверяю следующий Tab')
                    continue
                if not self.bridge_cmd('ATTACK_PAIR'):return
                self.say('Агрессор подтверждён дважды: два нажатия ], жду завершения боя')
                until=time.monotonic()+6;absent=None;defeated=False
                while self._focus_ok() and time.monotonic()<until:
                    frame,_=self.screen.frame();evidence=self.threat.check(frame) if self.network is None else None
                    net_dead=False
                    if self.network is not None:
                        view=self._net_view();npc=view['state'].npcs.get(self.network_attacker) if view['ready'] else None
                        net_dead=bool(npc and npc['dead'])
                    if (self.network is None and not evidence.matches and not evidence.hp) or net_dead:
                        if absent is None:absent=time.monotonic()
                        if time.monotonic()-absent>.6:defeated=True;break
                    else:absent=None
                    if not GamepadInput.wait(.25,self.stop_event,self.screen.focused):return
                if not defeated:
                    self.say('Исчезновение обеих боевых плашек не подтверждено: остановка перед возвратом к сбору')
                    self.stop();return
                break
            if not self._focus_ok():return
            if not resume:
                if resource not in self.cfg['target_names']:
                    self.target=None;self.target_confirmed=False;self.resource_hold=False
                    self.defense_cycles=0
                    self._reset_resource_watch();self.change_mode('SEARCH');self.nav.pause(time.monotonic())
                    self.say('Защита патруля закончена: продолжаю поиск ресурса');return
                frame,_=self.screen.frame();self.collecting_visible=False
                self.return_to_search('Последняя попытка ресурса уже потрачена: следующая цель',
                                      exhausted=True,reading=read_flight(frame))
                return
            self._begin_reacquire('Защита закончена: заново выбираю сохранённый ресурс '+str(resource))
        finally:
            self.next_defense=time.monotonic()+8
            self.hp_handled_event=self.health.state()['damage_sequence'];self.hp_next_defense=time.monotonic()+1

    def _recover(self,frame,origin,obs,reading,now):
        fresh,_=self.screen.frame()
        live_panel=self._gather_panel(fresh)
        if live_panel or self.real_gather_panel_seen:
            self._neutral();self.collecting_visible=live_panel
            self.change_mode('GATHER')
            if live_panel:
                self.fast_gather_seen=True;self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                self.collection_activity_at=now
            self.f_enable()
            self.say('Восстановление пути запрещено: сбор уже начался; остаюсь у ресурса без V/движения')
            return
        if self.mode=='TAKEOFF':
            self._neutral();return
        if obs.target_name==self.target and obs.distance_m is not None and obs.distance_m<=3:
            self._neutral()
            self.say('Ресурс ближе 3 м: V не открываю, жду штатное начало сбора')
            return
        self._neutral()
        if reading.confirmed:
            if reading.confirmed:self.flight_attempted=True
            if now-self.last_note>2:
                self.say('Штатный путь к ресурсу ещё ожидает начало сбора: F не повторяю, движение не отменяю')
                self.last_note=now
            return
        if not reading.confirmed and not self.flight_attempted and self.budget.can_start():
            if not self.bridge_cmd('V'):return
            self.flight_attempted=True;self.wing_route_restart_pending=True;self.route_active=False
            self.change_mode('TAKEOFF')
            self.say('Упор в препятствие: V, проверка раскрытых крыльев, затем F по выбранному таргету')
            return
        if not self.jump_attempted and self.target!='Эфир' and not reading.confirmed and not self.flight_attempted:
            self.jump_attempted=True;self.bridge_cmd('JUMP')
            self.change_mode('JUMP_RETRY');self.say('Энергии для облёта мало: одна попытка перепрыгнуть препятствие')
            return
        if self.target=='Эфир' and not reading.confirmed and not self.flight_attempted:
            self.budget.failed_takeoff(now)
        self.return_to_search('Нет сближения с ресурсом: пропускаю и патрулирую дальше',frame,reading=reading)

    def step(self,frame,origin,obs,radar,reading,now,sequence=0):
        if self.stop_event.is_set():return
        if self._automatic_recovery_tick(frame,now):return
        if self._network_guard(now):return
        self._adopt_network_collection()
        self.current_size=(frame.shape[1],frame.shape[0])
        self._budget_update(reading,now)
        if self.cfg.get('area_search_rescue',False):self._track_working_area(reading)
        if not self.screen.focused():
            self.no_yield.pause();self._neutral();self.f_disable();self.nav.pause(now);return
        if self._map_teleport_tick(frame,reading,now):return
        if self._network_defense_tick(now):return
        if self._no_yield_tick(frame,reading,now):return
        if self._return_exit_tick(frame,reading,now):return
        local_search=(self.mode in ('SEARCH','ACQUIRE_WAIT','PROBE','PATROL_ESCAPE','RESCUE')
                      and not self.return_exit_guard and not self.resource_hold and not self.target_confirmed)
        rescue_due=self.terrain_watch.update(radar,local_search,now)
        if self._terrain_recovery_tick(frame,reading,now,radar):return
        if rescue_due and self._start_terrain_recovery(now,reading):return
        plate=segment_count(frame)
        panel=self._gather_panel(frame)
        self.collecting_visible=panel
        if self._check_route_damage(frame,now,panel,plate):return
        if (self.network is not None and self.mode=='SEARCH' and self.target is None
            and gathering_panel_pair(frame) and obs.target_name in self.cfg['target_names']):
            view=self._net_view();state=view['state'] if view['ready'] else None
            node=state.nodes.get(state.collecting) if state else None
            if node and node.gather_time is not None and node.visible and node.used is not None and node.used<3 and not self._retired_collection(view,node):
                self._reset_resource_watch(True)
                self.target=obs.target_name;self.target_confirmed=True;self.resource_hold=True
                self.network_target=(view['flow'],node.actor);self.network_owner=state.own;self.network_claimed_at=node.gather_time
                self.change_mode('APPROACH')
                self.say('Подхватил уже начавшийся собственный сбор по сети; новый стартовый F не нужен')
        if self._resource_fast_tick(frame,reading,now,panel,plate):return
        if self._patrol_escape_tick(frame,reading,now):return
        if (self.mode=='APPROACH' and not self.real_gather_panel_seen and obs.target_name==self.target
            and obs.distance_m is not None and (self.distance_live_at is None or now-self.distance_live_at>=2)):
            if self.last_distance is None or obs.distance_m<self.last_distance-.3:
                self.last_distance=obs.distance_m;self.last_progress=now
        if self._approach_fast_tick(frame,origin,reading,now):return
        panel=self.collecting_visible
        if self.mode=='REACQUIRE':
            self._reacquire_step(frame,origin,obs,now);return
        if panel and self.mode=='SEARCH' and self.target is None and self.probe is None:
            returning=self.cfg.get('world_map_enabled') and self.region.ready and self.region.returning
            if ((self.cfg.get('assist_manual_target') and self.network is None) and obs.target_name in self.cfg['target_names']
                and plate is not None and not self.nav.is_retreating(now) and not returning
                and self.policy.allows(obs.target_name)):
                self.target=obs.target_name;self.target_confirmed=True;self.resource_hold=True
                self.defense_cycles=0;self.interrupts.reset();self.missing_since=None
                self.folded=False;self.health.begin_gather();self.change_mode('GATHER')
                self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                self.say('Уже идёт сбор выбранного ресурса: принимаю управление независимо от старой дистанции OCR')
            else:
                self._neutral();return
        if not panel:self.panel_cleared=True
        if panel and self.target_confirmed and (self.panel_cleared or self.mode=='GATHER'):
            self._neutral()
            if self.mode!='GATHER':self.change_mode('GATHER');self.missing_since=None
            self.f_enable()
        if now<self.post_gather_until:
            self._neutral();return
        if (self.camera_scheduler_active and self._automatic_camera_enabled()
            and self.camera_alignment_due and self.mode=='SEARCH' and not panel
            and not self._search_caption_priority(obs,now)
            and not self.resource_hold and self.probe is None):
            if reading.confirmed:
                self._neutral()
                if now-self.camera_requested_at>5:
                    self.say(f'Калибровка {self.camera_alignment_due} ожидает закрытых крыльев: энергия={reading.energy}, признаки дуги={reading.evidence}. Остановка ввода, состояние полёта требует проверки');self.stop()
                return
            if not self._calibrate_camera(self.camera_alignment_due):self.stop()
            return
        if self.pitch.failed and not self.resource_hold and not panel:
            if self._start_terrain_recovery(now,reading,force_ground=True):return
            safe=(self.mode=='SEARCH' and not self.resource_hold and self.probe is None) or (self.mode=='GATHER' and panel)
            if self.camera_scheduler_active and self._automatic_camera_enabled() and safe:
                if not self._calibrate_camera('нет подтверждённого возврата наклона',allow_gather=panel):self.stop()
            else:
                self.say('Возврат наклона не подтверждён: остановка ввода');self.stop()
            return
        if self.probe is not None:
            self._probe_step(frame,origin,obs,radar,reading,now);return
        if self.pitch.returning and not panel and self.mode!='GATHER' and not self.resource_hold:
            correction=self.pitch.correction(time.monotonic())
            if correction:
                self._motion(Drive(pitch=correction,lifetime=self.pitch.correction_lifetime(),reason='возвращаю прежний наклон камеры той же силой стика'))
            else:
                self._neutral();self.nav.pause(now);self.last_progress=now
                self.identity_valid_after=time.monotonic()
                if self.pitch.failed:
                    if self._start_terrain_recovery(now,reading,force_ground=True):return
                    self.halt_reason='Возврат наклона камеры не подтверждён';self.say('Не удалось вернуть наклон камеры: остановка');self.stop()
            return
        if self.pending_probe is not None:
            goal=self.pending_probe;self.pending_probe=None
            if self.budget.can_probe(self.cfg.get('flight_probe_min_percent',18)):
                self.probe=FlightProbe(goal,now,self.cfg);self.change_mode('PROBE')
            else:self.nav.abandon_goal(now,60)
            self._neutral();return
        if (self.mode=='SEARCH' and not self.resource_hold and self.cfg.get('auto_view_recovery',True)
            and not self._search_caption_priority(obs,now)
            and self.nav.air_since is None and (self.view_guard.active or abs(self.pitch.offset(time.monotonic()))<.009)):
            action,accepted,failed=self.view_guard.update(frame,now)
            if failed:
                if self.scene_view_repair:
                    self.scene_view_repair=False
                    if not self._calibrate_camera('после проверки неба нейронной моделью'):self.stop()
                    return
                if self._start_terrain_recovery(now,reading,force_ground=True):return
                recent=self.camera_last_calibrated is not None and now-self.camera_last_calibrated<10
                if self.camera_scheduler_active and self._automatic_camera_enabled() and not recent:
                    if not self._calibrate_camera('земля в поле зрения не найдена'):self.stop()
                else:
                    self.say('Земля не подтверждена после коррекции камеры: остановка ввода');self.stop()
                return
            if accepted:
                self.scene_view_repair=False
                self._neutral();self.pitch.accept_visible_ground(time.monotonic());self.nav.pause(now)
                self.identity_valid_after=time.monotonic();return
            if action is not None:
                self._motion(action);return
        near=(obs.distance_m is not None and obs.distance_m<=3)
        # Being two metres from a node can still mean being behind a rock.
        # Near distance enables F, but does not disable obstacle recovery.
        gather_ready=obs.f_prompt or (panel and (obs.distance_m is None or near))
        if self.target_confirmed and self.mode in ('APPROACH','JUMP_RETRY','TAKEOFF') and plate is not None:
            if self.last_segments is not None and plate<self.last_segments:
                gather_ready=True
                self.say('Счётчик изменился; начало сбора всё ещё требует нижнюю плашку')
            self.last_segments=plate
        if reading.confirmed and self.target_confirmed and self.mode in ('APPROACH','TAKEOFF','GATHER'):
            self.flight_attempted=True
        if self.mode in ('SEARCH','ACQUIRE_WAIT'):
            returning=self.cfg.get('world_map_enabled') and self.region.ready and self.region.returning
            if (not returning and not self.nav.is_retreating(now)
                and (self.cfg.get('assist_manual_target') and self.network is None) and obs.target_name in self.cfg['target_names']
                and plate is not None
                and self.policy.allows(obs.target_name)
                and gather_ready):
                self.target=obs.target_name;self.target_confirmed=True;self.missing_since=None
                self.resource_hold=True
                self.defense_cycles=0;self.interrupts.reset()
                self.folded=False;self._neutral()
                if panel:
                    self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                    self.f_enable();self.change_mode('GATHER')
                else:
                    self._reset_resource_watch(verified_header=True)
                    self.route_active=True;self.route_f_sent=True;self.change_mode('APPROACH')
                    self.say('Уже выбран ручной таргет: F не повторяю, наблюдаю текущий подход')
                return
            candidate=obs.candidate
            if (not returning and not self.nav.is_retreating(now) and candidate
                and self.cfg.get('allow_click',True) and self._allowed(candidate,now)):
                self._neutral();self.nav.pause(now)
                if self.mode=='SEARCH':
                    self.candidate=candidate;self.candidate_sequence=sequence
                    self.candidate_since=now;self.change_mode('ACQUIRE_WAIT')
                    self.say('Вижу '+candidate.name+'; остановил движение, уточняю координаты')
                elif candidate.name==self.candidate.name and (sequence!=self.candidate_sequence or now-self.candidate_since>=.2):
                    fresh=candidate if sequence!=self.candidate_sequence else find_resource_near(frame,self.candidate)
                    if fresh is not None and not self.click_candidate(fresh,origin):
                        self._acquire_miss(fresh,time.monotonic())
                return
            if self.mode=='ACQUIRE_WAIT':
                if self.candidate is not None and (sequence!=self.candidate_sequence or now-self.candidate_since>=.2):
                    fresh=find_resource_near(frame,self.candidate)
                    if fresh is not None:
                        if not self.click_candidate(fresh,origin):self._acquire_miss(fresh,time.monotonic())
                        return
                if now-self.candidate_since<2.5:return
                self.candidate=None;self.change_mode('SEARCH')
            if self._return_exit_scan(now):return
            if not self.cfg.get('minimap_search',True):radar.markers=[]
            radar=replace(radar,markers=[m for m in radar.markers if self.policy.allows('Эфир' if m.kind=='aether' else 'Самоцвет')])
            if now<self.scene_avoid_until and self.scene_avoid_bearing is not None:
                cx,cy=radar.center
                radar=replace(radar,markers=[m for m in radar.markers if abs(((math.degrees(math.atan2(m.x-cx,cy-m.y))-self.scene_avoid_bearing+180)%360)-180)>60])
            if self.nav.goal and not self.policy.allows('Эфир' if self.nav.goal.kind=='aether' else 'Самоцвет'):self.nav.goal=None
            self._spatial_route(radar)
            if self.cfg.get('world_map_enabled') and self.region.ready:
                bearing=self.region.terrain_bearing(frame,radar,now)
                if bearing is not None:
                    self.nav.route(bearing,'курс по сопоставлению рельефа миникарты',self.region.returning)
            plan=self.nav.update(radar,now,self.budget.can_start())
            plan=self._scene_plan(frame,radar,reading,plan,now)
            if plan is None:return
            if self.cfg.get('ground_route_navigation',False):
                if self.scene_pilot.follower.observe_progress(radar,now,math.hypot(plan.forward,plan.strafe)>.2):
                    self.say('GROUND_ROUTE: 5 с без подтверждённого смещения; этот вариант пути отложен на 8 с')
            if plan.flight_probe:
                if self.nav.goal is not None and self.nav.goal.kind=='aether':self.save_debug(frame,'ether_not_seen')
                self._request_probe(now);return
            if plan.restore_pitch:
                self._neutral();self._restore_pitch();return
            if not self.cfg.get('ground_walk',True):plan.forward=0;plan.strafe=0
            if not self.cfg.get('camera_scan',True):plan.yaw=0;plan.pitch=0
            sent=self._motion(plan)
            walking=bool(sent and math.hypot(plan.forward,plan.strafe)>.2 and self.nav.goal is None and self.probe is None)
            search_walking=bool(sent and math.hypot(plan.forward,plan.strafe)>.2 and self.probe is None)
            if self.nav.track_walk(radar,search_walking,now):
                self.say('Рельеф смещается, но маршрут возвращается к прежнему месту: 12 с прямого выхода без поворотов')
            stuck=self.patrol_stall.update(radar,walking,now)
            if (stuck and now>=self.patrol_escape_after and self.budget.can_start() and not reading.confirmed
                and self.cfg.get('patrol_escape_enabled',True) and not self.cfg.get('dry_run')):
                self._neutral();self.patrol_stall.consume();self.patrol_escape=PatrolEscape(now,self.patrol_escape_side)
                self.patrol_escape_side*=-1;self.change_mode('PATROL_ESCAPE')
                self.say('10 секунд рельеф миникарты не смещается при ходьбе: один короткий выход крыльями')
                return
            if now-self.last_note>1.5:
                self.say(f'{plan.reason}; ресурсы на карте: {len(radar.markers)}, ход={plan.forward:.2f}, бок={plan.strafe:.2f}, камера={plan.yaw:.2f}, наклон={plan.pitch:.2f}')
                self.last_note=now
            return
        if self.mode in ('APPROACH','JUMP_RETRY','TAKEOFF'):
            if obs.target_name and obs.target_name!=self.target:
                self.return_to_search('В таргете другой ресурс',frame,reading=reading);return
            if obs.distance_m is not None and obs.target_name==self.target:
                # Track a new best distance, not alternating OCR values such
                # as 12/13/12/13 which otherwise reset the wall timer forever.
                if self.last_distance is None or obs.distance_m<self.last_distance-.3:
                    self.last_progress=now;self.last_distance=obs.distance_m
            if self.target_confirmed and panel and (self.panel_cleared or self.fast_gather_seen):
                self.f_repeat_allowed=self.real_gather_panel_seen;self.route_active=False
                self._neutral();self.f_enable();self.missing_since=None;self.change_mode('GATHER')
                self.say('Сбор доступен; F работает независимо от OCR');return
            if self.mode=='TAKEOFF':
                if reading.confirmed:
                    if self._start_resource_route(restart_after_wings=True):
                        self.last_distance=obs.distance_m;self.last_progress=now;self.change_mode('APPROACH')
                    return
                if now-self.started>3.5:
                    self.budget.failed_takeoff(now)
                    self.say(self.budget.describe(now))
                    self.return_to_search('Крылья не подтверждены дугой; повторно V не переключаю',frame,reading=reading)
                return
            if self.mode=='JUMP_RETRY':
                if now-self.started>1.5:
                    self.last_distance=obs.distance_m;self.last_progress=now;self.change_mode('APPROACH')
                return
            if plate is None and obs.target_name is None:
                if self.missing_since is None:self.missing_since=now
                if now-self.missing_since>2:
                    self.return_to_search('Плашка выбранного ресурса исчезла до сбора',frame,reading=reading);return
            else:self.missing_since=None
            if radar.motion_valid and math.hypot(*radar.displacement)>.15:
                self.last_path_motion=now
            progress=max(self.last_progress,self.last_path_motion or self.last_progress)
            stall=max(1,self.cfg.get('approach_stall_seconds',6))
            distance_stale=(obs.target_name==self.target and obs.distance_m is not None
                and obs.distance_m>3 and now-self.last_progress>
                (stall if obs.distance_m<=6 else max(12,stall*2)))
            route_since=self.native_route_started_at if self.native_route_started_at is not None else self.started
            delayed=(now-route_since>10 and now-self.last_progress>2)
            if now-self.started>max(60,self.cfg.get('approach_timeout',60)):
                self.return_to_search('Таймаут подхода',frame,reading=reading)
            elif distance_stale or now-progress>stall or delayed:
                self._recover(frame,origin,obs,reading,now)
            return
        if self.mode=='GATHER':
            if (panel and self.real_gather_panel_seen and self.target_confirmed and self.camera_scheduler_active
                and self._automatic_camera_enabled() and self._gather_camera_needed()
                and not self.health.pending(self.hp_handled_event,now)):
                if not self._calibrate_camera('один раз после поискового движения камеры',allow_gather=True):self.stop()
                return
            # Cached OCR cannot terminate a live resource. Red target changes
            # and resource depletion are handled from fresh frames above.
            if not self.f_on:self.f_enable()
            remaining=plate is not None or resource_header_visible(frame)
            if self.cfg.get('protect_player',True) and not panel and self.interrupts.ready(radar.hostiles_near,now):
                # A missed last frame of a normal attempt is not proof of a hit.
                # Ask the HP reader; never change the resource target on this alone.
                self.health.request_check(frame,now)
            if plate is not None and plate!=self.last_segments:
                self.last_segments=plate;self.last_progress=now;self.say(f'Осталось попыток: {plate}/3')
            # A missing panel BETWEEN attempts never re-enters approach recovery.
            # Keep the same target and F timer; depletion is owned by the live UI tick.
            activity=self.collection_activity_at if self.collection_activity_at is not None else self.last_progress
            if not panel and now-activity>20:
                if self._recover_resource_wait(frame,reading,now,'missing_panel'):return
                self.say('20 секунд без нижней плашки/расхода попытки: остановка ввода с сохранением ресурса, без V')
                self.stop();return
            if now-self.started>self.cfg.get('gather_timeout',55):
                if self._recover_resource_wait(frame,reading,now,'gather_timeout'):return
                if panel:
                    self.say('Окно сбора не исчезло за отведённое время: остановка ввода без движения')
                    self.stop()
                else:self.return_to_search('Сбор не завершился за отведённое время',frame,reading=reading)

    def _recover_resource_wait(self,frame,reading,now,kind):return False

    def process(self,frame,origin,now):
        if self.stop_event.is_set():return
        obs=self.vision.scan(frame)
        self.observation_captured_at=now
        self.sequence+=1
        self.step(frame,origin,obs,self.minimap.observe(frame),read_flight(frame),now,self.sequence)

    def current_observation(self,obs,captured):
        if captured>=self.identity_valid_after:return obs
        # OCR started before A may finish later; it must not undo the new selection.
        return Observation(None,None,None,False,0,False,None,'HIDDEN')

    def _navigation_observation(self,snapshot,now):
        """OCR may delay acquisition, never completion or ordinary patrol.

        A missing observation grants no click/target/F authority. Native paths
        and own collection remain stationary here and are serviced above.
        """
        if snapshot is not None and now-snapshot[3]<=3 and snapshot[1]>=self.identity_valid_after:
            obs,captured,sequence,_=snapshot
            return self.current_observation(obs,captured),captured,sequence
        pending_caption=self.mode=='ACQUIRE_WAIT' and self.candidate is not None
        if (self.mode!='SEARCH' and not pending_caption) or self.target_confirmed or self.resource_hold or self.collecting_visible:
            return None
        view=self._net_view()
        if view and (not view['ready'] or self._own_collection(view) is not None or self._live_attempt(view)):return None
        if now-self.ocr_wait_note>=5:
            self.say('OCR ещё обрабатывает кадр: патруль по свежей миникарте продолжается; выбор ресурса ждёт распознавания')
            self.ocr_wait_note=now
        return Observation(None,None,None,False,0,False,None,'HIDDEN'),now,-1

    def _spatial_route(self,radar):
        # The current camera heading still comes from the north-up minimap.
        # Fresh XYZ may supply a bearing, never a collision-free path or click.
        if self.spatial_route_active:
            if self.nav.route_reason.startswith('свежие XYZ:'):self.nav.route(None)
            self.spatial_route_active=False
        atlas=getattr(self.network,'atlas',None)
        if radar.markers or atlas is None:return
        view=self._net_view()
        if not view or not view['ready']:return
        options=[]
        for node in view['state'].nodes.values():
            if time.monotonic()<self.resource_retry_after.get((view['flow'],node.actor),0):continue
            label=atlas.objects.get(str(node.template),{}).get('names',{}).get('ru')
            if label not in self.cfg['target_names'] or not self.policy.allows(label):continue
            relative=geometry(view['state'],node)
            if relative and 3<relative['planar_m']<=100:options.append((relative['distance_m'],relative,label))
        if options:
            _,relative,label=min(options,key=lambda item:item[0])
            self.nav.route(relative['bearing'],f'свежие XYZ: {label}, высота {relative["height_m"]:+.1f} м')
            self.spatial_route_active=True

    def _gather_camera_needed(self):
        if self.network is not None and not self.cfg.get('calibrate_during_collection',False):return False
        return (self.camera_search_revision>self.camera_aligned_revision
                and self.camera_gather_tried_revision!=self.camera_search_revision)

    def _automatic_camera_enabled(self):
        return (not self.cfg.get('dry_run') and self.cfg.get('camera_scan',True)
                and self.cfg.get('camera_auto_calibrate',True) and self.gamepad is not None)

    def _camera_wait(self,seconds):
        """Camera-only motion cannot postpone depletion or wing closure."""
        until=time.monotonic()+seconds
        while self._focus_ok():
            if self.target_confirmed:
                frame,_=self.screen.frame();now=time.monotonic()
                if self._check_route_damage(frame,now):
                    self.calibration_defense_interrupted=True
                    self.camera_alignment_due='после защиты от моба'
                    self.camera_requested_at=time.monotonic();self._neutral();return False
                self._resource_fast_tick(frame,read_flight(frame),now)
                if not self.target_confirmed:
                    self.calibration_resource_ended=True
                    self.camera_alignment_due='ресурс закончился во время коррекции камеры'
                    self.camera_requested_at=time.monotonic();self._neutral();return False
            remaining=until-time.monotonic()
            if remaining<=0:return True
            if not GamepadInput.wait(min(.06,remaining),self.stop_event,self.screen.focused):return False
        return False

    def _hold_pitch_up(self,seconds):
        return self._hold_calibration_pitch(seconds,1)

    def _hold_pitch_down(self,seconds):
        return self._hold_calibration_pitch(seconds,-1)

    def _hold_calibration_pitch(self,seconds,direction):
        if not self.pitch_observed:return False
        before=self.pitch.offset(time.monotonic());end=time.monotonic()+seconds+2
        try:
            while self._focus_ok() and time.monotonic()<end:
                delivered=direction*(self.pitch.offset(time.monotonic())-before)/PITCH_STRENGTH
                remaining=seconds-delivered
                if remaining<=.005:return True
                self.gamepad.drive(0,0,0,direction*PITCH_STRENGTH,lifetime=min(.15,remaining))
                if not self._camera_wait(min(.08,remaining)):return False
            return False
        finally:self._neutral()

    def _calibrate_camera(self,reason,allow_gather=False):
        self.camera_in_progress=True
        try:return self._calibrate_camera_impl(reason,allow_gather)
        finally:self.camera_in_progress=False

    def _calibrate_camera_impl(self,reason,allow_gather=False):
        if not self._automatic_camera_enabled():return True
        if allow_gather and self.network is not None and not self.cfg.get('calibrate_during_collection',False):return True
        if not self._camera_input_ready():return False
        self.calibration_resource_ended=False
        self.calibration_defense_interrupted=False
        self._neutral()
        if not self._focus_ok():return False
        frame,_=self.screen.frame()
        panel=self._gather_panel(frame)
        selected=self.resource_hold or self.target_confirmed or panel
        gather_exception=(allow_gather and panel and self.real_gather_panel_seen and self.target_confirmed
                          and self.mode=='GATHER' and self._gather_camera_needed())
        if gather_exception and self.network is not None:
            view=self._net_view()
            if not view or not view['ready'] or not view['state'].attempt_active:
                # Continuing a completed attempt has priority over calibration.
                # The dirty revision remains pending for the next active attempt.
                return True
        if selected and not gather_exception:
            if self.camera_search_revision>self.camera_aligned_revision:
                self.camera_alignment_due=reason;self.camera_requested_at=time.monotonic()
            self.say('Калибровка не запущена: нет нового поискового отклонения либо ещё идёт подход')
            return True
        for kind,detector in (('CAPTCHA',self.cap),('DEATH',self.death)):
            if detector.check(frame)[0]:self.trigger_alarm(kind,frame);return False
        if not self._focus_ok():return False
        revision=self.camera_search_revision
        if gather_exception:self.camera_gather_tried_revision=revision
        seconds=2.0
        milliseconds=working_view_ms(self.cfg)
        self.say(f'Калибровка камеры ({reason}): около {seconds:.0f} с вверх до предполагаемого упора, затем {milliseconds} мс вниз; только вертикальная ось')
        if not self._hold_pitch_up(seconds):
            if self.calibration_resource_ended or self.calibration_defense_interrupted:return True
            self.say('Подъём камеры прерван; частичная калибровка не принята');return False
        if not self._camera_wait(.10):return self.calibration_resource_ended or self.calibration_defense_interrupted
        before=self.pitch.offset(time.monotonic());completed=False
        try:completed=self._hold_pitch_down(milliseconds/1000)
        finally:self._neutral()
        if not completed or not self._focus_ok():
            if self.calibration_resource_ended or self.calibration_defense_interrupted:return True
            self.say('Опускание камеры прервано; частичная калибровка не принята');return False
        delivered=(before-self.pitch.offset(time.monotonic()))/PITCH_STRENGTH*1000
        self.say(f'Камера: вниз задано {milliseconds} мс; фактически передано около {delivered:.1f} мс')
        if not self.pitch_observed or abs(delivered-milliseconds)>max(40,milliseconds*.04):
            self.say('Длительность импульса не подтверждена: калибровка не принята');return False
        self.pitch.set_working_baseline(time.monotonic())
        self.camera_last_calibrated=time.monotonic();self.camera_alignment_due=None
        self.camera_aligned_revision=revision
        self.identity_valid_after=self.camera_last_calibrated;self.nav.pause(self.identity_valid_after)
        self.nav.air_since=None;self.nav.scan_kind=None;self.view_guard=ViewGuard()
        with self.snapshot_lock:self.snapshot=None
        self.say('Рабочий наклон камеры восстановлен по временному ориентиру; угол непосредственно не измеряется')
        return True

    def _prepare_working_view(self):
        if not self._automatic_camera_enabled():return True
        if not self._focus_ok():return False
        frame,_=self.screen.frame();panel=self._gather_panel(frame)
        if panel:
            self.camera_alignment_due='после текущего сбора при запуске'
            self.camera_requested_at=time.monotonic()
            self.say('При запуске уже идёт сбор: калибровка отложена, ввод камеры запрещён')
            return True
        if not panel:
            name,distance=selected_target(frame,tuple(self.cfg['target_names']))
            reading=read_flight(frame)
            if reading.confirmed or name in self.cfg['target_names']:
                self.camera_alignment_due='после текущего подхода/полёта'
                self.camera_requested_at=time.monotonic()
                if name in self.cfg['target_names'] and (self.cfg.get('assist_manual_target') and self.network is None):
                    self.target=name;self.target_confirmed=True;self.resource_hold=True
                    self.last_distance=distance;self.last_progress=time.monotonic()
                    self.flight_attempted=reading.confirmed;self.change_mode('APPROACH')
                    self._reset_resource_watch(verified_header=True)
                    self.route_active=True;self.route_f_sent=True
                    self.say('Путь к уже выбранному ресурсу принят без второго F')
                self.say('Калибровка отложена до сбора или остановки: текущий подход/полёт продолжается')
                return True
        return self._calibrate_camera('при запуске',allow_gather=panel)

    def _automatic_recovery_tick(self,frame,now):return False

    def _runtime_failure(self,exc):return False

    def _retry_runtime_setup(self):return False

    def _start_safety_observers(self):
        if self.safety_threads:return
        self.safety_threads=[
            threading.Thread(target=self._vision_loop,daemon=True),
            threading.Thread(target=self._health_fast_loop,daemon=True),
            threading.Thread(target=self._health_numeric_loop,daemon=True),
            threading.Thread(target=self._heartbeat_loop,daemon=True),
            threading.Thread(target=self._input_audit_loop,daemon=True),
            threading.Thread(target=self._dialog_loop,args=('CAPTCHA',self.cap,1.0),daemon=True),
            threading.Thread(target=self._dialog_loop,args=('DEATH',self.death,3.0),daemon=True)]
        for worker in self.safety_threads:worker.start()

    def _run_session(self,offline=None):
        try:
            if offline:
                for file in offline:
                    if self.stop_event.is_set():break
                    frame=cv2.imread(str(file))
                    if frame is not None:self.process(frame,(0,0),time.monotonic())
                return
            if self.screen.pick() is None:raise RuntimeError('Окно AION2 не найдено')
            if not self.cfg.get('dry_run') and self.gamepad is None:raise RuntimeError('Нажмите «Подключить Xbox»')
            if self.cfg.get('network_enabled',False) and self.network is None and not self.cfg.get('dry_run'):
                raise RuntimeError('Встроенный сетевой режим не подключён')
            self._start_safety_observers()
            while not self._preflight_receiver():
                if not self._retry_runtime_setup() or self.stop_event.wait(1):return
            if self.scene_host is not None:self.scene_host.start()
            process=getattr(self.network,'process',None)
            if self.network is not None and (process is None or process.poll() is not None):self.network.start()
            self.bridge_cmd('F_OFF');self.f_on=False
            self.say('Навигация стиками; миникарта включена с готовыми цветами/формами, отдельный OCR-поток')
            self.camera_scheduler_active=True
            prepared=False
            if self.network is None:
                if not self._prepare_working_view():return self._retry_runtime_setup()
                prepared=True
            while not self.stop_event.is_set():
                try:
                    frame,origin=self.screen.frame();now=time.monotonic()
                    if not self.screen.focused():
                        self.no_yield.pause();self._neutral();self.f_disable();self.nav.pause(now)
                        self.stop_event.wait(.1);continue
                    if self._automatic_recovery_tick(frame,now):
                        self.stop_event.wait(.10);continue
                    if self._network_guard(now):
                        self.stop_event.wait(.06);continue
                    self._adopt_network_collection()
                    if not prepared:
                        if not self._prepare_working_view():
                            if self._retry_runtime_setup():
                                self.stop_event.wait(.2);continue
                            return
                        prepared=True
                    reading=read_flight(frame);self._budget_update(reading,now)
                    if self.cfg.get('area_search_rescue',False):self._track_working_area(reading)
                    if self._network_guard(now):
                        self.stop_event.wait(.06);continue
                    if self._map_teleport_tick(frame,reading,now):
                        self.stop_event.wait(.06);continue
                    if self._network_defense_tick(now):
                        self.stop_event.wait(.06);continue
                    if self._no_yield_tick(frame,reading,now):
                        self.stop_event.wait(.06);continue
                    if self._return_exit_tick(frame,reading,now):
                        self.stop_event.wait(.06);continue
                    if self._terrain_recovery_tick(frame,reading,now):
                        self.stop_event.wait(.06);continue
                    if self._check_route_damage(frame,now):
                        self.stop_event.wait(.06);continue
                    if self._resource_fast_tick(frame,reading,now):
                        self.stop_event.wait(.06);continue
                    if self._patrol_escape_tick(frame,reading,now):
                        self.stop_event.wait(.06);continue
                    if self._approach_fast_tick(frame,origin,reading,now):
                        self.stop_event.wait(.06);continue
                    if (self.cfg.get('world_map_enabled') and self.region.ready and not self.cfg.get('dry_run')
                        and not self.return_exit_guard and self.mode=='SEARCH' and not self.resource_hold and not self.collecting_visible
                        and not self.nav.is_retreating(now)
                        and now>=self.post_gather_until and not self.pitch.returning and self.nav.air_since is None
                        and self.probe is None and self.pending_probe is None and not self.view_guard.active
                        and self.camera_alignment_due is None
                        and self.wing_close_pending is None
                        and now>=self.region.next_check):
                        self._check_world_map();continue
                    with self.snapshot_lock:snapshot=self.snapshot
                    navigation=self._navigation_observation(snapshot,now)
                    if navigation is None:
                        self._neutral();self.stop_event.wait(.08);continue
                    obs,captured,sequence=navigation
                    self.observation_captured_at=captured
                    radar=self.minimap.observe(frame)
                    if not self.cfg.get('minimap_search',True):radar.markers=[]
                    self.step(frame,origin,obs,radar,reading,now,sequence)
                    if self.stop_event.wait(.09):break
                except Exception as exc:
                    if not self._runtime_failure(exc):raise
                    try:self.screen.pick()
                    except Exception:pass
                    self.stop_event.wait(.20)
        except Exception as exc:
            self.emit('ОШИБКА: '+repr(exc)+'\n'+traceback.format_exc())
            return self._runtime_failure(exc)

    def run(self,offline=None):
        try:
            while not self.stop_event.is_set():
                if not self._run_session(offline):break
                if self.stop_event.wait(1):break
        finally:
            self.stop(terminal=True)
            if self.release_thread:self.release_thread.join(timeout=5)
            if self.network is not None:self.network.close()
            self.emit(('Сканер остановлен: '+self.halt_reason+'; A и стики сброшены') if self.halt_reason else 'Сканер остановлен; A и стики сброшены')
