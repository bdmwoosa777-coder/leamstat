"""Event positions, never an echo of continuous own movement.

Status layout adapted from TuringBlooming/aion2-hidden-cube-radar,
commit 4a3441ddfe2e2a297dd99c9bccd7ab171a8cc3f1 (MIT).
Copyright (c) 2026 AION2 Hidden Cube Radar contributors.
See LICENSE_HIDDEN_CUBE_MIT.txt. No identity inference from these messages.
"""
import math
import struct


def own_event_position(op, body, own):
    if own is None or op not in ('2a38', '2b38', '0238'):return None
    # Import here to keep the telemetry's input-validation exception identical.
    from network_state import Cursor, Invalid
    c=Cursor(body)
    if op=='0238':
        c.var();c.var();c.take(5)
        if c.u8()!=2 or c.var()!=own:return None
        heading=struct.unpack('<f',c.take(4))[0]
        if not math.isfinite(heading):raise Invalid('cast heading')
        xyz=struct.unpack('<fff',c.take(12))
        # Kind 2 also carries direction vectors for some skills. Those cannot
        # determine world position. This event belongs to TARGET, not caster.
        return xyz if world_position(xyz) else None
    target=c.var();count=c.var() if op=='2a38' else 1
    if not target or count>min(256,(len(body)-c.at)//23):raise Invalid('status count')
    bits=0;fixes=[]
    def boolean():
        nonlocal bits
        if bits==0:c.take(1)
        bits=(bits+1)%8
    for _ in range(count):
        flags=c.u8()
        if flags&~31:raise Invalid('status flags')
        c.var();c.take(20)
        caster=c.var() if flags&1 else 0
        c.take(1)
        if flags&2:c.take(4)
        boolean()
        if flags&4:c.var()
        if flags&8:c.take(4)
        if flags&16:
            xyz=struct.unpack('<fff',c.take(12))
            if not all(math.isfinite(v) and abs(v)<=1000000 for v in xyz):raise Invalid('status position')
            # Conservative: agree on both identities, avoiding differing
            # interpretations of caster/recipient in third-party decoders.
            if target==caster==own and world_position(xyz):fixes.append(xyz)
    if op=='2b38':boolean()
    c.end() # A malformed later entry must not commit an earlier position.
    if not fixes:return None
    # Several status instances may have been applied at different positions.
    # A list does not supply separate timestamps: reject conflicting samples.
    if any(math.dist(fixes[0],p)>100 for p in fixes[1:]):return None
    return fixes[-1]


def world_position(xyz):
    return (all(math.isfinite(v) for v in xyz) and
            abs(xyz[0])<420000 and abs(xyz[1])<420000 and abs(xyz[2])<120000
            and math.hypot(*xyz[:2])>2000)
