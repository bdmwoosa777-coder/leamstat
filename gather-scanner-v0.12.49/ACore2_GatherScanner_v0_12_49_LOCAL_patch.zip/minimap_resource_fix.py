"""Match typed live XYZ to a north-up minimap. No fabricated own coordinates.

The result is a visual estimate used only to order destinations. A minimum
of three non-collinear correspondences and a unique solution are required.
"""
from dataclasses import dataclass
import math,time
import cv2,numpy as np
from spatial import resource_names

@dataclass(frozen=True)
class ResourceFix:
 xy:tuple
 matches:int
 error:float

def locate(state,radar,allowed,seconds=.20):
 if radar is None:return None
 markers=[m for m in radar.markers if m.kind in ('aether','gem')]
 markers=sorted(markers,key=lambda m:m.distance)[:10]
 names=resource_names();nodes=[]
 for n in state.nodes.values():
  name=names.get(n.template)
  if (name not in allowed or not n.visible or n.used==3 or n.removed_reason==4 or n.xyz is None
      or n.actor in state.players or n.actor in state.npcs or n.actor in state.deaths):continue
  if not all(math.isfinite(v) and abs(v)<1e6 for v in n.xyz):continue
  nodes.append(n)
 if not 3<=len(nodes)<=32 or len(markers)<3:return None
 world=np.array([n.xyz[:2] for n in nodes],float)/100
 visual=np.array([(m.x-radar.center[0],m.y-radar.center[1]) for m in markers],float)
 kinds=np.array(['aether' if 'эфир' in names[n.template].lower() else 'gem' for n in nodes])
 mkinds=np.array([m.kind for m in markers]);compatible=kinds[:,None]==mkinds[None,:]
 tolerance=2.5*max(.6,(radar.bounds[2]-radar.bounds[0])/313)
 until=time.perf_counter()+seconds;solutions=[]
 for a in range(len(markers)):
  for b in range(a+1,len(markers)):
   dv=visual[b]-visual[a]
   if np.linalg.norm(dv)<12:continue
   for i in np.flatnonzero(kinds==mkinds[a]):
    js=np.flatnonzero(kinds==mkinds[b]);delta=world[js]-world[i];den=np.sum(delta*delta,axis=1)
    scales=np.divide(delta@dv,den,out=np.zeros(len(js)),where=den>4)
    valid=(scales>.08)&(scales<20)&(np.linalg.norm(delta*scales[:,None]-dv,axis=1)<tolerance)
    for j,scale in zip(js[valid],scales[valid]):
     if time.perf_counter()>until:return None # An incomplete ambiguity search cannot authorize a fix.
     offset=visual[a]-scale*world[i]
     distances=np.linalg.norm((world*scale+offset)[:,None,:]-visual[None,:,:],axis=2)
     distances=np.where(compatible,distances,float('inf'));pairs=np.argwhere(distances<=tolerance)
     used_nodes=set();used_markers=set();chosen=[]
     for ni,mi in sorted(pairs,key=lambda pair:distances[tuple(pair)]):
      if ni in used_nodes or mi in used_markers:continue
      used_nodes.add(ni);used_markers.add(mi);chosen.append((ni,mi))
     if len(chosen)<3:continue
     points=np.float32([visual[mi] for ni,mi in chosen])
     if cv2.contourArea(cv2.convexHull(points))<30:continue
     error=float(np.sqrt(np.mean([distances[ni,mi]**2 for ni,mi in chosen])))
     own=-offset/scale*100
     if not np.isfinite(own).all() or np.max(np.abs(own))>=1e6:continue
     value=ResourceFix(tuple(map(float,own)),len(chosen),error)
     index=next((k for k,old in enumerate(solutions) if math.dist(old.xy,value.xy)<500),None)
     if index is None:solutions.append(value)
     elif (-value.matches,value.error)<(-solutions[index].matches,solutions[index].error):solutions[index]=value
 if not solutions:return None
 solutions.sort(key=lambda item:(-item.matches,item.error));best=solutions[0]
 if len(solutions)>1 and solutions[1].matches==best.matches and solutions[1].error<=best.error+.75:return None
 return best
