# -*- coding: utf-8 -*-
from __future__ import annotations
import json,logging,os,queue,threading,time
os.environ.setdefault('OMP_THREAD_LIMIT','1')
import cv2
cv2.setNumThreads(1)
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from gamepad_input import GamepadInput
from network_feed import NetworkFeed
from gather_stats import GatherStats
from hybrid_engine import HybridGatherEngine as GatherEngine
from screen_capture import ScreenCapture
from minimap_setup import MinimapSetup
from map_setup import MapSetup
from map_click_setup import MapClickSetup
from win_hotkeys import SystemHotkeys
from vision import DEFAULT_NAMES
from camera_working_view import WORKING_VIEW_PRESETS,DEFAULT_WORKING_VIEW_MS,working_view_ms
from return_exit import DEFAULT_EXIT
from post_tp_exit import back_exit_seconds
from autopath_profile import effective as map_profile,RECOMMENDED as MAP_OPTIONS,REQUIRED as MAP_REQUIRED

if os.name=='nt':
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:pass

ROOT=Path(__file__).resolve().parent
CONF=ROOT/'settings_gather.json'
DEFAULT={
 'ether_quick_search':True,'ether_neighbor_handoff':True,'recorded_camp_exit_enabled':False,'terrain_experience_enabled':True,'post_tp_back_exit_enabled':True,'post_tp_back_exit_seconds':13.5,'nearby_ground_exception':False,
 'control_transport':'xbox',
 'smooth_translation_seconds':.75,'ollama_autostart':True,
 'qwen_temporal_enabled':True,'qwen_model':'qwen3-vl:8b-instruct-q4_K_M','qwen_wait_before_start':False,'qwen_models_path':r'C:\Ollama\models',
 'hybrid_camp_exit':True,'hybrid_debug':True,'ground_route_navigation':True,'analyzer_enabled':False,'analyzer_model':'qwen2.5vl:3b','analyzer_url':'http://127.0.0.1:11434',
 'map_safe_return_enabled':True,'map_return_destination':'Рабочий лагерь стального молота','map_return_index':48,
 'scan_frame_checks':True,
 'isolate_vision_processes':True,'responsive_control':True,'minimap_character_arrow':False,'patrol_sprint':True,'patrol_sprint_repeat_seconds':3.0,'aether_absence_seconds':30,
 'scene_navigation_enabled':True,'scene_gpu_device':None,'area_search_rescue':False,
 'no_yield_return_enabled':True,'return_exit_route':DEFAULT_EXIT,
 'terrain_rescue_enabled':True,'terrain_rescue_seconds':90,
 'network_enabled':True,'resource_click_interaction':True,'visual_route_hold':True,'air_search_wide':True,
 'defense_during_approach':False,'defense_arrival_distance':10,
 'only_aether':False,'allow_click':True,'camera_scan':True,'dry_run':False,
 'aether_priority_low_percent':20,'aether_priority_resume_percent':35,
 'probe_retreat_pitch_offset':.20,'probe_retreat_rise_seconds':1.5,
 'assist_manual_target':True,'approach_timeout':60,'approach_stall_seconds':6,
 'gather_timeout':55,'audio_device':'AG271QG4','target_names':list(DEFAULT_NAMES),
 'defense_air_search':True,'collection_event_driven':True,'native_cursor_chord':True,'preserve_owned_resource':True,'repeat_owned_clicks':True,'calibrate_during_collection':False,'collection_cursor_hold':True,'debug_screenshots':False,'click_backend':'gamepad','ground_walk':True,
 'minimap_search':True,'minimap_roi':[],'minimap_templates':[],
 'minimap_threshold':.80,'gem_icon_threshold':.74,'target_missing_seconds':.6,
 'cursor_alt':True,'a_gap_seconds':.32,'flight_low_percent':8.0,
 'flight_resume_percent':18.0,'navigation_stall_seconds':6,'camera_yaw_sign':1,
 'scan_seconds':3.5,
 'patrol_leg_seconds':24,'patrol_walk_speed':.78,'resource_walk_speed':.90,
 'steering_deadband_degrees':16,'camera_pulse_seconds':.12,'camera_settle_seconds':.55,
 'heading_min_confidence':.30,'air_search_map_radius':22,'air_pitch_strength':.45,
 'map_mousekeys_enabled':False,'map_autopath_required':True,'map_use_builtin':True,'map_farm_radius_m':450,'map_mousekeys_fly_long':True,'map_mousekeys_flight_distance_m':80,'map_mousekeys':{},'world_map_enabled':False,'world_map_check_seconds':12,'world_map':{},
 'protect_player':True,'player_name':'Darkleam','threat_roi':[.665,.028,.752,.054],
 'patrol_escape_enabled':False,'flight_retry_delay':3,'retreat_seconds':5,'air_sweep_pause_seconds':.9,'gather_idle_seconds':6,
 'hp_fast_seconds':.05,'hp_ocr_seconds':.20,'hp_roi':[.405,.858,.477,.888],
 'flight_probe_enabled':False,'flight_probe_min_percent':18,'probe_pitch_offset':.12,
 'probe_rise_seconds':1.0,'probe_peek_seconds':.8,'auto_view_recovery':True,
 'defense_max_tabs':8,'defense_max_cycles':6,
 'ground_search_map_radius':8,'navigation_unknown_stall_seconds':12,'minimap_goal_timeout_seconds':45,
 'camera_auto_calibrate':True,'camera_working_view_ms':DEFAULT_WORKING_VIEW_MS,
}

def read_config():
 try:r=json.loads(CONF.read_text(encoding='utf-8'))
 except Exception:r={}
 r.pop('network_exe',None)
 r.setdefault('map_mousekeys_enabled',True)
 return map_profile({**DEFAULT,**r})

class UI:
    def __init__(self):
        self.root=tk.Tk();self.root.title('ACore2 Gather Scanner v0.12.49 — игровой автопуть + сбор')
        self.root.geometry('1100x980')
        self.cfg=read_config();self.q=queue.Queue();self.worker=None;self.engine=None
        self.file_log=logging.getLogger('gather_scanner')
        self.file_log.setLevel(logging.INFO)
        try:
            handler=logging.FileHandler(ROOT/'gather.log',encoding='utf-8')
            handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
            self.file_log.addHandler(handler)
        except OSError:pass
        self.gamepad=None
        self.vars={}
        self._start_token=0
        self._start_pending=False
        self._closing=False
        self._retired_qwen=[]
        self.route_record=None;self.gather_stats=GatherStats();self.stats_update_at=0
        self.stats_feed=None;self.stats_preparing=False
        row=ttk.Frame(self.root,padding=10);row.pack(fill='x');self.option_widgets={}
        for key,label in [('map_mousekeys_enabled','ОСНОВНОЙ РЕЖИМ: автопуть игры по встроенной карте Альтгарда (G9 Lua)'),('map_mousekeys_fly_long','Для дальних точек от 80 м сразу лететь при энергии от 50%'),('terrain_experience_enabled','Запоминать удачные обходы по рельефу миникарты'),('post_tp_back_exit_enabled','После подтверждённого ТП: выйти назад без движения камеры'),('analyzer_enabled','Эксперимент Qwen3-VL 8B: обход по кадрам и миникарте (SETUP_ANALYZER.bat)'),('qwen_wait_before_start','Ждать готовности Qwen перед стартом (для отдельной проверки ИИ)'),('scene_navigation_enabled','Старый обход DirectML (не нужен при игровом автопути)'),('map_safe_return_enabled','Возврат через карту к указанному ниже кибелиску'),('network_enabled','Встроенная сеть: подтверждать сбор и удары (Npcap)'),('dry_run','Только наблюдение (НЕ нажимать)'),('allow_click','Выбирать ресурс, проверять его ID и повторным кликом запускать сбор'),('minimap_search','Искать иконки ресурсов на миникарте (в автопути без патруля стиком)'),('assist_manual_target','Продолжать сбор уже выбранного ресурса'),('only_aether','Приоритет эфира; самоцветы при низкой энергии или 30 с без эфира на миникарте'),('nearby_ground_exception','Исключение: один самоцвет рядом при подсказке Сбор, выбор значка без B'),('camera_scan','Коротко осматривать вверх-вниз: эфир и наземные ресурсы'),('flight_probe_enabled','Один пробный подъём крыльями над препятствием'),('patrol_escape_enabled','Выход из застревания при патруле: короткий отлёт вбок'),('ground_walk','Патрулировать и двигаться к ресурсам стиком Xbox'),('patrol_sprint','Ускоряться на A при непрерывном наземном беге по свободному проходу'),('protect_player','Защита: подтверждённый удар → RS (цель) → два RB'),('world_map_enabled','Сверять положение по большой карте и возвращаться в настроенную зону')]:
            v=tk.BooleanVar(value=bool(self.cfg.get(key)))
            self.vars[key]=v
            option=ttk.Checkbutton(row,text=label,variable=v,command=self._map_mode_options if key=='map_mousekeys_enabled' else None);option.pack(anchor='w');self.option_widgets[key]=option
            if self.cfg.get('map_mousekeys_enabled') and key in MAP_REQUIRED:option.state(['disabled'])
        returns=ttk.Frame(self.root,padding=5);returns.pack(fill='x')
        ttk.Label(returns,text='Кибелиск возврата:').pack(side='left')
        self.return_name=tk.StringVar(value=self.cfg.get('map_return_destination',DEFAULT['map_return_destination']))
        ttk.Entry(returns,textvariable=self.return_name,width=40).pack(side='left',padx=5)
        ttk.Label(returns,text='№ в списке:').pack(side='left')
        self.return_index=tk.StringVar(value=str(self.cfg.get('map_return_index',48)))
        ttk.Entry(returns,textvariable=self.return_index,width=5).pack(side='left',padx=5)
        netrow=ttk.Frame(self.root,padding=5);netrow.pack(fill='x')
        modelsrow=ttk.Frame(self.root,padding=5);modelsrow.pack(fill='x')
        ttk.Label(modelsrow,text='Папка моделей Ollama (для автозапуска):').pack(side='left')
        self.models_path=tk.StringVar(value=self.cfg.get('qwen_models_path',''))
        ttk.Entry(modelsrow,textvariable=self.models_path,width=48).pack(side='left',padx=5)
        recorder=ttk.Frame(self.root,padding=5);recorder.pack(fill='x')
        ttk.Label(recorder,text='Выход после загрузки: держать назад').pack(side='left')
        self.back_exit_seconds=tk.StringVar(value=str(back_exit_seconds(self.cfg)))
        ttk.Combobox(recorder,textvariable=self.back_exit_seconds,values=('13','13.5','14'),width=5,state='readonly').pack(side='left',padx=5)
        ttk.Label(recorder,text='с; первые 1,2 с также вправо. Камеру не трогать.').pack(side='left')
        ttk.Button(netrow,text='Состояние сети',command=self.network_status).pack(side='left',padx=5)
        ttk.Button(netrow,text='Анализатор',command=self.analyzer_status).pack(side='left',padx=5)
        ttk.Button(netrow,text='Состояние ИИ',command=self.scene_status).pack(side='left',padx=5)
        ttk.Label(netrow,text='Захват встроен. CubeRadar выбирать и запускать не требуется.').pack(side='left')
        camera=ttk.Frame(self.root,padding=5);camera.pack(fill='x')
        self.vars['camera_auto_calibrate']=tk.BooleanVar(value=self.cfg.get('camera_auto_calibrate',True))
        ttk.Checkbutton(camera,text='Автокалибровка камеры: 2 с вверх, затем вниз на',variable=self.vars['camera_auto_calibrate']).pack(side='left')
        self.working_ms=tk.StringVar(value=str(working_view_ms(self.cfg)))
        ttk.Combobox(camera,textvariable=self.working_ms,values=[str(v) for v in WORKING_VIEW_PRESETS],width=5,state='readonly').pack(side='left',padx=5)
        ttk.Label(camera,text='мс (650–1200, сила 0,45; при следующей калибровке)').pack(side='left')
        connection=ttk.Frame(self.root,padding=5);connection.pack(fill='x')
        ttk.Label(connection,text='Выбор ресурса:').pack(side='left')
        self.backend=tk.StringVar(value=self.cfg.get('click_backend','gamepad'))
        ttk.Combobox(connection,textvariable=self.backend,values=['gamepad'],width=12,state='readonly').pack(side='left',padx=5)
        ttk.Button(connection,text='Подключить Xbox',command=self.connect_gamepad).pack(side='left',padx=5)
        ttk.Button(connection,text='Настроить миникарту / добавить иконку',command=self.setup_minimap).pack(side='left',padx=5)
        ttk.Label(connection,text='Радиус фарма, м:').pack(side='left',padx=5)
        self.map_radius=tk.StringVar(value=str(self.cfg.get('map_farm_radius_m',450)))
        ttk.Spinbox(connection,from_=150,to=1000,increment=50,textvariable=self.map_radius,width=5).pack(side='left')
        maprow=ttk.Frame(self.root,padding=5);maprow.pack(fill='x')
        ttk.Button(maprow,text='Галочки для автопути',command=self.map_recommended).pack(side='left',padx=5)
        ttk.Button(maprow,text='Проверить новый Lua',command=self.check_map_lua).pack(side='left',padx=5)
        ttk.Label(maprow,text='Карта встроена; ручная привязка не нужна.').pack(side='left')
        ttk.Label(self.root,text='Xbox: сбор и бой. Автопуть: Lua v0.12.49, G9, макрос AION_MAP_RMB; Num Lock не трогать.',foreground='#245').pack(anchor='w',padx=10)
        ttk.Label(self.root,text='Физический F710/USB-приёмник отключите. Старые Lua-приёмники выключите; для нового автопути оставьте только GHUB_MAP_MOUSEKEYS.lua.',foreground='#a43').pack(anchor='w',padx=10)
        buttons=ttk.Frame(self.root,padding=10);buttons.pack(fill='x')
        ttk.Button(buttons,text='Сохранить настройки',command=self.save).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F8 Старт/пауза',command=self.toggle).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F9 СТОП',command=self.stop).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F10 Заглушить сигнал',command=self.silence).pack(side='left',padx=3)
        ttk.Button(buttons,text='ТЕСТ по двум кадрам',command=self.offline).pack(side='left',padx=3)
        journal=ttk.Frame(self.root,padding=5);journal.pack(fill='x')
        ttk.Button(journal,text='Скопировать журнал',command=self.copy_log).pack(side='left',padx=4)
        ttk.Button(journal,text='Сохранить журнал...',command=self.save_log).pack(side='left',padx=4)
        ttk.Button(journal,text='Папка журнала',command=self.open_log_folder).pack(side='left',padx=4)
        ttk.Button(journal,text='Диагностический кадр через 3 с',command=self.diagnostic).pack(side='left',padx=4)
        statistics=ttk.Frame(self.root,padding=5);statistics.pack(fill='x')
        self.stats_label=ttk.Label(statistics,text=self.gather_stats.describe(),wraplength=670);self.stats_label.pack(side='left')
        ttk.Button(statistics,text='Статистика',command=self.show_stats).pack(side='right',padx=3)
        ttk.Button(statistics,text='Сброс счётчика',command=self.reset_stats).pack(side='right',padx=3)
        ttk.Button(statistics,text='Подготовить счётчик',command=self.prepare_stats).pack(side='right',padx=3)
        self.status=ttk.Label(self.root,text='Не запущено');self.status.pack(anchor='w',padx=10)
        self.box=tk.Text(self.root,height=23,wrap='word');self.box.pack(fill='both',expand=True,padx=10,pady=10)
        self.root.after(180,self.pump)
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.hotkeys=SystemHotkeys(self.q)
        self.root.after(150,self.connect_gamepad)

    def show_stats(self):
        self.log('STATS: '+self.gather_stats.describe().replace('\n',' | '))
    def reset_stats(self):
        self.gather_stats.reset();self.stats_label.config(text=self.gather_stats.describe())
        self.log('STATS: счётчик и время сброшены; управление ботом не менялось')
    def prepare_stats(self):
        if self._closing:return
        if self._start_pending or self.worker and self.worker.is_alive():
            self.log('STATS: подготовка доступна при остановленном боте; сначала пауза Ctrl+F8.');return
        if getattr(self,'stats_preparing',False):return
        prepared=getattr(self,'stats_feed',None)
        if prepared is not None and not prepared.closed.is_set() and not prepared.error:
            self.log('STATS: захват уже включён. Открой инвентарь и нажми сортировку, затем закрой его и запусти бота.');return
        self.gather_stats.capture_gap()
        network=NetworkFeed(logger=self.log);network.gather_stats=self.gather_stats
        self.stats_feed=network;self.stats_preparing=True
        def work():
            try:
                if prepared is not None:prepared.close()
                network.start()
                if self._closing or self.stats_feed is not network:network.close();return
                self.log('STATS: только захват, кнопки не нажимаю. Открой инвентарь и нажми сортировку для исходных количеств; затем закрой его и нажми Ctrl+F8. Дождись строки «исходный инвентарь получен».')
            except Exception as exc:
                network.close()
                if self.stats_feed is network:self.stats_feed=None
                self.log('STATS: подготовка не удалась: '+str(exc))
            finally:self.stats_preparing=False
        threading.Thread(target=work,daemon=True).start()
    def _close_prepared_stats(self):
        network=getattr(self,'stats_feed',None);self.stats_feed=None
        if network is not None:threading.Thread(target=network.close,daemon=True).start()
    def network_status(self):
        network=(self.engine.network if self.engine else None) or getattr(self,'stats_feed',None)
        self.log(network.describe() if network else 'Сеть запускается вместе с ботом по Ctrl+F8. Нужен установленный Npcap.')

    def analyzer_status(self):
        host=self.engine.analyzer if self.engine else None
        if host is None:self.log('ANALYZER: включается вместе с ботом; установка — SETUP_ANALYZER.bat');return
        if getattr(host,'preparation_pending',False) and not host.busy:self.log('ANALYZER: '+getattr(host,'phase','подготовка отложена'));return
        if host.busy:self.log('ANALYZER: '+getattr(host,'phase','анализ')+('; ожидаю ИИ перед стартом' if getattr(self,'_start_pending',False) and self.cfg.get('qwen_wait_before_start',False) else '; подготовка в фоне, запуск сборщика её не ждёт'));return
        if getattr(host,'suspended',False):self.log('ANALYZER: помощник приостановлен: '+str(host.error or 'ошибка/задержка')+'. Сборщик продолжает без Qwen; новый Ctrl+F8 повторит подготовку. Подробности: qwen_runtime_status.json');return
        if getattr(host,'prepared',False) and not host.ready and not host.error:self.log('ANALYZER: модель подготовлена; ожидаю запрос по игровой обстановке');return
        self.log('ANALYZER: '+('готов, '+(self.cfg.get('qwen_model','qwen3-vl:8b-instruct-q4_K_M') if self.cfg.get('qwen_temporal_enabled',False) else self.cfg.get('analyzer_model','qwen2.5vl:3b')) if host.ready else 'не подключён: '+str(host.error or 'ожидаю первый кадр')))

    def scene_status(self):
        host=self.engine.scene_host if self.engine else None
        if host is None:
            self.log('SCENE: '+('загрузится после Ctrl+F8; настройка ИИ включена' if self.vars['scene_navigation_enabled'].get() else 'ИИ выключен; используется прежняя навигация'))
            return
        if host.error:self.log('SCENE ERROR: '+host.error);return
        with host.lock:reading=host.latest
        if reading is None:self.log('SCENE: загрузка моделей или ожидание первого кадра; подробности в журнале');return
        self.log(f'SCENE: {reading.backend}, последний результат {max(0,time.monotonic()-reading.captured):.2f} с назад, обработка {reading.elapsed_ms:.0f} мс. При повороте устаревший кадр не используется.')

    def connect_gamepad(self):
        if self.gamepad:return True
        try:
            self.gamepad=GamepadInput(logger=self.log)
            self.log('Xbox готов. Оставьте программу открытой; приёмник F710 можно отключить.')
            return True
        except Exception as exc:
            self.log('Xbox не подключён: '+str(exc))
            return False

    def setup_minimap(self):
        self.stop('НАСТРОЙКА МИНИКАРТЫ')
        self.log('Снимок через 4 секунды: переключитесь в игру, откройте миникарту с видимой иконкой ресурса.')
        self.root.iconify()
        self.root.after(4000,self._capture_minimap)

    def _capture_minimap(self):
        if self._closing:return
        if self.worker and self.worker.is_alive():
            self.root.after(250,self._capture_minimap);return
        try:
            screen=ScreenCapture()
            if not screen.pick():raise RuntimeError('Окно AION2 не найдено')
            frame,_=screen.frame()
            self.root.deiconify()
            MinimapSetup(self.root,frame,self.cfg,self._minimap_saved)
        except Exception as exc:
            self.root.deiconify();self.log('Не удалось настроить миникарту: '+str(exc))

    def _minimap_saved(self):
        self.vars['minimap_search'].set(True)
        self.save()
        self.log('Миникарта сохранена. Иконок-эталонов: '+str(len(self.cfg['minimap_templates'])))

    def setup_world_map(self):
        self.stop('НАСТРОЙКА ЗОНЫ')
        self.log('Снимок через 5 секунд: переключитесь в игру и физически откройте большую карту M.')
        self.root.iconify();self.root.after(5000,self._capture_world_map)

    def _map_mode_options(self):
        for key,widget in getattr(self,'option_widgets',{}).items():
            if key in MAP_REQUIRED:widget.state(['disabled'] if self.vars['map_mousekeys_enabled'].get() else ['!disabled'])
        if self.vars['map_mousekeys_enabled'].get():
            self.cfg.update(MAP_REQUIRED)
            for key,value in MAP_REQUIRED.items():
                if key in self.vars:self.vars[key].set(value)
            self.log('MAP_MODE: игровой автопуть; старый патруль, DirectML, спринт и выход назад отключены')
    def map_recommended(self):
        self.cfg.update(MAP_OPTIONS)
        for key,value in MAP_OPTIONS.items():
            if key in self.vars:self.vars[key].set(value)
        self._map_mode_options();self.save();self.log('MAP_OPTIONS: рекомендуемые галочки применены. Save & Run нового Lua, G9, затем Старт')
    def setup_map_click(self):
        self.stop('НАСТРОЙКА АВТОПУТИ')
        self.log('Через 5 с снимок: остановись, открой M, оставь видимыми стрелку и три кибелиска вокруг области фарма.')
        self.root.iconify();self.root.after(5000,self._capture_map_click)

    def _capture_map_click(self):
        if self._closing:return
        if self.worker and self.worker.is_alive():self.root.after(250,self._capture_map_click);return
        try:
            screen=ScreenCapture()
            if not screen.pick():raise RuntimeError('Окно AION2 не найдено')
            frame,_=screen.frame()
            from map_teleport import is_map
            if not is_map(frame):raise RuntimeError('Нужна открытая большая карта M')
            self.root.deiconify();MapClickSetup(self.root,frame,self.cfg,self._map_click_saved)
        except Exception as exc:self.root.deiconify();self.log('Настройка автопути: '+str(exc))

    def _map_click_saved(self):
        self.vars['map_mousekeys_enabled'].set(True);self.vars['world_map_enabled'].set(False);self.save()
        self.log('Автопуть настроен. В G HUB установи GHUB_MAP_MOUSEKEYS.lua и нажми G9 один раз; проверь Lua, затем запускай бота.')

    def check_map_lua(self):
        self.stop('ПРОВЕРКА НОВОГО LUA')
        self.log('Переключись в AION2. Через 3 с отправлю только PING, без клика и движения. Lua-приёмник должен быть включён нажатием G9.')
        self.root.iconify()
        def run():
            from map_mousekeys import MapMouseKeys
            bridge=None
            try:
                screen=ScreenCapture()
                if not screen.pick():raise RuntimeError('Окно AION2 не найдено')
                bridge=MapMouseKeys(self.log);result=bridge.ping(lambda:not self._closing and screen.focused())
                self.log('Проверка Lua: '+result.reason)
            except Exception as exc:self.log('Проверка Lua: '+str(exc))
            finally:
                if bridge is not None:bridge.close()
        self.root.after(3000,lambda:threading.Thread(target=run,daemon=True).start())

    def _capture_world_map(self):
        if self._closing:return
        if self.worker and self.worker.is_alive():
            self.root.after(250,self._capture_world_map);return
        try:
            screen=ScreenCapture()
            if not screen.pick():raise RuntimeError('Окно AION2 не найдено')
            frame,_=screen.frame();self.root.deiconify()
            MapSetup(self.root,frame,self.cfg,self._world_map_saved)
        except Exception as exc:
            self.root.deiconify();self.log('Не удалось настроить зону: '+str(exc))

    def _world_map_saved(self):
        self.vars['world_map_enabled'].set(True);self.save()
        self.log('Зона сохранена. Закройте большую карту перед запуском; бот открывает её кнопкой Start.')
    def log(self,t):
        self.file_log.info(str(t));self.q.put(str(t))

    def copy_log(self):
        value=(ROOT/'gather.log').read_text(encoding='utf-8') if (ROOT/'gather.log').exists() else self.box.get('1.0','end')
        self.root.clipboard_clear();self.root.clipboard_append(value)
        self.log('Журнал скопирован в буфер обмена')

    def open_log_folder(self):
        try:os.startfile(str(ROOT))
        except Exception as exc:messagebox.showerror('Папка журнала',str(exc),parent=self.root)

    def save_log(self):
        destination=filedialog.asksaveasfilename(parent=self.root,title='Сохранить журнал',
            defaultextension='.txt',initialfile='gather_log.txt',filetypes=[('Текст','*.txt'),('Все','*.*')])
        if destination:
            try:
                value=(ROOT/'gather.log').read_text(encoding='utf-8') if (ROOT/'gather.log').exists() else self.box.get('1.0','end')
                Path(destination).write_text(value,encoding='utf-8');self.log('Журнал сохранён: '+destination)
            except Exception as exc:messagebox.showerror('Журнал',str(exc),parent=self.root)

    def diagnostic(self):
        self.stop('ДИАГНОСТИЧЕСКИЙ КАДР')
        self.log('Через 3 секунды снимок игры; затем снова Ctrl+F8 для работы')
        self.root.iconify();self.root.after(3000,self._diagnostic_capture)

    def _diagnostic_capture(self):
        try:
            from diagnostics import analyze
            screen=ScreenCapture()
            if not screen.pick():raise RuntimeError('Окно игры не найдено')
            frame,_=screen.frame();path=ROOT/'debug_gather'/('diagnostic_'+time.strftime('%Y%m%d_%H%M%S'))
            data=analyze(frame,self.cfg,path)
            self.log('Диагностика: '+str(path)+'.png / .json')
            self.log('Энергия/дуга: '+str(data['flight'])+'; направление: '+str(data['radar']['heading'])+'; иконок: '+str(len(data['radar']['markers'])))
        except Exception as exc:self.log('Ошибка диагностики: '+str(exc))
        finally:self.root.deiconify()
    def pump(self):
        for _ in range(40):
            try:s=self.q.get_nowait()
            except queue.Empty:break
            if isinstance(s,tuple) and s[0]=='hotkey':
                {'toggle':self.toggle,'stop':self.stop,'silence':self.silence}[s[1]]()
                continue
            s=str(s)
            self.box.insert('end',s+'\n');self.box.see('end')
            self.status.config(text=s[:110])
        stats=getattr(self,'gather_stats',None)
        if stats is not None and time.monotonic()>=getattr(self,'stats_update_at',0):
            self.stats_update_at=time.monotonic()+1
            if self.engine is not None and self.engine.stop_event.is_set():stats.pause()
            if hasattr(self,'stats_label'):self.stats_label.config(text=stats.describe())
        self.root.after(180,self.pump)
    def save(self):
        destination=None
        if hasattr(self,'return_name'):
            try:
                name=self.return_name.get().strip();index=int(self.return_index.get().strip())
                if not name or not 1<=index<=999:raise ValueError()
                destination=(name,index)
            except ValueError:
                messagebox.showerror('Кибелиск возврата','Укажите полное имя и целый номер 1–999.',parent=self.root)
                return False
        for k,v in self.vars.items():self.cfg[k]=bool(v.get())
        self.cfg=map_profile(self.cfg)
        for key,value in MAP_REQUIRED.items():
            if self.cfg.get('map_mousekeys_enabled') and key in self.vars:self.vars[key].set(self.cfg[key])
        if hasattr(self,'back_exit_seconds'):self.cfg['post_tp_back_exit_seconds']=back_exit_seconds({'post_tp_back_exit_seconds':self.back_exit_seconds.get()})
        if self.cfg.get('post_tp_back_exit_enabled',True):self.cfg['recorded_camp_exit_enabled']=False
        if hasattr(self,'models_path'):self.cfg['qwen_models_path']=self.models_path.get().strip()
        if hasattr(self,'map_radius'):
            try:self.cfg['map_farm_radius_m']=max(150,min(1000,float(self.map_radius.get())))
            except ValueError:self.cfg['map_farm_radius_m']=450
        self.cfg['click_backend']=self.backend.get()
        self.cfg['camera_working_view_ms']=working_view_ms({'camera_working_view_ms':self.working_ms.get()})
        if destination:self.cfg['map_return_destination'],self.cfg['map_return_index']=destination
        CONF.write_text(json.dumps(self.cfg,ensure_ascii=False,indent=2),encoding='utf-8')
        if self.engine is not None:self.engine.cfg['camera_working_view_ms']=self.cfg['camera_working_view_ms']
        if self.engine is not None:
            for key in ('post_tp_back_exit_enabled','post_tp_back_exit_seconds'):self.engine.cfg[key]=self.cfg.get(key,DEFAULT[key])
        if self.engine is not None and destination:
            self.engine.cfg['map_return_destination'],self.engine.cfg['map_return_index']=destination
        self.log('Настройки сохранены; наклон '+str(self.cfg['camera_working_view_ms'])+' мс применяется при следующей калибровке')
        return True
    def toggle(self):
        record=getattr(self,'route_record',None)
        if record is not None:
            record.finish_request.set();self.log('ROUTE_RECORD: завершаю запись; бот не запускается');return
        active=(self._start_pending or
                (self.worker is not None and self.worker.is_alive() and
                 self.engine is not None and not self.engine.stop_event.is_set()))
        if active:
            self.stop('ПАУЗА Ctrl+F8')
        else:
            self.start()

    def start(self):
        if self._closing:return
        if getattr(self,'route_record',None) is not None:
            self.log('ROUTE_RECORD: сначала заверши запись Ctrl+F8 или отмени Ctrl+F9');return
        if self._start_pending:return
        if self.worker and self.worker.is_alive() and self.engine and not self.engine.stop_event.is_set():
            self.log('Скан уже запущен')
            return
        self._start_token+=1
        token=self._start_token
        self._start_pending=True
        self.log('Ctrl+F8: запрос запуска, после завершения прежнего цикла')
        self.root.after(10,lambda:self._launch_if_ready(token))

    def _launch_if_ready(self,token):
        if self._closing or not self._start_pending or token!=self._start_token:return
        if getattr(self,'stats_preparing',False):
            self.root.after(150,lambda:self._launch_if_ready(token));return
        if self.worker and self.worker.is_alive():
            self.root.after(150,lambda:self._launch_if_ready(token))
            return
        old_adviser=getattr(self.engine,'analyzer',None) if self.engine else None
        if getattr(old_adviser,'temporal',False) is True:old_adviser.close()
        wants_qwen=(self.vars['analyzer_enabled'].get() if hasattr(self,'vars') and 'analyzer_enabled' in self.vars else self.cfg.get('analyzer_enabled'))
        wait_qwen=(self.vars['qwen_wait_before_start'].get() if hasattr(self,'vars') and 'qwen_wait_before_start' in self.vars else self.cfg.get('qwen_wait_before_start',False))
        retired=getattr(self,'_retired_qwen',[])
        if getattr(old_adviser,'temporal',False) is True and not any(h is old_adviser for h in retired):retired.append(old_adviser)
        self._retired_qwen=retired
        if wants_qwen and wait_qwen and any(self._qwen_cleanup_pending(h) for h in retired):
            from camp_memory import load_routes,store_path
            record_enabled=(self.vars['recorded_camp_exit_enabled'].get() if hasattr(self,'vars') and 'recorded_camp_exit_enabled' in self.vars else self.cfg.get('recorded_camp_exit_enabled',True))
            try:has_recorded=bool(record_enabled and load_routes(store_path(self.cfg)))
            except (OSError,ValueError):has_recorded=False
            if not has_recorded:
                now=time.monotonic()
                if now-getattr(self,'_old_qwen_wait_note',-1e9)>=5:
                    self._old_qwen_wait_note=now;self.log('Ожидаю завершения прежнего запроса/выгрузки Qwen перед новым запуском.')
                self.root.after(150,lambda:self._launch_if_ready(token));return
        if self.save() is False:
            self._start_pending=False;return
        if not self.cfg['dry_run'] and not (self.cfg['allow_click'] or self.cfg.get('assist_manual_target') or self.cfg.get('ground_walk')):
            self._start_pending=False
            messagebox.showwarning('Режим','Для ввода включите «Автоподход» или используйте режим наблюдения.')
            return
        if self.engine:self.engine.silence() # stop prior alarm before explicit manual restart
        if not self.cfg['dry_run'] and self.cfg.get('click_backend')=='gamepad' and not self.connect_gamepad():
            self._start_pending=False;return
        network=None
        if self.cfg.get('network_enabled') and not self.cfg['dry_run']:
            network=getattr(self,'stats_feed',None);self.stats_feed=None
            if network is not None and (network.error or network.closed.is_set()):
                threading.Thread(target=network.close,daemon=True).start();network=None
            if network is None:
                stats=getattr(self,'gather_stats',None)
                if stats is not None:stats.capture_gap()
                network=NetworkFeed(logger=self.log)
            network.gather_stats=getattr(self,'gather_stats',None)
        else:self._close_prepared_stats()
        self.engine=GatherEngine(dict(self.cfg),self.log,gamepad=None if self.cfg['dry_run'] else self.gamepad,network=network)
        host=getattr(self.engine,'analyzer',None)
        if getattr(host,'temporal',False) is True:
            host.preparation_pending=True
            self._qwen_preflight_started=time.monotonic();self._qwen_wait_note=-1e9
            if getattr(self.engine,'recorded_routes',()):
                host.phase='Qwen отложен до завершения записанного выхода'
                self._qwen_route_defer_until=time.monotonic()+12
                self.log('QWEN_DEFERRED: сначала проверю/повторю записанный выход без модели; затем подготовлю помощника в фоне.')
                self.root.after(250,lambda:self._qwen_after_recorded_exit(token,host))
                self._schedule_game_start(token);return
            if self.cfg.get('qwen_wait_before_start',False):
                host.prepare()
                self.log('Включено ожидание Qwen: управление начнётся после проверки ответа; Ctrl+F9 отменяет подготовку.')
                self.root.after(150,lambda:self._await_qwen(token,host));return
            self.log('QWEN_BACKGROUND: подготовка помощника в фоне. Сборщик запускается через обычные 3 с, без ожидания Qwen.')
            self._prepare_qwen_background(token,host)
        self._schedule_game_start(token)

    def _qwen_after_recorded_exit(self,token,host):
        if self._closing or token!=self._start_token or getattr(self.engine,'analyzer',None) is not host or host.stop.is_set():return
        camp=getattr(self.engine,'camp_route',None)
        # A failed replay is still an unfinished departure. Loading a large
        # model here starves the local scene worker exactly when it is needed.
        pending=bool(camp is not None or getattr(self.engine,'hybrid_camp_pending',False))
        if self._start_pending or pending or time.monotonic()<self._qwen_route_defer_until:
            self.root.after(250,lambda:self._qwen_after_recorded_exit(token,host));return
        self._prepare_qwen_background(token,host)

    @staticmethod
    def _qwen_cleanup_pending(host):
        return bool(getattr(host,'busy',False) or getattr(host,'unloading',False) or getattr(host,'touched_model',False))

    def _prepare_qwen_background(self,token,host):
        # Old unload must finish before a new load, but never blocks Xbox/control.
        # Retain every retiring host across rapid stop/start, not just the last one.
        if self._closing or token!=self._start_token or getattr(self.engine,'analyzer',None) is not host:return
        if getattr(host,'stop',None) is not None and host.stop.is_set():return
        self._retired_qwen=[h for h in getattr(self,'_retired_qwen',[]) if self._qwen_cleanup_pending(h)]
        if self._retired_qwen:
            host.phase='ожидание прежнего запроса/выгрузки'
            now=time.monotonic()
            if now-getattr(self,'_qwen_wait_note',-1e9)>=5:
                self._qwen_wait_note=now;self.log('QWEN_BACKGROUND: ожидаю прежнюю выгрузку; управление сборщика её не ждёт.')
            self.root.after(150,lambda:self._prepare_qwen_background(token,host));return
        host.prepare()
        self.root.after(150,lambda:self._watch_qwen_background(token,host))

    def _watch_qwen_background(self,token,host):
        if self._closing or token!=self._start_token or getattr(self.engine,'analyzer',None) is not host:return
        if getattr(host,'stop',None) is not None and host.stop.is_set():return
        if host.busy:
            now=time.monotonic()
            if now-self._qwen_wait_note>=5:
                self._qwen_wait_note=now
                self.log('QWEN_BACKGROUND: '+host.phase+', '+str(round(now-self._qwen_preflight_started))+' с; управление сборщика не ожидает ИИ.')
            self.root.after(150,lambda:self._watch_qwen_background(token,host));return
        if host.prepared:self.log('QWEN_BACKGROUND_READY: помощник подготовлен; игровые советы будут проверяться отдельно.')
        else:self.log('QWEN_BACKGROUND_ERROR: '+str(host.error or 'подготовка отменена')+'; сборщик продолжает без Qwen. Подробности: qwen_runtime_status.json.')

    def _await_qwen(self,token,host):
        if self._closing or not self._start_pending or token!=self._start_token:return
        if host.busy:
            now=time.monotonic()
            if now-self._qwen_wait_note>=5:
                self._qwen_wait_note=now
                self.log('Подготовка Qwen: '+host.phase+', '+str(round(now-self._qwen_preflight_started))+' с. Управление ещё не запущено.')
            self.root.after(150,lambda:self._await_qwen(token,host));return
        if not host.prepared:
            self.log('Qwen не подготовлен: '+str(host.error or 'подготовка отменена')+'. Запускаю обычный сбор без помощника; подробности: qwen_runtime_status.json.')
            host.close();self._schedule_game_start(token);return
        self.log('Qwen подготовлен и ответ проверен. Начинаю запуск бота.')
        self._schedule_game_start(token)

    def _schedule_game_start(self,token):
        if self._closing or not self._start_pending or token!=self._start_token:return
        self.log('Переключитесь в AION2. Через 3 с проверю G9 Lua и Xbox; поиск — только автопутём.' if self.cfg.get('map_mousekeys_enabled') else 'Переключитесь в AION2. Через 3 с проверю Xbox.' if getattr(self.engine.bridge,'controller_native',False) else 'Переключитесь в AION2 и включите Lua через G9. Через 3 с проверю Alt.')
        if self.cfg.get('camera_auto_calibrate') and self.cfg.get('camera_scan') and not self.cfg.get('dry_run'):
            self.log('Камера при запуске: автоматически около 2 с вверх, затем '+str(self.cfg['camera_working_view_ms'])+' мс вниз. Ручная подготовка не нужна.')
        self.root.after(3000,lambda:self._go(token))

    def _go(self,token):
        if self._closing or not self._start_pending or token!=self._start_token:return
        self._start_pending=False
        if not self.engine or self.engine.stop_event.is_set():return
        stats=getattr(self,'gather_stats',None)
        if stats is not None:stats.start()
        self.worker=threading.Thread(target=self.engine.run,daemon=True)
        self.worker.start()

    def stop(self,reason='СТОП Ctrl+F9'):
        self._start_token+=1
        self._start_pending=False
        record=getattr(self,'route_record',None)
        if record is not None:record.cancel.set();self.route_record=None
        if self.engine:self.engine.stop(manual=True)
        self._close_prepared_stats()
        stats=getattr(self,'gather_stats',None)
        if stats is not None:
            stats.pause();self.log('STATS: '+stats.describe().replace('\n',' | '))
        self.log(reason+': скан/CAPTCHA/смерть остановлены')

    def recorded_exit_status(self):
        from camp_memory import load_routes,store_path
        try:
            path=store_path(self.cfg);routes=load_routes(path)
            self.log('ROUTE_STORE: '+str(path))
            self.log('Записанные выходы: '+('; '.join(r.place+' — '+str(len(r.points))+' точек' for r in routes) if routes else 'нет записей'))
        except Exception as exc:self.log('ROUTE_STORE: '+str(exc))

    def record_exit(self):
        if self._closing:return
        if getattr(self,'route_record',None) is not None:
            self.route_record.finish_request.set();return
        if self.save() is False:return
        self.stop('ЗАПИСЬ ВЫХОДА')
        from camp_memory import RecordingSession
        record=RecordingSession(self.cfg,self.log);self.route_record=record;token=self._start_token
        self.log('ROUTE_RECORD: переключись в игру. После сигнала пройди обычным бегом через выход, без прыжков/крыльев; Ctrl+F8 — сохранить, Ctrl+F9 — отменить. Ввод бота выключен.')
        self.root.after(3000,lambda:self._begin_exit_record(token,record))

    def _begin_exit_record(self,token,record):
        if self._closing or token!=self._start_token or getattr(self,'route_record',None) is not record or record.cancel.is_set():return
        if self.worker and self.worker.is_alive():
            self.root.after(150,lambda:self._begin_exit_record(token,record));return
        record.start();self.root.after(150,lambda:self._poll_exit_record(token,record))

    def _poll_exit_record(self,token,record):
        if self._closing or token!=self._start_token or getattr(self,'route_record',None) is not record:return
        if not record.done.is_set():self.root.after(150,lambda:self._poll_exit_record(token,record));return
        self.route_record=None
        if record.error:self.log('ROUTE_RECORD_ERROR: '+record.error+'. Прежняя запись сохранена.');return
        if record.saved is None:self.log('ROUTE_RECORD: запись отменена');return
        self.cfg['recorded_camp_exit_enabled']=True
        if 'recorded_camp_exit_enabled' in self.vars:self.vars['recorded_camp_exit_enabled'].set(True)
        self.save();self.log('ROUTE_RECORDED: '+record.saved.place+'; '+str(len(record.saved.points))+' точек. Вернись к началу у кибелиска и запусти бот Ctrl+F8.')
        self.recorded_exit_status()

    def silence(self):
        if self.engine:self.engine.silence()
        self.log('Ctrl+F10: прекращён текущий звук CAPTCHA/смерти; состояние скана не изменено')

    def offline(self):
        if self._start_pending or (self.worker and self.worker.is_alive()):return
        cfg={**self.cfg,'dry_run':True,'allow_click':False,'camera_scan':False}
        self.engine=GatherEngine(cfg,self.log)
        samples=[ROOT/'testdata/orihalkon_example.jpg',ROOT/'testdata/air_gather_example.jpg']
        self.worker=threading.Thread(target=lambda:self.engine.run(offline=samples),daemon=True)
        self.worker.start()
    def close(self):
        self._closing=True
        self.stop('ЗАКРЫТИЕ')
        self.silence()
        self.hotkeys.stop()
        if self.gamepad:self.gamepad.close()
        self.root.after(500,self.root.destroy)
    def run(self):self.root.mainloop()

if __name__=='__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    UI().run()
