"""Run the actual dedicated Lua over a virtual LED wire; no OS/game input."""
from pathlib import Path
import threading,unittest
from types import SimpleNamespace
from unittest.mock import patch
try:from lupa import LuaRuntime
except ImportError:LuaRuntime=None
from map_key_wire import map_codes
from map_mousekeys import MapMouseKeys
from test_lua_transport import Wire

class ReceiverStopped(Exception):pass

def lua_run(commands,cancel=False,button=9):
 w=Wire([]);w.flags_at_click=[]
 at=100
 for command in commands:
  if command not in ('PING','RIGHT_STEP','MAP','JUMP'):continue
  for bit in map_codes(command):
   w.events.extend([(at,{"capslock":bool(bit),"numlock":True,"scrolllock":False}),(at+45,{"scrolllock":True}),(at+170,{"scrolllock":False})]);at+=250
  at+=650
 w.end=at+100;w.states["numlock"]=True
 if cancel:
  for t,state in w.events:
   if t>400 and 'scrolllock' in state:state['scrolllock']=True
 def press(key):
  if key in ('capslock','numlock'):w.states[key]=not w.lock(key)
  if key=='num5':w.flags_at_click.append(w.lock('numlock'))
  w.press(key)
 l=LuaRuntime();g=l.globals();g.IsKeyLockOn=w.lock;g.GetRunningTime=lambda:w.now;g.Sleep=lambda ms:sleep(ms)
 def sleep(ms):
  w.sleep(ms)
  if w.now>w.end:raise ReceiverStopped()
 def unsupported_poll(button):raise AssertionError('G9 must start by OnEvent, not IsMouseButtonPressed(9)')
 g.IsMouseButtonPressed=unsupported_poll
 g.PressKey=press;g.ReleaseKey=w.release;g.PressAndReleaseKey=lambda key:(press(key),w.release(key));g.OutputLogMessage=lambda *a:None
 l.execute((Path(__file__).parent/'GHUB_MAP_MOUSEKEYS.lua').read_text())
 try:g.OnEvent('MOUSE_BUTTON_PRESSED',button)
 except ReceiverStopped:pass
 return w

@unittest.skipIf(LuaRuntime is None,'Optional lupa is not installed')
class DedicatedLua(unittest.TestCase):
 def test_g9_event_starts_receiver_and_delivers_map_command(self):
  w=lua_run(['MAP'],button=9);self.assertEqual(sum(a=='down' and k=='m' for t,a,k in w.keys),1)
 def test_old_mouse5_no_longer_arms_receiver(self):
  w=lua_run(['MAP'],button=5);self.assertEqual(w.keys,[])
 def test_loading_without_g9_does_not_start_gameplay(self):
  w=lua_run(['RIGHT_STEP'],button=8);self.assertEqual(w.keys,[])
 def test_user_confirmed_numeric_sequence_and_numlock_on_at_click(self):
  w=lua_run(['RIGHT_STEP']);downs=[k for t,a,k in w.keys if a=='down']
  self.assertEqual([k for k in downs if k in ('numminus','num5')],['numminus','num5'])
  self.assertEqual(w.flags_at_click,[True]);self.assertFalse(w.held)
 def test_receiver_never_sends_raw_mouse_or_movement_keys(self):
  w=lua_run(['RIGHT_STEP','MAP','JUMP','F_ON','V','ATTACK_PAIR'])
  allowed={'numminus','num5','numlock','capslock','m','f'}
  self.assertTrue(all(k in allowed for t,a,k in w.keys));self.assertFalse(w.held)
 def test_map_and_flight_opcode_are_single_m_and_f(self):
  w=lua_run(['MAP','JUMP']);d=[k for t,a,k in w.keys if a=='down']
  self.assertEqual(d.count('m'),1);self.assertEqual(d.count('f'),1);self.assertNotIn('num5',d)
 def test_ping_ack_has_no_gameplay_key(self):
  w=lua_run(['PING']);self.assertTrue(all(k in ('capslock','numlock') for t,a,k in w.keys if a=='down'))
 def test_scroll_abort_during_numeric_delay_prevents_num5(self):
  w=lua_run(['RIGHT_STEP'],True);self.assertFalse(any(a=='down' and k=='num5' for t,a,k in w.keys))

class FakeWire:
 dry_run=False
 def __init__(self,ack=True):
  self.lock=threading.RLock();self.keys={20:False,144:True};self.ack=ack;self.sent=[];self.toggles=[];self.authorized=True
  self.win=SimpleNamespace(GetKeyState=lambda key:int(self.keys.get(key,False)))
 def send_guarded(self,name,authorize):
  if not authorize():return False
  self.sent.append(name);cap=bool(map_codes(name)[-1])
  self.keys[20]=not cap if self.ack else cap;self.keys[144]=True;return True
 def _toggle(self,key,value):self.keys[key]=value;self.toggles.append((key,value))
 def restore_locks(self):pass

class Transport(unittest.TestCase):
 def setUp(self):
  self.clock=100
  def sleep(x):self.clock+=x
  for p in (patch('map_mousekeys.time.monotonic',side_effect=lambda:self.clock),patch('map_mousekeys.time.sleep',side_effect=sleep)):
   p.start();self.addCleanup(p.stop)
 def make(self,ack=True,enabled=True):
  self.w=FakeWire(ack);return MapMouseKeys(wire=self.w,enabled=lambda:enabled)
 def test_old_lua_without_ack_cannot_enable_map_clicks(self):
  tr=self.make(False);self.assertFalse(tr.ping(lambda:True).acknowledged);self.assertFalse(tr.click(lambda:True).attempted)
  self.assertEqual(self.w.sent,['PING'])
 def test_ping_then_single_click_has_real_dispatch_ack(self):
  tr=self.make();self.assertTrue(tr.ping(lambda:True).acknowledged)
  self.assertTrue(tr.click(lambda:True).acknowledged);self.assertEqual(self.w.sent,['PING','RIGHT_STEP'])
 def test_mousekeys_setting_is_required(self):
  tr=self.make(enabled=False);self.assertFalse(tr.ping(lambda:True).attempted);self.assertEqual(self.w.sent,[])
 def test_unauthorized_command_is_not_dispatched(self):
  tr=self.make();self.assertFalse(tr.ping(lambda:False).attempted);self.assertEqual(self.w.sent,[])
 def test_ack_loss_is_never_retried_as_a_second_click(self):
  tr=self.make();tr.ping(lambda:True);self.w.ack=False
  r=tr.click(lambda:True);self.assertTrue(r.attempted);self.assertFalse(r.acknowledged)
  self.assertFalse(tr.click(lambda:True).attempted);self.assertEqual(self.w.sent.count('RIGHT_STEP'),1)
 def test_flight_f_and_map_have_separate_explicit_calls(self):
  tr=self.make();tr.ping(lambda:True);tr.confirm_flight(lambda:True);tr.map_toggle(lambda:True)
  self.assertEqual(self.w.sent,['PING','JUMP','MAP'])

if __name__=='__main__':unittest.main()
