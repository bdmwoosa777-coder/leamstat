-- CLICK v0.12.47.1 / MAP WIRE V2, G502 HERO. Replace the old map Lua, Save & Run, press G9.
-- Windows Mouse Keys and Num Lock must already be ON.
-- Num Lock is NEVER pressed: it may be the game's autorun hotkey.
-- CapsLock = one data bit, ScrollLock = clock. 010 + hi + lo + XOR.
local ARM_BUTTON=9
local function tap(key)
    PressKey(key);Sleep(50);ReleaseKey(key)
end
local function receiver()
    local prev=IsKeyLockOn("scrolllock")
    local phase,hi,lo=0,0,0
    local last=GetRunningTime()
    OutputLogMessage("[MAP CLICK 47.1] G9 ARMED; atomic numeric keys; Num Lock untouched\n")
    while true do
        local now=GetRunningTime()
        if phase~=0 and now-last>850 then phase=0 end
        local clock=IsKeyLockOn("scrolllock")
        if not IsKeyLockOn("numlock") then phase=0 end
        if clock and not prev and IsKeyLockOn("numlock") then
            local bit=IsKeyLockOn("capslock") and 1 or 0
            last=now
            if phase==0 then
                if bit==0 then phase=1 end
            elseif phase==1 then
                if bit==1 then phase=2 else phase=1 end
            elseif phase==2 then
                if bit==0 then phase=3 else phase=0 end
            elseif phase==3 then hi=bit;phase=4
            elseif phase==4 then lo=bit;phase=5
            else
                phase=0
                if bit==(hi+lo)%2 then
                    local cmd=hi*2+lo
                    local final_caps=IsKeyLockOn("capslock")
                    -- Let the host finish the last strobe before any action.
                    local until_low=GetRunningTime()+350
                    while IsKeyLockOn("scrolllock") and GetRunningTime()<until_low do Sleep(12) end
                    local allowed=not IsKeyLockOn("scrolllock") and IsKeyLockOn("numlock")
                    if allowed and cmd==1 then
                        PressAndReleaseKey("numminus");Sleep(100)
                        allowed=not IsKeyLockOn("scrolllock") and IsKeyLockOn("numlock")
                        if allowed then
                            PressAndReleaseKey("num5")
                            OutputLogMessage("[MAP CLICK 47.1] PressAndReleaseKey numminus / 100 ms / num5; Num Lock untouched\n")
                        end
                    elseif allowed and cmd==2 then tap("m")
                    elseif allowed and cmd==3 then tap("f") end
                    if allowed then
                        -- ACK only after key release, never an in-game success.
                        if IsKeyLockOn("capslock")==final_caps then tap("capslock") end
                        OutputLogMessage("[MAP V2] ACK cmd=%d\n",cmd)
                    else OutputLogMessage("[MAP V2] ABORT; no ACK\n") end
                else OutputLogMessage("[MAP V2] invalid parity\n") end
            end
        end
        prev=clock;Sleep(12)
    end
end
function OnEvent(event,arg)
    if event=="MOUSE_BUTTON_PRESSED" and arg==ARM_BUTTON then receiver() end
end
