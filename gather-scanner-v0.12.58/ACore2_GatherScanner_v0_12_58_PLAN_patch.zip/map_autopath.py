"""Game-owned pathfinding selected with G HUB Mouse Keys on the verified map."""
import math,time
from copy import copy
from map_next_goal import NextGoalPlanner,LivePoint,PlanRequest
from dataclasses import dataclass,replace
from gamepad_input import GamepadInput
from flight import read_flight
from auto_route_hud import route_hud
from map_teleport import is_map,menu_stamp,same_stamp
from map_coordinates import MapCoordinates,MapGoal
from map_mousekeys import MapMouseKeys
from vision import gathering_panel_pair
from map_flight_dialog import flight_dialog,same as same_flight_dialog
from map_arrival import ArrivalSearch
from map_terminal import FinalApproach

@dataclass
class PathRun:
 phase:str
 started:float
 since:float
 reason:str
 flow:object
 owner:object
 goal:object=None
 fix:object=None
 attempted:bool=False
 hud_seen:bool=False
 missing:int=0
 missing_since:float|None=None
 near:int=0
 best:float|None=None
 progress:float=0
 check_at:float=0
 hud_at:float=0
 ack:bool=False
 map_open:bool=False
 finishing:bool=False
 failed:bool=False
 result:str=''
 pending_air:bool=False
 wing_sent:bool=False
 close_retries:int=0
 switches:int=0
 straight:float=0
 dialog_sent:bool=False
 dialog:object=None
 centered_open:bool=False
 arrival_xy:tuple|None=None
 short_check:bool=False
 mini_sampled:bool=False
 correction_clicks:int=0
 projection_bias:tuple|None=None
 projection_source:str=''

class MapAutopath:
 def __init__(self,cfg,emit):
  self.cfg=cfg;self.emit=emit;self.coordinates=MapCoordinates(cfg);self.transport=None
  self.run=None;self.next_at=0;self.ping_after=0;self.stopping=False;self.force_camp=False
  self.escape_next=False;self.last_goal=None;self.last_note=-1e9
  self.cancelling=False;self.visual_until=0;self.arrival=None;self.initial_search_done=False
  if cfg.get('map_mousekeys_enabled') and not self.coordinates.ready:
   emit('MAP_SETUP_REQUIRED: карта недоступна; движение стиком заблокировано' if self.required else 'MAP_SETUP_REQUIRED: сначала «Автопуть: настроить карту»; пока используется прежняя навигация')
 @property
 def required(self):return bool(self.cfg.get('map_autopath_required',False))
 @property
 def enabled(self):return bool(self.cfg.get('map_mousekeys_enabled') and self.coordinates.ready)
 @property
 def owns(self):return self.run is not None
 @property
 def searching(self):return getattr(self,'arrival',None) is not None
 def inspect(self,e,now,goal=None,initial=False,position=None):
  refine=getattr(self.coordinates,'refine_goal',None)
  view=e._net_view()
  if goal is not None and view and view['ready'] and callable(refine):goal=refine(goal,view['state'])
  self.arrival=ArrivalSearch(goal,now,initial);self.visual_until=now+45;self.next_at=now+45
  if goal is not None and not initial:self.arrival.terminal=FinalApproach(goal,position,destination_check=True)
  e.nav.finish_goal(now);e.change_mode('SEARCH')
  self.emit('MAP_LOCAL_SEARCH: '+('короткая проверка после ошибки пути' if initial else 'прибытие к '+(goal.name if goal else 'точке'))+'; направляю камеру и довожу подход по миникарте до выбора ресурса')
 def local_tick(self,e,now):
  search=getattr(self,'arrival',None)
  if search is None:return False
  if e.target_confirmed or e.resource_hold or e._own_collection() is not None:
   self.arrival=None;self.visual_until=0;self.next_at=now
   self.emit('MAP_LOCAL_TARGET: ресурс принят старым контроллером; продолжаю полный сбор');return False
  busy=e.camera_in_progress or e.pitch.returning or e.caption_latch is not None or now<search.candidate_until or e.mode not in ('SEARCH','ACQUIRE_WAIT')
  if busy:search.pause(now);return True
  follow=getattr(self.coordinates,'followup_goal',None)
  corrected=follow(search.goal,now) if search.goal is not None and callable(follow) else None
  view=e._net_view() if corrected is not None else None
  if corrected is not None and view and view['ready'] and (getattr(self,'correction_target',None)!=corrected.key or getattr(self,'corrected_until',0)<now):
   self.corrected_until=now+45;self.correction_target=corrected.key
   self.preferred_goal=(view['flow'],view['state'].own,corrected,now+8)
   self.arrival=None;self.next_at=now;self.visual_until=0
   self.emit('MAP_CORRECT_TARGET: текущая иконка ресурса дальше справочной точки; повторно веду автопутём к точке миникарты')
   return False
  empty=bool(search.terminal is not None and getattr(search.terminal,'finished',False) and 'нет текущей отметки' in search.terminal.finished_reason)
  if not empty and not search.expired(now):return True
  self.arrival=None;self.visual_until=0;self.next_at=now
  if search.goal:self.coordinates.defer(search.goal,now,45)
  self.emit('MAP_LOCAL_EMPTY: ограниченный осмотр завершён без выбранного ресурса; наблюдений='+str(search.observed)+'; поиск='+str(round(search.elapsed,1))+' с; выбираю следующую близкую цель')
  return False
 def _transport(self,e):
  if self.transport is None:self.transport=MapMouseKeys(self.emit,e.cfg.get('dry_run',False))
  return self.transport
 def permitted(self,e):
  if self.stopping or e.stop_event.is_set() or not e._focus_ok() or e.cfg.get('dry_run'):return False
  if e.target_confirmed or e.resource_hold or e.collecting_visible or e._urgent_damage_pending() and not self.owns and not self.required:return False
  view=e._net_view()
  return bool(view and view['ready'] and (view['state'].own is not None or self.required) and e._own_collection(view) is None and not e._live_attempt(view))
 def phase(self,name,now):
  run=self.run
  if run is not None:run.phase=name;run.since=now
 def cancel(self,e,reason,move=True):
  run=self.run
  if run is None:return
  self.run=None
  # A real movement is sent ONLY for an explicit cancellation, never as patrol.
  if run.map_open and e._focus_ok():
   frame,_=e.screen.frame()
   if is_map(frame) and self.transport is not None:
    self._toggle_map(e,lambda:e._focus_ok());GamepadInput.wait(.18,e.stop_event,e.screen.focused)
    run.map_open=is_map(e.screen.frame()[0])
  e.map_active=run.map_open;e.change_mode('SEARCH');self.next_at=time.monotonic()+3
  if run.map_open:
   e.map_menu_stamp=None;e.map_exit_failure={'reason':'автопуть: закрытие карты не подтверждено','since':time.monotonic(),'sent':False,'absent':None}
  if move and run.attempted and not run.map_open and e._focus_ok() and e._own_collection() is None:
   self._cancel_motion(e)
  self.coordinates.defer(run.goal,time.monotonic(),30)
  self.emit('MAP_PATH_CANCEL: '+reason)
 def stop(self,e):
  self.stopping=True
  self.clear_next_plan()
  self.arrival=None
  self.cancel(e,'остановка бота',move=True)
  if self.transport is not None:
   try:self.transport.close()
   except Exception as exc:self.emit('MAP_LUA_CLOSE: '+str(exc))
 def finish(self,e,now):
  run=self.run
  self.run=None;e.map_active=False;e.change_mode('SEARCH');self.next_at=now+(3 if run.failed else 12)
  e.no_yield.next_return=max(e.no_yield.next_return,now+20)
  if self.required:
   self.visual_until=0;self.next_at=now+(2 if run.failed else 0)
  if run.failed and run.attempted and run.hud_seen and e._focus_ok() and e._own_collection() is None:
   self._cancel_motion(e)
  if run.goal and (run.failed or not self.required):self.coordinates.defer(run.goal,now,45 if run.failed else 20)
  self.emit(('MAP_PATH_FAIL: ' if run.failed else 'MAP_PATH_DONE: ')+run.result)
  if run.failed:
   self.escape_next=not run.pending_air and bool(self.coordinates.spec.get('air_points'))
   if self.required and run.reason=='resources':self.inspect(e,now,run.goal,initial=True)
  else:
   self.escape_next=False
   if run.pending_air and run.goal:
    e.resource_flight_owned=True;e.wing_close_pending=now;e.wing_close_started=now;e.wing_close_retries=0
   e.identity_valid_after=now;e.nav.finish_goal(now)
   if self.required:self.inspect(e,now,run.goal,position=run.arrival_xy)
 def _cancel_motion(self,e):
  self.cancelling=True
  try:
   e.gamepad.drive(-.35,0,0,0,lifetime=.06);GamepadInput.wait(.07,e.stop_event,e.screen.focused);e._neutral()
  finally:self.cancelling=False
 def end(self,now,failed,reason):
  run=self.run
  if run is None:return
  run.failed=failed;run.finishing=True;run.result=reason;run.phase='CLOSE';run.since=now
 def _toggle_map(self,e,authorize):
  result=self.transport.map_toggle(authorize)
  if not result.attempted and authorize():
   # This is a verified no-dispatch fallback, never a duplicate uncertain M.
   return e.bridge_cmd('MAP')
  return result.attempted
 @staticmethod
 def idle_service(e):
  # These flags are cleared by the ordinary engine AFTER this scheduler.
  # Waiting here would starve the very handler that can finish the work.
  for field,label in (('wing_close_pending','подтверждение закрытия крыльев'),
                      ('defense_restore_view','возврат камеры после защиты'),
                      ('camera_alignment_due','рабочий наклон камеры'),
                      ('view_recovery','завершение проверки ресурса')):
   if getattr(e,field,None) is not None:return label
  if e.pitch.returning:return 'возврат наклона камеры'
  return None
 def start(self,e,frame,now):
  if (not self.enabled or now<self.next_at or self.idle_service(e) or not self.permitted(e) or e.mode!='SEARCH'
      or e.caption_latch is not None or e.terrain_recovery is not None or e.post_tp_exit is not None
      or e.map_active or e.map_teleport is not None or e.camera_in_progress or e.pitch.returning
      or e.wing_close_pending is not None or e.click_busy or e.return_exit_guard):return False
  if self.required and not getattr(e,'map_start_view_prepared',True):return False
  view=e._net_view()
  if not self.coordinates.valid_layer(view['state']):return False
  if hasattr(self.coordinates,'set_nearby'):
   radar=e.minimap.observe(frame) if not is_map(frame) else None
   self.coordinates.set_nearby(view['state'],radar,now)
  if not is_map(frame):e._budget_update(read_flight(frame),now)
  if now<self.ping_after:return False
  tr=self._transport(e)
  if not tr.ready:
   self.ping_after=now+15
   result=tr.ping(lambda:self.permitted(e))
   if not result.acknowledged:
    self.emit('MAP_LUA_WAIT: '+result.reason+'; нужен GHUB_MAP_MOUSEKEYS.lua, профиль G502 и нажатие G9. Старый сбор остаётся доступен')
    return False
   self.ping_after=0
  reason='camp' if self.force_camp or e.hybrid_camp_pending else 'escape' if self.escape_next else 'resources'
  e._neutral();e._release_collection_cursor();e._clear_view_recovery()
  preferred=getattr(self,'preferred_goal',None);self.preferred_goal=None
  goal=preferred[2] if preferred and preferred[0:2]==(view['flow'],view['state'].own) and now<=preferred[3] else None
  ticket=getattr(e,'return_resource',None)
  if goal is None and reason=='resources' and ticket is not None:
   ticket.observe(view,now)
   if not ticket.done and not ticket.returning and ticket.ready_at is not None and now<ticket.ready_at:return False
   if (not ticket.done and not ticket.returning and ticket.ready_at is not None and now>=ticket.ready_at and ticket.xyz is not None
       and (ticket.name!='Эфир' or e.budget.can_start() and e.policy.allows('Эфир'))):
    from map_reference import transform
    n=view['state'].nodes.get(ticket.actor)
    if n is not None and n.visible and n.used!=3:
     xyz=n.xyz if n.xyz is not None else ticket.xyz
     goal=MapGoal(('node',view['state'].map_id,n.actor,n.generation),ticket.name,transform(xyz[:2],self.coordinates.matrix),tuple(xyz),n.xyz is not None)
     e.resource_retry_after.pop((view['flow'],n.actor),None) # This one verified return must not inherit its 45 s acquisition cooldown.
     ticket.returning=True;self.emit('MAP_RESOURCE_RETURN: прежде дальнейшей цели возвращаюсь к недособранному ID='+str(n.actor))
  self.run=PathRun('OPEN',now,now,reason,view['flow'],view['state'].own,progress=now,goal=goal)
  self.force_camp=False;e.camp_route=None;e.hybrid_camp_pending=False;e.camp_exit_until=0;e.camp_rearm=False
  e.terrain_recovery=None;e.probe=None;e.pending_probe=None;e.patrol_escape=None;e.nav.air_since=None
  e.change_mode('MAP_PATH');self.emit('MAP_PATH_START: '+reason+'; левый стик заблокирован')
  return True
 def clear_next_plan(self):
  planner=getattr(self,'next_planner',None)
  if planner is not None:planner.close()
  self.next_planner=None;self.next_plan=None;self.planner_context=None;self.planner_origin=None
  if hasattr(self.coordinates,'prepared_catalogue'):self.coordinates.prepared_catalogue=None
 def prefetch(self,e,view,node,now):
  if now<getattr(self,'planner_retry_at',0):return
  try:self._prefetch(e,view,node,now)
  except Exception as exc:
   self.clear_next_plan();self.planner_retry_at=now+5
   self.emit('MAP_NEXT_ERROR: расчёт пропущен без остановки сбора: '+str(exc))
 def _prefetch(self,e,view,node,now):
  c=self.coordinates
  if not self.enabled or not self.required or self.stopping or e.stop_event.is_set() or not getattr(c,'automatic',False) or not c.valid_layer(view['state']):
   self.clear_next_plan();return
  state=view['state'];spec=c.catalogue_spec();context=(view['flow'],state.own,state.map_id,spec)
  if getattr(self,'planner_context',None)!=context:
   previous=getattr(self,'next_planner',None)
   if previous is not None:previous.close()
   self.next_planner=None;self.next_plan=None;self.planner_context=context
   self.planner_origin=None;self.next_plan_at=0;c.prepared_catalogue=None
  owned=e._own_collection(view)
  anchor=node.xyz if node is not None else None
  if anchor is None and node is not None and self.last_goal is not None and self.last_goal.name==e.target:anchor=self.last_goal.xyz
  active=bool(node is not None and state.attempt_active and e.mode=='GATHER' and anchor is not None
              and len(anchor)==3 and all(math.isfinite(v) for v in anchor) and owned is not None
              and (owned.actor,owned.generation,owned.gather_time)==(node.actor,node.generation,node.gather_time))
  if active and getattr(self,'planner_origin',None)!=(node.actor,node.generation):
   self.planner_origin=(node.actor,node.generation);self.next_plan=None;self.next_plan_at=0
  planner=getattr(self,'next_planner',None)
  if planner is not None:
   try:result=planner.poll()
   except Exception as exc:
    planner.close();self.next_planner=None;self.next_plan=None;self.next_plan_at=now+5
    self.emit('MAP_NEXT_ERROR: предварительный расчёт пропущен; сбор продолжается: '+str(exc));return
   if result is not None and result.context==context and result.origin==self.planner_origin and 0<=now-result.created<=30:
    previous=getattr(self,'next_plan',None);self.next_plan=result
    c.prepared_catalogue=result.catalogue;c.prepared_catalogue_spec=spec
    if result.ranked and (previous is None or not previous.ranked or previous.ranked[0].key!=result.ranked[0].key):
     first=result.ranked[0];distance=math.dist(first.xyz[:2],result.anchor)/100
     self.emit('MAP_NEXT_READY: во время своего сбора подготовлено '+str(len(result.ranked))+' целей; '+first.name+' ~'+str(round(distance,1))+' м; '+('живой ID' if first.live else 'место из каталога')+'; перед выходом перепроверю')
  if not active or now<getattr(self,'next_plan_at',0):return
  policy=copy(e.policy);policy.update(e.budget)
  names=frozenset(policy.names(e.cfg.get('target_names',('Эфир','Алмаз','Сапфир','Рубин'))))
  from spatial import resource_names
  labels=resource_names()
  live=tuple(LivePoint(n.actor,n.generation,n.template,labels.get(n.template) or e.claimed_names.get((view['flow'],n.actor)) or (e.target if n.actor==node.actor else None),tuple(n.xyz) if n.xyz is not None else None,
                       n.visible,n.used,n.removed_reason,n.actor in state.players or n.actor in state.npcs or n.actor in state.deaths)
             for n in state.nodes.values() if n.xyz is None or len(n.xyz)==3 and all(math.isfinite(v) for v in n.xyz))
  if planner is None:
   planner=NextGoalPlanner(c.catalogue_sources(),c.matrix);self.next_planner=planner
  request=PlanRequest(context,self.planner_origin,tuple(anchor[:2]),now,names,policy.priority,
                      e.budget.can_start() and policy.allows('Эфир'),live,tuple(c.cooldown.items()),tuple(c.location_cooldown.items()),
                      c.farm_center,c.farm_radius)
  if planner.submit(request):self.next_plan_at=now+1.5
 def completed_location(self,e,view,node,now):
  state=view['state'];context=(view['flow'],state.own,state.map_id)
  record=getattr(self,'own_location',None)
  if record is not None and (record[0]!=context or now-record[4]>90):self.own_location=None;record=None
  if node is not None:
   goal=None
   if node.xyz is not None and e.target:
    from map_reference import transform
    goal=MapGoal(('node',state.map_id,node.actor,node.generation),e.target,transform(node.xyz[:2],self.coordinates.matrix),tuple(node.xyz),True)
   elif self.last_goal is not None and self.last_goal.name==e.target:
    goal=self.last_goal
   if goal is not None:
    self.own_location=(context,node.actor,node.generation,goal,now);record=self.own_location
  if record is None:return
  result=state.last_own_result;n=state.nodes.get(record[1])
  if (result and result[0]==record[1] and state.last_own_result_used==3 and n is not None
      and n.used==3 and n.generation==record[2]):
   self.coordinates.defer(record[3],now,75);self.own_location=None
   self.emit('MAP_RESOURCE_DONE: собственный полный сбор; точка исключена из ближайших маршрутов на 75 с')
 def tick(self,e,frame,now):
  view=e._net_view()
  if view and view['ready']:
   context=getattr(self.coordinates,'observe_context',None)
   if callable(context):context(view['state'],view['flow'])
   node=e._own_collection(view)
   if self.enabled:self.completed_location(e,view,node,now)
   remember=getattr(self.coordinates,'remember_collection',None)
   if node is not None and callable(remember):remember(view['state'],node,view['flow'],now)
   self.prefetch(e,view,node,now)
  else:self.clear_next_plan()
  if self.run is None:
   if self.required and not getattr(e,'map_start_view_prepared',True):return False
   if self.local_tick(e,now):return False
   service=self.idle_service(e)
   if service is not None:
    if self.required and now-self.last_note>=3:
     self.last_note=now;self.emit('MAP_SERVICE: '+service+'; передаю управление обработчику, затем следующий маршрут')
    return False
   visible=getattr(e,'_visible_resource_before_map',None)
   if (self.required and e.mode=='SEARCH' and now>=self.next_at and callable(visible)
       and not is_map(frame) and self.permitted(e) and visible(frame,now)):return False
   if not self.start(e,frame,now):
    if self.searching:return False
    if self.required and e.mode=='SEARCH' and not e.target_confirmed and not e.resource_hold and e._own_collection() is None and not e._live_attempt(e._net_view()):
     if now<getattr(self,'visual_until',0) or e.caption_latch is not None or e.camera_in_progress or e.pitch.returning:return False
     e._neutral()
     if now-self.last_note>=3:
      self.last_note=now;self.emit('MAP_WAIT: автопуть ожидает готовую карту/сеть/Lua; патруль стиком запрещён')
     return True
    return False
  run=self.run
  view=e._net_view()
  if (not view or not view['ready'] or view['flow']!=run.flow
      or run.owner is not None and view['state'].own!=run.owner):
   self.cancel(e,'потеря подтверждённого соединения');return True
  if run.owner is None and view['state'].own is not None:run.owner=view['state'].own
  if e._own_collection(view) is not None or e._live_attempt(view):
   # Collection already owns the game: a cancellation stick would interrupt it.
   self.cancel(e,'начался свой сбор',move=False);return False
  # The game path survives hits. Do not stop to fight each passing mob.
  if e.caption_latch is not None and not run.map_open:
   self.cancel(e,'найден свежий ресурс в мире');return False
  if not e._focus_ok():e._neutral();return True
  if now-run.started>70:
   self.cancel(e,'общий предел 70 с без бесконечного перепланирования');return True
  if run.attempted and run.phase=='CLOSE' and not run.dialog_sent:
   dialog=flight_dialog(frame)
   if dialog is not None:
    if e.budget.can_probe(18):
     run.dialog_sent=True
     def allowed_dialog():
      return self.permitted(e) and same_flight_dialog(e.screen.frame()[0],dialog.signature)
     result=self.transport.confirm_flight(allowed_dialog)
     if result.attempted:
      run.pending_air=True;run.hud_seen=False;run.best=None;run.progress=time.monotonic()
      run.dialog=dialog;self.phase('FLIGHT_WAIT',run.progress)
      self.emit('MAP_FLIGHT_DIALOG: подтверждён именно вопрос о полёте; '+('энергия не измерена, одна попытка' if e.budget.energy is None else 'энергия '+str(round(e.budget.energy,1)))+'; F передана, взлёт проверяется по кадрам')
     else:self.end(now,True,'подтверждение полёта не передано')
    else:
     fresh,origin=e.screen.frame()
     if same_flight_dialog(fresh,dialog.signature):
      e.bridge.cursor(origin[0]+dialog.cancel[0],origin[1]+dialog.cancel[1])
      e.gamepad.tap_ui_a(e.stop_event,e.screen.focused,lambda:self.permitted(e) and same_flight_dialog(e.screen.frame()[0],dialog.signature))
     self.end(now,True,'энергии для подтверждённого полёта недостаточно')
    return True
  if run.phase=='FLIGHT_WAIT':
   if same_flight_dialog(frame,run.dialog.signature):
    if now-run.since>3:
     fresh,origin=e.screen.frame()
     if same_flight_dialog(fresh,run.dialog.signature):
      e.bridge.cursor(origin[0]+run.dialog.cancel[0],origin[1]+run.dialog.cancel[1])
      e.gamepad.tap_ui_a(e.stop_event,e.screen.focused,lambda:self.permitted(e) and same_flight_dialog(e.screen.frame()[0],run.dialog.signature))
     self.end(now,True,'окно полёта не закрылось; F повторно не нажимаю')
   else:self.phase('CLOSE',now)
   return True
  if run.phase=='MINI_SAMPLE':
   if is_map(frame):
    if now-run.since>3:self.end(now,True,'карта не закрылась для чтения миникарты')
    return True
   e.map_active=False;run.map_open=False
   radar=e.minimap.observe(frame)
   pose=self.coordinates.observe_minimap(frame,radar,view['state'],now)
   if pose is not None or now-run.since>3:
    self.emit('MAP_MINI_FIX: '+('источник='+pose.source+'; совпадений='+str(pose.inliers)+'; качество='+str(round(pose.error,3)) if pose else 'рельеф не подтверждён; использую другие источники'))
    self.phase('OPEN',now)
   return True
  if run.phase=='OPEN':
   e.map_active=True;run.map_open=True
   if is_map(frame):self.phase('MAP',now);return True
   result=self.transport.map_toggle(lambda:self.permitted(e))
   if not result.attempted:self.end(now,True,'карта не открыта: '+result.reason)
   else:run.centered_open=True;self.phase('MAP',time.monotonic())
   return True
  if run.phase in ('MAP','CHECK_MAP'):
   if not is_map(frame):
    if now-run.since>3:self.end(now,True,'M не подтвердилось за 3 с')
    return True
   fix=self._register_map(frame)
   if fix is None:
    if now-run.since>4:self.end(now,True,'карта/стрелка не сопоставлены: '+str(getattr(getattr(self.coordinates,'native',None),'reason','нет привязки')))
    return True
   latest=e._net_view()
   if not latest or not latest['ready'] or latest['flow']!=run.flow or run.owner is not None and latest['state'].own!=run.owner:
    self.cancel(e,'сеть/персонаж изменились во время распознавания карты');return True
   view=latest
   self._prepare_fix(fix,view['state'])
   if (run.phase=='MAP' and run.reason=='resources' and not run.mini_sampled and run.goal is None
       and getattr(self.coordinates,'texture_enabled',False) and getattr(self.coordinates,'nearby_markers',False) and hasattr(self.coordinates,'observe_minimap')
       and not (0<=now-getattr(self.coordinates,'mini_goals_at',-1e9)<=8)):
    run.mini_sampled=True
    self._toggle_map(e,lambda:self.permitted(e));self.phase('MINI_SAMPLE',time.monotonic())
    self.emit('MAP_MINI_SAMPLE: читаю два кадра миникарты для переноса текущих ресурсов на большую карту');return True
   if run.phase=='CHECK_MAP':
    run.arrival_xy=fix.get('world')
    if fix.get('world') is None:
     if run.hud_seen and run.missing>=3:self.end(now,False,'надпись автопути исчезла; свою позицию не измеряю, передаю визуальному поиску')
     elif run.short_check:self.end(now,True,'нет надписи автопути и подтверждённой позиции; клик не повторяю')
     else:self.phase('CLOSE',now)
     return True
    distance=math.dist(fix['world'],self._world_goal(run.goal))/100
    if (distance>6 and run.hud_seen and run.missing>=3
        and fix.get('projection_bias') is not None and run.correction_clicks<1
        and self.coordinates.pixel(run.goal,fix) is not None):
     run.correction_clicks+=1;run.fix=fix;run.attempted=False;run.ack=False
     run.hud_seen=False;run.missing=0;run.missing_since=None;run.near=0;run.best=None;run.progress=now;run.short_check=False
     self.emit('MAP_REPROJECT: подтверждённая поправка; до ТОЙ ЖЕ цели '+str(round(distance,1))+' м; один исправленный маршрут')
     self.phase('CLICK',now);return True
    if run.short_check and not run.hud_seen:
     if run.attempted and distance<=6:self.end(now,False,'короткий маршрут проверен по свежей карте: до точки назначения '+str(round(distance,1))+' м по XY; надпись могла исчезнуть до закрытия M')
     else:self.end(now,True,'нет надписи автопути; по свежей карте до цели '+str(round(distance,1))+' м; клик не повторяю')
    elif distance<15 and run.hud_seen and run.missing>=3:self.end(now,False,'маршрут исчез; до выбранной точки '+str(round(distance,1))+' м по XY; довожу подход по миникарте')
    elif run.hud_seen and run.missing>=3:self.end(now,True,'маршрут исчез вдали от точки; это не прибытие')
    else:self.phase('CLOSE',now)
    return True
   self.emit('MAP_FIX: '+(str(tuple(round(v,1) for v in fix['world'])) if fix.get('world') is not None else 'позиция персонажа неизвестна; цель вычисляется по рельефу')+'; совпадений='+str(fix.get('inliers','?'))+'; область='+str(fix.get('search_source','player_arrow'))+'; кадр='+str(fix.get('frame_size','?'))+'; ошибка рельефа px='+str(fix.get('registration_error_px','?')))
   if run.goal is not None:
    if self.coordinates.pixel(run.goal,fix) is None:self.end(now,True,'заданная точка вышла из вида карты')
    else:run.fix=fix;run.straight=math.dist(fix['world'],self._world_goal(run.goal))/100 if fix.get('world') is not None else 0;run.pending_air=bool(run.goal.air or e.budget.airborne);self.phase('CLICK',now)
    return True
   if self.required:
    e.policy.update(e.budget);self.coordinates.active_names=set(e.policy.names(e.cfg.get('target_names',('Эфир','Алмаз','Сапфир','Рубин'))))
   can_fly=e.budget.can_start() and e.budget.energy is not None and e.budget.energy>=50
   goals=self.coordinates.goals(view['state'],fix,now,e.budget.can_start() and e.policy.allows('Эфир'),e.policy.priority,run.reason=='camp',run.reason=='escape')
   if not goals:
    reason='ближайшая цель не определена: нет позиции персонажа/уникальной привязки миникарты; центр вида не используется' if fix.get('search_source')=='unknown' else 'в видимой области нет подходящей точки'
    self.end(now,True,reason);return True
   if run.reason=='escape' and self.last_goal:
    goals.sort(key=lambda g:math.dist(g.reference,self.last_goal.reference)+.25*math.dist(g.reference,fix.get('search_position') or fix['position']))
   plan=getattr(self,'next_plan',None)
   if plan is not None and 0<=now-plan.created<=30 and run.reason=='resources':
    same=bool(plan.ranked and plan.ranked[0].key==goals[0].key)
    self.emit('MAP_NEXT_CHECK: '+('подготовленная цель подтверждена' if same else 'порядок обновлён по свежей карте/сети')+'; '+goals[0].name)
   run.goal=goals[0];run.fix=fix;run.pending_air=bool(run.goal.air or e.budget.airborne)
   run.straight=math.dist(fix['world'],self._world_goal(run.goal))/100 if fix.get('world') is not None else 0
   if (run.reason!='camp' and can_fly and self.cfg.get('map_mousekeys_fly_long',True)
       and fix.get('projection_bias') is not None
       and run.straight>=max(30,float(self.cfg.get('map_mousekeys_flight_distance_m',80)))):
    run.goal=replace(run.goal,air=True);run.pending_air=True
   if run.goal.air:self.phase('CLOSE_FOR_WINGS',now)
   else:self.phase('CLICK',now)
   return True
  if run.phase=='CLOSE_FOR_WINGS':
   if is_map(frame):self._toggle_map(e,lambda:self.permitted(e));self.phase('WINGS',time.monotonic())
   else:self.phase('WINGS',now)
   e.map_active=False;run.map_open=False;run.centered_open=False;return True
  if run.phase=='WINGS':
   if is_map(frame):
    if now-run.since>3:self.end(now,True,'карта не закрыта перед раскрытием крыльев')
    return True
   reading=read_flight(frame);e._budget_update(reading,now)
   if reading.confirmed:self.phase('OPEN',now);return True
   if reading.swimming or not e.budget.can_start() or e.budget.energy is None or e.budget.energy<50:self.end(now,True,'крылья сейчас недоступны');return True
   if now-run.since>.4 and not run.wing_sent:
    e.bridge_cmd('V');run.wing_sent=True
   if now-run.since>3:self.end(now,True,'раскрытие крыльев не подтверждено')
   return True
  if run.phase=='CLICK':
   if not self.permitted(e):self.end(now,True,'отменено до клика');return True
   fresh,origin=e.screen.frame()
   if not is_map(fresh):self.end(now,True,'карта исчезла до клика');return True
   fix=self._register_map(fresh)
   if fix:self._prepare_fix(fix,view['state'])
   point=self.coordinates.pixel(run.goal,fix) if fix else None
   if point is None:self.end(now,True,'точка вышла из подтверждённого вида карты');return True
   e.bridge.cursor(origin[0]+point[0],origin[1]+point[1])
   if not GamepadInput.wait(.10,e.stop_event,e.screen.focused):return True
   final,final_origin=e.screen.frame();check=self._register_map(final)
   if check:self._prepare_fix(check,view['state'])
   second=self.coordinates.pixel(run.goal,check) if check else None
   if (second is None or final_origin!=origin or math.dist(point,second)>6 or not e.bridge.cursor_matches()
       or not is_map(final) or not self.permitted(e)):
    self.end(now,True,'свежая проверка положения/карты запретила клик');return True
   run.attempted=True
   stamp=menu_stamp(final);patch=self._patch(final,point)
   def click_allowed():
    if not self.permitted(e) or not e.map_active or not e.bridge.cursor_matches():return False
    current,current_origin=e.screen.frame()
    if current_origin!=origin or current.shape!=final.shape or not same_stamp(current,stamp):return False
    sample=self._patch(current,point)
    return sample.shape==patch.shape and abs(sample.astype(float)-patch).mean()<4
   def quiet_context():
    # A successful route can draw blue dots or open the flight question.
    # Do not treat those expected pixel changes as cancellation after receipt.
    if not self.permitted(e) or not e.map_active or not e.bridge.cursor_matches():return False
    current,current_origin=e.screen.frame()
    return current_origin==origin and current.shape==final.shape
   departed=getattr(self.coordinates,'departed',None)
   if callable(departed):departed()
   result=self.transport.click(click_allowed,keepalive=quiet_context)
   if self.run is not run or self.stopping or e.stop_event.is_set():return True
   run.ack=result.acknowledged;self.last_goal=run.goal
   self.emit('MAP_PATH_CLICK: '+run.goal.name+'; пиксель='+str(point)+'; '+('текущая иконка: миникарта → рельеф → большая карта' if isinstance(run.goal.key,tuple) and run.goal.key[0]=='mini' else 'живой ID/XYZ' if run.goal.live else 'справочная/заданная точка')+'; XYZ='+str(run.goal.xyz)+'; прямая XY='+str(round(run.straight,1))+' м; '+result.reason)
   if not result.attempted:self.end(time.monotonic(),True,'Lua не отправила клик')
   else:run.progress=time.monotonic();self.phase('CLOSE',run.progress)
   return True
  if run.phase=='CLOSE':
   if is_map(frame):run.map_open=True;e.map_active=True
   if run.map_open:
    if is_map(frame):
     if now-run.since>4:self.cancel(e,'карта не закрылась');return True
     self._toggle_map(e,lambda:self.permitted(e));self.phase('CLOSE_WAIT',time.monotonic());return True
    run.map_open=False;e.map_active=False
   if run.finishing:self.finish(e,now);return True
   run.check_at=now+5;self.phase('TRAVEL',now);return True
  if run.phase=='CLOSE_WAIT':
   if is_map(frame):
    if now-run.since>2:
     if run.close_retries<1:
      run.close_retries+=1;e.bridge_cmd('MAP');run.since=time.monotonic()
     else:self.cancel(e,'M не закрыло карту; повтор не выдаётся за маршрут')
    return True
   run.map_open=False;e.map_active=False
   if run.finishing:self.finish(e,now)
   else:run.check_at=now+5;self.phase('TRAVEL',now)
   return True
  if run.phase=='TRAVEL':
   reading=read_flight(frame);e._budget_update(reading,now);e.unowned_flight.observe(reading,now)
   if now-run.hud_at<.6:return True
   run.hud_at=now;hud=route_hud(frame)
   if hud.present:
    run.hud_seen=True;run.missing=0;run.missing_since=None
    if hud.metres is not None:
     if (run.switches==0 and not reading.confirmed and not reading.swimming
         and (run.straight>30 and hud.metres>max(80,run.straight*2.2) or self.required and run.straight==0 and self.cfg.get('map_mousekeys_fly_long',True) and hud.metres>=max(30,float(self.cfg.get('map_mousekeys_flight_distance_m',80)))) and e.budget.can_start()
         and e.budget.energy is not None and e.budget.energy>=50):
      self._cancel_motion(e);run.switches=1;run.pending_air=True;run.wing_sent=False
      run.hud_seen=False;run.missing=0;run.best=None;run.progress=now
      self.phase('WINGS',time.monotonic())
      self.emit('MAP_PATH_UPGRADE: игровой путь '+str(hud.metres)+' м; '+('прямое расстояние '+str(round(run.straight))+' м' if run.straight else 'своя позиция неизвестна, длина взята из надписи игры')+'; один переход к той же точке в полёте')
      return True
     if run.best is None or hud.metres<run.best-1:run.best=hud.metres;run.progress=now
     run.near=run.near+1 if hud.metres<=3 else 0
     if run.near>=2:self.end(now,False,'две свежие проверки автопути: осталось не больше 3 м');return True
   elif hud.present is False and run.hud_seen:
    run.missing+=1
    if run.missing_since is None:run.missing_since=now
   if now-run.progress>(12 if run.pending_air else 6) and run.hud_seen and hud.present:
    self.end(now,True,'расстояние автопути не уменьшается');return True
   # A nearby route can finish during the mandatory QUIET/M-open interval.
   # Missing HUD alone cannot distinguish that arrival from a failed click.
   if run.missing>=3 and run.projection_bias is not None:
    self.end(now,False,'подтверждённый автопуть завершён; передаю свежей миникарте без повторного M');return True
   if run.missing>=3 or not run.hud_seen and now-run.since>5:
    run.short_check=not run.hud_seen
    if run.short_check:self.emit('MAP_SHORT_CHECK: надпись автопути не замечена; один раз проверяю фактическую позицию на карте без повторного ПКМ')
    e.map_active=True;run.map_open=True
    run.centered_open=bool(self._toggle_map(e,lambda:self.permitted(e)));self.phase('CHECK_MAP',time.monotonic())
   elif now>=run.check_at:run.check_at=now+5
   return True
  return True
 def _prepare_fix(self,fix,state):
  prepare=getattr(self.coordinates,'prepare',None)
  if callable(prepare):prepare(fix,state)
  run=self.run
  if run is None:return
  if fix.get('projection_bias') is not None:
   bias=fix['projection_bias'];source=fix['world_source']
   if run.projection_bias is None:self.emit('MAP_COORD_ANCHOR: '+source+'; коррекция мировой проекции '+str(round(math.hypot(*bias)/100,1))+' м; исходные XYZ не изменяются')
   run.projection_bias=bias;run.projection_source=source
  elif run.projection_bias is not None:
   self.coordinates.apply_bias(fix,run.projection_bias,run.projection_source)
 def _register_map(self,frame):
  opened=getattr(self.coordinates,'register_open_map',None)
  if self.run is not None and self.run.centered_open and callable(opened):return opened(frame)
  return self.coordinates.register(frame)
 def _world_goal(self,goal):
  from map_reference import transform
  xy=tuple(goal.xyz[:2]) if goal.xyz else transform(goal.reference,self.coordinates.inverse)
  bias=getattr(self.run,'projection_bias',None)
  if goal.xyz is None and isinstance(goal.key,tuple) and goal.key[0]=='mini' and bias is not None:xy=tuple(a+b for a,b in zip(xy,bias))
  return xy
 @staticmethod
 def _patch(frame,point):
  x,y=point;return frame[max(0,y-42):y+43,max(0,x-42):x+43].copy()
