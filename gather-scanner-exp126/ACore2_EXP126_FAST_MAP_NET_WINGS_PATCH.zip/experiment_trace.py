# -*- coding: utf-8 -*-
"""Non-blocking per-event telemetry and per-route metrics for REAL game tests.
Raw controller/game logs remain in gather.log; this module adds exact monotonic
timestamps, isolated sessions and CSVs. Does not issue any game commands.
"""
from __future__ import annotations
import collections,csv,datetime as dt,json,queue,re,statistics,threading,time
from pathlib import Path
from experiment_tuning import TIMING

ROOT=Path(__file__).resolve().parent/'experiment_logs'
TRACE_COLUMNS=('route','start','finish','result','source','goal','goal_xyz','start_to_open_s','open_to_fix_s','fix_to_cursor_s','cursor_to_guard_s','guard_to_dispatch_s','dispatch_to_ack_s','fix_to_wire_s','wire_to_ack_s','start_to_click_s','after_click_to_done_s','route_total_s','arrival_delta_m','arrival_source','notes','revision','map_register_ms','map_sift_features','map_sift_fallback','map_goal_rank_ms','preclick_phase_queue_ms','preclick_frame_ms','preclick_reused','preclick_lease_ms','preclick_cursor_and_settle_ms','preclick_final_capture_ms','preclick_final_verify_ms','preclick_modal_guard_ms','lua_wire_frame_ms','lua_wire_receipt_ms','lua_macro_completion_ms','lua_full_dispatch_ms')
ACTION_COLUMNS=('wall','type','node_id','ordinal','delay_s','note')
_TS=dt.datetime.now

def _float(d,a,b):
 return round(d[b]-d[a],4) if a in d and b in d else None

def _duration(start,finish):return round(finish-start,4) if isinstance(start,(float,int)) and isinstance(finish,(float,int)) else None

class ExperimentRecorder:
 def __init__(self):
  ROOT.mkdir(parents=True,exist_ok=True)
  self.dir=ROOT/_TS().strftime('%Y%m%d_%H%M%S')
  self.dir.mkdir(parents=True,exist_ok=True)
  self.q=queue.Queue(maxsize=120000);self.closed=False;self.dropped=0
  self.snap_lock=threading.Lock();self.route_count=0;self.success=0;self.fail=0;self.empty=0;self.own_results=0;self.own_starts=0;self.tx=0;self.route_times=[];self.click_times=[];self.stage_samples=collections.defaultdict(list)
  self.thread=threading.Thread(target=self._consume,name='experiment-log-writer',daemon=True);self.thread.start()
 def event(self,message,kind='BOT_LOG'):
  if self.closed:return
  datum={'wall':_TS().isoformat(timespec='milliseconds'), 'mono':time.perf_counter(), 'kind':kind,'message':str(message),'revision':TIMING.revision()}
  try:self.q.put_nowait(datum)
  except queue.Full:self.dropped+=1
 def notice(self,what,details):
  self.event(json.dumps({'what':what,'details':details},ensure_ascii=False,default=str),'EXPERIMENT_CONTROL')
 def status(self):
  with self.snap_lock:
   med=(statistics.median(self.click_times) if self.click_times else 0)
   p95=(sorted(self.click_times)[min(len(self.click_times)-1,int(.95*len(self.click_times)))] if self.click_times else 0)
   return {'routes':self.route_count,'success':self.success,'fail':self.fail,'empty':self.empty,
           'starts':self.own_starts,'results':self.own_results,'clicks':self.tx,
           'start_to_click_med_s':round(med,3),'start_to_click_p95_s':round(p95,3),
           'stage_median_ms':{k:round(statistics.median(v),2) for k,v in self.stage_samples.items() if v},
           'missing_events':self.dropped,'folder':str(self.dir)}
 def close(self):
  if self.closed:return
  self.closed=True
  self.q.put(None)
  self.thread.join(timeout=4)
 def _consume(self):
  routes_path=self.dir/'routes.csv';actions_path=self.dir/'actions.csv'
  event_file=(self.dir/'events.jsonl').open('w',encoding='utf-8',buffering=262144)
  routes_file=routes_path.open('w',encoding='utf-8-sig',newline='');actions_file=actions_path.open('w',encoding='utf-8-sig',newline='')
  routes_writer=csv.DictWriter(routes_file,fieldnames=TRACE_COLUMNS);routes_writer.writeheader()
  actions_writer=csv.DictWriter(actions_file,fieldnames=ACTION_COLUMNS);actions_writer.writeheader()
  current=None;index=0;end_by_id={};pending_click=None;arrival_details={};last_summary=time.monotonic()
  def finish(outcome,at,note=''):
   nonlocal current
   if not current:return
   stamps=current['stamps'];stamps['finish']=at
   row={'route':current['id'],'start':current['start_wall'],'finish':_TS().isoformat(timespec='seconds'),
        'result':outcome,'source':current.get('source'),'goal':current.get('goal'),
        'goal_xyz':current.get('xyz'),
        'start_to_open_s':_float(stamps,'start','open'),
        'open_to_fix_s':_float(stamps,'open','fix'),
        'fix_to_cursor_s':_float(stamps,'fix','cursor'),
        'cursor_to_guard_s':_float(stamps,'cursor','guard'),
        'guard_to_dispatch_s':_float(stamps,'guard','dispatch'),
        'dispatch_to_ack_s':_float(stamps,'dispatch','ack'),
        'fix_to_wire_s':_float(stamps,'fix','wire'),
        'wire_to_ack_s':_float(stamps,'wire','ack'),
        'start_to_click_s':_float(stamps,'start','ack'),
        'after_click_to_done_s':_float(stamps,'ack','finish'),
        'route_total_s':_float(stamps,'start','finish'),
        'arrival_delta_m':current.get('arrival_delta_m'),
        'arrival_source':current.get('arrival_source'),
        'notes':note[:240],'revision':current['revision']}
   for stage in ('map_register','map_goal_rank','preclick_phase_queue','preclick_frame','preclick_lease','preclick_cursor_and_settle','preclick_final_capture','preclick_final_verify','preclick_modal_guard','lua_wire_frame','lua_wire_receipt','lua_macro_completion','lua_full_dispatch'):
    value=current.get('stages',{}).get(stage)
    row[stage+'_ms']=value
   row['preclick_reused']=current.get('preclick_reused')
   row['map_sift_features']=current.get('map_sift_features')
   row['map_sift_fallback']=current.get('map_sift_fallback')
   routes_writer.writerow(row);routes_file.flush()
   with self.snap_lock:
    self.route_count+=1
    if outcome=='arrived':self.success+=1
    else:self.fail+=1
    if row['start_to_click_s'] is not None:
     self.click_times.append(row['start_to_click_s'])
    for stage in ('map_register','map_goal_rank','preclick_frame','preclick_lease','preclick_final_capture','preclick_final_verify','lua_wire_frame','lua_macro_completion','lua_full_dispatch'):
     duration=row.get(stage+'_ms')
     if duration is not None:
      samples=self.stage_samples[stage];samples.append(float(duration))
      if len(samples)>500:del samples[:len(samples)-500]
   current=None
  try:
   while True:
    try:item=self.q.get(timeout=.5)
    except queue.Empty:item='TICK'
    if item is None:break
    if item=='TICK':
     if time.monotonic()-last_summary>30:
      self._summary_write();event_file.flush();routes_file.flush();actions_file.flush();last_summary=time.monotonic()
     continue
    event_file.write(json.dumps(item,ensure_ascii=False,default=str)+'\n')
    msg=item['message'];t=item['mono'];wall=item['wall'];kind=item['kind']
    if 'MAP_PATH_START:' in msg:
     if current:finish('interrupted',t,'новый маршрут до подтверждения предыдущего')
     index+=1;current={'id':index,'start_wall':wall,'stamps':{'start':t},'revision':item['revision'],'goal':'','source':'','xyz':''}
    if current:
     if 'EXP_STAGE:' in msg:
      stage_match=re.search(r'EXP_STAGE:\s+(\w+)\s+duration_ms=([0-9.]+)',msg)
      if stage_match:
       stage=stage_match.group(1)
       # Opening-map packets belong to a separate stage, not to RIGHT_STEP.
       if stage not in ('lua_wire_frame','lua_wire_receipt') or 'command=RIGHT_STEP' in msg:
        current.setdefault('stages',{})[stage]=float(stage_match.group(2))
       if stage=='preclick_frame':
        reuse=re.search(r'\breused=(\d+)',msg)
        if reuse:current['preclick_reused']=int(reuse.group(1))
       if stage=='map_register':
        features=re.search(r'\bsift=(\d+)',msg)
        fallback=re.search(r'\bfallback=(\d+)',msg)
        if features:current['map_sift_features']=int(features.group(1))
        if fallback:current['map_sift_fallback']=int(fallback.group(1))
     stamps=current['stamps']
     if 'MAP_WIRE_V2: MAP;' in msg and 'open' not in stamps:stamps['open']=t
     if 'MAP_FIX:' in msg and 'fix' not in stamps:stamps['fix']=t
     if 'EXPERIMENT_CURSOR_SET:' in msg and 'cursor' not in stamps:stamps['cursor']=t
     if 'EXPERIMENT_CURSOR_GUARD_OK:' in msg and 'guard' not in stamps:stamps['guard']=t
     if 'EXPERIMENT_RIGHT_STEP_START:' in msg and 'dispatch' not in stamps:stamps['dispatch']=t
     if 'MAP_WIRE_V2: RIGHT_STEP' in msg and 'wire' not in stamps:stamps['wire']=t
     click_label=next((label for label in ('MAP_PATH_CLICK','MAP_PATH_CLICK_UNCONFIRMED','MAP_PATH_NO_CLICK') if label+':' in msg),None)
     if click_label is not None:
      confirmed=click_label=='MAP_PATH_CLICK'
      if confirmed and 'ack' not in stamps:stamps['ack']=t
      content=msg.split(click_label+':',1)[1]
      current['goal']=content.split(';',1)[0].strip()
      if 'ID present/XYZ' in content:current['source']='present'
      elif 'ID left/XYZ' in content:current['source']='left'
      elif 'мини' in content:current['source']='minimap'
      else:current['source']='catalogue'
      m=re.search(r'XYZ=(\([^)]*\))',content)
      if m:current['xyz']=m.group(1)
      if confirmed:
       with self.snap_lock:self.tx+=1
     if 'EXPERIMENT_ARRIVAL_POSITION:' in msg:
      try:
       data=json.loads(msg.split('EXPERIMENT_ARRIVAL_POSITION:',1)[1].strip())
       current['arrival_delta_m']=data.get('distance_m')
       current['arrival_source']=data.get('source')
      except (json.JSONDecodeError,IndexError):pass
     if 'MAP_PATH_DONE:' in msg:finish('arrived',t,msg.split('MAP_PATH_DONE:',1)[1].strip())
     elif 'MAP_PATH_FAIL:' in msg or 'MAP_PATH_CANCEL:' in msg:finish('failed',t,msg[-240:])
    if 'MAP_LOCAL_EMPTY:' in msg:
     with self.snap_lock:self.empty+=1
    if 'NET_COLLECTION: op=318d' in msg and 'собственный_результат=False' in msg:
     with self.snap_lock:self.own_starts+=1
    if 'NET_COLLECTION: op=3a36' in msg and 'собственный_результат=True' in msg:
     with self.snap_lock:self.own_results+=1
     m=re.search(r'actor=(\d+).*used=(\d+)',msg)
     if m:end_by_id[(m.group(1),int(m.group(2)))]=t
    if 'CLICK_POINT:' in msg and 'stage=repeat' in msg:
     m=re.search(r'ID=(\d+).*used=(\d+)',msg)
     pending_click=(m.group(1),int(m.group(2))) if m else None
    if 'Xbox TX: LB+LT+A' in msg and pending_click:
     end=end_by_id.get(pending_click);diff=_duration(end,t)
     actions_writer.writerow({'wall':wall,'type':'own_end_to_A','node_id':pending_click[0],
       'ordinal':pending_click[1],'delay_s':diff,'note':'same ID and used, includes recognition + cursor + action'})
     pending_click=None
    if kind=='EXPERIMENT_CONTROL':
     actions_writer.writerow({'wall':wall,'type':'parameter_change','node_id':'','ordinal':'','delay_s':'','note':msg[:800]})
  finally:
   if current:finish('logging_stopped',time.perf_counter(),'запись завершена')
   self._summary_write()
   event_file.close();routes_file.close();actions_file.close()
 def _summary_write(self):
  data=self.status();data['timings_last']=TIMING.snapshot();data['warning']='Точность прибытия только по свежим сетевым XYZ, если доступны. Время игрового движения не является задержкой Python.'
  try:(self.dir/'summary.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
  except OSError:pass
