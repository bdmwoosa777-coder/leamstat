"""Calibrated world XY -> map pixels; map arrows are CHARACTER headings."""
from dataclasses import dataclass
from pathlib import Path
import math,json,time
import cv2,numpy as np
from map_reference import TerrainMatcher,ArrowLocator,arrow_mask,transform
from spatial import Atlas,resource_names
from vision import DEFAULT_NAMES
from functools import lru_cache
from experiment_tuning import TIMING
from experiment_resource_index import ResourceXYIndex
from atlas_registration import AtlasRegistration
from minimap_resource_fix import locate as locate_resources
from minimap_position import MinimapPosition
from map_misses import MissCache
from farm_zones import select as select_farm_zone
from map_route_guard import blocked_route, temporary_coordinate_blocked
from map_goal_priority import goal_priority, RECENT_LEFT_SECONDS

ROOT=Path(__file__).resolve().parent

@lru_cache(maxsize=1)
def full_catalogue():
 data=json.loads((ROOT/'assets/atlas/gather_full.json').read_text(encoding='utf-8'))
 if data.get('version')!=1:raise ValueError('Неизвестный формат каталога ресурсов')
 resources={r['id']:r for r in data['resources']};maps={}
 for layer in data['maps']:
  table={}
  for group in layer['groups']:
   if len(group['env_object_ids'])!=1:raise ValueError('Неоднозначный тип спавна')
   template=group['env_object_ids'][0]
   if template not in resources:raise ValueError('Нет описания типа ресурса')
   points=table.setdefault(str(template),[])
   for xyz in group['points']:
    if len(xyz)!=3 or not all(math.isfinite(v) and abs(v)<1e6 for v in xyz):raise ValueError('Некорректная позиция спавна')
    points.append(tuple(xyz))
  maps[layer['map_id']]=table
 return maps

def fit_world(points):
 if len(points)<3:raise ValueError('Нужны три разных ориентира')
 world=np.float64([p['world'][:2] for p in points]);pixels=np.float64([p['pixel'] for p in points])
 if not np.isfinite(world).all() or not np.isfinite(pixels).all():raise ValueError('Некорректные точки')
 if abs(cv2.contourArea(world.astype(np.float32)))<1e6 or abs(cv2.contourArea(pixels.astype(np.float32)))<500:raise ValueError('Выберите три разнесённых ориентира, не на одной линии')
 # North-up similarity: positive isotropic scale and translation only.
 center=world.mean(axis=0);pc=pixels.mean(axis=0);v=world-center;u=pixels-pc
 scale=float(np.sum(v*u)/np.sum(v*v))
 if not 1e-5<scale<.1:raise ValueError('Масштаб/направление карты не совпали; север должен быть сверху')
 offset=pc-scale*center;error=np.linalg.norm(world*scale+offset-pixels,axis=1)
 if error.max()>min(8,scale*100*10):raise ValueError('Ориентиры не совпали с базой или карта слишком мелкая: ошибка '+str(round(float(error.max()),1))+' пикселей')
 return [[scale,0,float(offset[0])],[0,scale,float(offset[1])],[0,0,1]]

@dataclass(frozen=True)
class MapGoal:
 key:object
 name:str
 reference:tuple
 xyz:tuple|None=None
 live:bool=False
 air:bool=False
 presence:str='visible'  # for live network: visible | left; ignored for atlas/mini
 profile_at_ms:int|None=None

class MapCoordinates:
 def __init__(self,cfg):
  self.spec=cfg.get('map_mousekeys',{});self.ready=False;self.atlas=Atlas();self.allowed=set(cfg.get('target_names',DEFAULT_NAMES));self.full=full_catalogue();self.cooldown={};self.location_cooldown={};self.temporary_world_blocks=[]
  self.miss_cache=MissCache(ROOT/'map_resource_misses.json')
  spec=self.spec
  if cfg.get('map_use_builtin',False) or not spec.get('reference'):
   self.builtin(cfg);return
  try:
   path=(ROOT/spec['reference']).resolve()
   if not path.is_relative_to(ROOT):return
   self.image=cv2.imread(str(path));self.matrix=np.array(spec['world_matrix'],np.float64);self.inverse=np.linalg.inv(self.matrix)
   self.zone=np.array(spec['zone'],np.float32);self.layer=spec['layer'];self.meta=self.atlas.maps[self.layer]
   if self.image is None or self.matrix.shape!=(3,3) or not np.isfinite(self.matrix).all() or len(self.zone)<3:return
   self.matcher=TerrainMatcher(self.image);self.roi=spec['roi'];self.frame_width=spec['frame_width']
   arrow=np.array(spec['arrow'],np.uint8)
   if arrow.ndim!=2 or min(arrow.shape)<10 or np.count_nonzero(arrow)<20:return
   self.arrow=ArrowLocator(arrow);self.arrow_size=spec['arrow_size'];self.ready=True
  except (KeyError,TypeError,ValueError,cv2.error,np.linalg.LinAlgError):return
 def builtin(self,cfg):
  self.layer='altgard';self.meta=self.atlas.maps[self.layer]
  self.image=cv2.imread(str(ROOT/'assets/atlas/altgard_reference.jpg'))
  if self.image is None:return
  k=self.meta['scale']*.5
  self.matrix=np.array([[k,0,self.meta['offsetX']*.5],[0,k,self.meta['offsetY']*.5],[0,0,1]],float);self.inverse=np.linalg.inv(self.matrix)
  self.native=AtlasRegistration(self.image);self.automatic=True;self.ready=True;self.zone=None
  self.farm_center=None;self.farm_radius=max(150,min(1000,float(cfg.get('map_farm_radius_m',450))))
  self.farm_radius_enabled=bool(cfg.get('map_farm_radius_enabled',False))
  self.farm_zone=select_farm_zone(cfg.get('map_farm_profile','sanctuary'),abs(float(self.matrix[0,0]))*100)
  self.outside_since=None;self.outside_last_stamp=None;self.outside_return_reported=False
  self.profile_catalogue=None
  self.nearby_fix=None;self.nearby_at=0
  self.spec={'air_points':[],'builtin':True}
  self.calibration=[];self.learned_projection=None;self.texture_enabled=bool(cfg.get('map_minimap_texture_enabled',False))
  self.mini_position=MinimapPosition(self.image);self.mini_goals=[];self.mini_goals_at=-1e9;self.nearby_markers=False
  # Pre-filter all known spawns before the first resource route. No per-click polygon sweep.
  self.profile_catalogue=self.catalogue_sources()
  self.profile_spawn_goals=tuple(MapGoal(('spawn',str(t),*xyz[:2]),name,transform(xyz[:2],self.matrix),xyz)
                                for t,name,xyz in self.profile_catalogue)
  self.profile_spawn_spec=self.catalogue_spec()
 def valid_layer(self,state):return self.ready and (state.map_id in self.meta.get('openZones',[]) or getattr(self,'automatic',False) and state.map_id is None)
 def rebase_after_teleport(self):
  """Forget the old farm circle after a verified zone teleport.

  The new centre is learned from the next TERRAIN-REGISTERED map; the packet
  stream alone is not trusted as a new pixel origin. This is what previously
  excluded ALL catalogue/live nodes after a long-distance teleport inside
  the same Altgard world map.
  """
  if not getattr(self,'automatic',False):return
  self.farm_center=None
  self.outside_since=None;self.outside_last_stamp=None;self.outside_return_reported=False
  self.nearby_fix=None;self.nearby_at=0;self.nearby_markers=False
  self.collection_anchor=None;self.blocked_collection=None
  self.calibration=[];self.learned_projection=None
  self.mini_position.reset();self.mini_goals=[];self.mini_goals_at=-1e9
  self.cooldown.clear();self.location_cooldown.clear()
  if hasattr(self,'prepared_catalogue'):self.prepared_catalogue=None
 def inside(self,point,name=''):
  profile=getattr(self,'farm_zone',None)
  if profile is not None and not profile.permits(tuple(point),name):return False
  if getattr(self,'automatic',False):
   if not getattr(self,'farm_radius_enabled',True):return True
   return self.farm_center is not None and math.dist(point,self.farm_center)<=self.farm_radius*100*abs(float(self.matrix[0,0]))
  return cv2.pointPolygonTest(self.zone,tuple(map(float,point)),False)>=0
 def inside_network(self,point,name,presence):
  # Only current, positively-present IDs may use the inner 5..28 m edge band.
  # Never relax the fixed polygon or extend the permitted area outside it.
  if self.inside(point,name):return True
  profile=getattr(self,'farm_zone',None)
  if not (profile and presence=='visible' and 'эфир' in name.casefold()
          and profile.permits_live(tuple(point),name)):return False
  if getattr(self,'automatic',False) and getattr(self,'farm_radius_enabled',False):
   center=getattr(self,'farm_center',None)
   if center is None or math.dist(point,center)>self.farm_radius*100*abs(float(self.matrix[0,0])):return False
  return True
 def observe_zone_position(self,state,now):
  # A cheap, network-only, nonblocking 2-minute outside monitor.
  profile=getattr(self,'farm_zone',None)
  if profile is None:return None
  xyz=getattr(state,'xyz',None);stamp=getattr(state,'position_at',None)
  if xyz is None or stamp is None or getattr(state,'own',None) is None:return None
  if not -.1<=time.time()-stamp/1000<=3:return None
  if stamp==getattr(self,'outside_last_stamp',None):return None
  self.outside_last_stamp=stamp
  if profile.inside_character(transform(xyz[:2],self.matrix)):
   if self.outside_since is not None:self.outside_since=None;self.outside_return_reported=False;return 'inside'
   return None
  if self.outside_since is None:self.outside_since=now
  if now-self.outside_since>=120 and not self.outside_return_reported:
   self.outside_return_reported=True;return 'outside_due'
  return 'outside'
 def register_open_map(self,frame):return self.register(frame,centered=True)
 def register_open_map_fast(self,frame):return self.register(frame,centered=True,fast_initial=True)
 def register(self,frame,centered=False,fast_initial=False):
  if getattr(self,'automatic',False):
   fix=(self.native.register(frame,centered=True,fast_initial=True) if fast_initial
        else self.native.register(frame,centered=True) if centered else self.native.register(frame))
   if fix is None:return None
   if fix.get('position') is not None:self.mini_position.anchor(fix['position'])
   fix['world']=transform(fix['position'],self.inverse) if fix.get('position') is not None else None
   if self.farm_center is None and fix.get('position') is not None:self.farm_center=fix['position']
   return fix
  h,w=frame.shape[:2];x0,y0,x1,y1=[round(v*s) for v,s in zip(self.roi,(w,h,w,h))]
  crop=frame[y0:y1,x0:x1]
  if crop.size==0:return None
  reg=self.matcher.register(crop)
  if reg is None:return None
  # A game map pans/zooms; a rotated or heavily projective match is wrong.
  m=reg.matrix/mat_scale(reg.matrix)
  if abs(m[0,1])+abs(m[1,0])>max(abs(m[0,0]),abs(m[1,1]))*.12 or abs(m[2,0])+abs(m[2,1])>1e-4:return None
  m=np.array([[1,0,x0],[0,1,y0],[0,0,1]],float)@reg.matrix
  found=self.arrow.locate(crop,self.arrow_size*w/self.frame_width,threshold=.65)
  if found is None:return None
  _,px,py,rotation=found
  position=transform((px+x0,py+y0),np.linalg.inv(m))
  return dict(matrix=m,position=position,world=transform(position,self.inverse),viewport=(x0,y0,x1,y1),arrow_rotation=rotation,inliers=reg.inliers)
 def prepare(self,fix,state):
  if not getattr(self,'automatic',False):return fix
  if fix.get('position') is None and state.own is not None and getattr(state,'xyz',None) is not None and getattr(state,'position_at',None) is not None:
   age=(time.time()*1000-state.position_at)/1000
   xyz=state.xyz
   if -.1<=age<=.8 and all(math.isfinite(v) and abs(v)<1e6 for v in xyz):
    fix['world']=tuple(xyz[:2]);fix['position']=transform(xyz[:2],self.matrix);fix['position_source']='fresh_own_network'
  raw=fix.get('map_world',fix.get('world'))
  independent=None;independent_source=None
  xyz=getattr(state,'xyz',None);stamp=getattr(state,'position_at',None)
  if (getattr(state,'own',None) is not None and xyz is not None and stamp is not None
      and -.1<=time.time()-stamp/1000<=.8 and all(math.isfinite(v) and abs(v)<1e6 for v in xyz)):
   independent=tuple(xyz[:2]);independent_source='fresh_own_network'
  nearby=getattr(self,'nearby_fix',None)
  if independent is None and nearby is not None and 0<=time.monotonic()-self.nearby_at<=4:
   independent=nearby.xy;independent_source='minimap_resource_match'
  if independent is None:
   remembered=self.collection_reference(state)
   if remembered is not None:
    cached=self.projection_at(raw) if raw is not None else None
    if remembered[1]!='own_gather_near_resource' or cached is None or not cached[1].startswith('learned_own'):
     independent,independent_source,_=remembered
  if independent is not None and raw is not None and fix.get('position_source') in ('map_open_center','player_arrow'):
   self.learn_projection(raw,independent,independent_source)
   self.apply_bias(fix,tuple(a-b for a,b in zip(independent,raw)),independent_source)
  elif raw is not None:
   learned=self.projection_at(raw)
   if learned is not None:
    model,source=learned;a,bx,by=model
    corrected=(raw[0]*a+bx,raw[1]*a+by)
    self.apply_bias(fix,tuple(x-y for x,y in zip(corrected,raw)),source);fix['projection_model']=model
  if fix.get('position') is not None:
   anchor=transform(fix['world'],self.matrix) if fix.get('projection_bias') is not None else fix['position']
   source=fix.get('world_source',fix.get('position_source','player_arrow'))
  else:
   nearby=getattr(self,'nearby_fix',None)
   if nearby is not None and 0<=time.monotonic()-self.nearby_at<12:
    anchor=transform(nearby.xy,self.matrix);source='minimap_resource_match'
    fix['nearby_matches']=nearby.matches;fix['nearby_error']=nearby.error
   else:
    remembered=self.collection_reference(state)
    if remembered is None:anchor=None;source='unknown'
    else:
     xy,source,stamp=remembered;anchor=transform(xy,self.matrix)
     fix['reference_at']=stamp
  fix['search_position']=anchor;fix['search_source']=source
  if self.farm_center is None and anchor is not None:self.farm_center=anchor
  return fix
 def learn_projection(self,raw,xy,source):
  now=time.monotonic();approx=source not in ('fresh_own_network','stationary_own_network_reference')
  if not all(math.isfinite(v) for v in (*raw,*xy)):return
  # M centre and independent own position refer to the same capture. A
  # gathered node is explicitly only a nearby reference, not exact own XYZ.
  previous=getattr(self,'learned_projection',None)
  if previous is not None and now-previous[3]<600 and math.dist(raw,previous[2])<20000:
   a,bx,by=previous[0];predicted=(a*raw[0]+bx,a*raw[1]+by)
   if approx and math.dist(predicted,xy)>1500:return
  points=[p for p in getattr(self,'calibration',[]) if now-p[2]<600]
  points.append((tuple(raw),tuple(xy),now,approx));self.calibration=points[-12:]
  model=(1.,xy[0]-raw[0],xy[1]-raw[1]);label=('learned_gather_near_resource' if source=='own_gather_near_resource' else 'learned_resource_geometry') if approx else 'learned_own_network'
  exact=[p for p in self.calibration if not p[3]]
  if len(exact)>=3:
   x=np.float64([p[0] for p in exact]);y=np.float64([p[1] for p in exact]);u=x-x.mean(0);v=y-y.mean(0)
   denominator=float(np.sum(u*u))
   if denominator>4000**2:
    a=float(np.sum(u*v)/denominator);b=y.mean(0)-a*x.mean(0)
    error=np.linalg.norm(a*x+b-y,axis=1)
    if .85<a<1.15 and max(error)<400:model=(a,float(b[0]),float(b[1]));label='learned_own_network_scale'
  # Never replace an exact local calibration with a coarser gathered-node fix.
  if approx and previous is not None and previous[1].startswith('learned_own') and now-previous[3]<600 and math.dist(raw,previous[2])<20000:return
  self.learned_projection=(model,label,tuple(raw),now)
 def projection_at(self,raw):
  item=getattr(self,'learned_projection',None)
  if item is None or not 0<=time.monotonic()-item[3]<600 or math.dist(raw,item[2])>20000:return None
  return item[:2]
 def apply_bias(self,fix,bias,source):
  if fix.get('world') is None:return fix
  raw=fix.get('map_world',fix['world']);fix['map_world']=raw;fix.pop('projection_model',None)
  fix['projection_bias']=tuple(bias);fix['world']=tuple(a+b for a,b in zip(raw,bias));fix['world_source']=source
  fix['search_position']=transform(fix['world'],self.matrix);fix['search_source']=source
  return fix
 def observe_minimap(self,frame,radar,state,now):
  if not getattr(self,'automatic',False) or not self.valid_layer(state):return None
  if self.mini_position.seed is None and getattr(state,'xyz',None) is not None and getattr(state,'position_at',None) is not None:
   if 0<=time.time()-state.position_at/1000<.8:self.mini_position.anchor(transform(state.xyz[:2],self.matrix))
  pose=self.mini_position.observe(frame,radar,now)
  if pose is None:self.mini_goals=[];return None
  goals=[];active=getattr(self,'active_names',self.allowed)
  for m in radar.markers:
   if m.kind not in ('aether','gem') or m.distance>110*max(.5,(radar.bounds[2]-radar.bounds[0])/313):continue
   name='Эфир' if m.kind=='aether' else m.name
   if m.kind=='aether' and 'Эфир' not in active or m.kind=='gem' and not any('эфир' not in n.lower() for n in active):continue
   reference=tuple(v+(p-c)/pose.scale for v,p,c in zip(pose.reference,(m.x,m.y),radar.center))
   if not self.inside(reference):continue
   key=('mini',m.kind,*(round(v*2)/2 for v in reference))
   goals.append(MapGoal(key,name,reference))
  self.mini_goals=sorted(goals,key=lambda g:math.dist(g.reference,pose.reference));self.mini_goals_at=now
  return pose
 def followup_goal(self,goal,now):
  pose=self.mini_position.latest if getattr(self,'automatic',False) else None
  if pose is None or not 0<=now-pose.at<=1.5 or not 0<=now-self.mini_goals_at<=1.5:return None
  family='aether' if 'эфир' in goal.name.lower() else 'gem'
  items=[g for g in self.mini_goals if g.key[1]==family and self.cooldown.get(g.key,0)<=now and not self.missed(g,now) and not self.temporarily_blocked(g,now)]
  if not items:return None
  g=items[0]
  # A different atlas point and a still-distant CURRENT marker justify one
  # corrected map route; a claimed catalogue arrival cannot veto it.
  if math.dist(g.reference,pose.reference)*pose.scale<=12:return None
  if math.dist(g.reference,goal.reference)*pose.scale<=6:return None
  return g
 def set_nearby(self,state,radar,now):
  if not getattr(self,'automatic',False):return
  if radar is not None and radar.motion_valid and math.hypot(*radar.displacement)>2:self.departed()
  self.nearby_fix=locate_resources(state,radar,self.allowed);self.nearby_at=now
  self.nearby_markers=bool(radar is not None and any(m.kind in ('aether','gem') for m in radar.markers))
 def departed(self):
  self.collection_anchor=None;self.nearby_fix=None
  self.blocked_collection=getattr(self,'last_collection_token',None)
 def observe_context(self,state,flow):
  context=(flow,state.own,state.map_id)
  previous=getattr(self,'reference_context',context)
  if context!=previous:
   self.departed()
   if getattr(self,'automatic',False) and (previous[0]!=context[0] or previous[2]!=context[2] or previous[1] is not None and context[1] is not None and previous[1]!=context[1]):
    self.mini_position.reset();self.mini_goals=[];self.calibration=[];self.learned_projection=None
  self.reference_context=context
  if getattr(state,'map_id',None) is not None and hasattr(self,'miss_cache'):
   self.miss_cache.context((self.layer,state.map_id,self.matrix.tolist()),time.monotonic(),time.time()*1000)
  cached=getattr(self,'collection_anchor',None)
  if (cached and getattr(state,'position_source','') in ('zone-spawn','own-teleport')
      and (getattr(state,'position_at',None) or 0)>cached[0][4]):self.departed()
 def remember_collection(self,state,node,flow,now):
  # Called only after the engine confirms its OWN gathering lease. A spawn,
  # selection, or another player's interaction must never set this reference.
  token=(flow,state.own,state.map_id,node.actor,node.gather_time)
  if token==getattr(self,'blocked_collection',None):return
  if (state.own is None or node.xyz is None or node.gather_time is None
      or not all(math.isfinite(v) and abs(v)<1e6 for v in node.xyz)):return
  self.last_collection_token=token
  self.collection_anchor=(token,tuple(node.xyz[:2]),now)
 def collection_reference(self,state):
  cached=getattr(self,'collection_anchor',None)
  if cached is None:return None
  token,xy,observed=cached
  if (token[1:3]!=(state.own,state.map_id) or not 0<=time.monotonic()-observed<30):return None
  if (getattr(state,'position_source','') in ('zone-spawn','own-teleport')
      and (getattr(state,'position_at',None) or 0)>token[4]):return None
  # A delayed real fix can refine ranking while this gathering reference has
  # not been invalidated by movement. Retain the real capture timestamp.
  xyz=getattr(state,'xyz',None);stamp=getattr(state,'position_at',None)
  if (xyz is not None and stamp is not None and token[4]<=stamp
      and all(math.isfinite(v) and abs(v)<1e6 for v in xyz)
      and math.dist(xy,xyz[:2])>1500):return None
  if (xyz is not None and stamp is not None and token[4]<=stamp
      and 0<=time.time()*1000-stamp<=30000
      and all(math.isfinite(v) and abs(v)<1e6 for v in xyz)
      and math.dist(xy,xyz[:2])<=1500):
   return tuple(xyz[:2]),'stationary_own_network_reference',stamp
  # This is the resource's location, an approximate nearby area, never own XYZ.
  return xy,'own_gather_near_resource',token[4]
 def pixel(self,goal,fix):
  reference=goal.reference
  if fix.get('projection_bias') is not None and not (isinstance(goal.key,tuple) and goal.key[0]=='mini'):
   model=fix.get('projection_model')
   if model is not None:
    a,bx,by=model;xy=goal.xyz[:2] if goal.xyz is not None else transform(reference,self.inverse)
    reference=transform(((xy[0]-bx)/a,(xy[1]-by)/a),self.matrix)
   else:reference=tuple(v-b*self.matrix[0,0] for v,b in zip(reference,fix['projection_bias']))
  p=transform(reference,fix['matrix']);x0,y0,x1,y1=fix['viewport']
  return tuple(round(v) for v in p) if x0+12<p[0]<x1-12 and y0+12<p[1]<y1-12 else None
 def refine_goal(self,goal,state):
  if goal.xyz is None:return goal
  names=resource_names();nodes=[]
  for n in state.nodes.values():
   if (names.get(n.template)!=goal.name or not n.visible or n.used==3 or n.xyz is None
       or n.removed_reason==4 or n.actor in state.players or n.actor in state.npcs or n.actor in state.deaths):continue
   if not all(math.isfinite(v) and abs(v)<1e6 for v in n.xyz):continue
   if math.dist(n.xyz[:2],goal.xyz[:2])<=1500:nodes.append(n)
  if not nodes:return goal
  n=min(nodes,key=lambda n:math.dist(n.xyz,goal.xyz))
  return MapGoal(('node',state.map_id,n.actor,n.generation),goal.name,transform(n.xyz[:2],self.matrix),tuple(n.xyz),True,goal.air,'visible',n.profile_at)
 def catalogue_spec(self):
  return (getattr(self,'layer',''),tuple(float(v) for v in self.matrix.ravel()),tuple(sorted(getattr(self,'allowed',DEFAULT_NAMES))),getattr(getattr(self,'farm_zone',None),'key','free'),getattr(self,'farm_radius_enabled',True))
 def catalogue_sources(self):
  names=resource_names();table=getattr(self,'full',{}).get(self.meta['table']) or self.atlas.points.get(self.meta['table'],{})
  prepared=getattr(self,'profile_catalogue',None)
  if prepared is not None:return prepared
  zone=getattr(self,'farm_zone',None)
  result=[]
  for t,points in table.items():
   if not str(t).isdigit() or names.get(int(t)) not in getattr(self,'allowed',DEFAULT_NAMES):continue
   name=names[int(t)]
   for xyz in points:
    xyz=tuple(xyz)
    if zone is not None and not zone.permits(transform(xyz[:2],self.matrix),name):continue
    if blocked_route(name,xyz,getattr(zone,'key','free')):continue
    result.append((int(t),name,xyz))
  if getattr(self,'automatic',False):self.profile_catalogue=tuple(result)
  return tuple(result)
 def spawn_goals(self):
  prepared=getattr(self,'prepared_catalogue',None)
  if prepared is not None and getattr(self,'prepared_catalogue_spec',None)==self.catalogue_spec():return prepared
  cached=getattr(self,'profile_spawn_goals',None)
  if cached is not None and getattr(self,'profile_spawn_spec',None)==self.catalogue_spec():return cached
  return tuple(MapGoal(('spawn',str(t),*xyz[:2]),name,transform(xyz[:2],self.matrix),xyz)
               for t,name,xyz in self.catalogue_sources())
 def goals(self,state,fix,now,allow_air=True,prefer_ether=True,camp=False,escape=False):
  if not self.valid_layer(state):return []
  self.prepare(fix,state)
  if fix.get('search_position') is None and fix.get('position') is None:return []
  mini=list(getattr(self,'mini_goals',[])) if 0<=now-getattr(self,'mini_goals_at',-1e9)<=1.5 else []
  spatial=ResourceXYIndex(state.nodes.values()) if TIMING.get('map_goal_spatial_index')>0 else None
  goals=[]
  if camp and not getattr(self,'automatic',False):
   p=self.spec.get('exit')
   if p:goals=[MapGoal(('exit',self.layer),'выход из лагеря',tuple(p))]
  elif escape:
   goals=[MapGoal(('air',i),'точка облёта',tuple(p),air=True) for i,p in enumerate(self.spec.get('air_points',[]))] if allow_air else []
  else:
   names={k:v for k,v in resource_names().items() if v in getattr(self,'allowed',DEFAULT_NAMES) and v in getattr(self,'active_names',getattr(self,'allowed',DEFAULT_NAMES))}
   observed_names={k:v for k,v in resource_names().items() if v in getattr(self,'allowed',DEFAULT_NAMES)}
   for n in state.nodes.values():
    name=observed_names.get(n.template)
    if (not name or n.used is None or n.used>=3 or n.removed_reason==4 or n.xyz is None
        or n.actor in state.players or n.actor in state.npcs or n.actor in state.deaths):continue
    presence=('visible' if n.visible else 'left' if n.removed_reason==1 and n.left_at is not None
              and 0<=time.time()*1000-n.left_at<=RECENT_LEFT_SECONDS*1000 else None)
    if presence is None:continue
    p=transform(n.xyz[:2],self.matrix)
    goal=MapGoal(('node',state.map_id,n.actor,n.generation),name,p,tuple(n.xyz),True,False,
                 presence,getattr(n,'profile_at',None))
    if (self.inside_network(p,name,presence) and not blocked_route(name,n.xyz,getattr(getattr(self,'farm_zone',None),'key','free'))
        and self.cooldown.get(goal.key,0)<=now and (allow_air or 'эфир' not in name.lower())):goals.append(goal)
   now_ms=time.time()*1000
   for goal in self.spawn_goals():
    template=int(goal.key[1]);xyz=goal.xyz
    if goal.name not in names.values() or not allow_air and 'эфир' in goal.name.lower():continue
    # Present server ID supersedes its duplicate atlas entry regardless of
    # profile age. This is NOT a static TTL: 3536 clears visible.
    if (spatial.present_near(template,xyz) if spatial is not None else
        any(n.template==template and n.xyz is not None and n.visible
            and n.used is not None and n.used<3 and n.removed_reason!=4
            and math.dist(n.xyz,xyz)<200 for n in state.nodes.values())):continue
    if self.inside(goal.reference,goal.name) and not blocked_route(goal.name,xyz,getattr(getattr(self,'farm_zone',None),'key','free')):goals.append(goal)
  # A minimap marker is a CURRENT observation only while its 2-frame
  # terrain-to-atlas registration is still recent. Never navigate from an
  # unlocated marker or a marker left from a previous camera/route.
  if not camp and not escape:
   mini=[g for g in mini if self.inside(g.reference,g.name)
         and not blocked_route(g.name,transform(g.reference,self.inverse),getattr(getattr(self,'farm_zone',None),'key','free'))]
   goals=mini+goals
  goals=[g for g in goals if not self.temporarily_blocked(g,now) and not self.missed(g,now)
         and self.cooldown.get(g.key,0)<=now
         and (g.live and g.presence=='visible' or not any(t>now and math.dist(g.reference,p)<max(4,abs(self.matrix[0,0])*300) for p,t in getattr(self,'location_cooldown',{}).items()))
         and self.pixel(g,fix) is not None]
  if not camp and not escape:
   def source(g):
    return 'mini' if isinstance(g.key,tuple) and g.key and g.key[0]=='mini' else 'network' if g.live else 'catalogue'
   now_ms=time.time()*1000
   def packet_age(g):
    if not g.live or not isinstance(g.key,tuple) or len(g.key)<3:return None
    node=state.nodes.get(g.key[2]);stamp=getattr(node,'left_at' if g.presence=='left' else 'profile_at',None)
    return max(0.,(now_ms-stamp)/1000) if stamp else None
   # Corroborate a network XYZ with a separately located fresh minimap pin.
   # Same region/family is NOT enough: compare positions in the atlas frame.
   fresh_mini=[g for g in goals if source(g)=='mini' and now-getattr(self,'mini_goals_at',-1e9)<=1.5]
   k=max(.00001,abs(float(self.matrix[0,0])))
   def near_mini(g):
    family='aether' if 'эфир' in g.name.lower() else 'gem'
    return any(m.key[1]==family and math.dist(g.reference,m.reference)<=9*100*k for m in fresh_mini)
   # Presence is authoritative within the current flow, not packet recency.
   # Zone, map viewport and route safety checks above remain in force.
   # A fresh minimap pin close to an exact network node reinforces that node;
   # suppress the co-located approximate pin so it cannot steal its identity.
   goals=[g for g in goals if source(g)!='mini' or not any(n.live and ('эфир' in n.name.lower())==('эфир' in g.name.lower()) and math.dist(n.reference,g.reference)<=9*100*k for n in goals)]
   counts=(sum(g.live and g.presence=='visible' for g in goals),sum(g.live and g.presence=='left' for g in goals),sum(source(g)=='mini' for g in goals),sum(source(g)=='catalogue' for g in goals))
   known=sum(n.visible and n.used is not None and n.used<3 and n.xyz is not None for n in state.nodes.values())
   self.last_live_filter_report=''
   if known>counts[0]:
    # Once per opened map, show exactly WHY a currently present network ID
    # was not a route candidate. No per-frame capture, OCR or image matching.
    filtered={g.key for g in goals if g.live and g.presence=='visible'}
    rows=[];zone=getattr(self,'farm_zone',None)
    for n in state.nodes.values():
     if not (n.visible and n.used is not None and n.used<3 and n.xyz is not None):continue
     name=resource_names().get(n.template)
     p=transform(n.xyz[:2],self.matrix)
     key=('node',state.map_id,n.actor,n.generation)
     g=MapGoal(key,name or '?',p,tuple(n.xyz),True,False,'visible',getattr(n,'profile_at',None))
     edge=None
     if zone is not None:
      edge=cv2.pointPolygonTest(np.asarray(zone.polygon,np.float32),tuple(float(v) for v in p),True)/max(1.e-8,zone.pixels_per_metre)
     if key in filtered:reason='допущен'
     elif name not in observed_names.values():reason='тип отключён'
     elif n.actor in state.players or n.actor in state.npcs or n.actor in state.deaths:reason='ID не ресурс'
     elif not self.inside_network(p,name,'visible'):reason='контур / 5м граница' if edge is not None else 'контур'
     elif blocked_route(name,n.xyz,getattr(zone,'key','free')):reason='запрет участка'
     elif not allow_air and 'эфир' in name.casefold():reason='эфир запрещён состоянием полёта/энергии'
     elif self.temporarily_blocked(g,now):reason='точечная блокировка XYZ'
     elif self.missed(g,now):reason='память отрицательного осмотра'
     elif self.cooldown.get(g.key,0)>now:reason='пауза для данного ID'
     elif self.pixel(g,fix) is None:reason='вне видимой области большой карты'
     else:reason='другой фильтр'
     rows.append(str(n.actor)+' '+(name or '?')+' '+reason+(('; до контура '+str(round(edge,1))+'м') if edge is not None else ''))
     if len(rows)>=12:break
    self.last_live_filter_report='; '.join(rows)
   self.last_source_report=('присутствующих ID в сети='+str(known)+'; после фильтров: present='+str(counts[0])+', left='+str(counts[1])+', миникарта='+str(counts[2])+', каталог='+str(counts[3])+ '; порядок: присутствующий ID → свежая миникарта → недавно вышедший ID → каталог')
  def score(g):
   anchor=fix.get('search_position') or fix.get('position')
   pose=self.mini_position.latest if getattr(self,'automatic',False) else None
   if pose is not None and now-pose.at<=1.5 and anchor is not None and math.dist(pose.reference,anchor)<=15*100*abs(float(self.matrix[0,0])):
    anchor=pose.reference
   distance=math.dist(g.reference,anchor)/(100*max(.00001,abs(float(self.matrix[0,0]))))
   if camp or escape:
    return (distance,0 if g.air else 1)
   visual=isinstance(g.key,tuple) and bool(g.key) and g.key[0]=='mini'
   age=packet_age(g) if g.live else None
   # Corroboration is INDEPENDENT visual geometry, never another parsing of
   # the same server packet. The only extra work is constant-time set lookup.
   nearby=getattr(self,'nearby_fix',None)
   geometric=bool(nearby is not None and now-getattr(self,'nearby_at',-1e9)<=5
                   and isinstance(g.key,tuple) and len(g.key)>2
                   and g.key[2] in getattr(nearby,'matched_ids',()))
   verified=bool(g.live and (near_mini(g) or geometric))
   # A recently exhausted or implicitly absent old actor is weak negative
   # evidence for its *spawn*, never a reason to delete that spawn from atlas.
   suspect=False
   if not g.live and not visual and g.xyz is not None:
    now_ms=time.time()*1000
    suspect=(spatial.suspected_near(int(g.key[1]),g.xyz,now_ms) if spatial is not None else
             any(n.xyz is not None and n.template==int(g.key[1])
                 and math.dist(n.xyz,g.xyz)<200
                 and ((n.used==3 or n.removed_reason==4) and 0<=now_ms-n.time<=75000
                      or n.suspect_until is not None and now_ms<=n.suspect_until)
                 for n in state.nodes.values()))
   return goal_priority(distance,live=g.live,age_s=age,visual=visual,
                        corroborated=verified,suspected_absent=suspect,
                        name=g.name,prefer_ether=prefer_ether,
                        present=g.presence=='visible',departed=g.presence=='left')
  return sorted(goals,key=score)
 def recovery_goal(self,state,fix,now,allow_air,attempt=0):
  """Find a real movement objective if ordinary goals are empty.

  Prefer another allowed spawn beyond the local farm radius. Only when
  there are no eligible map-visible spawn points, explore 65-100 metres from
  the CURRENT registered map position; in both cases the destination must
  project inside the playable map viewport. Never use the stale old centre.
  """
  if (not getattr(self,'automatic',False) or not self.valid_layer(state)
      or fix.get('search_source')=='unknown'):
   return None
  anchor=fix.get('search_position') or fix.get('position')
  if anchor is None or fix.get('matrix') is None:return None
  k=abs(float(self.matrix[0,0]))
  if not k:return None
  active=set(getattr(self,'active_names',self.allowed))
  candidates=[]
  for g in self.spawn_goals():
   if (g.name not in active or (getattr(self,'farm_zone',None) is not None and not self.farm_zone.permits(g.reference,g.name)) or (not allow_air and 'эфир' in g.name.lower())
       or self.cooldown.get(g.key,0)>now or self.missed(g,now) or self.temporarily_blocked(g,now)
       or self.pixel(g,fix) is None):continue
   distance=math.dist(g.reference,anchor)/(100*k)
   # A distant map pin is not a safe local escape. Do not route across zones.
   limit=400 if getattr(self,'farm_zone',None) is not None and getattr(self,'outside_return_reported',False) else 250
   if 25<=distance<=limit and not any(t>now and math.dist(g.reference,p)<max(4,300*k) for p,t in self.location_cooldown.items()):
    candidates.append((distance,g))
  if candidates:return min(candidates,key=lambda row:row[0])[1]
  # A farm profile deliberately forbids arbitrary exploratory clicks over
  # water, a cliff or another sector. The existing no-yield TP remains fallback.
  if getattr(self,'farm_zone',None) is not None:return None
  # Emergency last resort: a verifiable map point, not blind stick movement.
  # Vary the direction after failed routes; never repeat a single exact click.
  angles=(0,45,-45,90,-90,135,-135,180)
  for offset in range(len(angles)):
   heading=math.radians(angles[(attempt+offset)%len(angles)])
   distance=75+25*((attempt//len(angles))%2)
   span=distance*100*k
   ref=(anchor[0]+span*math.cos(heading),anchor[1]+span*math.sin(heading))
   g=MapGoal(('explore',state.map_id,round(ref[0],1),round(ref[1],1)), 'Разведка области',ref)
   if self.pixel(g,fix) is not None and self.cooldown.get(g.key,0)<=now:
    return g
  return None
 def block_failed_world_point(self,xyz,now=None):
  """30s RAM-only exclusion for ONE failed resource, never persisted.

  The existing persistent empty-spawn MissCache is a separate mechanism.
  """
  if xyz is None or len(xyz)<3:return False
  try:point=tuple(float(v) for v in xyz[:3])
  except (ValueError,TypeError):return False
  if not all(math.isfinite(v) and abs(v)<1e7 for v in point):return False
  now=time.monotonic() if now is None else float(now)
  self.temporary_world_blocks=[(p,t) for p,t in self.temporary_world_blocks if t>now and p!=point][-31:]
  self.temporary_world_blocks.append((point,now+30.0))
  return True
 def temporarily_blocked(self,goal,now):
  if goal is None:return False
  blocks=getattr(self,'temporary_world_blocks',())
  if not blocks:return False
  xyz=goal.xyz if goal.xyz is not None else transform(goal.reference,self.inverse)
  return temporary_coordinate_blocked(xyz,blocks,now,
           profile_at_ms=(goal.profile_at_ms if goal.live and goal.presence=='visible' else None),
           now_wall_ms=time.time()*1000)
 def temporary_snapshot(self,now):
  self.temporary_world_blocks=[(p,t) for p,t in self.temporary_world_blocks if t>now]
  return tuple(self.temporary_world_blocks)
 def missed(self,goal,now):
  if goal is not None and goal.live and goal.presence=='visible':return False
  cache=getattr(self,'miss_cache',None)
  return bool(cache is not None and cache.blocked(goal,now))
 def defer_empty(self,goal,now):
  if goal is None:return 0
  if not hasattr(self,'miss_cache'):self.miss_cache=MissCache()
  # A negative observation must also enter the active coordinate cooldown.
  # MissCache persists misses, but its scope can change when network map IDs
  # flicker.  The routing planner already honours location_cooldown: using it
  # here prevents the exact same empty spawn from being selected on the very
  # next game-map click.  Visual selection in the world is unchanged.
  seconds=self.miss_cache.fail(goal,now,time.time()*1000,self.matrix[0,0])
  self.defer(goal,now,seconds)
  return seconds
 def confirm_present(self,goal):
  cache=getattr(self,'miss_cache',None)
  if cache is not None:cache.success(goal,time.monotonic(),time.time()*1000)
 def defer(self,goal,now,seconds=60):
  if goal:
   self.cooldown[goal.key]=now+seconds
   if not hasattr(self,'location_cooldown'):self.location_cooldown={}
   self.location_cooldown[tuple(goal.reference)]=now+seconds
  self.location_cooldown={p:t for p,t in getattr(self,'location_cooldown',{}).items() if t>now}
  self.cooldown={k:t for k,t in self.cooldown.items() if t>now}

def mat_scale(matrix):
 value=float(matrix[2,2]);return value if abs(value)>1e-9 else 1.
