"""Passive, bounded server signals; these functions never send input."""
import math,struct
from network_state import Cursor,Invalid
from dataclasses import dataclass


def xyz(b):
 p=struct.unpack('<fff',b)
 if not all(math.isfinite(x) for x in p) or any(abs(x)>=1000000 for x in p):raise Invalid('XYZ')
 return p

def destination(body):
 if len(body)!=18 or body[:2]!=b'\0\0':raise Invalid('unknown 0391 variant')
 zone=struct.unpack_from('<I',body,2)[0]
 if not 0<zone<10000000:raise Invalid('zone')
 return dict(zone=zone,xyz=xyz(body[6:18]))

def flight_path(body):
 # Only the exact 82-byte layout seen twice, not a universal path decoder.
 if len(body)!=82 or body[:4]!=b'\0\0\1\0' or body[28:34]!=bytes([4,8,8,8,8,4]):raise Invalid('unknown 4537 variant')
 start=xyz(body[4:16]);goal=xyz(body[16:28]);points=tuple(xyz(body[i:i+12]) for i in (34,46,58,70))
 if points[0]!=goal or points[-1]!=start:raise Invalid('endpoint mismatch')
 return dict(start=start,goal=goal,reverse_points=points)

@dataclass(frozen=True)
class Status:
 target:int
 instance:int
 effect:int
 duration:int
 source:int
 skill:int

def status_apply(op,body):
 if op not in ('2a38','2b38'):raise Invalid('opcode')
 c=Cursor(body);target=c.var();count=c.var() if op=='2a38' else 1
 if not target or count>256:raise Invalid('target/count')
 result=[];bits=0
 def boolean():
  nonlocal bits
  if bits==0:c.u8()
  bits=(bits+1)%8
 for _ in range(count):
  flags=c.u8()
  if flags&~31:raise Invalid('status flags')
  instance=c.var();effect,duration,expiry=struct.unpack('<Iqq',c.take(20))
  source=c.var() if flags&1 else 0;c.u8()
  skill=struct.unpack('<I',c.take(4))[0] if flags&2 else 0
  boolean()
  if flags&4:c.var()
  if flags&8:c.take(4)
  if flags&16:xyz(c.take(12))
  result.append(Status(target,instance,effect,duration,source,skill))
 if op=='2b38':boolean()
 c.end();return result

def status_remove(body):
 c=Cursor(body);target=c.var();count=c.var()
 if not target or count>128:raise Invalid('target/count')
 removed=[]
 for _ in range(count):
  flags=c.u8()
  if flags&~7:raise Invalid('remove flags')
  instance=c.var();reason=c.u8()
  if flags&1:c.var()
  if flags&2:c.take(4)
  if flags&4:c.take(4)
  removed.append((instance,reason))
 c.end();return target,removed
