"""Translation-only first-open map registration from a FULL SIFT seed.

Fast results never seed later fast results. Post-click verification does not
use this path. Zoom, ambiguity, small overlap and expired seeds fall back.
"""
import time
import cv2,numpy as np

class RecenterSeed:
 def __init__(self,image,registration,now):
  self.gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
  self.registration=registration;self.created=now
  h,w=self.gray.shape;self.shape=(h,w)
  ratio=min(1.,720/w)
  self.small=cv2.resize(self.gray,(round(w*ratio),round(h*ratio)),interpolation=cv2.INTER_AREA)
  self.ratio=(self.small.shape[1]/w,self.small.shape[0]/h)
  self.patches=[]
  radius=max(14,round(self.small.shape[1]*.032))
  for fy,fx in ((.18,.18),(.82,.82),(.18,.82),(.82,.18),(.18,.50),(.82,.50),(.50,.18),(.50,.82),(.50,.50)):
   x=round(fx*self.small.shape[1]);y=round(fy*self.small.shape[0])
   box=(x-radius,y-radius,2*radius+1,2*radius+1)
   patch=self.small[box[1]:box[1]+box[3],box[0]:box[0]+box[2]]
   if patch.size and patch.std()>=8:self.patches.append((box,patch.copy()))
 def match(self,image,now):
  if image.shape[:2]!=self.shape or not 0<=now-self.created<=120 or len(self.patches)<6:return None
  began=time.perf_counter();gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
  small=cv2.resize(gray,(self.small.shape[1],self.small.shape[0]),interpolation=cv2.INTER_AREA)
  votes=[];centers=[];scores=[];rx,ry=self.ratio
  for (x,y,w,h),template in self.patches:
   if time.perf_counter()-began>.14:return None
   scores_map=cv2.matchTemplate(small,template,cv2.TM_CCOEFF_NORMED)
   _,score,_,(u,v)=cv2.minMaxLoc(scores_map)
   if score<.90:continue
   scores_map[max(0,v-h//2):v+h//2+1,max(0,u-w//2):u+w//2+1]=-1
   if score-cv2.minMaxLoc(scores_map)[1]<.06:continue
   # Refine at original resolution; a resized match alone is insufficient.
   ox,oy=round(x/rx),round(y/ry);pw,ph=round(w/rx),round(h/ry)
   patch=self.gray[oy:oy+ph,ox:ox+pw]
   if patch.shape!=(ph,pw):continue
   cx,cy=round(u/rx),round(v/ry);pad=6
   x0,y0=max(0,cx-pad),max(0,cy-pad)
   region=gray[y0:min(gray.shape[0],cy+ph+pad),x0:min(gray.shape[1],cx+pw+pad)]
   if region.shape[0]<ph or region.shape[1]<pw:continue
   result=cv2.matchTemplate(region,patch,cv2.TM_CCOEFF_NORMED)
   _,quality,_,(a,b)=cv2.minMaxLoc(result)
   if quality<.94:continue
   votes.append((x0+a-ox,y0+b-oy));centers.append((ox+pw/2,oy+ph/2));scores.append(quality)
   # The same six-point acceptance threshold, without matching extra patches
   # once six already agree and span both axes. Outliers keep the full search.
   if len(votes)>=6:
    v0=np.array(votes,float);p0=np.array(centers,float);mid=np.median(v0,axis=0)
    if (np.max(np.linalg.norm(v0-mid,axis=1))<=.8
        and np.ptp(p0[:,0])>=self.shape[1]*.45 and np.ptp(p0[:,1])>=self.shape[0]*.45):break
  if len(votes)<6:return None
  votes=np.array(votes,float);centers=np.array(centers,float)
  shift=np.median(votes,axis=0);errors=np.linalg.norm(votes-shift,axis=1);good=errors<=1.5
  if good.sum()<6:return None
  points=centers[good];height,width=self.shape
  if np.ptp(points[:,0])<width*.45 or np.ptp(points[:,1])<height*.45:return None
  if np.median(errors[good])>.8:return None
  # An affine scale change can look like a shift in a single small patch.
  # Fit over widely separated inliers and reject measurable zoom/rotation.
  design=np.column_stack((points,np.ones(len(points))))
  linear=np.linalg.lstsq(design,points+votes[good],rcond=None)[0][:2]
  if np.max(np.abs(linear-np.eye(2)))>.0015:return None
  matrix=np.array(self.registration['matrix'],copy=True);matrix[:2,2]+=shift
  return dict(matrix=matrix,inliers=int(good.sum()),
              error_px=float(self.registration.get('error_px',0))+float(np.median(errors[good])),
              p90_error_px=float(self.registration.get('p90_error_px',0))+float(np.quantile(errors[good],.9)),registration_kind='recenter',
              shift=tuple(float(x) for x in shift),seed_age=now-self.created)
