"""Arrival-only decisions. Resource approach/collection owns deployed wings."""
ROUTE_CAMERA_REASONS=frozenset(('после сбора эфира','ресурс закончился во время коррекции камеры'))

def route_camera_reason(reason):return reason in ROUTE_CAMERA_REASONS

def arrival_fold_due(age,name,fresh_drain,protected=False,ether_visible=False,ether_grace=2.0):
 if protected or not fresh_drain or age<0:return False
 if name=='Эфир':return age>=ether_grace and not ether_visible
 return True
