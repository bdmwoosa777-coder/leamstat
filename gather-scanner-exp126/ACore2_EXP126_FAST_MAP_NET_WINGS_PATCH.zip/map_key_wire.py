"""Map Lua wire v2: Caps data / Scroll clock. Num Lock is never transmitted.

Num Lock can be the game's autorun key. Windows Mouse Keys must be enabled
and Num Lock already ON; neither Python nor Lua may change it during a route.
"""
import time
from bridge import GHubBridge
from experiment_tuning import TIMING

COMMANDS={'PING':0,'RIGHT_STEP':1,'MAP':2,'JUMP':3}

def map_codes(name):
 value=COMMANDS[name];hi=value>>1;lo=value&1
 return [0,1,0,hi,lo,hi^lo]

# EXP117: A dedicated short RIGHT_STEP frame, recognizable by its 1 prefix.
# 1-0-1-1: the final 1 is a checksum for command code 01.
# Other commands retain the proven six-bit wire and ACK semantics.
def fast_right_step_codes():
 return [1,0,1,1]

# EXP121: one more standalone 3-bit RIGHT_STEP 1-1-1.
# Its prefix cannot alias legacy 010, fast RIGHT 1011, or fast MAP 1101.
def ultra_right_step_codes():
 return [1,1,1]

# EXP122: another standalone 3-bit MAP 100 (cannot alias 1011/111/1101).
def ultra_map_codes():
 return [1,0,0]

# EXP118: 1-1-0-1 is a separate framed MAP command.
def fast_map_codes():
 return [1,1,0,1]

class MapKeyWire(GHubBridge):
 protocol='map-caps-scroll-v2'
 def send(self,command,authorize=None):
  with self.lock:
   timings=TIMING.snapshot()
   ultra_right=command=='RIGHT_STEP' and bool(timings['wire_ultrafast_right_step'])
   fast_right=command=='RIGHT_STEP' and bool(timings['wire_fast_right_step'])
   ultra_map=command=='MAP' and bool(timings['wire_ultrafast_map'])
   fast_map=command=='MAP' and bool(timings['wire_fast_map'])
   bits=ultra_right_step_codes() if ultra_right else ultra_map_codes() if ultra_map else fast_right_step_codes() if fast_right else fast_map_codes() if fast_map else map_codes(command)
   # ACK is the complement of the final bit of THIS frozen frame.
   self.last_frame_bits=tuple(bits)
   self.last_frame_command=command
   def permitted():
    try:return authorize is None or bool(authorize())
    except Exception:return False
   if not permitted():return False
   if self.dry_run:
    self.sent.append((time.monotonic(),command,bits));return True
   if not self.win.GetKeyState(144)&1:return False
   # Frame length and timing knobs are frozen for the ENTIRE command.
   cancelled=False;last_edge=None
   for index,bit in enumerate(bits):
    # Abort before the last bit by sending an invalid parity. A stalled
    # partial frame times out in Lua; it must not become a different command.
    if index==len(bits)-1 and (not permitted() or last_edge is not None and time.monotonic()-last_edge>.5):
     bit^=1;cancelled=True
    self._toggle(145,False);self._toggle(20,bool(bit));time.sleep(timings["wire_setup_ms"]/1000.0)
    if index==len(bits)-1 and not cancelled and (not permitted() or last_edge is not None and time.monotonic()-last_edge>.7):
     bit^=1;cancelled=True;self._toggle(20,bool(bit))
    self._toggle(145,True);last_edge=time.monotonic();time.sleep(timings["wire_high_ms"]/1000.0)
    self._toggle(145,False);time.sleep(timings["wire_low_ms"]/1000.0)
   self.last_sent_at=time.monotonic()
   if ultra_right:self.log('MAP_ULTRA_RIGHT_WIRE: 3-битный ПКМ, Lua v121; старый 4-битный режим не используется')
   elif fast_right:self.log('MAP_FAST_RIGHT_WIRE: 4-битный ПКМ; 2 импульса сэкономлены, ожидаю прежний Lua ACK')
   if ultra_map:self.log('MAP_ULTRA_OPEN_WIRE: 3-битная M, Lua v122; проверка карты сохранена')
   elif fast_map:self.log('MAP_FAST_OPEN_WIRE: 4-битная M; 2 импульса сэкономлены, проверка карты сохранена')
   self.log('EXP_WIRE_FRAME: '+command+' setup_ms='+str(timings['wire_setup_ms'])+' high_ms='+str(timings['wire_high_ms'])+' low_ms='+str(timings['wire_low_ms']))
   self.log('MAP_WIRE_V2: '+command+('; отменено до исполнения' if cancelled else '; передан кадр; Num Lock не изменялся'))
   return not cancelled
 def restore_locks(self):
  if self.dry_run:return
  with self.lock:
   self._toggle(145,False)
   if self._saved is not None:self._toggle(20,self._saved[20])
   # Keep clock low. Do not restore Num Lock by pressing an in-game hotkey.
