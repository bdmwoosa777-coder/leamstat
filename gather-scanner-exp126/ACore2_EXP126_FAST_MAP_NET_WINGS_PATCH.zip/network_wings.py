"""Passive own wing state from server flight effects and 008D flight points.

No HUD arc, OCR, sleeps, or extra capture calls. A full-energy plateau is
learned after actual positive deltas and stable server values. Do NOT treat
arbitrary silence/unchanged energy as a maximum without observed recovery.
"""
from flight import FlightReading

DECREASE_GRACE_MS=650
FULL_PLATEAU_MS=2500


def effective_maximum(flow, now_ms):
    value=getattr(flow,'flight',None)
    peak=getattr(flow,'flight_recovery_peak',None)
    recovered_at=getattr(flow,'flight_recovery_at',None)
    delta=getattr(flow,'flight_delta',0)
    # The last real movement must be recovery, then stable for 2.5 s.
    if (value is not None and value>0 and peak==value and delta>0
        and recovered_at is not None and 0<=now_ms-recovered_at
        and now_ms-recovered_at>=FULL_PLATEAU_MS):
        previous=getattr(flow,'flight_observed_maximum',None)
        if previous is None or value>previous:
            # The first full plateau and a later +200 OP equipment upgrade
            # are both recorded automatically.
            flow.flight_observed_maximum=value
    explicit=getattr(flow,'flight_maximum',None)
    inferred=getattr(flow,'flight_observed_maximum',None)
    valid=[v for v in (explicit,inferred) if isinstance(v,int) and v>0]
    return max(valid) if valid else None


def from_flow(flow,now_ms):
    value=getattr(flow,'flight',None)
    maximum=effective_maximum(flow,now_ms)
    energy=(min(100.,100.*value/maximum)
            if isinstance(value,int) and maximum and 0<=value else None)
    is_open=fresh_open_evidence(flow,now_ms)
    return FlightReading(energy,is_open,300 if is_open else 0,False)

def explicit_flight_state(flow,now_ms,max_age_ms=180000):
    at=getattr(flow,'flight_effect_at',None)
    if (getattr(flow,'own',None) is None or getattr(flow,'flight_effect_owner',None)!=flow.own
        or at is None or not 0<=now_ms-at<=max_age_ms):return None
    return getattr(flow,'flight_effect_open',None)

def fresh_open_evidence(flow,now_ms):
    if flow is None:return False
    state=explicit_flight_state(flow,now_ms)
    effect_at=getattr(flow,'flight_effect_at',None)
    delta_at=getattr(flow,'flight_delta_at',None)
    # An explicit newer removal supersedes the last negative OP sample.
    if state is False and (delta_at is None or effect_at>=delta_at):return False
    if fresh_own_flight_drain(flow,now_ms):return True
    if state is not True:return False
    # Recovery after the old add can be newer evidence if its remove was lost.
    return not (getattr(flow,'flight_delta',0)>0 and delta_at is not None and delta_at>effect_at)

def folded_from_effect(flow,sent_wall_ms,now_ms,max_age_ms=1500):
    at=getattr(flow,'flight_effect_at',None)
    return bool(sent_wall_ms is not None and explicit_flight_state(flow,now_ms,max_age_ms) is False
                and sent_wall_ms<=at<=now_ms)


def folded_from_fresh_recovery(flow, sent_wall_ms, now_wall_ms, max_age_ms=1000):
    """Own 008D flight points rose AFTER our Y; no HUD / stale plateau inference.

    This is positive evidence of grounded regeneration, not merely a flat
    energy value. A lack of network packets must never satisfy this check.
    """
    if flow is None or getattr(flow, 'own', None) is None or sent_wall_ms is None:
        return False
    delta=getattr(flow,'flight_delta',0)
    changed=getattr(flow,'flight_delta_at',None)
    sampled=getattr(flow,'flight_at',None)
    if delta is None or delta<=0 or changed is None or sampled is None:
        return False
    return bool(sent_wall_ms<=changed<=sampled<=now_wall_ms
                and 0<=now_wall_ms-changed<=max_age_ms
                and 0<=now_wall_ms-sampled<=max_age_ms)


def fresh_own_flight_drain(flow, now_ms, max_age_ms=650):
    """A CURRENT OWN flight-point decrease is direct evidence of deployed wings.

    Does not infer flying from a static value / stale last-change; it only
    validates the already-observed 008D negative delta. No visual HUD required.
    """
    if flow is None or getattr(flow,'own',None) is None:
        return False
    delta=getattr(flow,'flight_delta',None)
    changed=getattr(flow,'flight_delta_at',None)
    sampled=getattr(flow,'flight_at',None)
    return bool(delta is not None and delta<0
                and changed is not None and 0<=now_ms-changed<=max_age_ms
                and (sampled is None or changed<=sampled<=now_ms))
