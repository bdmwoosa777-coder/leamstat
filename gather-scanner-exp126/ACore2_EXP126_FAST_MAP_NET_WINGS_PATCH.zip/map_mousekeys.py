"""Map-only G HUB Mouse Keys transport; Xbox remains the gameplay transport."""
import ctypes,os,time
from dataclasses import dataclass
from map_key_wire import MapKeyWire,map_codes
from experiment_tuning import TIMING
from experiment_map_fast import log_stage

class MouseKeys(ctypes.Structure):
 _fields_=[(n,ctypes.c_uint32) for n in ('cbSize','dwFlags','iMaxSpeed','iTimeToMaxSpeed','iCtrlSpeed','dwReserved1','dwReserved2')]

def mousekeys_enabled():
 if os.name!='nt':return False
 import ctypes.wintypes as wt
 api=ctypes.WinDLL('user32',use_last_error=True)
 api.SystemParametersInfoW.argtypes=[wt.UINT,wt.UINT,ctypes.c_void_p,wt.UINT];api.SystemParametersInfoW.restype=wt.BOOL
 value=MouseKeys();value.cbSize=ctypes.sizeof(value)
 return bool(api.SystemParametersInfoW(0x0036,value.cbSize,ctypes.byref(value),0) and value.dwFlags&1)

@dataclass(frozen=True)
class Dispatch:
 attempted:bool
 acknowledged:bool
 reason:str=''

class MapMouseKeys:
 def __init__(self,emit=lambda _:None,dry_run=False,wire=None,enabled=mousekeys_enabled):
  self.emit=emit;self.wire=wire or MapKeyWire(dry_run,emit);self.enabled=enabled;self.ready=False;self.receiver_ready_at=0.
 def _send(self,name,authorize):
  knobs=TIMING.snapshot()
  with self.wire.lock:
   if self.wire.dry_run:return Dispatch(False,False,'наблюдение: Lua не исполнялась')
   if not self.enabled():return Dispatch(False,False,'включите Windows Mouse Keys')
   if not self.wire.win.GetKeyState(144)&1:
    self.ready=False;return Dispatch(False,False,'включите Num Lock вручную; бот эту клавишу не нажимает')
   # Completion ACK starts a 50 ms Lua key press. Reuse the existing
   # settle budget only if another command arrives before it can finish.
   while time.monotonic()<self.receiver_ready_at:
    if not authorize():return Dispatch(False,False,'свежая проверка запретила ввод до готовности Lua')
    time.sleep(max(0.,min(knobs['wire_ack_poll_ms']/1000.0,self.receiver_ready_at-time.monotonic())))
   if not authorize():return Dispatch(False,False,'свежая проверка запретила ввод')
   _frame_t0=time.perf_counter()
   try:
    sent=self.wire.send_guarded(name,authorize)
    log_stage(self.emit,'lua_wire_frame',_frame_t0,command=name)
   except Exception as exc:
    self.ready=False;self.receiver_ready_at=max(self.receiver_ready_at,time.monotonic()+.9)
    return Dispatch(True,False,'неопределённая передача: '+str(exc))
   if not sent:
    self.ready=False;self.receiver_ready_at=max(self.receiver_ready_at,time.monotonic()+.9)
    return Dispatch(False,False,'передача отменена до разрешённого кадра')
   # MAP 100 ends in 0; legacy/4-bit MAP ends in 1. Lua ACK flips
   # the actual last data bit, never the old opcode's checksum.
   frame_bits=getattr(self.wire,'last_frame_bits',map_codes(name))
   expected=not bool(frame_bits[-1])
   self.emit('MAP_ACK_V123: '+name+'; кадр='+''.join(str(int(bit)) for bit in frame_bits)+'; ожидаемый Caps ACK='+str(int(expected)))
   _ack_t0=time.perf_counter()
   until=time.monotonic()+knobs["wire_ack_timeout_ms"]/1000.0
   while time.monotonic()<until:
    if not authorize():
     if name=='RIGHT_STEP':
      self.wire._toggle(145,True);time.sleep(.25);self.wire._toggle(145,False)
     self.ready=False;return Dispatch(True,False,'разрешение отозвано; возможное действие не повторяется')
    if bool(self.wire.win.GetKeyState(20)&1)==expected:
     if name=='RIGHT_STEP' and not bool(self.wire.win.GetKeyState(144)&1):break
     # ACK key itself is held for 50 ms. Give Lua time to release it and
     # observe the low clock before another frame, whose first bit may
     # require no Caps transition and arrive within 18 ms.
     time.sleep(knobs["wire_ack_settle_ms"]/1000.0)
     log_stage(self.emit,'lua_wire_receipt',_ack_t0,command=name)
     return Dispatch(True,True,'ACK Lua: команда принята; игровой автопуть ещё не подтверждён')
    time.sleep(knobs["wire_ack_poll_ms"]/1000.0)
   self.ready=False;return Dispatch(True,False,'нет ACK Lua v2; Save & Run нового GHUB_MAP_MOUSEKEYS.lua, затем G9; клик не повторяю')
 def recover_open_map(self,authorize):
  """One PING after a visibly completed M, never replay M or RIGHT_STEP.

  The caller must have observed the open map. Allow a partial M frame to
  expire before PING; a different pending command cannot use this recovery.
  """
  with self.wire.lock:
   if self.ready:return Dispatch(False,True,'Lua уже готова')
   if not authorize():return Dispatch(False,False,'восстановление Lua запрещено текущим состоянием')
   if getattr(self.wire,'last_frame_command',None)!='MAP':
    return Dispatch(False,False,'неопределённая предыдущая команда не M; автоматический PING не разрешён')
   try:
    if not self.wire.dry_run:self.wire._toggle(145,False)
   except Exception as exc:
    return Dispatch(False,False,'не удалось освободить линию Lua: '+str(exc))
   until=max(getattr(self.wire,'last_sent_at',time.monotonic())+.9,self.receiver_ready_at)
   while time.monotonic()<until:
    if not authorize():return Dispatch(False,False,'контекст изменился до восстановления Lua')
    time.sleep(max(0.,min(.02,until-time.monotonic())))
   return self.ping(authorize)
 def ping(self,authorize):
  result=self._send('PING',authorize);self.ready=result.acknowledged;return result
 def click(self,authorize,keepalive=None):
  if not self.ready:return Dispatch(False,False,'сначала PING/ACK нового Lua')
  knobs=TIMING.snapshot()
  with self.wire.lock:
   result=self._send('RIGHT_STEP',authorize)
   if not result.attempted:return result
   # Verified on the user's PC: receipt ACK, 2 s quiet, named macro, no
   # further keyboard input until the 3.3-second observation ends.
   guard=keepalive or authorize
   until=time.monotonic()+knobs["wire_quiet_window_ms"]/1000.0
   # RIGHT_STEP receipt ACK changes Caps to expected. New G9 Lua flips it
   # once more after the *experimental 300 ms* quiet and 150 ms settle.
   # The 1.4 s fallback applies only to the supplied experimental Lua.
   receipt_state=not bool(map_codes('RIGHT_STEP')[-1])
   completion=False
   _macro_t0=time.perf_counter()
   self.emit('MAP_QUIET_FAST: до '+str(knobs['wire_quiet_window_ms']/1000.0)+' с; Lua ждёт '+('0.14' if knobs['wire_ultrafast_right_step'] else '0.3')+' с перед ПКМ; ACK подтверждает вызов макроса')
   try:
    while time.monotonic()<until:
     if not guard():
      self._abort_pending();self.ready=False
      return Dispatch(True,False,'отложенный макрос отозван: фокус/окно/курсор/сбор изменились')
     if bool(self.wire.win.GetKeyState(20)&1)!=receipt_state:
      # Guard was checked before acknowledging completion. The old receiver
      # leaves Caps unchanged, so it always uses the conservative fallback.
      self.receiver_ready_at=time.monotonic()+knobs['wire_ack_settle_ms']/1000.0
      completion=True;break
     time.sleep(knobs["wire_ack_poll_ms"]/1000.0)
   except BaseException:
    self._abort_pending();self.ready=False;raise
   log_stage(self.emit,'lua_macro_completion',_macro_t0,confirmed=int(completion))
   reason=result.reason+('; FAST ACK Lua: макрос вызван' if completion else '; FAST 1.4 с ожидания, подтверждение макроса не получено')
   self.emit('MAP_MOUSEKEYS: '+reason)
   # The fast build requires the fast Lua completion ACK. With old Lua,
   # do not close the map as if a macro definitely executed.
   return Dispatch(True,result.acknowledged and completion,reason)
 def _abort_pending(self):
  self.wire._toggle(145,True);time.sleep(.12);self.wire._toggle(145,False)
 def map_toggle(self,authorize):
  if not self.ready:return Dispatch(False,False,'сначала PING/ACK нового Lua')
  return self._send('MAP',authorize)
 def confirm_flight(self,authorize):
  if not self.ready:return Dispatch(False,False,'сначала PING/ACK нового Lua')
  return self._send('JUMP',authorize) # Dedicated Lua opcode 14 is modal F, never jump.
 def close(self):
  self.ready=False;self.wire.restore_locks()
