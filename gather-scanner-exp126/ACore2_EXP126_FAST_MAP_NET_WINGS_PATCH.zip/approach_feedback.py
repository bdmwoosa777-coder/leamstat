"""Bounded evidence from distinct, dated observations; no input or packet guesses."""
from collections import deque
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class Feedback:
 kind:str
 source:str='none'
 samples:int=0
 span:float=0.
 at:float|None=None

class ApproachFeedback:
 def __init__(self,key,started):
  self.key=key;self.started=started;self.channels={}
 def observe(self,source,sample_id,stamp,distance,point=None):
  if not all(isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x) for x in (stamp,distance)):
   return
  if stamp<self.started or not 0<=distance<10000:return
  if point is not None and (len(point)!=3 or not all(math.isfinite(x) for x in point)):return
  channel=self.channels.get(source)
  if channel is not None:
   if sample_id==channel['id'] or stamp<=channel['rows'][-1][0]:return
   if stamp-channel['rows'][-1][0]>1.0:channel=None
  if channel is None:
   channel={'rows':deque(maxlen=64),'id':None,'anchor':(distance,point),'motion':None}
   self.channels[source]=channel
  old_distance,old_point=channel['anchor']
  if abs(distance-old_distance)>=.3 or point is not None and old_point is not None and math.dist(point,old_point)>=.3:
   channel['motion']=stamp;channel['anchor']=(distance,point)
  channel['id']=sample_id;channel['rows'].append((stamp,distance,point))
 def verdict(self,now):
  stable=None
  for source,c in self.channels.items():
   rows=c['rows'];stamp=rows[-1][0]
   if not 0<=now-stamp<=.8:continue
   # Both decreasing and increasing distance protect travel; fresh own XYZ
   # additionally detect tangential movement with a constant target distance.
   if c['motion'] is not None and 0<=now-c['motion']<=1.2:
    return Feedback('MOVING',source,len(rows),stamp-rows[0][0],c['motion'])
   window=[r for r in rows if stamp-r[0]<=2.0]
   if len(window)<3 or window[-1][0]-window[0][0]<1.2:continue
   distances=[r[1] for r in window]
   if max(distances)-min(distances)>=.3:continue
   points=[r[2] for r in window if r[2] is not None]
   if points and any(math.dist(points[0],p)>=.3 for p in points[1:]):continue
   stable=Feedback('STALLED',source,len(window),window[-1][0]-window[0][0])
  return stable or Feedback('UNKNOWN')
