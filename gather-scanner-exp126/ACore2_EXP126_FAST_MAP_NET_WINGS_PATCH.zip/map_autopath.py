"""Game-owned pathfinding selected with G HUB Mouse Keys on the verified map."""
import math,time,json
from experiment_tuning import TIMING,seconds
from experiment_map_fast import preliminary_frame,log_stage
from copy import copy
from map_next_goal import NextGoalPlanner,LivePoint,PlanRequest
from minimap import angle_delta
from spatial import resource_names
from map_reference import transform
from dataclasses import dataclass,replace
from gamepad_input import GamepadInput
from camera_control import PITCH_STRENGTH
from camera_working_view import working_view_ms
from arrival_policy import route_camera_reason
from network_route_receipt import destination_receipt
from auto_route_hud import route_hud
from map_teleport import is_map,menu_stamp,same_stamp
from map_coordinates import MapCoordinates,MapGoal
from map_mousekeys import MapMouseKeys
from edge_recenter import EdgeRecenter
from vision import gathering_panel_pair,local_world_candidates
from map_flight_dialog import flight_dialog,flight_hint,FlightConsent,same as same_flight_dialog
from map_arrival import ArrivalSearch
from map_terminal import FinalApproach
from map_boss import observe as boss_card,same as same_boss
from map_info import observe as info_card,same as same_info
from map_surface import TerrainLease,card_open,kibelisk_tab,icon_at,map_title_matches

@dataclass
class PathRun:
 phase:str
 started:float
 since:float
 reason:str
 flow:object
 owner:object
 goal:object=None
 fix:object=None
 attempted:bool=False
 hud_seen:bool=False
 missing:int=0
 missing_since:float|None=None
 near:int=0
 best:float|None=None
 progress:float=0
 check_at:float=0
 hud_at:float=0
 ack:bool=False
 map_open:bool=False
 finishing:bool=False
 failed:bool=False
 result:str=''
 pending_air:bool=False
 wing_sent:bool=False
 close_retries:int=0
 switches:int=0
 straight:float=0
 dialog_sent:bool=False
 dialog_check_at:float=0.
 dialog:object=None
 centered_open:bool=False
 arrival_xy:tuple|None=None
 short_check:bool=False
 mini_sampled:bool=False
 correction_clicks:int=0
 projection_bias:tuple|None=None
 projection_source:str=''
 ui_reset_at:float|None=None
 click_wall:float|None=None
 click_destination_sequence:int=0
 click_rejection:str=''
 boss:object=None
 boss_sent:bool=False
 info_close_at:float|None=None
 info_before:object=None
 travel_at:float|None=None
 route_wing_attempted:bool=False
 route_wing_sent:bool=False
 route_wing_sending:bool=False
 route_wing_at:float|None=None
 route_motion_failed:bool=False
 map_lease:object=None
 camera_overlap_attempted:bool=False
 short_near_hits:int=0
 experimental_retry_checked:bool=False
 experimental_retry_sent:bool=False
 camera_route_ready_at:float|None=None
 camera_route_phase:str=""
 camera_route_reference:float=0.
 camera_route_tried:bool=False
 camera_route_target_ms:float|None=None
 verified_map_progress_at:float=-1e9
 stamina_hold_active:bool=False
 stamina_last_log_at:float=-1e9
 stamina_samples:int=0
 stamina_hud_rescues:int=0
 stamina_both_reported:bool=False
 deferred_click_check:object=None
 map_link_recovery_tried:bool=False

def verified_map_lease(frame, fix, lease):
 """No title OCR needed if the verified map header/terrain stay unchanged.

 TerrainLease.matches checks both the original map menu stamp and independent
 remote terrain patches. Changed scenes must be re-registered and re-OCRed.
 """
 return bool(fix is not None and lease is not None and lease.matches(frame))

def route_stamina_drain(state,click_wall,now_wall_ms,max_age_ms=1250):
 """Fresh OWN stamina decrease after this route click is positive route evidence.

 Only a positive signal. Recovery/static/no packets never prove the route
 stopped. No movement inference from other players or pre-click samples.
 """
 if state is None or getattr(state,'own',None) is None or click_wall is None:
  return False
 changed=getattr(state,'stamina_delta_at',None)
 sampled=getattr(state,'stamina_at',None)
 delta=getattr(state,'stamina_delta',0)
 return bool(changed is not None and sampled is not None and delta is not None
             and delta<0 and changed>=click_wall and sampled>=changed
             and 0<=now_wall_ms-sampled<=max_age_ms
             and 0<=now_wall_ms-changed<=max_age_ms)

def confirmed_map_travel_progress(previous_world,current_world,goal_world,minimum=8.0):
 """Only credible motion TOWARD the clicked goal keeps a HUD-less route alive.

 World coordinates use 100 units per metre. A changed map pose alone is not
 enough: require independently registered distance toward the SAME goal.
 """
 try:
  if any(x is None for x in (previous_world,current_world,goal_world)):return None
  old=math.dist(previous_world[:2],goal_world[:2])/100.0
  new=math.dist(current_world[:2],goal_world[:2])/100.0
  moved=math.dist(previous_world[:2],current_world[:2])/100.0
  if not all(math.isfinite(x) for x in (old,new,moved)):return None
  if moved>=minimum and old-new>=minimum and new>6.0:return moved,old-new,new
 except (TypeError,ValueError,OverflowError):pass
 return None

class MapAutopath:
 def __init__(self,cfg,emit):
  self.cfg=cfg;self.emit=emit;self.coordinates=MapCoordinates(cfg);self.transport=None
  self.run=None;self.next_at=0;self.ping_after=0;self.stopping=False;self.force_camp=False
  self.escape_next=False;self.last_goal=None;self.last_note=-1e9
  self.explore_index=0;self.edge_recenter=EdgeRecenter()
  if getattr(self.coordinates,'farm_zone',None) is not None:
   z=self.coordinates.farm_zone
   emit('MAP_FARM_PROFILE: '+z.name+'; контроль ресурсов по готовому контуру, Эфир с внутренним отступом '+str(int(z.ether_margin_m))+' м; обычный радиус '+('включён' if self.coordinates.farm_radius_enabled else 'выключен'))
  self.cancelling=False;self.visual_until=0;self.arrival=None;self.initial_search_done=False
  # Optional fast handoff: a nearby *live* node is inspected for one brief
  # yaw pulse after OWN used=3. Never move the camera during collection.
  self.nearby_glance=None;self.arrived_source_goal=None;self.nearby_glance_stats={'offered':0,'hits':0,'misses':0,'skipped':0}
  if cfg.get('map_mousekeys_enabled') and not self.coordinates.ready:
   emit('MAP_SETUP_REQUIRED: карта недоступна; движение стиком заблокировано' if self.required else 'MAP_SETUP_REQUIRED: сначала «Автопуть: настроить карту»; пока используется прежняя навигация')
 @property
 def required(self):return bool(self.cfg.get('map_autopath_required',False))
 @property
 def enabled(self):return bool(self.cfg.get('map_mousekeys_enabled') and self.coordinates.ready)
 @property
 def owns(self):return self.run is not None
 @property
 def searching(self):return getattr(self,'arrival',None) is not None
 @property
 def modal_blocked(self):return bool(getattr(self,'flight_consent',None) and self.flight_consent.blocking)
 def flight_tick(self,e,frame,now):
  consent=getattr(self,'flight_consent',None)
  if consent is None:consent=FlightConsent(self.emit);self.flight_consent=consent
  handled=consent.tick(e,frame,now,self.run,flight_dialog,flight_hint,same_flight_dialog)
  window=consent.window
  if window is not None and window.route is self.run and self.run is not None:
   run=self.run;run.dialog=window.dialog;run.dialog_sent=window.attempts>0
   if window.last_action in ('accept','repeat'):
    run.pending_air=True;run.hud_seen=False;run.best=None;run.progress=now
   self.phase('FLIGHT_WAIT',now)
  closed=consent.finished
  if closed is not None:
   consent.finished=None;consent.resume_resource(e,closed,now)
   if closed.route is self.run and self.run is not None:
    run=self.run
    if closed.last_action in ('accept','repeat'):
     run.finishing=False;run.failed=False;run.result='';run.map_open=is_map(frame);e.map_active=run.map_open
     run.pending_air=True;run.hud_seen=False;run.best=None;run.progress=now
     self.phase('CLOSE' if run.map_open else 'TRAVEL',now)
     self.emit('MAP_FLIGHT_RESUME: окно закрыто; продолжаю ту же цель без нового ПКМ')
    else:self.end(now,True,'вопрос о полёте закрыт Отменой; следующая попытка учитывает повторное препятствие')
  return handled
 def inspect(self,e,now,goal=None,initial=False,position=None):
  refine=getattr(self.coordinates,'refine_goal',None)
  view=e._net_view()
  if goal is not None and view and view['ready'] and callable(refine):goal=refine(goal,view['state'])
  e.policy.commit_ground(goal.name,now+45) if goal is not None and not initial else e.policy.commit_ground(None,0)
  self.arrival=ArrivalSearch(goal,now,initial);self.arrived_source_goal=None;self.visual_until=now+45;self.next_at=now+45
  if goal is not None and not initial:self.arrival.terminal=FinalApproach(goal,position,destination_check=True)
  reader=getattr(getattr(e,'pitch',None),'view_ms',None)
  if (route_camera_reason(getattr(e,'camera_alignment_due',None))
      and callable(reader) and reader(now) is not None
      and getattr(e,'_automatic_camera_enabled',lambda:False)()):
   e.pitch.returning=False;e.pitch.failed=False;e.camera_alignment_due=None
   self.emit('MAP_CAMERA_LOCAL: известный остаток наклона передан осмотру точки, без полной калибровки перед картой')
  e.nav.finish_goal(now);e.change_mode('SEARCH')
  source=('ID present/XYZ' if goal.presence=='visible' else 'ID left/XYZ') if goal is not None and goal.live else 'текущая миникарта' if goal is not None and isinstance(goal.key,tuple) and goal.key[0]=='mini' else 'справочная точка'
  self.emit('MAP_LOCAL_SEARCH: '+('короткая проверка после ошибки пути' if initial else 'прибытие к '+(goal.name if goal else 'точке'))+'; источник осмотра='+source+'; направляю камеру и довожу подход по миникарте до выбора ресурса')
 def local_tick(self,e,now):
  search=getattr(self,'arrival',None)
  if search is None:return False
  if e.target_confirmed or e.resource_hold or e._own_collection() is not None:
   # Remember the map point actually visited, not just the network ID
   # eventually collected. If the user collects a nearby off-atlas resource,
   # only this exact old atlas point is temporarily avoided; other nearby
   # resources (especially fresh network IDs) remain eligible.
   if search.goal is not None and e.target==search.goal.name:
    self.arrived_source_goal=(search.goal,now)
   self.arrival=None;self.visual_until=0;self.next_at=now
   self.emit('MAP_LOCAL_TARGET: ресурс принят старым контроллером; продолжаю полный сбор');return False
  busy=e.camera_in_progress or e.pitch.returning or e.caption_latch is not None or now<search.candidate_until or e.mode not in ('SEARCH','ACQUIRE_WAIT')
  if busy and now-search.created<search.absolute_limit:
   search.pause(now);return True
  # Prevent perpetual waits caused by camera/recognition busy flags, even if
  # they were held while a local search exceeded its wall-clock budget.
  follow=getattr(self.coordinates,'followup_goal',None) if not busy else None
  corrected=follow(search.goal,now) if search.goal is not None and callable(follow) else None
  view=e._net_view() if corrected is not None else None
  if corrected is not None and view and view['ready'] and (getattr(self,'correction_target',None)!=corrected.key or getattr(self,'corrected_until',0)<now):
   self.corrected_until=now+45;self.correction_target=corrected.key
   self.preferred_goal=(view['flow'],view['state'].own,corrected,now+8)
   self.arrival=None;self.next_at=now;self.visual_until=0
   self.emit('MAP_CORRECT_TARGET: текущая иконка ресурса дальше справочной точки; повторно веду автопутём к точке миникарты')
   return False
  empty=bool(search.terminal is not None and getattr(search.terminal,'finished',False) and ('нет текущей отметки' in search.terminal.finished_reason or getattr(search.terminal,'sky',True) is None))
  if not empty and not search.expired(now):return True
  self.arrival=None;self.visual_until=0;self.next_at=now;e.policy.commit_ground(None,0)
  # A completed, empty inspection must release the caption/acquisition lease.
  # v0.12.88 left ACQUIRE_WAIT + a stale candidate alive; the map scheduler
  # only starts in SEARCH, and repeated OCR kept the return timer deferred.
  # Do not touch a real own interaction; that case is handled above.
  if e.mode in ('SEARCH','ACQUIRE_WAIT') and not e.target_confirmed and not e.resource_hold and e._own_collection() is None:
   e.candidate=None
   e.caption_latch=None
   e.caption_after=max(getattr(e,'caption_after',0),now+1.3)
   e.map_sight_after=max(getattr(e,'map_sight_after',0),now+1.3)
   e.change_mode('SEARCH')
  if search.goal:
   skip=getattr(self.coordinates,'defer_empty',None)
   if callable(skip):
    seconds=skip(search.goal,now);self.emit('MAP_EMPTY_SKIP: без выбранного ресурса; временно пропускаю эту точку '+str(seconds)+' с')
   else:self.coordinates.defer(search.goal,now,45)
  gate=getattr(self,'edge_recenter',None)
  if gate is not None:gate.observe_empty(search.goal,now)
  self.emit('MAP_LOCAL_EMPTY: ограниченный осмотр завершён без выбранного ресурса; наблюдений='+str(search.observed)+'; поиск='+str(round(search.elapsed,1))+' с; выбираю следующую близкую цель')
  return False
 def _nearby_glance_offer(self,e,view,record,now):
  """Offer once at confirmed own 3/3, never from a catalogue point.

  Selection reads only already decoded network data. An old ID, unavailable
  node, or distant/elevated resource never creates a camera/search lease.
  """
  self.nearby_glance=None
  if not e.cfg.get('nearby_glance_enabled',True) or not self.required:return
  source=record[3]
  if source is None or source.xyz is None or 'эфир' in source.name.casefold():return
  anchor=source.xyz
  names=resource_names();state=view['state'];wall=int(time.time()*1000)
  candidates=[]
  for other in state.nodes.values():
   if (other.actor==record[1] or not other.visible or other.used is None or other.used>=3
       or other.removed_reason==4 or other.xyz is None or len(other.xyz)!=3
       or other.actor in state.players or other.actor in state.npcs
       or not all(math.isfinite(float(v)) for v in other.xyz)):continue
   label=names.get(other.template) or getattr(e,'claimed_names',{}).get((view['flow'],other.actor))
   if (not label or 'эфир' in label.casefold()
       or label not in e.cfg.get('target_names',()) or not e.policy.allows(label)):continue
   observed=getattr(other,'profile_at',None) or getattr(other,'time',None)
   age=(wall-observed)/1000 if observed else 1e6
   # 'visible' is the server lifecycle state; no arbitrary 35s expiry.
   planar=math.dist(anchor[:2],other.xyz[:2])/100
   # Ground neighbour only: keep the working pitch and do not switch view
   # during or directly after the preceding three gather attempts.
   if not 1.5<=planar<=36 or abs(anchor[2]-other.xyz[2])/100>5:continue
   candidates.append((planar,age,other,label))
  if not candidates:
   self.nearby_glance_stats['skipped']+=1
   # Once per exhausted node; diagnostic only, no OCR or blocking work.
   self.emit('MAP_NEAR_SKIP: нет подтверждённого соседнего наземного ID в радиусе 36 м')
   return
  planar,age,target,label=min(candidates,key=lambda row:(row[0],row[1]))
  self.nearby_glance={'flow':view['flow'],'owner':state.own,'origin':tuple(anchor),
        'actor':target.actor,'generation':target.generation,'xyz':tuple(target.xyz),
        'name':label,'distance_m':planar,'created':now,'phase':'offer',
        'ready_at':now,'eligible_at':None}
  self.nearby_glance_stats['offered']+=1
  self.emit('MAP_NEAR_OFFER: живой '+label+' ID='+str(target.actor)+' ~'+str(round(planar,1))+' м; короткая проверка после 3/3, карта остаётся запасным способом')

 def _nearby_glance_tick(self,e,frame,now):
  """One bounded, optional camera pulse and one fresh OCR check.

  Never loops if missing; immediate fallthrough to ordinary map routing.
  The current resource's 3 attempts have already completed by server proof.
  """
  task=getattr(self,'nearby_glance',None)
  if task is None:return False
  # The map scheduler runs BEFORE GatherEngine observes used=3 in the same
  # frame. Keep the offer until that controller finishes its own transition;
  # never send camera input while mode is still GATHER.
  if e.mode=='GATHER' or e.wing_close_pending is not None:
   # The server posts used=3 BEFORE GatherEngine leaves GATHER. The separate
   # wing-close action may take >1.5 s. Do not steal its input or waste the
   # nearby deadline during the ongoing mandatory transition.
   if now-task['created']<=6:return False
   self.nearby_glance=None;return False
  def stop(reason):
   self.nearby_glance=None
   self.nearby_glance_stats['misses']+=1
   self.emit('MAP_NEAR_MISS: '+reason+'; карта без дополнительного ожидания')
   return False
  # Never steal a server session, active resource, caption or a map lease.
  if (not e.cfg.get('nearby_glance_enabled',True) or e.cfg.get('dry_run',False)
      or not e.cfg.get('allow_click',True) or e.gamepad is None
      or self.run is not None or self.searching or e.stop_event.is_set() or not e._focus_ok()
      or e.mode!='SEARCH' or e.target_confirmed or e.resource_hold or e.collecting_visible
      or e.map_active or e.click_busy or e.caption_latch is not None
      or e.pitch.returning or e.pitch.failed or e.camera_in_progress
      or (e.camera_alignment_due is not None and not route_camera_reason(e.camera_alignment_due))
      or getattr(e,'automatic_recovery',None) is not None
      or getattr(e,'network_defense',None) is not None
      or getattr(e,'return_exit_guard',False) or getattr(e,'terrain_recovery',None) is not None
      or getattr(e,'post_tp_exit',None) is not None
      or (callable(getattr(e,'_urgent_damage_pending',None)) and e._urgent_damage_pending())
      or getattr(e,'death_wait',False) or getattr(e,'alert','')=='CAPTCHA'):
   self.nearby_glance=None;return False
  view=e._net_view()
  if (not view or not view['ready'] or view['flow']!=task['flow']
      or view['state'].own!=task['owner'] or e._own_collection(view) is not None
      or e._live_attempt(view)):return stop('сетевая идентичность/сбор изменились')
  node=view['state'].nodes.get(task['actor'])
  if (node is None or not node.visible or node.used is None or node.used>=3
      or node.generation!=task['generation'] or node.xyz is None
      or math.dist(node.xyz[:2],task['xyz'][:2])/100>2):return stop('ближайший ID уже не подтверждён')
  # A one-shot deadline, not an extra waiting period after every resource.
  # The *active* glance takes at most 1.5 s. The clock starts only after
  # GatherEngine has handed off and the wing-close controller has finished.
  if task['eligible_at'] is None:task['eligible_at']=now
  if now-task['eligible_at']>1.50:return stop('истёк лимит 1,5 с доступного короткого обзора')
  if now<getattr(e,'post_gather_until',0):return True # overlap existing settling
  if task['phase']=='offer':
   radar=e.minimap.observe(frame)
   heading=radar.heading if radar.confidence>=.42 else None
   if heading is None:return stop('конус камеры не подтверждён')
   dx=task['xyz'][0]-task['origin'][0]
   dy=task['xyz'][1]-task['origin'][1]
   bearing=math.degrees(math.atan2(dx,-dy))%360
   error=angle_delta(bearing,heading)
   if abs(error)>65:return stop('угол больше 65°, сразу карта')
   # If the neighbour is already in view, don't turn the camera at all.
   pulse=min(.22,abs(error)/235.7) if abs(error)>12 else 0
   if pulse:
    direction=(1 if error>0 else -1)*e.cfg.get('camera_yaw_sign',1)
    e.gamepad.drive(0,0,direction*.45,0,lifetime=pulse)
   task['phase']='scan';task['ready_at']=now+pulse+(.12 if pulse else 0)
   self.emit('MAP_NEAR_LOOK: '+task['name']+' '+str(round(task['distance_m'],1))+' м; ошибка курса '+str(round(error))+'°; поворот '+str(round(pulse*1000))+' мс')
   return True
  if now<task['ready_at']:return True
  # Synchronous world-caption+emblem check ONCE, not periodic OCR. 150 ms
  # budget. Never issue A directly: normal selection validates fresh imagery.
  candidate=None
  with e.snapshot_lock:snapshot=e.snapshot
  if (snapshot is not None and 0<=now-snapshot[1]<=.7
      and snapshot[1]>=max(e.identity_valid_after,task['created']+.05,task['ready_at'])
      and snapshot[0].candidate is not None
      and snapshot[0].candidate.name==task['name']
      and snapshot[0].candidate.emblem is not None):candidate=snapshot[0].candidate
  if candidate is None:
   options=local_world_candidates(frame,(task['name'],),deadline=time.monotonic()+.15)
   candidate=next((x for x in options if x.name==task['name'] and x.emblem is not None
                   and not e._caption_rejected(x)),None)
  if candidate is None:return stop('нет свежего значка рядом')
  pose,baseline=e.pitch.capture(time.monotonic())
  e._candidate_observed(candidate,time.monotonic(),pose,baseline)
  self.nearby_glance=None
  if e.caption_latch is None:
   self.nearby_glance_stats['misses']+=1
   self.emit('MAP_NEAR_MISS: значок не прошёл стандартную проверку; карта без ожидания')
   return False
  self.nearby_glance_stats['hits']+=1
  self.emit('MAP_NEAR_HIT: найден '+candidate.name+' на расстоянии ~'+str(round(task['distance_m'],1))+' м; передано обычному контроллеру; A вслепую не нажимается')
  return True

 def _route_camera_schedule(self,e,run,now):
  if (run.reason!='resources' or run.camera_route_tried
      or not getattr(e,'_automatic_camera_enabled',lambda:False)()):return
  # Never consume a pending recovery/defense calibration. Only the ordinary
  # post-Ether ground reset is eligible for target-aware route preparation.
  if (getattr(e,'camera_alignment_due',None) is not None and not route_camera_reason(e.camera_alignment_due)):return
  view_reader=getattr(e.pitch,'view_ms',None)
  known=view_reader(now) if callable(view_reader) else None
  if known is not None and run.goal is not None:
   desired=(0. if 'эфир' in run.goal.name.lower() else float(working_view_ms(e.cfg)))
   run.camera_route_target_ms=desired
   run.camera_route_tried=True
   if abs(desired-known)<45:
    # The next destination is already at the correct camera pitch: do not
    # issue a stick pulse, and do not keep an obsolete repair obligation.
    if desired>0 and abs(e.pitch.offset(now))>.012:
     e.pitch.set_working_baseline(now)
    e.pitch.returning=False;e.pitch.failed=False
    e.camera_alignment_due=None
    self.emit('MAP_CAMERA_KEEP: цель '+run.goal.name+'; тот же наклон, без калибровки')
    return
   run.camera_route_ready_at=now+.12
   self.emit('MAP_CAMERA_TARGET: '+run.goal.name+'; готовлю наклон '+str(int(round(known)))+' → '+str(int(desired))+' мс во время автопути')
   return
  # Compatibility fallback only when pose isn't known. Do not guess the
  # number of previous partial up/down impulses.
  if route_camera_reason(e.camera_alignment_due):
   run.camera_route_ready_at=now+.5
   self.emit('MAP_CAMERA_QUEUED: неизвестный наклон; старая калибровка во время маршрута')

 def _route_camera_abort(self,e,run,reason):
  """Release only the right stick; never cancel game autopath or its left-stick lease."""
  if not run.camera_route_phase and run.camera_route_ready_at is None:return
  if run.camera_route_phase and e.gamepad is not None:
   stop=getattr(e.gamepad,'stop_camera',None)
   if callable(stop):stop()
  run.camera_route_phase=''
  run.camera_route_ready_at=None  # even a not-yet-started pulse is cancelled
  # A partial calibration is not a valid working baseline.  Leave the dirty
  # revision for a future route; an arriving resource must not wait for it.
  self.emit('MAP_CAMERA_ABORT: '+reason+'; ресурс/защита/маршрут имеют приоритет')

 def _route_camera_tick(self,e,run,now):
  """Nonblocking camera-only calibration on the live game-owned route.

  Each tick issues only a short right-stick lease, then yields to path HUD
  and sight acquisition.  A mob hit alone does not affect game autopath or
  right-stick calibration; actual acquisition still preempts immediately.
  In particular there are no 3 s
  synchronous sleeps in the path controller.
  """
  if run.camera_route_ready_at is None and not run.camera_route_phase:return
  if (run.phase!='TRAVEL' or e.target_confirmed
      or e.resource_hold or e.collecting_visible or e.caption_latch is not None
      or e._own_collection() is not None or run.finishing or run.pending_air
      or run.route_wing_attempted or e.budget.airborne or self.modal_blocked):
   self._route_camera_abort(e,run,'более приоритетное действие')
   return
  if (e.gamepad is None or not e.pitch_observed or not e._focus_ok()
      or not getattr(e,'_automatic_camera_enabled',lambda:False)()
      or getattr(e.bridge,'alt_is_down',lambda:False)()
      or not getattr(e,'_camera_input_ready',lambda:True)()):
   self._route_camera_abort(e,run,'нет безопасного доступа к камере')
   return
  if not run.camera_route_phase:
   if now<run.camera_route_ready_at:return
   e.pitch.returning=False;e.pitch.failed=False
   if run.camera_route_target_ms is not None:
    run.camera_route_phase='TRACK'
   else:
    if run.camera_route_tried or not route_camera_reason(e.camera_alignment_due):return
    run.camera_route_phase='UP';run.camera_route_reference=e.pitch.offset(now)
    run.camera_route_tried=True
    self.emit('MAP_CAMERA_AFTER_CLOSE: неизвестная позиция; прежний фоновый возврат без остановки автопути')
  phase=run.camera_route_phase
  if phase=='TRACK':
   reading=getattr(e.pitch,'view_ms',None)
   pose=reading(now) if callable(reading) else None
   if pose is None:
    self._route_camera_abort(e,run,'положение камеры перестало быть известным')
    run.camera_route_ready_at=None
    return
   remaining_ms=run.camera_route_target_ms-pose
   if abs(remaining_ms)<=85:
    if hasattr(e.gamepad,'stop_camera'):e.gamepad.stop_camera()
    if run.camera_route_target_ms>0 and abs(e.pitch.offset(now))>.012:
     e.pitch.set_working_baseline(now)
    e.camera_alignment_due=None
    e.camera_aligned_revision=e.camera_search_revision
    run.camera_route_phase='';run.camera_route_ready_at=None
    self.emit('MAP_CAMERA_DONE: рабочий наклон '+str(int(run.camera_route_target_ms))+' мс достигнут без полной калибровки')
    return
   # right-stick only, measured 0.45 strength; no sleeps, map clicks or
   # player movement commands. A fresh caption/own collection preempts us.
   e.gamepad.drive(0,0,0,(-1 if remaining_ms>0 else 1)*PITCH_STRENGTH,
                   lifetime=min(.14,max(.02,abs(remaining_ms)/1000.)))
   return
  delivered=(e.pitch.offset(now)-run.camera_route_reference)/PITCH_STRENGTH
  target=(2.0 if phase=='UP' else -working_view_ms(e.cfg)/1000)
  remaining=target-delivered
  if phase=='UP' and remaining<=.012:
   run.camera_route_phase='DOWN';run.camera_route_reference=e.pitch.offset(now)
   if hasattr(e.gamepad,'stop_camera'):e.gamepad.stop_camera()
   return
  if phase=='DOWN' and remaining>=-.018:
   if hasattr(e.gamepad,'stop_camera'):e.gamepad.stop_camera()
   e.pitch.set_working_baseline(now);e.camera_last_calibrated=now
   if hasattr(e.pitch,'mark_view_ms'):
    e.pitch.mark_view_ms(now,working_view_ms(e.cfg))
   e.camera_alignment_due=None;e.camera_aligned_revision=e.camera_search_revision
   run.camera_route_phase='';run.camera_route_ready_at=None
   self.emit('MAP_CAMERA_DONE: рабочий наклон восстановлен во время маршрута; поиск/сбор не задерживались')
   return
  # Give the game short renewable right-stick leases; this never sends
  # translation or a keyboard event and cannot block the control loop.
  if phase=='UP':direction=1.;remaining=max(0.,remaining)
  else:direction=-1.;remaining=max(0.,-remaining)
  duration=max(.02,min(.14,remaining))
  e.gamepad.drive(0,0,0,direction*PITCH_STRENGTH,lifetime=duration)

 def _transport(self,e):
  if self.transport is None:self.transport=MapMouseKeys(self.emit,e.cfg.get('dry_run',False))
  return self.transport
 def permitted(self,e):
  if self.modal_blocked:return False
  if self.stopping or e.stop_event.is_set() or not e._focus_ok() or e.cfg.get('dry_run'):return False
  if e.target_confirmed or e.resource_hold or e.collecting_visible or e._urgent_damage_pending() and not self.owns and not self.required:return False
  view=e._net_view()
  return bool(view and view['ready'] and (view['state'].own is not None or self.required) and e._own_collection(view) is None and not e._live_attempt(view))
 def phase(self,name,now):
  run=self.run
  if run is not None:
   self.emit('EXPERIMENT_PHASE: '+str(name)+' t_since_start_s='+str(round(now-run.started,4))+' setup_rev='+str(TIMING.revision()))
   run.phase=name;run.since=now
 def cancel(self,e,reason,move=True):
  run=self.run
  if run is None:return
  self._route_camera_abort(e,run,'маршрут отменён')
  self.run=None
  # A real movement is sent ONLY for an explicit cancellation, never as patrol.
  if run.map_open and e._focus_ok():
   frame,_=e.screen.frame()
   if is_map(frame) and self.transport is not None:
    self._toggle_map(e,lambda:e._focus_ok());GamepadInput.wait(.18,e.stop_event,e.screen.focused)
    run.map_open=is_map(e.screen.frame()[0])
  e.map_active=run.map_open;e.change_mode('SEARCH');self.next_at=time.monotonic()+3
  if run.map_open:
   e.map_menu_stamp=None;e.map_exit_failure={'reason':'автопуть: закрытие карты не подтверждено','since':time.monotonic(),'sent':False,'absent':None}
  if move and run.attempted and not run.map_open and e._focus_ok() and e._own_collection() is None:
   self._cancel_motion(e)
  self.coordinates.defer(run.goal,time.monotonic(),30)
  self.emit('MAP_PATH_CANCEL: '+reason)
 def suspend_session(self,e,now):
  """Release the Python route lease when the server session disappears.

  Deliberately does not press M, F, left/right click, or a movement key:
  the game may currently be displaying a disconnect dialog over its map.
  """
  run=self.run
  if run is not None:
   self._route_camera_abort(e,run,'потеря игровой сессии')
  self.run=None;self.arrival=None;self.visual_until=0;self.next_at=now+1
  forget=getattr(getattr(e,'pitch',None),'forget_view',None)
  if callable(forget):forget(now)
  consent=getattr(self,'flight_consent',None)
  if consent is not None:
   consent.window=None;consent.finished=None  # stale flight menu must never resume after new login
  self.clear_next_plan();self.nearby_glance=None;self.edge_recenter.release()
  e.map_active=False;e.change_mode('SEARCH')
  if run is not None:self.emit('MAP_SESSION_SUSPEND: маршрут приостановлен без нажатий по карте; восстановление входа имеет приоритет')

 def stop(self,e):
  self.stopping=True;e.policy.commit_ground(None,0)
  self.clear_next_plan();self.nearby_glance=None;self.edge_recenter.release()
  self.arrival=None
  self.cancel(e,'остановка бота',move=True)
  if self.transport is not None:
   try:self.transport.close()
   except Exception as exc:self.emit('MAP_LUA_CLOSE: '+str(exc))
 def _log_experimental_arrival(self,e,run):
  """Read-only: compare current own network XY to target (100 map-units/m)."""
  if run.goal is None:return
  record={'goal':getattr(run.goal,'name',None),'path_success':not run.failed,
          'reason':run.result,'expected_xy':None,'actual_xy':None,
          'distance_m':None,'age_s':None,'source':'no_fresh_network'}
  try:
   target=tuple(self._world_goal(run.goal))
   record['expected_xy']=[round(float(v),2) for v in target]
   view=e._net_view();state=view['state'] if view and view.get('ready') else None
   xyz=getattr(state,'xyz',None);stamp=getattr(state,'position_at',None)
   age=(time.time()*1000-float(stamp))/1000 if stamp is not None else None
   record['age_s']=round(age,3) if age is not None else None
   record['position_kind']=str(getattr(state,'position_source',None))
   if xyz is not None and age is not None and 0<=age<=2 and (run.click_wall is None or float(stamp)>=run.click_wall):
    actual=tuple(float(v) for v in xyz[:2]);record['actual_xy']=[round(v,2) for v in actual]
    record['distance_m']=round(math.dist(actual,target)/100.0,3)
    record['source']='fresh_network_after_click'
   elif run.arrival_xy is not None:
    # Report fallback for diagnostics, NOT a valid accuracy proof.
    record['arrival_xy_unverified']=list(run.arrival_xy)
  except Exception as exc:record['error']=repr(exc)
  self.emit('EXPERIMENT_ARRIVAL_POSITION: '+json.dumps(record,ensure_ascii=False))

 def finish(self,e,now):
  run=self.run
  if run is not None:
   if run.stamina_samples or run.stamina_hud_rescues:
    self.emit('MAP_STAMINA_ROUTE_SUMMARY: samples='+str(run.stamina_samples)+
              '; hud_missing_held='+str(run.stamina_hud_rescues)+
              '; both='+str(int(run.stamina_both_reported)))
   self._log_experimental_arrival(e,run)
   self._route_camera_abort(e,run,'маршрут завершён')
  self.run=None;e.map_active=False;e.change_mode('SEARCH');self.next_at=now+(3 if run.failed else 12)
  e.no_yield.next_return=max(e.no_yield.next_return,now+20)
  if run.result.startswith('MAP_RECENTER:'):
   # No destination was clicked. Finishing this empty map pass must NOT
   # create a 45-second ArrivalSearch(None) that delays named teleport.
   self.arrival=None;self.visual_until=0;self.next_at=now
   self.emit('MAP_PATH_DONE: '+run.result)
   return
  if self.required:
   self.visual_until=0;self.next_at=now+(2 if run.failed else 0)
  if run.failed and run.attempted and run.hud_seen and e._focus_ok() and e._own_collection() is None:
   self._cancel_motion(e)
  if run.goal and (run.failed or not self.required):
   skip=getattr(self.coordinates,'defer_empty',None)
   if run.failed and run.result.startswith('MAP_INFO_ONLY') and callable(skip):
    seconds=skip(run.goal,now);self.emit('MAP_INFO_SKIP: описательная иконка не запустила путь; точка отложена на '+str(seconds)+' с')
   else:self.coordinates.defer(run.goal,now,120 if run.failed and not run.hud_seen else 45 if run.failed else 20)
  self.emit(('MAP_PATH_FAIL: ' if run.failed else 'MAP_PATH_DONE: ')+run.result)
  if run.route_wing_sent:
   # Do not shorten the 180 s watch set when V was sent; late flight
   # confirmation can appear only after a subsequent camera turn.
   e.route_wing_watch_until=max(getattr(e,'route_wing_watch_until',0),now+90)
  if run.failed:
   self.escape_next=not run.pending_air and bool(self.coordinates.spec.get('air_points'))
   if (self.required and run.reason=='resources' and run.hud_seen and not run.route_motion_failed
       and not (run.goal is not None and isinstance(run.goal.key,tuple) and run.goal.key[0]=='explore')):
    self.inspect(e,now,run.goal,initial=True)
  else:
   consent=getattr(self,'flight_consent',None)
   if consent is not None:consent.reset_retry()
   self.escape_next=False
   # Also handle takeoff confirmed too late for ROUTE_WINGS (3 s window).
   if run.pending_air and run.goal:
    e.resource_flight_owned=True
    arrival_policy=self.required and run.reason=='resources' and run.goal.name in e.cfg.get('target_names',())
    if not arrival_policy:
     e.wing_close_pending=now;e.wing_close_started=now;e.wing_close_retries=0
     e.wing_absent_since=None;e.wing_absent_hits=0
   e.identity_valid_after=now;e.nav.finish_goal(now)
   if self.required:
    if run.goal is not None and isinstance(run.goal.key,tuple) and run.goal.key[0]=='explore':
     self.emit('MAP_EXPLORE_DONE: точка разведки достигнута; сразу ищу свежую сеть/мини-карту и каталог')
     self.arrival=None;self.next_at=now
    else:self.inspect(e,now,run.goal,position=run.arrival_xy)
 def route_wing_allowed(self,e):
  run=self.run
  if (run is None or run.phase!='ROUTE_WINGS' or not run.route_wing_sending or e.map_active
      or run.finishing or not self.permitted(e) or not e.budget.can_probe(18)):return False
  view=e._net_view()
  return bool(view and view['flow']==run.flow and (run.owner is None or view['state'].own==run.owner))
 def open_route_wings(self,e,now):
  run=self.run
  run.route_wing_attempted=True;run.route_wing_at=now;run.progress=now
  self.phase('ROUTE_WINGS',now);run.route_wing_sending=True
  try:sent=e.bridge_cmd('V')
  finally:run.route_wing_sending=False
  run.route_wing_sent=bool(sent)
  if sent:
   # A wing HUD can arrive after the 3-second acknowledgement window.
   # Keep observing until the route has actually ended; never toggle blindly.
   e.route_wing_watch_until=max(getattr(e,'route_wing_watch_until',0),now+180)
  self.emit('MAP_ROUTE_WINGS: 7 с подтверждённого пути; одна V '+('передана' if sent else 'не передана')+'; цель и игровой маршрут сохранены, без стика/M/повторного ПКМ')
  if not sent:
   e.budget.failed_takeoff(now);self.phase('TRAVEL',now)
 def _cancel_motion(self,e):
  self.cancelling=True
  try:
   e.gamepad.drive(-.35,0,0,0,lifetime=.06);GamepadInput.wait(.07,e.stop_event,e.screen.focused);e._neutral()
  finally:self.cancelling=False
 def end(self,now,failed,reason):
  run=self.run
  if run is None:return
  # Right-stick cleanup is applied by tick() before handing off to search.
  run.failed=failed;run.finishing=True;run.result=reason;run.phase='CLOSE';run.since=now
 def _toggle_map(self,e,authorize):
  result=self.transport.map_toggle(authorize)
  if not result.attempted and authorize():
   # This is a verified no-dispatch fallback, never a duplicate uncertain M.
   return e.bridge_cmd('MAP')
  return result.attempted
 def _recover_open_map_link(self,e,now):
  """Recover a lost M receipt on the open map, before computing/clicking.

  Healthy routes do no extra work. Returning True requires a new control
  tick/frame before any coordinate or cursor guard can authorize RIGHT_STEP.
  """
  if getattr(self.transport,'ready',True):return False
  run=self.run
  if run is None or run.phase not in ('MAP','CHECK_MAP'):return False
  def allowed():
   if self.run is not run or run.finishing or not e.map_active or not self.permitted(e):return False
   view=e._net_view()
   return bool(view and view['ready'] and view['flow']==run.flow
               and (run.owner is None or view['state'].own==run.owner))
  if not allowed():return True
  if run.map_link_recovery_tried:
   self.end(now,True,'повторная потеря готовности Lua на открытой карте');return True
  run.map_link_recovery_tried=True
  self.emit('MAP_LINK_RECOVER: карта уже открыта; восстанавливаю только PING, без повторного M/ПКМ')
  recover=getattr(self.transport,'recover_open_map',None)
  result=recover(allowed) if callable(recover) else self.transport.ping(allowed)
  if self.run is not run or self.stopping or e.stop_event.is_set():return True
  if not result.acknowledged:
   self.end(time.monotonic(),True,'Lua не восстановлена на открытой карте: '+result.reason)
  else:
   self.emit('MAP_LINK_RESTORED: ACK PING получен; та же цель, свежая проверка карты перед ПКМ')
   self.phase(run.phase,time.monotonic())
  return True
 @staticmethod
 def _fast_retry_permitted(initial_world,current_world,remaining_metres,point):
  # The first click may have been delayed without displaying the route HUD.
  # Do not retry when localization is unknown, the avatar has moved, or the
  # destination is already close. The caller additionally verifies identity,
  # current map lease and safe input focus.
  if initial_world is None or current_world is None or point is None:return False
  if remaining_metres<=12:return False
  return math.dist(current_world,initial_world)/100<=2.5
 def idle_service(self,e):
  # These flags are cleared by the ordinary engine AFTER this scheduler.
  # Waiting here would starve the very handler that can finish the work.
  for field,label in (('wing_close_pending','подтверждение закрытия крыльев'),
                      ('defense_restore_view','возврат камеры после защиты'),
                      ('camera_alignment_due','рабочий наклон камеры'),
                      ('view_recovery','завершение проверки ресурса')):
   if (getattr(e,field,None) is not None
       and not (field=='camera_alignment_due' and route_camera_reason(getattr(e,'camera_alignment_due',None))
                and self.required and getattr(e,'_automatic_camera_enabled',lambda:False)())):return label
  if (e.pitch.returning and not (self.required and route_camera_reason(getattr(e,'camera_alignment_due',None))
                         and getattr(e,'_automatic_camera_enabled',lambda:False)())):return 'возврат наклона камеры'
  return None
 def _recenter_tick(self,e,frame,now):
  """Use existing named-teleport state machine, not blind coordinates or map pan.

  A denied transport gives up after a short bounded window so normal gathering
  and the existing 180s no-yield recovery can continue unchanged.
  """
  gate=self.edge_recenter
  if not gate.pending:return False
  if (e.stop_event.is_set() or e.death_wait or getattr(e,'alert',None)=='CAPTCHA' or e.automatic_recovery is not None
      or e.daily_camp_state in ('requested','returning') or e._own_collection() is not None
      or e._live_attempt(e._net_view()) or e.target_confirmed or e.resource_hold):
   gate.release();self.emit('MAP_RECENTER_ABORT: появился более приоритетный режим/ресурс');return False
  if now-gate.pending_since>20 or now<e.map_return_after:
   gate.release();self.emit('MAP_RECENTER_DEFER: телепорт недоступен; штатный поиск и аварийный возврат сохранены');return False
  zone=getattr(self.coordinates,'farm_zone',None)
  if (zone is None or e.cfg.get('map_return_destination')!=zone.teleport_name
      or not e.cfg.get('map_safe_return_enabled',True)):
   gate.release();self.emit('MAP_RECENTER_ABORT: назначение телепорта не совпадает с кибелиском выбранной зоны');return False
  if (self.run is not None or is_map(frame) or e.map_active or e.map_teleport is not None
      or e.mode!='SEARCH' or not e._focus_ok() or e.cfg.get('dry_run')):return False
  if e.post_tp_exit is not None or e.wing_close_pending is not None:return False
  flight=e._flight_reading(frame)
  if flight.confirmed or flight.swimming:
   if flight.confirmed:e.bridge_cmd('END_AIR')
   return False
  if e._start_map_teleport(now):
   gate.release();self.emit('MAP_RECENTER_TP: после пустых точек каталога запускаю штатный телепорт к кибелиску '+zone.teleport_name)
   return True
  # A newly appeared visual resource, unsafe UI, or camera setup can veto TP.
  # Never spin forever: pending_since imposes the 20s maximum.
  return False

 def start(self,e,frame,now):
  if (not self.enabled or now<self.next_at or self.idle_service(e) or not self.permitted(e) or e.mode!='SEARCH'
      or e.caption_latch is not None or e.terrain_recovery is not None or e.post_tp_exit is not None
      or e.map_active or e.map_teleport is not None or e.camera_in_progress
      or e.pitch.returning and not route_camera_reason(e.camera_alignment_due)
      or e.wing_close_pending is not None or e.click_busy or e.return_exit_guard):return False
  if self.required and not getattr(e,'map_start_view_prepared',True):return False
  view=e._net_view()
  if not self.coordinates.valid_layer(view['state']):return False
  if hasattr(self.coordinates,'set_nearby'):
   radar=e.minimap.observe(frame) if not is_map(frame) else None
   self.coordinates.set_nearby(view['state'],radar,now)
  if not is_map(frame):e._budget_update(e._flight_reading(frame),now)
  if now<self.ping_after:return False
  tr=self._transport(e)
  if not tr.ready:
   self.ping_after=now+15
   result=tr.ping(lambda:self.permitted(e))
   if not result.acknowledged:
    self.emit('MAP_LUA_WAIT: '+result.reason+'; нужен GHUB_MAP_MOUSEKEYS.lua, профиль G502 и нажатие G9. Старый сбор остаётся доступен')
    return False
   self.ping_after=0
  reason='camp' if self.force_camp or e.hybrid_camp_pending else 'escape' if self.escape_next else 'resources'
  e._neutral();e._release_collection_cursor();e._clear_view_recovery()
  preferred=getattr(self,'preferred_goal',None);self.preferred_goal=None
  goal=preferred[2] if preferred and preferred[0:2]==(view['flow'],view['state'].own) and now<=preferred[3] else None
  if goal is not None and (not self.coordinates.inside(goal.reference,goal.name) or self.coordinates.temporarily_blocked(goal,now)):goal=None
  ticket=getattr(e,'return_resource',None)
  if goal is None and reason=='resources' and ticket is not None:
   ticket.observe(view,now)
   if not ticket.done and not ticket.returning and ticket.ready_at is not None and now<ticket.ready_at:return False
   if (not ticket.done and not ticket.returning and ticket.ready_at is not None and now>=ticket.ready_at and ticket.xyz is not None
       and (ticket.name!='Эфир' or e.budget.can_start() and e.policy.allows('Эфир'))
       and self.coordinates.inside(transform(ticket.xyz[:2],self.coordinates.matrix),ticket.name)
       and not self.coordinates.temporarily_blocked(MapGoal(('ticket',ticket.actor),ticket.name,transform(ticket.xyz[:2],self.coordinates.matrix),tuple(ticket.xyz),True),now)):
    from map_reference import transform
    n=view['state'].nodes.get(ticket.actor)
    if n is not None and n.visible and n.used!=3:
     xyz=n.xyz if n.xyz is not None else ticket.xyz
     goal=MapGoal(('node',view['state'].map_id,n.actor,n.generation),ticket.name,transform(xyz[:2],self.coordinates.matrix),tuple(xyz),n.xyz is not None)
     e.resource_retry_after.pop((view['flow'],n.actor),None) # This one verified return must not inherit its 45 s acquisition cooldown.
     ticket.returning=True;self.emit('MAP_RESOURCE_RETURN: прежде дальнейшей цели возвращаюсь к недособранному ID='+str(n.actor))
  e.policy.commit_ground(None,0)
  self.run=PathRun('OPEN',now,now,reason,view['flow'],view['state'].own,progress=now,goal=goal)
  self.force_camp=False;e.camp_route=None;e.hybrid_camp_pending=False;e.camp_exit_until=0;e.camp_rearm=False
  e.terrain_recovery=None;e.probe=None;e.pending_probe=None;e.patrol_escape=None;e.nav.air_since=None
  e.change_mode('MAP_PATH');self.emit('MAP_PATH_START: '+reason+'; левый стик заблокирован')
  self.emit('EXPERIMENT_ROUTE_SETTINGS: '+json.dumps(TIMING.snapshot(),ensure_ascii=False))
  return True
 def clear_next_plan(self):
  planner=getattr(self,'next_planner',None)
  if planner is not None:planner.close()
  self.next_planner=None;self.next_plan=None;self.planner_context=None;self.planner_origin=None
  if hasattr(self.coordinates,'prepared_catalogue'):self.coordinates.prepared_catalogue=None
 def prefetch(self,e,view,node,now):
  if now<getattr(self,'planner_retry_at',0):return
  try:self._prefetch(e,view,node,now)
  except Exception as exc:
   self.clear_next_plan();self.planner_retry_at=now+5
   self.emit('MAP_NEXT_ERROR: расчёт пропущен без остановки сбора: '+str(exc))
 def _prefetch(self,e,view,node,now):
  c=self.coordinates
  if not self.enabled or not self.required or self.stopping or e.stop_event.is_set() or not getattr(c,'automatic',False) or not c.valid_layer(view['state']):
   self.clear_next_plan();return
  state=view['state'];spec=c.catalogue_spec();context=(view['flow'],state.own,state.map_id,spec)
  if getattr(self,'planner_context',None)!=context:
   previous=getattr(self,'next_planner',None)
   if previous is not None:previous.close()
   self.next_planner=None;self.next_plan=None;self.planner_context=context
   self.planner_origin=None;self.next_plan_at=0;c.prepared_catalogue=None
  owned=e._own_collection(view)
  anchor=node.xyz if node is not None else None
  if anchor is None and node is not None and self.last_goal is not None and self.last_goal.name==e.target:anchor=self.last_goal.xyz
  active=bool(node is not None and state.attempt_active and e.mode=='GATHER' and anchor is not None
              and len(anchor)==3 and all(math.isfinite(v) for v in anchor) and owned is not None
              and (owned.actor,owned.generation,owned.gather_time)==(node.actor,node.generation,node.gather_time))
  if active and getattr(self,'planner_origin',None)!=(node.actor,node.generation):
   self.planner_origin=(node.actor,node.generation);self.next_plan=None;self.next_plan_at=0
  planner=getattr(self,'next_planner',None)
  if planner is not None:
   try:result=planner.poll()
   except Exception as exc:
    planner.close();self.next_planner=None;self.next_plan=None;self.next_plan_at=now+5
    self.emit('MAP_NEXT_ERROR: предварительный расчёт пропущен; сбор продолжается: '+str(exc));return
   if result is not None and result.context==context and result.origin==self.planner_origin and 0<=now-result.created<=30:
    previous=getattr(self,'next_plan',None);self.next_plan=result
    c.prepared_catalogue=result.catalogue;c.prepared_catalogue_spec=spec
    if result.ranked and (previous is None or not previous.ranked or previous.ranked[0].key!=result.ranked[0].key):
     first=result.ranked[0];distance=math.dist(first.xyz[:2],result.anchor)/100
     self.emit('MAP_NEXT_READY: во время своего сбора подготовлено '+str(len(result.ranked))+' целей; '+first.name+' ~'+str(round(distance,1))+' м; '+('ID present' if first.live and first.presence=='visible' else 'ID left' if first.live else 'место из каталога')+'; перед выходом перепроверю')
  if not active or now<getattr(self,'next_plan_at',0):return
  policy=copy(e.policy);policy.update(e.budget)
  names=frozenset(policy.names(e.cfg.get('target_names',('Эфир','Алмаз','Сапфир','Рубин'))))
  from spatial import resource_names
  labels=resource_names()
  live=tuple(LivePoint(n.actor,n.generation,n.template,labels.get(n.template) or e.claimed_names.get((view['flow'],n.actor)) or (e.target if n.actor==node.actor else None),tuple(n.xyz) if n.xyz is not None else None,
                       n.visible,n.used,n.removed_reason,n.actor in state.players or n.actor in state.npcs or n.actor in state.deaths,getattr(n,'time',None),getattr(n,'suspect_until',None),getattr(n,'left_at',None),getattr(n,'profile_at',None))
             for n in state.nodes.values() if n.xyz is None or len(n.xyz)==3 and all(math.isfinite(v) for v in n.xyz))
  if planner is None:
   planner=NextGoalPlanner(c.catalogue_sources(),c.matrix,getattr(c,'farm_zone',None));self.next_planner=planner
  request=PlanRequest(context,self.planner_origin,tuple(anchor[:2]),now,names,policy.priority,
                      e.budget.can_start() and policy.allows('Эфир'),live,tuple(c.cooldown.items()),tuple(c.location_cooldown.items()),
                      c.farm_center,c.farm_radius,tuple(getattr(getattr(c,'miss_cache',None),'records',())),
                      radius_enabled=getattr(c,'farm_radius_enabled',True),
                      observed_names=frozenset(e.cfg.get('target_names',())),created_wall_ms=int(time.time()*1000),
                      temporary_world_blocks=c.temporary_snapshot(now))
  if planner.submit(request):self.next_plan_at=now+1.5
 def completed_location(self,e,view,node,now):
  state=view['state'];context=(view['flow'],state.own,state.map_id)
  record=getattr(self,'own_location',None)
  if record is not None and (record[0]!=context or now-record[4]>90):self.own_location=None;record=None
  if node is not None:
   goal=None
   if node.xyz is not None and e.target:
    from map_reference import transform
    goal=MapGoal(('node',state.map_id,node.actor,node.generation),e.target,transform(node.xyz[:2],self.coordinates.matrix),tuple(node.xyz),True)
   elif self.last_goal is not None and self.last_goal.name==e.target:
    goal=self.last_goal
   if goal is not None:
    present=getattr(self.coordinates,'confirm_present',None)
    if node.xyz is not None and callable(present):present(goal)
    self.own_location=(context,node.actor,node.generation,goal,now);record=self.own_location
  if record is None:return
  result=state.last_own_result;n=state.nodes.get(record[1])
  if (result and result[0]==record[1] and state.last_own_result_used==3 and n is not None
      and n.used==3 and n.generation==record[2]):
   self._nearby_glance_offer(e,view,record,now)
   # The previous game-map destination can have a different identity from the
   # nearby node that was actually selected by the visual controller. Prevent
   # an immediate second click into that SAME old atlas destination, but do
   # not blacklist its coordinate for live IDs or different catalogue nodes.
   arrived=getattr(self,'arrived_source_goal',None)
   if arrived is not None:
    visited,visited_at=arrived
    self.arrived_source_goal=None
    if (0<=now-visited_at<=75 and visited.name==record[3].name
        and isinstance(visited.key,tuple) and visited.key and visited.key[0]=='spawn'):
     self.coordinates.cooldown[visited.key]=max(self.coordinates.cooldown.get(visited.key,0),now+60)
     self.emit('MAP_CATALOGUE_VISITED_HOLD: точка предыдущего прибытия пропущена на 60 с; соседние живые ID не блокируются')
   self.coordinates.defer(record[3],now,75);self.own_location=None
   self.emit('MAP_RESOURCE_DONE: собственный полный сбор; точка исключена из ближайших маршрутов на 75 с')
 def tick(self,e,frame,now):
  if self.flight_tick(e,frame,now):return True
  view=e._net_view()
  if view and view['ready']:
   context=getattr(self.coordinates,'observe_context',None)
   if callable(context):context(view['state'],view['flow'])
   node=e._own_collection(view)
   if self.enabled:self.completed_location(e,view,node,now)
   monitor=getattr(self.coordinates,'observe_zone_position',None)
   if callable(monitor):
    status=monitor(view['state'],now)
    if status=='outside_due':self.emit('MAP_ZONE_RETURN: 120 секунд подтверждённого нахождения вне зоны; следующий маршрут только внутрь профиля, текущий сбор не прерываю')
    elif status=='inside' and getattr(self.coordinates,'farm_zone',None) is not None:self.emit('MAP_ZONE_INSIDE: возвращение в рабочий контур подтверждено')
   remember=getattr(self.coordinates,'remember_collection',None)
   if node is not None and callable(remember):remember(view['state'],node,view['flow'],now)
   self.prefetch(e,view,node,now)
  else:self.clear_next_plan()
  if self.run is None:
   if self.edge_recenter.pending:
    if self._recenter_tick(e,frame,now):return True
    if self.edge_recenter.pending:return False
   if self.required and not getattr(e,'map_start_view_prepared',True):return False
   if self.local_tick(e,now):return False
   if self._nearby_glance_tick(e,frame,now):return True
   service=self.idle_service(e)
   if service is not None:
    if self.required and now-self.last_note>=3:
     self.last_note=now;self.emit('MAP_SERVICE: '+service+'; передаю управление обработчику, затем следующий маршрут')
    return False
   visible=getattr(e,'_visible_resource_before_map',None)
   if (self.required and e.mode=='SEARCH' and now>=self.next_at and callable(visible)
       and not is_map(frame) and self.permitted(e) and visible(frame,now)):return False
   if not self.start(e,frame,now):
    if self.searching:return False
    if self.required and e.mode=='SEARCH' and not e.target_confirmed and not e.resource_hold and e._own_collection() is None and not e._live_attempt(e._net_view()):
     if now<getattr(self,'visual_until',0) or e.caption_latch is not None or e.camera_in_progress or e.pitch.returning:return False
     e._neutral()
     if now-self.last_note>=3:
      self.last_note=now;self.emit('MAP_WAIT: автопуть ожидает готовую карту/сеть/Lua; патруль стиком запрещён')
     return True
    return False
  run=self.run
  view=e._net_view()
  if (not view or not view['ready'] or view['flow']!=run.flow
      or run.owner is not None and view['state'].own!=run.owner):
   self.cancel(e,'потеря подтверждённого соединения');return True
  if run.owner is None and view['state'].own is not None:run.owner=view['state'].own
  if e._own_collection(view) is not None or e._live_attempt(view):
   self._route_camera_abort(e,run,'начался сбор')
   # Collection already owns the game: a cancellation stick would interrupt it.
   self.cancel(e,'начался свой сбор',move=False);return False
  # The game path survives hits. Do not stop to fight each passing mob.
  if e.caption_latch is not None and not run.map_open:
   self._route_camera_abort(e,run,'ресурс виден по пути')
   self.cancel(e,'найден свежий ресурс в мире');return False
  if not e._focus_ok():e._neutral();return True
  if now-run.started>seconds('route_max_duration_s'):
   self.cancel(e,'общий предел 70 с без бесконечного перепланирования');return True
  if run.attempted and run.phase=='CLOSE' and not run.finishing and not run.boss_sent and run.reason=='resources':
   description=info_card(frame)
   if description is not None and (run.info_before is None or not same_info(frame,run.info_before)):
    self.end(now,True,'MAP_INFO_ONLY: открыто описание зоны без автопути; сразу следующая цель');return True
   boss=boss_card(frame)
   if boss is not None:
    run.boss=boss;self.phase('BOSS_ACTION',now)
    self.emit('MAP_BOSS_CARD: клик к ресурсу открыл карточку '+boss.name+'; проверяю обычную кнопку Переместиться')
    return True
  if run.phase=='BOSS_ACTION':
   fresh,origin=e.screen.frame();boss=run.boss
   if boss is None or not is_map(fresh) or not same_boss(fresh,boss) or not self.permitted(e):
    self.end(now,True,'карточка босса изменилась до кнопки перемещения');return True
   stamp=TerrainLease.capture(fresh,boss.point)
   e.bridge.cursor(origin[0]+boss.point[0],origin[1]+boss.point[1])
   if not GamepadInput.wait(.10,e.stop_event,e.screen.focused):return True
   def allowed_boss():
    if not self.permitted(e) or not e.map_active or self.run is not run or not e.bridge.cursor_matches():return False
    current,current_origin=e.screen.frame()
    return current_origin==origin and current.shape==fresh.shape and map_title_matches(current,stamp.header) and same_boss(current,boss)
   run.boss_sent=True
   if not e.gamepad.tap_ui_a(e.stop_event,e.screen.focused,allowed_boss):
    self.end(time.monotonic(),True,'кнопка перемещения босса не передана; повтора нет');return True
   run.hud_seen=False;run.missing=0;run.missing_since=None;run.best=None;run.near=0
   run.click_wall=time.time()*1000;run.progress=time.monotonic();self.phase('CLOSE',run.progress)
   self.emit('MAP_BOSS_MOVE: одна A по кнопке Переместиться передана; закрываю карту и проверяю игровой автопуть, без атаки')
   return True
  if run.phase=='MINI_SAMPLE':
   if is_map(frame):
    if now-run.since>3:self.end(now,True,'карта не закрылась для чтения миникарты')
    return True
   e.map_active=False;run.map_open=False
   radar=e.minimap.observe(frame)
   pose=self.coordinates.observe_minimap(frame,radar,view['state'],now)
   if pose is not None or now-run.since>3:
    self.emit('MAP_MINI_FIX: '+('источник='+pose.source+'; совпадений='+str(pose.inliers)+'; качество='+str(round(pose.error,3)) if pose else 'рельеф не подтверждён; использую другие источники'))
    self.phase('OPEN',now)
   return True
  if run.phase=='OPEN':
   e.map_active=True;run.map_open=True
   if is_map(frame):self.phase('MAP',now);return True
   result=self.transport.map_toggle(lambda:self.permitted(e))
   if not result.attempted:self.end(now,True,'карта не открыта: '+result.reason)
   else:run.centered_open=True;self.phase('MAP',time.monotonic())
   return True
  if run.phase in ('MAP','CHECK_MAP'):
   if not is_map(frame):
    if now-run.since>seconds('map_open_timeout_s'):self.end(now,True,'M не подтвердилось за лимит')
    return True
   if self._recover_open_map_link(e,now):return True
   info=info_card(frame)
   if info is not None:
    run.centered_open=False
    if info.close is not None and run.info_close_at is None:
     fresh,origin=e.screen.frame();shape=fresh.shape;stamp=TerrainLease.capture(fresh,info.close)
     e.bridge.cursor(origin[0]+info.close[0],origin[1]+info.close[1]);run.info_close_at=now
     def allowed_info_close():
      if not self.permitted(e) or not e.bridge.cursor_matches():return False
      current,current_origin=e.screen.frame()
      return current_origin==origin and current.shape==shape and map_title_matches(current,stamp.header) and same_info(current,info)
     e.gamepad.tap_ui_a(e.stop_event,e.screen.focused,allowed_info_close)
     self.emit('MAP_INFO_CLOSE: один клик по найденному X описания зоны, без перемещения и повторного ПКМ');return True
    if run.info_close_at is not None and now-run.info_close_at<1:return True
   if card_open(frame):
    if run.ui_reset_at is None:
     tab=kibelisk_tab(frame)
     if tab is None:self.end(now,True,'карточка объекта закрывает карту; вкладка Кибелиск не подтверждена');return True
     stamp=TerrainLease.capture(frame,tab.point);origin=e.screen.frame()[1]
     e.bridge.cursor(origin[0]+tab.point[0],origin[1]+tab.point[1])
     run.ui_reset_at=now;run.centered_open=False
     e.gamepad.tap_ui_a(e.stop_event,e.screen.focused,lambda:self.permitted(e) and map_title_matches(e.screen.frame()[0],stamp.header))
     self.emit('MAP_UI_RESET: карточка объекта; один клик по подтверждённой вкладке Кибелиск, без F/перемещения к боссу')
    elif now-run.ui_reset_at>2:self.end(now,True,'карточка объекта не закрылась после смены вкладки')
    return True
   _register_t0=time.perf_counter()
   fix=self._register_map(frame)
   _atlas=getattr(self.coordinates,'native',None)
   log_stage(self.emit,'map_register',_register_t0,valid=int(fix is not None),
             sift=int(TIMING.get('map_sift_features')),
             fallback=int(bool(getattr(_atlas,'last_exp_fallback',False))))
   if fix is None:
    if now-run.since>seconds('map_fix_timeout_s'):self.end(now,True,'карта/стрелка не сопоставлены: '+str(getattr(getattr(self.coordinates,'native',None),'reason','нет привязки')))
    return True
   latest=e._net_view()
   if not latest or not latest['ready'] or latest['flow']!=run.flow or run.owner is not None and latest['state'].own!=run.owner:
    self.cancel(e,'сеть/персонаж изменились во время распознавания карты');return True
   view=latest
   self._prepare_fix(fix,view['state'])
   if (run.phase=='MAP' and run.reason=='resources' and not run.mini_sampled and run.goal is None
       and getattr(self.coordinates,'texture_enabled',False) and getattr(self.coordinates,'nearby_markers',False) and hasattr(self.coordinates,'observe_minimap')
       and not (0<=now-getattr(self.coordinates,'mini_goals_at',-1e9)<=8)):
    run.mini_sampled=True
    self._toggle_map(e,lambda:self.permitted(e));self.phase('MINI_SAMPLE',time.monotonic())
    self.emit('MAP_MINI_SAMPLE: читаю два кадра миникарты для переноса текущих ресурсов на большую карту');return True
   if run.phase=='CHECK_MAP':
    run.arrival_xy=fix.get('world')
    # Experimental: if no route HUD appeared, and a FRESH map shows the
    # player did not move, allow ONE same-goal retry. Reproject the cursor
    # on the new map; do not blindly double-click after the first macro.
    if run.short_check and run.experimental_retry_checked and not run.experimental_retry_sent and not run.hud_seen and run.reason=='resources' and run.goal is not None and fix.get('world') is not None and run.fix is not None and run.fix.get('world') is not None:
     moved=math.dist(fix['world'],run.fix['world'])/100
     remaining=math.dist(fix['world'],self._world_goal(run.goal))/100
     point=self.coordinates.pixel(run.goal,fix)
     if self._fast_retry_permitted(run.fix['world'],fix['world'],remaining,point) and self.permitted(e):
      run.experimental_retry_sent=True
      run.short_check=False;run.map_open=True
      run.fix=fix;run.map_lease=TerrainLease.capture(frame,point)
      run.attempted=False;run.ack=False;run.missing=0;run.missing_since=None
      run.best=None;run.near=0;run.progress=now
      self.emit('MAP_FAST_RETRY: нет HUD, на свежей карте стоим на месте ('+str(round(moved,1))+' м); один повтор ПКМ к той же цели, расстояние '+str(round(remaining,1))+' м')
      self.phase('CLICK',now);return True
     run.experimental_retry_sent=True
     self.emit('MAP_FAST_RETRY_SKIP: движение='+str(round(moved,1))+' м, цель='+str(round(remaining,1))+' м; повтор запрещён')
    if fix.get('world') is None:
     if run.hud_seen and run.missing>=3:self.end(now,False,'надпись автопути исчезла; свою позицию не измеряю, передаю визуальному поиску')
     elif run.short_check:self.end(now,True,'нет надписи автопути и подтверждённой позиции; клик не повторяю')
     else:self.phase('CLOSE',now)
     return True
    distance=math.dist(fix['world'],self._world_goal(run.goal))/100
    if (distance>6 and run.hud_seen and run.missing>=3
        and fix.get('projection_bias') is not None and run.correction_clicks<1
        and self.coordinates.pixel(run.goal,fix) is not None):
     run.correction_clicks+=1;run.fix=fix;run.attempted=False;run.ack=False
     run.hud_seen=False;run.missing=0;run.missing_since=None;run.near=0;run.best=None;run.progress=now;run.short_check=False
     self.emit('MAP_REPROJECT: подтверждённая поправка; до ТОЙ ЖЕ цели '+str(round(distance,1))+' м; один исправленный маршрут')
     self.phase('CLICK',now);return True
    if run.short_check and not run.hud_seen:
     if run.attempted and distance<=6:self.end(now,False,'короткий маршрут проверен по свежей карте: до точки назначения '+str(round(distance,1))+' м по XY; надпись могла исчезнуть до закрытия M')
     else:
      travel=confirmed_map_travel_progress(run.fix.get('world') if run.fix else None,fix.get('world'),self._world_goal(run.goal)) if run.goal is not None else None
      if travel is not None:
       # No route caption is NOT a click failure when the avatar has demonstrably
       # moved toward the SAME goal. Close the map and let the game keep walking.
       run.fix=fix;run.short_check=False;run.progress=now
       run.verified_map_progress_at=now
       self.emit('MAP_ROUTE_PROGRESS: надпись автопути не найдена, но подтверждено движение '+str(round(travel[0],1))+' м и сближение с той же целью на '+str(round(travel[1],1))+' м; осталось '+str(round(travel[2],1))+' м; сохраняю текущий автопуть, новый ПКМ запрещён')
       self.phase('CLOSE',now)
      else:self.end(now,True,'нет надписи автопути; по свежей карте до цели '+str(round(distance,1))+' м; клик не повторяю')
    elif distance<15 and run.hud_seen and run.missing>=3:self.end(now,False,'маршрут исчез; до выбранной точки '+str(round(distance,1))+' м по XY; довожу подход по миникарте')
    elif run.hud_seen and run.missing>=3:self.end(now,True,'маршрут исчез вдали от точки; это не прибытие')
    else:self.phase('CLOSE',now)
    return True
   self.emit('MAP_FIX: '+(str(tuple(round(v,1) for v in fix['world'])) if fix.get('world') is not None else 'позиция персонажа неизвестна; цель вычисляется по рельефу')+'; совпадений='+str(fix.get('inliers','?'))+'; область='+str(fix.get('search_source','player_arrow'))+'; кадр='+str(fix.get('frame_size','?'))+'; ошибка рельефа px='+str(fix.get('registration_error_px','?')))
   if run.goal is not None and self.coordinates.temporarily_blocked(run.goal,now):
    self.emit('MAP_FAILED_XYZ_30: подготовленная цель временно заблокирована; выбираю другую')
    run.goal=None
   if run.goal is not None and run.reason=='resources' and getattr(run.goal,'name',None)=='Эфир':
    e.policy.update(e.budget)
    if not e.policy.allows('Эфир'):
     self.emit('MAP_AETHER_ENERGY_HOLD: заранее подготовленный эфир отложен до '+
               str(int(e.policy.route_resume or 35))+'% энергии; выбираю наземный ресурс')
     run.goal=None
   if run.goal is not None:
    point=self.coordinates.pixel(run.goal,fix)
    if point is None:self.end(now,True,'заданная точка вышла из вида карты')
    else:
     run.fix=fix;run.map_lease=TerrainLease.capture(frame,point)
     run.straight=math.dist(fix['world'],self._world_goal(run.goal))/100 if fix.get('world') is not None else 0
     run.pending_air=bool(run.goal.air or e.budget.airborne);self.phase('CLICK',now)
    return True
   if self.required:
    e.policy.update(e.budget);self.coordinates.active_names=set(e.policy.names(e.cfg.get('target_names',('Эфир','Алмаз','Сапфир','Рубин'))))
   if run.reason=='resources' and e.policy.route_recovering is True and e.policy.route_resume is not None:
    current='не измерена' if e.budget.energy is None else f'{e.budget.energy:.1f}%'
    self.emit('MAP_AETHER_ENERGY_HOLD: энергия '+current+'; новая цель Эфир отложена до '+
              str(int(e.policy.route_resume))+'%; пока ищу наземные ресурсы')
   can_fly=e.budget.can_start() and e.budget.energy is not None and e.budget.energy>=50
   _goals_t0=time.perf_counter()
   goals=self.coordinates.goals(view['state'],fix,now,e.budget.can_start() and e.policy.allows('Эфир'),e.policy.priority,run.reason=='camp',run.reason=='escape')
   log_stage(self.emit,'map_goal_rank',_goals_t0,count=len(goals),index=int(TIMING.get('map_goal_spatial_index')))
   report=getattr(self.coordinates,'last_source_report',None)
   if run.reason=='resources' and report:self.emit('MAP_GOAL_SOURCE: '+report)
   live_report=getattr(self.coordinates,'last_live_filter_report','')
   if run.reason=='resources' and live_report:self.emit('MAP_LIVE_FILTER: '+live_report)
   if (run.reason=='resources' and self.cfg.get('map_edge_recenter_enabled',True)
       and self.edge_recenter.eligible(now,goals,fix,self.coordinates)
       and getattr(e,'daily_camp_state','idle')=='idle'):
    self.edge_recenter.request(now)
    self.emit('MAP_RECENTER_DECISION: у края нет доступного live-ID/мини-карты; уже проверены две разные пустые точки каталога; возвращаюсь к кибелиску вместо очередного дальнего маршрута')
    self.end(now,False,'MAP_RECENTER: закрываю карту без клика по каталогу')
    return True
   if not goals and run.reason in ('resources','camp'):
    # No eligible resource should strand the character at the kibelisk.
    # First extend to a grounded catalogue point, then try a terrain-mapped
    # exploration waypoint; never click without a registered current map.
    rescue=self.coordinates.recovery_goal(view['state'],fix,now,e.budget.can_start() and e.policy.allows('Эфир'),self.explore_index)
    if rescue is not None:
     self.explore_index+=1
     goals=[rescue]
     source='справочная точка за обычным радиусом' if rescue.name!='Разведка области' else 'точка разведки на подтверждённой карте'
     self.emit('MAP_NO_GOAL_MOVE: доступных целей в обычном радиусе нет; '+source+'; координаты='+str(rescue.xyz)+'; попытка='+str(self.explore_index))
   if not goals:
    reason='ближайшая цель не определена: нет позиции персонажа/уникальной привязки миникарты; центр вида не используется' if fix.get('search_source')=='unknown' else 'в видимой области нет подходящей точки'
    self.end(now,True,reason);return True
   if run.reason=='escape' and self.last_goal:
    goals.sort(key=lambda g:math.dist(g.reference,self.last_goal.reference)+.25*math.dist(g.reference,fix.get('search_position') or fix['position']))
   plan=getattr(self,'next_plan',None)
   if plan is not None and 0<=now-plan.created<=30 and run.reason=='resources':
    same=bool(plan.ranked and plan.ranked[0].key==goals[0].key)
    self.emit('MAP_NEXT_CHECK: '+('подготовленная цель подтверждена' if same else 'порядок обновлён по свежей карте/сети')+'; '+goals[0].name)
   run.goal=goals[0];run.fix=fix
   run.map_lease=TerrainLease.capture(frame,self.coordinates.pixel(run.goal,fix))
   run.pending_air=bool(run.goal.air or e.budget.airborne)
   run.straight=math.dist(fix['world'],self._world_goal(run.goal))/100 if fix.get('world') is not None else 0
   if (run.reason!='camp' and can_fly and self.cfg.get('map_mousekeys_fly_long',True)
       and fix.get('projection_bias') is not None
       and run.straight>=max(30,float(self.cfg.get('map_mousekeys_flight_distance_m',80)))):
    run.goal=replace(run.goal,air=True);run.pending_air=True
   if run.goal.air:
    self.phase('CLOSE_FOR_WINGS',now)
    return True
   # EXP114: The same frame has *just* passed is_map(), atlas registration,
   # goal ranking and the destination TerrainLease. Avoid waiting for an
   # entire subsequent engine loop before the existing CLICK verification.
   # CLICK still independently captures a fresh pre-cursor frame, moves the
   # cursor, obtains a new post-cursor frame, checks the map lease/focus,
   # and only then dispatches RIGHT_STEP. No check is deleted here.
   self.phase('CLICK',time.monotonic())
   self.emit('MAP_CLICK_SAME_TICK: новая цель проверена; запускаю штатную защитную проверку ПКМ без следующего цикла')
   # Fall through to the existing CLICK branch below, in this same tick.
  if run.phase=='CLOSE_FOR_WINGS':
   if is_map(frame):self._toggle_map(e,lambda:self.permitted(e));self.phase('WINGS',time.monotonic())
   else:self.phase('WINGS',now)
   e.map_active=False;run.map_open=False;run.centered_open=False;return True
  if run.phase=='WINGS':
   if is_map(frame):
    if now-run.since>3:self.end(now,True,'карта не закрыта перед раскрытием крыльев')
    return True
   reading=e._flight_reading(frame);e._budget_update(reading,now)
   if reading.confirmed:self.phase('OPEN',now);return True
   if reading.swimming or not e.budget.can_start() or e.budget.energy is None or e.budget.energy<50:self.end(now,True,'крылья сейчас недоступны');return True
   if now-run.since>.4 and not run.wing_sent:
    e.bridge_cmd('V');run.wing_sent=True
   if now-run.since>3:self.end(now,True,'раскрытие крыльев не подтверждено')
   return True
  if run.phase=='CLICK':
   if not self.permitted(e):self.end(now,True,'отменено до клика');return True
   self.emit('EXP_STAGE: preclick_phase_queue duration_ms='+str(round(max(0,time.monotonic()-run.since)*1000,3)))
   _preclick_began=time.perf_counter()
   _before_click_capture=time.perf_counter()
   fresh,origin,_reused,_reuse_reason=preliminary_frame(e,frame,now,TIMING.get('map_preclick_reuse_max_age_ms'))
   log_stage(self.emit,'preclick_frame',_before_click_capture,reused=int(_reused),reason=_reuse_reason)
   first_click=bool(int(TIMING.get('map_first_click_then_check')) and run.fix is not None
        and run.goal is not None and run.map_lease is not None and e._focus_ok() and e.map_active)
   # The previous MAP phase already verified the title and registered terrain.
   # If the captured header AND >=88% remote tiles still match, repeating
   # OCR-based is_map twice is redundant. Any changed map uses legacy OCR.
   _lease_t0=time.perf_counter()
   cached=verified_map_lease(fresh,run.fix,run.map_lease)
   log_stage(self.emit,'preclick_lease',_lease_t0,cached=int(bool(cached)))
   if not cached and not is_map(fresh):
    self.end(now,True,'карта исчезла до клика');return True
   static_fast=None
   if (not first_click and not cached and int(TIMING.get('map_preclick_static_fast')) and run.fix is not None
       and run.map_lease is not None and is_map(fresh)):
    _static_t0=time.perf_counter()
    static_fast=run.map_lease.stable_terrain(fresh)
    log_stage(self.emit,'preclick_static_fast',_static_t0,accepted=int(static_fast is not None))
    self.emit('MAP_STATIC_DIAG: '+json.dumps(run.map_lease.static_diag,ensure_ascii=False,separators=(',',':')))
    if static_fast is not None:
     self.emit('MAP_STATIC_FAST: рельеф не сдвинулся; стабильных участков '+
               str(static_fast[0])+'/'+str(static_fast[1])+', повторный SIFT пропущен')
   structural_fast=None
   if (not first_click and not cached and static_fast is None
       and int(TIMING.get('map_preclick_structural_fast'))
       and run.fix is not None and run.map_lease is not None):
    _struct_t0=time.perf_counter()
    structural_fast=run.map_lease.structural_static(fresh)
    log_stage(self.emit,'preclick_structural_fast',_struct_t0,accepted=int(structural_fast is not None))
    self.emit('MAP_STRUCTURAL_DIAG: '+json.dumps(run.map_lease.static_diag,ensure_ascii=False,separators=(',',':')))
    if structural_fast is not None:
     self.emit('MAP_STRUCTURAL_FAST: рельеф структурно совпал; повторный SIFT пропущен')
   fix=run.fix if first_click or cached or static_fast is not None or structural_fast is not None else self._register_map(fresh)
   if not first_click and not cached and static_fast is None and structural_fast is None and fix:self._prepare_fix(fix,view['state'])
   point=self.coordinates.pixel(run.goal,fix) if fix else None
   if self.coordinates.temporarily_blocked(run.goal,now):
    self.end(now,True,'временный запрет координаты 30 с; выбираю другую цель');return True
   if point is None:self.end(now,True,'точка вышла из подтверждённого вида карты');return True
   lease=TerrainLease.capture(fresh,point)
   log_stage(self.emit,'preclick_before_cursor',_preclick_began,structural=int(structural_fast is not None))
   _cursor_t0=time.perf_counter()
   e.bridge.cursor(origin[0]+point[0],origin[1]+point[1])
   self.emit('EXPERIMENT_CURSOR_SET: point='+str(point))
   if not GamepadInput.wait(seconds('cursor_settle_ms'),e.stop_event,e.screen.focused):return True
   log_stage(self.emit,'preclick_cursor_and_settle',_cursor_t0)
   _final_t0=time.perf_counter()
   if first_click:
    # Fast-first experiment: screenshot/terrain verification is intentionally
    # DEFERRED until AFTER Lua's RMB ACK (the game can already be travelling).
    # We still keep the exact cursor, input focus, map and modal gates.
    final,final_origin=fresh,origin
    self.emit('MAP_FIRST_CLICK_EARLY: уже зарегистрированная карта; '
              'повторный SIFT/независимый кадр перенесены после ПКМ')
   else:
    final,final_origin=e.screen.frame()
   log_stage(self.emit,'preclick_final_capture',_final_t0,deferred=int(first_click))
   _guard_t0=time.perf_counter()
   _origin_ok=final_origin==origin
   _cursor_ok=bool(e.bridge.cursor_matches()) if _origin_ok else False
   _terrain_ok=(True if first_click else bool(lease.matches(final))) if _origin_ok and _cursor_ok else False
   _title_ok=(True if first_click else bool(cached or is_map(final))) if _terrain_ok else False
   _permission_ok=bool(self.permitted(e)) if _title_ok else False
   _guard_ok=all((_origin_ok,_cursor_ok,_terrain_ok,_title_ok,_permission_ok))
   log_stage(self.emit,'preclick_final_verify',_guard_t0,ok=int(_guard_ok))
   if not _guard_ok:
    self.emit('MAP_FINAL_GUARD_DIAG: '+json.dumps({'origin':int(_origin_ok),'cursor':int(_cursor_ok),
      'terrain':int(_terrain_ok),'title':int(_title_ok),'permitted':int(_permission_ok)},separators=(',',':')))
    # EXP119 user-option: last terrain/cursor pixel mismatch can be false
    # negative from icon/cursor overlays. Retry the EXACT computed cursor
    # point once, but never click through a closed map, lost focus, another
    # origin, a dialog, stop, or absent calculated target.
    if (int(TIMING.get('map_preclick_retry_click')) and _origin_ok and self.permitted(e)
        and e._focus_ok() and is_map(final) and not card_open(final)):
     e.bridge.cursor(origin[0]+point[0],origin[1]+point[1])
     if not GamepadInput.wait(seconds('cursor_settle_ms'),e.stop_event,e.screen.focused):return True
     _retry_frame,_retry_origin=e.screen.frame()
     if (_retry_origin==origin and e.bridge.cursor_matches() and e._focus_ok()
         and self.permitted(e) and is_map(_retry_frame) and not card_open(_retry_frame)):
      final=_retry_frame;_guard_ok=True
      self.emit('MAP_FINAL_GUARD_RETRY_CLICK: ПКМ после повторного точного наведения; '+
                'карта открыта, фокус/курсор/диалог проверены; рельефный отказ записан отдельно')
    if not _guard_ok:
     self.end(now,True,'карта/рельеф/курсор изменились до ПКМ');return True
   if cached and not first_click:self.emit('MAP_CLICK_FAST: карта не изменилась; повторная тяжёлая регистрация пропущена')
   _ui_t0=time.perf_counter()
   _blocked=card_open(final)
   if not _blocked:run.info_before=info_card(final)
   log_stage(self.emit,'preclick_modal_guard',_ui_t0,blocked=int(_blocked))
   if _blocked:
    self.end(now,True,'MAP_POINT_BLOCKED: открытая карточка закрывает карту; новый клик отменён');return True
   lease=TerrainLease.capture(final,point);run.click_rejection='';quiet_at=[-1e9,True]

   def wire_allowed():
    # NO screen acquisition/OCR/terrain matching inside the 6 short Lua bits.
    # Slow screenshots used to exceed the wire parity timeout and cancel RIGHT_STEP.
    return bool(self.run is run and not self.stopping and not e.stop_event.is_set()
                and not self.modal_blocked and e.map_active and e._focus_ok()
                and not run.finishing and e.bridge.cursor_matches())
   if not wire_allowed():self.end(now,True,'MAP_CLICK_REJECT: фокус/курсор изменился перед передачей');return True
   self.emit('EXPERIMENT_CURSOR_GUARD_OK: карта/рельеф/фокус/курсор проверены')
   # final was captured *after* placing the cursor and checked against
   # the earlier terrain lease. A third capture here merely costs ~0.5s;
   # wire_allowed keeps cursor/focus/phase guarded until Lua dispatch.
   def quiet_context():
    # The Lua macro itself may create dots/dialogs. Verify the window at a
    # measured cadence, not on EVERY 12 ms poll while holding the wire lock.
    if not wire_allowed():return False
    stamp=time.monotonic()
    if 0<=stamp-quiet_at[0]<seconds('quiet_context_cache_ms'):return quiet_at[1]
    current,current_origin=e.screen.frame()
    allowed=current_origin==origin and current.shape==final.shape
    quiet_at[:]=[time.monotonic(),allowed]
    return allowed
   departed=getattr(self.coordinates,'departed',None)
   if callable(departed):departed()
   latest=e._net_view()
   run.click_destination_sequence=getattr(latest['state'],'map_destination_sequence',0) if latest else 0
   run.click_wall=time.time()*1000
   self.emit('EXPERIMENT_RIGHT_STEP_START: начало протокола Lua')
   _lua_t0=time.perf_counter()
   result=self.transport.click(wire_allowed,keepalive=quiet_context)
   log_stage(self.emit,'lua_full_dispatch',_lua_t0,ack=int(result.acknowledged))
   if self.run is not run or self.stopping or e.stop_event.is_set():return True
   run.attempted=result.attempted;run.ack=result.acknowledged;self.last_goal=run.goal
   age=None
   if run.goal.live and isinstance(run.goal.key,tuple) and len(run.goal.key)>2:
    node=view['state'].nodes.get(run.goal.key[2]);observed=getattr(node,'left_at' if run.goal.presence=='left' else 'profile_at',None) or getattr(node,'time',0)
    if observed:age=round(max(0,time.time()*1000-observed)/1000,1)
   label='MAP_PATH_CLICK' if result.acknowledged else 'MAP_PATH_CLICK_UNCONFIRMED' if result.attempted else 'MAP_PATH_NO_CLICK'
   self.emit(label+': '+run.goal.name+'; пиксель='+str(point)+'; '+('текущая иконка: миникарта → рельеф → большая карта' if isinstance(run.goal.key,tuple) and run.goal.key[0]=='mini' else ('ID present/XYZ' if run.goal.presence=='visible' else 'ID left/XYZ') if run.goal.live else 'справочная/заданная точка')+'; XYZ='+str(run.goal.xyz)+('; возраст последнего подтверждения '+('3536' if run.goal.presence=='left' else '3436')+'='+str(age)+' с' if age is not None else '')+'; прямая XY='+str(round(run.straight,1))+' м; '+result.reason)
   if not result.attempted:self.end(time.monotonic(),True,'Lua не отправила клик')
   elif not result.acknowledged:self.end(time.monotonic(),True,'Lua не подтвердила клик; повторный ПКМ запрещён')
   else:
    if first_click:
     run.deferred_click_check={'point':tuple(point),'origin':tuple(origin),'checked':False}
     self.emit('MAP_POSTCLICK_QUEUED: ПКМ подтверждён, проверка точки выполняется при ещё открытой карте')
    run.progress=time.monotonic();self.phase('CLOSE',run.progress)
   return True
  if run.phase=='CLOSE':
   if is_map(frame):run.map_open=True;e.map_active=True
   check=run.deferred_click_check
   if check is not None:
    receipt,distance=self._destination_receipt(e,run)
    if receipt=='match':
     run.deferred_click_check=None;check=None
     self.emit('MAP_DESTINATION_MATCH: свежий 0391 после нашего ПКМ; отклонение XY '+str(round(distance,3))+' м; SIFT после клика пропущен, прибытие проверяется отдельно')
    elif receipt=='mismatch':
     self.emit('MAP_DESTINATION_MISMATCH: 0391 отличается от цели на '+str(round(distance,2))+' м; маршрут уже идёт, выполняю прежнюю проверку карты')
   if check is not None:
    run.deferred_click_check=None # one-shot even if the check/correction fails
    if (run.attempted and run.ack and run.map_open and is_map(frame)
        and not card_open(frame) and self.permitted(e) and e._focus_ok()):
     original=check['point'];origin_before=check['origin']
     _post_t0=time.perf_counter()
     fix_after=self._register_map(frame)
     if fix_after is not None:
      if run.projection_bias is not None and fix_after.get('projection_bias') is None:
       self.coordinates.apply_bias(fix_after,run.projection_bias,run.projection_source)
      verified_point=self.coordinates.pixel(run.goal,fix_after)
     else:verified_point=None
     log_stage(self.emit,'postclick_map_register',_post_t0,valid=int(verified_point is not None))
     if verified_point is None:
      self.emit('MAP_POSTCLICK_CHECK: карту не удалось повторно зарегистрировать; ПКМ НЕ повторяю')
     else:
      offset=math.dist(original,verified_point)
      self.emit('MAP_POSTCLICK_CHECK: отклонение='+str(round(offset,2))+' px; '
                'автопуть уже запущен; коррекция только при двух независимых подтверждениях')
      if offset>10 and fix_after.get('inliers',0)>=50 and fix_after.get('registration_error_px',1e9)<=.8:
       second,second_origin=e.screen.frame()
       if (second_origin==origin_before and is_map(second) and not card_open(second)
           and self.permitted(e) and e._focus_ok()):
        second_fix=self._register_map(second)
        if second_fix is not None:
         if run.projection_bias is not None and second_fix.get('projection_bias') is None:
          self.coordinates.apply_bias(second_fix,run.projection_bias,run.projection_source)
         second_point=self.coordinates.pixel(run.goal,second_fix)
        else:second_point=None
        if (second_point is not None and math.dist(verified_point,second_point)<=3
            and second_fix.get('inliers',0)>=50 and second_fix.get('registration_error_px',1e9)<=.8
            and not self.coordinates.temporarily_blocked(run.goal,now)
            and self._destination_receipt(e,run)[0]!='match'):
         self.emit('MAP_POSTCLICK_CORRECTION_PROVEN: два SIFT совпали; точка изменилась на '+
                   str(round(offset,1))+' px; пробую один исправляющий ПКМ')
         e.bridge.cursor(second_origin[0]+second_point[0],second_origin[1]+second_point[1])
         if (GamepadInput.wait(seconds('cursor_settle_ms'),e.stop_event,e.screen.focused)
             and e.bridge.cursor_matches() and self.permitted(e) and e._focus_ok()):
          # Do not repeat after an ambiguous ACK. Every correction is at most once.
          def corrected_allowed():
           return bool(self.run is run and e.map_active and not self.stopping
                       and not e.stop_event.is_set() and not self.modal_blocked
                       and e._focus_ok() and e.bridge.cursor_matches() and self.permitted(e))
          correction=self.transport.click(corrected_allowed,keepalive=corrected_allowed)
          self.emit('MAP_POSTCLICK_CORRECTION_SENT: attempted='+str(int(correction.attempted))+
                    ' ack='+str(int(correction.acknowledged))+'; '+correction.reason)
          if correction.acknowledged:run.click_wall=time.time()*1000;run.progress=time.monotonic()
        else:self.emit('MAP_POSTCLICK_CORRECTION_REJECTED: независимая точка не подтверждена; маршрут не трогаю')
       else:self.emit('MAP_POSTCLICK_CORRECTION_REJECTED: карта/фокус поменялись; маршрут не трогаю')
    else:self.emit('MAP_POSTCLICK_CHECK_SKIPPED: карта уже закрыта, диалог или фокус потерян; ничего не повторяю')
   if run.map_open:
    if is_map(frame):
     if now-run.since>seconds('map_close_timeout_s'):self.cancel(e,'карта не закрылась');return True
     self._toggle_map(e,lambda:self.permitted(e));self.phase('CLOSE_WAIT',time.monotonic());return True
    run.map_open=False;e.map_active=False
   if run.finishing:self.finish(e,now);return True
   self._route_camera_schedule(e,run,now)
   run.check_at=now+seconds('hud_recheck_s');self.phase('TRAVEL',now);return True
  if run.phase=='CLOSE_WAIT':
   if is_map(frame):
    if now-run.since>seconds('map_close_retry_s'):
     if run.close_retries<1:
      run.close_retries+=1;e.bridge_cmd('MAP');run.since=time.monotonic()
     else:self.cancel(e,'M не закрыло карту; повтор не выдаётся за маршрут')
    return True
   run.map_open=False;e.map_active=False
   if run.finishing:self.finish(e,now)
   else:
    self._route_camera_schedule(e,run,now)
    run.check_at=now+seconds('hud_recheck_s');self.phase('TRAVEL',now)
   return True
  if run.phase=='ROUTE_WINGS':
   reading=e._flight_reading(frame);e._budget_update(reading,now)
   if reading.confirmed:
    run.pending_air=True;run.progress=now;self.phase('TRAVEL',now)
    self.emit('MAP_ROUTE_AIR: раскрытие подтверждено; продолжаю тот же автопуть без новой карты')
   elif now-run.route_wing_at>=3:
    e.budget.failed_takeoff(now);run.progress=now;self.phase('TRAVEL',now)
    self.emit('MAP_ROUTE_AIR_FAIL: раскрытие не подтверждено за 3 с; повторной V в этом маршруте нет')
   return True
  if run.phase=='TRAVEL':
   reading=e._flight_reading(frame);e._budget_update(reading,now);e.unowned_flight.observe(reading,now)
   state=view['state'];xyz=getattr(state,'xyz',None);stamp=getattr(state,'position_at',None)
   if (run.attempted and run.goal is not None and run.click_wall is not None and stamp is not None
       and stamp>=run.click_wall and 0<=time.time()*1000-stamp<=800 and xyz is not None
       and all(math.isfinite(v) for v in xyz) and math.dist(xyz[:2],self._world_goal(run.goal))<=100*TIMING.get('network_arrival_m')):
    run.arrival_xy=tuple(xyz[:2]);self.end(now,False,'свежие собственные сетевые XYZ: до ресурса не больше 6 м; повторная карта не нужна');return True
   # New positive network proof does not replace HUD or alter the route.
   # No new wait window: it only prevents a redundant M while stamina drains.
   od_drain=route_stamina_drain(state,run.click_wall,time.time()*1000)
   if od_drain and now-run.stamina_last_log_at>=1.0:
    run.stamina_last_log_at=now;run.stamina_samples+=1
    self.emit('MAP_STAMINA_DRAIN: own ОД='+str(getattr(state,'stamina',None))+
              '; delta='+str(getattr(state,'stamina_delta',None))+
              '; network_ms='+str(getattr(state,'stamina_delta_at',None))+
              '; маршрут='+str(getattr(run.goal,'name','?')))
   self._route_camera_tick(e,run,now)
   if now-run.hud_at<seconds('hud_poll_s'):return True
   run.hud_at=now;hud=route_hud(frame)
   if hud.present:
    if od_drain and not run.stamina_both_reported:
     run.stamina_both_reported=True
     self.emit('MAP_STAMINA_HUD_BOTH: надпись автопути и свежий расход ОД подтверждены вместе')
    run.hud_seen=True;run.missing=0;run.missing_since=None
    if run.travel_at is None:run.travel_at=now
    if hud.metres is not None:
     if run.best is None or hud.metres<run.best-1:run.best=hud.metres;run.progress=now
     run.near=run.near+1 if hud.metres<=TIMING.get('hud_arrival_m') else 0
     if run.near>=int(TIMING.get('hud_arrival_checks')):self.end(now,False,'две свежие проверки автопути: осталось не больше 3 м');return True
    # Intentional travel optimization for ALL resource types (including ground
    # resources): after seven seconds of confirmed in-game autoroute, unfold
    # wings to bypass long detours/obstacles without interrupting the route.
    # This is separate from the obsolete APPROACH -> TAKEOFF recovery.
    if (run.travel_at is not None and now-run.travel_at>=seconds('route_wing_trigger_s') and not run.route_wing_attempted
        and not reading.confirmed and not reading.swimming and e.budget.can_probe(18)
        and (hud.metres is None or hud.metres>3)):
     self.open_route_wings(e,now);return True
   elif hud.present is False and run.hud_seen:
    run.missing+=1
    if run.missing_since is None:run.missing_since=now
   # The route label can finish before the first post-click frame. If a
   # CURRENT minimap already locates the requested family right on our arrow,
   # use two independent samples instead of reopening the large map.
   if (not run.hud_seen and run.goal is not None and run.reason=='resources'
       and not (isinstance(run.goal.key,tuple) and run.goal.key[0]=='explore')
       and now-run.since>1.2 and not hud.present):
    radar=e.minimap.observe(frame)
    if radar is not None:
     kind='aether' if 'эфир' in run.goal.name.lower() else 'gem'
     scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
     near=any(m.kind==kind and m.distance<=8*scale for m in radar.markers)
     # A random same-family pin nearby must not be mistaken for the exact
     # distant route destination. Permit the fast handoff only for a short
     # verified map route or a terrain-registered pin at this target XYZ.
     close_route=run.fix is not None and run.fix.get('world') is not None and run.straight<=15
     mini_goals=getattr(self.coordinates,'mini_goals',()) if 0<=now-getattr(self.coordinates,'mini_goals_at',-1e9)<=1.5 else ()
     k=abs(float(getattr(self.coordinates,'matrix',[[.001]])[0][0])) if hasattr(self.coordinates,'matrix') else .001
     pinned=any(isinstance(g.key,tuple) and g.key[0]=='mini' and g.key[1]==kind
                and math.dist(g.reference,run.goal.reference)<=9*100*k for g in mini_goals)
     run.short_near_hits=run.short_near_hits+1 if near and (close_route or pinned) else 0
     if run.short_near_hits>=2:
      self.end(now,False,'короткий маршрут: две свежие миникарты подтвердили иконку ресурса у стрелки; без повторного M')
      return True
   if now-run.progress>seconds('route_no_progress_timeout_s') and run.hud_seen and hud.present:
    run.route_motion_failed=True
    self.end(now,True,'расстояние автопути не уменьшается после попытки спасения/при недоступных крыльях; осмотр недостигнутой точки запрещён');return True
   # A nearby route can finish during the mandatory QUIET/M-open interval.
   # Missing HUD alone cannot distinguish that arrival from a failed click.
   if run.missing>=3 and (run.projection_bias is not None or run.best is not None and run.best<=12):
    self.end(now,False,'подтверждённый автопуть завершён; передаю свежей миникарте без повторного M');return True
   # The game may hide its route text for a few frames. In this program
   # the avatar is not manually sprinted: fresh consumption of OWN ОД after
   # the confirmed RMB is sufficient to KEEP this same autoroute. It never
   # authorizes arrival, a new click, or a change of target.
   if not hud.present and od_drain:
    if not run.stamina_hold_active:
     run.stamina_hud_rescues+=1
     self.emit('MAP_STAMINA_HOLD: HUD отсутствует; свежий расход собственных ОД после ПКМ; '
               'не открываю M, не меняю цель, продолжаю автопуть')
    run.stamina_hold_active=True
    return True
   if run.stamina_hold_active:
    run.stamina_hold_active=False
    self.emit('MAP_STAMINA_HOLD_END: '+('HUD восстановлен' if hud.present else
             'свежего расхода ОД нет; обычная проверка HUD/карты (бой или прибытие возможны)'))
   # Experimental retry check after 1.1 s with no HUD on a truly
   # stationary distant route. This only OPENS the map for validation;
   # a second RMB is impossible without the independent fresh map check.
   if (run.reason=='resources' and run.attempted and not run.hud_seen
       and not run.experimental_retry_checked and not reading.confirmed
       and now-run.since>=seconds('hud_fast_verify_s') and run.fix is not None and run.fix.get('world') is not None
       and run.straight>12):
    run.experimental_retry_checked=True;run.short_check=True
    self.emit('MAP_FAST_VERIFY: нет признаков автопути; проверяю координаты прежде чем повторять ПКМ')
    e.map_active=True;run.map_open=True
    run.centered_open=bool(self._toggle_map(e,lambda:self.permitted(e)))
    self.phase('CHECK_MAP',time.monotonic());return True
   if (not run.hud_seen and run.verified_map_progress_at>0
       and now-run.verified_map_progress_at<8.0):
    # A fresh independent map confirmed movement toward the clicked resource.
    # Avoid immediately reopening M while the avatar is still on that path.
    return True
   if run.missing>=3 or not run.hud_seen and now-run.since>seconds('hud_fallback_s'):
    run.short_check=not run.hud_seen
    if run.short_check:self.emit('MAP_SHORT_CHECK: надпись автопути не замечена; один раз проверяю фактическую позицию на карте без повторного ПКМ')
    e.map_active=True;run.map_open=True
    run.centered_open=bool(self._toggle_map(e,lambda:self.permitted(e)));self.phase('CHECK_MAP',time.monotonic())
   elif now>=run.check_at:run.check_at=now+seconds('hud_recheck_s')
   return True
  return True
 def _prepare_fix(self,fix,state):
  prepare=getattr(self.coordinates,'prepare',None)
  if callable(prepare):prepare(fix,state)
  run=self.run
  if run is None:return
  if fix.get('projection_bias') is not None:
   bias=fix['projection_bias'];source=fix['world_source']
   if run.projection_bias is None:self.emit('MAP_COORD_ANCHOR: '+source+'; коррекция мировой проекции '+str(round(math.hypot(*bias)/100,1))+' м; исходные XYZ не изменяются')
   run.projection_bias=bias;run.projection_source=source
  elif run.projection_bias is not None:
   self.coordinates.apply_bias(fix,run.projection_bias,run.projection_source)
 def _register_map(self,frame):
  opened=getattr(self.coordinates,'register_open_map',None)
  panel=info_card(frame)
  if self.run is not None and panel is not None:self.run.centered_open=False
  fast=getattr(self.coordinates,'register_open_map_fast',None)
  initial=bool(self.run is not None and self.run.centered_open and self.run.phase=='MAP' and not self.run.attempted)
  if initial and callable(fast) and TIMING.get('map_fast_recenter') and TIMING.get('map_first_click_then_check'):
   fix=fast(frame)
   if fix is not None and fix.get('registration_kind')=='recenter':
    self.emit('MAP_RECENTER_FAST: сдвиг по '+str(fix.get('inliers'))+' участкам рельефа; '+str(fix.get('recenter_shift'))+' px; полный SIFT после ПКМ')
  else:fix=opened(frame) if self.run is not None and self.run.centered_open and callable(opened) else self.coordinates.register(frame)
  if fix is not None and panel is not None:
   x0,y0,x1,y1=fix['viewport'];fix['viewport']=(x0,y0,min(x1,round(frame.shape[1]*.75)),y1)
  return fix
 def _destination_receipt(self,e,run):
  view=e._net_view()
  if (not view or not view.get('ready') or not view.get('identity_ready') or view['flow']!=run.flow
      or run.owner is None or view['state'].own!=run.owner or run.goal is None):return 'unknown',None
  zones=getattr(self.coordinates,'meta',{}).get('openZones',())
  return destination_receipt(view['state'],self._world_goal(run.goal),run.click_wall,
                             run.click_destination_sequence,time.time()*1000,zones)
 def _world_goal(self,goal):
  from map_reference import transform
  xy=tuple(goal.xyz[:2]) if goal.xyz else transform(goal.reference,self.coordinates.inverse)
  bias=getattr(self.run,'projection_bias',None)
  if goal.xyz is None and isinstance(goal.key,tuple) and goal.key[0]=='mini' and bias is not None:xy=tuple(a+b for a,b in zip(xy,bias))
  return xy
 @staticmethod
 def _patch(frame,point):
  x,y=point;return frame[max(0,y-42):y+43,max(0,x-42):x+43].copy()
