"""A destination echo verifies coordinates, never movement/arrival or liveness."""
import math

def destination_receipt(state,expected,click_wall,prior_sequence,now_ms,zones,tolerance_m=2.5):
 if state is None or click_wall is None or not zones:return 'unknown',None
 point=getattr(state,'map_destination',None);at=getattr(state,'map_destination_at',None)
 sequence=getattr(state,'map_destination_sequence',0);zone=getattr(state,'map_destination_zone',None)
 if (point is None or len(point)!=3 or at is None or sequence<=prior_sequence
     or zone not in zones or not click_wall<=at<=now_ms or not 0<=now_ms-at<=2500):return 'unknown',None
 if getattr(state,'map_id',None) is not None and state.map_id!=zone:return 'unknown',None
 if len(expected)!=2 or not all(math.isfinite(x) for x in (*point,*expected)):return 'unknown',None
 distance=math.dist(point[:2],expected)/100
 return ('match' if distance<=tolerance_m else 'mismatch'),distance
