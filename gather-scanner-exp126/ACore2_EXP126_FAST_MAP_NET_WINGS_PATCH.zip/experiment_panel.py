# -*- coding: utf-8 -*-
"""Live timing controls for a COMPLETE original-v110 bot copy.
Experimental window edits a separate timing registry only, never the regular settings.
"""
from __future__ import annotations
import json,os,tkinter as tk
from tkinter import ttk,messagebox
from experiment_tuning import TIMING,KNOBS,BASELINE,ROOT
from experiment_lua_export import export_test_lua
from tkinter import simpledialog

class ExperimentPanel:
 def __init__(self,parent,log,recorder,app=None):
  self.parent=parent;self.log=log;self.recorder=recorder;self.app=app
  self.top=tk.Toplevel(parent);self.top.title('ACore2 EXP 126 — координата ПКМ и крылья по сети')
  self.top.geometry('1040x790');self.top.minsize(800,600)
  self.top.protocol('WM_DELETE_WINDOW',self.top.withdraw)
  self.vars={}
  intro=ttk.Frame(self.top,padding=10);intro.pack(fill='x')
  ttk.Label(intro,text='Это ПОЛНАЯ копия Gather Scanner v110 — выбор цели, автопуть, сбор, защита и возвраты НЕ отключены.',font=('Segoe UI',10,'bold'),wraplength=970).pack(anchor='w')
  ttk.Label(intro,text='Изменения ползунков применяются после отпускания мыши либо Enter, со СЛЕДУЮЩЕЙ полной командой. '
             'Не изменяйте настройки сразу пачкой: сравнивайте с базовой сессией. '
             'Слишком короткие интервалы могут сломать передачу G HUB и движение.',foreground='#a53',wraplength=960).pack(anchor='w',pady=(5,0))
  self.screenshot_var=tk.BooleanVar(value=bool(app.cfg.get('debug_screenshots',False)) if app is not None else False)
  ttk.Checkbutton(intro,text='Диагностические кадры при зависании распознавания (могут немного замедлять проблемные случаи)',
                  variable=self.screenshot_var,command=self.toggle_screenshots).pack(anchor='w',pady=(6,0))
  tabs=ttk.Notebook(self.top);tabs.pack(fill='both',expand=True,padx=10,pady=6)
  groups=list(dict.fromkeys(k.group for k in KNOBS))
  for group in groups:
   frame=ttk.Frame(tabs);tabs.add(frame,text=group)
   canvas=tk.Canvas(frame,highlightthickness=0);bar=ttk.Scrollbar(frame,orient='vertical',command=canvas.yview)
   inner=ttk.Frame(canvas,padding=10)
   inner.bind('<Configure>',lambda ev,c=canvas:c.configure(scrollregion=c.bbox('all')))
   canvas.create_window((0,0),window=inner,anchor='nw')
   canvas.configure(yscrollcommand=bar.set)
   canvas.pack(side='left',fill='both',expand=True);bar.pack(side='right',fill='y')
   for knob in [k for k in KNOBS if k.group==group]:
    r=ttk.Frame(inner);r.pack(fill='x',pady=(4,11))
    ttk.Label(r,text=knob.name,width=46).pack(side='left')
    v=tk.DoubleVar(value=TIMING.get(knob.key));self.vars[knob.key]=v
    sc=ttk.Scale(r,from_=knob.minimum,to=knob.maximum,variable=v,length=250)
    sc.pack(side='left',padx=8,fill='x',expand=True)
    sc.bind('<ButtonRelease-1>',lambda _e,k=knob.key:self.apply_one(k))
    spin=ttk.Spinbox(r,from_=knob.minimum,to=knob.maximum,increment=knob.step,textvariable=v,width=8)
    spin.pack(side='left',padx=(0,5))
    spin.bind('<Return>',lambda _e,k=knob.key:self.apply_one(k))
    spin.bind('<FocusOut>',lambda _e,k=knob.key:self.apply_one(k))
    ttk.Label(r,text=knob.unit,width=4).pack(side='left')
    ttk.Label(inner,text=knob.help,foreground='#666',wraplength=950).pack(anchor='w',padx=3)
  footer=ttk.Frame(self.top,padding=10);footer.pack(fill='x')
  ttk.Button(footer,text='Применить ВСЕ поля',command=self.apply_all).pack(side='left',padx=3)
  ttk.Button(footer,text='Вернуть базовые v110',command=self.restore).pack(side='left',padx=3)
  ttk.Button(footer,text='Сохранить экспериментальный профиль',command=self.save).pack(side='left',padx=3)
  ttk.Button(footer,text='Открыть папку измерений',command=self.folder).pack(side='left',padx=3)
  ttk.Button(footer,text='Тестовый Lua (нужен Save & Run)',command=self.export_lua).pack(side='left',padx=3)
  self.status=ttk.Label(self.top,text='',foreground='#246');self.status.pack(anchor='w',padx=12,pady=(0,5))
  self.metrics=ttk.Label(self.top,text='',wraplength=970);self.metrics.pack(anchor='w',padx=12,pady=(0,12))
  self._refresh()
 def _check(self,key):
  knob=next(k for k in KNOBS if k.key==key)
  value=float(self.vars[key].get())
  if not knob.minimum<=value<=knob.maximum:raise ValueError(f'{knob.name}: {knob.minimum}…{knob.maximum} {knob.unit}')
  steps=round((value-knob.minimum)/knob.step)
  value=min(knob.maximum,max(knob.minimum,knob.minimum+steps*knob.step))
  return round(value,4)
 def _apply(self,values):
  snapshot,rev=TIMING.apply(values)
  for key,value in values.items():self.vars[key].set(value)
  TIMING.save()
  self.recorder.notice('timings_applied',{'rev':rev,'changes':values,'snapshot':snapshot})
  self.log('EXP_LIVE_APPLY: rev='+str(rev)+' '+', '.join(f'{key}={val}' for key,val in values.items())+'; следующий полный Lua-кадр')
  self.status.config(text='Применено. Ревизия '+str(rev)+'; новые значения — на следующем действии.')
 def apply_one(self,key):
  try:
   new=self._check(key)
   if abs(TIMING.get(key)-new)>1e-8:self._apply({key:new})
  except (ValueError,tk.TclError) as exc:
   self.status.config(text='Не применено: '+str(exc))
 def apply_all(self):
  try:self._apply({k.key:self._check(k.key) for k in KNOBS})
  except (ValueError,tk.TclError) as exc:messagebox.showerror('Некорректное значение',str(exc),parent=self.top)
 def restore(self):
  self._apply(BASELINE)
 def save(self):
  self.apply_all();self.log('EXP_PROFILE_SAVED: '+str(ROOT/'experiment_timing_profile.json'))
 def folder(self):
  try:os.startfile(str(self.recorder.dir))
  except (AttributeError,OSError) as exc:messagebox.showinfo('Журнал',str(self.recorder.dir),parent=self.top)
 def toggle_screenshots(self):
  if self.app is None:return
  enabled=bool(self.screenshot_var.get())
  self.app.cfg['debug_screenshots']=enabled
  if self.app.engine is not None:self.app.engine.cfg['debug_screenshots']=enabled
  self.log('EXP_DEBUG_SCREENSHOTS: '+('ON' if enabled else 'OFF')+'; действуют со следующего зависания')
  self.recorder.notice('screenshots_toggle',{'enabled':enabled})

 def export_lua(self):
  quiet=simpledialog.askinteger('Пауза до ПКМ','G HUB: ожидание перед PlayMacro, мс (200–600).\nОригинал = 300.',initialvalue=300,minvalue=200,maxvalue=600,parent=self.top)
  if quiet is None:return
  settle=simpledialog.askinteger('После макроса','G HUB: settle после PlayMacro, мс (110–450).\nОригинал = 150.',initialvalue=150,minvalue=110,maxvalue=450,parent=self.top)
  if settle is None:return
  try:
   path=export_test_lua(quiet,settle)
   self.recorder.notice('lua_generated',{'path':str(path),'quiet_ms':quiet,'settle_ms':settle})
   self.log('EXP_LUA_EXPORTED: '+str(path)+'; требует загрузки в G HUB, Save & Run и G9!')
   messagebox.showinfo('Тестовый Lua сохранён',str(path)+'\n\nВажно: в G HUB нужно вставить этот скрипт, Save & Run, затем нажать G9. До этого настройки Lua НЕ применены.',parent=self.top)
  except Exception as exc:messagebox.showerror('Ошибка Lua',str(exc),parent=self.top)

 def _refresh(self):
  if not self.top.winfo_exists():return
  s=self.recorder.status()
  med=s.get('stage_median_ms',{})
  self.metrics.config(text=(f"Сессия: {self.recorder.dir.name}   Маршруты: {s['routes']}  прибытия: {s['success']}   отказы: {s['fail']}   пустые: {s['empty']}\n"
      f"Начало сбора: {s['starts']}   результаты: {s['results']}   ПКМ: {s['clicks']}   подготовка: {s['start_to_click_med_s']} с (P95 {s['start_to_click_p95_s']}). Потерь лога: {s['missing_events']}\n"
      f"Медианы подэтапов, мс: привязка карты {med.get('map_register','?')}; ранжирование целей {med.get('map_goal_rank','?')}; первый кадр {med.get('preclick_frame','?')}; финальный кадр {med.get('preclick_final_capture','?')}; Lua кадр {med.get('lua_wire_frame','?')}; завершение макроса {med.get('lua_macro_completion','?')}"))
  self.top.after(1000,self._refresh)
