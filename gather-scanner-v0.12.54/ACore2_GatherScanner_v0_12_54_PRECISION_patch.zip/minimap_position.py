"""Screenshot-only atlas localization. Atlas pixels are NOT exact network XYZ.

An independent implementation of local SIFT/RANSAC registration, with two-frame
confirmation. No code from the surveyed programs is embedded here.
"""
from dataclasses import dataclass,replace
import math
import cv2,numpy as np

@dataclass(frozen=True)
class MiniPose:
 reference:tuple
 scale:float
 inliers:int
 error:float
 at:float
 source:str='sift'

class MinimapPosition:
 def __init__(self,image):
  self.image=image;self.seed=None;self.pending=None;self.latest=None;self.next_at=0
  self.cache=None;self.absolute_at=-1e9;self.reason='нет опорной области карты'
  self.detector=cv2.SIFT_create(nfeatures=3000,contrastThreshold=.012)
 def anchor(self,reference):
  if reference is not None and all(math.isfinite(v) for v in reference):self.seed=tuple(reference)
 def reset(self):self.seed=None;self.pending=None;self.latest=None;self.cache=None;self.next_at=0
 @staticmethod
 def gray(image):return cv2.createCLAHE(2.,(8,8)).apply(cv2.cvtColor(image,cv2.COLOR_BGR2GRAY))
 def _sift(self,frame,radar,now):
  if self.seed is None or radar is None:return None
  x0,y0,x1,y1=radar.bounds;crop=frame[y0:y1,x0:x1]
  if min(crop.shape[:2],default=0)<60:return None
  h,w=crop.shape[:2];center=(radar.center[0]-x0,radar.center[1]-y0)
  if not 0<center[0]<w or not 0<center[1]<h:return None
  cx,cy=self.seed;H,W=self.image.shape[:2]
  left=max(0,int(cx)-190);top=max(0,int(cy)-190);right=min(W,int(cx)+191);bottom=min(H,int(cy)+191)
  key=(round(cx/64),round(cy/64))
  if self.cache is None or self.cache[0]!=key:
   reference=self.image[top:bottom,left:right]
   if min(reference.shape[:2],default=0)<60:return None
   gray=cv2.resize(self.gray(reference),None,fx=4,fy=4)
   kp,des=self.detector.detectAndCompute(gray,None)
   self.cache=(key,left,top,kp,des)
  _,left,top,kp,des=self.cache
  if des is None or len(kp)<12:return None
  mask=np.full((h,w),255,np.uint8);mask[:5]=0;mask[-5:]=0;mask[:,:5]=0;mask[:,-5:]=0
  cv2.circle(mask,tuple(round(v) for v in center),max(10,round(min(h,w)*.08)),0,-1)
  hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV);mask[(hsv[:,:,1]>105)&(hsv[:,:,2]>145)]=0
  for m in radar.markers:cv2.circle(mask,(round(m.x-x0),round(m.y-y0)),7,0,-1)
  target=cv2.resize(self.gray(crop),None,fx=2,fy=2)
  q,dq=self.detector.detectAndCompute(target,cv2.resize(mask,None,fx=2,fy=2,interpolation=cv2.INTER_NEAREST))
  if dq is None or len(q)<12:return None
  matcher=cv2.FlannBasedMatcher(dict(algorithm=1,trees=4),dict(checks=48))
  pairs=[p[0] for p in matcher.knnMatch(dq,des,k=2) if len(p)==2 and p[0].distance<.70*p[1].distance]
  unique={}
  for p in sorted(pairs,key=lambda p:p.distance):unique.setdefault(p.trainIdx,p)
  pairs=list(unique.values())
  if len(pairs)<12:return None
  source=np.float32([kp[p.trainIdx].pt for p in pairs]);dest=np.float32([q[p.queryIdx].pt for p in pairs])
  a,flags=cv2.estimateAffinePartial2D(source,dest,method=cv2.RANSAC,ransacReprojThreshold=3,maxIters=2500,confidence=.995)
  if a is None or flags is None:return None
  good=flags.ravel()>0;n=int(good.sum());scale=2*math.hypot(a[0,0],a[1,0]);angle=math.degrees(math.atan2(a[1,0],a[0,0]))
  if n<12 or n<len(pairs)*.6 or not .2<scale<12 or abs(angle)>4:return None
  residual=np.linalg.norm(source@a[:,:2].T+a[:,2]-dest,axis=1)[good]/2
  span=np.ptp(dest[good],axis=0)/2
  if np.median(residual)>1.5 or np.quantile(residual,.9)>2.5 or span[0]<w*.30 or span[1]<h*.25:return None
  own=np.linalg.solve(a[:,:2],np.array(center)*2-a[:,2])/4+np.array([left,top])
  if not np.isfinite(own).all() or not 0<=own[0]<W or not 0<=own[1]<H:return None
  return MiniPose(tuple(map(float,own)),scale,n,float(np.median(residual)),now)
 def _dense(self,frame,radar,now):
  if self.seed is None or radar is None:return None
  x0,y0,x1,y1=radar.bounds;mini=frame[y0:y1,x0:x1]
  if min(mini.shape[:2],default=0)<60:return None
  h,w=mini.shape[:2];center=(radar.center[0]-x0,radar.center[1]-y0)
  cx,cy=self.seed;H,W=self.image.shape[:2]
  left=max(0,int(cx)-190);top=max(0,int(cy)-190);right=min(W,int(cx)+191);bottom=min(H,int(cy)+191)
  reference=cv2.cvtColor(self.image[top:bottom,left:right],cv2.COLOR_BGR2GRAY).astype(np.float32)
  if min(reference.shape,default=0)<60:return None
  reference-=cv2.GaussianBlur(reference,(0,0),2.)
  gray=cv2.cvtColor(mini,cv2.COLOR_BGR2GRAY)
  if gray.std()<2:return None
  mask=np.full((h,w),255,np.uint8);mask[:5]=0;mask[-5:]=0;mask[:,:5]=0;mask[:,-5:]=0
  cv2.circle(mask,tuple(round(v) for v in center),max(10,round(min(h,w)*.08)),0,-1)
  hsv=cv2.cvtColor(mini,cv2.COLOR_BGR2HSV);mask[(hsv[:,:,1]>105)&(hsv[:,:,2]>145)]=0
  for m in radar.markers:cv2.circle(mask,(round(m.x-x0),round(m.y-y0)),7,0,-1)
  choices=[]
  for scale in np.arange(.8,3.51,.1):
   size=(round(w/scale),round(h/scale))
   if size[0]>=reference.shape[1] or size[1]>=reference.shape[0] or min(size)<30:continue
   template=cv2.resize(gray,size,interpolation=cv2.INTER_AREA).astype(np.float32)
   template-=cv2.GaussianBlur(template,(0,0),2.)
   masked=cv2.resize(mask,size,interpolation=cv2.INTER_NEAREST)
   if template[masked>0].std()<1:continue
   scores=cv2.matchTemplate(reference,template,cv2.TM_CCORR_NORMED,mask=masked)
   scores=np.nan_to_num(scores,nan=-1,posinf=-1,neginf=-1)
   for _ in range(2):
    _,score,_,point=cv2.minMaxLoc(scores)
    if score<.48:break
    position=(left+point[0]+center[0]/scale,top+point[1]+center[1]/scale)
    choices.append((score,position,float(scale)))
    px,py=point;scores[max(0,py-10):py+11,max(0,px-10):px+11]=-1
  if not choices:return None
  choices.sort(reverse=True,key=lambda x:x[0]);best=choices[0]
  supported=[c for c in choices if math.dist(c[1],best[1])<3]
  other=max((c[0] for c in choices if math.dist(c[1],best[1])>12),default=0)
  if len({round(c[2],2) for c in supported})<2 or best[0]-other<.10:return None
  return MiniPose(best[1],best[2],0,1-best[0],now,'dense-texture')
 def candidate(self,frame,radar,now):
  return self._sift(frame,radar,now) or self._dense(frame,radar,now)
 def observe(self,frame,radar,now):
  if (self.latest is not None and radar is not None and radar.motion_valid
      and 0<=now-self.absolute_at<1.5 and 0<=now-self.latest.at<.8
      and math.hypot(*radar.displacement)<min(radar.bounds[2]-radar.bounds[0],radar.bounds[3]-radar.bounds[1])*.15):
   reference=tuple(p-d/self.latest.scale for p,d in zip(self.latest.reference,radar.displacement))
   self.latest=replace(self.latest,reference=reference,at=now,source='terrain-flow');self.seed=reference
   return self.latest
  if now<self.next_at:return self.latest if self.latest and 0<=now-self.latest.at<=.9 else None
  self.next_at=now+.35
  pose=self.candidate(frame,radar,now)
  if pose is None:self.pending=None;self.latest=None;self.reason='рельеф миникарты не подтвердился';return None
  if self.pending is None or now-self.pending.at>2 or math.dist(pose.reference,self.pending.reference)>8 or abs(pose.scale/self.pending.scale-1)>.08:
   self.pending=pose;self.latest=None;self.reason='ожидаю второй согласованный кадр';return None
  self.pending=pose;self.latest=pose;self.absolute_at=now;self.seed=pose.reference;self.reason='два согласованных кадра рельефа'
  return pose

