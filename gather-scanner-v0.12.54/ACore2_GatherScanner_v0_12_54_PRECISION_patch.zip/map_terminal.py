"""Bounded final approach AFTER game path arrival, using a current minimap.

No map clicks or resource actions here. A visible caption immediately gives
control to the existing native selection/collection state machine.
"""
from dataclasses import replace
import math
from navigation import Drive,Navigator
from minimap import angle_delta
from camera_control import PITCH_STRENGTH

class FinalApproach:
 def __init__(self,goal,position=None):
  self.goal=goal;self.position=position;self.marker=None;self.authorized_until=0.
  self.walked=0.;self.turns=0.;self.next_action=0.;self.last_sent=None
  self.best=None;self.stalls=0;self.heading_search=0
  # Reuse the old working vertical scan, independently from patrol steering.
  # No cone/heading correction can pre-empt its six upward pulses.
  self.sky=Navigator({'ether_quick_search':True}) if 'эфир' in goal.name.lower() else None
  self.sky_stage='SCAN';self.sky_round=0;self.finished=False
  self.adjust_turns=0;self.adjust_steps=0;self.adjust_side=0
  self.close_done=False;self.close_heading=None;self.close_heading_at=0;self.close_best=None;self.close_stalls=0;self.close_steps=0;self.close_evaluated=0

 def permits_translation(self,now):return now<=self.authorized_until and self.authorized_until>0 and self.walked<self.walk_limit
 @property
 def walk_limit(self):return 10. if self.sky is not None else 2.2
 def revoke(self):self.authorized_until=0.
 def marker_for(self,radar):
  if radar is None:return None
  kind='aether' if 'эфир' in self.goal.name.lower() else 'gem'
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  options=[m for m in radar.markers if m.kind==kind and m.distance<=90*scale]
  if not options:return None
  if self.marker is not None:
   dx,dy=radar.displacement if radar.motion_valid else (0,0)
   near=[m for m in options if math.hypot(m.x-self.marker.x-dx,m.y-self.marker.y-dy)<=15*scale]
   if not near:return None # Do not jump between neighbouring resource marks.
   chosen=min(near,key=lambda m:math.hypot(m.x-self.marker.x-dx,m.y-self.marker.y-dy))
  else:
   expected=None
   if self.position is not None and self.goal.xyz is not None:
    dx,dy=self.goal.xyz[0]-self.position[0],self.goal.xyz[1]-self.position[1]
    if math.hypot(dx,dy)>500:expected=math.degrees(math.atan2(dx,-dy))%360
   def score(m):
    bearing=math.degrees(math.atan2(m.x-radar.center[0],radar.center[1]-m.y))%360
    return (0 if expected is None or abs(angle_delta(bearing,expected))<35 else 1,m.distance)
   chosen=min(options,key=score)
  self.marker=replace(chosen);return chosen
 def plan(self,radar,now,pitch,working_ms=1200):
  self.revoke()
  ether='эфир' in self.goal.name.lower()
  if ether:return self._ether_plan(radar,now,pitch,working_ms)
  marker=self.marker_for(radar)
  if marker is None:return Drive(reason='MAP_FINAL_WAIT: жду свежую отметку того же ресурса')
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  distance=math.hypot(marker.x-radar.center[0],marker.y-radar.center[1])/scale
  if self.best is None or distance<self.best-1:self.best=distance;self.stalls=0
  if now<self.next_action:return Drive(reason='MAP_FINAL_HOLD: сохраняю ракурс для распознавания')
  heading=radar.heading if radar.confidence>=.30 else None
  bearing=math.degrees(math.atan2(marker.x-radar.center[0],radar.center[1]-marker.y))%360
  error=angle_delta(bearing,heading) if heading is not None else None
  if distance>5 and (error is None or abs(error)>18):
   if self.turns>=4:return Drive(reason='MAP_FINAL_WAIT: предел поворота, жду новое распознавание')
   if error is None:
    if self.heading_search>=2:return Drive(reason='MAP_FINAL_WAIT: конус камеры не подтверждён')
    yaw=.48;seconds=.35
   else:yaw=math.copysign(.48,error);seconds=min(.65,max(.18,abs(error)/130))
   return Drive(yaw=yaw,lifetime=seconds,yaw_lifetime=seconds,local_approach=True,
                reason='MAP_FINAL_AIM: поворачиваю камеру к отметке наземного ресурса')
  if abs(pitch)>.02:
   return Drive(pitch=-math.copysign(PITCH_STRENGTH,pitch),lifetime=min(.30,abs(pitch)/PITCH_STRENGTH),
                local_approach=True,reason='MAP_FINAL_GROUND_VIEW: возвращаю наземный ресурс в обзор')
  if distance>5 and self.walked<2.2 and self.stalls<3 and error is not None:
   seconds=min(.45,2.2-self.walked);self.authorized_until=now+.45
   return Drive(forward=.5,lifetime=seconds,tilted_motion=True,local_approach=True,
                reason='MAP_FINAL_CLOSE: коротко сближаюсь с отметкой наземного ресурса')
  return Drive(reason='MAP_FINAL_HOLD: держу ресурс в секторе камеры, жду подпись')
 @property
 def scan_pending(self):return self.sky is not None and not self.finished
 def _restart_sky(self,now):
  self.sky.scan_last_pulse=-1;self.sky.scan_next_at=now
  self.sky.scan_pitch=0;self.sky.scan_pulse_end=now;self.sky_stage='SCAN'
 def _close_to_marker(self,radar,now,pitch):
  marker=self.marker_for(radar)
  if marker is None:self.close_done=True;return None
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  distance=math.hypot(marker.x-radar.center[0],marker.y-radar.center[1])/scale
  if distance<=7 or self.walked>=self.walk_limit or self.close_stalls>=3:
   self.close_done=True;return None
  if radar.heading is None or radar.confidence<.30:
   self.close_done=True;return None # No blind walking while the cone is unknown.
  if self.close_heading is None or abs(angle_delta(radar.heading,self.close_heading))>25:
   self.close_heading=radar.heading;self.close_heading_at=now
   return Drive(reason='MAP_NEAR_WAIT: далёкая иконка; подтверждаю направление по двум свежим кадрам')
  if now-self.close_heading_at<.20:return Drive(reason='MAP_NEAR_WAIT: жду независимый кадр направления')
  if self.close_best is None or distance<self.close_best-1:
   self.close_best=distance;self.close_stalls=0
  elif self.close_steps>self.close_evaluated:self.close_stalls+=1
  self.close_evaluated=self.close_steps
  if self.close_stalls>=3:self.close_done=True;return None
  bearing=math.degrees(math.atan2(marker.x-radar.center[0],radar.center[1]-marker.y))%360
  error=math.radians(angle_delta(bearing,radar.heading));seconds=min(.45,self.walk_limit-self.walked)
  self.authorized_until=now+.45
  return Drive(forward=.65*math.cos(error),strafe=.65*math.sin(error),lifetime=seconds,
               tilted_motion=True,local_approach=True,
               reason='MAP_NEAR_CLOSE: сближаюсь с текущей иконкой ('+str(round(distance,1))+' px); полный осмотр после подхода')
 def _ether_plan(self,radar,now,pitch,working_ms):
  if self.finished:return Drive(reason='MAP_ETHER_DONE: полный вертикальный осмотр завершён')
  if now<self.next_action:return Drive(reason='MAP_ETHER_HOLD: сохраняю кадр для прежнего сканера')
  if not self.close_done:
   nearby=self._close_to_marker(radar,now,pitch)
   if nearby is not None:return nearby
  if self.sky_stage=='SCAN':
   # Use the user's whole working-view interval, not the old far-search cap
   # of 0.70/0.88 s. At 1200 ms the UP reports total 1200 ms at strength .45.
   self.sky.scan_quick_total=max(.65,min(2.,working_ms/1000))
   plan=self.sky._wide_air_scan(now)
   if not plan.restore_pitch:
    return replace(plan,local_approach=True,reason='MAP_ETHER_SCAN: '+plan.reason)
   self.sky_round+=1
   if self.sky_round>=2:
    self.finished=True
    return Drive(reason='MAP_ETHER_DONE: два полных осмотра без подписи; следующая цель')
   self.sky_stage='ADJUST'
   return Drive(reason='MAP_ETHER_HOLD: полный обзор вверх-вниз выполнен; проверяю свежую отметку')
  marker=self.marker_for(radar)
  at_goal=False # World/catalogue arrival alone does not prove icon proximity.
  error=None;distance=0
  if marker is not None:
   scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
   distance=math.hypot(marker.x-radar.center[0],marker.y-radar.center[1])/scale
   if self.best is None or distance<self.best-1:self.best=distance;self.stalls=0
   if radar.heading is not None and radar.confidence>=.30:
    bearing=math.degrees(math.atan2(marker.x-radar.center[0],radar.center[1]-marker.y))%360
    error=angle_delta(bearing,radar.heading)
  if (not at_goal and marker is not None and distance>5 and error is not None
      and abs(error)<=18 and self.adjust_steps<5 and self.walked<self.walk_limit and self.stalls<3):
   self.authorized_until=now+.45
   return Drive(forward=.5,lifetime=min(.45,self.walk_limit-self.walked),tilted_motion=True,local_approach=True,
                reason='MAP_FINAL_CLOSE: после полного осмотра коротко подхожу по свежей отметке')
  if self.adjust_turns<3:
   side=1 if error is None or error>=0 else -1
   if not self.adjust_side:self.adjust_side=side
   # Stop on overshoot or cone jitter; never alternate left/right commands.
   if self.adjust_turns and error is not None and (side!=self.adjust_side or abs(error)<=18):
    self._restart_sky(now)
   elif error is None or abs(error)>18 or at_goal:
    return Drive(yaw=.30*self.adjust_side,lifetime=.18,yaw_lifetime=.18,local_approach=True,
                 reason='MAP_ETHER_SECTOR: один ограниченный поворот перед повторным полным осмотром')
   else:self._restart_sky(now)
  else:self._restart_sky(now)
  return self._ether_plan(radar,now,pitch,working_ms)
 def delivered(self,forward,strafe,yaw,pitch,seconds,now):
  if abs(forward)+abs(strafe)+abs(yaw)+abs(pitch)<=.001:return
  if abs(forward)+abs(strafe)>.001:
   self.walked+=seconds;self.stalls+=1
   if self.sky is not None:
    self.adjust_steps+=1;self.close_steps+=1
  if abs(yaw)>.001:
   self.turns+=seconds;self.heading_search+=1
   if self.sky is not None:self.adjust_turns+=1
  self.last_sent=now;self.next_action=now+seconds+.20
