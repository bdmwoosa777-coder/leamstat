"""Built-in Altgard terrain -> current M-map. No user landmark calibration."""
from pathlib import Path
import math,hashlib,time
import cv2,numpy as np
from map_reference import ArrowLocator,arrow_mask,transform

ROOT=Path(__file__).resolve().parent

class AtlasRegistration:
 def __init__(self,image):
  self.image=image;self.features=cv2.SIFT_create(nfeatures=10000,contrastThreshold=.025)
  self.matcher=cv2.FlannBasedMatcher(dict(algorithm=1,trees=4),dict(checks=48));self.reference=None;self.last=None;self.reason='ожидание карты';self.arrow_after=0
  path=ROOT/'assets/atlas/altgard_features.npz'
  if path.is_file():
   with np.load(path,allow_pickle=False) as data:
    if str(data['image_sha256'])==hashlib.sha256((ROOT/'assets/atlas/altgard_reference.jpg').read_bytes()).hexdigest():
     points=data['points'];descriptors=data['descriptors']
     if points.ndim==2 and points.shape[1]==2 and descriptors.shape==(len(points),128) and len(points)>=25:
      self.reference=([cv2.KeyPoint(float(x),float(y),1) for x,y in points],descriptors.astype(np.float32))
  mask=cv2.imread(str(ROOT/'assets/player_arrow_mask.png'),0);ys,xs=np.where(mask>128)
  tight=mask[ys.min():ys.max()+1,xs.min():xs.max()+1];side=max(tight.shape)+8
  square=np.zeros((side,side),np.uint8);y=(side-tight.shape[0])//2;x=(side-tight.shape[1])//2
  square[y:y+tight.shape[0],x:x+tight.shape[1]]=tight
  self.arrow=ArrowLocator(cv2.resize(square,(64,64)))
 @staticmethod
 def gray(image):return cv2.createCLAHE(2,(8,8)).apply(cv2.cvtColor(image,cv2.COLOR_BGR2GRAY))
 def terrain(self,crop):
  if self.last is not None and crop.shape==self.last['frame'].shape and np.array_equal(crop,self.last['frame']):return self.last['registration']
  if self.reference is None:self.reference=self.features.detectAndCompute(self.gray(self.image),None)
  a,da=self.reference;b,db=self.features.detectAndCompute(self.gray(crop),None)
  if da is None or db is None or len(b)<25:return None
  matches=[p[0] for p in self.matcher.knnMatch(da,db,k=2) if len(p)==2 and p[0].distance<.68*p[1].distance]
  if len(matches)<25:return None
  source=np.float32([a[m.queryIdx].pt for m in matches]);target=np.float32([b[m.trainIdx].pt for m in matches])
  h,mask=cv2.findHomography(source,target,cv2.RANSAC,3.5)
  if h is None or mask is None:return None
  good=mask.ravel()>0;n=int(good.sum())
  if n<20 or n/len(matches)<.55:return None
  h=h/h[2,2];scale=(h[0,0]+h[1,1])/2
  if not .05<scale<12 or abs(h[0,0]-h[1,1])>scale*.08 or abs(h[0,1])+abs(h[1,0])>scale*.08 or abs(h[2,0])+abs(h[2,1])>3e-5:return None
  spread=np.ptp(target[good],axis=0);height,width=crop.shape[:2]
  if spread[0]<min(200,width*.22) or spread[1]<min(120,height*.18):return None
  if cv2.contourArea(cv2.convexHull(target[good]))<width*height*.025:return None
  # Positive north-up similarity fitted on homography inliers prevents a
  # projective error from growing at a resource outside the matching landmarks.
  s=source[good];t=target[good];sc=s.mean(axis=0);tc=t.mean(axis=0);v=s-sc;u=t-tc
  k=float(np.sum(v*u)/np.sum(v*v));offset=tc-k*sc
  error=np.linalg.norm(s*k+offset-t,axis=1)
  if np.median(error)>2.5 or np.quantile(error,.9)>5:return None
  result=dict(matrix=np.array([[k,0,offset[0]],[0,k,offset[1]],[0,0,1]],float),inliers=n,error_px=float(np.median(error)),p90_error_px=float(np.quantile(error,.9)))
  self.last={'frame':crop.copy(),'registration':result};return result
 def player(self,crop,frame_width):
  mask=arrow_mask(crop);count,labels,stats,centers=cv2.connectedComponentsWithStats(mask)
  candidates=[];unit=frame_width/2048
  for x,y,w,h,area in stats[1:]:
   if not (14*unit<=max(w,h)<=115*unit and min(w,h)>=10*unit and area>=45*unit*unit and .35<w/h<2.8):continue
   size=max(w,h)*1.3
   found=self.arrow.locate(crop,size,near=(x+w/2,y+h/2),threshold=.59)
   if found:candidates.append(found)
  if not candidates:return None
  candidates.sort(reverse=True);best=candidates[0]
  if any(math.dist(p[1:3],best[1:3])>20*unit and best[0]-p[0]<.055 for p in candidates[1:]):return None
  return best
 def register(self,frame,centered=False):
  height,width=frame.shape[:2];x0,y0,x1,y1=round(width*.225),round(height*.115),round(width*.965),round(height*.91)
  crop=frame[y0:y1,x0:x1]
  if not crop.size:return None
  self.reason='недостаточно надёжных совпадений рельефа Альтгарда'
  registration=self.terrain(crop)
  if registration is None:return None
  m=np.array([[1,0,x0],[0,1,y0],[0,0,1]],float)@registration['matrix']
  result=dict(matrix=m,position=None,viewport=(x0,y0,x1,y1),arrow_rotation=None,inliers=registration['inliers'],arrow_score=None,position_source='unknown',registration_error_px=registration.get('error_px'),frame_size=(width,height))
  if centered:
   # A map opened by this controller centres the character in the GAME
   # WINDOW, including the left list. Its cursor can cover the player arrow.
   # The map terrain must still register at its current zoom and translation.
   center=(width/2,height/2);position=transform(center,np.linalg.inv(m))
   if not (0<=position[0]<self.image.shape[1] and 0<=position[1]<self.image.shape[0]):return None
   self.reason='рельеф подтверждён; персонаж в центре только что открытой карты'
   result.update(position=position,position_source='map_open_center',screen_center=center)
   return result
  # Resource XYZ can be projected through the terrain transform even when
  # the optional character-arrow detector fails. Never invent own coordinates.
  self.reason='рельеф подтверждён; стрелка не обязательна для точки ресурса'
  if time.monotonic()<self.arrow_after:return result
  arrow=self.player(crop,width)
  if arrow is None:self.arrow_after=time.monotonic()+10;return result
  score,px,py,angle=arrow;position=transform((px+x0,py+y0),np.linalg.inv(m))
  if not (0<=position[0]<self.image.shape[1] and 0<=position[1]<self.image.shape[0]):return result
  self.reason='готово'
  result.update(position=position,arrow_rotation=angle,arrow_score=score,position_source='player_arrow')
  return result
