# Исследование источников координат AION2 — v54

## Разбор открытых проектов

Поиск охватывал GitHub и первичные страницы проектов по AION2, radar,
minimap, position, coordinates, map overlay. Форки одинакового кода не
считались отдельными способами. Это перечень проверенных реализаций,
а не утверждение, что найдены абсолютно все существующие программы.

| Проект и проверенные файлы | Что в исходниках | Как используется / ограничение |
|---|---|---|
| [SkeeveAN/Aion-DPS-Meter: calibration.json](https://github.com/SkeeveAN/Aion-DPS-Meter/blob/main/Tools/aion2-maps/calibration.json), [position-frames.md](https://github.com/SkeeveAN/Aion-DPS-Meter/blob/main/docs/protocol/position-frames.md) | Серверные позиции, события, спавны, статический каталог и преобразование world→map. Для Альтгарда прямо указана приблизительная калибровка с остатком до 6 пикселей на обзоре 1024 — около 50 м. | Это источник прежних коэффициентов. Нельзя выдавать прибытие к такой проекции за близость к реальному ресурсу. Старый каталог остаётся запасным ориентиром. |
| [dr89mh/CubeRadar: PositionMessages.cs](https://github.com/dr89mh/aion2-cube-radar/blob/main/src/CubeRadar.Core/Protocol/PositionMessages.cs), [FINDINGS.md](https://github.com/dr89mh/aion2-cube-radar/blob/main/docs/FINDINGS.md) | Npcap, разбор входящих сообщений, ID сущностей, XYZ, возраст позиции; координаты приходят по событиям. Есть отдельная приблизительная оценка по появлению объектов. Чтение конуса миникарты даёт направление камеры, не непрерывную абсолютную XYZ. | Возраст и ID обязательны. Имеющийся сетевой модуль сохранён; свежая позиция теперь может корректировать смещение проекции. Дублирующий CubeRadar не требуется. |
| [Carchutin19/Aion-2-Helper: ClientPosition.cs](https://github.com/Carchutin19/Aion-2-Helper/blob/main/src/ClientPosition.cs) | Отдельный путь декодирования исходящего движения с ключом сессии, получаемым из памяти клиента. | Это действительно иной источник координат, но не просто ещё один пассивный Npcap-парсер. Чтение памяти и этот модуль в v54 не добавлены. |
| [NoRhythmDEV/aion2-map-overlay: MinimapTracker.cs](https://github.com/NoRhythmDEV/aion2-map-overlay/blob/main/src/Aion2MapOverlay.Vision/MinimapTracker.cs), [TerrainTracker.cs](https://github.com/NoRhythmDEV/aion2-map-overlay/blob/main/src/Aion2MapOverlay.Vision/TerrainTracker.cs) | SIFT миникарты/эталона, RANSAC, проверки масштаба, поворота, разброса совпадений и ошибки. Отдельное преобразование эталон→открытая карта. Показанная конфигурация данных ориентирована на Вертерон. | Полезна сама цепочка mini→reference→M. В v54 написана независимая реализация для уже встроенного Альтгарда; чужой код не скопирован. |
| [problem-xyz/aion2-map-overlay: tracker.py](https://github.com/problem-xyz/aion2-map-overlay/blob/main/src/map_overlay/vision/tracker.py), [features.py](https://github.com/problem-xyz/aion2-map-overlay/blob/main/src/map_overlay/vision/features.py), [flow.py](https://github.com/problem-xyz/aion2-map-overlay/blob/main/src/map_overlay/vision/flow.py) | Глобальный/локальный поиск, распределение признаков по областям, SIFT/ORB, RANSAC и оптический поток между повторными привязками. Учитывается разница разрешения детального эталона и координатной плоскости. | Использованы принципы локального поиска и периодической абсолютной перепроверки. Нельзя смешивать пиксели разных размеров карты. |
| [allenOuYang/ai2_autu_story: player_pose.py](https://github.com/allenOuYang/ai2_autu_story/blob/main/vision/player_pose.py) | Разделены относительное перемещение миникарты, положение на карте, направление персонажа и камеры. Есть SIFT и DenseGlobalMapLocalizer: высокочастотная текстура, несколько масштабов, сравнение конкурирующих мест, подтверждение следующим кадром. | Эти принципы полезны там, где SIFT мало. В v54 есть собственный локальный поиск по текстуре с проверкой альтернатив; система координат KINA напрямую не подмешивается к сетевой XYZ. |
| [Fulgrim92/aion2-map-and-quest: position_tracker.py](https://github.com/Fulgrim92/aion2-map-and-quest/blob/main/app/core/position_tracker.py), [POSITION_TRACKING.md](https://github.com/Fulgrim92/aion2-map-and-quest/blob/main/docs/POSITION_TRACKING.md) | SIFT/ORB, маски UI, гомография, сопровождение от кадра к кадру и повторное подтверждение больших скачков. Положение задано на изображении маршрута. | Подтверждает применимость локализации по экрану; координаты изображения не равны сетевой XYZ автоматически. |
| [hnomkeng/Aion2MapOverlay: RobustMapMatcher.cs](https://github.com/hnomkeng/Aion2MapOverlay/blob/main/RobustMapMatcher.cs) | Ещё одна реализация визуального совмещения карты и преобразования координат. | Дополнительное сравнение геометрических проверок; не новый источник живых спавнов. |
| [arkive-games/arkive: worldmap.py](https://github.com/arkive-games/arkive/blob/master/tools/apps/aion2/tools/maps/worldmap.py), [transform.py](https://github.com/arkive-games/arkive/blob/master/tools/apps/aion2/tools/maps/transform.py) | Преобразование через WorldBoundBox, SectorSize и SectorPlaneSize из экспортированных данных клиента, с явным выбором осей и отражений. | Предпочтительнее приблизительных коэффициентов, если доступны проверенные метаданные именно нужной карты/версии. Публичного подтверждённого набора этих параметров для нашего Альтгарда здесь не получено; новые константы не угаданы. |
| [sam-t-anderson/Aion-2-tools: radar.py](https://github.com/sam-t-anderson/Aion-2-tools/blob/main/aion2calc/app/radar.py) | Звуковой поиск кубов: образцы, спектр, громкость и стереопанорама. | Не даёт точную XYZ эфира и не подходит для точного клика по ресурсу. |
| [ycswe/aion2-minimap-overlay](https://github.com/ycswe/aion2-minimap-overlay/blob/main/minimap_overlay.py) | Захват и показ миникарты, обнаружение красных точек. | Сам по себе не является абсолютным локализатором. |

[filvoch/AionCoreUpdate](https://github.com/filvoch/AionCoreUpdate) проверен
как репозиторий распространения: в просмотренном дереве нет исходного
кода реализации. Аналогично, открытый репозиторий
[Aion2-QoL](https://github.com/CrackedNamless/Aion2-QoL) не следует
автоматически считать открытым исходным кодом его локализатора.
Публичные исходники локализации [RiftMeter](https://aion2.gg/riftmeter)
при этом поиске не найдены. Его заявленные 0,1 с/30 Гц не считаются
измеренной характеристикой нашего бота.

### Вывод для бота

Одного увеличения карты недостаточно: зум не исправляет неверное
преобразование XYZ→пиксели. Цель текущего исправления — переносить
видимую иконку mini→эталон→M, проверять положение свежей сетью и уникальной
геометрией ресурсов, а при потере уверенности не выдумывать точный GPS.
Нужные идеи реализованы самостоятельно на уже имеющемся OpenCV;
чужой код с отсутствующей/несовместимой лицензией в патч не встроен.
