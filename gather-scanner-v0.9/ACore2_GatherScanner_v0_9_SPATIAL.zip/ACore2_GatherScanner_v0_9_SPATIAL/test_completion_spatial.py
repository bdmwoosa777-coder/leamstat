"""Regressions: depleted ether, slow OCR, fresh coordinates and isolation."""
import struct
import time
import unittest
from unittest.mock import patch
from network_state import Flow,Node,Telemetry
from spatial import Atlas,geometry
from test_network_control import Source
from test_navigation import GatherFixture,obs,radar
from flight import FlightReading
import gather_engine as ge


class CompletionTests(GatherFixture,unittest.TestCase):
    def selected(self,used=3):
        self.source=Source();self.e.network=self.source
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode='GATHER';self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
        self.e.collecting_visible=True;self.e.f_on=True;self.e.f_renewed_at=100
        self.e.network_target=(1,99);self.e.network_claimed_at=900
        self.source.state.nodes[99].used=used;self.source.state.nodes[99].gather_time=1000

    def test_depletion_needs_no_frame_or_ocr_to_authorize_fold(self):
        self.selected();self.e.network_exhausted=True
        with patch.object(self.e.screen,'frame',side_effect=AssertionError('must not capture')):
            self.assertTrue(self.e._wing_action_allowed('END_AIR'))

    def test_last_attempt_releases_stale_collection_lock_without_ocr(self):
        self.selected()
        with patch.object(ge,'selected_target',side_effect=AssertionError('slow OCR must not run')):
            self.assertTrue(self.e._net_resource(self.frame,FlightReading(70,True),100))
        self.assertEqual(self.commands,['END_AIR'])
        self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.collecting_visible)
        self.assertFalse(self.e.resource_hold);self.assertFalse(self.e.f_on)
        self.assertIsNotNone(self.e.wing_close_pending)

    def test_one_and_two_remaining_never_fold(self):
        for used in (1,2):
            self.selected(used)
            self.assertFalse(self.e._net_resource(self.frame,FlightReading(70,True),100))
            self.assertEqual(self.e.mode,'GATHER')
        self.assertNotIn('END_AIR',self.commands)

    def test_repeat_lease_is_renewed_only_after_own_start(self):
        self.selected(1)
        with patch.object(ge.time,'monotonic',return_value=104):self.assertTrue(self.e.f_enable())
        self.assertEqual(self.commands,['F_ON'])
        with patch.object(ge.time,'monotonic',return_value=104.5):self.assertTrue(self.e.f_enable())
        self.assertEqual(self.commands,['F_ON'])
        self.source.state.selected=777
        with patch.object(ge.time,'monotonic',return_value=108):self.e.f_enable()
        self.assertEqual(self.commands,['F_ON'])

    def test_no_repeat_while_native_approach_has_not_started_gather(self):
        self.selected(0);self.source.state.nodes[99].gather_time=None
        self.e.real_gather_panel_seen=False;self.e.fast_gather_seen=False;self.e.f_on=False
        self.e.mode='APPROACH';self.e.route_f_sent=True
        with patch.object(ge.time,'monotonic',return_value=104):self.e.f_enable()
        self.assertEqual(self.commands,[])

    def test_missing_or_old_ocr_does_not_stop_free_patrol(self):
        for snapshot in (None,(obs(),1,1,2)):
            result=self.e._navigation_observation(snapshot,100)
            self.assertIsNotNone(result);self.assertIsNone(result[0].candidate)

    def test_ocr_fallback_cannot_move_during_unbound_own_gather(self):
        self.e.network=Source()
        self.assertIsNone(self.e._navigation_observation(None,100))

    def test_ocr_fallback_cannot_change_target_or_route(self):
        for mode in ('APPROACH','GATHER','REACQUIRE','ACQUIRE_WAIT'):
            self.e.mode=mode
            self.assertIsNone(self.e._navigation_observation(None,100))

    def test_intermittent_arc_has_absolute_close_deadline(self):
        self.e.wing_close_pending=100;self.e.wing_close_started=100
        self.e._service_wing_close(FlightReading(None,False),105.9)
        with patch.object(self.e,'stop') as stop:
            self.assertTrue(self.e._service_wing_close(FlightReading(70,True),106.1))
        stop.assert_called_once();self.assertEqual(self.commands,[])

    def test_explicit_false_send_is_not_reported_as_success(self):
        self.e.bridge.send=lambda command:False
        self.assertFalse(self.e.bridge_cmd('END_AIR'))


class SpatialTests(unittest.TestCase):
    def setUp(self):
        self.f=Flow(own=7,map_id=1110,xyz=(10000,20000,3000),position_at=1000,position_source='zone-spawn')
        self.node=Node(99,1550020,(10000,19000,5000),used=1)

    def test_height_and_north_up_bearing_use_correct_units(self):
        r=geometry(self.f,self.node,1100)
        self.assertEqual(r['planar_m'],10);self.assertEqual(r['height_m'],20)
        self.assertEqual(r['bearing'],0);self.assertAlmostEqual(r['distance_m'],500**.5)
        self.node.xyz=(11000,20000,2000);r=geometry(self.f,self.node,1100)
        self.assertEqual(r['bearing'],90);self.assertEqual(r['height_m'],-10)

    def test_stale_future_unknown_and_exhausted_positions_cannot_guide(self):
        self.assertIsNone(geometry(self.f,self.node,1900))
        self.assertIsNone(geometry(self.f,self.node,500))
        self.f.own=None;self.assertIsNone(geometry(self.f,self.node,1100))
        self.f.own=7;self.node.used=3;self.assertIsNone(geometry(self.f,self.node,1100))

    def test_zone_spawn_carries_own_xyz(self):
        t=Telemetry();b=bytearray(46);struct.pack_into('<I',b,4,1110)
        struct.pack_into('<fff',b,16,10000,20000,3000)
        t.feed(1,'2136',bytes(b),1000);f=t.flows[1]
        self.assertEqual(f.xyz,(10000,20000,3000));self.assertEqual(f.position_at,1000)
        self.assertEqual(f.position_source,'zone-spawn');self.assertEqual(f.map_id,1110)

    def test_own_teleport_zero_marker_is_required(self):
        t=Telemetry();t.flows[1]=self.f
        b=bytes(6)+struct.pack('<fff',15000,25000,6000)
        t.feed(1,'2336',b,1200);self.assertEqual(self.f.xyz,(15000,25000,6000))
        t.feed(1,'2336',b'\x01'+b[1:],1300)
        self.assertEqual(self.f.position_at,1200)

    def test_other_movement_and_energy_are_not_own_coordinates(self):
        t=Telemetry();t.flows[1]=self.f
        for op in ('1a37','1b37','1c37','0238','4637'):
            t.feed(1,op,b'\x08\x03'+struct.pack('<fff',50000,50000,50000),1100)
        self.assertEqual(self.f.xyz,(10000,20000,3000));self.assertEqual(self.f.position_at,1000)

    def test_invalid_new_zone_cannot_retain_previous_map_position(self):
        t=Telemetry();t.flows[1]=self.f;b=bytearray(46)
        struct.pack_into('<I',b,4,1010);struct.pack_into('<fff',b,16,float('nan'),20000,3000)
        t.feed(1,'2136',bytes(b),1200)
        self.assertIsNone(self.f.xyz);self.assertEqual(self.f.map_id,1010)

    def test_atlas_is_map_scoped_and_static_is_never_live(self):
        atlas=Atlas();self.assertEqual(atlas.map_for_zone(1110),'altgard')
        point=atlas.points[atlas.maps['altgard']['table']]['1550020'][0]
        rows=atlas.nearest(1110,point,{1550020},1)
        self.assertEqual(rows[0]['name'],'Сапфир');self.assertEqual(rows[0]['planar_m'],0)
        self.assertFalse(rows[0]['live']);self.assertEqual(atlas.nearest(999999,point),[])
        self.assertEqual(atlas.nearest(1010,point,{1550020}),[])

    def test_fast_snapshot_isolates_every_mutable_decoder_container(self):
        self.f.nodes[99]=self.node;self.f.npcs[55]={'hp':100,'xyz':(1,2,3)}
        self.f.identity_interactions[99]={7:100};self.f.falls=[(100,5)]
        snap=self.f.snapshot();self.f.nodes[99].used=3;self.f.npcs[55]['hp']=1
        self.f.identity_interactions[99][7]=200;self.f.falls.append((200,10))
        self.assertEqual(snap.nodes[99].used,1);self.assertEqual(snap.npcs[55]['hp'],100)
        self.assertEqual(snap.identity_interactions[99][7],100);self.assertEqual(snap.falls,[(100,5)])


class SpatialRouteTests(GatherFixture,unittest.TestCase):
    def test_fresh_live_bearing_is_revoked_immediately_when_position_ages(self):
        self.e.network=Source();self.e.network.atlas=Atlas()
        f=self.e.network.state;f.xyz=(10000,20000,3000);f.position_at=1000
        f.nodes[99].xyz=(11000,20000,3000)
        with patch.object(ge.time,'time',return_value=1.1):self.e._spatial_route(radar())
        self.assertEqual(self.e.nav.route_bearing,90)
        with patch.object(ge.time,'time',return_value=2):self.e._spatial_route(radar())
        self.assertIsNone(self.e.nav.route_bearing)

    def test_expired_spatial_route_cannot_clear_a_new_world_map_route(self):
        self.e.spatial_route_active=True;self.e.nav.route(180,'курс по большой карте')
        self.e._spatial_route(radar())
        self.assertEqual(self.e.nav.route_bearing,180)

    def test_far_nodes_cannot_guide_after_teleport(self):
        self.e.network=Source();self.e.network.atlas=Atlas()
        f=self.e.network.state;f.xyz=(10000,20000,3000);f.position_at=1000
        f.nodes[99].xyz=(90000,20000,3000)
        with patch.object(ge.time,'time',return_value=1.1):self.e._spatial_route(radar())
        self.assertIsNone(self.e.nav.route_bearing)


if __name__=='__main__':unittest.main()
