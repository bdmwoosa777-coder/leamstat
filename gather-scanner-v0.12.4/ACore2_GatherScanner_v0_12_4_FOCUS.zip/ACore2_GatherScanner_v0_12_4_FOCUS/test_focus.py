"""Settled sight checks, six-step first look and feedback-limited map scrolling."""
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from http.server import HTTPServer,BaseHTTPRequestHandler
import json,tempfile,threading,unittest
import cv2,numpy as np
import app,vision,hybrid_engine as he,hybrid_navigation as hn
from navigation import Navigator,Drive
from hybrid_engine import HybridGatherEngine
from hybrid_navigation import HybridPlanner,RouteClient,RouteAdvisor
from gamepad_input import GamepadInput
from map_teleport import MapTeleport,MapObservation,Line,observe,DEFAULT_DESTINATION
from flight import FlightReading
from minimap import Marker
from test_navigation import GatherFixture,radar,obs
from test_network_control import Source
from test_sight import glyph_frame
from test_hybrid import scene,FRAME,CTX
from test_xbox_bridge import Reports

NAME='Рабочий лагерь стального молота'

class TopWorldSight(unittest.TestCase):
 def test_top_central_world_caption_is_not_masked_when_no_target_bar_exists(self):
  f=glyph_frame(.48,.08);self.assertFalse(vision.resource_header_visible(f))
  candidates=vision.fast_ether_candidates(f)
  self.assertTrue(candidates);self.assertLess(candidates[0].box[1],f.shape[0]*.115)
 def test_visible_target_bar_keeps_its_own_title_excluded(self):
  f=glyph_frame(.48,.08);h,w=f.shape[:2];y=round(h*.061)
  cv2.rectangle(f,(round(w*.41),y-3),(round(w*.59),y+10),(15,15,15),-1)
  cv2.rectangle(f,(round(w*.415),y),(round(w*.585),y+4),(100,180,70),-1)
  self.assertTrue(vision.resource_header_visible(f));self.assertEqual(vision.fast_ether_candidates(f),[])
 def test_top_region_fast_pass_uses_original_coordinates_and_current_glyph(self):
  f=glyph_frame(.48,.08);h,w=f.shape[:2]
  found=vision.fast_ether_candidates(f,bounds=(round(w*.02),round(h*.02),round(w*.98),round(h*.55)))
  self.assertTrue(found);self.assertAlmostEqual(found[0].box[0],w*.48,delta=5)
  self.assertIsNotNone(vision.find_resource_near(f,found[0]))

class SixStepSearch(unittest.TestCase):
 def test_outer_scan_has_six_up_steps_then_stationary_hold_before_down(self):
  n=Navigator({'air_search_wide':True,'air_search_map_radius':30});r=radar([Marker('Эфир',115,100,.9,15,'aether')])
  t=100;plans=[];d=n.update(r,t)
  for _ in range(13):
   plans.append(d);t=n.scan_next_at+.001;d=n.update(r,t)
  self.assertTrue(all(p.pitch>.4 for p in plans[:6]));self.assertEqual(plans[6].pitch,0)
  self.assertGreaterEqual(plans[6].lifetime,.75);self.assertTrue(all(p.pitch<-.4 for p in plans[7:]))
  self.assertAlmostEqual(sum(p.pitch*p.lifetime for p in plans),0);self.assertTrue(d.restore_pitch);self.assertFalse(d.flight_probe)
 def test_close_marker_behind_camera_is_faced_before_any_vertical_scan(self):
  n=Navigator({});r=radar([Marker('Эфир',108,100,.9,8,'aether')],heading=270)
  d=n.update(r,100);self.assertEqual(d.pitch,0);self.assertNotEqual(d.yaw,0)
  self.assertEqual((d.forward,d.strafe),(0,0));self.assertIsNone(n.air_since)

class SightController(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();bridge=self.e.bridge;screen=self.e.screen
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  cfg={**self.e.cfg,'hybrid_camp_exit':False,'analyzer_enabled':False,'auto_view_recovery':False,'scan_frame_checks':True}
  self.e=HybridGatherEngine(cfg,self.log.append,self.input,network=self.source);self.e.bridge=bridge;self.e.screen=screen
  self.e.mode='SEARCH';self.e.target=None;self.clock=100
  self.timer=patch.object(he.time,'monotonic',side_effect=lambda:self.clock);self.timer.start();self.addCleanup(self.timer.stop)
  self.frame=glyph_frame(.48,.08);self.e.current_size=(self.frame.shape[1],self.frame.shape[0])
 def prepare_scan(self):
  self.e.nav=Navigator({'air_search_wide':True,'air_search_map_radius':30})
  self.e.nav.update(radar([Marker('Эфир',115,100,.9,15,'aether')]),99)
  self.e.nav.scan_last_pulse=5;self.e.nav.scan_pulse_end=99.9;self.e.nav.scan_next_at=99.9
 def test_current_visible_caption_interrupts_before_next_down_pulse_even_with_empty_background_ocr(self):
  self.prepare_scan();self.e.step(self.frame,(0,0),obs(),radar(),FlightReading(80,False),100,1)
  self.assertEqual(self.e.mode,'ACQUIRE_WAIT');self.assertIsNotNone(self.e.caption_latch)
  self.assertEqual(self.e.nav.scan_last_pulse,5);self.assertEqual(self.pad.axes,(0,0,0,0))
  self.assertEqual(self.pad.presses,0);self.assertNotIn('V',self.commands)
 def test_fresh_sight_reaches_click_on_next_frame_without_waiting_for_ocr_worker(self):
  self.prepare_scan();self.e.step(self.frame,(0,0),obs(),radar(),FlightReading(80,False),100,1);self.clock=100.3
  with patch.object(self.e,'click_candidate',return_value=True) as click:
   self.e.step(self.frame,(0,0),obs(),radar(),FlightReading(80,False),100.3,2)
  click.assert_called_once();self.assertEqual(click.call_args.args[0].name,'Эфир')
 def test_owned_collection_still_blocks_fast_sight_and_all_camera_input(self):
  self.prepare_scan();self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
  with patch.object(he,'fast_ether_candidates',side_effect=AssertionError('search during owned gather')):
   with patch.object(self.e,'_resource_fast_tick',return_value=True):self.e.step(self.frame,(0,0),obs(),radar(),FlightReading(80,True),100,1)
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertIsNone(self.e.caption_latch)
 def test_visual_route_planner_cannot_turn_a_scan_pause_into_walking(self):
  self.e.scene_host=SimpleNamespace(offer=lambda *a:None,current=lambda *a:scene())
  for d in (Drive(reason='выдерживаю ракурс'),Drive(yaw=.4,lifetime=.1)):
   result=self.e._scene_plan(self.frame,radar(),FlightReading(80,False),d,100)
   self.assertEqual((result.forward,result.strafe),(0,0));self.assertEqual(result.yaw,d.yaw)

class SlowNativeScroll(unittest.TestCase):
 def test_scroll_is_a_small_bounded_pulse_and_overshoot_scale_shortens_it(self):
  p=Reports();g=GamepadInput(factory=lambda:p,a_button=0x1000);g.motion_worker=object();durations=[]
  try:
   for scale,expected in ((1,.09),(.5,.045)):
    p.reports=[];g.map_scroll_factor=scale
    with patch.object(g,'wait',side_effect=lambda seconds,*args:durations.append(seconds) or True):
     self.assertTrue(g.scroll_map_list(-1,threading.Event(),lambda:True,lambda:True))
    moving=[axes[3] for b,lt,axes in p.reports if axes[3]];self.assertEqual(moving,[-.3]);self.assertAlmostEqual(durations[-1],expected)
    self.assertEqual(p.axes,(0,0,0,0));self.assertEqual(p.lt,0);self.assertEqual(p.buttons,0)
  finally:g.close()
 def test_interrupted_scroll_cannot_leave_trigger_or_stick_held(self):
  p=Reports();g=GamepadInput(factory=lambda:p,a_button=0x1000);g.motion_worker=object();stop=threading.Event()
  try:
   def wait(*args):stop.set();return False
   with patch.object(g,'wait',side_effect=wait):self.assertFalse(g.scroll_map_list(1,stop,lambda:True,lambda:True))
   self.assertEqual(p.axes,(0,0,0,0));self.assertEqual(p.lt,0)
  finally:g.close()

class MapFeedback(unittest.TestCase):
 def test_defaults_use_current_chosen_camp_and_can_be_overridden(self):
  self.assertEqual(DEFAULT_DESTINATION,NAME);self.assertEqual(MapTeleport(0).index,48)
  self.assertEqual(app.DEFAULT['map_return_destination'],NAME)
  self.assertEqual(MapTeleport(0,'Другой лагерь',7).destination,'Другой лагерь')
 def test_visible_target_page_is_read_again_instead_of_scrolled_past(self):
  m=MapTeleport(0);o=MapObservation(True,list_first=40,list_last=50)
  self.assertEqual(m.step(0,o).kind,'WAIT');self.assertEqual(m.scrolls,0)
  self.assertEqual(m.step(1,replace(o,row=(100,500))).kind,'ROW')
 def test_crossing_target_index_reduces_the_return_scroll(self):
  m=MapTeleport(0);a=m.step(0,MapObservation(True,list_first=20,list_last=30,list_signature=np.zeros((24,40))))
  self.assertEqual((a.direction,a.scroll_scale),(-1,1))
  b=m.step(1,MapObservation(True,list_first=60,list_last=70,list_signature=np.full((24,40),50)))
  self.assertEqual(b.direction,1);self.assertEqual(b.scroll_scale,.5)
 def test_truncated_indexed_row_only_selects_it_does_not_authorize_teleport(self):
  import map_teleport as mt
  row=Line('48. Рабочий лагерь стальн...', (20,500,220,20))
  with patch.object(mt,'is_map',return_value=True),patch.object(mt,'confirmation_dialog',return_value=None),patch.object(mt,'lines',side_effect=lambda f,region,*a,**kw:[row] if region[0]==0 else []):
   o=observe(np.full((720,1280,3),35,np.uint8),NAME,'FIND',index=48)
  self.assertEqual(o.row,row.point);self.assertFalse(o.popup);self.assertIsNone(o.confirm)
 def test_truncated_popup_title_needs_full_matching_destination_in_description(self):
  import map_teleport as mt
  f=np.full((720,1280,3),35,np.uint8);f[445:495,1107:1268]=(20,180,230)
  for correct in (True,False):
   text='Рабочий лагерь стального молота' if correct else 'Временный приют'
   popup=[Line('Рабочий лагерь стальн...', (990,290,250,20)),Line('Активирован',(990,325,100,15)),Line(text,(990,385,260,45)),Line('Переместиться',(975,460,120,20))]
   with patch.object(mt,'is_map',return_value=True),patch.object(mt,'confirmation_dialog',return_value=None),patch.object(mt,'lines',side_effect=lambda frame,region,*a,**kw:popup if region[0]==.70 else []):
    o=observe(f,NAME,'WAIT_ROW',index=48)
   self.assertEqual(o.popup,correct);self.assertEqual(o.confirm is not None,correct)
 def test_real_ocr_can_verify_long_destination_in_wrapped_popup_description(self):
  from PIL import Image,ImageDraw,ImageFont
  from test_map_teleport import map_frame,FONT
  f=map_frame(row=False);im=Image.fromarray(cv2.cvtColor(f,cv2.COLOR_BGR2RGB));d=ImageDraw.Draw(im)
  d.rectangle((965,260,1270,520),fill=(24,31,46))
  def text(x,y,s,size=16):d.text((x,y),s,font=ImageFont.truetype(FONT,size),fill=(235,235,235))
  text(980,275,'Рабочий лагерь стальн...',18);text(980,309,'Активирован',15)
  for i,line in enumerate(('Этот кибелиск позволяет','переместиться в рабочий лагерь','стального молота, расположенный','у залежей фафнита.')):text(980,345+i*22,line,15)
  text(974,470,'Переместиться',16);d.rectangle((1120,455,1260,510),fill=(215,165,35));text(1130,469,'F',19)
  result=observe(cv2.cvtColor(np.asarray(im),cv2.COLOR_RGB2BGR),NAME,'WAIT_ROW',index=48)
  self.assertTrue(result.popup);self.assertIsNotNone(result.confirm);self.assertGreater(result.popup_box[3],90)

class ReturnSettings(unittest.TestCase):
 def ui(self,index='48'):
  return SimpleNamespace(root=None,cfg=dict(app.DEFAULT),vars={},backend=SimpleNamespace(get=lambda:'gamepad'),working_ms=SimpleNamespace(get=lambda:'940'),
   return_name=SimpleNamespace(get=lambda:NAME),return_index=SimpleNamespace(get=lambda:index),engine=SimpleNamespace(cfg={}),log=lambda s:None)
 def test_name_and_index_are_saved_and_used_by_next_return_of_running_engine(self):
  ui=self.ui()
  with tempfile.TemporaryDirectory() as tmp,patch.object(app,'CONF',Path(tmp)/'settings.json'):
   self.assertTrue(app.UI.save(ui));saved=json.loads(app.CONF.read_text())
  self.assertEqual(saved['map_return_destination'],NAME);self.assertEqual(ui.engine.cfg['map_return_index'],48)
 def test_invalid_index_is_rejected_before_writing_or_restarting(self):
  ui=self.ui('bad')
  with tempfile.TemporaryDirectory() as tmp,patch.object(app,'CONF',Path(tmp)/'settings.json'),patch.object(app.messagebox,'showerror') as error:
   self.assertFalse(app.UI.save(ui));error.assert_called_once();self.assertFalse(app.CONF.exists())

class AdvisorRecovery(unittest.TestCase):
 def test_empty_chat_can_fall_back_to_generate_without_changing_model_or_locality(self):
  calls=[]
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_POST(self):
    payload=json.loads(self.rfile.read(int(self.headers['Content-Length'])));calls.append((self.path,payload))
    raw=b'' if self.path=='/api/chat' else json.dumps({'response':'{"route_id":2,"scene":"open"}','done':True}).encode()
    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   c=RouteClient('http://127.0.0.1:'+str(server.server_port));answer=c.analyze(FRAME,scene().ground,CTX)
   self.assertEqual(answer['route_id'],2);self.assertEqual([p for p,_ in calls],['/api/chat','/api/generate'])
   self.assertEqual(calls[0][1]['model'],calls[1][1]['model']);self.assertTrue(calls[1][1]['images']);self.assertNotIn('messages',calls[1][1])
  finally:server.shutdown();server.server_close();thread.join()
 def test_repeated_server_failure_backs_off_and_does_not_get_a_gamepad(self):
  clock=[100.];h=RouteAdvisor({'ollama_autostart':False,'hybrid_debug':False},lambda s:None)
  fake=SimpleNamespace(probe=lambda:None,analyze=lambda *args:(_ for _ in ()).throw(ValueError('empty advisor response')))
  with patch.object(hn,'RouteClient',return_value=fake),patch.object(hn.time,'monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   for i in range(3):
    self.assertTrue(h.offer(FRAME,scene().ground,clock[0],90,0,CTX));h.worker.join(1);self.assertFalse(h.busy)
    if i<2:clock[0]+=11
   self.assertGreaterEqual(h.retry_at-clock[0],60);self.assertFalse(h.offer(FRAME,scene().ground,clock[0]+1,90,0,CTX))
  self.assertIsNone(h.latest);self.assertFalse(hasattr(h,'gamepad'));h.close()

if __name__=='__main__':unittest.main()
