"""Probe orchestration with real sender/Lua; hook event parsing off Windows."""
import unittest
from unittest.mock import Mock
from TEST_MAP_CLICK import execute_probe
from click_event_observer import key_record,mouse_record
from test_map_wire47 import Link
from map_mousekeys import Dispatch

class Probe(unittest.TestCase):
 def test_manual_map_one_real_click_and_no_map_or_movement_command(self):
  link=Link();link.map=True;messages=[]
  with link.patch():result=execute_probe(link.tr,lambda:True,messages.append);link.tr.close()
  self.assertEqual(result,dict(ping_ack=True,attempted=True,ack=True));self.assertTrue(link.map);self.assertTrue(link.route)
  downs=[k for t,a,k in link.events if a=='down']
  self.assertEqual(downs.count('num5'),1);self.assertNotIn('m',downs)
  self.assertTrue(set(downs)<={20,145,'capslock','numminus','num5'})
 def test_no_ack_never_sends_click(self):
  link=Link(legacy=True);link.map=True
  with link.patch():result=execute_probe(link.tr,lambda:True,lambda _:None)
  self.assertFalse(result['ping_ack']);self.assertFalse(any(k=='num5' for _,_,k in link.events))
 def test_no_authorization_has_no_input(self):
  link=Link()
  with link.patch():result=execute_probe(link.tr,lambda:False,lambda _:None)
  self.assertFalse(result['attempted']);self.assertEqual(link.events,[])
 def test_uncertain_click_is_not_retried(self):
  transport=Mock();transport.ping.return_value=Dispatch(True,True);transport.click.return_value=Dispatch(True,False,'unknown')
  result=execute_probe(transport,lambda:True,lambda _:None)
  self.assertTrue(result['attempted']);self.assertFalse(result['ack']);transport.click.assert_called_once()
 def test_numlock_off_never_sends_a_key(self):
  link=Link();link.flags[144]=False
  with link.patch():result=execute_probe(link.tr,lambda:True,lambda _:None)
  self.assertFalse(result['attempted']);self.assertFalse(link.flags[144]);self.assertEqual(link.events,[])

class Events(unittest.TestCase):
 def test_right_button_down_and_up_are_distinct(self):
  self.assertEqual(mouse_record(0x204,100,200,1),dict(kind='mouse',action='RIGHT_DOWN',x=100,y=200,flags=1))
  self.assertEqual(mouse_record(0x205,100,200,0)['action'],'RIGHT_UP')
 def test_left_click_is_not_counted_as_right(self):
  self.assertEqual(mouse_record(0x201,1,2,0)['action'],'LEFT_DOWN')
  self.assertEqual(mouse_record(0x202,1,2,0)['action'],'LEFT_UP')
 def test_mouse_motion_is_not_collected(self):self.assertIsNone(mouse_record(0x200,1,2,0))
 def test_numpad_virtual_key_and_clear_variant_are_both_seen(self):
  self.assertEqual(key_record(0x100,0x65,0x4c,16)['key'],'NUM5')
  self.assertEqual(key_record(0x101,0x0c,0x4c,0)['action'],'UP')
 def test_numpad_scan_is_seen_even_with_unexpected_virtual_key(self):
  self.assertEqual(key_record(0x100,0x35,0x4c,0)['key'],'NUM_SCAN')
 def test_ordinary_typing_is_not_collected(self):
  scans=[0x1e,0x30,0x2e,0x20,0x12,0x21,0x22,0x23,0x17,0x24,0x25,0x26,0x32,0x31,0x18,0x19,0x10,0x13,0x1f,0x14,0x16,0x2f,0x11,0x2d,0x15,0x2c]
  for vk,scan in zip(range(0x41,0x5b),scans):self.assertIsNone(key_record(0x100,vk,scan,0))
 def test_numlock_wire_keys_and_flags_are_only_observed(self):
  for vk in (20,144,145):self.assertEqual(key_record(0x104,vk,0,16)['flags'],16)


class ManualTarget(unittest.TestCase):
 def test_focus_cursor_and_window_are_required(self):
  from TEST_MAP_CLICK import manual_target_ready as ready
  bounds=(100,200,1920,1080);p=(1000,500)
  self.assertTrue(ready(True,p,p,bounds,bounds))
  self.assertFalse(ready(False,p,p,bounds,bounds))
  self.assertFalse(ready(True,(1010,500),p,bounds,bounds))
  self.assertFalse(ready(True,p,p,(120,200,1920,1080),bounds))
 def test_outside_client_is_rejected_without_using_map_text(self):
  from TEST_MAP_CLICK import manual_target_ready as ready
  bounds=(100,200,1920,1080)
  self.assertFalse(ready(True,(99,500),(99,500),bounds,bounds))
  self.assertFalse(ready(True,(1000,1300),(1000,1300),bounds,bounds))
 def test_negative_monitor_coordinates_are_valid(self):
  from TEST_MAP_CLICK import manual_target_ready as ready
  bounds=(-1920,0,1920,1080);p=(-1000,500)
  self.assertTrue(ready(True,p,p,bounds,bounds))
 def test_actual_main_sends_one_click_without_reading_an_image(self):
  from unittest.mock import patch
  from types import SimpleNamespace
  from pathlib import Path
  import ctypes,io,tempfile
  import TEST_MAP_CLICK as module
  class Function:
   def __init__(self,fn):self.fn=fn
   def __call__(self,*args):return self.fn(*args)
  def cursor(p):p._obj.x=1000;p._obj.y=500;return True
  dll=SimpleNamespace(GetCursorPos=Function(cursor))
  screen=SimpleNamespace(hwnd=99,title='AION2',pick=lambda:True,focused=lambda:True,
   frame=Mock(side_effect=AssertionError('must not capture/OCR the map')),
   win32gui=SimpleNamespace(ClientToScreen=lambda *a:(0,0),GetClientRect=lambda *a:(0,0,1920,1080)))
  transport=Mock();transport.ping.return_value=Dispatch(True,True,'ping');transport.click.return_value=Dispatch(True,True,'click')
  observer=SimpleNamespace(error=None,events=[],close=lambda:None);observer.start=lambda:observer
  output=io.StringIO();output.reconfigure=lambda **k:None
  with tempfile.TemporaryDirectory() as folder:
   with patch.object(module,'ROOT',Path(folder)),patch.object(module.os,'name','nt'),patch.object(module.time,'sleep'),patch('ctypes.WinDLL',return_value=dll,create=True),patch('screen_capture.ScreenCapture',return_value=screen),patch('map_mousekeys.MapMouseKeys',return_value=transport),patch('click_event_observer.ClickObserver',return_value=observer),patch.object(module.sys,'stdout',output):
    self.assertEqual(module.main(),0)
   text=(Path(folder)/'map_click_probe.log').read_text()
  transport.ping.assert_called_once();transport.click.assert_called_once();screen.frame.assert_not_called()
  self.assertIn('manual_user',text);self.assertIn('CLICK:',text)

if __name__=='__main__':unittest.main()
