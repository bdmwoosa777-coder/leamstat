@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 python TEST_MAP_CLICK.py
) else (
 py -3 TEST_MAP_CLICK.py
)
pause
