"""One PING and one numeric map click, at the user's own cursor. No Xbox."""
from pathlib import Path
import json,os,subprocess,sys,time
ROOT=Path(__file__).resolve().parent

def execute_probe(transport,allowed,emit):
 ping=transport.ping(allowed);emit('PING: '+ping.reason)
 if not ping.acknowledged:return {'ping_ack':False,'attempted':False,'ack':False}
 click=transport.click(allowed);emit('CLICK: '+click.reason)
 return {'ping_ack':True,'attempted':click.attempted,'ack':click.acknowledged}

def manual_target_ready(focused,current,chosen,bounds,initial):
 return bool(focused and bounds==initial and max(abs(a-b) for a,b in zip(current,chosen))<=6
             and bounds[0]<=current[0]<bounds[0]+bounds[2] and bounds[1]<=current[1]<bounds[1]+bounds[3])

def main():
 if os.name!='nt':raise RuntimeError('Этот тест требует Windows')
 from screen_capture import ScreenCapture
 from map_mousekeys import MapMouseKeys
 from click_event_observer import ClickObserver
 import ctypes
 from ctypes import wintypes as wt
 sys.stdout.reconfigure(encoding='utf-8',errors='replace')
 lines=[];tr=None;observer=None;report={}
 def emit(message):
  line=time.strftime('%H:%M:%S')+' '+message;lines.append(line);print(line,flush=True)
 user=ctypes.WinDLL('user32',use_last_error=True)
 user.GetCursorPos.argtypes=[ctypes.POINTER(wt.POINT)];user.GetCursorPos.restype=wt.BOOL
 def point():
  p=wt.POINT()
  if not user.GetCursorPos(ctypes.byref(p)):raise ctypes.WinError(ctypes.get_last_error())
  return p.x,p.y
 try:
  emit('TEST MAP CLICK 2: ручная карта, без OCR; Python -> Lua -> Num-/Num5. Бот закрыт.')
  try:
   ctypes.windll.shcore.SetProcessDpiAwareness(2)
   emit('DPI: запрошены физические координаты, как в основном боте')
  except Exception:emit('DPI: используется уже настроенный режим процесса')
  emit('Lua 47.1 оставить включённым (G9). Num Lock НЕ ТРОГАТЬ.')
  emit('За 8 секунд переключитесь в игру, откройте M и наведите курсор на доступную точку рядом.')
  emit('Карту не закрывайте, курсор после отсчёта не двигайте. Xbox/движение/M тест не отправляет.')
  for left in range(8,0,-1):emit(str(left));time.sleep(1)
  screen=ScreenCapture()
  if not screen.pick() or not screen.focused():raise RuntimeError('AION2 не в фокусе; ввод не отправлен')
  def bounds():
   origin=screen.win32gui.ClientToScreen(screen.hwnd,(0,0))
   left,top,w,h=screen.win32gui.GetClientRect(screen.hwnd)
   return origin[0],origin[1],w-left,h-top
  area=bounds();position=point();x,y=position[0]-area[0],position[1]-area[1]
  if not (0<=x<area[2] and 0<=y<area[3]):raise RuntimeError('Курсор вне клиентской области игры; ввод не отправлен')
  emit('Курсор пользователя: '+str(position)+'; клиент: '+str((x,y))+'; границы='+str(area)+'; окно='+screen.title)
  report.update(point=position,client_point=(x,y),window=screen.title,bounds=area,map_confirmation='manual_user')
  observer=ClickObserver().start()
  emit('Наблюдатель Windows: '+('ошибка: '+observer.error if observer.error else 'запущен; записывает только кнопки мыши и клавиши канала'))
  tr=MapMouseKeys(emit)
  def allowed():
   current=point();current_area=bounds()
   ready=manual_target_ready(screen.focused(),current,position,current_area,area)
   if not ready:report['authorization_failure']=dict(focused=screen.focused(),point=current,bounds=current_area)
   return ready
  report.update(execute_probe(tr,allowed,emit));time.sleep(.7)
  emit('ПЕРЕДАЧА ЗАВЕРШЕНА. Карта оставлена открытой. Теперь можно закрыть её M и проверить путь.')
 except KeyboardInterrupt:emit('Тест прерван пользователем')
 except Exception as exc:report['error']=str(exc);emit('ОШИБКА: '+str(exc))
 finally:
  if tr is not None:
   try:tr.close()
   except Exception as exc:emit('CLOSE: '+str(exc))
  if observer is not None:
   observer.close();report['observer_error']=observer.error;report['events']=list(observer.events)
   for event in observer.events:emit(json.dumps(event,ensure_ascii=False))
   mouse=[e['action'] for e in observer.events if e['kind']=='mouse']
   report['right_down_seen']='RIGHT_DOWN' in mouse;report['right_up_seen']='RIGHT_UP' in mouse
   emit('Windows RIGHT_DOWN / RIGHT_UP: '+str((report['right_down_seen'],report['right_up_seen'])))
  path=ROOT/'map_click_probe.log';path.write_text('\n'.join(lines)+'\nRESULT '+json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
  print('Журнал: '+str(path),flush=True)
 return 0 if report.get('ack') else 1

def bootstrap():
 if '--runtime' in sys.argv:return main()
 from runtime_env import find_runtime
 python=find_runtime(ROOT)
 if python is None:
  print('Общее окружение бота не найдено. Распакуйте тест в папку рабочей v0.12.47 с START.bat.');return 2
 return subprocess.run([str(python),str(Path(__file__).resolve()),'--runtime'],cwd=ROOT).returncode
if __name__=='__main__':raise SystemExit(bootstrap())
