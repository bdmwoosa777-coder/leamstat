import ast,base64,copy,csv,hashlib,io,json,re,threading,time,unittest,zipfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import cv2
from unittest.mock import Mock
from tempfile import TemporaryDirectory
from xbox_combat import XboxCombatBridge,CombatState,Report,RB,RS,A,B
from visual_templates import VisualLibrary

ROOT=Path(__file__).parent

class Pad:
 def __init__(self):self.reports=[];self.fail=False;self.reset()
 def reset(self):self.buttons=0;self.lt=0.;self.rt=0.;self.yaw=0.
 def press_button(self,button):self.buttons|=button
 def release_button(self,button):self.buttons&=~button
 def left_trigger_float(self,value_float):self.lt=value_float
 def right_trigger_float(self,value_float):self.rt=value_float
 def right_joystick_float(self,x_value_float,y_value_float):self.yaw=x_value_float;assert y_value_float==0
 def update(self):
  if self.fail:raise RuntimeError('device disconnected')
  self.reports.append(Report(self.buttons,self.lt,self.rt,self.yaw))

class Transport(unittest.TestCase):
 def setUp(self):
  self.now=0.;self.focus=True;self.active=True;self.pad=Pad();self.log=[]
  self.bridge=XboxCombatBridge(lambda:self.focus,lambda:self.active,self.log.append,lambda:self.pad,lambda:self.now,False)
  self.addCleanup(self.bridge.close);self.bridge.begin_session({'six_spam_enabled':True})
 def at(self,now):self.now=now;return self.bridge.tick()
 def heartbeats_to(self,end):
  while self.now+2.5<end:self.at(self.now+2.5);self.bridge.send('START')
  return self.at(end)
 def test_weaving_holds_real_rb_and_right_trigger_not_trigger_as_a_button(self):
  self.assertTrue(self.bridge.send('START'));r=self.pad.reports[-1]
  self.assertEqual(r.buttons,RB);self.assertEqual(r.rt,1);self.assertEqual(r.lt,0)
 def test_loot_is_added_every_two_seconds_without_releasing_attack(self):
  self.bridge.send('START')
  for stamp in (2.,4.,6.):
   r=self.at(stamp);self.assertEqual(r.buttons,RB|B);self.assertEqual(r.rt,1)
   r=self.at(stamp+.09);self.assertEqual(r.buttons,RB);self.assertEqual(r.rt,1)
  self.assertTrue(all(r.buttons&RB and r.rt==1 for r in self.pad.reports[2:]))
 def test_buff_occurs_at_eighty_seconds_with_lt_before_a_and_rb_rt_unchanged(self):
  self.bridge.send('START');self.heartbeats_to(79.99)
  r=self.at(80.);self.assertEqual(r.buttons,RB|B);self.assertEqual((r.lt,r.rt),(1,1))
  r=self.at(80.04);self.assertEqual(r.buttons,RB|B|A);self.assertEqual((r.lt,r.rt),(1,1))
  for i in range(1,200):
   t=80.04+i*.02
   if t>82 and i%50==0:self.bridge.send('START')
   r=self.at(t);self.assertTrue(r.buttons&RB);self.assertEqual(r.rt,1)
   if r.buttons&A:self.assertEqual(r.lt,1)
  r=self.at(84.1);self.assertFalse(r.buttons&A);self.assertEqual(r.lt,0)
 def test_buff_checkbox_can_disable_only_the_buff_timer(self):
  self.bridge.begin_session({'six_spam_enabled':False});self.bridge.send('START');self.heartbeats_to(80)
  self.assertTrue(self.pad.reports[-1].buttons&RB);self.assertEqual(self.pad.reports[-1].lt,0)
 def test_original_eighty_second_period_four_second_window_and_forty_five_ms_hold(self):
  self.bridge.send('START');self.heartbeats_to(60)
  self.assertEqual(self.pad.lt,0);self.assertFalse(self.pad.buttons&A);self.assertEqual(self.bridge.state.next_six,80)
  self.heartbeats_to(79.99);self.at(80)
  self.assertEqual(self.bridge.state.buff_end,84);self.assertEqual(self.bridge.state.next_six,160)
  self.assertTrue(self.at(80.04).buttons&A);self.assertTrue(self.at(80.084).buttons&A)
  self.assertFalse(self.at(80.086).buttons&A);self.assertTrue(self.at(80.191).buttons&A)
  self.assertFalse(self.at(84).buttons&A);self.assertEqual(self.at(84.041).lt,0)
 def test_single_release_keeps_periodic_loot_running(self):
  self.bridge.send('START');self.bridge.send('RELEASE')
  self.assertEqual(self.at(2).buttons,B);self.assertEqual(self.pad.rt,0)
 def test_start_heartbeat_does_not_reset_loot_or_buff_deadlines(self):
  self.bridge.send('START');self.at(1);self.bridge.send('START')
  self.assertEqual(self.bridge.state.next_loot,2);self.assertEqual(self.bridge.state.next_six,80)
 def test_full_finish_cancels_all_pending_auxiliary_actions(self):
  self.bridge.send('START');self.heartbeats_to(80.05);self.bridge.finish()
  for t in (80.06,81,82,160):self.assertEqual(self.at(t),Report())
 def test_focus_loss_clears_attack_and_does_not_reapply_it_on_return(self):
  self.bridge.send('START');self.focus=False;self.assertEqual(self.at(.1),Report())
  self.focus=True;self.assertEqual(self.at(.2),Report());self.assertFalse(self.bridge.attacking)
 def test_alarm_or_focus_loss_mid_buff_drops_every_hold_in_the_same_report(self):
  self.bridge.send('START');self.heartbeats_to(80.04)
  self.assertEqual(self.pad.buttons,RB|B|A);self.focus=False;self.active=False
  self.assertEqual(self.at(80.05),Report());self.focus=True
  self.assertEqual(self.at(82),Report());self.assertFalse(self.bridge.send('START'))
 def test_stopped_scanner_rejects_late_automatic_tab_f_and_start(self):
  self.bridge.send('START');self.active=False;self.bridge.finish()
  for name in ('START','TAB','F'):self.assertFalse(self.bridge.send(name))
  self.assertEqual(self.at(2),Report())
 def test_manual_diagnostic_is_one_pulse_without_a_background_session(self):
  self.active=False;self.bridge.finish()
  self.assertTrue(self.bridge.test_button('TAB'));self.assertEqual(self.pad.buttons,RS)
  self.assertEqual(self.at(.08),Report());self.assertEqual(self.at(2),Report())
  self.assertTrue(self.bridge.test_button('F'));self.assertEqual(self.pad.buttons,B)
  self.assertEqual(self.at(2.09),Report());self.assertFalse(self.bridge.state.session)
 def test_diagnostic_cannot_run_during_active_scan_or_after_revoked_generation(self):
  self.assertFalse(self.bridge.test_button('TAB'));self.active=False
  self.assertFalse(self.bridge.test_button('TAB',lambda:False));self.assertEqual(self.pad.buttons,0)
 def test_missing_heartbeat_releases_all_outputs_at_nine_seconds(self):
  self.bridge.send('START');self.bridge.turn(.45,.14)
  self.assertEqual(self.at(9.01),Report());self.assertFalse(self.bridge.attacking)
 def test_camera_has_short_deadline_but_does_not_drop_attack(self):
  self.bridge.send('START');self.bridge.turn(.45,.14)
  self.assertEqual(self.pad.reports[-1],Report(RB,0,1,.45))
  self.assertEqual(self.at(.15),Report(RB,0,1,0))
 def test_camera_off_is_immediate_and_keeps_weaving(self):
  self.bridge.send('START');self.bridge.turn(.45,.7);self.bridge.stop_camera()
  self.assertEqual(self.pad.reports[-1],Report(RB,0,1,0))
 def test_tab_is_a_single_rs_with_auxiliary_modifiers_released(self):
  self.bridge.send('START');self.heartbeats_to(80.04);self.bridge.send('TAB')
  self.assertEqual(self.pad.reports[-1],Report(RS));self.assertFalse(self.bridge.attacking)
 def test_close_is_permanent_and_releases_device(self):
  self.bridge.send('START');self.bridge.close();self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.rt,0)
  with self.assertRaises(RuntimeError):self.bridge.send('START')
 def test_unknown_commands_cannot_send_arbitrary_inputs(self):
  with self.assertRaises(ValueError):self.bridge.send('Y')
  with self.assertRaises(ValueError):self.bridge.test_button('START')

class WorkerRelease(unittest.TestCase):
 def test_real_worker_observes_stop_without_waiting_for_scanner_ocr(self):
  active=threading.Event();active.set();pad=Pad();b=XboxCombatBridge(lambda:True,active.is_set,factory=lambda:pad)
  try:
   self.assertTrue(b.begin_session({}));self.assertTrue(b.send('START'));active.clear()
   end=time.monotonic()+.5
   while pad.rt and time.monotonic()<end:time.sleep(.01)
   self.assertEqual((pad.buttons,pad.lt,pad.rt),(0,0,0))
  finally:b.close()

class ActualScannerCycle(unittest.TestCase):
 def build(self,stop_at=40,mode_switch=None,alarm_at=None):
  tree=ast.parse((ROOT/'target_scanner.py').read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ScannerApp')
  selected=[n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name in ('run_continuous_attack','start_macro','release_macro')]
  scope={};clock=SimpleNamespace(t=0.)
  scope['time']=SimpleNamespace(monotonic=lambda:clock.t,sleep=lambda sec:None)
  exec(compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])),'actual-scanner-cycle','exec'),scope)
  cfg={'attack_all_targets':True};active=threading.Event();active.set();closed=threading.Event();alarm=threading.Event()
  pad=Pad();b=XboxCombatBridge(lambda:not alarm.is_set(),active.is_set,factory=lambda:pad,clock=lambda:clock.t,background=False);b.begin_session({'six_spam_enabled':True})
  records=[]
  class App:
   macro_running=False;macro_lock=threading.RLock();captcha_locked=alarm
   def can_send(self):return active.is_set() and not closed.is_set() and not alarm.is_set()
   def game_active(self):return True
   def show(self,msg):pass
   def log(self,msg):records.append((clock.t,msg))
   def maybe_rotate_camera(self,*args):pass
   def finish_bridge(self):b.finish();self.macro_running=False
   def wait(self,sec):
    clock.t+=sec
    if alarm_at is not None and clock.t>=alarm_at:alarm.set();active.clear();b.finish()
    if mode_switch is not None and clock.t>=mode_switch:cfg['attack_all_targets']=False
    if clock.t>=stop_at:active.clear()
    b.tick();return active.is_set()
  app=App();app.active=active;app.closed=closed;app.bridge=b
  for name in ('run_continuous_attack','start_macro','release_macro'):setattr(App,name,scope[name])
  app.run_continuous_attack(cfg);return clock,pad,b,records
 def test_actual_twelve_second_half_second_cycle_has_no_tab_or_ocr(self):
  clock,pad,b,records=self.build()
  try:
   held=[t for t,msg in records if 'RB+RT зажаты' in msg];pauses=[t for t,msg in records if 'ПАУЗА' in msg]
   self.assertEqual(len(held),4);self.assertEqual(len(pauses),3)
   self.assertTrue(all(11.9<=pause-start<=12.1 for pause,start in zip(pauses,held)))
   self.assertTrue(all(.49<=start-pause<=.56 for start,pause in zip(held[1:],pauses)))
   self.assertFalse(any(r.buttons&RS for r in pad.reports));self.assertEqual(pad.rt,0)
  finally:b.close()
 def test_alarm_during_half_second_pause_prevents_any_late_attack_restart(self):
  clock,pad,b,records=self.build(alarm_at=12.2)
  try:
   self.assertEqual(sum('RB+RT зажаты' in msg for t,msg in records),1);self.assertEqual((pad.buttons,pad.lt,pad.rt),(0,0,0))
  finally:b.close()
 def test_live_switch_to_list_releases_weaving_before_list_can_select(self):
  clock,pad,b,records=self.build(mode_switch=4)
  try:self.assertLess(clock.t,5);self.assertEqual(pad.rt,0);self.assertFalse(b.attacking)
  finally:b.close()

class PreservedDataAndSource(unittest.TestCase):
 def test_actual_settings_parser_accepts_the_ported_camera_units_and_saved_options(self):
  tree=ast.parse((ROOT/'target_scanner.py').read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ScannerApp')
  funcs=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('parse_targets','normalize_name')]
  method=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='parse_ui');scope={'re':re}
  exec(compile(ast.fix_missing_locations(ast.Module(body=funcs+[method],type_ignores=[])),'actual-settings-parser','exec'),scope)
  cfg=json.loads((ROOT/'settings.json').read_text());app=SimpleNamespace(config=cfg,fields={})
  def var(value):return SimpleNamespace(get=lambda *args:value)
  app.targets_box=var('\n'.join(cfg['targets']));app.visual_mode=var(cfg['visual_mode']);app.visual_player_enabled=var(cfg['visual_player_enabled'])
  for attr,key in [('captcha_enabled_var','captcha_watch_enabled'),('death_enabled_var','death_watch_enabled'),('captcha_device_var','captcha_audio_device'),('attack_all_var','attack_all_targets'),('repeat_var','repeat_search'),('six_spam_var','six_spam_enabled'),('combat_spin_var','combat_spin'),('never_camera_var','never_move_camera'),('protect_var','protect_player'),('player_var','player_name'),('threat_sec_var','threat_scan_sec'),('turn_sec_var','search_turn_sec'),('turn_mode_var','search_turn_mode')]:
   setattr(app,attr,var(str(cfg[key]) if attr in ('threat_sec_var','turn_sec_var') else cfg[key]))
  parsed=scope['parse_ui'](app);self.assertEqual(parsed['turn_ms'],140);self.assertTrue(parsed['six_spam_enabled']);self.assertTrue(parsed['attack_all_targets'])
 def test_template_library_remains_loadable_and_self_matches(self):
  lib=VisualLibrary(ROOT/'visual_samples');self.assertGreaterEqual(len(lib.entries),10)
  for rec in lib.entries:
   raw=cv2.imread(str(lib.root/rec['file']));self.assertIsNotNone(raw)
   found,score,margin=lib.match(rec['kind'],raw,rec['name'] if rec['kind']=='player' else None)
   self.assertEqual(found,rec['name']);self.assertGreaterEqual(score,.79)
 def test_gameplay_source_has_no_ghub_or_injected_mouse_keyboard_calls(self):
  source=(ROOT/'target_scanner.py').read_text();tree=ast.parse(source)
  calls={ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n,ast.Call)}
  self.assertFalse(any(s in call for call in calls for s in ('keybd_event','mouse_event','SendInput','GHubBridge')))
  self.assertIn('XboxCombatBridge',calls)
 def test_shipped_settings_preserve_explicit_continuous_and_buff_options(self):
  cfg=json.loads((ROOT/'settings.json').read_text());self.assertTrue(cfg['attack_all_targets']);self.assertTrue(cfg['six_spam_enabled'])
  self.assertEqual(cfg['f_interval_ms'],2000);self.assertEqual(cfg['turn_ms'],140)

class DiagnosticCancellation(unittest.TestCase):
 def test_actual_delayed_test_cannot_press_after_a_later_stop(self):
  tree=ast.parse((ROOT/'target_scanner.py').read_text());cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ScannerApp')
  methods=[n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='test_bridge_tab'];tasks=[]
  class Thread:
   def __init__(self,target,**kw):self.target=target
   def start(self):tasks.append(self.target)
  ns={'time':SimpleNamespace(sleep=lambda _:None),'threading':SimpleNamespace(Thread=Thread)}
  exec(compile(ast.fix_missing_locations(ast.Module(body=methods,type_ignores=[])),'actual-delayed-test','exec'),ns)
  bridge=SimpleNamespace(test_button=Mock(return_value=True),finish=Mock())
  app=SimpleNamespace(active=threading.Event(),closed=threading.Event(),start_generation=1,game_active=lambda:True,bridge=bridge,log=lambda _:None)
  ns['test_bridge_tab'](app);self.assertEqual(len(tasks),1);app.start_generation+=1;tasks[0]();bridge.test_button.assert_not_called()

class SharedRuntime(unittest.TestCase):
 def test_gamepad_installs_from_local_binary_wheel_without_setup_or_network(self):
  import bootstrap
  with patch.object(bootstrap.subprocess,'run') as run:
   bootstrap.install_gamepad_runtime('python.exe')
  args=run.call_args.args[0];self.assertIn('--no-index',args);self.assertIn('--only-binary=:all:',args);self.assertTrue(args[-1].endswith('.whl'))
 def test_vendor_wheel_has_no_driver_installer_or_setup_hook_and_valid_records(self):
  wheel=ROOT/'vendor/vgamepad-0.1.0-py3-none-win_amd64.whl'
  with zipfile.ZipFile(wheel) as z:
   self.assertIsNone(z.testzip());names=z.namelist()
   self.assertFalse(any(n.endswith(('.msi','setup.py','.exe')) or '/install/' in n for n in names))
   self.assertTrue(any(n.endswith('ViGEmClient.dll') for n in names))
   records=list(csv.reader(io.StringIO(z.read('vgamepad-0.1.0.dist-info/RECORD').decode())))
   for name,digest,size in records:
    if not digest:continue
    data=z.read(name);self.assertEqual(len(data),int(size));self.assertEqual(digest,'sha256='+base64.urlsafe_b64encode(hashlib.sha256(data).digest()).decode().rstrip('='))
 def test_ready_runtime_is_reused_without_installing_again(self):
  import bootstrap
  with TemporaryDirectory() as tmp,patch.object(bootstrap,'find_runtime',return_value=Path(tmp)/'python.exe'),patch.object(bootstrap.subprocess,'run') as run:
   bootstrap.main();run.assert_not_called()
 def test_same_requirements_in_another_folder_find_the_existing_environment(self):
  import runtime_env
  with TemporaryDirectory() as tmp,patch.dict('os.environ',{'LOCALAPPDATA':tmp}):
   a=Path(tmp)/'a';b=Path(tmp)/'b';a.mkdir();b.mkdir()
   for p in (a,b):(p/'requirements.txt').write_text('vgamepad==0.1.0')
   folder=runtime_env.runtime_dir(a);exe=runtime_env.runtime_python(folder);exe.parent.mkdir(parents=True);exe.touch()
   (folder/'ready.json').write_text(json.dumps({'requirements_sha256':runtime_env.requirement_hash(a),'python_version':[3,12]}))
   self.assertEqual(runtime_env.find_runtime(b),exe);self.assertIn('ACore2TargetScanner',str(folder));self.assertFalse((b/'.venv').exists())

if __name__=='__main__':unittest.main()
