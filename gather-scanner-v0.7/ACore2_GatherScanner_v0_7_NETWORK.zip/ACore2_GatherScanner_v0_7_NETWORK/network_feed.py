"""Read-only bridge from CubeRadar's decoded live capture to the gather engine."""
import copy,json,subprocess,threading,time
from pathlib import Path
from network_state import Telemetry

ROOT=Path(__file__).resolve().parent

class NetworkFeed:
    def __init__(self,exe,logger=lambda _:None):
        self.exe=Path(exe).resolve();self.log=logger;self.lock=threading.RLock()
        catalogue=json.loads((ROOT/'gather_catalogue.json').read_text(encoding='utf-8-sig'))
        self.telemetry=Telemetry(map(int,catalogue));self.closed=threading.Event()
        self.process=None;self.worker=None;self.output=None;self.error=None
        self.directory=ROOT/'network_captures'/('live_'+str(time.time_ns()))
        self.latest_flow=None;self.last_packet=None
    def start(self):
        if not self.exe.is_file():raise RuntimeError('Выберите Cube.Radar.exe в программе')
        self.directory.mkdir(parents=True,exist_ok=True)
        self.output=(self.directory/'capture.log').open('w',encoding='utf-8')
        self.process=subprocess.Popen([str(self.exe),'dump','live','--out',str(self.directory),
            '--no-heartbeat','--no-hotkeys','--no-beep'],cwd=self.exe.parent,
            stdin=subprocess.PIPE,stdout=self.output,stderr=subprocess.STDOUT,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.worker=threading.Thread(target=self._loop,daemon=True);self.worker.start()
        self.log('Сеть: захват запущен; запись остаётся в network_captures. Ожидаю данные персонажа.')
    def ingest(self,row):
        if row.get('type')!='frame':return
        stamp=row.get('t');flow=row.get('flow');op=row.get('op');raw=row.get('hex')
        if not isinstance(flow,int) or not isinstance(stamp,int) or isinstance(stamp,bool):return
        if not isinstance(op,str) or not isinstance(raw,str) or len(raw)>131072:return
        try:body=bytes.fromhex(raw)
        except ValueError:return
        with self.lock:
            self.telemetry.feed(flow,op,body,stamp)
            state=self.telemetry.flows.get(flow)
            if state and state.own is not None:
                # Competing active own identities require a fresh single flow.
                others=[f for key,f in self.telemetry.flows.items() if key!=flow and f.own is not None
                        and f.last_packet is not None and abs(stamp-f.last_packet)<2500]
                if others:self.latest_flow=None
                else:self.latest_flow=flow
            self.last_packet=max(stamp,self.last_packet or stamp)
    def view(self,now=None):
        now=time.time()*1000 if now is None else now
        with self.lock:
            state=self.telemetry.flows.get(self.latest_flow)
            age=(now-state.last_packet)/1000 if state and state.last_packet is not None else None
            return dict(flow=self.latest_flow,state=copy.deepcopy(state),age=age,error=self.error,
                        ready=state is not None and state.own is not None and age is not None and -.5<=age<=2.5)
    def _loop(self):
        stream=None;pending=b''
        try:
            started=time.monotonic()
            while not self.closed.wait(.03):
                if stream is None:
                    files=list(self.directory.glob('*/frames.jsonl'))
                    if files:stream=files[0].open('rb')
                    elif self.process.poll() is not None:raise RuntimeError('CubeRadar завершился; подробности: '+str(self.directory/'capture.log'))
                    elif time.monotonic()-started>20:raise RuntimeError('CubeRadar не создал запись за 20 с. Проверьте Npcap и выбранный exe.')
                    else:continue
                part=stream.read(4*1024*1024)
                if part:
                    pending+=part
                    while b'\n' in pending:
                        line,pending=pending.split(b'\n',1)
                        if len(line)>2*1024*1024:continue
                        try:row=json.loads(line)
                        except (ValueError,UnicodeDecodeError):continue
                        if isinstance(row,dict):self.ingest(row)
                    if len(pending)>2*1024*1024:raise RuntimeError('Слишком длинная строка сетевого журнала')
                elif self.process.poll() is not None:raise RuntimeError('Сетевая запись завершилась; управление остановлено')
        except Exception as exc:
            with self.lock:self.error=str(exc)
            self.log('Сеть: '+str(exc))
        finally:
            if stream:stream.close()
    def close(self):
        self.closed.set()
        if self.process and self.process.poll() is None:
            try:
                self.process.stdin.write(b'q\n');self.process.stdin.flush()
                self.process.wait(timeout=6)
            except (OSError,subprocess.TimeoutExpired):
                self.process.terminate()
                try:self.process.wait(timeout=2)
                except subprocess.TimeoutExpired:self.process.kill()
        if self.worker and self.worker is not threading.current_thread():self.worker.join(timeout=1)
        if self.output:self.output.close()
