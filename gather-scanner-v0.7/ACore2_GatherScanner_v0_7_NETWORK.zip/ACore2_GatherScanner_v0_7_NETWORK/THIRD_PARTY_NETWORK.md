# Network attribution

`network_state.py` adapts the full Hit/reader wire layout documented by
[nuriland/a2kit](https://github.com/nuriland/a2kit), MIT, copyright (c) 2026 nuri.
The MIT notice is preserved in `A2KIT_LICENSE.txt`.

`gather_catalogue.json` is the display-only catalogue from
[Carchutin19/Aion-2-Helper](https://github.com/Carchutin19/Aion-2-Helper/tree/main/assets/gathering),
whose attribution identifies the MIT data source
[SkeeveAN/Aion-DPS-Meter](https://github.com/SkeeveAN/Aion-DPS-Meter).
The source notice is retained in `GATHER_METADATA_LICENSE.txt`. Game names
remain the content of their respective rights holders.

Resource/player wire fields were cross-checked against private Global captures,
CubeRadar's ObjectMessages documentation and Aion-2-Helper's public protocol
observations. Helper/Wingbeat application classes are not included.

[CubeRadar](https://github.com/dr89mh/aion2-cube-radar), GPL-3.0, is a separately
installed executable. It is not bundled. The bridge launches its documented
`dump live` command and reads its local JSONL output. It never sends packets
to the game. Gameplay input remains the existing G HUB / virtual Xbox path.

No player captures, private decoded packets, character IDs, positions, IPs,
user logs, local settings paths or session keys are embedded in this release.
