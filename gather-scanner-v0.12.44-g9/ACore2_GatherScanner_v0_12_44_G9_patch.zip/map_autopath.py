"""Game-owned pathfinding selected with G HUB Mouse Keys on the verified map."""
import math,time
from dataclasses import dataclass,replace
from gamepad_input import GamepadInput
from flight import read_flight
from auto_route_hud import route_hud
from map_teleport import is_map,menu_stamp,same_stamp
from map_coordinates import MapCoordinates
from map_mousekeys import MapMouseKeys
from vision import gathering_panel_pair
from map_flight_dialog import flight_dialog,same as same_flight_dialog

@dataclass
class PathRun:
 phase:str
 started:float
 since:float
 reason:str
 flow:object
 owner:object
 goal:object=None
 fix:object=None
 attempted:bool=False
 hud_seen:bool=False
 missing:int=0
 missing_since:float|None=None
 near:int=0
 best:float|None=None
 progress:float=0
 check_at:float=0
 hud_at:float=0
 ack:bool=False
 map_open:bool=False
 finishing:bool=False
 failed:bool=False
 result:str=''
 pending_air:bool=False
 wing_sent:bool=False
 close_retries:int=0
 switches:int=0
 straight:float=0
 dialog_sent:bool=False
 dialog:object=None

class MapAutopath:
 def __init__(self,cfg,emit):
  self.cfg=cfg;self.emit=emit;self.coordinates=MapCoordinates(cfg);self.transport=None
  self.run=None;self.next_at=0;self.ping_after=0;self.stopping=False;self.force_camp=False
  self.escape_next=False;self.last_goal=None;self.last_note=-1e9
  self.cancelling=False
  if cfg.get('map_mousekeys_enabled') and not self.coordinates.ready:
   emit('MAP_SETUP_REQUIRED: сначала «Автопуть: настроить карту»; пока используется прежняя навигация')
 @property
 def enabled(self):return bool(self.cfg.get('map_mousekeys_enabled') and self.coordinates.ready)
 @property
 def owns(self):return self.run is not None
 def _transport(self,e):
  if self.transport is None:self.transport=MapMouseKeys(self.emit,e.cfg.get('dry_run',False))
  return self.transport
 def permitted(self,e):
  if self.stopping or e.stop_event.is_set() or not e._focus_ok() or e.cfg.get('dry_run'):return False
  if e.target_confirmed or e.resource_hold or e.collecting_visible or e._urgent_damage_pending() and not self.owns:return False
  view=e._net_view()
  return bool(view and view['ready'] and view['state'].own is not None and e._own_collection(view) is None and not e._live_attempt(view))
 def phase(self,name,now):self.run.phase=name;self.run.since=now
 def cancel(self,e,reason,move=True):
  run=self.run
  if run is None:return
  self.run=None
  # A real movement is sent ONLY for an explicit cancellation, never as patrol.
  if run.map_open and e._focus_ok():
   frame,_=e.screen.frame()
   if is_map(frame) and self.transport is not None:
    self._toggle_map(e,lambda:e._focus_ok());GamepadInput.wait(.18,e.stop_event,e.screen.focused)
    run.map_open=is_map(e.screen.frame()[0])
  e.map_active=run.map_open;e.change_mode('SEARCH');self.next_at=time.monotonic()+3
  if run.map_open:
   e.map_menu_stamp=None;e.map_exit_failure={'reason':'автопуть: закрытие карты не подтверждено','since':time.monotonic(),'sent':False,'absent':None}
  if move and run.attempted and not run.map_open and e._focus_ok() and e._own_collection() is None:
   e.gamepad.drive(-.35,0,0,0,lifetime=.06)
   GamepadInput.wait(.07,e.stop_event,e.screen.focused);e._neutral()
  self.coordinates.defer(run.goal,time.monotonic(),30)
  self.emit('MAP_PATH_CANCEL: '+reason)
 def stop(self,e):
  self.stopping=True
  self.cancel(e,'остановка бота',move=True)
  if self.transport is not None:
   try:self.transport.close()
   except Exception as exc:self.emit('MAP_LUA_CLOSE: '+str(exc))
 def finish(self,e,now):
  run=self.run
  self.run=None;e.map_active=False;e.change_mode('SEARCH');self.next_at=now+(3 if run.failed else 12)
  e.no_yield.next_return=max(e.no_yield.next_return,now+20)
  if run.failed and run.attempted and e._focus_ok() and e._own_collection() is None:
   e.gamepad.drive(-.35,0,0,0,lifetime=.06);GamepadInput.wait(.07,e.stop_event,e.screen.focused);e._neutral()
  if run.goal:self.coordinates.defer(run.goal,now,45 if run.failed else 20)
  self.emit(('MAP_PATH_FAIL: ' if run.failed else 'MAP_PATH_DONE: ')+run.result)
  if run.failed:
   self.escape_next=not run.pending_air and bool(self.coordinates.spec.get('air_points'))
  else:
   self.escape_next=False
   if run.pending_air and run.goal and 'эфир' not in run.goal.name.lower():
    e.resource_flight_owned=True;e.wing_close_pending=now;e.wing_close_started=now;e.wing_close_retries=0
   e.identity_valid_after=now;e.nav.finish_goal(now)
 def _cancel_motion(self,e):
  self.cancelling=True
  try:
   e.gamepad.drive(-.35,0,0,0,lifetime=.06);GamepadInput.wait(.07,e.stop_event,e.screen.focused);e._neutral()
  finally:self.cancelling=False
 def end(self,now,failed,reason):
  self.run.failed=failed;self.run.finishing=True;self.run.result=reason;self.phase('CLOSE',now)
 def _toggle_map(self,e,authorize):
  result=self.transport.map_toggle(authorize)
  if not result.attempted and authorize():
   # This is a verified no-dispatch fallback, never a duplicate uncertain M.
   return e.bridge_cmd('MAP')
  return result.attempted
 def start(self,e,frame,now):
  if (not self.enabled or now<self.next_at or not self.permitted(e) or e.mode!='SEARCH'
      or e.caption_latch is not None or e.terrain_recovery is not None or e.post_tp_exit is not None
      or e.map_active or e.map_teleport is not None or e.camera_in_progress or e.pitch.returning
      or e.wing_close_pending is not None or e.click_busy or e.return_exit_guard):return False
  view=e._net_view()
  if not self.coordinates.valid_layer(view['state']):return False
  if not is_map(frame):e._budget_update(read_flight(frame),now)
  if now<self.ping_after:return False
  tr=self._transport(e)
  if not tr.ready:
   self.ping_after=now+15
   result=tr.ping(lambda:self.permitted(e))
   if not result.acknowledged:
    self.emit('MAP_LUA_WAIT: '+result.reason+'; нужен GHUB_MAP_MOUSEKEYS.lua, профиль G502 и нажатие G9. Старый сбор остаётся доступен')
    return False
   self.ping_after=0
  reason='camp' if self.force_camp or e.hybrid_camp_pending else 'escape' if self.escape_next else 'resources'
  e._neutral();e._release_collection_cursor();e._clear_view_recovery()
  self.run=PathRun('OPEN',now,now,reason,view['flow'],view['state'].own,progress=now)
  self.force_camp=False;e.camp_route=None;e.hybrid_camp_pending=False;e.camp_exit_until=0;e.camp_rearm=False
  e.terrain_recovery=None;e.probe=None;e.pending_probe=None;e.patrol_escape=None;e.nav.air_since=None
  e.change_mode('MAP_PATH');self.emit('MAP_PATH_START: '+reason+'; левый стик заблокирован')
  return True
 def tick(self,e,frame,now):
  if self.run is None:
   if not self.start(e,frame,now):return False
  run=self.run
  view=e._net_view()
  if (not view or not view['ready'] or view['flow']!=run.flow
      or run.owner is not None and view['state'].own!=run.owner):
   self.cancel(e,'потеря подтверждённого соединения');return True
  if e._own_collection(view) is not None or e._live_attempt(view):
   # Collection already owns the game: a cancellation stick would interrupt it.
   self.cancel(e,'начался свой сбор',move=False);return False
  # The game path survives hits. Do not stop to fight each passing mob.
  if e.caption_latch is not None and not run.map_open:
   self.cancel(e,'найден свежий ресурс в мире');return False
  if not e._focus_ok():e._neutral();return True
  if now-run.started>70:
   self.cancel(e,'общий предел 70 с без бесконечного перепланирования');return True
  if run.attempted and run.phase=='CLOSE' and not run.dialog_sent:
   dialog=flight_dialog(frame)
   if dialog is not None:
    if e.budget.can_start() and e.budget.energy is not None and e.budget.energy>=50:
     run.dialog_sent=True
     def allowed_dialog():
      return self.permitted(e) and same_flight_dialog(e.screen.frame()[0],dialog.signature)
     result=self.transport.confirm_flight(allowed_dialog)
     if result.attempted:
      run.pending_air=True;run.hud_seen=False;run.best=None;run.progress=time.monotonic()
      run.dialog=dialog;self.phase('FLIGHT_WAIT',run.progress)
      self.emit('MAP_FLIGHT_DIALOG: подтверждён именно вопрос о полёте; F передана, взлёт проверяется по кадрам')
     else:self.end(now,True,'подтверждение полёта не передано')
    else:
     fresh,origin=e.screen.frame()
     if same_flight_dialog(fresh,dialog.signature):
      e.bridge.cursor(origin[0]+dialog.cancel[0],origin[1]+dialog.cancel[1])
      e.gamepad.tap_ui_a(e.stop_event,e.screen.focused,lambda:self.permitted(e) and same_flight_dialog(e.screen.frame()[0],dialog.signature))
     self.end(now,True,'энергии для подтверждённого полёта недостаточно')
    return True
  if run.phase=='FLIGHT_WAIT':
   if same_flight_dialog(frame,run.dialog.signature):
    if now-run.since>3:
     fresh,origin=e.screen.frame()
     if same_flight_dialog(fresh,run.dialog.signature):
      e.bridge.cursor(origin[0]+run.dialog.cancel[0],origin[1]+run.dialog.cancel[1])
      e.gamepad.tap_ui_a(e.stop_event,e.screen.focused,lambda:self.permitted(e) and same_flight_dialog(e.screen.frame()[0],run.dialog.signature))
     self.end(now,True,'окно полёта не закрылось; F повторно не нажимаю')
   else:self.phase('CLOSE',now)
   return True
  if run.phase=='OPEN':
   e.map_active=True;run.map_open=True
   if is_map(frame):self.phase('MAP',now);return True
   result=self.transport.map_toggle(lambda:self.permitted(e))
   if not result.attempted:self.end(now,True,'карта не открыта: '+result.reason)
   else:self.phase('MAP',time.monotonic())
   return True
  if run.phase in ('MAP','CHECK_MAP'):
   if not is_map(frame):
    if now-run.since>3:self.end(now,True,'M не подтвердилось за 3 с')
    return True
   fix=self.coordinates.register(frame)
   if fix is None:
    if now-run.since>4:self.end(now,True,'карта/стрелка не сопоставлены с эталоном')
    return True
   if run.phase=='CHECK_MAP':
    distance=math.dist(fix['world'],self._world_goal(run.goal))/100
    if distance<15 and run.hud_seen and run.missing>=3:self.end(now,False,'маршрут исчез; позиция у выбранной точки подтверждена')
    elif run.hud_seen and run.missing>=3:self.end(now,True,'маршрут исчез вдали от точки; это не прибытие')
    else:self.phase('CLOSE',now)
    return True
   if run.goal is not None:
    if self.coordinates.pixel(run.goal,fix) is None:self.end(now,True,'заданная точка вышла из вида карты')
    else:run.fix=fix;self.phase('CLICK',now)
    return True
   can_fly=e.budget.can_start() and e.budget.energy is not None and e.budget.energy>=50
   goals=self.coordinates.goals(view['state'],fix,now,can_fly,e.policy.priority,run.reason=='camp',run.reason=='escape')
   if not goals:self.end(now,True,'в видимой области нет подходящей точки; вслепую карту не кликаю');return True
   if run.reason=='escape' and self.last_goal:
    goals.sort(key=lambda g:math.dist(g.reference,self.last_goal.reference)+.25*math.dist(g.reference,fix['position']))
   run.goal=goals[0];run.fix=fix;run.pending_air=bool(run.goal.air or e.budget.airborne)
   run.straight=math.dist(fix['world'],self._world_goal(run.goal))/100
   if (run.reason!='camp' and can_fly and self.cfg.get('map_mousekeys_fly_long',True)
       and run.straight>=max(30,float(self.cfg.get('map_mousekeys_flight_distance_m',80)))):
    run.goal=replace(run.goal,air=True);run.pending_air=True
   if run.goal.air:self.phase('CLOSE_FOR_WINGS',now)
   else:self.phase('CLICK',now)
   return True
  if run.phase=='CLOSE_FOR_WINGS':
   if is_map(frame):self._toggle_map(e,lambda:self.permitted(e));self.phase('WINGS',time.monotonic())
   else:self.phase('WINGS',now)
   e.map_active=False;run.map_open=False;return True
  if run.phase=='WINGS':
   if is_map(frame):
    if now-run.since>3:self.end(now,True,'карта не закрыта перед раскрытием крыльев')
    return True
   reading=read_flight(frame);e._budget_update(reading,now)
   if reading.confirmed:self.phase('OPEN',now);return True
   if reading.swimming or not e.budget.can_start() or e.budget.energy is None or e.budget.energy<50:self.end(now,True,'крылья сейчас недоступны');return True
   if now-run.since>.4 and not run.wing_sent:
    e.bridge_cmd('V');run.wing_sent=True
   if now-run.since>3:self.end(now,True,'раскрытие крыльев не подтверждено')
   return True
  if run.phase=='CLICK':
   if not self.permitted(e):self.end(now,True,'отменено до клика');return True
   fresh,origin=e.screen.frame()
   if not is_map(fresh):self.end(now,True,'карта исчезла до клика');return True
   fix=self.coordinates.register(fresh);point=self.coordinates.pixel(run.goal,fix) if fix else None
   if point is None:self.end(now,True,'точка вышла из подтверждённого вида карты');return True
   e.bridge.cursor(origin[0]+point[0],origin[1]+point[1])
   if not GamepadInput.wait(.10,e.stop_event,e.screen.focused):return True
   final,final_origin=e.screen.frame();check=self.coordinates.register(final)
   second=self.coordinates.pixel(run.goal,check) if check else None
   if (second is None or final_origin!=origin or math.dist(point,second)>6 or not e.bridge.cursor_matches()
       or not is_map(final) or not self.permitted(e)):
    self.end(now,True,'свежая проверка положения/карты запретила клик');return True
   run.attempted=True
   stamp=menu_stamp(final);patch=self._patch(final,point)
   def click_allowed():
    if not self.permitted(e) or not e.map_active or not e.bridge.cursor_matches():return False
    current,current_origin=e.screen.frame()
    if current_origin!=origin or current.shape!=final.shape or not same_stamp(current,stamp):return False
    sample=self._patch(current,point)
    return sample.shape==patch.shape and abs(sample.astype(float)-patch).mean()<4
   result=self.transport.click(click_allowed)
   run.ack=result.acknowledged;self.last_goal=run.goal
   self.emit('MAP_PATH_CLICK: '+run.goal.name+'; '+('живой ID/XYZ' if run.goal.live else 'справочная/заданная точка')+'; '+result.reason)
   if not result.attempted:self.end(time.monotonic(),True,'Lua не отправила клик')
   else:run.progress=time.monotonic();self.phase('CLOSE',run.progress)
   return True
  if run.phase=='CLOSE':
   if is_map(frame):run.map_open=True;e.map_active=True
   if run.map_open:
    if is_map(frame):
     if now-run.since>4:self.cancel(e,'карта не закрылась');return True
     self._toggle_map(e,lambda:self.permitted(e));self.phase('CLOSE_WAIT',time.monotonic());return True
    run.map_open=False;e.map_active=False
   if run.finishing:self.finish(e,now);return True
   run.check_at=now+5;self.phase('TRAVEL',now);return True
  if run.phase=='CLOSE_WAIT':
   if is_map(frame):
    if now-run.since>2:
     if run.close_retries<1:
      run.close_retries+=1;e.bridge_cmd('MAP');run.since=time.monotonic()
     else:self.cancel(e,'M не закрыло карту; повтор не выдаётся за маршрут')
    return True
   run.map_open=False;e.map_active=False
   if run.finishing:self.finish(e,now)
   else:run.check_at=now+5;self.phase('TRAVEL',now)
   return True
  if run.phase=='TRAVEL':
   reading=read_flight(frame);e._budget_update(reading,now);e.unowned_flight.observe(reading,now)
   if now-run.hud_at<.6:return True
   run.hud_at=now;hud=route_hud(frame)
   if hud.present:
    run.hud_seen=True;run.missing=0;run.missing_since=None
    if hud.metres is not None:
     if (run.switches==0 and not reading.confirmed and not reading.swimming and run.straight>30
         and hud.metres>max(80,run.straight*2.2) and e.budget.can_start()
         and e.budget.energy is not None and e.budget.energy>=50):
      self._cancel_motion(e);run.switches=1;run.pending_air=True;run.wing_sent=False
      run.hud_seen=False;run.missing=0;run.best=None;run.progress=now
      self.phase('WINGS',time.monotonic())
      self.emit('MAP_PATH_UPGRADE: пешком '+str(hud.metres)+' м против '+str(round(run.straight))+' м напрямую; отменяю подтверждённый крюк и один раз перестраиваю этот же маршрут в полёте')
      return True
     if run.best is None or hud.metres<run.best-1:run.best=hud.metres;run.progress=now
     run.near=run.near+1 if hud.metres<=3 else 0
     if run.near>=2:self.end(now,False,'две свежие проверки автопути: осталось не больше 3 м');return True
   elif hud.present is False and run.hud_seen:
    run.missing+=1
    if run.missing_since is None:run.missing_since=now
   if now-run.progress>(12 if run.pending_air else 6) and run.hud_seen and hud.present:
    self.end(now,True,'расстояние автопути не уменьшается');return True
   if not run.hud_seen and now-run.since>5:
    self.end(now,True,'нет игрового подтверждения автопути; не повторяю сомнительный клик');return True
   if run.missing>=3 or now>=run.check_at:
    e.map_active=True;run.map_open=True
    self._toggle_map(e,lambda:self.permitted(e));self.phase('CHECK_MAP',time.monotonic())
   return True
  return True
 def _world_goal(self,goal):
  from map_reference import transform
  return tuple(goal.xyz[:2]) if goal.xyz else transform(goal.reference,self.coordinates.inverse)
 @staticmethod
 def _patch(frame,point):
  x,y=point;return frame[max(0,y-42):y+43,max(0,x-42):x+43].copy()
