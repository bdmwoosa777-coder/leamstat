import json,threading,time,unittest,math
from types import SimpleNamespace
from unittest.mock import patch
from http.server import HTTPServer,BaseHTTPRequestHandler
import numpy as np
from ai_policy import PolicyClient,PolicyHost,Decision,validate
from ai_engine import AIGatherEngine,unchanged
from gather_engine import GatherEngine
from flight import FlightReading
from test_navigation import GatherFixture,radar,obs
from test_network_control import Source

ACTION={'action':'move','direction':'forward','resource':'none','x':500,'y':500,'duration_ms':600,'reason':'clear road'}
FRAME=np.full((360,640,3),40,np.uint8)

class PolicyContract(unittest.TestCase):
 def test_one_tool_has_a_bounded_lease(self):self.assertEqual(validate(ACTION,['Эфир']),ACTION)
 def test_arbitrary_commands_and_bad_coordinates_are_rejected(self):
  for bad in ({**ACTION,'action':'shell'},{**ACTION,'x':True},{**ACTION,'duration_ms':5000},{**ACTION,'x':float('nan')},{**ACTION,'command':'F'}):
   with self.assertRaises(ValueError):validate(bad,['Эфир'])
 def test_resource_action_needs_known_identity(self):
  for name in ('none','Страж'):
   with self.assertRaises(ValueError):validate({**ACTION,'action':'acquire','resource':name},['Эфир'])
 def test_generate_receives_two_images_and_action_history(self):
  c=PolicyClient();response={'message':{'content':json.dumps(ACTION)}}
  with patch.object(c,'call',return_value=response) as call:
   self.assertEqual(c.decide(FRAME,FRAME,{'flight_confirmed':False},[{'feedback':'blocked'}],['Эфир']),ACTION)
  args,kw=call.call_args;payload=args[1]
  self.assertEqual(args[0],'/api/generate');self.assertTrue(payload['stream']);self.assertEqual(len(payload['images']),2)
  self.assertIn('blocked',payload['prompt']);self.assertNotIn('messages',payload)
 def test_changed_view_revokes_stale_points(self):
  self.assertTrue(unchanged(FRAME,FRAME.copy()));self.assertFalse(unchanged(FRAME,np.full_like(FRAME,180)))
 def test_late_reply_cannot_cross_a_tool_generation(self):
  entered=threading.Event();release=threading.Event()
  class Client:
   def __init__(self,*a):pass
   def probe(self):pass
   def decide(self,*a):entered.set();release.wait(2);return ACTION
  host=PolicyHost({'target_names':['Эфир']},lambda s:None)
  with patch('ai_policy.PolicyClient',Client):
   host.offer(FRAME,{},[],time.monotonic());self.assertTrue(entered.wait(1));host.invalidate();release.set();host.worker.join(2)
  self.assertIsNone(host.take());host.close()
 def test_generate_stream_is_joined_through_final_record(self):
  content=json.dumps(ACTION)
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*a):pass
   def do_POST(self):
    self.rfile.read(int(self.headers['Content-Length']))
    raw=b'\n'.join(json.dumps(o).encode() for o in [{'response':'','done':False},{'response':content[:15],'done':False},{'response':content[15:],'done':True}])
    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   c=PolicyClient('http://127.0.0.1:'+str(server.server_port));self.assertEqual(c.decide(FRAME,None,{},[],['Эфир']),ACTION)
  finally:server.shutdown();server.server_close();thread.join()

class FakeHost:
 def __init__(self):self.latest=None;self.offers=[];self.invalid=0
 def offer(self,*a):self.offers.append(a)
 def take(self):r=self.latest;self.latest=None;return r
 def invalidate(self):self.invalid+=1;self.latest=None
 def close(self):pass

class AITools(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();bridge=self.e.bridge;screen=self.e.screen;cfg=self.e.cfg
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=AIGatherEngine(cfg,self.log.append,self.input,network=self.source);self.e.bridge=bridge;self.e.screen=screen
  self.e.ai=FakeHost();self.e.mode='SEARCH'
 def tick(self,a=None,t=100):
  if a is not None:self.e.ai.latest=Decision(0,t,self.frame.copy(),a,.2)
  with patch('ai_engine.time.monotonic',return_value=t):self.e.step(self.frame,(0,0),obs(),radar(),FlightReading(None,False),t)
 def test_waiting_for_model_never_runs_legacy_navigation(self):
  with patch.object(self.e.nav,'update',side_effect=AssertionError('old planner')):self.tick()
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(len(self.e.ai.offers),1)
 def test_ai_move_is_executed_once_and_does_not_renew_forever(self):
  self.tick(ACTION);self.assertIsNotNone(self.input.motion_deadline)
  self.tick(t=101);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.e.ai_history[-1]['action'],'move')
 def test_old_response_does_not_execute_after_view_change(self):
  self.e.ai.latest=Decision(0,100,np.full_like(self.frame,180),ACTION,.2);self.tick()
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertTrue(any('AI_STALE' in s for s in self.log))
 def test_collection_delegates_without_ai_movement(self):
  self.e.resource_hold=True;self.e.target_confirmed=True;self.e.mode='GATHER'
  with patch.object(GatherEngine,'step') as legacy:self.tick(ACTION);legacy.assert_called_once()
  self.assertFalse(self.e.ai.offers)
 def test_unknown_energy_cannot_toggle_flight(self):
  self.tick({**ACTION,'action':'takeoff'});self.assertNotIn('V',self.commands)
 def test_stop_revokes_future_actions(self):
  self.e.stop_event.set();self.tick(ACTION);self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_wrong_network_identity_does_not_get_a_second_click(self):
  self.input.native_cursor=True
  a={**ACTION,'action':'acquire','resource':'Эфир','y':500}
  with patch('ai_engine.GamepadInput.wait',return_value=True):self.tick(a)
  self.assertEqual(self.pad.presses,1);self.assertFalse(self.e.target_confirmed);self.assertFalse(self.alt_held)
 def test_fresh_resource_identity_hands_off_after_exactly_one_native_click(self):
  self.input.native_cursor=True;tap=self.input.tap_a
  def click(*a,**kw):
   ok=tap(*a,**kw);self.source.state.nodes[99].template=1500000
   self.source.state.selection_time=int(time.time()*1000)+10;return ok
  self.input.tap_a=click
  with patch('ai_engine.GamepadInput.wait',return_value=True):self.tick({**ACTION,'action':'acquire','resource':'Эфир'})
  self.assertEqual(self.pad.presses,1);self.assertTrue(self.e.target_confirmed);self.assertEqual(self.e.mode,'APPROACH')
  self.assertEqual(self.e.network_target,(1,99));self.assertFalse(self.alt_held);self.assertEqual(self.pad.buttons,0)
 def test_network_failure_prevents_ai_input(self):
  self.source.ready=False;self.tick(ACTION);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.presses,0)
 def test_no_legacy_no_yield_or_rescue_or_patrol_can_take_over(self):
  self.assertFalse(self.e._no_yield_tick(None,None,100));self.assertFalse(self.e._start_terrain_recovery(100,None))
  self.assertFalse(self.e._return_exit_tick(None,None,100));self.assertFalse(self.e._patrol_escape_tick(None,None,100))
 def test_observation_mode_records_decision_without_pressing(self):
  self.e.cfg['dry_run']=True;self.tick(ACTION);self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.presses,0)
 def test_selected_goal_is_carried_into_the_next_ai_observation(self):
  self.tick({**ACTION,'resource':'Эфир'});self.tick(t=101)
  self.assertEqual(self.e.ai.offers[-1][1]['goal'],'Эфир')
