"""Exercise the actual AI tool schema on a synthetic image; no game input."""
from pathlib import Path
import json,time
import numpy as np
from ai_policy import PolicyClient

def main():
 root=Path(__file__).resolve().parent;cfg=json.loads((root/'settings_gather.json').read_text(encoding='utf-8'))
 client=PolicyClient(cfg['analyzer_url'],cfg['analyzer_model']);data={'model':client.model,'synthetic':True}
 started=time.monotonic()
 try:
  client.probe();data['answer']=client.decide(np.full((360,640,3),60,np.uint8),None,{'test':'blank picture, choose wait'},[],cfg['target_names']);data['valid_answer']=True
 except Exception as exc:data['valid_answer']=False;data['error']=str(exc)
 data['seconds']=round(time.monotonic()-started,2)
 try:data['running_models']=client.call('/api/ps')
 except Exception as exc:data['gpu_error']=str(exc)
 (root/'ai_check.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8');print(json.dumps(data,ensure_ascii=False,indent=2))
 return 0 if data['valid_answer'] else 1
if __name__=='__main__':raise SystemExit(main())
