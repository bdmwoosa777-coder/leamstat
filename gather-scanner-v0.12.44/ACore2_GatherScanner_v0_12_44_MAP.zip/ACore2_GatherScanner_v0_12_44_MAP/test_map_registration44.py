"""Real OpenCV registration, full static catalogue and exact flight-consent parser."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import hashlib,math,unittest
import cv2,numpy as np
from map_coordinates import MapCoordinates,MapGoal,full_catalogue
from map_reference import TerrainMatcher,ArrowLocator,transform
from map_teleport import Line
from map_flight_dialog import flight_dialog,QUESTION,stamp,same
from spatial import Atlas,resource_names

ROOT=Path(__file__).resolve().parent

class FullCatalogue(unittest.TestCase):
 def test_original_catalogue_bytes_are_pinned(self):
  self.assertEqual(hashlib.sha256((ROOT/'assets/atlas/gather_full.json').read_bytes()).hexdigest(),'955a618744dbc1a75e4e8b9e702fb4e3325aa66d5e4275ec662fcbd86aa749ec')
 def test_all_5401_points_and_2692_altgard_locations_are_available(self):
  data=full_catalogue();self.assertEqual(sum(len(p) for rows in data.values() for p in rows.values()),5401)
  rows=data['World/World_D/World_D_A'];self.assertEqual(sum(map(len,rows.values())),2692)
  self.assertEqual(len(rows['1550000']),650);self.assertEqual(sum(len(rows[k]) for k in ('1550020','1550021','1550022')),590)
 def test_all_templates_join_existing_russian_names(self):
  names=resource_names()
  for rows in full_catalogue().values():
   for template in rows:self.assertTrue(names.get(int(template)))
 def test_static_selection_uses_full_map_and_only_configured_resources(self):
  c=MapCoordinates.__new__(MapCoordinates);c.ready=True;c.meta=Atlas().maps['altgard'];c.layer='altgard';c.atlas=Atlas();c.full=full_catalogue()
  c.matrix=np.array([[.001,0,600],[0,.001,400],[0,0,1]]);c.inverse=np.linalg.inv(c.matrix)
  c.zone=np.float32([[0,0],[1200,0],[1200,800],[0,800]]);c.cooldown={};c.spec={};c.allowed={'Алмаз'}
  state=SimpleNamespace(map_id=1110,nodes={},players={},npcs={},deaths={})
  fix={'matrix':np.eye(3),'position':(600,400),'viewport':(0,0,1200,800)}
  goals=c.goals(state,fix,100)
  self.assertGreater(len(goals),100);self.assertTrue(all(g.name=='Алмаз' and not g.live for g in goals))

class Registration(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  rng=np.random.default_rng(40);cls.background=rng.integers(40,160,(525,700,3),dtype=np.uint8)
  cls.template=cv2.imread(str(ROOT/'assets/player_arrow_mask.png'),0)
 def make(self):
  c=MapCoordinates.__new__(MapCoordinates);c.roi=[.25,.15,.95,.9];c.frame_width=1000;c.arrow_size=64
  c.inverse=np.array([[100,0,-20000],[0,100,-10000],[0,0,1]],float)
  ref=self.background.copy();ref[100:164,150:214][self.template>128]=250
  c.matcher=TerrainMatcher(ref);c.arrow=ArrowLocator(self.template);return c
 def picture(self,matrix=None,arrow=True):
  image=self.background.copy() if matrix is None else cv2.warpAffine(self.background,matrix,(700,525))
  if arrow:image[250:314,400:464][self.template>128]=250
  frame=np.zeros((700,1000,3),np.uint8);frame[105:630,250:950]=image;return frame
 def test_fresh_arrow_position_locates_character_independently_of_reference_arrow(self):
  c=self.make();fix=c.register(self.picture());self.assertIsNotNone(fix)
  self.assertLess(math.dist(fix['position'],(432,282)),3)
  self.assertLess(math.dist(fix['world'],(23200,18200)),300)
  point=c.pixel(MapGoal(1,'Эфир',(500,300)),fix);self.assertLess(math.dist(point,(750,405)),3)
  self.assertNotIn('camera_heading',fix)
 def test_north_up_zoom_pan_is_registered_before_resource_projection(self):
  c=self.make();matrix=np.float32([[1.08,0,-28],[0,1.08,-16]])
  fix=c.register(self.picture(matrix));self.assertIsNotNone(fix)
  point=c.pixel(MapGoal(1,'Эфир',(500,300)),fix);self.assertLess(math.dist(point,(762,413)),3)
 def test_missing_player_arrow_does_not_reuse_its_old_reference_position(self):self.assertIsNone(self.make().register(self.picture(arrow=False)))
 def test_rotated_map_is_not_a_world_coordinate_fix(self):
  matrix=cv2.getRotationMatrix2D((350,262),15,1)
  self.assertIsNone(self.make().register(self.picture(matrix)))
 def test_blank_frame_never_creates_a_click_coordinate(self):self.assertIsNone(self.make().register(np.zeros((700,1000,3),np.uint8)))

class FlightConsent(unittest.TestCase):
 def setUp(self):
  self.image=np.zeros((1152,2048,3),np.uint8);self.image[656:714,1044:1291]=(0,190,240)
  self.question='Невозможно переместиться по земле. Переместиться с помощью полета?'
 def recognize(self,question=None,cancel='Отмена',accept='F OK'):
  texts=[self.question if question is None else question,cancel,accept]
  rows=[[Line(text,(900,600,100,30))] for text in texts]
  with patch('map_flight_dialog.lines',side_effect=rows):return flight_dialog(self.image)
 def test_exact_question_buttons_and_gold_allow_specific_consent(self):self.assertIsNotNone(self.recognize())
 def test_teleport_confirmation_does_not_authorize_flight_f(self):self.assertIsNone(self.recognize('Переместиться к кибелиску?'))
 def test_resource_or_loot_prompt_never_authorizes_f(self):self.assertIsNone(self.recognize('F Сбор'))
 def test_missing_cancel_rejects_modal(self):self.assertIsNone(self.recognize(cancel='Назад'))
 def test_missing_ok_rejects_modal(self):self.assertIsNone(self.recognize(accept='Собрать'))
 def test_missing_gold_rejects_question(self):
  self.image[:]=0;self.assertIsNone(self.recognize())
 def test_changed_modal_pixels_revoke_old_consent(self):
  signature=stamp(self.image);self.assertTrue(same(self.image,signature));self.image[:]=240;self.assertFalse(same(self.image,signature))

if __name__=='__main__':unittest.main()
