"""Exact flight-only consent. This never authorizes F for loot or resources."""
from dataclasses import dataclass
import cv2,numpy as np
from map_teleport import lines,canonical

QUESTION=canonical('Невозможно переместиться по земле. Переместиться с помощью полета?')

@dataclass(frozen=True)
class FlightDialog:
 accept:tuple
 cancel:tuple
 signature:object

def stamp(frame):
 h,w=frame.shape[:2];crop=frame[round(h*.43):round(h*.64),round(w*.35):round(w*.65)]
 return cv2.resize(cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY),(180,90))

def same(frame,signature):
 if signature is None:return False
 value=stamp(frame)
 return value.shape==signature.shape and float(np.mean(abs(value.astype(float)-signature)))<3

def flight_dialog(frame):
 title=lines(frame,(.30,.39,.72,.52),140)
 if canonical(' '.join(x.text for x in title))!=QUESTION:return None
 cancel=next((x for x in lines(frame,(.36,.55,.50,.64),140) if canonical(x.text)=='отмена'),None)
 accept=next((x for x in lines(frame,(.50,.55,.65,.64),140,hide_gold=True) if canonical(x.text).endswith('ок') and len(canonical(x.text))<=4),None)
 if cancel is None or accept is None:return None
 h,w=frame.shape[:2];crop=frame[round(h*.57):round(h*.62),round(w*.51):round(w*.63)]
 gold=cv2.inRange(cv2.cvtColor(crop,cv2.COLOR_BGR2HSV),(12,100,140),(40,255,255))
 if np.mean(gold>0)<.15:return None
 return FlightDialog(accept.point,cancel.point,stamp(frame))
