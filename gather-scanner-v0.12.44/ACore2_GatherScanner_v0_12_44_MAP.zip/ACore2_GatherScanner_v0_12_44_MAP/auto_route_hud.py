"""The game's own auto-move banner; an OCR failure is not an arrival."""
from dataclasses import dataclass
from difflib import SequenceMatcher
import re
import cv2,pytesseract

@dataclass(frozen=True)
class AutoRouteHUD:
 present:bool|None
 metres:float|None=None

def parse_route(text):
 text=text.lower().replace('ё','е');plain=re.sub('[^а-я]','',text)
 expected='автоперемещение'
 known=(expected in plain or 'автоп' in plain and SequenceMatcher(None,plain[:len(expected)],expected).ratio()>=.72)
 if not known:return AutoRouteHUD(False)
 tail=text[text.find('авто'):] if 'авто' in text else text
 m=re.search(r'(\d{1,4}(?:[.,]\d{1,2})?)\s*[мm]\s*\)?',tail)
 return AutoRouteHUD(True,float(m[1].replace(',','.')) if m else None)

def route_hud(frame):
 h,w=frame.shape[:2];crop=frame[round(h*.665):round(h*.755),round(w*.34):round(w*.67)]
 if not crop.size:return AutoRouteHUD(None)
 gray=cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY);gray=cv2.resize(gray,None,fx=2,fy=2)
 image=cv2.threshold(gray,185,255,cv2.THRESH_BINARY)[1]
 try:text=pytesseract.image_to_string(image,lang='rus',config='--oem 3 --psm 6',timeout=.5)
 except (RuntimeError,pytesseract.TesseractError):return AutoRouteHUD(None)
 return parse_route(text)
