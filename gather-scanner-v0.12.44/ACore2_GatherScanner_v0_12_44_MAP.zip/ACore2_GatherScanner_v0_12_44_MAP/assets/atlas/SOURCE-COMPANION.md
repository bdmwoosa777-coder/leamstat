# Complete possible gathering placements

Source: [nicholascostadev/aion-companion-public](https://github.com/nicholascostadev/aion-companion-public)
at commit `24087a7b7594b10440390617917b263ef0162d10`.
`gather_full.json` is an unchanged copy of `frontend/src/data/gathering-spawns.json`.
SHA-256: `955a618744dbc1a75e4e8b9e702fb4e3325aa66d5e4275ec662fcbd86aa749ec`.
Software/documentation license: MIT, Copyright (c) 2026 Aion Companion contributors;
full notice in LICENSE-COMPANION-MIT.txt. Game data remains copyright
NCSOFT / NC Corporation, separate from the software license, as the source states.

The catalogue records 5,401 possible placements from the original Steam client
3393110 build 26077854, extracted 2026-10-22. It preserves native environment IDs,
XYZ centimetres, category/name joins, source archive/member hashes and provenance.
Verteron: 2,709; Altgard: 2,692 (650 aether, 590 gemstones).
These are potential locations, never a live server census or respawn promise.

Reviewed docs/GATHERING.md, docs/GATHERING_RESEARCH.md and
docs/MAP_POSITION_RESEARCH.md at that commit. No raw game archives, extraction
keys, game-process reader, artwork, executable or third-party runtime are included.
The bot independently reads the static catalogue and uses its existing passive
network decoder for current nearby resource identity/XYZ/remaining attempts.
No gaming.tools bulk marker data was copied.
