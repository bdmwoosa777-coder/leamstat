import unittest
from types import SimpleNamespace
from unittest.mock import patch
import numpy as np
from map_coordinates import fit_world,MapCoordinates,MapGoal
from network_state import Node
from auto_route_hud import parse_route,route_hud

class Calibration(unittest.TestCase):
 def points(self):return [dict(world=[-10000,0],pixel=[100,200]),dict(world=[10000,0],pixel=[300,200]),dict(world=[0,20000],pixel=[200,400])]
 def test_three_landmarks_give_north_up_world_to_reference(self):
  m=np.array(fit_world(self.points()));self.assertTrue(np.allclose(m,[[.01,0,200],[0,.01,200],[0,0,1]]))
 def test_collinear_landmarks_are_rejected(self):
  p=self.points();p[2]=dict(world=[0,0],pixel=[200,200])
  with self.assertRaises(ValueError):fit_world(p)
 def test_wrong_or_rotated_map_is_rejected(self):
  p=self.points();p[2]['pixel']=[250,400]
  with self.assertRaises(ValueError):fit_world(p)
 def test_two_points_cannot_enable_coordinate_clicks(self):
  with self.assertRaises(ValueError):fit_world(self.points()[:2])
 def test_nonfinite_data_is_rejected(self):
  p=self.points();p[2]['world'][0]=float('nan')
  with self.assertRaises(ValueError):fit_world(p)

class ResourceChoice(unittest.TestCase):
 def setUp(self):
  self.c=MapCoordinates.__new__(MapCoordinates);self.c.ready=True;self.c.layer='altgard';self.c.meta={'openZones':[1110],'table':'map'}
  self.c.matrix=np.array([[.01,0,200],[0,.01,200],[0,0,1]]);self.c.inverse=np.linalg.inv(self.c.matrix)
  self.c.zone=np.array([[0,0],[600,0],[600,600],[0,600]],np.float32);self.c.cooldown={};self.c.spec={'exit':[250,200],'air_points':[[400,400]]}
  self.c.atlas=SimpleNamespace(points={'map':{'1':[[10000,0,500]],'2':[[0,10000,0]]}})
  self.s=SimpleNamespace(map_id=1110,nodes={},players={},npcs={},deaths={})
  self.fix={'matrix':np.eye(3),'position':(200,200),'world':(0,0),'viewport':(0,0,800,700)}
  p=patch('map_coordinates.resource_names',return_value={1:'Эфир',2:'Алмаз'});p.start();self.addCleanup(p.stop)
 def test_live_resource_coordinates_are_used_instead_of_old_own_xyz(self):
  self.s.nodes[8]=Node(8,1,xyz=(10000,0,500),used=0,generation=1)
  g=self.c.goals(self.s,self.fix,100)[0];self.assertTrue(g.live);self.assertEqual(g.reference,(300.,200.));self.assertEqual(g.xyz,(10000,0,500))
 def test_exhausted_resource_is_not_reintroduced_by_static_atlas(self):
  self.s.nodes[8]=Node(8,1,xyz=(10000,0,500),used=3)
  goals=self.c.goals(self.s,self.fix,100);self.assertTrue(goals);self.assertTrue(all(g.name!='Эфир' for g in goals))
 def test_static_spawn_is_explicitly_not_proof_of_liveness(self):
  goals=self.c.goals(self.s,self.fix,100);self.assertTrue(goals);self.assertFalse(goals[0].live)
 def test_wrong_map_produces_no_candidates(self):
  self.s.map_id=1010;self.assertEqual(self.c.goals(self.s,self.fix,100),[])
 def test_low_energy_does_not_choose_ether(self):
  self.assertTrue(all(g.name=='Алмаз' for g in self.c.goals(self.s,self.fix,100,False)))
 def test_camp_uses_explicit_exit_not_a_guessed_direction(self):
  g=self.c.goals(self.s,self.fix,100,camp=True)[0];self.assertEqual(g.reference,(250,200));self.assertFalse(g.air)
 def test_escape_uses_only_user_approved_air_points(self):
  self.assertEqual(self.c.goals(self.s,self.fix,100,False,escape=True),[])
  g=self.c.goals(self.s,self.fix,100,True,escape=True)[0];self.assertTrue(g.air);self.assertEqual(g.reference,(400,400))
 def test_outside_viewport_point_is_never_a_click(self):
  self.assertIsNone(self.c.pixel(MapGoal(1,'bad',(900,200)),self.fix))
 def test_deferred_live_node_does_not_block_all_other_atlas_choices(self):
  self.s.nodes[8]=Node(8,1,xyz=(10000,0,500),used=0,generation=1)
  g=self.c.goals(self.s,self.fix,100)[0];self.c.defer(g,100)
  self.assertTrue(all(x.key!=g.key and x.reference!=g.reference for x in self.c.goals(self.s,self.fix,101)))

class AutoHUD(unittest.TestCase):
 def test_exact_banner_and_metres(self):
  r=parse_route('Автоперемещение(48 м)');self.assertTrue(r.present);self.assertEqual(r.metres,48)
 def test_decimal_comma_and_near_arrival(self):self.assertEqual(parse_route('Автоперемещение (2,5 м)').metres,2.5)
 def test_earlier_monster_level_is_not_route_distance(self):self.assertEqual(parse_route('Ур 1 м\nАвтоперемещение(148 м)').metres,148)
 def test_empty_banner_is_absence_not_zero_metres(self):
  r=parse_route('');self.assertFalse(r.present);self.assertIsNone(r.metres)
 def test_flight_altitude_is_not_an_autopath_banner(self):self.assertFalse(parse_route('56.7M 1.7M').present)
 def test_ocr_timeout_is_unknown_not_arrival(self):
  with patch('auto_route_hud.pytesseract.image_to_string',side_effect=RuntimeError('timeout')):self.assertIsNone(route_hud(np.zeros((600,900,3),np.uint8)).present)

if __name__=='__main__':unittest.main()
