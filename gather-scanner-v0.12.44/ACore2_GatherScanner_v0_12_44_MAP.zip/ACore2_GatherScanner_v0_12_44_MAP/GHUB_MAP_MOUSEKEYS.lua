-- G502 HERO: install in one dedicated persistent profile.
-- Button 5 arms the receiver; press it again to leave the receiver.
-- Uses the existing four-strobe LED wire. No W/A/S/D or raw mouse clicks.
-- Windows Mouse Keys must already be enabled; Num Lock is ON at the click.
local ARM_BUTTON=5
local function tap(key)
    PressKey(key);Sleep(35);ReleaseKey(key)
end
local function receiver()
    local prev=IsKeyLockOn("scrolllock")
    local phase,hi,lo=0,0,0
    local last=GetRunningTime()
    OutputLogMessage("[MAP MK] ARMED; button %d exits; PING / M / numeric RMB / verified flight F\n",ARM_BUTTON)
    while not IsMouseButtonPressed(ARM_BUTTON) do
        local now=GetRunningTime()
        if phase~=0 and now-last>850 then phase=0 end
        local clock=IsKeyLockOn("scrolllock")
        if clock and not prev then
            local code=(IsKeyLockOn("capslock") and 2 or 0)+(IsKeyLockOn("numlock") and 1 or 0)
            last=now
            if phase==0 then
                if code==3 then phase=1 end
            elseif phase==1 then hi=code;phase=2
            elseif phase==2 then lo=code;phase=3
            else
                phase=0
                if code==(hi+2*lo+1)%4 then
                    local cmd=hi*4+lo
                    if cmd==0 or cmd==13 or cmd==14 or cmd==15 then
                        local final_caps=IsKeyLockOn("capslock")
                        if not IsKeyLockOn("numlock") then tap("numlock") end
                        if cmd==15 then tap("m") end
                        if cmd==14 then tap("f") end -- only verified flight confirmation
                        if cmd==13 then
                            tap("numminus");Sleep(100)
                            if not IsKeyLockOn("scrolllock") then
                                tap("num5")
                                OutputLogMessage("[MAP MK] numminus + num5 dispatched\n")
                            else cmd=-1;OutputLogMessage("[MAP MK] click cancelled on wire\n") end
                        end
                        -- ACK is the opposite Caps state AFTER execution.
                        -- This confirms Lua dispatch, never in-game arrival.
                        if cmd~=-1 and IsKeyLockOn("capslock")==final_caps then tap("capslock") end
                    else OutputLogMessage("[MAP MK] ignored cmd=%d\n",cmd) end
                else OutputLogMessage("[MAP MK] invalid frame\n") end
            end
        end
        prev=clock;Sleep(12)
    end
    ReleaseKey("numminus");ReleaseKey("num5")
    OutputLogMessage("[MAP MK] STOPPED; click keys released\n")
end
function OnEvent(event,arg)
    if event=="MOUSE_BUTTON_PRESSED" and arg==ARM_BUTTON then
        while IsMouseButtonPressed(ARM_BUTTON) do Sleep(12) end
        receiver()
    end
end
