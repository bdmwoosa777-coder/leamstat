"""One-time visual calibration; never sends gameplay input."""
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox
import cv2,numpy as np
from PIL import Image,ImageTk
from spatial import Atlas
from map_reference import arrow_mask
from map_coordinates import fit_world

ROOT=Path(__file__).resolve().parent

class MapClickSetup:
 def __init__(self,parent,frame,cfg,on_save):
  self.frame=frame;self.cfg=cfg;self.on_save=on_save;self.stage=0;self.start=None;self.box=None
  self.controls=[];self.zone=[];self.exit=None;self.air=[];self.atlas=Atlas();self.anchors=[]
  self.window=tk.Toplevel(parent);self.window.title('Автопуть по большой карте — настройка')
  self.info=ttk.Label(self.window,text='1/5: обведите только область карты справа, без списка слева и верхних вкладок.');self.info.pack(anchor='w',padx=8,pady=6)
  row=ttk.Frame(self.window);row.pack(fill='x',padx=8)
  self.layer=tk.StringVar(value='altgard');ttk.Label(row,text='Карта:').pack(side='left')
  layer=ttk.Combobox(row,textvariable=self.layer,values=tuple(self.atlas.maps),state='readonly',width=14);layer.pack(side='left',padx=5);layer.bind('<<ComboboxSelected>>',self.load_names)
  self.name=tk.StringVar();self.names=ttk.Combobox(row,textvariable=self.name,state='readonly',width=48);self.names.pack(side='left');self.load_names()
  self.point_kind=tk.StringVar(value='Выход из лагеря')
  ttk.Combobox(row,textvariable=self.point_kind,values=('Выход из лагеря','Вершина/точка облёта'),state='readonly',width=25).pack(side='left',padx=5)
  self.scale=min(1300/frame.shape[1],780/frame.shape[0],1)
  im=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));im=im.resize((round(im.width*self.scale),round(im.height*self.scale)))
  self.photo=ImageTk.PhotoImage(im);self.canvas=tk.Canvas(self.window,width=im.width,height=im.height,cursor='crosshair');self.canvas.pack();self.canvas.create_image(0,0,anchor='nw',image=self.photo)
  self.canvas.bind('<ButtonPress-1>',self.down);self.canvas.bind('<B1-Motion>',self.drag);self.canvas.bind('<ButtonRelease-1>',self.up)
  buttons=ttk.Frame(self.window);buttons.pack(fill='x',padx=8,pady=7)
  ttk.Button(buttons,text='Граница зоны готова',command=self.finish_zone).pack(side='left')
  ttk.Button(buttons,text='Убрать последнюю точку',command=self.undo).pack(side='left',padx=5)
  ttk.Button(buttons,text='Сохранить',command=self.save).pack(side='right')
 def load_names(self,event=None):
  if self.stage>=2 and self.anchors:
   self.layer.set(self.saved_layer)
   messagebox.showerror('Карта','После первой опорной точки карту менять нельзя. Закройте настройку и откройте заново.',parent=self.window);return
  self.landmarks={x['names'].get('ru',x['names'].get('en',str(i))):x for i,x in enumerate(self.atlas.kibelisks['maps'].get(self.layer.get(),[]))}
  self.saved_layer=self.layer.get()
  self.names['values']=sorted(self.landmarks);self.name.set('')
 def point(self,event):return (round(event.x/self.scale),round(event.y/self.scale))
 def local(self,p):return (p[0]-self.roi[0],p[1]-self.roi[1])
 def valid(self,p):return self.roi[0]<=p[0]<self.roi[2] and self.roi[1]<=p[1]<self.roi[3]
 def mark(self,p,label,color):
  x,y=(v*self.scale for v in p);self.canvas.create_oval(x-4,y-4,x+4,y+4,fill=color,tags='points');self.canvas.create_text(x+9,y-9,text=label,fill=color,anchor='w',tags='points')
 def down(self,event):
  p=self.point(event)
  if self.stage<2:
   self.start=p
   if self.box:self.canvas.delete(self.box)
   self.box=self.canvas.create_rectangle(event.x,event.y,event.x,event.y,outline='#00ffff',width=2);return
  if not self.valid(p):return
  q=self.local(p)
  if self.stage==2:
   if self.name.get() not in self.landmarks:messagebox.showerror('Ориентир','Выбери название фиолетового кибелиска в списке, затем щёлкни центр его значка на карте.',parent=self.window);return
   if any(a['name']==self.name.get() for a in self.anchors):return
   src=self.landmarks[self.name.get()]
   self.anchors.append(dict(name=self.name.get(),world=[src['x'],src['y']],pixel=list(q)));self.mark(p,str(len(self.anchors)),'#00ffff')
   if len(self.anchors)==3:
    try:self.matrix=fit_world(self.anchors)
    except ValueError as exc:
     self.anchors.pop();self.redraw();messagebox.showerror('Ориентиры',str(exc)+'\nПоследняя точка отменена. Выберите другой ориентир.',parent=self.window);return
    self.stage=3;self.info['text']='4/5: отметьте границу области фарма (минимум три вершины), затем «Граница зоны готова».'
   else:self.info['text']='3/5: ориентир '+str(len(self.anchors)+1)+'/3. Выбери другое название и щёлкни его фиолетовый значок; точки должны быть разнесены.'
  elif self.stage==3:
   self.zone.append(list(q));self.mark(p,'зона','#ffff00')
  elif self.stage==4:
   if self.point_kind.get()=='Выход из лагеря':self.exit=list(q);self.redraw()
   else:self.air.append(list(q));self.mark(p,'облёт '+str(len(self.air)),'#ff88ff')
 def drag(self,event):
  if self.start is not None:self.canvas.coords(self.box,self.start[0]*self.scale,self.start[1]*self.scale,event.x,event.y)
 def up(self,event):
  if self.start is None:return
  a,b=self.start;c,d=self.point(event);self.start=None;x0,x1=sorted((a,c));y0,y1=sorted((b,d))
  if self.stage==0:
   if x0<self.frame.shape[1]*.22 or y0<self.frame.shape[0]*.10 or min(x1-x0,y1-y0)<200:return
   self.roi=(x0,y0,x1,y1);self.stage=1;self.info['text']='2/5: плотно обведите только белую стрелку персонажа на большой карте.'
  elif self.stage==1:
   if not self.valid((x0,y0)) or not self.valid((x1-1,y1-1)):return
   if min(x1-x0,y1-y0)<10 or max(x1-x0,y1-y0)>140:return
   mask=arrow_mask(self.frame[y0:y1,x0:x1]);n=max(mask.shape)+8;self.arrow=np.zeros((n,n),np.uint8)
   oy,ox=(n-mask.shape[0])//2,(n-mask.shape[1])//2;self.arrow[oy:oy+mask.shape[0],ox:ox+mask.shape[1]]=mask
   if np.count_nonzero(mask)<20:return
   self.stage=2;self.info['text']='3/5: выбери название первого кибелиска и щёлкни точно по центру его фиолетового значка (не зелёной галочки). Нужно три разных ориентира.'
 def finish_zone(self):
  if self.stage==3 and len(self.zone)>=3:
   self.stage=4;self.info['text']='5/5: отметь выход ЗА воротами. Дополнительно можно отметить безопасные вершины для облёта, переключив тип точки. Затем «Сохранить».'
 def redraw(self):
  self.canvas.delete('points')
  def absolute(p):return (p[0]+self.roi[0],p[1]+self.roi[1])
  for i,a in enumerate(self.anchors):self.mark(absolute(a['pixel']),str(i+1),'#00ffff')
  for p in self.zone:self.mark(absolute(p),'зона','#ffff00')
  if self.exit:self.mark(absolute(self.exit),'выход','#00ff88')
  for i,p in enumerate(self.air):self.mark(absolute(p),'облёт '+str(i+1),'#ff88ff')
 def undo(self):
  if self.stage==2 and self.anchors:self.anchors.pop()
  elif self.stage==3 and self.zone:self.zone.pop()
  elif self.stage==4:
   if self.point_kind.get()=='Выход из лагеря':self.exit=None
   elif self.air:self.air.pop()
  if self.stage>=2:self.redraw()
 def save(self):
  if self.stage!=4 or self.exit is None:messagebox.showerror('Настройка','Нужны граница фарма и одна точка выхода за воротами.',parent=self.window);return
  folder=ROOT/'assets/map_mousekeys';folder.mkdir(exist_ok=True)
  x0,y0,x1,y1=self.roi;cv2.imwrite(str(folder/'reference.png'),self.frame[y0:y1,x0:x1])
  h,w=self.frame.shape[:2]
  self.cfg['map_mousekeys']=dict(reference='assets/map_mousekeys/reference.png',layer=self.layer.get(),world_matrix=self.matrix,
   roi=[x0/w,y0/h,x1/w,y1/h],frame_width=w,arrow=self.arrow.tolist(),arrow_size=self.arrow.shape[0],zone=self.zone,exit=self.exit,air_points=self.air,anchors=self.anchors)
  self.cfg['map_mousekeys_enabled']=True;self.cfg['world_map_enabled']=False;self.on_save();self.window.destroy()
