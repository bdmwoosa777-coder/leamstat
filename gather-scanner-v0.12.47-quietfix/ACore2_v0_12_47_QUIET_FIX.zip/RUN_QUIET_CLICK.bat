@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 python quiet_click_run.py
) else (
 py -3 quiet_click_run.py
)
pause
