"""Observe only map-wire/numpad keys and mouse buttons. Never inject input."""
import ctypes,os,threading,time

KEY_NAMES={20:'CAPS',144:'NUMLOCK',145:'SCROLL',0x6d:'NUM_MINUS',0x65:'NUM5',0x0c:'CLEAR/NUM5'}
MOUSE_NAMES={0x201:'LEFT_DOWN',0x202:'LEFT_UP',0x204:'RIGHT_DOWN',0x205:'RIGHT_UP'}
def key_record(message,vk,scan,flags):
 if vk not in KEY_NAMES and scan not in (0x4a,0x4c):return None
 return dict(kind='key',action='DOWN' if message in (0x100,0x104) else 'UP',key=KEY_NAMES.get(vk,'NUM_SCAN'),vk=vk,scan=scan,flags=flags)
def mouse_record(message,x,y,flags):
 if message not in MOUSE_NAMES:return None
 return dict(kind='mouse',action=MOUSE_NAMES[message],x=x,y=y,flags=flags)

class ClickObserver:
 def __init__(self):
  self.events=[];self.ready=threading.Event();self.error=None;self.thread=None;self.tid=None;self.user=None;self.origin=time.monotonic()
 def append(self,event):
  if event is not None:self.events.append(dict(at=round(time.monotonic()-self.origin,4),**event))
 def start(self):
  if os.name!='nt':self.error='Windows required';return self
  self.thread=threading.Thread(target=self._run,daemon=True);self.thread.start()
  if not self.ready.wait(2):self.error='hook thread did not become ready'
  return self
 def _run(self):
  from ctypes import wintypes as wt
  ptr=ctypes.c_size_t;result=ctypes.c_ssize_t
  class Kbd(ctypes.Structure):_fields_=[('vk',wt.DWORD),('scan',wt.DWORD),('flags',wt.DWORD),('time',wt.DWORD),('extra',ptr)]
  class Mouse(ctypes.Structure):_fields_=[('point',wt.POINT),('data',wt.DWORD),('flags',wt.DWORD),('time',wt.DWORD),('extra',ptr)]
  proc=ctypes.WINFUNCTYPE(result,ctypes.c_int,wt.WPARAM,wt.LPARAM)
  user=ctypes.WinDLL('user32',use_last_error=True);kernel=ctypes.WinDLL('kernel32',use_last_error=True);self.user=user
  user.SetWindowsHookExW.argtypes=[ctypes.c_int,proc,wt.HINSTANCE,wt.DWORD];user.SetWindowsHookExW.restype=wt.HANDLE
  user.CallNextHookEx.argtypes=[wt.HANDLE,ctypes.c_int,wt.WPARAM,wt.LPARAM];user.CallNextHookEx.restype=result
  user.UnhookWindowsHookEx.argtypes=[wt.HANDLE];user.UnhookWindowsHookEx.restype=wt.BOOL
  user.GetMessageW.argtypes=[ctypes.POINTER(wt.MSG),wt.HWND,wt.UINT,wt.UINT];user.GetMessageW.restype=ctypes.c_int
  user.PeekMessageW.argtypes=[ctypes.POINTER(wt.MSG),wt.HWND,wt.UINT,wt.UINT,wt.UINT];user.PeekMessageW.restype=wt.BOOL
  user.PostThreadMessageW.argtypes=[wt.DWORD,wt.UINT,wt.WPARAM,wt.LPARAM];user.PostThreadMessageW.restype=wt.BOOL
  kernel.GetCurrentThreadId.restype=wt.DWORD
  kernel.GetModuleHandleW.argtypes=[wt.LPCWSTR];kernel.GetModuleHandleW.restype=wt.HMODULE
  def keyboard(code,msg,address):
   if code>=0:
    try:
     value=ctypes.cast(address,ctypes.POINTER(Kbd)).contents
     self.append(key_record(msg,value.vk,value.scan,value.flags))
    except Exception:pass
   return user.CallNextHookEx(None,code,msg,address)
  def mouse(code,msg,address):
   if code>=0:
    try:
     value=ctypes.cast(address,ctypes.POINTER(Mouse)).contents
     self.append(mouse_record(msg,value.point.x,value.point.y,value.flags))
    except Exception:pass
   return user.CallNextHookEx(None,code,msg,address)
  callbacks=[proc(keyboard),proc(mouse)];hooks=[]
  try:
   self.tid=kernel.GetCurrentThreadId();message=wt.MSG();user.PeekMessageW(ctypes.byref(message),None,0,0,0)
   for kind,callback in zip((13,14),callbacks):
    handle=user.SetWindowsHookExW(kind,callback,kernel.GetModuleHandleW(None),0)
    if not handle:raise ctypes.WinError(ctypes.get_last_error())
    hooks.append(handle)
   self.ready.set()
   while True:
    status=user.GetMessageW(ctypes.byref(message),None,0,0)
    if status==0:break
    if status<0:raise ctypes.WinError(ctypes.get_last_error())
  except Exception as exc:self.error=str(exc);self.ready.set()
  finally:
   for handle in reversed(hooks):user.UnhookWindowsHookEx(handle)
 def close(self):
  if self.user is not None and self.tid is not None:self.user.PostThreadMessageW(self.tid,0x12,0,0)
  if self.thread is not None:self.thread.join(timeout=2)
