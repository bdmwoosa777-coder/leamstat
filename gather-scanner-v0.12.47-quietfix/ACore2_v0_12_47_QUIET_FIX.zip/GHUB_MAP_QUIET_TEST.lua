-- QUIET TEST ONLY / MAP WIRE V2, G502 HERO. Replace the old map Lua, Save & Run, press G9.
-- Windows Mouse Keys and Num Lock must already be ON.
-- Num Lock is NEVER pressed: it may be the game's autorun hotkey.
-- CapsLock = one data bit, ScrollLock = clock. 010 + hi + lo + XOR.
local ARM_BUTTON=9
local MACRO_NAME="AION_MAP_RMB"
local MACRO_SETTLE_MS=500
local PRE_MACRO_QUIET_MS=2000
local function tap(key)
    PressKey(key);Sleep(50);ReleaseKey(key)
end
local function receiver()
    local prev=IsKeyLockOn("scrolllock")
    local phase,hi,lo=0,0,0
    local last=GetRunningTime()
    OutputLogMessage("[MAP QUIET TEST] G9 ARMED; test only, two seconds quiet before macro; Num Lock untouched\n")
    while true do
        local now=GetRunningTime()
        if phase~=0 and now-last>850 then phase=0 end
        local clock=IsKeyLockOn("scrolllock")
        if not IsKeyLockOn("numlock") then phase=0 end
        if clock and not prev and IsKeyLockOn("numlock") then
            local bit=IsKeyLockOn("capslock") and 1 or 0
            last=now
            if phase==0 then
                if bit==0 then phase=1 end
            elseif phase==1 then
                if bit==1 then phase=2 else phase=1 end
            elseif phase==2 then
                if bit==0 then phase=3 else phase=0 end
            elseif phase==3 then hi=bit;phase=4
            elseif phase==4 then lo=bit;phase=5
            else
                phase=0
                if bit==(hi+lo)%2 then
                    local cmd=hi*2+lo
                    local final_caps=IsKeyLockOn("capslock")
                    local receipt_sent=false
                    -- Let the host finish the last strobe before any action.
                    local until_low=GetRunningTime()+350
                    while IsKeyLockOn("scrolllock") and GetRunningTime()<until_low do Sleep(12) end
                    local allowed=not IsKeyLockOn("scrolllock") and IsKeyLockOn("numlock")
                    if allowed and cmd==1 then
                        -- TEST ONLY: ACK means receipt, not macro completion.
                        if IsKeyLockOn("capslock")==final_caps then tap("capslock") end
                        receipt_sent=true
                        local quiet=GetRunningTime()+PRE_MACRO_QUIET_MS
                        while allowed and GetRunningTime()<quiet do
                            if IsKeyLockOn("scrolllock") or not IsKeyLockOn("numlock") then allowed=false
                            else Sleep(12) end
                        end
                        if allowed then
                        local ok,err=pcall(PlayMacro,MACRO_NAME)
                        allowed=ok
                        if not ok then OutputLogMessage("[MAP QUIET TEST] PlayMacro error: %s\n",tostring(err)) end
                        local settle=GetRunningTime()+MACRO_SETTLE_MS
                        while allowed and GetRunningTime()<settle do
                            if IsKeyLockOn("scrolllock") or not IsKeyLockOn("numlock") then
                                AbortMacro();allowed=false
                                OutputLogMessage("[MAP QUIET TEST] macro aborted on cancellation\n")
                            else Sleep(12) end
                        end
                        if allowed then OutputLogMessage("[MAP QUIET TEST] PlayMacro AION_MAP_RMB dispatched; game path still needs confirmation\n") end
                        end
                    elseif cmd~=0 then allowed=false end
                    if allowed then
                        -- ACK only after key release, never an in-game success.
                        if not receipt_sent and IsKeyLockOn("capslock")==final_caps then tap("capslock") end
                        OutputLogMessage("[MAP V2] ACK cmd=%d\n",cmd)
                    else OutputLogMessage("[MAP V2] ABORT; no ACK\n") end
                else OutputLogMessage("[MAP V2] invalid parity\n") end
            end
        end
        prev=clock;Sleep(12)
    end
end
function OnEvent(event,arg)
    if event=="MOUSE_BUTTON_PRESSED" and arg==ARM_BUTTON then receiver() end
end
