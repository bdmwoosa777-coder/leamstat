"""Exclusive map navigation; the existing resource collection stays intact."""
REQUIRED={
 'map_autopath_required':True,'map_use_builtin':True,
 'scene_navigation_enabled':False,'analyzer_enabled':False,'qwen_wait_before_start':False,
 'ground_walk':False,'patrol_sprint':False,'terrain_experience_enabled':False,
 'hybrid_camp_exit':False,'post_tp_back_exit_enabled':False,'recorded_camp_exit_enabled':False,
 'ground_route_navigation':False,'terrain_rescue_enabled':False,'patrol_escape_enabled':False,
 'flight_probe_enabled':False,'world_map_enabled':False,'area_search_rescue':False,
}
RECOMMENDED={**REQUIRED,'map_mousekeys_enabled':True,'map_mousekeys_fly_long':True,
 'network_enabled':True,'allow_click':True,'assist_manual_target':True,'minimap_search':True,
 'only_aether':True,'camera_scan':True,'protect_player':True,'camera_auto_calibrate':True,
 'nearby_ground_exception':False,'dry_run':False}

def effective(cfg):
 result=dict(cfg)
 if cfg.get('map_mousekeys_enabled') and cfg.get('map_autopath_required',False):result.update(REQUIRED)
 return result

def initial_options(cfg):
 """Apply the user's requested working checkboxes once on this update.

 Keep map/camera/device calibration, resource names and return destination.
 Later explicit edits (including observation mode) remain user choices.
 """
 result=dict(cfg)
 if result.get('autopath_preset_revision')!=51:
  result.update(RECOMMENDED)
  result.update(map_safe_return_enabled=True,resource_click_interaction=True,
                preserve_owned_resource=True,repeat_owned_clicks=True,scan_frame_checks=True,
                control_transport='xbox',click_backend='gamepad',autopath_preset_revision=51)
 return effective(result)
