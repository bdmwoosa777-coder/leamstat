"""A bounded local resource inspection, measured after the camera is ready."""
from dataclasses import dataclass

@dataclass
class ArrivalSearch:
 goal:object
 created:float
 initial:bool=False
 elapsed:float=0.
 observed:int=0
 last:float|None=None
 next_probe:float=0.
 candidate_until:float=0.
 terminal:object=None
 def pause(self,now):self.last=now
 def observe(self,now):
  if self.last is not None:self.elapsed+=max(0,min(3.,now-self.last))
  self.last=now;self.observed+=1
 @property
 def limit(self):return 6. if self.initial else 14.
 def expired(self,now):return self.observed>=2 and self.elapsed>=self.limit or now-self.created>=45
