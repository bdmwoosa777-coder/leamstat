"""Bounded final approach AFTER game path arrival, using a current minimap.

No map clicks or resource actions here. A visible caption immediately gives
control to the existing native selection/collection state machine.
"""
from dataclasses import replace
import math
from navigation import Drive
from minimap import angle_delta
from camera_control import PITCH_STRENGTH

class FinalApproach:
 def __init__(self,goal,position=None):
  self.goal=goal;self.position=position;self.marker=None;self.authorized_until=0.
  self.walked=0.;self.turns=0.;self.next_action=0.;self.last_sent=None
  self.best=None;self.stalls=0;self.heading_search=0
 def permits_translation(self,now):return now<=self.authorized_until and self.authorized_until>0 and self.walked<2.2
 def revoke(self):self.authorized_until=0.
 def marker_for(self,radar):
  if radar is None:return None
  kind='aether' if 'эфир' in self.goal.name.lower() else 'gem'
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  options=[m for m in radar.markers if m.kind==kind and m.distance<=90*scale]
  if not options:return None
  if self.marker is not None:
   dx,dy=radar.displacement if radar.motion_valid else (0,0)
   near=[m for m in options if math.hypot(m.x-self.marker.x-dx,m.y-self.marker.y-dy)<=15*scale]
   if not near:return None # Do not jump between neighbouring resource marks.
   chosen=min(near,key=lambda m:math.hypot(m.x-self.marker.x-dx,m.y-self.marker.y-dy))
  else:
   expected=None
   if self.position is not None and self.goal.xyz is not None:
    dx,dy=self.goal.xyz[0]-self.position[0],self.goal.xyz[1]-self.position[1]
    if math.hypot(dx,dy)>500:expected=math.degrees(math.atan2(dx,-dy))%360
   def score(m):
    bearing=math.degrees(math.atan2(m.x-radar.center[0],radar.center[1]-m.y))%360
    return (0 if expected is None or abs(angle_delta(bearing,expected))<35 else 1,m.distance)
   chosen=min(options,key=score)
  self.marker=replace(chosen);return chosen
 def plan(self,radar,now,pitch,working_ms=1200):
  self.revoke()
  ether='эфир' in self.goal.name.lower()
  target_pitch=PITCH_STRENGTH*min(1.25,max(.45,working_ms/1000))
  marker=self.marker_for(radar)
  if marker is None:
   if ether and now>=self.next_action and pitch<target_pitch-.008:
    return Drive(pitch=PITCH_STRENGTH,lifetime=min(.27,max(.05,(target_pitch-pitch)/PITCH_STRENGTH)),
                 local_approach=True,reason='MAP_FINAL_LOOK_UP: прибыл к эфиру, ищу подпись выше без слепого шага')
   return Drive(reason='MAP_FINAL_WAIT: жду свежую отметку того же ресурса')
  scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
  distance=math.hypot(marker.x-radar.center[0],marker.y-radar.center[1])/scale
  if self.best is None or distance<self.best-1:self.best=distance;self.stalls=0
  if now<self.next_action:return Drive(reason='MAP_FINAL_HOLD: сохраняю ракурс для распознавания')
  heading=radar.heading if radar.confidence>=.30 else None
  bearing=math.degrees(math.atan2(marker.x-radar.center[0],radar.center[1]-marker.y))%360
  error=angle_delta(bearing,heading) if heading is not None else None
  if ether and error is None and pitch<target_pitch-.008:
   return Drive(pitch=PITCH_STRENGTH,lifetime=min(.27,max(.05,(target_pitch-pitch)/PITCH_STRENGTH)),
                local_approach=True,reason='MAP_FINAL_LOOK_UP: конус не читается, ищу эфир вверх без движения')
  if distance>5 and (error is None or abs(error)>18):
   if self.turns>=4:return Drive(reason='MAP_FINAL_WAIT: предел поворота, жду новое распознавание')
   if error is None:
    if self.heading_search>=2:return Drive(reason='MAP_FINAL_WAIT: конус камеры не подтверждён')
    yaw=.48;seconds=.35
   else:yaw=math.copysign(.48,error);seconds=min(.65,max(.18,abs(error)/130))
   return Drive(yaw=yaw,lifetime=seconds,yaw_lifetime=seconds,local_approach=True,
                reason='MAP_FINAL_AIM: поворачиваю камеру к отметке ресурса')
  if not ether and abs(pitch)>.02:
   return Drive(pitch=-math.copysign(PITCH_STRENGTH,pitch),lifetime=min(.30,abs(pitch)/PITCH_STRENGTH),
                local_approach=True,reason='MAP_FINAL_GROUND_VIEW: возвращаю наземный ресурс в обзор')
  # Raise the view before walking to Ether and keep that tilt while closing
  # in. Use the delivered pitch ledger, not elapsed OCR/wall-clock phases.
  if ether and pitch<min(.16,target_pitch)-.008:
   return Drive(pitch=PITCH_STRENGTH,lifetime=min(.32,max(.05,(min(.16,target_pitch)-pitch)/PITCH_STRENGTH)),
                local_approach=True,reason='MAP_FINAL_LOOK_UP: поднимаю камеру к эфиру')
  if distance>5 and self.walked<2.2 and self.stalls<3 and error is not None:
   seconds=min(.45,2.2-self.walked);self.authorized_until=now+.45
   return Drive(forward=.5,lifetime=seconds,tilted_motion=True,local_approach=True,
                reason='MAP_FINAL_CLOSE: коротко сближаюсь с отметкой, сохраняя поднятую камеру')
  if ether and pitch<target_pitch-.008:
   return Drive(pitch=PITCH_STRENGTH,lifetime=min(.27,max(.05,(target_pitch-pitch)/PITCH_STRENGTH)),
                local_approach=True,reason='MAP_FINAL_LOOK_UP: ищу эфир выше, направление сохраняется')
  return Drive(reason='MAP_FINAL_HOLD: держу ресурс в секторе камеры, жду подпись')
 def delivered(self,forward,strafe,yaw,pitch,seconds,now):
  if abs(forward)+abs(strafe)+abs(yaw)+abs(pitch)<=.001:return
  if abs(forward)+abs(strafe)>.001:
   self.walked+=seconds;self.stalls+=1
  if abs(yaw)>.001:
   self.turns+=seconds;self.heading_search+=1
  self.last_sent=now;self.next_action=now+seconds+.20
