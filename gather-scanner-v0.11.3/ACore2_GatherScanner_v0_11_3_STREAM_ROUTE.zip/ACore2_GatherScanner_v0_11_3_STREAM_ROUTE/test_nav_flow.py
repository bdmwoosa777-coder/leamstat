"""Scheduling and state regressions observed in the private field report.

No user logs/screenshots are part of these deterministic tests.
"""
import math,unittest
from unittest.mock import patch
from types import SimpleNamespace
import gather_engine as ge
from scene_navigation import ScenePilot,SceneReading,Lane
from navigation import Drive,Navigator
from camera_pitch import PitchLedger
from area_recovery import AreaRecovery
from flight import FlightReading
from test_navigation import GatherFixture,obs,radar
from test_network_control import Source

FREE=Lane(.98,0,0,.02)
WALL=Lane(.01,.85,0,.1)
AIR=FlightReading(80,True)

def reading(lanes,seq=1):return SceneReading(100,0,0,seq,tuple(lanes))

class NavFlow(unittest.TestCase):
 def test_weak_depth_texture_over_ground_does_not_cause_side_steps(self):
  lanes=[Lane(.98,0,.024,.02)]*3
  a=ScenePilot().decide(Drive(.78),reading(lanes),100,80)
  self.assertGreater(a.drive.forward,.6);self.assertEqual(a.drive.strafe,0)
 def test_strong_discontinuity_still_blocks_even_with_ground_labels(self):
  a=ScenePilot().decide(Drive(.78),reading([Lane(1,0,.14,0)]*3),100,80)
  self.assertEqual(a.drive.forward,0);self.assertFalse(a.fly)
 def test_slow_half_second_frames_do_not_expire_each_detour_early(self):
  p=ScenePilot();deadline=0
  for tick in range(20):
   now=100+tick*.55
   if tick:self.assertGreaterEqual(deadline,now)
   a=p.decide(Drive(.7),reading([FREE,WALL,WALL],tick),now,80)
   self.assertLess(a.drive.strafe,0);self.assertLessEqual(a.drive.lifetime,.85)
   deadline=now+a.drive.lifetime
 def test_missing_frames_between_camera_turns_do_not_add_stops(self):
  p=ScenePilot()
  for i in range(20):
   a=p.decide(Drive(.7),None if i%2 else reading([FREE]*3,i),100+i*.55)
   self.assertGreater(a.drive.forward,.6)
 def test_primary_steering_converges_without_an_extra_scene_turn_controller(self):
  n=Navigator({});p=ScenePilot();heading=0;progress=0
  for i in range(32):
   now=100+i*.55;plan=n._move_to(120,heading,now,'resource')
   action=p.decide(plan,reading([FREE]*3,i),now,80)
   self.assertEqual(action.drive.yaw,plan.yaw)
   if plan.yaw:self.assertEqual(action.drive.yaw_lifetime,plan.yaw_lifetime)
   yaw_time=min(.55,action.drive.yaw_lifetime or 0)
   heading=(heading+action.drive.yaw*yaw_time*400)%360
   progress+=math.cos(math.radians(120-heading))*action.drive.forward+math.sin(math.radians(120-heading))*action.drive.strafe
  self.assertLess(abs((120-heading+180)%360-180),20)
  self.assertGreater(progress,12)

class PitchFlow(unittest.TestCase):
 def test_minimum_pulse_residual_is_consumed_before_translation_gate(self):
  for residual in (.007,-.009,.011,-.011):
   p=PitchLedger();p.balance=residual;p.restore(100)
   self.assertFalse(p.returning);self.assertEqual(p.offset(100),0)
 def test_correction_accepts_scheduler_sized_residual_without_reversing(self):
  p=PitchLedger();p.balance=.010;p.returning=True;p.return_end=110
  self.assertEqual(p.correction(100),0);self.assertFalse(p.returning)
 def test_large_error_is_not_erased_by_deadband(self):
  p=PitchLedger();p.balance=.2;p.restore(100)
  self.assertTrue(p.returning);self.assertAlmostEqual(p.offset(100),.2)

class RescueFlow(unittest.TestCase):
 def scan(self):
  r=AreaRecovery(100,80);r.phase='SCAN';r.since=110;r.cycles=1;return r
 def test_no_coordinates_descends_instead_of_another_ascent(self):
  r=self.scan();a=r.step(117,AIR,0)
  self.assertFalse(a.done);self.assertEqual(r.phase,'DESC_DOWN');self.assertIsNone(a.command)
 def test_only_a_real_height_gap_permits_a_repeat(self):
  r=self.scan();a=r.step(117,AIR,0,height_gap=20)
  self.assertEqual(r.phase,'DOWN');self.assertLess(a.drive.pitch,0)
 def test_known_near_level_also_checks_descent(self):
  r=self.scan();self.assertFalse(r.step(117,AIR,0,height_gap=1).done);self.assertEqual(r.phase,'DESC_DOWN')
 def test_no_resource_result_never_claims_a_landing_or_sends_v(self):
  r=self.scan();a=r.step(117,AIR,0)
  self.assertFalse(a.done);self.assertEqual(r.phase,'DESC_DOWN');self.assertIsNone(a.command)
 def test_hard_deadline_exits_even_a_stuck_rise(self):
  r=AreaRecovery(100,80);r.phase='RISE';r.since=140
  a=r.step(146,AIR,0,height_gap=20)
  self.assertTrue(a.done);self.assertIsNone(a.command)
 def test_failed_camera_return_is_explicit_instead_of_another_rescue(self):
  r=AreaRecovery(100,80);r.phase='LEVEL';r.since=100;r.homed=False
  a=r.step(107,AIR,.2)
  self.assertTrue(a.done);self.assertTrue(a.camera_failed);self.assertFalse(a.levelled)
 def test_descent_fallback_does_not_repeat_forever(self):
  r=AreaRecovery(100,80);r.phase='DESCEND';r.since=100
  r.step(108.1,AIR,-.9);self.assertEqual(r.phase,'DRIFT')
  r.step(110.2,AIR,-.9);self.assertEqual(r.phase,'LEVEL')
  a=r.step(111.3,AIR,-.9+.45*.94)
  self.assertTrue(a.done);self.assertIsNone(a.command)
 def test_full_rescue_with_slow_frames_is_finite_and_translation_is_renewed(self):
  r=AreaRecovery(100,80);balance=0;commands=[];air=False;done=False
  for i in range(90):
   now=100+i*.6;a=r.step(now,FlightReading(80 if air else None,air),balance)
   if a.command:
    commands.append(a.command);air=True;r.sent(a.command,now)
   if a.drive:
    if abs(a.drive.forward)+abs(a.drive.strafe)>.01:self.assertGreaterEqual(a.drive.lifetime,.6)
    balance+=a.drive.pitch*min(.6,max(.02,a.drive.lifetime))
   if a.levelled:balance=0
   if a.done:done=True;break
  self.assertTrue(done);self.assertLess(now-100,45);self.assertEqual(commands,['V'])

class AcquireFlow(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.e.mode='ACQUIRE_WAIT';self.e.candidate=self.c
  self.e.candidate_since=100;self.e.candidate_sequence=1
 def test_same_ocr_sequence_can_refind_caption_on_new_frame(self):
  with patch.object(ge,'find_resource_near',return_value=self.c),patch.object(self.e,'click_candidate',return_value=True) as click:
   self.step(obs(candidate=self.c),100.3)
   click.assert_called_once()
 def test_old_ocr_never_authorizes_a_click_without_current_caption(self):
  with patch.object(ge,'find_resource_near',return_value=None),patch.object(self.e,'click_candidate') as click:
   self.step(obs(candidate=self.c),100.3);click.assert_not_called()
 def test_missing_ocr_does_not_suspend_the_fresh_frame_confirmation_step(self):
  self.assertIsNotNone(self.e._navigation_observation(None,100.3))
 def test_active_collection_still_blocks_missing_ocr_acquisition(self):
  self.e.resource_hold=True
  self.assertIsNone(self.e._navigation_observation(None,100.3))

class RescueEngineFlow(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e.network=self.source;self.e.mode='RESCUE';self.e.cfg['area_search_rescue']=True
  self.e.terrain_recovery=AreaRecovery(100,80)
  self.e.terrain_recovery.long_attempt=True
 def test_failed_camera_stage_rehomes_once_instead_of_starting_another_rescue(self):
  r=self.e.terrain_recovery;r.phase='LEVEL';r.since=100;r.homed=False
  self.e.pitch.balance=.2;self.e.pitch.failed=True
  with patch.object(self.e,'_calibrate_camera',return_value=True) as calibrate:
   self.assertTrue(self.e._terrain_recovery_tick(self.frame,AIR,107,radar()))
   calibrate.assert_called_once()
  self.assertIsNone(self.e.terrain_recovery);self.assertEqual(self.e.mode,'SEARCH')
  self.assertNotIn('V',self.commands)
 def test_scan_completion_keeps_control_in_descent_with_wings_untoggled(self):
  r=self.e.terrain_recovery;r.phase='SCAN';r.since=100
  with patch.object(ge.time,'monotonic',return_value=107):self.assertTrue(self.e._terrain_recovery_tick(self.frame,AIR,107,radar()))
  self.assertIs(self.e.terrain_recovery,r);self.assertEqual(self.e.mode,'RESCUE');self.assertEqual(r.phase,'DESC_DOWN')
  with patch.object(ge.time,'monotonic',return_value=108):self.assertTrue(self.e._terrain_recovery_tick(self.frame,AIR,108,radar()))
  self.assertNotIn('END_AIR',self.commands)
 def test_new_collection_revokes_a_long_rescue_translation_lease(self):
  self.e._motion(Drive(.6,lifetime=.65,tilted_motion=True));self.assertGreater(self.pad.axes[1],0)
  s=self.source.state;s.collecting=99;s.attempt_active=True;s.nodes[99].gather_time=1000
  self.e._terrain_recovery_tick(self.frame,AIR,107,radar())
  self.assertEqual(self.pad.axes,(0,0,0,0));self.assertIsNone(self.e.terrain_recovery)
  self.e._motion(Drive(.6,lifetime=.65,tilted_motion=True));self.assertEqual(self.pad.axes,(0,0,0,0))

if __name__=='__main__':unittest.main()
