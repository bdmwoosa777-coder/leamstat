"""Record with the user's CubeRadar, then export a small semantic report.
No game input, injection, packet sending, driver installation or automatic download.
"""
import argparse
from collections import Counter
from datetime import datetime
import json
import math
from pathlib import Path
import struct
import subprocess
import sys
import zipfile

ROOT=Path(__file__).resolve().parent
LABELS={'sapphire_selected','aether_selected','first_gather','attempt_completed','resource_depleted'}
HOTKEYS=','.join('ctrl+alt+F%d=%s'%(n,label) for n,label in enumerate(
    ('sapphire_selected','aether_selected','first_gather','attempt_completed','resource_depleted'),5))
OBJECT_OPS={'3436','3536','3836','3a36'}
MAX_LINE=2*1024*1024
CATALOGUE=json.loads((ROOT/'gather_catalogue.json').read_text(encoding='utf-8-sig'))


def uint_varint(data,offset=0):
    value=0
    for shift in range(0,35,7):
        if offset>=len(data):raise ValueError('truncated id')
        byte=data[offset];offset+=1;value|=(byte&127)<<shift
        if not byte&128:
            if value>0xffffffff:raise ValueError('id overflow')
            return value,offset
    raise ValueError('id overflow')


def object_event(op,data):
    """Documented CubeRadar object layouts, NOT verified resource layouts.
    Never interpret a generic interaction as a successful gather or depletion.
    """
    oid,offset=uint_varint(data)
    if not oid:raise ValueError('zero object id')
    base={'op':op,'object_id':oid,'resource_identity_verified':False}
    if op=='3436':
        if len(data)<offset+26:raise ValueError('truncated spawn')
        kind,template=struct.unpack_from('<HI',data,offset)
        xyz=struct.unpack_from('<fff',data,offset+6)
        heading=struct.unpack_from('<f',data,offset+22)[0]
        if not all(math.isfinite(v) for v in (*xyz,heading)):raise ValueError('nonfinite position')
        if abs(xyz[0])>=420000 or abs(xyz[1])>=420000 or abs(xyz[2])>=120000:raise ValueError('position outside documented bounds')
        event=dict(base,event='object_spawn',kind=kind,template_id=template,x=xyz[0],y=xyz[1],z=xyz[2],heading=heading)
        # Restrict to the exact documented resource profile, not generic cubes.
        if kind==4 and len(data)-offset==52 and str(template) in CATALOGUE:
            used=struct.unpack_from('<I',data,offset+37)[0]
            if used<=3:
                event.update(gather_name_en=CATALOGUE[str(template)]['en'],
                             consumed_attempts_candidate=used,
                             profile_signature='known-gather-52-byte/global',
                             verified_for_this_game_session=False)
        return event
    if op=='3536':
        if offset>=len(data):raise ValueError('truncated remove')
        return dict(base,event='object_remove',reason=data[offset])
    actor,offset=uint_varint(data,offset)
    if op=='3836':return dict(base,event='object_interaction_start',actor_id=actor)
    if op=='3a36':
        if len(data)<offset+8:raise ValueError('truncated interaction')
        count,item=struct.unpack_from('<II',data,offset)
        return dict(base,event='object_interaction_done',actor_id=actor,count=count,item_id=item)
    raise ValueError('unsupported opcode')


def records(path):
    with path.open('r',encoding='utf-8-sig',errors='replace') as stream:
        while True:
            line=stream.readline(MAX_LINE+1)
            if not line:break
            if len(line)>MAX_LINE:
                while line and not line.endswith('\n'):line=stream.readline(MAX_LINE+1)
                yield None;continue
            try:
                row=json.loads(line)
                yield row if isinstance(row,dict) else None
            except (ValueError,TypeError):yield None


def analyze(directory):
    directory=Path(directory).resolve();frames=directory/'frames.jsonl'
    if not frames.is_file():raise RuntimeError('В выбранной папке нет frames.jsonl')
    counts=Counter();events=[];times=[];seen=set();malformed=0;failed_objects=Counter()
    for row in records(frames):
        if row is None:malformed+=1;continue
        if row.get('type')!='frame':continue
        op=str(row.get('op','')).lower().replace(' ','')
        if len(op)!=4 or any(c not in '0123456789abcdef' for c in op):malformed+=1;continue
        t=row.get('t')
        if not isinstance(t,(int,float)) or isinstance(t,bool) or not math.isfinite(t):malformed+=1;continue
        counts[op]+=1;times.append((t,op))
        if op not in OBJECT_OPS:continue
        # Decoder sequence IDs identify duplicate exports without suppressing
        # independent real events that happen to have the same body/time.
        key=(row.get('flow'),row.get('n'))
        if key[1] is not None and key in seen:continue
        if key[1] is not None:seen.add(key)
        try:
            raw=bytes.fromhex(row.get('hex',''));event=object_event(op,raw)
        except (ValueError,TypeError,struct.error):failed_objects[op]+=1;continue
        event['t']=t
        if isinstance(row.get('flow'),int):event['flow']=row['flow']
        events.append(event)
    markers=[];markfile=directory/'markers.jsonl'
    if markfile.is_file():
        for row in records(markfile):
            if row and row.get('label')=='note' and row.get('text') in LABELS:
                row=dict(row,label=row['text'])
            if row and row.get('label') in LABELS and isinstance(row.get('t'),(int,float)) and not isinstance(row.get('t'),bool) and math.isfinite(row['t']):
                t=row['t'];window=Counter(op for at,op in times if abs(at-t)<=1500)
                objects=sorted({e['object_id'] for e in events if abs(e['t']-t)<=1500})
                markers.append({'t':t,'label':row['label'],'nearby_object_ids':objects,'opcodes_within_1500ms':dict(window)})
    templates=Counter(e['template_id'] for e in events if e['event']=='object_spawn')
    report={'tool':'ACore2_Network_Probe_v0_1','frames':sum(counts.values()),'opcodes':dict(counts),
        'object_events':len(events),'object_templates':dict(templates),'markers':markers,
        'candidate_resource_profiles':sum('gather_name_en' in e for e in events),
        'malformed_lines':malformed,'undecodable_object_messages':dict(failed_objects),
        'resource_support_confirmed':False,
        'limits':['Object layouts are taken from CubeRadar Global documentation and may differ in your region/build.',
                  'Temporal coincidence with a marker does not prove resource identity.',
                  'Remove reasons and interaction completion do not prove resource depletion or a successful gather.',
                  'No current HP, selected target, wing energy or fresh player position is inferred.']}
    output=directory/'probe_report';output.mkdir(exist_ok=True)
    (output/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (output/'object_events.jsonl').write_text(''.join(json.dumps(e,ensure_ascii=False)+'\n' for e in events),encoding='utf-8')
    archive=directory/'probe_report.zip'
    # Explicit two-file allowlist: no raw payloads, packets, names/chat or paths.
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for name in ('report.json','object_events.jsonl'):z.write(output/name,name)
    print('Кадров:',report['frames'],'событий объектов:',len(events),'отметок:',len(markers))
    print('Отчёт:',archive)
    if not report['frames']:print('Трафик не распознан. Это не подтверждает отсутствие ресурсов.')
    elif not events:print('Объектные сообщения этой схемы не найдены. Нужен дальнейший разбор протокола.')
    print('Профилей ресурсов по известной схеме:',report['candidate_resource_profiles'])
    print('Совпадения нужно сверить с ручными отметками; управление ботом не подключено.')
    return archive


def choose_exe():
    for name in ('Cube.Radar.exe','Cube Radar.exe','cuberadar.exe'):
        candidate=ROOT/name
        if candidate.is_file():return candidate
    import tkinter as tk
    from tkinter import filedialog
    window=tk.Tk();window.withdraw()
    try:chosen=filedialog.askopenfilename(title='Выберите Cube.Radar.exe — исполняемый файл CubeRadar',filetypes=[('CubeRadar','*.exe')])
    finally:window.destroy()
    if not chosen:raise RuntimeError('Выбор CubeRadar отменён')
    return Path(chosen)


def capture_command(exe,destination,seconds):
    return [str(exe),'dump','live','--seconds',str(seconds),'--out',str(destination),
            '--no-heartbeat','--hotkeys',HOTKEYS]


def main(argv=None):
    parser=argparse.ArgumentParser(description='Отдельная сетевая диагностика; управление ботом не запускается.')
    parser.add_argument('--exe',type=Path);parser.add_argument('--seconds',type=int,default=180)
    parser.add_argument('--analyze',type=Path)
    args=parser.parse_args(argv)
    if args.analyze:analyze(args.analyze);return 0
    if sys.platform!='win32':raise RuntimeError('Живая запись требует Windows, Npcap и CubeRadar. Анализ файлов работает отдельно.')
    if not 30<=args.seconds<=600:raise RuntimeError('Длительность должна быть от 30 до 600 секунд')
    exe=(args.exe or choose_exe()).resolve()
    if not exe.is_file():raise RuntimeError('Исполняемый файл CubeRadar не найден')
    destination=ROOT/'captures'/datetime.now().strftime('probe_%Y%m%d_%H%M%S_%f')
    destination.mkdir(parents=True)
    print('Запись',args.seconds,'секунд. Сканер сбора должен быть остановлен; действия выполняйте вручную.',flush=True)
    print('Ctrl+Alt+F5 — сапфир выбран; F6 — эфир выбран; F7 — появилась нижняя плашка;',flush=True)
    print('Ctrl+Alt+F8 — закончилась одна попытка; F9 — ресурс полностью исчез.',flush=True)
    result=subprocess.run(capture_command(exe,destination,args.seconds),cwd=exe.parent,check=False)
    sessions=sorted(destination.glob('*/frames.jsonl'))
    if result.returncode:print('CubeRadar завершился с кодом',result.returncode)
    if not sessions:raise RuntimeError('frames.jsonl не создан. Проверьте Npcap и вывод CubeRadar; записи находятся в '+str(destination))
    for framefile in sessions:analyze(framefile.parent)
    return result.returncode


if __name__=='__main__':
    try:raise SystemExit(main())
    except (OSError,RuntimeError,ValueError) as exc:
        print('ОШИБКА:',exc,file=sys.stderr);raise SystemExit(1)
