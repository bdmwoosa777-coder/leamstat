import contextlib
import io
import json
from pathlib import Path
import struct
import tempfile
import unittest
import zipfile
import probe


def varint(n):
    data=bytearray()
    while n>=128:data.append((n&127)|128);n>>=7
    data.append(n);return bytes(data)


class ProbeTests(unittest.TestCase):
    def test_public_real_cube_fixture_positions_and_lifecycle(self):
        fixture=json.loads((Path(__file__).parent/'cube_fixture.json').read_text())
        events=[probe.object_event(row['op'],bytes.fromhex(row['hex'])) for row in fixture['frames'] if row['op'] in probe.OBJECT_OPS]
        self.assertEqual(len(events),8)
        for cube in fixture['cubes']:
            spawn=next(e for e in events if e['object_id']==cube['id'] and e['event']=='object_spawn')
            self.assertEqual(spawn['template_id'],cube['template'])
            for axis in 'xyz':self.assertAlmostEqual(spawn[axis],cube[axis],places=2)
            self.assertFalse(spawn['resource_identity_verified']);self.assertNotIn('gather_name_en',spawn)

    def test_known_gather_profile_yields_only_unverified_candidate(self):
        body=bytearray(52);struct.pack_into('<HIfff',body,0,4,1500020,10000,20000,3000)
        struct.pack_into('<I',body,37,1)
        e=probe.object_event('3436',varint(4000)+body)
        self.assertEqual(e['gather_name_en'],'Sapphire');self.assertEqual(e['consumed_attempts_candidate'],1)
        self.assertFalse(e['verified_for_this_game_session']);self.assertFalse(e['resource_identity_verified'])
        struct.pack_into('<I',body,37,4)
        self.assertNotIn('gather_name_en',probe.object_event('3436',varint(4000)+body))

    def test_unknown_template_or_generic_shape_never_claims_gather(self):
        for template,length in ((12,52),(1500020,26)):
            body=bytearray(length);struct.pack_into('<HIfff',body,0,4,template,10000,20000,3000)
            self.assertNotIn('gather_name_en',probe.object_event('3436',varint(1)+body))

    def test_truncation_overflow_nonfinite_and_invalid_position_are_rejected(self):
        for raw in (b'',b'\x80',b'\xff'*9,b'\x01',b'\x00'):
            with self.assertRaises(ValueError):probe.object_event('3436',raw)
        for x in (float('nan'),float('inf'),1e8):
            body=bytearray(26);struct.pack_into('<HIfff',body,0,4,1500020,x,1,1)
            with self.assertRaises(ValueError):probe.object_event('3436',varint(1)+body)

    def test_recording_command_uses_argument_list_and_custom_markers(self):
        command=probe.capture_command(Path('C:/Folder With Spaces/Cube.Radar.exe'),Path('C:/local records'),180)
        self.assertEqual(command[:3],['C:/Folder With Spaces/Cube.Radar.exe','dump','live'])
        self.assertIn('--no-heartbeat',command);self.assertIn('ctrl+alt+F7=first_gather',command[-1])

    def analyze(self,rows,markers=None):
        temp=tempfile.TemporaryDirectory();self.addCleanup(temp.cleanup);folder=Path(temp.name)
        (folder/'frames.jsonl').write_text('\n'.join(json.dumps(r) for r in rows),encoding='utf-8')
        if markers:(folder/'markers.jsonl').write_text('\n'.join(json.dumps(r) for r in markers),encoding='utf-8')
        with contextlib.redirect_stdout(io.StringIO()):archive=probe.analyze(folder)
        return folder,archive

    def test_export_has_only_semantic_allowlist_no_names_chat_addresses_or_hex(self):
        row={'type':'frame','op':'3836','t':1000,'flow':1,'n':2,'hex':(varint(50)+varint(100)+b'\x01').hex(),
             'src':'SECRET_IP','name':'SECRET_NAME','text':'SECRET_CHAT'}
        _,archive=self.analyze([row,dict(row,op='4536',hex='5345435245545f4e414d45')],
            [{'t':1000,'label':'first_gather','text':'SECRET_CHAT','local':'SECRET_NAME'}])
        with zipfile.ZipFile(archive) as z:
            self.assertEqual(set(z.namelist()),{'report.json','object_events.jsonl'})
            all_text=''.join(z.read(n).decode() for n in z.namelist())
        self.assertNotIn('SECRET',all_text);self.assertNotIn('"hex"',all_text)
        self.assertIn('object_interaction_start',all_text)

    def test_duplicate_export_does_not_duplicate_events_but_independent_ids_survive(self):
        row={'type':'frame','op':'3536','t':1000,'flow':1,'n':2,'hex':'01040300'}
        folder,_=self.analyze([row,row,dict(row,n=3)])
        report=json.loads((folder/'probe_report/report.json').read_text())
        self.assertEqual(report['object_events'],2);self.assertFalse(report['resource_support_confirmed'])

    def test_marker_window_does_not_infer_causation_or_success(self):
        row={'type':'frame','op':'3a36','t':1000,'hex':(varint(1)+varint(2)+struct.pack('<II',1,0)).hex()}
        folder,_=self.analyze([row],[{'t':1000,'label':'resource_depleted'}])
        report=json.loads((folder/'probe_report/report.json').read_text())
        self.assertEqual(report['markers'][0]['nearby_object_ids'],[1])
        self.assertFalse(report['resource_support_confirmed'])

    def test_console_note_is_only_accepted_for_an_exact_known_label(self):
        row={'type':'frame','op':'3436','t':1000,'hex':'00'}
        folder,_=self.analyze([row],[{'t':1000,'label':'note','text':'first_gather'},
                                    {'t':1000,'label':'note','text':'SECRET_CHAT'}])
        report=json.loads((folder/'probe_report/report.json').read_text())
        self.assertEqual([m['label'] for m in report['markers']],['first_gather'])

    def test_empty_or_malformed_input_is_reported_not_resource_absence(self):
        folder,_=self.analyze([{'type':'frame','op':'3436','t':1000,'hex':'broken'},
                               {'type':'frame','op':'3436','t':True,'hex':'0100'}])
        report=json.loads((folder/'probe_report/report.json').read_text())
        self.assertEqual(report['undecodable_object_messages'],{'3436':1})
        self.assertEqual(report['malformed_lines'],1);self.assertFalse(report['resource_support_confirmed'])


if __name__=='__main__':unittest.main()
