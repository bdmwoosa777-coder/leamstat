"""Six-metre plateau works without world OCR; checkmarked feathers are not aether."""
from pathlib import Path
import tempfile,time,unittest
from unittest.mock import patch
import cv2,numpy as np
from PIL import Image,ImageDraw,ImageFont
from test_navigation import GatherFixture,obs
from test_exploration import radar
from test_reference_crops import canvas
from minimap import MinimapVision
from flight import FlightReading
from vision import read_target_distance
import gather_engine as ge

ROOT=Path(__file__).resolve().parent
AIR=FlightReading(50,True)
GROUND=FlightReading(None,False)

class LiveApproachTests(GatherFixture,unittest.TestCase):
    def selected(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='APPROACH'
        self.e._reset_resource_watch(verified_header=True)
        self.e.last_distance=6;self.e.last_progress=0;self.e.started=0
        with patch.object(ge.time,'monotonic',return_value=0):self.assertTrue(self.e._start_resource_route())
    def fast(self,now,slots=3):
        with patch.object(ge,'gathering_panel_pair',return_value=False),patch.object(ge,'segment_count',return_value=slots),patch.object(ge,'read_target_distance',return_value=6),patch.object(ge.time,'monotonic',return_value=now):
            self.e._resource_fast_tick(self.frame,GROUND,now,panel=False,slots=slots)
            self.e._approach_fast_tick(self.frame,(0,0),GROUND,now)
    def test_constant_six_metres_start_v_recovery_without_any_ocr_snapshot(self):
        self.selected()
        for now in (0,2,4,6.1):self.fast(now)
        self.assertIsNone(self.e.snapshot);self.assertEqual(self.commands,['TAP_F','V'])
        self.assertEqual(self.e.mode,'TAKEOFF');self.assertTrue(self.e.wing_route_restart_pending)
        with patch.object(ge,'gathering_panel_pair',return_value=False),patch.object(ge,'read_target_distance',return_value=6),patch.object(ge,'read_flight',return_value=AIR),patch.object(ge.time,'monotonic',return_value=6.3):
            self.e._approach_fast_tick(self.frame,(0,0),AIR,6.3)
        self.assertEqual(self.commands,['TAP_F','V','TAP_F']);self.assertEqual(self.e.mode,'APPROACH')
        self.assertFalse(self.e.f_on)
    def test_jittering_upper_slot_count_never_claims_that_gathering_started(self):
        self.selected()
        for now,slots in ((0,3),(1,2),(2,3),(3,2),(4,3)):
            self.fast(now,slots)
            self.assertFalse(self.e.fast_gather_seen);self.assertEqual(self.e.mode,'APPROACH')
        self.fast(6.1,2)
        self.assertIn('V',self.commands);self.assertNotIn('F_ON',self.commands)
    def test_real_panel_stops_the_plateau_watchdog(self):
        self.selected()
        with patch.object(ge,'gathering_panel_pair',return_value=True),patch.object(ge,'segment_count',return_value=3):
            self.e._resource_fast_tick(self.frame,AIR,7,panel=True,slots=3)
            self.assertFalse(self.e._approach_fast_tick(self.frame,(0,0),AIR,7))
        self.assertEqual(self.commands,['TAP_F','F_ON']);self.assertNotIn('V',self.commands)
    def test_route_stagnation_is_serviced_by_run_before_waiting_for_world_ocr(self):
        self.selected();self.e.screen.pick=lambda:'game';clock=[0.]
        def wait(seconds):clock[0]+=max(.1,seconds);return self.e.stop_event.is_set()
        def send(command):
            self.commands.append(command)
            if command=='V':self.e.stop_event.set()
        self.e.bridge.send=send
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(ge.threading,'Thread'),patch.object(self.e,'_prepare_working_view',return_value=True),patch.object(self.e.stop_event,'wait',side_effect=wait),patch.object(ge,'gathering_panel_pair',return_value=False),patch.object(ge,'segment_count',return_value=3),patch.object(ge,'read_target_distance',return_value=6),patch.object(ge,'read_flight',return_value=GROUND):
            self.e.run()
        self.assertIsNone(self.e.snapshot);self.assertEqual(self.commands.count('V'),1)
        self.assertLess(clock[0],8);self.assertNotIn('F_ON',self.commands)
    def test_selected_target_ocr_does_not_search_all_world_captions(self):
        self.selected()
        def scan(frame,**kwargs):self.e.stop_event.set();return obs('Сапфир',distance=6)
        with patch.object(self.e.vision,'scan',side_effect=scan) as scan_call:self.e._vision_loop()
        self.assertFalse(scan_call.call_args.kwargs['candidates'])

class DistanceReaderTests(unittest.TestCase):
    def test_real_reference_distances_without_name_ocr(self):
        self.assertEqual(read_target_distance(canvas('sapphire_target_49m_crop.png',950,40)),49)
        self.assertEqual(read_target_distance(cv2.imread(str(ROOT/'testdata/orihalkon_example.jpg'))),10)
        self.assertIsNone(read_target_distance(np.zeros((1152,2048,3),np.uint8)))
    def test_six_metre_digits_in_top_hud_are_read_at_user_resolution(self):
        im=Image.new('RGB',(2048,1152),(90,95,100));draw=ImageDraw.Draw(im)
        font=next((p for p in (Path('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'),Path('C:/Windows/Fonts/arialbd.ttf')) if p.exists()),None)
        if font is None:self.skipTest('No test font')
        draw.text((round(2048*.575),round(1152*.035)),'6 м',font=ImageFont.truetype(str(font),18),fill='white')
        self.assertEqual(read_target_distance(cv2.cvtColor(np.array(im),cv2.COLOR_RGB2BGR)),6)

class FeatherRadarTests(unittest.TestCase):
    def markers(self,file,scale,cfg=None):
        frame=cv2.imread(str(ROOT/'testdata'/file))
        frame=cv2.resize(frame,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA if scale<1 else cv2.INTER_CUBIC)
        h,w=frame.shape[:2]
        return MinimapVision(cfg or {})._markers(frame,(0,0),(w/2,h/2),round(2480*scale))
    def test_checkmarked_feathers_are_rejected_while_real_aether_stays_at_all_scales(self):
        for scale in (.4,.5,.65,.75,.825,1,1.1,1.25,1.5,2):
            with self.subTest(scale=scale):
                markers=self.markers('minimap_ground_crop.png',scale)
                air=[m for m in markers if m.kind=='aether'];self.assertEqual(len(air),2)
                self.assertTrue(any(abs(m.x/scale-170)<6 and abs(m.y/scale-23)<6 for m in air))
                self.assertTrue(any(abs(m.x/scale-90)<6 and abs(m.y/scale-185)<6 for m in air))
                self.assertFalse(any(abs(m.x/scale-215)<20 and abs(m.y/scale-150)<20 for m in air))
    def test_real_air_icon_is_not_split_into_duplicate_targets(self):
        for scale in (.5,.75,.825,1,1.25,1.5,2):
            with self.subTest(scale=scale):
                self.assertEqual(len([m for m in self.markers('minimap_air_crop.png',scale) if m.kind=='aether']),1)
    def test_optional_wrong_feather_template_cannot_override_shape_filter(self):
        source=cv2.imread(str(ROOT/'testdata/minimap_ground_crop.png'))
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            p=Path(folder)/'feather.png';cv2.imwrite(str(p),source[119:174,190:241])
            cfg={'minimap_templates':[{'name':'Эфир','file':str(p.relative_to(ROOT))}],'minimap_reference_size':[2480,1395]}
            self.assertEqual(len([m for m in self.markers('minimap_ground_crop.png',1,cfg) if m.kind=='aether']),2)

if __name__=='__main__':unittest.main()
