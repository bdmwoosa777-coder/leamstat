"""Shared dependency environment. Version folders contain no virtualenv copy."""
from pathlib import Path
import hashlib,json,os,sys

def requirement_hash(root):return hashlib.sha256((Path(root)/'requirements.txt').read_bytes()).hexdigest()
def runtime_base():
 local=os.environ.get('LOCALAPPDATA')
 return Path(local)/'ACore2TargetScanner'/'runtime' if local else Path.home()/'.local'/'share'/'ACore2TargetScanner'/'runtime'
def runtime_dir(root):return runtime_base()/('py'+str(sys.version_info.major)+str(sys.version_info.minor)+'-'+requirement_hash(root)[:12])
def runtime_python(folder):return Path(folder)/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
def find_runtime(root):
 digest=requirement_hash(root)
 for stamp in sorted(runtime_base().glob('py*-'+digest[:12]+'/ready.json')):
  try:
   data=json.loads(stamp.read_text());version=tuple(data['python_version'])
   if data['requirements_sha256']==digest and (3,10)<=version<(3,14) and runtime_python(stamp.parent).is_file():return runtime_python(stamp.parent)
  except (OSError,ValueError,KeyError,TypeError):continue
 return None
