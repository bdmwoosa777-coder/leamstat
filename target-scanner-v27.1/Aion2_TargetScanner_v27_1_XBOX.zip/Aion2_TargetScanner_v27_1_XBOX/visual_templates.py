# -*- coding: utf-8 -*-
"""Small fixed-HUD image library for Aion 2.

Compare complete glyph masks rather than OCR text or raw terrain RGB pixels.
Sample images remain ordinary PNG files. No training, cloud API or injection.
"""
import json
import re
import threading
import uuid
from pathlib import Path

import cv2
import numpy as np

ROOT = Path(__file__).with_name('visual_samples')
MANIFEST = ROOT / 'library.json'
SHAPES = {'mob': (357, 26), 'player': (179, 30)}


def signature(name):
    return ''.join(ch for ch in name.lower().replace('ё', 'е') if ch.isalnum())


def ink_mask(raw, kind, grayscale=False):
    """Glyph shapes in a fixed sub-rectangle, independent of the game background.

    Both rectangular subregions are measured inside the original calibrated ROIs;
    scale to canonical size to accommodate small screen capture differences.
    """
    if kind not in SHAPES or raw is None or raw.size == 0:
        return None
    if len(raw.shape) != 3 or raw.shape[2] not in (3, 4):
        return None
    rgb = cv2.cvtColor(raw, cv2.COLOR_BGRA2BGR) if raw.shape[2] == 4 else raw
    w, h = SHAPES[kind]
    img = cv2.resize(rgb, (w, h), interpolation=cv2.INTER_AREA)
    if kind == 'mob':
        img = img[1:24, 152:320]
        lower, upper = (9, 65, 140), (45, 255, 255)
    else:
        img = img[4:27, 16:121]
        lower, upper = (30, 38, 95), (105, 255, 255)
    if grayscale:
        # Local high-frequency letter strokes, *without using hue at all*.
        # Text is anchored; terrain detail only lowers the full-image Dice
        # score rather than allowing a few matching prefix glyphs to win.
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        background = cv2.GaussianBlur(gray, (0, 0), 3)
        strokes = cv2.subtract(gray, background)
        level = max(14, int(np.percentile(strokes, 90)))
        return (strokes > level).astype(np.uint8)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(hsv, lower, upper)
    return (mask > 0).astype(np.uint8)


def glyph_similarity(a, b):
    """Dice overlap after small integer displacement; scores in [0..1].

    Dice penalises both missing ink and background false positives. A partial
    prefix of an excluded similar name cannot achieve full-text confidence.
    """
    if a is None or b is None or a.shape != b.shape:
        return 0.0
    n1, n2 = int(np.count_nonzero(a)), int(np.count_nonzero(b))
    if n1 < 25 or n2 < 25 or max(n1, n2) > 2.7 * min(n1, n2):
        return 0.0
    best = 0.0
    for dy in range(-2, 3):
        y1, y2 = max(0, dy), max(0, -dy)
        height = a.shape[0] - abs(dy)
        for dx in range(-4, 5):
            x1, x2 = max(0, dx), max(0, -dx)
            width = a.shape[1] - abs(dx)
            inter = np.count_nonzero(a[y1:y1+height, x1:x1+width] &
                                     b[y2:y2+height, x2:x2+width])
            score = (2.0 * inter) / (n1 + n2)
            if score > best:
                best = score
    return best


class VisualLibrary:
    def __init__(self, root=ROOT):
        self.root = Path(root)
        self.manifest = self.root / 'library.json'
        self.lock = threading.RLock()
        self.entries = []
        self.load()

    def load(self):
        with self.lock:
            self.entries = []
            if not self.manifest.is_file():
                return
            try:
                records = json.loads(self.manifest.read_text(encoding='utf-8')).get('samples', [])
            except (OSError, json.JSONDecodeError):
                return
            for rec in records:
                kind, name, fname = rec.get('kind'), rec.get('name', ''), rec.get('file', '')
                if kind not in SHAPES or not name or not re.fullmatch(r'[a-zA-Z0-9_\-]+\.png', fname):
                    continue
                pic = cv2.imread(str(self.root / fname), cv2.IMREAD_COLOR)
                mask = ink_mask(pic, kind)
                neutral = ink_mask(pic, kind, grayscale=True)
                if mask is not None and max(np.count_nonzero(mask),np.count_nonzero(neutral)) >= 25:
                    self.entries.append({'kind': kind, 'name': name, 'file': fname,
                                         'mask': mask, 'neutral': neutral})

    def _save_locked(self):
        self.root.mkdir(parents=True, exist_ok=True)
        payload = {'format': 1, 'samples': [{k: r[k] for k in ('kind', 'name', 'file')}
                                          for r in self.entries]}
        tmp = self.root / 'library.tmp'
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')
        tmp.replace(self.manifest)

    def add(self, kind, name, raw):
        name = str(name).strip()
        if kind not in SHAPES or not signature(name):
            raise ValueError('Требуется корректный тип и имя образца')
        mask = ink_mask(raw, kind)
        neutral = ink_mask(raw, kind, grayscale=True)
        if mask is None or max(np.count_nonzero(mask),np.count_nonzero(neutral)) < (55 if kind == 'player' else 35):
            raise ValueError('В выбранной области почти нет букв нужного цвета. Проверь скриншот.')
        with self.lock:
            self.root.mkdir(parents=True, exist_ok=True)
            fname = kind + '_' + uuid.uuid4().hex[:16] + '.png'
            path = self.root / fname
            if not cv2.imwrite(str(path), raw):
                raise OSError('Не удалось сохранить снимок')
            self.entries.append({'kind': kind, 'name': name, 'file': fname,
                                 'mask': mask, 'neutral': neutral})
            self._save_locked()
            return fname

    def delete_name(self, kind, name):
        with self.lock:
            to_delete = [r for r in self.entries if r['kind'] == kind and signature(r['name']) == signature(name)]
            doomed = {r['file'] for r in to_delete}
            self.entries = [r for r in self.entries if r['file'] not in doomed]
            self._save_locked()
            for rec in to_delete:
                (self.root / rec['file']).unlink(missing_ok=True)
            return len(to_delete)

    def summary(self):
        with self.lock:
            grouped = {}
            for r in self.entries:
                key = (r['kind'], signature(r['name']))
                if key not in grouped:
                    grouped[key] = {'kind': r['kind'], 'name': r['name'], 'count': 0}
                grouped[key]['count'] += 1
            return list(grouped.values())

    def match(self, kind, raw, player_name=None):
        """(best name, best score, margin). Match ALL known mobs incl exclusions."""
        candidate = ink_mask(raw, kind)
        neutral = ink_mask(raw, kind, grayscale=True)
        if candidate is None or max(np.count_nonzero(candidate),np.count_nonzero(neutral)) < 35:
            return '', 0.0, 0.0
        with self.lock:
            scores = {}
            names = {}
            for r in self.entries:
                if r['kind'] != kind:
                    continue
                if kind == 'player' and player_name and signature(r['name']) != signature(player_name):
                    continue
                key = signature(r['name'])
                # Primary image-shape comparison is colour-independent. The
                # colour mask is an alternative for lettering rendered with
                # less grayscale contrast; never compare raw scenery pixels.
                score = max(glyph_similarity(neutral, r['neutral']),
                            glyph_similarity(candidate, r['mask']))
                if score > scores.get(key, 0.0):
                    scores[key] = score
                    names[key] = r['name']
            if not scores:
                return '', 0.0, 0.0
            ranked = sorted(scores.items(), key=lambda pair: pair[1], reverse=True)
            best_key, best_score = ranked[0]
            runner_up = ranked[1][1] if len(ranked) > 1 else 0.0
            return names[best_key], float(best_score), float(best_score - runner_up)
