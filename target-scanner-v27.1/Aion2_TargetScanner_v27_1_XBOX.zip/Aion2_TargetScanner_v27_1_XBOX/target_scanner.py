# -*- coding: utf-8 -*-
"""Aion 2 Target Scanner v27 — native Xbox transport, original recognition policy.

No game-memory access/injection. Windows only. Virtual Xbox; no G HUB, Lua or keyboard/mouse injection.
"""
import ctypes
from ctypes import wintypes
from difflib import SequenceMatcher
import json
import os
from pathlib import Path
import queue
import re
import threading
import time
import tkinter as tk
from tkinter import ttk, messagebox, filedialog

import cv2
import mss
import numpy as np
from PIL import Image, ImageTk
import pytesseract
from visual_templates import VisualLibrary, signature
from xbox_combat import XboxCombatBridge
from captcha_watchdog import CenterDialogDetector, AudioAlarm
from death_watchdog import DeathDialogDetector, DeathAudioAlarm

if os.name != 'nt':
    raise SystemExit('Программа работает только в Windows.')

u32 = ctypes.windll.user32
u32.GetForegroundWindow.restype = wintypes.HWND
u32.GetAsyncKeyState.argtypes = [ctypes.c_int]
u32.GetAsyncKeyState.restype = ctypes.c_short
u32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
u32.GetWindowThreadProcessId.restype = wintypes.DWORD
u32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
u32.GetClientRect.restype = wintypes.BOOL
u32.ClientToScreen.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.POINT)]
u32.ClientToScreen.restype = wintypes.BOOL
VK_CONTROL = 0x11
HOTKEYS = {'sample_player': 0x74, 'sample_mob': 0x75, 'toggle': 0x77, 'stop': 0x78, 'silence_captcha': 0x79}  # Ctrl+F5/F6/F8/F9/F10
MOD_CONTROL = 0x0002
MOD_NOREPEAT = 0x4000
WM_HOTKEY = 0x0312
WM_QUIT = 0x0012
u32.RegisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int, wintypes.UINT, wintypes.UINT]
u32.RegisterHotKey.restype = wintypes.BOOL
u32.UnregisterHotKey.argtypes = [wintypes.HWND, ctypes.c_int]
u32.UnregisterHotKey.restype = wintypes.BOOL
u32.GetMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT]
u32.GetMessageW.restype = ctypes.c_int
u32.PeekMessageW.argtypes = [ctypes.POINTER(wintypes.MSG), wintypes.HWND, wintypes.UINT, wintypes.UINT, wintypes.UINT]
u32.PeekMessageW.restype = wintypes.BOOL
u32.PostThreadMessageW.argtypes = [wintypes.DWORD, wintypes.UINT, wintypes.WPARAM, wintypes.LPARAM]
u32.PostThreadMessageW.restype = wintypes.BOOL
EnumWindowsProc = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
u32.EnumWindows.argtypes = [EnumWindowsProc, wintypes.LPARAM]
u32.EnumWindows.restype = wintypes.BOOL
u32.IsWindowVisible.argtypes = [wintypes.HWND]
u32.IsWindowVisible.restype = wintypes.BOOL
u32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
u32.GetWindowTextLengthW.restype = ctypes.c_int
u32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
u32.GetWindowTextW.restype = ctypes.c_int
ctypes.windll.kernel32.GetCurrentThreadId.restype = wintypes.DWORD
CONFIG_PATH = Path(__file__).with_name('settings.json')
LOG_PATH = Path(__file__).with_name('scanner_log.txt')
# Gameplay reports use a virtual Xbox. Windows APIs below only inspect focus/hotkeys.

DEFAULTS = {
    'targets': ['Дух леса', 'Поблекший дух камня'],
    'visual_mode': 'hybrid',  # hybrid | text | visual
    'visual_player_enabled': True,
    'tab_interval_ms': 110,
    'tabs_per_sector': 12,
    'turn_ms': 140,
    'turn_delay_ms': 15,
    'search_turn_sec': 2.0,
    'search_turn_mode': 'рывок',
    'tab_settle_ms': 85,
    'threat_settle_ms': 200,
    'never_move_camera': False,
    'attack_timeout_sec': 25,
    'min_combat_sec': 3,
    'combat_hp_loss_confirm_sec': 0.36,  # v2.6: confirmation window is distinct from RELEASE+TAB transmission
    'combat_hud_loss_confirm_sec': 1.15,
    'max_no_hp_progress_sec': 8.0,
    'combat_empty_hp_stall_sec': 2.2,
    'combat_identity_timeout_sec': 4.8,  # no credible original name for 4.8s => release regardless of coloured scenery  # HP absent with no evidence of damage
    'combat_full_hp_stall_sec': 8.0,   # target HP unchanged at full capacity
    'combat_no_damage_sec': 3.0,  # diagnostics only
    'combat_lost_identity_sec': 1.3,
    'combat_progress_stall_sec': 4.5,
    'min_tabs_between_turns': 8,
    'debug_each_tab': True,
    'death_confirm_sec': 0.43,  # old unsafe setting; no longer used for ending combat
    'f_interval_ms': 2000,
    'six_spam_enabled': False,  # LT+A burst for 4 seconds every 80 active-session seconds
    'attack_all_targets': False,  # default: whitelist + original optional aggressor mode
    'ocr_check_ms': 120,
    'repeat_search': True,
    'combat_spin': True,   # same periodic turn timer during combat and search
    'combat_turn_ms': 80,
    'combat_turn_sec': 0.33,
    'protect_player': True,  # Selected mobs targeting Darkleam are priority targets.
    'player_name': 'Darkleam',
    'threat_roi': [0.665, 0.028, 0.752, 0.054],
    'threat_scan_sec': 6,
    'fast_threat': True,
    'fast_threat_fallback_period': 4,
    'threat_delayed_probe_every': 2,
    'threat_delayed_probe_ms': 115,
    'name_roi': [0.3991478125, 0.036232777777777773, 0.5734256249999999, 0.05841611111111111],
    'tesseract': r'C:\Program Files\Tesseract-OCR\tesseract.exe',
    'captcha_watch_enabled': True,
    'captcha_audio_device': 'AG271QG4',
    'captcha_scan_period': 1.0,
    'death_watch_enabled': True,  # independent of OCR/Tab; every 5 seconds

}


def key_pressed(vk):
    return bool(u32.GetAsyncKeyState(vk) & 0x8000)


def normalize_name(value):
    value = value.casefold().replace('ё', 'е')
    return ''.join(ch for ch in value if ch.isalpha() or ch.isdigit())


def name_matches(read_name, target):
    """Careful prefix match because game's target panel may truncate long names."""
    seen, full = normalize_name(read_name), normalize_name(target)
    if not seen or not full:
        return False
    # Short names such as «Файни»: OCR can prepend level digits and stray text
    # (e.g. ". io Файни'"). Match a FULL Cyrillic word, never a substring of
    # an unrelated name. The target HUD is independently checked before combat.
    if len(full) <= 6:
        tokens = re.findall(r'[a-zа-яё0-9]+', read_name.casefold().replace('ё', 'е'))
        # Tesseract sometimes sees «Керуб» as Latin «Kepy6». Convert only
        # lookalike characters for an EXACT whole-word match; fuzzy short-name
        # matching would risk attacking a different mob.
        lookalikes = str.maketrans({'k':'к','e':'е','p':'р','y':'у',
                                    'a':'а','o':'о','c':'с','t':'т',
                                    'x':'х','m':'м','h':'н','b':'ь','6':'б'})
        return any(token == full or token.translate(lookalikes) == full
                   for token in tokens)
    # Longer names: allow a noisy level prefix / punctuation (but not an
    # arbitrary mid-word substring, which risks hitting unintended mobs).
    if len(seen) < 7:
        return False
    if seen.startswith(full) or seen.startswith(full[:min(10, len(full))]):
        return True
    if seen.endswith(full):
        return True
    # Remove only a small number of leading OCR-garbage glyphs, not whole words.
    for offset in range(5):
        candidate = seen[offset:]
        n = min(len(candidate), len(full))
        if n >= 9 and SequenceMatcher(None, candidate[:n], full[:n]).ratio() >= .86:
            return True
    return False


def find_target(read_name, targets):
    matches = [name for name in targets if name_matches(read_name, name)]
    return max(matches, key=lambda name: len(normalize_name(name)), default=None)


def combat_absence_confirmed(absent_since, now, name_confirmed, header_visible, hp_visible, grace_sec=0.58):
    """Release only if BOTH selected name/header and bar are absent for long enough.

    An unchanged HP colour or an empty OCR result alone is NOT sufficient.
    Return (updated_absent_since, confirmed_absence).
    """
    if name_confirmed or header_visible or hp_visible:
        return None, False
    if absent_since is None:
        absent_since = now
    return absent_since, now - absent_since >= grace_sec


def combat_stall_reason(elapsed, unconfirmed_age, hp_progress_seen, progress_age,
                        identity_ok, no_damage_limit=3.0,
                        lost_identity_limit=1.3, progress_stall_limit=4.5):
    """Return a reason for aborting an idle/stale fight, else None.

    Presence of *some* HP bar is not evidence that the weaving macro worked.
    Only changing target HP can confirm attempted combat in this HUD scheme.
    Losing both target name and matching visual fingerprint must not block TAB.
    """
    if not hp_progress_seen:
        if not identity_ok and unconfirmed_age >= lost_identity_limit:
            return 'нет прежней цели и подтверждённого урона'
        if elapsed >= no_damage_limit:
            return 'нет подтверждённого урона после START'
    elif not identity_ok and unconfirmed_age >= lost_identity_limit and progress_age >= progress_stall_limit:
        return 'цель потеряна, урон давно не менялся'
    return None



def cyrillic_ocr_tokens(value):
    """Extract readable word-shapes from OCR with mixed Cyrillic/Latin lookalikes.

    Used for *identity comparison only*. Does not imply permission to attack.
    """
    mixed = str.maketrans({'a':'а','e':'е','o':'о','p':'р','c':'с',
                           'x':'х','y':'у','k':'к','m':'м','t':'т','h':'н'})
    words = re.findall(r'[а-яёa-z]{3,}', value.casefold().replace('ё','е'))
    return [w.translate(mixed) for w in words]


def word_score(seen, expected):
    """OCR may glue a HUD prefix/suffix to the actual word."""
    if seen == expected:
        return 1.0
    n = len(expected)
    candidates = [seen]
    if len(seen) > n:
        # Limit window size: a shared suffix (e.g. 'дудуков') is not enough.
        for size in range(max(4,n-1), min(len(seen),n+2)+1):
            for off in range(len(seen)-size+1):
                candidates.append(seen[off:off+size])
    return max((SequenceMatcher(None,v,expected).ratio() for v in candidates),default=0)


def target_phrase_evidence(ocr, target, strict=False):
    """Two-word name identity independent of irrelevant HUD prefixes.

    A shared family/suffix alone is NOT a match: both distinctive word parts
    must be visible. This also handles 'Пращник звуков' vs 'Пращник дудуков'
    conservatively, as one error in an otherwise distinctive first word.
    """
    wanted = cyrillic_ocr_tokens(target)
    got = cyrillic_ocr_tokens(ocr)
    if len(wanted) < 2 or not got:
        return 0.0
    a = max((word_score(w,wanted[0]) for w in got),default=0)
    b = max((word_score(w,wanted[1]) for w in got),default=0)
    # Need two independent parts. Prevent 'Рабочий дудуков' from matching
    # 'Пращник дудуков', irrespective of suffix similarity.
    if a >= .88 and b >= (.75 if strict else .57):
        return (a+b)/2
    if a >= .65 and b >= .75:
        return (a+b)/2
    return 0.0



def _mixed_ocr_words(value):
    """Convert only common Latin lookalikes in the fixed mob-name ROI.

    This is never an attack authorisation by itself. The *entire two-word
    mob name* must be corroborated on a later, fresh, uncached screenshot.
    """
    glyphs = str.maketrans({'a':'а','e':'е','o':'о','p':'р','c':'с','x':'х',
                            'y':'у','k':'к','m':'м','t':'т','h':'н','6':'б'})
    return [w.translate(glyphs) for w in re.findall(
        r'[а-яёa-z0-9]{3,}', value.casefold().replace('ё','е'))]


def _fuzzy_full_name_score(text, target):
    """One OCR deletion/insertion in a COMPLETE multiword name, not a prefix.

    e.g. 'Духлеа' (lost с) -> 'Дух леса', but a real 'Дух шквала'
    or 'Дух бриза' is very different. Short one-word Керуб is excluded.
    Every candidate needs a second INDEPENDENT sample to authorize attack.
    """
    wanted = normalize_name(target)
    if len(wanted) < 7 or len(cyrillic_ocr_tokens(target)) < 2:
        return 0.0
    words = _mixed_ocr_words(text)
    if not words:
        return 0.0
    best = 0.0
    # OCR may join the two words or mistakenly split them. Limit source
    # prefixes to four characters of debris; do not match suffix-only text.
    for i in range(len(words)):
        for count in (1, 2, 3):
            piece = ''.join(words[i:i+count])
            if not piece:
                continue
            for off in range(min(5, max(1, len(piece)-len(wanted)+2))):
                for length in (len(wanted)-1,len(wanted),len(wanted)+1):
                    segment = piece[off:off+length]
                    if abs(len(segment)-len(wanted)) > 1:
                        continue
                    if len(segment) < len(wanted)-1:
                        continue
                    # Do not mistake 'Дух лесной' for 'Дух леса' simply
                    # because the short prefix 'духлес' almost matches.
                    # The candidate must consume nearly the WHOLE word.
                    if len(piece) - (off + len(segment)) > 1:
                        continue
                    score = SequenceMatcher(None, segment, wanted).ratio()
                    if score > best:
                        best = score
    return best


def fuzzy_full_target(text, targets):
    """Return only an essentially exact *full* 2+word name (>=.90 similarity).

    This is a *candidate for rereading*, never permission to attack directly.
    An equal/conflicting candidate makes the result ambiguous and is refused.
    """
    candidates = sorted(((_fuzzy_full_name_score(text,t),t) for t in targets),reverse=True)
    if not candidates or candidates[0][0] < .90:
        return None
    if len(candidates) > 1 and candidates[0][0]-candidates[1][0] < .09:
        return None
    return candidates[0][1]


def verified_fuzzy_name(initial, fresh_primary, fresh_alternate, targets):
    """Require two different screenshots and bypass the OCR visual cache.

    One nearly-complete full name on the initial image, then the same name
    recovered by a true second OCR invocation or by an alternate mask.
    """
    candidate = fuzzy_full_target(initial, targets)
    if not candidate:
        return None
    for reading in (fresh_primary, fresh_alternate):
        if find_target(reading,targets) == candidate:
            return candidate
        if fuzzy_full_target(reading,targets) == candidate:
            return candidate
    return None


def classify_combat_name(ocr, locked_target, allowed_targets):
    """Conservative target identity: do not abort on an isolated OCR *word*.

    v2.2 interpreted 'звуков' from 'Пращник звуков' and 'задира' from
    'Задира мандури...' as FOREIGN, thereby repeatedly aborting the right
    enemy. Consider 2-word evidence for an unrelated enemy instead.
    """
    if not ocr:
        return 'unknown', ''
    locked_normal = normalize_name(locked_target)
    seen_normal = normalize_name(ocr)
    # Keep exact-ish same-name matching including accidentally joined punctuation.
    if len(locked_normal) >= 6 and (locked_normal in seen_normal or
        (len(seen_normal) >= 6 and SequenceMatcher(None,seen_normal,locked_normal).ratio() >= .89)):
        return 'same', locked_target
    # The short Kerub family is intentionally disjoint.
    distinct_family = {'керуб', 'керубим', 'керубиэль'}
    listed = {normalize_name(t) for t in allowed_targets}
    for word in re.findall(r'[а-яё]{4,}',ocr.casefold()):
        token=normalize_name(word)
        if token in distinct_family and token not in listed and token != locked_normal:
            return 'excluded_family', token
    if target_phrase_evidence(ocr,locked_target) >= .72:
        return 'same', locked_target
    recognised=find_target(ocr,allowed_targets)
    if recognised is not None:
        return ('same' if normalize_name(recognised)==locked_normal else 'other_allowed'), recognised
    # OCR may produce a VERY noisy reading of the same desired target.
    # Evidence for at least one unique core word means UNKNOWN, not FOREIGN.
    locked_words=cyrillic_ocr_tokens(locked_target)
    got=cyrillic_ocr_tokens(ocr)
    if locked_words and got and max((word_score(g,locked_words[0]) for g in got),default=0) >= .67:
        return 'unknown',''
    # Clear, familiar one-word mobs still need protection: a real switch to
    # 'Эфириум' should not be treated as an OCR typo of a two-word target.
    # Never infer a foreign target from arbitrary one-word fragments such as
    # 'звуков', 'задира' or 'абетовой' in an otherwise garbled name.
    sure_singles = {'эфириум','панцирник'}
    if len(got)==1 and got[0] in sure_singles:
        return 'foreign', got[0]
    # An unrelated enemy needs a plausible two-word name, not one misleading
    # fragment ('абетовой', 'звуков', 'задира'). Reject mostly Latin junk.
    if len(got)>=2:
        informative=[w for w in got if len(w)>=5]
        if len(informative)>=2:
            first=informative[0]
            # Do not treat prefixes, levels or one split word as another mob.
            if not locked_words or word_score(first,locked_words[0]) < .55:
                return 'foreign', ' '.join(informative[:3])
    return 'unknown',''


class CombatIdentityGuard:
    """Observe HUD name changes without instantly trusting single OCR errors."""
    def __init__(self, locked_target, allowed_targets):
        self.locked = locked_target
        self.allowed = allowed_targets
        self.suspect_kind = None
        self.first_suspect_at = None
        self.suspect_count = 0
        self.last_suspect = ''

    def observe(self, raw_name, now):
        kind, label = classify_combat_name(raw_name, self.locked, self.allowed)
        if kind == 'same':
            self.suspect_kind = None
            self.suspect_count = 0
            self.first_suspect_at = None
            return None
        if kind == 'unknown':
            # One OCR miss between two foreign readings doesn't establish
            # a safe target; don't reset, but don't count the miss either.
            if self.first_suspect_at is not None and now-self.first_suspect_at > 1.25:
                self.suspect_kind = None
                self.suspect_count = 0
                self.first_suspect_at = None
            return None
        if kind != self.suspect_kind or (self.first_suspect_at is not None and
                                        now-self.first_suspect_at > 1.6):
            self.suspect_kind = kind
            self.first_suspect_at = now
            self.suspect_count = 1
        else:
            self.suspect_count += 1
        self.last_suspect = label
        duration = now-self.first_suspect_at
        if kind == 'foreign' and self.suspect_count >= 2 and duration >= .17:
            return f'посторонняя цель {label!r}; {self.suspect_count} подтверждения за {duration:.2f}с'
        if kind == 'other_allowed' and self.suspect_count >= 3 and duration >= .35:
            return f'другая цель из списка {label!r}; {self.suspect_count} подтверждения за {duration:.2f}с'
        if kind == 'excluded_family' and self.suspect_count >= 3 and duration >= .35:
            return f'исключённый моб схожего имени {label!r}; {self.suspect_count} подтверждения за {duration:.2f}с'
        return None


def parse_targets(value):
    """One mob name per line; semicolons also accepted as separators."""
    lines = re.split(r'[\n;]+', value)
    names = []
    seen = set()
    for line in lines:
        name = line.strip()
        signature = normalize_name(name)
        if signature and signature not in seen:
            names.append(name)
            seen.add(signature)
    return names


def ocr_name(bgra):
    """Read yellow/orange/red; as a fallback, pale gray target names."""
    if bgra is None or not bgra.size:
        return ''
    bgr = cv2.cvtColor(bgra, cv2.COLOR_BGRA2BGR)
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    yellow = cv2.inRange(hsv, (8, 75, 95), (48, 255, 255))
    red_low = cv2.inRange(hsv, (0, 95, 95), (8, 255, 255))
    red_high = cv2.inRange(hsv, (165, 95, 95), (179, 255, 255))
    mask = cv2.bitwise_or(yellow, cv2.bitwise_or(red_low, red_high))
    if cv2.countNonZero(mask) < 18:
        # Optional gray/white names, inside ONLY the calibrated name rectangle.
        mask = cv2.inRange(hsv, (0, 0, 165), (179, 72, 255))
    if cv2.countNonZero(mask) < 18:
        return ''
    mask = cv2.resize(mask, None, fx=3, fy=3, interpolation=cv2.INTER_CUBIC)
    _, mask = cv2.threshold(mask, 130, 255, cv2.THRESH_BINARY)
    raw = pytesseract.image_to_string(mask, lang='rus+eng', config='--psm 7')
    return re.sub(r'\s+', ' ', raw).strip(' \t\r\n|[]«»')



def ocr_name_alt(bgra):
    """Independent OCR pass for borderline short names (not run per every Tab).

    A different mask and Russian-only model sometimes recovers «Керуб» from
    partial mixed-language readings such as «Куб». This NEVER authorizes fuzzy
    matching: the alternative must contain an EXACT short target word.
    """
    if bgra is None or not bgra.size:
        return ''
    bgr = cv2.cvtColor(bgra, cv2.COLOR_BGRA2BGR)
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    # Prefer brightly colored name text, filter out gray UI labels.
    colored = cv2.inRange(hsv, (5, 50, 95), (55, 255, 255))
    if cv2.countNonZero(colored) < 15:
        gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
        colored = cv2.inRange(gray, 155, 255)
    if cv2.countNonZero(colored) < 15:
        return ''
    colored = cv2.resize(colored, None, fx=4, fy=4, interpolation=cv2.INTER_LINEAR)
    _, colored = cv2.threshold(colored, 150, 255, cv2.THRESH_BINARY)
    result = pytesseract.image_to_string(colored, lang='rus', config='--psm 7')
    return re.sub(r'\s+', ' ', result).strip(' \t\r\n|[]«»')


def is_short_name_ambiguous(read_name, short_name):
    """Refuse short match if primary OCR spells a longer same-family mob.

    E.g. Керуб must never be inferred from recognized Керубим/Керубиэль.
    """
    full = normalize_name(short_name)
    for word in re.findall(r'[а-яёa-z0-9]+', read_name.lower().replace('ё', 'е')):
        token = normalize_name(word)
        if len(token) >= len(full) + 2 and token.startswith(full):
            return True
    return False


def accept_alternative_name(primary, alternate, targets):
    """Accept a short exact name restored by independent OCR only.

    A noisy or empty alternate remains NO MATCH; cannot turn Kerubim into
    Kerub by matching a prefix, edit distance or a guessed substring.
    """
    candidate = find_target(alternate, targets)
    if not candidate or len(normalize_name(candidate)) > 6:
        return None
    if is_short_name_ambiguous(primary, candidate):
        return None
    return candidate

def ocr_player_name(bgra, expected=None):
    """OCR the name in the right (target-of-target) HUD. No memory reading.

    Gold/green text can change apparent saturation with terrain and antialiasing.
    Read a slightly wider HSV range, and retry at a lower threshold when needed.
    """
    if bgra is None or not bgra.size:
        return ''
    bgr = cv2.cvtColor(bgra, cv2.COLOR_BGRA2BGR)
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    fallback = ''
    for bounds in (((28, 45, 110), (102, 255, 255)),
                   ((25, 25, 85), (105, 255, 255))):
        mask = cv2.inRange(hsv, bounds[0], bounds[1])
        if cv2.countNonZero(mask) < 9:
            continue
        mask = cv2.resize(mask, None, fx=4, fy=4, interpolation=cv2.INTER_CUBIC)
        _, mask = cv2.threshold(mask, 120, 255, cv2.THRESH_BINARY)
        value = pytesseract.image_to_string(
            mask, lang='eng',
            config='--psm 7 -c tessedit_char_whitelist=ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789_-')
        value = value.strip()
        if value:
            if expected is None or player_matches(value, expected):
                return value
            if not fallback:
                fallback = value
    return fallback


def player_matches(read_name, player_name):
    """Recognise the exact player name OR common OCR debris after it.

    Examples from the user's scanner_log: Darkleam3e_-, Darkleam773,
    Darkleam3o-, Darkleam Vj, Darkieam. Never treat an arbitrary longer
    nickname such as DarkleamOther as the user's nickname.
    The surrounding caller also requires repeated captures and a target HP bar.
    """
    expected = normalize_name(player_name)
    if not expected or not read_name:
        return False

    def glyphs(value):
        return value.replace('rn', 'm').replace('nn', 'm').replace('1', 'l').replace('i', 'l')

    expected = glyphs(expected)
    # Split by nonalphanumeric separators. Trailing HUD text becomes a
    # separate token when whitespace/punctuation separates it from the name.
    for raw in re.findall(r'[A-Za-z0-9]+', read_name):
        token = glyphs(normalize_name(raw))
        if token == expected:
            return True
        if token.startswith(expected):
            suffix = token[len(expected):]
            # A few stray OCR glyphs (commonly digits from level/other UI)
            # may be joined to a correctly read nickname. Never accept an
            # arbitrary entirely alphabetic suffix: it could be another user.
            if 1 <= len(suffix) <= 3 and any(ch.isdigit() for ch in suffix):
                return True
    return False



class FastThreatDetector:
    """Fast visual match for right HUD 'Darkleam', with OCR fallback.

    Reference template was cropped from the user's 2048x1151 screenshot.
    Not a generic recognition method for arbitrary nicknames or HUD scales.
    """
    def __init__(self):
        path = Path(__file__).with_name('Darkleam_green_template.png')
        self.template = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        if self.template is None:
            raise FileNotFoundError('Не найден Darkleam_green_template.png')
        if self.template.shape[0] < 15 or cv2.countNonZero(self.template) < 170:
            raise RuntimeError('Шаблон Darkleam повреждён/обрезан; переустанови v1.1.')
        self.calls = 0

    @staticmethod
    def mask(image):
        hsv = cv2.cvtColor(cv2.cvtColor(image, cv2.COLOR_BGRA2BGR), cv2.COLOR_BGR2HSV)
        return cv2.inRange(hsv, (28, 55, 110), (95, 255, 255))

    def check(self, image, player_name, screenshot_height):
        # Only compare the nickname pictured in the supplied template.
        if normalize_name(player_name) != 'darkleam':
            return False, 0.0, False
        mask = self.mask(image)
        if screenshot_height != 1151:
            scale = 1151 / screenshot_height
            mask = cv2.resize(mask, None, fx=scale, fy=scale, interpolation=cv2.INTER_NEAREST)
        if mask.shape[0] < self.template.shape[0] or mask.shape[1] < self.template.shape[1]:
            return False, 0.0, False
        scores = cv2.matchTemplate(mask, self.template, cv2.TM_CCOEFF_NORMED)
        confidence = float(cv2.minMaxLoc(scores)[1])
        return confidence >= .88, confidence, True

class VisualNameCache:
    """Remember exact visual signatures of already-OCR'd names to avoid launching
    a Tesseract process again for an identical target HUD image. Conservative:
    mismatches fall back to OCR. Not a replacement for OCR on new names.
    """
    def __init__(self, max_entries=100):
        self.entries = []
        self.max_entries = max_entries
        self.hits = 0
        self.misses = 0

    @staticmethod
    def fingerprint(image):
        hsv = cv2.cvtColor(cv2.cvtColor(image, cv2.COLOR_BGRA2BGR), cv2.COLOR_BGR2HSV)
        y = cv2.inRange(hsv, (8, 75, 95), (48, 255, 255))
        r1 = cv2.inRange(hsv, (0, 95, 95), (8, 255, 255))
        r2 = cv2.inRange(hsv, (165, 95, 95), (179, 255, 255))
        mask = y | r1 | r2
        if cv2.countNonZero(mask) < 18:
            mask = cv2.inRange(hsv, (0, 0, 165), (179, 72, 255))
        if cv2.countNonZero(mask) < 18:
            return None
        return cv2.resize(mask, (192, 24), interpolation=cv2.INTER_NEAREST) > 0

    def lookup(self, fingerprint):
        if fingerprint is None:
            return ''
        total = fingerprint.size
        for old, label in self.entries:
            if old.shape != fingerprint.shape:
                continue
            # High threshold avoids matching two different, similarly shaped names.
            mismatch = int(np.count_nonzero(old != fingerprint))
            if mismatch <= max(9, int(total * .013)):
                self.hits += 1
                return label
        self.misses += 1
        return None

    def store(self, fingerprint, name):
        if fingerprint is None or not name:
            return
        for old, label in self.entries:
            if label == name and np.count_nonzero(old != fingerprint) <= 12:
                return
        self.entries.append((fingerprint, name))
        if len(self.entries) > self.max_entries:
            self.entries.pop(0)


def enum_candidate_windows():
    """No process/memory access: just standard Windows visible-window titles."""
    records = []
    def callback(hwnd, _):
        if not u32.IsWindowVisible(hwnd):
            return True
        size = u32.GetWindowTextLengthW(hwnd)
        if size < 3:
            return True
        namebuf = ctypes.create_unicode_buffer(size + 1)
        u32.GetWindowTextW(hwnd, namebuf, size + 1)
        name = namebuf.value.strip()
        if not name:
            return True
        pid = wintypes.DWORD()
        u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value != os.getpid():
            records.append((int(hwnd), name))
        return True
    fn = EnumWindowsProc(callback)
    u32.EnumWindows(fn, 0)
    return records


class SystemHotkeys:
    """RegisterHotKey via the Windows message queue, not Tk GetAsyncKeyState polling."""
    def __init__(self, output_queue):
        self.queue = output_queue
        self.thread_id = 0
        self.registered = {}
        self.ready = threading.Event()
        self.thread = threading.Thread(target=self._main, daemon=True)
        self.thread.start()
        self.ready.wait(timeout=2)

    def _main(self):
        msg = wintypes.MSG()
        self.thread_id = ctypes.windll.kernel32.GetCurrentThreadId()
        # Force Windows to create this thread's message queue.
        u32.PeekMessageW(ctypes.byref(msg), None, 0, 0, 0)
        for i, (name, vk) in enumerate(HOTKEYS.items(), start=101):
            if u32.RegisterHotKey(None, i, MOD_CONTROL | MOD_NOREPEAT, vk):
                self.registered[i] = name
            else:
                self.queue.put(('log', 'Не удалось зарегистрировать сочетание ' + name + ': WinError ' + str(ctypes.windll.kernel32.GetLastError())))
        self.ready.set()
        self.queue.put(('log', 'Системные горячие клавиши зарегистрированы: ' +
                        ', '.join('Ctrl+F' + str(HOTKEYS[k] - 0x6F) for k in self.registered.values())
                        if self.registered else 'Системная регистрация горячих клавиш не удалась.'))
        try:
            while True:
                result = u32.GetMessageW(ctypes.byref(msg), None, 0, 0)
                if result <= 0:
                    break
                if msg.message == WM_HOTKEY:
                    name = self.registered.get(int(msg.wParam))
                    if name:
                        self.queue.put(('hotkey', name))
        finally:
            for i in self.registered:
                u32.UnregisterHotKey(None, i)

    def stop(self):
        if self.thread_id:
            u32.PostThreadMessageW(self.thread_id, WM_QUIT, 0, 0)


def load_config():
    cfg = dict(DEFAULTS)
    cfg['targets'] = list(DEFAULTS['targets'])
    if CONFIG_PATH.exists():
        try:
            parsed = json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
            for key in cfg:
                if key in parsed:
                    cfg[key] = parsed[key]
            # Read the user's old v0.1 settings unchanged: "target": "Файни".
            if 'targets' not in parsed and parsed.get('target'):
                cfg['targets'] = [parsed['target']]
        except (OSError, ValueError, TypeError):
            pass
    if isinstance(cfg['targets'], str):
        cfg['targets'] = parse_targets(cfg['targets'])
    return cfg


class ROISelector(tk.Toplevel):
    def __init__(self, root, screenshot, callback):
        super().__init__(root)
        self.title('Обведи только нужное имя в верхней панели (без уровня/HP)')
        self.callback = callback
        self.begin = None
        self.rectangle = None
        self.im_w, self.im_h = screenshot.size
        self.crop_x = int(self.im_w * 0.24)
        crop = screenshot.crop((self.crop_x, 0, int(self.im_w * 0.76), int(self.im_h * .19)))
        self.scale = min(1.4, 1200 / crop.width)
        scaled = crop.resize((int(crop.width * self.scale), int(crop.height * self.scale)))
        self.photo = ImageTk.PhotoImage(scaled)
        ttk.Label(self, text='Выдели ТОЛЬКО текст нужного имени сверху (моба или игрока справа).').pack(pady=6)
        self.canvas = tk.Canvas(self, width=scaled.width, height=scaled.height, cursor='crosshair')
        self.canvas.pack()
        self.canvas.create_image(0, 0, image=self.photo, anchor='nw')
        self.canvas.bind('<Button-1>', self.mouse_down)
        self.canvas.bind('<B1-Motion>', self.mouse_move)
        self.canvas.bind('<ButtonRelease-1>', self.mouse_up)
        self.resizable(False, False)
        self.grab_set()

    def mouse_down(self, evt):
        self.begin = (evt.x, evt.y)
        if self.rectangle is not None:
            self.canvas.delete(self.rectangle)
        self.rectangle = self.canvas.create_rectangle(evt.x, evt.y, evt.x, evt.y, outline='#00e5ff', width=2)

    def mouse_move(self, evt):
        if self.begin:
            self.canvas.coords(self.rectangle, self.begin[0], self.begin[1], evt.x, evt.y)

    def mouse_up(self, evt):
        if not self.begin:
            return
        ax, ay = self.begin
        bx, by = evt.x, evt.y
        if abs(bx - ax) < 22 or abs(by - ay) < 7:
            messagebox.showwarning('Область', 'Нужен прямоугольник вокруг всего имени.', parent=self)
            return
        lx, rx = sorted((ax, bx))
        ty, by = sorted((ay, by))
        roi = [(self.crop_x + lx / self.scale) / self.im_w,
               (ty / self.scale) / self.im_h,
               (self.crop_x + rx / self.scale) / self.im_w,
               (by / self.scale) / self.im_h]
        self.callback(roi)
        self.destroy()


class ScannerApp:
    def __init__(self, root):
        self.root = root
        root.title('Aion 2 Target Scanner v27.1 — Xbox без Lua')
        root.geometry('980x1010+30+30')
        root.minsize(750, 700)
        root.resizable(True, True)
        self.config = load_config()
        self.current_cfg = dict(self.config)
        self.game_hwnd = None
        self.events = queue.Queue()
        self.active = threading.Event()
        self.closed = threading.Event()
        self.system_hotkeys = SystemHotkeys(self.events)
        self.start_generation = 0
        self.bridge = XboxCombatBridge(allowed=self.input_allowed, running=self.active.is_set, logger=self.log)
        self.macro_running = False
        self.last_threat_debug = 0.0
        self.fast_threat_detector = FastThreatDetector()
        self.visual_name_cache = VisualNameCache()
        self.visual_library = VisualLibrary()
        self.last_threat_snapshot = 0.0
        self.last_speed_debug = 0.0
        self.last_sweep = 0.0
        self.tab_number = 0
        self._last_combat_end = None
        self._last_selected_signature = None
        self.macro_lock = threading.RLock()
        self.captcha_detector = CenterDialogDetector()
        self.captcha_sound = AudioAlarm(self.log)
        self.death_detector = DeathDialogDetector()
        self.death_sound = DeathAudioAlarm(self.log)
        self.death_watch_enabled = threading.Event()
        if self.config.get('death_watch_enabled', True):
            self.death_watch_enabled.set()
        self._death_alerted = False
        self.captcha_locked = threading.Event()
        self.captcha_watch_enabled = threading.Event()
        if self.config.get('captcha_watch_enabled',True):
            self.captcha_watch_enabled.set()
        self._captcha_hits = 0
        self._captcha_last_frame = None
        self.fields = {}
        self.status = tk.StringVar(value='Xbox без Lua: Ctrl+F8 в игре; физический F710/USB-приёмник отключите')
        self.roi_status = tk.StringVar(value='Область имени сохранена из прежних настроек; при необходимости уточни.')
        self.threat_roi_status = tk.StringVar(value='Правая панель: область имени игрока задаётся отдельно.')
        self.make_ui()
        try:
            LOG_PATH.open('a', encoding='utf-8').write('\n===== TARGET SCANNER v27.1 XBOX / ' + time.strftime('%Y-%m-%d %H:%M:%S') + ' =====\n')
        except OSError:
            pass
        self.worker = threading.Thread(target=self.run_loop, daemon=True)
        self.worker.start()
        self.captcha_thread = threading.Thread(target=self.captcha_watch_loop, daemon=True)
        self.captcha_thread.start()
        self.death_thread = threading.Thread(target=self.death_watch_loop, daemon=True)
        self.death_thread.start()
        self.root.after(60, self.poll_ui)
        self.root.protocol('WM_DELETE_WINDOW', self.close)

    def field(self, parent, label, key, r, c, width=15):
        pane = ttk.Frame(parent)
        pane.grid(row=r, column=c, padx=6, pady=5, sticky='nw')
        ttk.Label(pane, text=label).pack(anchor='w')
        var = tk.StringVar(value=str(self.config[key]))
        ttk.Entry(pane, width=width, textvariable=var).pack(anchor='w')
        self.fields[key] = var

    def make_ui(self):
        # The old tall fixed layout clipped the lower controls on 1080p
        # displays. Keep a proper vertical scrollable form instead.
        shell=ttk.Frame(self.root)
        shell.pack(fill='both',expand=True)
        self.ui_canvas=tk.Canvas(shell, highlightthickness=0)
        self.ui_canvas.pack(side='left',fill='both',expand=True)
        vertical=ttk.Scrollbar(shell,orient='vertical',command=self.ui_canvas.yview)
        vertical.pack(side='right',fill='y')
        self.ui_canvas.configure(yscrollcommand=vertical.set)
        area = ttk.Frame(self.ui_canvas, padding=12)
        inner=self.ui_canvas.create_window((0,0),window=area,anchor='nw')
        area.bind('<Configure>',lambda event:self.ui_canvas.configure(scrollregion=self.ui_canvas.bbox('all')))
        self.ui_canvas.bind('<Configure>',lambda event:self.ui_canvas.itemconfigure(inner,width=event.width))
        self.root.bind('<MouseWheel>',lambda event:self.ui_canvas.yview_scroll(
            -max(-3,min(3,int(event.delta/120))), 'units'))
        ttk.Label(area, text='Поиск по нескольким именам мобов', font=('Segoe UI', 14, 'bold')).pack(anchor='w')
        ttk.Label(area, text='Каждое название на новой строке. Проверяется имя выбранной TAB цели.').pack(anchor='w', pady=(2, 5))
        self.targets_box = tk.Text(area, height=4, width=74, font=('Segoe UI', 10))
        self.targets_box.pack(fill='x', pady=(0, 8))
        self.targets_box.insert('1.0', '\n'.join(self.config['targets']))
        templates = ttk.LabelFrame(area, text='Визуальная библиотека целей — образцы прямо из Aion 2')
        templates.pack(fill='x', pady=(0, 7))
        selectors = ttk.Frame(templates)
        selectors.pack(fill='x', padx=5, pady=(4, 3))
        ttk.Label(selectors, text='Режим имён:').pack(side='left', padx=(3, 5))
        self.visual_mode = tk.StringVar(value=self.config.get('visual_mode','hybrid'))
        ttk.Combobox(selectors, width=17, state='readonly', textvariable=self.visual_mode,
                     values=('hybrid','text','visual')).pack(side='left')
        self.visual_player_enabled = tk.BooleanVar(value=self.config.get('visual_player_enabled',True))
        ttk.Checkbutton(selectors, text='Darkleam: визуальные образцы + старый OCR',
                        variable=self.visual_player_enabled).pack(side='left', padx=10)
        buttons = ttk.Frame(templates)
        buttons.pack(fill='x', padx=5, pady=(1, 5))
        ttk.Button(buttons, text='Снимок имени моба (Ctrl+F6)', command=self.capture_mob_sample).pack(side='left', padx=2)
        ttk.Button(buttons, text='Снимок Darkleam (Ctrl+F5)', command=self.capture_player_sample).pack(side='left', padx=2)
        ttk.Button(buttons, text='Библиотека / удалить', command=self.open_visual_library).pack(side='left', padx=2)
        ttk.Label(templates, text='Ctrl+F6: выбери моба через Tab в игре; Ctrl+F5: когда его правая панель показывает Darkleam.\n'
                  'При нажатии кнопки мышью будет 3 секунды на возврат в игру. Сначала останови автопоиск.',
                  foreground='#555555', justify='left').pack(anchor='w', padx=8, pady=(0, 5))

        keys = ttk.LabelFrame(area, text='Команды выполняет виртуальный Xbox')
        keys.pack(fill='x', pady=(1, 7))
        ttk.Label(keys, text='Без галочки: RS + библиотека имён. С галочкой: непрерывная атака без RS/OCR. RB+RT — атака, B — лут каждые 2 с.').pack(anchor='w', padx=7, pady=6)

        grid = ttk.Frame(area)
        grid.pack(fill='x')
        self.field(grid, 'Минимальный цикл TAB (мс)', 'tab_interval_ms', 0, 0)
        self.field(grid, 'TAB за сектор (резерв)', 'tabs_per_sector', 0, 1)
        self.field(grid, 'Импульс камеры (мс)', 'turn_ms', 0, 2)
        self.field(grid, 'Пауза поворота (мс)', 'turn_delay_ms', 1, 0)
        self.turn_sec_var = tk.StringVar(value=str(self.config.get('search_turn_sec', 1.5)))
        ttk.Label(grid, text='Разворот камеры (сек; поиск и бой)').grid(row=5, column=0, sticky='w', padx=6)
        ttk.Entry(grid, width=12, textvariable=self.turn_sec_var).grid(row=6, column=0, sticky='w', padx=6)
        self.turn_mode_var = tk.StringVar(value=self.config.get('search_turn_mode', 'рывок'))
        ttk.Label(grid, text='Режим поворота:').grid(row=5, column=1, sticky='w', padx=6)
        ttk.Combobox(grid, textvariable=self.turn_mode_var, values=('рывок','часто'), width=12, state='readonly').grid(row=6, column=1, sticky='w', padx=6)
        ttk.Label(grid, text='B: каждые 2 с пока поиск включён').grid(row=1, column=1, sticky='w', padx=8, pady=5)
        self.field(grid, 'Тайм-аут атаки (с)', 'attack_timeout_sec', 1, 2)
        self.field(grid, 'Проверка имени в бою (мс)', 'ocr_check_ms', 2, 0)
        self.field(grid, 'Подтверждение агрессора (мс)', 'threat_settle_ms', 3, 2)
        self.field(grid, 'Нет урона: диагностический порог (с)', 'combat_no_damage_sec', 8, 0)
        self.field(grid, 'Старая настройка потери имени (не используется)', 'combat_lost_identity_sec', 8, 1)
        self.field(grid, 'Минимум боя при видимом имени (с)', 'min_combat_sec', 9, 0)
        self.field(grid, 'Tab перед поворотом (мин)', 'min_tabs_between_turns', 8, 2)
        self.never_camera_var = tk.BooleanVar(value=self.config.get('never_move_camera', False))
        ttk.Checkbutton(grid, text='НИКОГДА не двигать камеру (в обоих режимах)', variable=self.never_camera_var, command=self.on_camera_toggle).grid(row=4, column=0, columnspan=3, sticky='w', padx=6, pady=3)
        self.combat_spin_var = tk.BooleanVar(value=self.config['combat_spin'])
        ttk.Checkbutton(grid, text='Вращать также в бою при поиске по списку (общий таймер)', variable=self.combat_spin_var, command=self.on_combat_spin_toggle).grid(row=7, column=0, columnspan=3, sticky='w', padx=6, pady=3)
        self.attack_all_var = tk.BooleanVar(value=self.config.get('attack_all_targets', False))
        ttk.Checkbutton(grid, text='Непрерывная атака БЕЗ Tab и проверки имён (переключается на ходу)',
                        variable=self.attack_all_var, command=self.on_attack_all_toggle).grid(
                        row=11, column=0, columnspan=3, sticky='w', padx=6, pady=4)
        self.six_spam_var = tk.BooleanVar(value=self.config.get('six_spam_enabled', False))
        ttk.Checkbutton(grid, text='LT+A (кнопка 6): каждые 80 с серия 4 с, вместе с RB+RT',
                        variable=self.six_spam_var).grid(row=10, column=0, columnspan=3, sticky='w', padx=6, pady=4)
        self.repeat_var = tk.BooleanVar(value=self.config['repeat_search'])
        ttk.Checkbutton(grid, text='После цели искать следующую', variable=self.repeat_var).grid(row=2, column=1, columnspan=2, sticky='w', padx=6)
        ttk.Separator(area).pack(fill='x', pady=9)
        aggro = ttk.LabelFrame(area, text='Дополнительные мобы, нацеленные на игрока (ЭКСПЕРИМЕНТ)')
        aggro.pack(fill='x', pady=(0, 7))
        self.protect_var = tk.BooleanVar(value=self.config.get('protect_player', False))
        ttk.Checkbutton(aggro, text='Атаковать и мобов НЕ из списка, если их цель — мой персонаж',
                        variable=self.protect_var).pack(anchor='w', padx=6, pady=3)
        own = ttk.Frame(aggro)
        own.pack(fill='x', padx=6, pady=2)
        ttk.Label(own, text='Имя персонажа:').pack(side='left', padx=(0, 5))
        self.player_var = tk.StringVar(value=self.config.get('player_name', 'Darkleam'))
        ttk.Entry(own, textvariable=self.player_var, width=24).pack(side='left')
        ttk.Label(own, text='Проверка других мобов во время атаки (сек):').pack(side='left', padx=(12, 4))
        self.threat_sec_var = tk.StringVar(value=str(self.config.get('threat_scan_sec', 6)))
        ttk.Entry(own, textvariable=self.threat_sec_var, width=5).pack(side='left')
        ttk.Label(aggro, textvariable=self.threat_roi_status).pack(anchor='w', padx=6)
        tb = ttk.Frame(aggro)
        tb.pack(anchor='w', padx=5, pady=4)
        ttk.Button(tb, text='Область имени игрока справа', command=self.select_threat_roi).pack(side='left', padx=(0, 6))
        ttk.Label(area, textvariable=self.roi_status, wraplength=620).pack(anchor='w')
        b = ttk.Frame(area)
        b.pack(fill='x', pady=8)
        ttk.Button(b, text='Область имени', command=self.select_roi).pack(side='left', padx=(0, 5))
        ttk.Button(b, text='Сохранить', command=self.save).pack(side='left')
        c = ttk.Frame(area)
        c.pack(fill='x', pady=(0, 8))
        ttk.Button(c, text='Найти окно Aion 2', command=self.find_window).pack(side='left', padx=(0, 6))
        ttk.Button(c, text='Ctrl+F8 — запуск/пауза', command=self.toggle).pack(side='left', padx=(0, 6))
        ttk.Button(c, text='Ctrl+F9 — СТОП', command=self.stop).pack(side='left')
        ttk.Button(c, text='ЖУРНАЛ', command=self.open_log).pack(side='left', padx=(7, 0))
        d = ttk.Frame(area)
        d.pack(fill='x', pady=(0, 5))
        ttk.Button(d, text='СТАРТ с задержкой 5 сек (без горячих клавиш)',
                   command=self.delayed_start).pack(side='left', padx=(0, 6))
        ttk.Label(area, text='Lua и G8/G9 не нужны. Сборщик ресурсов и этот сканер одновременно не запускайте.').pack(anchor='w', pady=(0, 6))
        captcha = ttk.LabelFrame(area, text='CAPTCHA Watchdog — остановка и звуковая тревога (эксперимент)')
        captcha.pack(fill='x', pady=(5, 8))
        self.captcha_enabled_var = tk.BooleanVar(value=self.config.get('captcha_watch_enabled',True))
        ttk.Checkbutton(captcha, text='Следить за центральным окном CAPTCHA (по форме и элементам)',
                        variable=self.captcha_enabled_var, command=self.on_captcha_watch_toggle).pack(anchor='w',padx=8,pady=4)
        row = ttk.Frame(captcha)
        row.pack(fill='x', padx=8, pady=(2,5))
        ttk.Label(row,text='Звуковой выход:').pack(side='left')
        self.captcha_device_var=tk.StringVar(value=self.config.get('captcha_audio_device','AG271QG4'))
        ttk.Entry(row,textvariable=self.captcha_device_var,width=27).pack(side='left',padx=(6,8))
        ttk.Button(row,text='ТЕСТ ЗВУКА',command=self.test_captcha_sound).pack(side='left',padx=3)
        ttk.Button(row,text='Список выходов',command=self.list_audio_outputs).pack(side='left',padx=3)
        ttk.Label(row,text='Ctrl+F10 — тишина').pack(side='left',padx=3)
        row2=ttk.Frame(captcha)
        row2.pack(fill='x', padx=8,pady=(0,6))
        ttk.Button(row2,text='Выключить тревогу (Ctrl+F10)',command=self.silence_captcha_sound).pack(side='left',padx=(0,6))
        ttk.Button(row2,text='Тест тревоги (без игры)',
                   command=self.simulate_captcha).pack(side='left')
        self.captcha_ui_status=tk.StringVar(value='Детектор откалиброван по настоящей русской капче; перед фармом проверь тест тревоги.')
        ttk.Label(captcha,textvariable=self.captcha_ui_status,
                  wraplength=740,foreground='#a35b00').pack(anchor='w',padx=8,pady=(0,6))
        death = ttk.LabelFrame(area, text='Смерть персонажа — отдельная тревога (проверка раз в 5 сек)')
        death.pack(fill='x', pady=(5, 8))
        self.death_enabled_var = tk.BooleanVar(value=self.config.get('death_watch_enabled', True))
        ttk.Checkbutton(death, text='Следить за окном смерти независимо от режима атаки и OCR',
                        variable=self.death_enabled_var, command=self.on_death_watch_toggle).pack(anchor='w',padx=8,pady=4)
        death_actions=ttk.Frame(death)
        death_actions.pack(fill='x',padx=8,pady=(0,5))
        ttk.Button(death_actions,text='ТЕСТ звука смерти',command=self.test_death_sound).pack(side='left',padx=(0,6))
        ttk.Button(death_actions,text='Тест смерти: остановка + звук (без игры)',command=self.simulate_death).pack(side='left')
        ttk.Label(death, text='Отдельный низкий сигнал на том же устройстве, что CAPTCHA. '
                  'Ctrl+F10 — выключить любой звук; после проверки запусти фарм Ctrl+F8.',
                  wraplength=740).pack(anchor='w',padx=8,pady=(0,6))
        self.death_ui_status=tk.StringVar(value='Ожидание. Проверяется только во время активного фарма.')
        ttk.Label(death,textvariable=self.death_ui_status,wraplength=740,foreground='#a35b00').pack(anchor='w',padx=8,pady=(0,6))
        ttk.Label(d, text='Ctrl+F9 отпускает все кнопки и триггеры Xbox.').pack(side='left')
        ttk.Label(area, textvariable=self.status, foreground='#007779', wraplength=660).pack(anchor='w', pady=6)
        log_row = ttk.Frame(area)
        log_row.pack(fill='x', pady=(3, 4))
        ttk.Label(log_row, text='Журнал событий: ' + str(LOG_PATH)).pack(side='left')
        ttk.Button(log_row, text='Копировать журнал', command=self.copy_log).pack(side='right', padx=3)
        ttk.Button(log_row, text='Сохранить журнал...', command=self.save_log).pack(side='right', padx=3)
        ttk.Button(log_row, text='Открыть файл журнала', command=self.open_log).pack(side='right', padx=3)
        logframe = ttk.Frame(area)
        logframe.pack(fill='both', expand=True)
        self.logbox = tk.Text(logframe, height=13, width=80, state='disabled', font=('Consolas', 9), wrap='none')
        self.logbox.pack(side='left', fill='both', expand=True)
        logscroll = ttk.Scrollbar(logframe, orient='vertical', command=self.logbox.yview)
        logscroll.pack(side='right', fill='y')
        self.logbox.configure(yscrollcommand=logscroll.set)
        self.log('CAPTCHA: Ctrl+F10 — выключить тревогу; после проверки Ctrl+F8 — запуск. Звук AG271QG4.')
        self.log('ФАЙЛ ЖУРНАЛА: ' + str(LOG_PATH))
        self.log('Для защиты от мобов вне списка включи галочку, затем проверь OCR справа: Darkleam.')
        self.log('Визуальная библиотека: ' + str(len(self.visual_library.entries)) + ' сохранённых PNG-образцов.')

    def copy_log(self):
        try:
            value = LOG_PATH.read_text(encoding='utf-8') if LOG_PATH.exists() else self.logbox.get('1.0', 'end')
            self.root.clipboard_clear()
            self.root.clipboard_append(value)
            self.root.update()
            self.show('Журнал скопирован в буфер обмена.')
        except Exception as exc:
            messagebox.showerror('Журнал', str(exc), parent=self.root)

    def save_log(self):
        try:
            destination = filedialog.asksaveasfilename(parent=self.root,
                title='Сохранить журнал', defaultextension='.txt', initialfile='scanner_log.txt',
                filetypes=[('Текстовые файлы', '*.txt'), ('Все файлы', '*.*')])
            if destination:
                value = LOG_PATH.read_text(encoding='utf-8') if LOG_PATH.exists() else self.logbox.get('1.0', 'end')
                Path(destination).write_text(value, encoding='utf-8')
                self.show('Журнал сохранён: ' + destination)
        except Exception as exc:
            messagebox.showerror('Журнал', str(exc), parent=self.root)

    def open_log(self):
        try:
            LOG_PATH.touch(exist_ok=True)
            os.startfile(str(LOG_PATH))
        except Exception as exc:
            messagebox.showerror('Журнал', str(exc), parent=self.root)

    def log(self, msg):
        self.events.put(('log', msg))

    def show(self, msg):
        self.events.put(('status', msg))

    def poll_ui(self):
        if self.closed.is_set():
            return
        # System RegisterHotKey sends WM_HOTKEY events from its dedicated Windows message loop.
        # Focus lost: stop worker and issue RELEASE via bridge (background).
        if self.active.is_set() and not self.game_active():
            self.active.clear()
            self.log('Потерян фокус игры: аварийная остановка.')
            threading.Thread(target=self.finish_bridge, daemon=True).start()
        while True:
            try:
                kind, value = self.events.get_nowait()
            except queue.Empty:
                break
            if kind == 'hotkey':
                {'sample_player': self.capture_player_sample, 'sample_mob': self.capture_mob_sample,
                 'toggle': self.toggle, 'stop': self.stop,
                 'silence_captcha': self.silence_captcha_sound}[value]()
            elif kind == 'status':
                self.status.set(value)
            elif kind == 'captcha_alert':
                self.captcha_ui_status.set('CAPTCHA обнаружена. Макросы остановлены; после проверки запусти Ctrl+F8.')
            elif kind == 'death_alert':
                self.death_ui_status.set('СМЕРТЬ! Макросы остановлены; после воскрешения запусти Ctrl+F8.')
            elif kind == 'audio_error':
                self.log('Не удалось подать звук на AG271QG4: '+str(value))
                self.captcha_ui_status.set('ОШИБКА ЗВУКА: '+str(value))
            else:
                line = f'[{time.strftime("%H:%M:%S")}.{int(time.time()%1*1000):03d}] {value}\n'
                try:
                    with LOG_PATH.open('a', encoding='utf-8') as f:
                        f.write(line)
                except OSError:
                    pass
                self.logbox.configure(state='normal')
                self.logbox.insert('end', line)
                self.logbox.see('end')
                self.logbox.configure(state='disabled')
        self.root.after(60, self.poll_ui)

    def parse_ui(self):
        cfg = dict(self.config)
        cfg['targets'] = parse_targets(self.targets_box.get('1.0', 'end'))
        cfg['visual_mode'] = self.visual_mode.get()
        cfg['visual_player_enabled'] = bool(self.visual_player_enabled.get())
        cfg['captcha_watch_enabled'] = bool(self.captcha_enabled_var.get())
        cfg['death_watch_enabled'] = bool(self.death_enabled_var.get())
        cfg['captcha_audio_device'] = self.captcha_device_var.get().strip() or 'AG271QG4'
        # Read live checkbox state BEFORE validating an empty whitelist.
        cfg['attack_all_targets'] = bool(self.attack_all_var.get())
        if not cfg['targets'] and not cfg['attack_all_targets']:
            raise ValueError('Введи хотя бы одно имя моба или включи «Непрерывная атака БЕЗ Tab».')
        if cfg['visual_mode'] not in ('text', 'hybrid', 'visual'):
            raise ValueError('Неверный режим распознавания.')
        for key, var in self.fields.items():
            cfg[key] = float(var.get().replace(',', '.').strip()) if key in ('combat_turn_sec','combat_no_damage_sec','combat_lost_identity_sec') else int(var.get().strip())
        cfg['repeat_search'] = bool(self.repeat_var.get())
        cfg['six_spam_enabled'] = bool(self.six_spam_var.get())
        cfg['combat_spin'] = bool(self.combat_spin_var.get())
        cfg['never_move_camera'] = bool(self.never_camera_var.get())
        cfg['protect_player'] = bool(self.protect_var.get())
        cfg['player_name'] = self.player_var.get().strip()
        cfg['threat_scan_sec'] = int(self.threat_sec_var.get().strip())
        cfg['search_turn_sec'] = float(self.turn_sec_var.get().strip().replace(',', '.'))
        cfg['search_turn_mode'] = self.turn_mode_var.get()
        if not 0.25 <= cfg['search_turn_sec'] <= 10:
            raise ValueError('Разворот при поиске: интервал от 0,25 до 10 секунд.')
        if not 2 <= cfg['threat_scan_sec'] <= 30:
            raise ValueError('Интервал проверки дополнительных мобов: 2–30 сек.')
        if cfg['protect_player'] and not cfg['player_name']:
            raise ValueError('Укажи свой игровой ник для режима защиты.')
        bounds = {
            'tab_interval_ms': (70, 2500),
            'tabs_per_sector': (1, 60),
            'turn_ms': (-800, 800),
            'combat_turn_ms': (-800, 800),
            'combat_turn_sec': (0.25, 30),
            'turn_delay_ms': (0, 2000),
            'attack_timeout_sec': (15, 300),
            'min_combat_sec': (1, 30),
            'ocr_check_ms': (100, 2000),
            'threat_settle_ms': (160, 800),
            'combat_no_damage_sec': (1.5, 15.0),
            'combat_lost_identity_sec': (0.6, 5.0),
            'min_tabs_between_turns': (1, 60),
        }
        for name, (minimum, maximum) in bounds.items():
            if not minimum <= cfg[name] <= maximum:
                raise ValueError(f'{name}: допустимый диапазон {minimum}..{maximum}')
        if cfg['turn_ms'] == 0 and not cfg['never_move_camera']:
            raise ValueError('Поворот камеры не может равняться 0.')
        roi = cfg['name_roi']
        if not isinstance(roi, list) or len(roi) != 4 or not (0 <= roi[0] < roi[2] <= 1 and 0 <= roi[1] < roi[3] <= 1):
            raise ValueError('Неверная область OCR — настрой её повторно.')
        tr = cfg['threat_roi']
        if not isinstance(tr, list) or len(tr) != 4 or not (0 <= tr[0] < tr[2] <= 1 and 0 <= tr[1] < tr[3] <= 1):
            raise ValueError('Неверная область имени персонажа справа.')
        return cfg

    def save(self):
        try:
            cfg = self.parse_ui()
            CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False), encoding='utf-8')
            self.config = cfg
            if self.active.is_set():
                # Apply list edits without restarting the scanner; other fields
                # still apply on the next start for predictable camera timing.
                self.current_cfg['targets'] = list(cfg['targets'])
                self.current_cfg['attack_all_targets'] = cfg['attack_all_targets']
                self.log('СПИСОК ОБНОВЛЁН во время поиска: ' + ' | '.join(cfg['targets']))
            self.log('Настройки сохранены. Имен: ' + str(len(cfg['targets'])) + '; ' + ' | '.join(cfg['targets']))
            return True
        except Exception as exc:
            messagebox.showerror('Ошибка настроек', str(exc), parent=self.root)
            return False

    def on_camera_toggle(self):
        """Independent live camera switch; affects both attack modes."""
        disabled = bool(self.never_camera_var.get())
        self.current_cfg['never_move_camera'] = disabled
        self.config['never_move_camera'] = disabled
        if disabled: self.bridge.stop_camera()
        self.log('КАМЕРА / ' + ('ВЫКЛ во всех режимах' if disabled else
                                'ВКЛ во всех режимах (общий таймер)'))

    def on_combat_spin_toggle(self):
        """Preserve original extra combat-spin option for whitelist mode."""
        enabled = bool(self.combat_spin_var.get())
        self.current_cfg['combat_spin'] = enabled
        self.config['combat_spin'] = enabled
        self.log('КАМЕРА / в бою по списку: ' + ('ВКЛ' if enabled else 'ВЫКЛ'))

    def on_attack_all_toggle(self):
        """Hot-switch attack policy. Whitelist OCR/PNG mode is left intact.

        The worker transitions modes on its next loop iteration. In particular,
        switching OFF continuous attack releases weaving before any whitelist
        TAB, while switching it ON stops all further OCR/Tab scanning.
        """
        enabled = bool(self.attack_all_var.get())
        self.current_cfg['attack_all_targets'] = enabled
        self.config['attack_all_targets'] = enabled
        self.log('РЕЖИМ / ' +
                 ('НЕПРЕРЫВНАЯ АТАКА: ВКЛ (без Tab, OCR и проверки имени)' if enabled else
                  'СТАРЫЙ СПИСКОВЫЙ ПОИСК: ВКЛ (Tab, PNG, OCR, агрессоры)'))
        self.show('Режим: ' + ('непрерывный боевой макрос без Tab' if enabled else
                                'поиск разрешённых целей по списку') +
                  '. Для сохранения настройки нажми «Сохранить».')

    def any_tab_target_confirmed(self, sct, cfg):
        """Confirm a real selected-target HP HUD; never trust OCR junk alone.

        Tab ordinarily selects enemy targets only. A second measurement allows
        time for the HP HUD to settle when a fresh target was just selected.
        This is not an allegiance/faction filter and will accept a hostile player
        if AION2 shows the same target HP HUD.
        """
        if not cfg.get('attack_all_targets', False):
            return False
        if self.target_hp_signal(sct)[0]:
            return True
        if not self.wait(.080):
            return False
        return bool(cfg.get('attack_all_targets', False) and
                    self.target_hp_signal(sct)[0])

    def _try_capture_sample(self, kind):
        if self.active.is_set():
            messagebox.showwarning('Библиотека', 'Сначала останови поиск Ctrl+F9, чтобы цель не менялась.', parent=self.root)
            return
        if self.game_active():
            self._capture_sample_now(kind)
        else:
            # Called by a Tk button rather than an in-game global hotkey.
            self.show('Через 3 секунды снимок. Переключись в Aion 2 и выдели нужного моба.')
            self.root.after(3000, lambda: self._capture_sample_now(kind))

    def capture_mob_sample(self):
        self._try_capture_sample('mob')

    def capture_player_sample(self):
        self._try_capture_sample('player')

    def _capture_sample_now(self, kind):
        if self.closed.is_set() or self.active.is_set():
            return
        if not self.game_active():
            self.log('ОБРАЗЕЦ / ОТМЕНЁН: вернись в привязанное окно Aion 2.')
            self.show('Снимок отменён: Aion 2 не в фокусе. Сначала выбери окно игры.')
            return
        try:
            roi = self.config['name_roi'] if kind == 'mob' else self.config['threat_roi']
            with mss.mss() as sct:
                raw = self.screenshot_region(sct, roi)
            # Preview is shown BEFORE any image is added to the library.
            try:
                self.initialize_ocr(self.config)
                suggestion = (ocr_name(raw) if kind == 'mob' else
                              ocr_player_name(raw, self.config.get('player_name','Darkleam')))
            except Exception:
                # Saving a sample must not depend on Tesseract being ready.
                suggestion = ''
            win = tk.Toplevel(self.root)
            win.title('Образец ' + ('имени моба' if kind == 'mob' else 'Darkleam'))
            win.transient(self.root)
            win.resizable(False, False)
            win.grab_set()
            panel = ttk.Frame(win, padding=12)
            panel.pack(fill='both', expand=True)
            img = cv2.cvtColor(raw, cv2.COLOR_BGRA2RGB)
            preview = ImageTk.PhotoImage(Image.fromarray(img).resize((raw.shape[1]*2,raw.shape[0]*3)))
            ttk.Label(panel, image=preview).pack(pady=(0, 9))
            win.preview_ref = preview
            ttk.Label(panel, text='Проверь, что это именно имя в верхней панели, а не фон.').pack(anchor='w')
            ttk.Label(panel, text='Название (можно исправить OCR):').pack(anchor='w', pady=(9, 2))
            val = tk.StringVar(value=(self.config.get('player_name','Darkleam') if kind=='player' else suggestion))
            edit = ttk.Entry(panel,textvariable=val,width=52)
            edit.pack(fill='x')
            if kind == 'mob':
                add_to_targets = tk.BooleanVar(value=True)
                ttk.Checkbutton(panel,text='Добавить в список целей для атаки',variable=add_to_targets).pack(anchor='w',pady=7)
            else:
                ttk.Label(panel, text='Образец используется только в проверке агрессии, НЕ как имя моба.').pack(anchor='w',pady=7)
            foot = ttk.Frame(panel)
            foot.pack(fill='x', pady=(10,0))
            def commit():
                name = val.get().strip()
                try:
                    if kind == 'player' and signature(name) != signature(self.player_var.get().strip()):
                        raise ValueError('Образец правой панели должен совпадать с именем игрока в настройках.')
                    self.visual_library.add(kind, name, raw)
                    if kind == 'mob' and add_to_targets.get():
                        existing = parse_targets(self.targets_box.get('1.0','end'))
                        if signature(name) not in {signature(v) for v in existing}:
                            existing.append(name)
                            self.targets_box.delete('1.0','end')
                            self.targets_box.insert('1.0','\n'.join(existing))
                        self.save()
                    self.log(f'ОБРАЗЕЦ / СОХРАНЁН: {kind}: {name!r}; всего PNG={len(self.visual_library.entries)}')
                    self.show('Образец сохранён: ' + name)
                    win.destroy()
                except Exception as exc:
                    messagebox.showerror('Ошибка сохранения', str(exc), parent=win)
            ttk.Button(foot, text='Сохранить образец',command=commit).pack(side='left',padx=(0,8))
            ttk.Button(foot, text='Отмена',command=win.destroy).pack(side='left')
            edit.focus_set()
        except Exception as exc:
            self.log('ОБРАЗЕЦ / ОШИБКА: ' + str(exc))
            messagebox.showerror('Образец',str(exc),parent=self.root)

    def open_visual_library(self):
        win=tk.Toplevel(self.root)
        win.title('Визуальные образцы — цели, исключения и Darkleam')
        win.geometry('660x400')
        panel=ttk.Frame(win,padding=12)
        panel.pack(fill='both', expand=True)
        ttk.Label(panel,text='Цель: будет атакована, если имя есть в текстовом списке. Исключение: только защита от ложного совпадения.').pack(anchor='w')
        grid=ttk.Treeview(panel,columns=('name','state','count'),show='headings',height=11,selectmode='browse')
        grid.heading('name',text='Название');grid.column('name',width=250)
        grid.heading('state',text='Тип');grid.column('state',width=230)
        grid.heading('count',text='Снимков');grid.column('count',width=75,anchor='center')
        grid.pack(fill='both',expand=True,pady=(10,5))
        lookup={}
        def refresh():
            grid.delete(*grid.get_children());lookup.clear()
            allowed={signature(n) for n in parse_targets(self.targets_box.get('1.0','end'))}
            for i,r in enumerate(self.visual_library.summary()):
                typ='Игрок / защита' if r['kind']=='player' else ('Цель для атаки' if signature(r['name']) in allowed else 'Исключение (не атаковать)')
                iid=str(i);lookup[iid]=r
                grid.insert('', 'end', iid=iid, values=(r['name'],typ,r['count']))
        def remove():
            sel=grid.selection()
            if not sel:return
            r=lookup[sel[0]]
            if not messagebox.askyesno('Удаление',f'Удалить все образцы для {r["name"]!r}?',parent=win):return
            num=self.visual_library.delete_name(r['kind'],r['name'])
            if r['kind']=='mob':
                names=[n for n in parse_targets(self.targets_box.get('1.0','end')) if signature(n)!=signature(r['name'])]
                self.targets_box.delete('1.0','end');self.targets_box.insert('1.0','\n'.join(names))
                if names:self.save()
                else:self.show('Список целей пуст. Добавь имя перед запуском.')
            self.log(f'ОБРАЗЕЦ / УДАЛЕНО: {r["name"]!r} ({num} PNG)')
            refresh()
        controls=ttk.Frame(panel);controls.pack(fill='x',pady=5)
        ttk.Button(controls,text='Удалить выбранного моба / образцы',command=remove).pack(side='left',padx=(0,8))
        ttk.Button(controls,text='Обновить',command=refresh).pack(side='left')
        ttk.Button(controls,text='Закрыть',command=win.destroy).pack(side='right')
        ttk.Label(panel,text='Удаление цели также убирает её имя из списка поиска. Для повторного добавления сохрани новый снимок.').pack(anchor='w')
        refresh()

    def visual_name(self, raw, cfg):
        """(name,score) only for a decisive complete-glyph match.

        A separately stored *excluded* mob acts as a negative sample.
        """
        if cfg.get('visual_mode','hybrid') == 'text':
            return '', 0.0
        name,score,margin=self.visual_library.match('mob',raw)
        if score >= .72 and margin >= .12:
            return name,score
        return '',score

    def select_roi(self):
        if self.active.is_set():
            messagebox.showwarning('Пауза', 'Сначала останови поиск Ctrl+F9.', parent=self.root)
            return
        with mss.mss() as sct:
            screenshot = np.array(sct.grab(sct.monitors[1]))
        pic = Image.fromarray(cv2.cvtColor(screenshot, cv2.COLOR_BGRA2RGB))
        def on_select(roi):
            self.config['name_roi'] = roi
            self.roi_status.set('Область: ' + ', '.join(f'{c:.3f}' for c in roi))
            self.save()
        ROISelector(self.root, pic, on_select)

    def select_threat_roi(self):
        if self.active.is_set():
            messagebox.showwarning('Пауза', 'Останови поиск перед настройкой.', parent=self.root)
            return
        with mss.mss() as sct:
            screenshot = np.array(sct.grab(sct.monitors[1]))
        pic = Image.fromarray(cv2.cvtColor(screenshot, cv2.COLOR_BGRA2RGB))
        def on_select(roi):
            self.config['threat_roi'] = roi
            self.threat_roi_status.set('Область имени справа: ' + ', '.join(f'{c:.3f}' for c in roi))
            self.save()
        ROISelector(self.root, pic, on_select)

    def test_threat(self):
        try:
            cfg = self.parse_ui()
        except Exception as exc:
            self.log('Ошибка настроек: ' + str(exc)); return
        def task():
            try:
                self.initialize_ocr(cfg)
                with mss.mss() as sct:
                    selected = self.screenshot_name(sct, cfg['name_roi'])
                    is_self, player, score, method = self.check_threat(sct, cfg, force_ocr=True)
                self.log(f'ТЕСТ: выбран моб={selected!r}; справа={player!r}; мой ник={cfg["player_name"]!r}; совпало={is_self}; метод={method}; score={score:.3f}')
                self.show('Правая панель: ' + (player or '(не прочитано)'))
            except Exception as exc:
                self.log('Ошибка проверки правой панели: ' + str(exc))
        threading.Thread(target=task, daemon=True).start()

    def find_window(self):
        records = enum_candidate_windows()
        likely = [(hwnd, title) for hwnd, title in records if 'aion' in title.casefold() or 'айон' in title.casefold()]
        if len(likely) == 1:
            self.game_hwnd = likely[0][0]
            self.log('Окно Aion 2 найдено: ' + likely[0][1] + ' (HWND ' + str(self.game_hwnd) + ')')
            self.show('Игра привязана. Для запуска используй Ctrl+F8.')
            return
        # Allow a one-off selection if the actual game has an unexpected window title.
        choices = likely if likely else records
        popup = tk.Toplevel(self.root)
        popup.title('Выбор окна игры')
        popup.geometry('650x270')
        popup.transient(self.root)
        ttk.Label(popup, text='Выбери именно окно Aion 2 из списка окон Windows:').pack(anchor='w', padx=10, pady=8)
        lb = tk.Listbox(popup, width=90, height=8)
        lb.pack(fill='both', expand=True, padx=10)
        for hwnd, title in choices:
            lb.insert('end', f'{title}  [HWND {hwnd}]')
        if choices:
            lb.selection_set(0)
        def choose():
            sel = lb.curselection()
            if not sel:
                return
            hwnd, title = choices[sel[0]]
            self.game_hwnd = hwnd
            self.log('Вручную выбрано окно: ' + title + ' (HWND ' + str(hwnd) + ')')
            self.show('Окно привязано. Проверь OCR, затем поиск.')
            popup.destroy()
        ttk.Button(popup, text='Использовать выбранное окно', command=choose).pack(pady=8)

    def delayed_start(self):
        if not self.game_hwnd:
            self.log('Сначала нажми «Найти окно Aion 2».')
            return
        if not self.save():
            return
        self.start_generation += 1
        seq = self.start_generation
        self.show('Старт через 5 секунд — перейди в игру!')
        self.log('Запланирован старт через 5 секунд. Ввод Xbox начнётся только при активном окне игры.')
        def start():
            if seq != self.start_generation or self.closed.is_set():
                return
            if not self.game_active():
                self.log('Отмена запуска: Aion 2 не активно. Повтори старт с задержкой.')
                return
            if not self.active.is_set():
                self.toggle()
        self.root.after(5000, start)

    def test_bridge_tab(self):
        if self.active.is_set():
            self.log('Для теста моста останови автопоиск.')
            return
        self.log('Тест выбора цели RS: вернись в игру за 4 сек. Lua не нужен.')
        generation = self.start_generation
        def task():
            time.sleep(4)
            if self.game_active() and not self.closed.is_set() and generation == self.start_generation and not self.active.is_set():
                try:
                    self.bridge.test_button('TAB', lambda: generation == self.start_generation and not self.active.is_set())
                    self.log('Xbox: одиночное нажатие RS передано; результат проверь в игре.')
                    self.bridge.finish()
                except Exception as exc:
                    self.log('Ошибка моста: ' + str(exc))
            else:
                self.log('Тест отменён: игра не в фокусе.')
        threading.Thread(target=task, daemon=True).start()

    def test_bridge_f(self):
        """One native B press without weaving or background timers."""
        if self.active.is_set():
            self.log('Для теста F останови автопоиск.')
            return
        self.log('Тест лута B: вернись в игру за 4 сек. B будет нажата один раз, без атаки.')
        generation = self.start_generation
        def task():
            time.sleep(4)
            if self.game_active() and not self.closed.is_set() and generation == self.start_generation and not self.active.is_set():
                try:
                    self.bridge.test_button('F', lambda: generation == self.start_generation and not self.active.is_set())
                    self.log('Xbox: передана одиночная B без атаки; проверь действие в игре.')
                    self.bridge.finish()
                except Exception as exc:
                    self.log('Ошибка теста F: ' + str(exc))
            else:
                self.log('Тест F отменён: игра не в фокусе.')
        threading.Thread(target=task, daemon=True).start()

    def release_macro(self):
        with self.macro_lock:
            if self.macro_running:
                self.bridge.send('RELEASE')
                self.macro_running = False
                self.log('Xbox: RB+RT отпущены; таймеры лута/бафа продолжаются до общего стопа.')

    def start_macro(self):
        with self.macro_lock:
            if not self.can_send():
                return False
            if not self.macro_running or not self.bridge.attacking:
                if self.bridge.send('START') is False:
                    self.macro_running = False
                    return False
                self.macro_running = True
                self.log('Xbox: RB+RT зажаты; B и LT+A не отпускают атаку.')
            return True

    def finish_bridge(self):
        with self.macro_lock:
            try:
                self.bridge.finish()
            except Exception as exc:
                self.log('Ошибка остановки моста: ' + str(exc))
            finally:
                self.macro_running = False

    def bind_instructions(self):
        messagebox.showinfo('Привязка игры',
                            'Выбери окно игры кнопкой «Найти окно Aion 2». Для сохранения имени моба нажми Ctrl+F6.\n'
                            'Не нужно открывать или активировать окно сканера.', parent=self.root)

    def bind_window(self):
        hwnd = u32.GetForegroundWindow()
        if not hwnd:
            self.log('Нет активного окна игры.')
            return
        pid = wintypes.DWORD()
        u32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if pid.value == os.getpid():
            self.log('Нельзя привязывать окно самого сканера. Переключись в Aion 2.')
            return
        self.game_hwnd = hwnd
        self.log('Окно привязано (HWND ' + str(hwnd) + ').')
        self.show('Игра привязана. Ctrl+F8 — запуск поиска.')

    def screenshot_player(self, sct, roi, expected=None):
        return ocr_player_name(self.screenshot_region(sct, roi), expected)

    def screenshot_region(self, sct, roi):
        mon = sct.monitors[1]
        x0, y0, x1, y1 = roi
        rect = {'left': int(mon['left'] + x0 * mon['width']),
                'top': int(mon['top'] + y0 * mon['height']),
                'width': max(12, int((x1-x0) * mon['width'])),
                'height': max(8, int((y1-y0) * mon['height']))}
        return np.array(sct.grab(rect))

    def debug_threat_snapshot(self, sct, mob):
        """Save ONLY top HUD crops of accepted off-list targets for auditing.

        A mistaken target can be checked from the saved image without dumping
        the user's entire screen or chat. Limited to 12 snapshots per run.
        """
        try:
            if getattr(self, '_threat_debug_count', 0) >= 12:
                return
            self._threat_debug_count = getattr(self, '_threat_debug_count', 0) + 1
            folder = Path(__file__).with_name('debug_aggro')
            folder.mkdir(exist_ok=True)
            screenshot = self.screenshot_region(sct, [0.30, 0.017, 0.77, 0.085])
            filename = time.strftime('%H%M%S') + '_' + str(self._threat_debug_count) + '.png'
            cv2.imwrite(str(folder / filename), screenshot)
            self.log('ЗАЩИТА: сохранён кадр верхних панелей: debug_aggro/' + filename)
        except Exception as exc:
            self.log('ЗАЩИТА: не удалось сохранить кадр: ' + str(exc))

    @staticmethod
    def measure_target_hp(bar, frame):
        """Measure ONLY the anchored red HP strip, not red scenery behind HUD.

        On actual supplied Aion 2 debug screenshots the selected-target strip
        starts at x≈39.8% and occupies y≈6.3..7.3%. The previous 39.4..60%
        region included background rocks/sky, whose red pixels change as the
        camera rotates and falsely appear to be living/changing HP.

        The anchored bar is accompanied by a dark metallic left border. A
        colourful world crop without this frame must not count as target HP.
        """
        if bar is None or frame is None or bar.size == 0 or frame.size == 0:
            return False, 0
        fhsv = cv2.cvtColor(cv2.cvtColor(frame, cv2.COLOR_BGRA2BGR), cv2.COLOR_BGR2HSV)
        # In four user-supplied HUD screenshots the dark frame ratio is ~0.77.
        dark_ratio = float(np.mean(fhsv[:, :, 2] < 95))
        if dark_ratio < .28:
            return False, 0
        hsv = cv2.cvtColor(cv2.cvtColor(bar, cv2.COLOR_BGRA2BGR), cv2.COLOR_BGR2HSV)
        red = (cv2.inRange(hsv, (0, 115, 75), (10, 255, 255)) |
               cv2.inRange(hsv, (169, 115, 75), (179, 255, 255)))
        pink = cv2.inRange(hsv, (137, 115, 75), (169, 255, 255))
        color = (red | pink) > 0
        h, w = color.shape
        # The bar ALWAYS begins at its fixed left anchor, even when depleted.
        left = max(2, int(round(w * .008)))
        right = min(w, max(left + 14, int(round(w * .075))))
        if right - left < 7:
            return False, 0
        rows = np.count_nonzero(color[:, left:right], axis=1) >= .52 * (right - left)
        if int(np.count_nonzero(rows)) < max(3, int(h * .26)):
            return False, 0
        # Ignore every red pixel in world scenery outside valid HP strip rows.
        count = int(np.count_nonzero(red[rows]))
        return True, count

    def target_hp_signal(self, sct):
        """Selected-target HP, gated by the actual bar anchor and dark frame.

        The previous large ROI and a single background-colour threshold could
        report HP=True even when no target was selected. Never trust stray red
        pixels in a sky/rock texture as a real HP bar.
        """
        # One capture, rather than two different frames during a 2-second
        # camera sweep. Apart from lower latency, the dark frame and its HP
        # bar must originate from the SAME screen image.
        whole = self.screenshot_region(sct, [0.391, 0.063, 0.593, 0.073])
        split = int(round(whole.shape[1] * ((0.3975 - 0.391) / (0.593 - 0.391))))
        return self.measure_target_hp(whole[:, split:], whole[:, :split])

    def target_bar_present(self, sct):
        """A target HUD may exist even when its RED/PINK HP fill is depleted.

        Use the independently selected name text as supporting evidence.
        Called only AFTER OCR selected an allowed mob or right HUD confirmed
        Darkleam; this is never sufficient to start an attack by itself.
        """
        if self.target_hp_signal(sct)[0]:
            return True
        cfg = self.current_cfg
        name_crop = self.screenshot_region(sct, cfg['name_roi'])
        return self.visual_name_cache.fingerprint(name_crop) is not None

    def screenshot_name(self, sct, roi):
        image = self.screenshot_region(sct, roi)
        mark = self.visual_name_cache.fingerprint(image)
        cached = self.visual_name_cache.lookup(mark)
        if cached is not None:
            return cached
        result = ocr_name(image)
        self.visual_name_cache.store(mark, result)
        return result

    def read_name_crop(self, image):
        # Same cache policy as screenshot_name, but the same frame that was
        # inspected for target HUD settling is now OCR'd, avoiding a race.
        sig = self.visual_name_cache.fingerprint(image)
        cached = self.visual_name_cache.lookup(sig)
        if cached is not None:
            return cached
        value = ocr_name(image)
        self.visual_name_cache.store(sig, value)
        return value

    @staticmethod
    def _looks_like_target(name, targets):
        # Only retry borderline names with substantial overlap, not every
        # completely unrelated enemy (e.g. 'Черная бронированная').
        seen = normalize_name(name)
        for target in targets:
            full = normalize_name(target)
            if len(full) >= 8:
                for start in range(max(1, len(seen)-len(full)+1)):
                    piece = seen[start:start+len(full)]
                    if len(piece) >= 7 and SequenceMatcher(None, piece, full).ratio() >= .64:
                        return True
        # For short targets such as «Керуб» the old check len(full)>=8
        # never retried «Кери» / «Керб» at all. Only REQUEST an extra OCR
        # sample, do not accept the target from similarity alone.
        tokens = re.findall(r'[а-яё]{3,}', name.casefold().replace('ё','е'))
        for token in tokens:
            for target in targets:
                full = normalize_name(target)
                if len(full) >= 4 and (token[:3] == full[:3] or
                                       (len(full) <= 6 and len(token) >= 3 and
                                        SequenceMatcher(None, token, full).ratio() >= .72) or
                                       (len(token) >= 4 and SequenceMatcher(None, token, full).ratio() >= .72)):
                    return True
        return False

    def initialize_ocr(self, cfg):
        path = cfg.get('tesseract', DEFAULTS['tesseract'])
        pytesseract.pytesseract.tesseract_cmd = path if os.path.isfile(path) else 'tesseract'
        langs = pytesseract.get_languages(config='')
        if 'rus' not in langs:
            raise RuntimeError('В Tesseract отсутствует языковой пакет rus.')

    def test(self):
        if self.active.is_set():
            self.log('Останови поиск перед проверкой OCR.')
            return
        try:
            cfg = self.parse_ui()
        except Exception as exc:
            self.log('Ошибка настроек: ' + str(exc))
            return
        def task():
            try:
                self.initialize_ocr(cfg)
                with mss.mss() as sct:
                    crop = self.screenshot_region(sct, cfg['name_roi'])
                name = self.read_name_crop(crop)
                matched = find_target(name, cfg['targets'])
                visual_name,visual_score=self.visual_name(crop,cfg)
                self.log('ТЕСТ: OCR=' + repr(name) + '; OCR-цель=' + repr(matched) +
                         '; образец=' + repr(visual_name) + f'; совпадение формы={visual_score:.2f}')
                self.show('Тест имени: OCR ' + (name or '—') + ' / образец ' +
                          (visual_name or 'не найден') + f' ({visual_score:.2f})')
            except Exception as exc:
                self.log('Ошибка OCR: ' + str(exc))
        threading.Thread(target=task, daemon=True).start()

    def game_active(self):
        return self.game_hwnd is not None and u32.GetForegroundWindow() == self.game_hwnd

    def input_allowed(self):
        return (not self.closed.is_set() and self.game_active()
                and not self.captcha_locked.is_set() and not key_pressed(VK_CONTROL))

    def can_send(self):
        return self.active.is_set() and not self.closed.is_set() and self.game_active() and not key_pressed(VK_CONTROL)

    def toggle(self):
        self.start_generation += 1
        if self.active.is_set():
            self.active.clear()
            threading.Thread(target=self.finish_bridge, daemon=True).start()
            self.show('Пауза: все кнопки и триггеры Xbox отпускаются.')
            self.log('Пауза.')
            return
        if self.game_hwnd is None:
            self.log('Сначала нажми «Найти окно Aion 2» и выбери игровое окно вручную.')
            return
        if not self.save():
            return
        self.current_cfg = dict(self.config)
        self._name_miss_count = 0
        self._name_miss_seen = 0
        self._last_name_miss = 0.0
        # CAPTCHA/death still latch and STOP the macros immediately. Only an
        # explicit subsequent user START (Ctrl+F8 or delayed-start button) clears
        # the internal latch. There is no separate manual unlock step.
        if self.captcha_locked.is_set():
            self.captcha_sound.stop()
            self.death_sound.stop()
            self.captcha_locked.clear()
            self._death_alerted = False
            self._captcha_hits = 0
            self.captcha_ui_status.set('Слежение за CAPTCHA включено. Ожидание следующего события.')
            self.death_ui_status.set('Слежение за смертью включено. Ожидание следующего события.')
            self.log('Повторный запуск по команде пользователя: аварийная остановка сброшена.')
        self.active.set()
        self.show('Поиск включён. Ctrl+F8 пауза, Ctrl+F9 стоп.')
        self.log('Поиск включён. Режим=' + ('НЕПРЕРЫВНАЯ АТАКА БЕЗ TAB' if self.current_cfg.get('attack_all_targets') else 'список/агрессоры') + '; Имен: ' + str(len(self.config['targets'])) + '; защита от агрессоров: ' + ('ВКЛ' if self.config.get('protect_player') else 'ВЫКЛ') + '; камера=' + ('ВЫКЛ' if self.current_cfg.get('never_move_camera') else self.current_cfg.get('search_turn_mode', 'рывок')) + '; управление Xbox, без Lua и G9.')

    def stop(self):
        self.start_generation += 1
        self.active.clear()
        threading.Thread(target=self.finish_bridge, daemon=True).start()
        self.show('СТОП: отпускаю RB/RT, B, LT/A и стик камеры.')
        self.log('Поиск остановлен.')

    def wait(self, duration):
        end = time.monotonic() + duration
        while time.monotonic() < end:
            if not self.active.is_set() or self.closed.is_set():
                return False
            time.sleep(min(.025, max(0, end-time.monotonic())))
        return True

    def debug_skipped_name(self, sct, text, cfg):
        """Actual target-name pixels, not the unrelated right Darkleam panel.

        Saves at most 12 captures per run, >=2 sec apart. Never starts attack.
        """
        try:
            now = time.monotonic()
            n = getattr(self,'_name_miss_count',0)
            if n >= 12 or now - getattr(self,'_last_name_miss',0.) < 2.0:
                return
            # Target-like corrupted OCR is most useful; every fifth empty
            # reading also helps diagnose backgrounds that entirely hide text.
            clue = self._looks_like_target(text,cfg['targets']) or bool(fuzzy_full_target(text,cfg['targets']))
            self._name_miss_seen = getattr(self,'_name_miss_seen',0) + 1
            if not clue and self._name_miss_seen % 6:
                return
            self._last_name_miss = now
            self._name_miss_count = n + 1
            region = self.screenshot_region(sct,[0.382, 0.022, 0.622, 0.079])
            folder = Path(__file__).with_name('debug_name_miss')
            folder.mkdir(exist_ok=True)
            filename = time.strftime('%H%M%S') + '_' + str(n+1) + '.png'
            if cv2.imwrite(str(folder / filename),region):
                self.log(f'OCR / КАДР ПРОПУСКА ИМЕНИ: {text!r} -> debug_name_miss/{filename}')
        except Exception as exc:
            self.log('OCR / КАДР ПРОПУСКА: ошибка ' + repr(exc))

    def check_threat(self, sct, cfg, force_ocr=False):
        """Return (attacks_me, read_name, visual_score, method).

        Fast case is a template match on the player's green right HUD name.
        OCR is needed on ambiguous images, different nicknames and periodically
        after a visual miss. No target change is issued by this method.
        """
        if not cfg.get('protect_player'):
            return False, '', 0.0, 'disabled'
        image = self.screenshot_region(sct, cfg['threat_roi'])
        if cfg.get('visual_player_enabled',True):
            known,visual_score,margin=self.visual_library.match('player',image,cfg['player_name'])
            if known and visual_score >= .79:
                return True,cfg['player_name'],visual_score,'saved-shape'
        self.fast_threat_detector.calls += 1
        height = sct.monitors[1]['height']
        if cfg.get('fast_threat', True):
            found, score, usable = self.fast_threat_detector.check(image, cfg['player_name'], height)
            if found:
                return True, cfg['player_name'], score, 'template'
            fallback = (not usable or force_ocr or score >= .56 or
                        self.fast_threat_detector.calls % max(1, cfg.get('fast_threat_fallback_period',3)) == 0)
        else:
            score = 0.0
            fallback = True
        if fallback:
            # OCR can hallucinate the name from a few isolated green pixels.
            # Only attempt it if the full-size green name area contains enough
            # coloured glyph pixels. On the supplied 2048x1151 screenshots the
            # complete 'Darkleam' text has ~400+ pixels; no panel has ~0–50.
            hsv = cv2.cvtColor(cv2.cvtColor(image, cv2.COLOR_BGRA2BGR), cv2.COLOR_BGR2HSV)
            bounds = (24, 24, 80) if force_ocr else (28, 55, 110)
            colored = cv2.inRange(hsv, bounds, (105 if force_ocr else 95, 255, 255))
            min_glyphs = max(45 if force_ocr else 65,
                             int(image.shape[0]*image.shape[1]*(.008 if force_ocr else .012)))
            if cv2.countNonZero(colored) < min_glyphs:
                return False, '', score, 'no-green-text'
            name = ocr_player_name(image, cfg['player_name'])
            return player_matches(name, cfg['player_name']), name, score, 'OCR'
        return False, '', score, 'fast-skip'

    def is_threat(self, sct, cfg):
        return self.check_threat(sct, cfg)[0]

    def rotate_search(self, cfg):
        if cfg.get('never_move_camera') or not self.can_send():
            return
        milliseconds = int(cfg.get('turn_ms', 140))
        if cfg.get('search_turn_mode') == 'часто':
            milliseconds = (1 if milliseconds >= 0 else -1) * max(20, abs(milliseconds)//4)
        if milliseconds:
            self.bridge.turn(.45 if milliseconds > 0 else -.45, abs(milliseconds)/1000)


    def maybe_rotate_camera(self, cfg, state='поиск'):
        """Time-based camera movement; no dependency on TAB count or fight state.

        Right-stick time is not an angle; tune the same pulse in both modes.
        The selected target's combat handling is unchanged by orientation.
        """
        if cfg.get('never_move_camera') or (state == 'бой' and not cfg.get('combat_spin', True)):
            return False
        if not self.can_send():
            return False
        now = time.monotonic()
        sec = max(.25, float(cfg.get('search_turn_sec', 2.0)))
        if now - self.last_sweep < sec:
            return False
        # Reserve slot before input, preventing repeat bursts on slow machines.
        self.last_sweep = now
        self.rotate_search(cfg)
        self.tabs_since_turn = 0
        self.log(f'КАМЕРА / ТАЙМЕР: {state}; прошло={sec:g}с; '
                 f'импульс правого стика={cfg.get("turn_ms", 0)}мс; ' +
                 ('TAB не используется.' if state == 'непрерывная атака' else 'TAB не заблокирован.'))
        return True

    def interrupt_for_threat(self, sct, cfg, original):
        """Look for threats after temporarily ending the existing fight.

        Same-named mobs are NOT excluded: two mobs may have identical names.
        Once Darkleam has been read confidently once, keep that selected enemy.
        """
        self.release_macro()
        for _ in range(min(cfg['tabs_per_sector'] + 2, 8)):
            if not self.can_send():
                return None
            self.bridge.send('TAB')
            if not self.wait(.075):
                return None
            name = self.screenshot_name(sct, cfg['name_roi'])
            player = self.screenshot_player(sct, cfg['threat_roi'], cfg['player_name'])
            if player_matches(player, cfg['player_name']):
                self.log('ЗАЩИТА: другой моб нацелен на ' + cfg['player_name'] +
                         ': ' + (name or '(имя не прочитано)'))
                return name or '(агрессор с неразборчивым именем)'
        self.log('За время проверки другой агрессор не обнаружен; продолжаю поиск.')
        return None

    def attack(self, sct, cfg, target, reason='из списка'):
        """v2.6: anchor-validated HP and independent lost-identity watchdog; lock TAB while fighting, but NEVER blindly hold on a new mob.

        Stop macro after confirmed foreign OCR or selected mob change;
        guard against short OCR errors and intermittent HP flicker.  HP
        depletion followed by a persistent HUD reset is a secondary stop.
        """
        # If the checkbox was switched on during a preceding Tab scan, do
        # not perform even a single whitelist/OCR check in continuous mode.
        if cfg.get('attack_all_targets', False):
            return None
        self.log('БОЙ / ФИКСАЦИЯ ЦЕЛИ v2.6: ' + repr(target) + ' (' + reason + ') — удерживаю только пока не подтверждена смена или окончание.')
        self.show('Бой: ' + target)
        if not self.can_send():
            return None
        dispatch_start = time.monotonic()
        self.start_macro()
        dispatch_ms = round((time.monotonic() - dispatch_start) * 1000)
        if hasattr(self, '_selected_at'):
            self.log('АТАКА / ТАЙМИНГ: выбор Tab -> START=' +
                     str(round((time.monotonic()-self._selected_at)*1000)) +
                     ' мс; передача START=' + str(dispatch_ms) + ' мс; причина=' + reason)
        start = time.monotonic()
        self._last_kill_hp_disappeared_at = None
        last_ping = start
        last_diag = start
        last_warning = start
        hud_absent_since = None
        red_absent_since = None
        saw_red_bar = False
        maximum_red = 0
        low_red_samples = 0
        confirmed_low_red = False
        last_name = target
        last_identity_seen_at = start
        # In ALL-Tab mode any selected enemy is eligible, including names
        # that also happen to be on the whitelist. The first Tab OCR often
        # contains level text/noise and can disagree with the later reading
        # of the SAME target. Do not treat this disagreement as a target
        # switch; use the anchored HP HUD and existing loss/timeout guards.
        all_tab_fight = (reason == 'все цели Tab' or
                         bool(cfg.get('attack_all_targets', False)))
        guard = None if all_tab_fight else CombatIdentityGuard(target, cfg.get('targets', []))
        # Only *two separate low frames* followed by a return to a full bar
        # can suggest that weaving jumped to a new enemy automatically.
        hp_low_since = None
        hp_reset_samples = 0
        hp_was_low = False
        is_listed = reason == 'из списка'
        min_hold = cfg.get('min_combat_sec', 5)
        # A short HUD animation/dropout must not cancel combat in ALL-Tab
        # mode. Preserve the normal whitelist behaviour unchanged.
        hud_grace = max(1.8 if all_tab_fight else .75,
                        cfg.get('combat_hud_loss_confirm_sec', 1.15))
        hp_grace = max(.30, cfg.get('combat_hp_loss_confirm_sec', .36))
        empty_hp_grace = max(1.7, cfg.get('combat_empty_hp_stall_sec', 2.2))
        full_hp_stall = max(6.0, cfg.get('combat_full_hp_stall_sec', 8.0))
        stable_full_since = None
        zero_hp_since = None
        stale_low_since = None  # HUD artifact: target name gone, fixed tiny red remnant
        plateau_red = None
        plateau_since = None
        plateau_samples = 0  # repeated, nearly identical HP with unconfirmed target name
        # Save debug snapshot only AFTER START, so initial attack is never delayed.
        if not is_listed:
            self.debug_threat_snapshot(sct, target)
        try:
            while self.active.is_set() and not self.closed.is_set():
                if not self.game_active():
                    self.log('БОЙ ОСТАНОВЛЕН: окно игры потеряло фокус.')
                    return None
                # List-mode fight only. Continuous mode must never enter this
                # OCR/HP watchdog; transfer control to its independent loop.
                if cfg.get('attack_all_targets', False):
                    self.log('БОЙ / переход на непрерывную атаку: завершаю старый бой со сверкой имени.')
                    return None
                # Restore the active mode immediately when the user switches
                # the checkbox, including during an ongoing fight.
                # The pre-ALL whitelist identity guard remains the default.
                if cfg.get('attack_all_targets', False) and not all_tab_fight:
                    all_tab_fight = True
                    guard = None
                    hud_grace = max(1.8, cfg.get('combat_hud_loss_confirm_sec', 1.15))
                    last_identity_seen_at = time.monotonic()
                    self.log('БОЙ / РЕЖИМ СМЕНЁН: все цели Tab; контроль имени отключён.')
                elif all_tab_fight and not cfg.get('attack_all_targets', False):
                    if not find_target(target, cfg.get('targets', [])):
                        self.log('БОЙ / РЕЖИМ СМЕНЁН: цель не из списка; отпускаю макрос.')
                        return None
                    all_tab_fight = False
                    guard = CombatIdentityGuard(target, cfg.get('targets', []))
                    hud_grace = max(.75, cfg.get('combat_hud_loss_confirm_sec', 1.15))
                    last_identity_seen_at = time.monotonic()
                    self.log('БОЙ / РЕЖИМ СМЕНЁН: возвращена проверка имени по списку.')
                # Rotation occurs on a shared monotonic timer and does not
                # send TAB, change selected target, or restart the macro.
                self.maybe_rotate_camera(cfg, 'бой')
                now = time.monotonic()
                elapsed = now - start
                if elapsed > cfg['attack_timeout_sec']:
                    self.log('БОЙ / АВАРИЙНЫЙ ЛИМИТ ' + str(cfg['attack_timeout_sec']) +
                             ' c: жив ли моб, неизвестно. Останавливаю макрос; это НЕ смерть цели.')
                    return None
                raw = self.screenshot_region(sct, cfg['name_roi'])
                mark = self.visual_name_cache.fingerprint(raw)
                # Using the existing OCR cache, but never trusting it enough to
                # cancel an established fight, even for Керубим/Керубиэль.
                visual_combat,visual_combat_score=self.visual_name(raw,cfg)
                # Ignore very small lettering artifacts; retain OCR when the
                # independent visual sample cannot identify the complete word.
                name = visual_combat or (self.read_name_crop(raw) if mark is not None else '')
                if name:
                    last_name = name
                if guard is not None:
                    lost_reason = guard.observe(name, now)
                    if lost_reason:
                        self.log('БОЙ / СМЕНА ЦЕЛИ, STOP: ' + lost_reason +
                                 '; прежняя=' + repr(target) + '; OCR=' + repr(name) +
                                 '. Не разрешаю продолжать макрос по другой цели.')
                        return None
                hp_visible, red_pixels = self.target_hp_signal(sct)
                # The old `mark is not None` is NOT a HUD-presence test: it
                # can stay true for decorative glyphs, even when OCR returns
                # just «и» and HP=False for 25 seconds (real user log).
                # Only a plausible current name counts as textual evidence.
                # OCR gibberish of 4+ letters is NOT confirmation of the
                # original mob. A once-verified name remains the identity.
                # In broad Tab mode the *anchored selected-target HP HUD*
                # is the live proof of a target, even if OCR cannot read a
                # hostile player's/mob's name. A strong multi-frame name
                # change still triggers CombatIdentityGuard above.
                identity_confirmed = (hp_visible if all_tab_fight else
                    classify_combat_name(name, target, cfg.get('targets', []))[0] == 'same')
                meaningful_name = identity_confirmed
                header_visible = identity_confirmed
                if identity_confirmed:
                    last_identity_seen_at = now
                # Independent fail-safe against the real 02:42:05..02:42:25
                # hang: red pixels jump around with background/camera while
                # every OCR reading is garbage. A long unverified fight MUST
                # not monopolise TAB until the 25-second emergency timeout.
                no_identity_for = now-last_identity_seen_at
                if (elapsed >= 4.8 and no_identity_for >=
                        cfg.get('combat_identity_timeout_sec', 4.8)):
                    self.log('БОЙ / НЕТ ПОДТВЕРЖДЕНИЯ ЦЕЛИ: ' +
                             f'OCR не подтверждает {target!r} уже {no_identity_for:.2f}с; '
                             f'HP={hp_visible}, red={red_pixels}, peak={maximum_red}. '
                             'Прекращаю макрос и разблокирую TAB. Смерть не доказана.')
                    return None
                if hp_visible:
                    zero_hp_since = None
                else:
                    if zero_hp_since is None:
                        zero_hp_since = now
                # An empty HP bar AND no meaningful target name for sustained
                # time means we cannot justify keeping the weaving macro held.
                # This is classified as LOST, never a proven kill.
                if (not hp_visible and not meaningful_name and
                        zero_hp_since is not None and
                        elapsed >= 1.5 and now-zero_hp_since >= 1.8):
                    self.log('БОЙ / ЦЕЛЬ ПОТЕРЯНА: HP=False и OCR без имени '
                             f'{now-zero_hp_since:.2f}с ({name!r}). Возврат к Tab; смерть не подтверждена.')
                    return None
                if (not hp_visible and not confirmed_low_red and
                        zero_hp_since is not None and now-zero_hp_since >= empty_hp_grace):
                    self.log('БОЙ / HP НЕ ВИДНА: отсутствует ' +
                             f'{now-zero_hp_since:.2f}с без подтверждённого урона. '
                             'Отпускаю макрос, не считаю моба убитым.')
                    return None

                # Definitive safe exit: selected-target name/header AND HP are
                # BOTH continuously gone. A one-frame OCR failure is insufficient.
                if not header_visible and not hp_visible:
                    if hud_absent_since is None:
                        hud_absent_since = now
                    if now - hud_absent_since >= hud_grace:
                        self.log('БОЙ / HUD ИСЧЕЗ: нет имени/заголовка и полоски HP ' +
                                 f'{now-hud_absent_since:.2f} с. Возврат к Tab (смерть не доказана).')
                        return None
                else:
                    hud_absent_since = None

                if hp_visible and red_pixels >= 80:
                    saw_red_bar = True
                    red_absent_since = None
                    previous_peak = maximum_red
                    maximum_red = max(maximum_red, red_pixels)
                    # A full HP bar returning *after two low observations*
                    # usually means a freshly acquired mob, not healing.
                    # This is only a secondary signal; bar extraction is noisy.
                    if (previous_peak >= 1000 and red_pixels <= previous_peak*.16):
                        if hp_low_since is None:
                            hp_low_since = now
                        elif now-hp_low_since >= .16:
                            hp_was_low = True
                    elif (hp_was_low and previous_peak >= 1000 and
                          red_pixels >= previous_peak*.73):
                        hp_reset_samples += 1
                        if hp_reset_samples >= 2 and elapsed >= 1.5:
                            self.log('БОЙ / СМЕНА HP-ПОЛОСКИ, STOP: после низкого HP снова '
                                     f'{red_pixels}/{previous_peak} красных пикселей. '
                                     'Вероятно, макрос взял другого моба; прекращаю бой.')
                            return None
                    else:
                        hp_reset_samples = 0
                    # Require TWO distinct, low, *visible* HP measurements,
                    # not a single accidental masking of the red HUD.
                    if maximum_red >= 300 and red_pixels <= maximum_red * 0.32:
                        low_red_samples += 1
                        if low_red_samples >= 2:
                            confirmed_low_red = True
                    else:
                        low_red_samples = 0
                else:
                    if saw_red_bar and red_absent_since is None:
                        red_absent_since = now
                    low_red_samples = 0

                # v2.1: In the user's 01:12:39-01:12:57 log, the target
                # name had vanished and the HUD was stuck on ~350 red pixels
                # (~5% of the prior full bar) for 19 seconds.  Some red pixels
                # persist in the UI even AFTER the target is gone; HP=True is
                # not sufficient proof that combat should remain locked.
                # Only abort this stale low-bar condition when:
                #   1. Actual damage was confirmed by two low-HP samples;
                #   2. Remaining red is <=8% of the former full bar;
                #   3. OCR no longer contains a plausible target name;
                #   4. These observations CONTINUOUSLY persist for >=2.1s.
                # This must not trigger on short OCR/HP flicker or living
                # targets that still have recognizable names.
                stale_low = (confirmed_low_red and maximum_red >= 1500 and
                             hp_visible and red_pixels >= 80 and
                             red_pixels <= maximum_red * .08 and
                             not meaningful_name and elapsed >= min_hold)
                if stale_low:
                    if stale_low_since is None:
                        stale_low_since = now
                    elif now - stale_low_since >= 2.1:
                        self.log('БОЙ / ЗАСТЫВШАЯ ПОЛОСКА: прежняя HP упала до <=8%, '
                                 f'имя отсутствует {now-stale_low_since:.2f}с, '
                                 f'red={red_pixels}/{maximum_red}. '
                                 'Вероятно остаток HUD, снимаю макрос и возвращаю Tab; '
                                 'смерть не доказана.')
                        return None
                else:
                    stale_low_since = None

                # v2.2: the user's log contains bars stuck at 26%, 33%,
                # and 52% for 20+ seconds with NO recognisable locked name.
                # The v2.1 <=8% filter could never catch those cases.
                # Require 4+ seconds of BOTH missing identity and virtually
                # unchanged HP AFTER HP has visibly dropped; do not interrupt
                # a recognisable living mob merely because damage pauses.
                plateau_candidate = (not identity_confirmed and hp_visible and
                                     maximum_red >= 1500 and red_pixels >= 80 and
                                     red_pixels <= maximum_red*.82 and
                                     elapsed >= min_hold)
                tolerance = max(110, maximum_red*.04)
                if plateau_candidate:
                    if (plateau_red is None or
                            abs(red_pixels-plateau_red) > tolerance):
                        plateau_red = red_pixels
                        plateau_since = now
                        plateau_samples = 1
                    else:
                        plateau_samples += 1
                        if (plateau_samples >= 8 and plateau_since is not None
                                and now-plateau_since >= 4.0):
                            self.log('БОЙ / ЗАВИСШАЯ ЦЕЛЬ: имя исходного моба не подтверждено, '
                                     f'HP стоит {now-plateau_since:.2f}с '
                                     f'(red={red_pixels}, peak={maximum_red}, '
                                     f'последний OCR={name!r}). '
                                     'Отпускаю макрос, возвращаю TAB; смерть НЕ доказана.')
                            return None
                else:
                    plateau_red = None
                    plateau_since = None
                    plateau_samples = 0

                # A healthy, visually unchanged HP bar for many seconds
                # means START was not effective or the character cannot reach
                # this enemy. Release to recover Tab, but do not label as kill.
                if (hp_visible and maximum_red >= 1000 and
                        not confirmed_low_red and red_pixels >= maximum_red * .90):
                    if stable_full_since is None:
                        stable_full_since = now
                    elif now-stable_full_since >= full_hp_stall:
                        self.log('БОЙ / НЕТ РЕЗУЛЬТАТА: HP около полной ' +
                                 f'{now-stable_full_since:.2f}с, red={red_pixels}, '
                                 f'peak={maximum_red}. Возврат к Tab; смерть не подтверждена.')
                        return None
                else:
                    stable_full_since = None

                # Optional faster finish when the red HP fill has REALLY been
                # seen declining to near zero on two distinct captured frames,
                # and *then* stays absent. A v1.7-style 0.53s dropout after a
                # full HP bar can NEVER be interpreted as death again.
                if (confirmed_low_red and red_absent_since is not None and
                        elapsed >= 1.15 and now-red_absent_since >= hp_grace):
                    self._last_kill_hp_disappeared_at = red_absent_since
                    self.log('БОЙ / ВЕРОЯТНО УБИТ: HP ранее упала до <=32% пикселей '
                             'дважды, затем отсутствует ' +
                             f'{now-red_absent_since:.2f} с; время атаки {elapsed:.2f} с. Возврат к Tab.')
                    return None

                if now-last_diag >= 2.0:
                    self.log('БОЙ / УДЕРЖАНИЕ: ' + repr(target) + '; OCR=' + repr(name) +
                             f'; заголовок={header_visible}; HP={hp_visible}; red={red_pixels}; '
                             f'peak={maximum_red}; low_confirmed={confirmed_low_red}; '
                             f'время={elapsed:.1f}с; TAB ЗАПРЕЩЁН.')
                    last_diag = now
                if (now-last_warning >= cfg.get('combat_no_damage_sec',3.0) and
                        not confirmed_low_red and elapsed >= cfg.get('combat_no_damage_sec',3.0)):
                    self.log('БОЙ / ДИАГНОСТИКА: нет подтверждённого урона, '
                             'проверка идентичности цели остаётся включённой.')
                    last_warning = now
                # Keep the combat loop responsive; camera rotation is handled
                # independently by maybe_rotate_camera().
                if now-last_ping >= 2.5:
                    if not self.can_send():
                        return None
                    self.bridge.send('START')  # idempotent native holding-state heartbeat
                    last_ping = time.monotonic()
                if not self.wait(cfg['ocr_check_ms'] / 1000):
                    return None
        finally:
            self.release_macro()
            self._last_combat_end = time.monotonic()
            self.log('БОЙ / РАЗБЛОКИРОВКА TAB: макрос отпущен; поиск продолжается.')

    def debug_missed_threat(self, sct, mob):
        """Store a small upper-right HUD crop at most once per 15 seconds.

        v2.3 samples a few skipped target-of-target panes in unfamiliar
        locations. The screenshot helps calibrate colour and ROI; it is NEVER
        interpreted as proof of aggression and never authorises an attack.
        """
        now = time.monotonic()
        if getattr(self,'_missed_threat_count',0) >= 10:
            return
        if now-getattr(self,'_last_missed_threat_snap',0) < 15:
            return
        self._last_missed_threat_snap=now
        try:
            folder=Path(__file__).with_name('debug_aggro_miss')
            folder.mkdir(exist_ok=True)
            crop=self.screenshot_region(sct,[0.62,0.017,0.77,0.083])
            filename=time.strftime('%H%M%S')+'_'+str(getattr(self,'_missed_threat_count',0)+1)+'.png'
            if cv2.imwrite(str(folder/filename),crop):
                self._missed_threat_count=getattr(self,'_missed_threat_count',0)+1
                self.log('АГРО / КАДР ПРОПУСКА: '+repr(mob)+' -> debug_aggro_miss/'+filename+
                         ' (для проверки ROI/цветов; сам по себе НЕ доказывает агрессию)')
        except Exception as exc:
            self.log('АГРО / ошибка сохранения кадра пропуска: '+str(exc))

    def _confirm_threat_fast(self, sct, cfg, tab_time, name, initial):
        """Only spend extra time when Darkleam might actually be on the right.

        v1.4 waited >=360ms on EVERY non-listed mob, including obvious skips.
        A positive or ambiguous right HUD is sampled twice before combat;
        negative readings are skipped immediately without attacking strangers.
        """
        detected, player, confidence, method = initial
        late_force_ocr = False
        if not cfg.get('protect_player'):
            return False, player, confidence, method
        # No green right HUD => almost certainly not an aggressor.  Do not
        # pay the old fixed 360ms penalty for an ordinary skipped target.
        if not detected and confidence < .52:
            # The right-side target-of-target HUD can appear AFTER the left
            # target name. Previously a zero score immediately skipped real
            # aggressors. Probe a delayed frame on alternate skipped targets.
            probe_every = max(1,int(cfg.get('threat_delayed_probe_every',2)))
            if self.tab_number % probe_every:
                return False, player, confidence, method
            if not self.wait(cfg.get('threat_delayed_probe_ms',115)/1000.0):
                return False, player, confidence, 'stopped'
            detected, player, confidence, method = self.check_threat(sct,cfg,force_ocr=True)
            if not detected:
                return False,player,confidence,'delayed-'+method
            late_force_ocr = True
            self.log(f'АГРО / ОПОЗДАВШАЯ ПАНЕЛЬ: справа={player!r}, score={confidence:.2f}; '
                     'ещё нужны повторные подтверждения перед атакой')
        settle = cfg.get('threat_settle_ms', 200) / 1000.0
        remaining = settle - (time.monotonic()-tab_time)
        if remaining > 0 and not self.wait(remaining):
            return False, player, confidence, 'stopped'
        found2, player2, score2, method2 = self.check_threat(sct, cfg,force_ocr=late_force_ocr)
        if not found2 or not self.target_bar_present(sct):
            return False, player2, score2, 'confirm-failed:' + method2
        if not self.wait(.055):
            return False, player2, score2, 'stopped'
        found3, player3, score3, method3 = self.check_threat(sct, cfg,force_ocr=late_force_ocr)
        return bool(found3 and self.target_bar_present(sct)), player3, score3, 'confirmed:' + method3

    def run_continuous_attack(self, cfg):
        """Attack every automatically selected enemy; do not send TAB or read HUD.

        Cycle weaving macro: 12 seconds held, 0.5 seconds released. A
        SINGLE RELEASE keeps B (2 s) and optional LT+A (80 s) timers alive;
        finish_bridge resets everything on STOP/CAPTCHA. START heartbeats
        refresh the independent native 9-second watchdog.
        """
        if not self.can_send():
            time.sleep(.06)
            return
        hold_seconds = 12.0
        release_seconds = .50
        heartbeat_seconds = 2.5
        self.log('АТАКА ВСЕХ / ЦИКЛ: 12 с удержание -> 0,5 с отпускание -> повтор; '
                 'без Tab/OCR/PNG/HUD; камера работает по собственной галочке.')
        self.show('Атака всех: цикл 12 с / пауза 0,5 с; Tab и проверки целей отключены.')
        macro_held = False
        cycle_started = 0.0
        last_heartbeat = 0.0
        pause_started = 0.0
        try:
            while (self.active.is_set() and not self.closed.is_set() and
                   cfg.get('attack_all_targets', False)):
                if not self.game_active():
                    self.active.clear()
                    self.log('АТАКА ВСЕХ / СТОП: окно игры потеряло фокус.')
                    # Full stop: unlike a cyclic single RELEASE, this also
                    # disables native periodic B/LT+A as well.
                    self.finish_bridge()
                    break
                now = time.monotonic()
                if not macro_held:
                    if pause_started and now - pause_started < release_seconds:
                        # Camera has its own checkbox and stays independent of
                        # the 0.5 s attack gap, just like the old continuous mode.
                        self.maybe_rotate_camera(cfg, 'непрерывная атака')
                        if not self.wait(.05):
                            break
                        continue
                    # No START can race in *after* CAPTCHA's double RELEASE:
                    # _on_captcha clears active, and its finish_bridge holds
                    # this same lock.
                    with self.macro_lock:
                        if (not self.can_send() or self.captcha_locked.is_set() or
                                not cfg.get('attack_all_targets', False)):
                            break
                        self.start_macro()
                    cycle_started = time.monotonic()
                    last_heartbeat = cycle_started
                    macro_held = True
                    pause_started = 0.0
                elif now - cycle_started >= hold_seconds:
                    # Release weaving ONCE. Do not reset the native session,
                    # so F and the independent 6 timer keep working.
                    with self.macro_lock:
                        if not self.active.is_set() or self.captcha_locked.is_set():
                            break
                        self.release_macro()
                    macro_held = False
                    pause_started = time.monotonic()
                    self.log('АТАКА ВСЕХ / ПАУЗА: одиночный RELEASE на 0,5 с; '
                             'таймеры B и LT+A остаются включены.')
                elif now - last_heartbeat >= heartbeat_seconds and self.can_send():
                    # START during active native weaving is an idempotent
                    # watchdog heartbeat, not a macro restart.
                    with self.macro_lock:
                        if (self.active.is_set() and not self.captcha_locked.is_set() and
                                cfg.get('attack_all_targets', False) and self.can_send()):
                            self.bridge.send('START')
                    last_heartbeat = time.monotonic()
                self.maybe_rotate_camera(cfg, 'непрерывная атака')
                if not self.wait(.05):
                    break
        finally:
            # Live switch to whitelist: release before any TAB/OCR scan.
            # On CAPTCHA/STOP, the other handler already sends double RELEASE.
            self.release_macro()
            self._last_combat_end = time.monotonic()
            self.log('АТАКА ВСЕХ / ВЫХОД: макрос отпущен; стоп или переход к списку.')

    def run_loop(self):
        was_active = False
        ocr_initialized_for_session = False
        while not self.closed.is_set():
            if not self.active.is_set():
                was_active = False
                ocr_initialized_for_session = False
                time.sleep(.06)
                continue
            try:
                cfg = self.current_cfg
                if not was_active:
                    ocr_initialized_for_session = False
                    if not cfg.get('attack_all_targets', False):
                        self.initialize_ocr(cfg)
                        ocr_initialized_for_session = True
                    self.last_sweep = time.monotonic()
                    self.tabs_since_turn = 0
                    self._last_selected_signature = None
                    self._threat_debug_count = 0
                    self._missed_threat_count = 0
                    self._six_handshake_done = False
                    self._last_missed_threat_snap = 0
                    was_active = True
                    if not self.wait(.20):
                        continue
                if not self.game_active():
                    self.release_macro()
                    time.sleep(.09)
                    continue
                # Session-owned timers; no synthetic F configuration keys.
                if not self._six_handshake_done and self.can_send():
                    self._six_handshake_done = self.bridge.begin_session(cfg)
                    if not self._six_handshake_done:
                        time.sleep(.05)
                        continue
                if cfg.get('attack_all_targets', False):
                    self.run_continuous_attack(cfg)
                    continue
                # After switching from continuous mode to whitelist, OCR must
                # be initialised before the normal original Tab search resumes.
                if not ocr_initialized_for_session:
                    self.initialize_ocr(cfg)
                    ocr_initialized_for_session = True
                with mss.mss() as sct:
                    acquired = False
                    for _ in range(cfg['tabs_per_sector']):
                        if not self.can_send() or cfg.get('attack_all_targets', False):
                            break
                        t0 = time.monotonic()
                        self.bridge.send('TAB')
                        self.tab_number += 1
                        tab_id = self.tab_number
                        self.tabs_since_turn = getattr(self, 'tabs_since_turn', 0) + 1
                        self.last_tab_sent = time.monotonic()
                        bridge_ms = round((time.monotonic()-t0)*1000)
                        if getattr(self,'_last_kill_hp_disappeared_at',None) is not None:
                            self.log(f'TAB / ПОСЛЕ ИСЧЕЗНОВЕНИЯ HP: '
                                     f'{(time.monotonic()-self._last_kill_hp_disappeared_at)*1000:.0f}мс '
                                     '(включая ожидание HUD, отпускание макроса и передачу команды; '
                                     'не подтверждает физическое нажатие в игре)')
                            self._last_kill_hp_disappeared_at = None
                        if not self.wait(cfg.get('tab_settle_ms', 85)/1000):
                            break
                        if cfg.get('attack_all_targets', False):
                            break
                        ocr_start = time.monotonic()
                        raw = self.screenshot_region(sct, cfg['name_roi'])
                        sig = self.visual_name_cache.fingerprint(raw)
                        # The HUD can update after RS has already been transmitted.
                        # If it is pixel-identical to the previous selected name,
                        # allow the UI a short extra refresh before recognition.
                        if (sig is not None and self._last_selected_signature is not None and
                            sig.shape == self._last_selected_signature.shape and
                            np.count_nonzero(sig != self._last_selected_signature) <= 10):
                            if not self.wait(.065):
                                break
                            raw = self.screenshot_region(sct, cfg['name_roi'])
                            sig = self.visual_name_cache.fingerprint(raw)
                        self._last_selected_signature = sig.copy() if sig is not None else None
                        visual_read,visual_score=self.visual_name(raw,cfg)
                        visual_known = bool(visual_read)
                        # Hybrid: samples first, Tesseract as fallback. 'visual'
                        # is a strict test mode: no OCR-based attack decision.
                        mode=cfg.get('visual_mode','hybrid')
                        if visual_known:
                            name = visual_read
                        elif mode == 'visual':
                            name = ''
                        else:
                            name = self.read_name_crop(raw)
                        target = find_target(name, cfg['targets'])
                        # A decisive negative visual sample must never be
                        # converted to a fuzzy positive by OCR retry.
                        excluded_visual = visual_known and not target
                        if target and visual_known:
                            self.log(f'ОБРАЗЕЦ / НАЙДЕН: {target!r}; форма={visual_score:.2f}')
                        # v2.3: noisy location-specific target text. Only consider
                        # fuzzy recovery when TWO word components agree and we can
                        # independently confirm with a fresh screenshot below.
                        weak_candidate = None
                        if not target and not cfg.get('attack_all_targets', False) and not excluded_visual and mode != 'visual':
                            for t in cfg['targets']:
                                if target_phrase_evidence(name,t,strict=True) >= .78:
                                    weak_candidate=t
                                    break
                        if not target and not cfg.get('attack_all_targets', False) and not excluded_visual and mode != 'visual' and (not name or weak_candidate or self._looks_like_target(name, cfg['targets'])):
                            # A partial/late first HUD frame must not cause a
                            # known mob to be instantly skipped. Retry once.
                            if not self.wait(.065):
                                break
                            raw = self.screenshot_region(sct, cfg['name_roi'])
                            self._last_selected_signature = self.visual_name_cache.fingerprint(raw)
                            retry_name = self.read_name_crop(raw)
                            retry_target = find_target(retry_name, cfg['targets'])
                            if retry_target:
                                name, target = retry_name, retry_target
                            elif retry_name:
                                if (weak_candidate and
                                    target_phrase_evidence(retry_name,weak_candidate,strict=True) >= .78):
                                    target = weak_candidate
                                    self.log(f'OCR / ДВОЙНОЕ ПОДТВЕРЖДЕНИЕ: {weak_candidate!r}; '
                                             f'первое={name!r}; второе={retry_name!r}')
                                name = retry_name
                        # v2.6: Forest/spirit names often OCR as one glued
                        # word with exactly one missing character ('Духлеа').
                        # Earlier retries could hit the visual OCR cache again,
                        # producing TWO identical wrong values with no fresh OCR.
                        # This path always OCRs a NEW screenshot, bypasses the
                        # visual cache, and requires the same complete name.
                        if not target and not cfg.get('attack_all_targets', False) and not excluded_visual and mode != 'visual' and fuzzy_full_target(name, cfg['targets']):
                            first_name = name
                            if self.wait(.075):
                                verify_crop = self.screenshot_region(sct,cfg['name_roi'])
                                check1 = ocr_name(verify_crop)  # fresh, NO cache
                                candidate = verified_fuzzy_name(first_name,check1,'',cfg['targets'])
                                check2 = ''
                                if not candidate:
                                    check2 = ocr_name_alt(verify_crop)
                                    candidate = verified_fuzzy_name(first_name,check1,check2,cfg['targets'])
                                if candidate:
                                    self.log(f'OCR / ИСПРАВЛЕНО ИМЯ: {candidate!r}; '
                                             f'первое={first_name!r}; новый OCR={check1!r}; запасной={check2!r}')
                                    target = candidate
                                    name = check1 or first_name
                                    self._last_selected_signature = self.visual_name_cache.fingerprint(verify_crop)
                                else:
                                    self.log(f'OCR / ИМЯ НЕ ПОДТВЕРЖДЕНО: {first_name!r}; '
                                             f'новый OCR={check1!r}; запасной={check2!r}')
                        # If Tesseract mangles a short listed name, take a
                        # separate OCR pass with another mask and Russian-only
                        # model. Never accept edit-distance alone, or Керубим
                        # would be mistaken for excluded Керуб.
                        if not target and not cfg.get('attack_all_targets', False) and not excluded_visual and mode != 'visual' and self._looks_like_target(name, cfg['targets']):
                            short_names = [t for t in cfg['targets'] if len(normalize_name(t)) <= 6]
                            if short_names and not any(is_short_name_ambiguous(name, t) for t in short_names):
                                extra_roi = list(cfg['name_roi'])
                                extra_roi[2] = min(.65, max(extra_roi[2], extra_roi[0]+.19))
                                alt_crop = self.screenshot_region(sct, extra_roi)
                                alt_name = ocr_name_alt(alt_crop)
                                alt_match = accept_alternative_name(name, alt_name, cfg['targets'])
                                self.log(f'OCR / КОРОТКОЕ ИМЯ: основное={name!r}; запасное={alt_name!r}; '
                                         f'решение={alt_match or "пропуск"}')
                                if alt_match:
                                    name, target = alt_name, alt_match
                        ocr_ms = round((time.monotonic()-ocr_start)*1000)
                        if cfg.get('debug_each_tab', True):
                            self.log(f'TAB #{tab_id}: OCR={name!r}; найден={target or "нет"}; '
                                     f'мост={bridge_ms}мс; чтение={ocr_ms}мс; '
                                     f'после боя={round((t0-self._last_combat_end)*1000) if self._last_combat_end else "—"}мс')
                        if target:
                            # HIGHEST PRIORITY: never require the delayed/empty
                            # HP bar to accept a clearly recognised listed mob.
                            # No Darkleam/OCR calls after name match and START.
                            acquired = True
                            self.log('Найдена цель (из списка): ' + repr(name) +
                                     f' | bridge={bridge_ms}ms; OCR={ocr_ms}ms')
                            self._selected_at = t0
                            self.attack(sct, cfg, target, 'из списка')
                        else:
                            # v2.6: save actual LEFT name panel, missing from
                            # all previously supplied debug_aggro(_miss) zips.
                            # Limit count & frequency; no new OCR/keyboard calls.
                            self.debug_skipped_name(sct, name, cfg)
                            # Only unlisted mobs use target-of-target HUD check.
                            initial = self.check_threat(sct, cfg)
                            detected, player, confidence, method = initial
                            confirmed, player2, score2, method2 = self._confirm_threat_fast(
                                sct, cfg, t0, name, initial)
                            if confirmed and self.can_send():
                                acquired = True
                                threat_name = name or '(агрессор с неразборчивым именем)'
                                self.log('ЗАЩИТА: агрессор=' + repr(threat_name) +
                                         ' | справа=' + repr(player2) +
                                         f' | {method2}={score2:.2f}')
                                # Write screenshot AFTER starting combat, to
                                # keep PNG compression off the critical path.
                                self._selected_at = t0
                                self.attack(sct, cfg, threat_name,
                                            'нацелен на ' + cfg['player_name'])
                            else:
                                if cfg.get('protect_player') and str(method2).startswith('delayed-'):
                                    self.debug_missed_threat(sct,name)
                                if cfg.get('protect_player') and time.monotonic()-self.last_threat_debug > 2.0:
                                    self.last_threat_debug = time.monotonic()
                                    self.log(f'ЗАЩИТА / пропуск: моб={name!r}; справа={player2!r}; '
                                             f'ранняя={confidence:.2f}/{method}; проверка={score2:.2f}/{method2}')
                        if acquired:
                            if not cfg['repeat_search'] and not cfg.get('attack_all_targets', False):
                                self.active.clear()
                                self.finish_bridge()
                            break
                        elapsed_ms = round((time.monotonic()-t0)*1000)
                        if time.monotonic() - self.last_speed_debug >= 4.0:
                            self.last_speed_debug = time.monotonic()
                            # In ALL-Tab mode check_threat() was intentionally
                            # NOT called. Its local variables player/method/
                            # confidence therefore do not exist in this branch.
                            # The previous diagnostic f-string raised
                            # UnboundLocalError and stopped the scanner.
                            if cfg.get('attack_all_targets', False):
                                threat_diag = 'агро-HUD=не проверяется (все цели Tab)'
                            else:
                                threat_diag = f'справа={player!r}; {method}={confidence:.2f}'
                            self.log(f'СКОРОСТЬ: Tab-команда={bridge_ms} мс; OCR={ocr_ms} мс; '
                                     f'полный цикл={elapsed_ms} мс; кэш OCR={self.visual_name_cache.hits}/'
                                     f'{self.visual_name_cache.misses}; моб={name!r}; '
                                     + threat_diag)
                        if not cfg.get('attack_all_targets', False):
                            self.maybe_rotate_camera(cfg, 'поиск')
                        delay = cfg['tab_interval_ms']/1000-(time.monotonic()-t0)
                        if not self.wait(max(0, delay)):
                            break
                    if not acquired and self.can_send() and not cfg.get('attack_all_targets', False):
                        self.maybe_rotate_camera(cfg, 'поиск')
            except Exception as exc:
                self.active.clear()
                was_active = False
                self.finish_bridge()
                self.log('ОШИБКА: ' + str(exc))
                self.show('Ошибка: смотри журнал событий.')

    def on_death_watch_toggle(self):
        enabled=bool(self.death_enabled_var.get())
        if enabled:
            self.death_watch_enabled.set()
        else:
            self.death_watch_enabled.clear()
        self.config['death_watch_enabled']=enabled
        self.log('DEATH Watchdog: слежение ' + ('ВКЛ' if enabled else 'ВЫКЛ'))

    def test_death_sound(self):
        device=self.captcha_device_var.get().strip() or 'AG271QG4'
        self.show('Пробный ОТДЕЛЬНЫЙ сигнал смерти -> ' + device)
        if not self.death_sound.test(device,error_cb=lambda err:self.events.put(('audio_error',err))):
            self.show('Тест звука смерти уже запущен.')

    def simulate_death(self):
        """Safe full-alert test without game; next manual start clears internal latch."""
        self._on_death('ТЕСТ КНОПКОЙ (без игрового окна)')

    def death_watch_loop(self):
        """Independent low-frequency window check, never uses mob name or Tab."""
        while not self.closed.is_set():
            if (not self.active.is_set() or not self.death_watch_enabled.is_set() or
                    self.captcha_locked.is_set() or not self.game_active()):
                time.sleep(.20)
                continue
            try:
                with mss.mss() as sct:
                    frame=self._capture_game_frame(sct)
                if frame is not None and self.death_watch_enabled.is_set():
                    present,score=self.death_detector.check(frame)
                    if present and self.active.is_set():
                        # Confirm once on a fresh frame; no need to scan >1/sec.
                        time.sleep(.35)
                        if self.active.is_set() and not self.captcha_locked.is_set():
                            with mss.mss() as sct:
                                check_frame=self._capture_game_frame(sct)
                            confirmed,score2=self.death_detector.check(check_frame)
                            if confirmed:
                                self._on_death(f'устойчивое окно смерти ({score:.2f}/{score2:.2f})')
            except Exception as exc:
                self.log('DEATH Watchdog / ошибка проверки: '+str(exc))
            # Interruption-friendly ~5 sec interval, including switches in both modes.
            for _ in range(25):
                if (self.closed.is_set() or not self.active.is_set() or
                    self.captcha_locked.is_set()):
                    break
                time.sleep(.20)

    def _on_death(self,reason):
        """Stop both combat modes and all native timers; no automatic resurrection."""
        with self.macro_lock:
            if self.captcha_locked.is_set():
                return
            # Keep an internal latch until the next explicit user start (Ctrl+F8).
            self.captcha_locked.set()
            self._death_alerted=True
            self.start_generation+=1
            self.active.clear()
        self.log('!!! СМЕРТЬ ПЕРСОНАЖА !!! '+reason+
                 '. ОСТАНАВЛИВАЮ RB/RT, B И LT/A; следующий запуск — по Ctrl+F8 после проверки.')
        threading.Thread(target=self.finish_bridge,daemon=True).start()
        self.death_sound.start(self.config.get('captcha_audio_device','AG271QG4'),
                               error_cb=lambda error:self.events.put(('audio_error',error)))
        self.events.put(('death_alert',reason))
        self.show('СМЕРТЬ: автоматические действия остановлены, отдельная тревога на монитор!')

    def on_captcha_watch_toggle(self):
        if self.captcha_enabled_var.get():
            self.captcha_watch_enabled.set()
            self.log('CAPTCHA Watchdog: слежение ВКЛ.')
        else:
            self.captcha_watch_enabled.clear()
            self.log('CAPTCHA Watchdog: слежение ВЫКЛ.')

    def test_captcha_sound(self):
        name=self.captcha_device_var.get().strip() or 'AG271QG4'
        self.show('Пробный звуковой сигнал → ' + name + ' (не меняет устройство Windows).')
        if not self.captcha_sound.test(name, error_cb=lambda error:
                                       self.events.put(('audio_error',error))):
            self.show('Тест звука уже выполняется.')

    def list_audio_outputs(self):
        try:
            outputs=self.captcha_sound.outputs()
            lines=['%d: %s [%s]' % (idx,name,api) for idx,name,api in outputs]
            self.log('АУДИОУСТРОЙСТВА:\n'+'\n'.join(lines))
            messagebox.showinfo('Звуковые выходы Windows',
                                '\n'.join(lines)[:3500] or 'Не найдено',
                                parent=self.root)
        except Exception as exc:
            messagebox.showerror('Звук',str(exc),parent=self.root)

    def silence_captcha_sound(self):
        self.captcha_sound.stop()
        self.death_sound.stop()
        self.show('Звуковые тревоги выключены (Ctrl+F10). Макросы остановлены; после проверки запуск Ctrl+F8.')

    def simulate_captcha(self):
        """Test release/alarm/lockout without a real CAPTCHA or game."""
        self._on_captcha('Тест кнопкой',None)

    def capture_captcha_reference(self):
        """Manual screenshot of the CURRENT game client window, even if scanner is stopped.

        The user can press the UI button when CAPTCHA is visible. This captures
        unaltered evidence for later detector calibration; it does NOT read
        or enter the CAPTCHA response. Keep the screenshot private.
        """
        try:
            with mss.mss() as sct:
                frame=self._capture_game_frame(sct)
            if frame is None:
                self.show('Снимок: игровое окно ещё не обнаружено. Выбери окно игры в сканере.')
                return
            folder=Path(__file__).with_name('captcha_events')
            folder.mkdir(exist_ok=True)
            path=folder/('manual_captcha_'+time.strftime('%Y%m%d_%H%M%S')+'.png')
            if not cv2.imwrite(str(path),frame):
                raise RuntimeError('cv2.imwrite вернул False')
            self.log('Ручной снимок игрового окна: '+str(path))
            self.show('Снимок сохранён: '+str(path))
        except Exception as exc:
            self.log('Ошибка ручного снимка: '+str(exc))

    def _capture_game_frame(self, sct):
        """Read game client's actual screen rectangle, not Tk's screen centre."""
        if not self.game_hwnd:
            return None
        rect=wintypes.RECT()
        if not u32.GetClientRect(self.game_hwnd,ctypes.byref(rect)):
            return None
        pt=wintypes.POINT(0,0)
        if not u32.ClientToScreen(self.game_hwnd,ctypes.byref(pt)):
            return None
        w,h=rect.right-rect.left,rect.bottom-rect.top
        if w<500 or h<300:
            return None
        capture=sct.grab({'left':int(pt.x),'top':int(pt.y),'width':int(w),'height':int(h)})
        return np.asarray(capture)[:,:,:3].copy()

    def captcha_watch_loop(self):
        """Independent watchdog; runs while the scanner is actively farming."""
        while not self.closed.is_set():
            if (not self.active.is_set() or not self.captcha_watch_enabled.is_set()
                or self.captcha_locked.is_set() or not self.game_active()):
                self._captcha_hits=0
                time.sleep(.15)
                continue
            try:
                with mss.mss() as sct:
                    frame=self._capture_game_frame(sct)
                if frame is None:
                    self._captcha_hits=0
                    time.sleep(.15)
                    continue
                present,score=self.captcha_detector.check(frame)
                self._captcha_hits=self._captcha_hits+1 if present else 0
                # Two consecutive sightings avoid one-frame effects and flashes.
                if self._captcha_hits>=2 and self.active.is_set():
                    self._on_captcha(f'совпали постоянные заголовок и инструкция, оценка={score:.2f}',frame)
            except Exception as exc:
                self._captcha_hits=0
                self.log('WATCHDOG / ошибка кадра: '+str(exc))
                time.sleep(1.2)
            time.sleep(1.0)

    def _on_captcha(self,reason,frame):
        if self.captcha_locked.is_set():
            return
        # First clear the active flag; the native guard releases all reports.
        # finish_bridge also cancels the loot/buff timers and any queued pulse.
        self.captcha_locked.set()
        self.start_generation += 1
        self.active.clear()
        self._captcha_hits=0
        self.log('!!! ВОЗМОЖНА CAPTCHA !!! '+reason+
                 '. АВТОПОИСК ВЫКЛЮЧЕН. Сбрасываю все кнопки Xbox.')
        if frame is not None:
            try:
                folder=Path(__file__).with_name('captcha_events')
                folder.mkdir(exist_ok=True)
                path=folder/('captcha_'+time.strftime('%Y%m%d_%H%M%S')+'.png')
                cv2.imwrite(str(path),frame)
                self.log('Скриншот подозрительного окна сохранён: '+str(path))
            except Exception as exc:
                self.log('Не удалось сохранить скриншот: '+str(exc))
        threading.Thread(target=self.finish_bridge,daemon=True).start()
        self.captcha_sound.start(self.config.get('captcha_audio_device','AG271QG4'),
                                 error_cb=lambda error:self.events.put(('audio_error',error)))
        self.events.put(('captcha_alert',reason))
        self.show('CAPTCHA: автодействия остановлены, звуковая тревога на монитор!')

    def close(self):
        self.captcha_sound.stop()
        self.death_sound.stop()
        self.system_hotkeys.stop()
        self.closed.set()
        self.active.clear()
        self.finish_bridge()
        try:
            self.bridge.close()
        finally:
            self.root.destroy()


def main():
    root = tk.Tk()
    ttk.Style().theme_use('clam')
    ScannerApp(root)
    root.mainloop()

if __name__ == '__main__':
    main()
