"""Serialized native Xbox weaving and additive loot/buff timers.

No keyboard/mouse injection or Lua receiver. Every report is constructed from
the complete desired state; B and LT+A do NOT release held RB+RT.
"""
import os,threading,time
from dataclasses import dataclass

RB=0x0200
RS=0x0080
A=0x1000
B=0x2000

SIX_PERIOD_SECONDS=80.
SIX_WINDOW_SECONDS=4.
SIX_TAP_EVERY_SECONDS=.150
SIX_A_HOLD_SECONDS=.045

@dataclass(frozen=True)
class Report:
 buttons:int=0
 lt:float=0.
 rt:float=0.
 yaw:float=0.

class CombatState:
 """Pure time policy. The caller serializes state updates and delivery."""
 def __init__(self):
  self.session=False;self.attack=False;self.deadline=0.;self.epoch=0
  self.six_enabled=False;self.next_six=0.;self.buff_start=0.;self.buff_end=0.
  self.next_loot=0.;self.loot_until=0.;self.tab_until=0.;self.yaw=0.;self.yaw_until=0.
 def clear(self):
  self.session=False;self.attack=False;self.deadline=0.;self.epoch+=1
  self.next_six=0.;self.buff_start=0.;self.buff_end=0.;self.next_loot=0.
  self.loot_until=0.;self.tab_until=0.;self.yaw=0.;self.yaw_until=0.
 def begin(self,now,six=False):
  self.clear();self.session=True;self.six_enabled=bool(six)
  self.deadline=now+9.;self.next_loot=now+2.;self.next_six=now+SIX_PERIOD_SECONDS
 def touch(self,now):self.deadline=now+9.
 def report(self,now,allowed,running):
  if not allowed:
   self.clear();return Report()
  if self.session and (not running or now>=self.deadline):
   self.clear();return Report()
  if self.session:
   if now>=self.next_loot and now>=self.tab_until:
    self.loot_until=now+.085;self.next_loot=now+2.
   if self.six_enabled and now>=self.next_six:
    self.buff_start=now+.04;self.buff_end=now+SIX_WINDOW_SECONDS;self.next_six=now+SIX_PERIOD_SECONDS
  buttons=RB if self.session and self.attack else 0
  rt=1. if buttons&RB else 0.
  if now<self.tab_until:return Report(RS)
  if now<self.loot_until:buttons|=B
  lt=0.
  # LT leads the first A and remains held for a short A-up tail. No report
  # can contain a fresh A down without its skill-layer trigger.
  if self.buff_end and now<self.buff_end+.04:
   lt=1.
   if self.buff_start<=now<self.buff_end and (now-self.buff_start)%SIX_TAP_EVERY_SECONDS<SIX_A_HOLD_SECONDS:buttons|=A
  return Report(buttons,lt,rt,self.yaw if now<self.yaw_until else 0.)

class XboxCombatBridge:
 def __init__(self,allowed,running,logger=lambda _:None,factory=None,clock=time.monotonic,background=True):
  self.allowed=allowed;self.running=running;self.log=logger;self.factory=factory;self.clock=clock;self.background=background
  self.lock=threading.RLock();self.state=CombatState();self.pad=None;self.ready=False;self.last=Report()
  self.closed=threading.Event();self.worker=None;self.error=None;self.cfg={}
 @property
 def attacking(self):
  with self.lock:return self.state.session and self.state.attack and self.clock()<self.state.deadline
 def _permitted(self):
  try:return not self.closed.is_set() and bool(self.allowed())
  except Exception:return False
 def prepare(self):
  with self.lock:
   if self.closed.is_set():raise RuntimeError('Xbox transport is closed')
   if self.error:raise RuntimeError('Xbox: '+self.error)
   if self.pad is None:
    factory=self.factory
    if factory is None:
     if os.name!='nt':raise RuntimeError('Виртуальный Xbox требует Windows')
     try:
      import vgamepad
      factory=vgamepad.VX360Gamepad
     except ImportError as exc:raise RuntimeError('Выполните INSTALL_ONCE.bat: нужен vgamepad и ViGEmBus') from exc
    self.pad=factory();self.pad.reset();self.pad.update();self.ready=True
    self.log('XBOX: виртуальный контроллер готов; G HUB, Lua и G8/G9 не нужны')
   if self.background and self.worker is None:
    self.worker=threading.Thread(target=self._run,daemon=True);self.worker.start()
 def _deliver(self,report):
  if report==self.last:return
  # Always release A before dropping LT; the report itself also enforces the
  # A=>LT invariant. In normal operation all desired holds are additive.
  old=self.last
  for bit in (RB,RS,A,B):
   if old.buttons&bit and not report.buttons&bit:self.pad.release_button(button=bit)
  self.pad.left_trigger_float(value_float=report.lt)
  self.pad.right_trigger_float(value_float=report.rt)
  self.pad.right_joystick_float(x_value_float=report.yaw,y_value_float=0.)
  for bit in (RB,RS,A,B):
   if report.buttons&bit and not old.buttons&bit:self.pad.press_button(button=bit)
  self.pad.update();self.last=report
 def tick(self):
  with self.lock:
   if self.pad is None:return Report()
   report=self.state.report(self.clock(),self._permitted(),bool(self.running()))
   self._deliver(report);return report
 def _run(self):
  while not self.closed.wait(.01):
   try:self.tick()
   except Exception as exc:
    with self.lock:
     self.error=str(exc);self.state.clear()
     try:self.pad.reset();self.pad.update();self.last=Report()
     except Exception:pass
    self.log('XBOX ERROR: '+str(exc)+'; ввод сброшен');return
 def begin_session(self,cfg):
  self.prepare()
  with self.lock:
   if not self._permitted() or not self.running():return False
   self.cfg=dict(cfg);self.state.begin(self.clock(),cfg.get('six_spam_enabled',False));self.tick()
   self.log('XBOX SESSION: B каждые 2 с; LT+A '+('серия 4 с каждые 80 с' if self.state.six_enabled else 'выключено')+'; RB+RT удерживаются вместе с ними')
   return True
 def _ensure_session(self):
  if not self.state.session:self.state.begin(self.clock(),self.cfg.get('six_spam_enabled',False))
  self.state.touch(self.clock())
 def _wait_pulse(self,until,epoch):
  if not self.background:return True
  while self.clock()<until:
   with self.lock:
    if self.state.epoch!=epoch or not self._permitted():return False
   if self.closed.wait(min(.01,max(0,until-self.clock()))):return False
  self.tick();return True
 def send(self,name):return self._send(name)
 def test_button(self,name,authorize=lambda:True):
  if name not in ('TAB','F'):raise ValueError(name)
  return self._send(name,manual=True,authorize=authorize)
 def _send(self,name,manual=False,authorize=lambda:True):
  if name not in ('START','RELEASE','TAB','F'):raise ValueError(name)
  if name=='RELEASE':
   with self.lock:
    self.state.attack=False
    if self.state.session:self.state.touch(self.clock())
    if self.pad is not None:self.tick()
   return True
  self.prepare()
  with self.lock:
   if not self._permitted() or not authorize():return False
   if manual:
    if self.running():return False
    self.state.clear()
   elif not self.running():return False
   now=self.clock()
   if name=='START':
    if not self.running():return False
    self._ensure_session();self.state.attack=True
   else:
    if self.running():self._ensure_session()
    if name=='TAB':
     self.state.attack=False
     # Ensure a second command has a new RS edge even if sent very quickly.
     self.state.tab_until=0.;self.tick();self.state.tab_until=now+.075
     if self.state.buff_end>now:self.state.buff_start=now+.115
    else:self.state.loot_until=now+.085
   epoch=self.state.epoch;self.tick()
   until=self.state.tab_until if name=='TAB' else self.state.loot_until if name=='F' else now
  return self._wait_pulse(until,epoch)
 def turn(self,strength,seconds):
  self.prepare()
  with self.lock:
   if not self._permitted() or not self.running():return False
   self._ensure_session();self.state.yaw=max(-.7,min(.7,strength))
   self.state.yaw_until=self.clock()+max(.02,min(.8,seconds));until=self.state.yaw_until;epoch=self.state.epoch;self.tick()
  return self._wait_pulse(until,epoch)
 def stop_camera(self):
  with self.lock:
   self.state.yaw_until=0.;self.state.yaw=0.
   if self.pad is not None:self.tick()
 def finish(self):
  with self.lock:
   self.state.clear()
   if self.pad is not None:
    self.pad.reset();self.pad.update();self.last=Report()
 def close(self):
  self.closed.set()
  try:self.finish()
  finally:
   if self.worker is not None and self.worker is not threading.current_thread():self.worker.join(timeout=1.)
