from pathlib import Path
import json,os,subprocess,sys,venv
from runtime_env import runtime_dir,runtime_python,find_runtime,requirement_hash
ROOT=Path(__file__).resolve().parent

def main():
 if not (3,10)<=sys.version_info[:2]<(3,14) or sys.maxsize<=2**32:raise RuntimeError('Нужен Python 3.10–3.13 x64; предпочтительно 3.12')
 python=find_runtime(ROOT)
 if python is None:
  env=runtime_dir(ROOT);env.parent.mkdir(parents=True,exist_ok=True)
  if not runtime_python(env).is_file():venv.EnvBuilder(with_pip=True).create(env)
  python=runtime_python(env);install_env=os.environ.copy();install_env['VGAMEPAD_SKIP_VIGEMBUS_INSTALL']='true'
  subprocess.run([str(python),'-m','pip','install','--no-cache-dir','--disable-pip-version-check','-r',str(ROOT/'requirements.txt')],check=True,env=install_env)
  subprocess.run([str(python),'-c','import cv2,numpy,mss,pytesseract,PIL,sounddevice,vgamepad'],check=True)
  (env/'ready.json').write_text(json.dumps({'requirements_sha256':requirement_hash(ROOT),'python_version':list(sys.version_info[:2])})+'\n')
 else:print('Использую общее окружение:',python,flush=True)
 print('Готово. START.bat запускает сканер. Нужен тот же ViGEmBus, что у сборщика ресурсов. Новая .venv в папке версии не создаётся.')
if __name__=='__main__':main()
