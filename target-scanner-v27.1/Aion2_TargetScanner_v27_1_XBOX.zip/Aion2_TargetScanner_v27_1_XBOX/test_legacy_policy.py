# -*- coding: utf-8 -*-
"""Actual-source offline regression tests; NO Windows, game, or G HUB connected."""
import ast, cv2, json, numpy as np, re
from pathlib import Path
from difflib import SequenceMatcher

here=Path(__file__).parent
code=(here/'target_scanner.py').read_text('utf-8')
tree=ast.parse(code)
scanner=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='ScannerApp')
methods={n.name:n for n in scanner.body if isinstance(n,ast.FunctionDef)}
funcnames={'normalize_name','name_matches','find_target','cyrillic_ocr_tokens','word_score','target_phrase_evidence','classify_combat_name'}
functions=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in funcnames]
functions += [n for n in tree.body if isinstance(n,ast.ClassDef) and n.name=='CombatIdentityGuard']
class Clock:
    def __init__(self):self.t=100.
    def monotonic(self):return self.t
    def step(self,secs):self.t+=secs
clock=Clock()
scope={'cv2':cv2,'np':np,'re':re,'SequenceMatcher':SequenceMatcher,'time':clock}
load=functions+[methods['measure_target_hp'], methods['target_hp_signal'],methods['attack'],methods['maybe_rotate_camera']]
exec(compile(ast.fix_missing_locations(ast.Module(body=load,type_ignores=[])),'v24','exec'),scope)

# HUD crop geometry is normalized to the game screen; supplied screenshots
# debug_aggro/*.png were captured from screen x .30..77 and y .017..085.
def crop_snap(im,x1,y1,x2,y2):
    hh,ww=im.shape[:2]
    return im[max(0,round((y1-.017)/(.085-.017)*hh)):min(hh,round((y2-.017)/(.085-.017)*hh)),
              max(0,round((x1-.30)/(.77-.30)*ww)):min(ww,round((x2-.30)/(.77-.30)*ww))]

def band_test(image):
    bar=crop_snap(image,.3975,.063,.593,.073)
    frame=crop_snap(image,.391,.063,.3975,.073)
    return scope['measure_target_hp'](bar,frame)

# Re-use actual attached user screenshots if optional (they aren't included
# in the distributed zip). If absent, synthetic realistic bands are tested.
# We assert on a drawn HUD frame + bar and world background.
def makebar(redwidth=350, frame=True, worldred=False):
    im=np.zeros((14,500,4),dtype='uint8')
    if worldred:
        im[:]=(8,9,220,255) # red rocks can yield a *huge* naive red count
    if frame:
        im[:]=(10,10,15,255)
    if redwidth:
        im[:,4:4+redwidth]=(16,4,251,255)
    border=np.zeros((14,17,4),dtype='uint8')
    border[:]=(25,25,25,255) if frame else (90,124,186,255)
    return im,border

bar,frame=makebar(350)
assert scope['measure_target_hp'](bar,frame)[0]
bar,frame=makebar(0)
assert scope['measure_target_hp'](bar,frame)==(False,0)
bar,frame=makebar(0,frame=False,worldred=True)
assert scope['measure_target_hp'](bar,frame)==(False,0)
print('PASS: HP color gate ignores red scenery without actual HUD frame')

class Flag:
    def __init__(self,x):self.x=x
    def is_set(self):return self.x
class Sim:
    def __init__(self,rows,max_time):
        self.rows=rows;self.max_time=max_time
        self.active=Flag(True);self.closed=Flag(False);self.visual_name_cache=self
        self._selected_at=100.;self.events=[];self.sent=[];self.bridge=self;self.last_sweep=100.
        self.rotations=[]
    def log(self,msg):self.events.append((clock.monotonic()-100,msg))
    def show(self,msg):pass
    def can_send(self):return True
    def game_active(self):return True
    def start_macro(self):self.sent.append((clock.monotonic()-100,'START'))
    def release_macro(self):self.sent.append((clock.monotonic()-100,'RELEASE'))
    def send(self,command):self.sent.append((clock.monotonic()-100,command))
    def rotate_search(self,cfg):self.rotations.append((clock.monotonic()-100,cfg['turn_ms']))
    def maybe_rotate_camera(self,cfg,state='бой'):return scope['maybe_rotate_camera'](self,cfg,state)
    def screenshot_region(self,*args):
        age=clock.monotonic()-100
        self.current=max((r for r in self.rows if r[0]<=age),key=lambda r:r[0],default=self.rows[0])
        return self.current
    def fingerprint(self,data):return object() if data[2] else None
    def read_name_crop(self,data):return data[1]
    def visual_name(self,raw,cfg):return '', 0.0
    def target_hp_signal(self,sct):return self.current[3],self.current[4]
    def wait(self,seconds):
        clock.step(seconds)
        if clock.monotonic()-100>self.max_time:
            self.active.x=False
            return False
        return True
    def debug_threat_snapshot(self,*args):pass

def run(rows,max_time=30,target='Детектор драканов'):
    clock.t=100
    sim=Sim(rows,max_time)
    config={'name_roi':[.4,.03,.58,.06],'targets':[target],
           'ocr_check_ms':120,'attack_timeout_sec':25,'min_combat_sec':3,
           'combat_hp_loss_confirm_sec':.36,'combat_hud_loss_confirm_sec':1.15,
           'combat_empty_hp_stall_sec':2.2,'combat_identity_timeout_sec':4.8,
           'combat_full_hp_stall_sec':8., 'combat_no_damage_sec':3.,
           'search_turn_sec':2.0,'combat_spin':True,'turn_ms':1700,
           'never_move_camera':False}
    scope['attack'](sim,None,config,target,'из списка')
    return sim

def has(sim,tag):return any(tag in s for t,s in sim.events)
def release_at(sim):return next(t for t,m in sim.sent if m=='RELEASE')

# Exact user's 02:42:04..02:42:25 case: name vanished, red fluctuates
# drastically due to camera/world, and old v2.3 held for 20-25 seconds.
hang=run([(0,'Детектор драканов',True,True,7600),
          (1.0,'',False,True,567), (2.5,'а ~ at A Та МУ.',False,True,2409),
          (3.3,'',False,True,767),(4.2,'',False,True,1169),
          (5.2,'',False,True,335),(6.0,'',False,True,3107)],max_time=26)
assert has(hang,'НЕТ ПОДТВЕРЖДЕНИЯ ЦЕЛИ') and 4.7 < release_at(hang) < 6.4, hang.events[-8:]
print('PASS: real 02:42:04 hang recovered near 5s, despite oscillating red colour')

# Old stalled 26% / 52% variants likewise cannot hold 25s.
for pct in (1950,4350):
    stall=run([(0,'Детектор драканов',True,True,7600),
               (1.3,'и.',True,True,pct)],max_time=27)
    assert release_at(stall)<7, stall.events[-8:]
print('PASS: old plateau / no-name cases bounded below 7s')

# Recognized target with paused damage must not be abandoned by identity guard.
alive=run([(0,'Детектор драканов',True,True,7600),
           (.8,'Детектор драканов',True,True,4200)],max_time=12)
assert not has(alive,'НЕТ ПОДТВЕРЖДЕНИЯ ЦЕЛИ')
assert release_at(alive)>=12
print('PASS: readable living mob retained even with stalled HP')

# Confirmed low bar + absence releases in <=~.5s rather than 1.28s.
kill=run([(0,'Детектор драканов',True,True,7500),
          (.6,'Детектор драканов',True,True,600),
          (1.0,'Детектор драканов',True,True,450),
          (2.3,'',False,False,0)],max_time=8)
assert has(kill,'ВЕРОЯТНО УБИТ') and 2.60<=release_at(kill)<=2.88,kill.events[-10:]
print('PASS: low HP + disappearance quickly returns Tab after short confirmation')

# Single foreign OCR blip isn't reliable; repeated foreign mob must stop.
f=run([(0,'Детектор драканов',True,True,7600),(.9,'Поблекший папис',True,True,7000)],max_time=6)
assert has(f,'СМЕНА ЦЕЛИ, STOP') and release_at(f)<2, f.events
print('PASS: foreign mob still blocks continuous attack')

# Logged timer is still active during combat independently from Tab.
c=run([(0,'Детектор драканов',True,True,7400)],max_time=10)
assert len(c.rotations)>=3 and all(x[1]==1700 for x in c.rotations)
print('PASS: camera remains on its 2-second time-based rotation')

cfg=json.loads((here/'settings.json').read_text('utf-8'))
assert cfg['targets'] and cfg['combat_hp_loss_confirm_sec']==.36 and cfg['combat_identity_timeout_sec']==4.8
assert 'xbox_combat.py' in [p.name for p in here.iterdir()]
print('PASS: original combat-policy regressions; native transport packaged')
