@echo off
call "%~dp0RUN_PYTHON.bat" target_scanner.py
if errorlevel 1 pause
