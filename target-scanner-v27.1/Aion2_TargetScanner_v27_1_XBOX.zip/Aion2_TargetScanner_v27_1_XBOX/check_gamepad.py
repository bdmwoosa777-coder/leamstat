"""Connection check only: no buttons, triggers, movement, game capture or OCR."""
import vgamepad
pad=vgamepad.VX360Gamepad()
pad.reset();pad.update()
print('Xbox готов. Кнопки и стики не нажимались. Закройте это окно перед START.bat.')
