@echo off
call "%~dp0RUN_PYTHON.bat" check_gamepad.py
pause
