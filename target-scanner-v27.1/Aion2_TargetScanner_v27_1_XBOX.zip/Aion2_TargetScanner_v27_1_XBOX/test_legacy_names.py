# Offline AST extraction of real matching functions, does not launch Windows UI.
import ast,re
from pathlib import Path
from difflib import SequenceMatcher
source=Path(__file__).with_name('target_scanner.py').read_text('utf-8')
mod=ast.parse(source)
used={'normalize_name','name_matches','find_target','cyrillic_ocr_tokens',
      'word_score','_mixed_ocr_words','_fuzzy_full_name_score','fuzzy_full_target',
      'verified_fuzzy_name'}
selected=[n for n in mod.body if isinstance(n,ast.FunctionDef) and n.name in used]
assert {n.name for n in selected}==used
scope={'re':re,'SequenceMatcher':SequenceMatcher}
exec(compile(ast.fix_missing_locations(ast.Module(body=selected,type_ignores=[])), '<actual-v25>', 'exec'),scope)
fn=scope['fuzzy_full_target']; vf=scope['verified_fuzzy_name']; tgt=['Дух леса','Поблекший дух камня']
assert fn('Духлеа',tgt)=='Дух леса'
assert fn('РО Дух леса ae',tgt)=='Дух леса'
assert fn('Дух леа',tgt)=='Дух леса'
assert vf('Духлеа','Духлеа','',tgt)=='Дух леса'
assert vf('Духлеа','Дух шквала','Дух бриза',tgt) is None
assert vf('Духлеа','','',tgt) is None
print('PASS forest: high confidence fused/dropped-letter target recovers only after fresh OCR')
for bad in ['Дух шквала', 'Дух бриза', 'дух брызг','Поблекший дух камня',
            'Дух камня','Дух лесной','Дух лета', 'р Чешуйница','Пращник дудуков',
            'Рабочий дудуков','pyxneca', 'pyxneca .', 'Дух']:
    result=fn(bad,tgt)
    assert result!='Дух леса', (bad,result)
print('PASS forest: 13 negative mob names and damaged OCR rejected')
# Even a full-looking guess is NOT accepted without a second fresh OCR reading.
for p in ['Духлеа','Дух леа','РО Дух леса ae']:
    assert vf(p,'Дух бриза','Дух шквала',tgt) is None, p
print('PASS forest: repeated alien OCR blocks new START')
# Same-family user examples from other locations must not be collapsed.
for t in [ ['Керуб','Керубим','Керубиэль'], ['Пращник дудуков','Рабочий дудуков'],
           ['Каилин','Малый каилин']]:
    for seen in t:
        result = fn(seen,t)
        if result:
            assert result==seen, (seen,t,result)
print('PASS multi-target: similarly named whitelist entries remain distinct')
