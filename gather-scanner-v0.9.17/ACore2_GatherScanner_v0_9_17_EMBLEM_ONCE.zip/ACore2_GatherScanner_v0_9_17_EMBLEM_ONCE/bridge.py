# -*- coding: utf-8 -*-
"""Windows lock-key -> dedicated G HUB Lua command transport.

No SendInput gameplay keys. The Python -> G HUB bridge is best-effort: there is
NO acknowledge from Lua. All stateful Lua operations have an independent watchdog.
"""
import os,time,threading

COMMANDS={
    'PING':0,'ALT_DOWN':1,'TAB':2,'ALT_UP':3,
    'F_ON':4,'F_OFF':5,'V':6,'STOP':7,
    'ATTACK_PAIR':8,'END_AIR':9,'TAP_F':10,
    'W_STEP':11, 'LEFT_STEP':12, 'RIGHT_STEP':13,
    'JUMP':14,'MAP':15,
}

def frame_codes(command):
    if command not in COMMANDS:raise ValueError(command)
    v=COMMANDS[command];hi=v//4;lo=v%4
    # SOF, 2-bit high, 2-bit low, 2-bit parity/checksum
    return [3,hi,lo,(hi+2*lo+1)%4]

class GHubBridge:
    def __init__(self,dry_run=False,logger=None):
        self.dry_run=dry_run or os.name!='nt'
        self.log=logger or (lambda _:None)
        self.lock=threading.RLock()
        self.sent=[]
        self._saved=None;self._dry_alt=False;self.last_cursor_target=None;self.last_cursor_actual=None
        if not self.dry_run:
            import ctypes
            from ctypes import wintypes
            self.win=ctypes.windll.user32
            self.win.GetKeyState.argtypes=[ctypes.c_int]
            self.win.GetKeyState.restype=ctypes.c_short
            self.win.GetAsyncKeyState.argtypes=[ctypes.c_int]
            self.win.GetAsyncKeyState.restype=ctypes.c_short
            self.win.keybd_event.argtypes=[wintypes.BYTE,wintypes.BYTE,wintypes.DWORD,ctypes.c_size_t]
            self.win.keybd_event.restype=None
            self.win.SetCursorPos.argtypes=[ctypes.c_int,ctypes.c_int]
            self.win.SetCursorPos.restype=wintypes.BOOL
            self._point_type=wintypes.POINT;self._byref=ctypes.byref
            self.win.GetCursorPos.argtypes=[ctypes.POINTER(wintypes.POINT)]
            self.win.GetCursorPos.restype=wintypes.BOOL
            self._saved={20:bool(self.win.GetKeyState(20)&1),144:bool(self.win.GetKeyState(144)&1),145:bool(self.win.GetKeyState(145)&1)}

    def _toggle(self,key,desired):
        # Scan codes and short down/up separation follow the working v26 bridge.
        scan={20:0x3A,144:0x45,145:0x46}[key]
        for _ in range(3):
            if bool(self.win.GetKeyState(key)&1)==bool(desired):return
            self.win.keybd_event(key,scan,0,0)
            time.sleep(.008)
            self.win.keybd_event(key,scan,2,0)
            time.sleep(.034)
        if bool(self.win.GetKeyState(key)&1)!=bool(desired):
            raise RuntimeError('Не удалось переключить lock-key '+hex(key))

    def send_guarded(self,command,authorize):
        return self.send(command,authorize=authorize)

    def resync_receiver(self,stop,focused):
        """Let Lua's 850 ms partial-frame timeout expire on a quiet wire.

        No gameplay command is repeated here. A caller may retry only a
        separately verified idempotent Alt state command, never F/V/Tab.
        """
        with self.lock:
            if stop.is_set() or not focused():return False
            if not self.dry_run:self._toggle(145,False)
            until=time.monotonic()+.95
            while time.monotonic()<until:
                if stop.is_set() or not focused():return False
                if stop.wait(min(.03,max(0,until-time.monotonic()))):return False
            return not stop.is_set() and focused()

    def send(self,command,authorize=None):
        data=frame_codes(command)
        with self.lock:
            started=time.monotonic()
            def permitted():
                try:return authorize is None or bool(authorize())
                except Exception as exc:
                    self.log('Команда отменена: ошибка проверки свежего кадра: '+str(exc));return False
            if not permitted():return False
            if self.dry_run:
                if command=='ALT_DOWN':self._dry_alt=True
                elif command in ('ALT_UP','STOP','END_AIR'):self._dry_alt=False
                self.sent.append((time.monotonic(),command,data))
                self.log('СИМУЛЯЦИЯ '+command)
                return True
            # G HUB samples lock state at ScrollLock positive edge. A pulse
            # must be long enough for POLL_MS=12ms. Each strobe carries two bits.
            cancelled=False;last_edge=None
            invalid=next(v for v in range(3) if v!=data[-1])
            for index,v in enumerate(data):
                if index==3 and authorize is not None and (not permitted() or last_edge is not None and time.monotonic()-last_edge>.5):
                    v=invalid;cancelled=True
                self._toggle(20,bool(v&2))
                self._toggle(144,bool(v&1))
                self._toggle(145,False)
                time.sleep(.018)
                if index==3 and authorize is not None and not cancelled and (not permitted() or last_edge is not None and time.monotonic()-last_edge>.7):
                    # A non-SOF invalid checksum consumes the partial frame;
                    # Lua never dispatches this action, even after RX timeout.
                    v=invalid;cancelled=True
                    self._toggle(20,bool(v&2));self._toggle(144,bool(v&1))
                self._toggle(145,True)
                last_edge=time.monotonic()
                time.sleep(.078)
                self._toggle(145,False)
                time.sleep(.040)
            self.log(('Python TX CANCELLED (fresh authorization/checksum): ' if cancelled else 'Python TX (lock-key frame sent; Lua ACK absent): ')+command)
            self.last_sent_at=time.monotonic()
            duration=self.last_sent_at-started
            if duration>1.8:self.log(f'Медленная передача Lua: {command}, {duration:.2f} с; выполнение игрой не подтверждено')
            return not cancelled

    def alt_is_down(self):
        """Observe the real key state, not merely successful packet encoding."""
        if self.dry_run:return self._dry_alt
        return bool((self.win.GetAsyncKeyState(0x12)|self.win.GetAsyncKeyState(0xA4))&0x8000)

    def cursor(self,x,y):
        self.last_cursor_target=(int(x),int(y))
        if self.dry_run:
            self.log(f'СИМУЛЯЦИЯ курсор ({x},{y})');return
        # SetCursorPos positions the cursor; virtual Xbox A selects the object.
        if not self.win.SetCursorPos(int(x),int(y)):
            raise OSError('Не удалось установить позицию курсора')

    def cursor_matches(self,tolerance=6):
        """Read back the OS pointer after settling, immediately before Xbox A."""
        if self.dry_run:return True
        if self.last_cursor_target is None:return False
        point=self._point_type()
        if not self.win.GetCursorPos(self._byref(point)):return False
        self.last_cursor_actual=(point.x,point.y)
        return max(abs(a-b) for a,b in zip(self.last_cursor_target,self.last_cursor_actual))<=tolerance

    def ping_if_idle(self):
        if not self.lock.acquire(blocking=False):return
        try:
            if time.monotonic()-getattr(self,'last_sent_at',-1e9)>=1.8:self.send('PING')
        finally:self.lock.release()

    def restore_locks(self):
        if self.dry_run:return
        with self.lock:
            self._toggle(145,False)
            for k,v in self._saved.items():self._toggle(k,v)
