"""Conservative scene check for a view dominated by sky during patrol.
No upward correction is guessed from a wall. Ambiguous scenes do not establish
an absolute angle; the initial level must still be set by the user.
"""
import cv2
import numpy as np
from navigation import Drive
from camera_control import PITCH_STRENGTH


def scene_view(frame):
    h,w=frame.shape[:2]
    tiles=[]
    for xa,xb,ya,yb in [(.25,.40,.15,.22),(.60,.75,.15,.22),
                         (.25,.40,.45,.57),(.60,.75,.45,.57),
                         (.25,.40,.60,.72),(.60,.75,.60,.72)]:
        a=frame[round(h*ya):round(h*yb),round(w*xa):round(w*xb)]
        if not a.size:return 'unknown'
        a=cv2.resize(a,(80,50));hsv=cv2.cvtColor(a,cv2.COLOR_BGR2HSV)
        hue,sat,value=np.median(hsv.reshape(-1,3),axis=0)
        edges=float((cv2.Canny(cv2.cvtColor(a,cv2.COLOR_BGR2GRAY),60,130)>0).mean())
        colour=((80<hue<125 and value>60) or (sat<60 and value>100) or (sat<100 and value>180))
        tiles.append((edges<.08 and colour,edges>.10 or (edges>.035 and not colour),float(value)))
    ground=[t[1] for t in tiles[2:]]
    if sum(ground)>=3 or all(ground[2:]):return 'ground'
    sky=sum(t[0] for t in tiles[2:])
    top=[t[2] for t in tiles[:2] if t[0]];bottom=[t[2] for t in tiles[2:] if t[0]]
    if sky>=3 and len(top)>=1 and bottom and np.median(bottom)-np.median(top)>12:return 'sky'
    return 'unknown'


class ViewGuard:
    def __init__(self):self.active=False;self.since=0;self.sky_since=None;self.next_pulse=0;self.ground_frames=0

    def update(self,frame,now):
        state=scene_view(frame)
        if not self.active:
            if state!='sky':self.sky_since=None;return None,False,False
            if self.sky_since is None:self.sky_since=now
            if now-self.sky_since<.35:return Drive(reason='проверяю, не направлена ли камера в небо'),False,False
            self.active=True;self.since=now;self.next_pulse=now
        if state=='ground':self.ground_frames+=1
        else:self.ground_frames=0
        if self.ground_frames>=2:
            self.active=False;self.sky_since=None;return Drive(),True,False
        if now-self.since>5:
            self.active=False;return Drive(),False,True
        if now>=self.next_pulse:
            self.next_pulse=now+.20
            return Drive(pitch=-PITCH_STRENGTH,lifetime=.035,reason='возвращаю землю в поле зрения коротким импульсом'),False,False
        return Drive(reason='проверяю поле зрения после короткого импульса'),False,False
