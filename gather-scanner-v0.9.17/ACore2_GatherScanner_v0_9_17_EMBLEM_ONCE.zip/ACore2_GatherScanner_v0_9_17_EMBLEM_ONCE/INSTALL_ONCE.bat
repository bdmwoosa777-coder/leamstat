@echo off
setlocal
cd /d "%~dp0"
set "VGAMEPAD_SKIP_VIGEMBUS_INSTALL=true"
python -m pip install -r requirements.txt
if errorlevel 1 pause
