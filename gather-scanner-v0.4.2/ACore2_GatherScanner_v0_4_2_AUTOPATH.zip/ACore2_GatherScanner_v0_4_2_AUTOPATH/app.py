# -*- coding: utf-8 -*-
from __future__ import annotations
import json,logging,os,queue,threading,time
import cv2
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox,filedialog
from gamepad_input import GamepadInput
from gather_engine import GatherEngine
from screen_capture import ScreenCapture
from minimap_setup import MinimapSetup
from win_hotkeys import SystemHotkeys
from vision import DEFAULT_NAMES

if os.name=='nt':
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(2)
    except Exception:pass

ROOT=Path(__file__).resolve().parent
CONF=ROOT/'settings_gather.json'
DEFAULT={
 'only_aether':False,'allow_click':True,'camera_scan':True,'dry_run':False,
 'assist_manual_target':True,'approach_timeout':30,'approach_stall_seconds':6,
 'gather_timeout':55,'audio_device':'AG271QG4','target_names':list(DEFAULT_NAMES),
 'debug_screenshots':True,'click_backend':'gamepad','ground_walk':True,
 'minimap_search':True,'minimap_roi':[],'minimap_templates':[],
 'minimap_threshold':.80,'gem_icon_threshold':.74,'target_missing_seconds':.8,
 'cursor_alt':True,'a_gap_seconds':.32,'flight_low_percent':8.0,
 'flight_resume_percent':18.0,'navigation_stall_seconds':6,'camera_yaw_sign':1,
 'scan_seconds':3.5,
}

def read_config():
 try:r=json.loads(CONF.read_text(encoding='utf-8'))
 except Exception:r={}
 return {**DEFAULT,**r}

class UI:
    def __init__(self):
        self.root=tk.Tk();self.root.title('ACore2 Gather Scanner v0.4.2 — штатный автопуть, обход V → F')
        self.root.geometry('1100x810')
        self.cfg=read_config();self.q=queue.Queue();self.worker=None;self.engine=None
        self.file_log=logging.getLogger('gather_scanner')
        self.file_log.setLevel(logging.INFO)
        try:
            handler=logging.FileHandler(ROOT/'gather.log',encoding='utf-8')
            handler.setFormatter(logging.Formatter('%(asctime)s %(message)s'))
            self.file_log.addHandler(handler)
        except OSError:pass
        self.gamepad=None
        self.vars={}
        self._start_token=0
        self._start_pending=False
        self._closing=False
        row=ttk.Frame(self.root,padding=10);row.pack(fill='x')
        for key,label in [('dry_run','Только наблюдение (НЕ нажимать)'),('allow_click','Выбирать ресурс одним A, проверять плашку и запускать подход F'),('minimap_search','Искать иконки на миникарте и двигаться к ним'),('assist_manual_target','Продолжать сбор уже выбранного ресурса'),('only_aether','Только эфир'),('camera_scan','Поворачивать камеру стиками при патрулировании'),('ground_walk','Патрулировать и двигаться к ресурсам стиком Xbox')]:
            v=tk.BooleanVar(value=bool(self.cfg.get(key)))
            self.vars[key]=v
            ttk.Checkbutton(row,text=label,variable=v).pack(anchor='w')
        connection=ttk.Frame(self.root,padding=5);connection.pack(fill='x')
        ttk.Label(connection,text='Выбор ресурса:').pack(side='left')
        self.backend=tk.StringVar(value=self.cfg.get('click_backend','gamepad'))
        ttk.Combobox(connection,textvariable=self.backend,values=['gamepad'],width=12,state='readonly').pack(side='left',padx=5)
        ttk.Button(connection,text='Подключить Xbox',command=self.connect_gamepad).pack(side='left',padx=5)
        ttk.Button(connection,text='Настроить миникарту / добавить иконку',command=self.setup_minimap).pack(side='left',padx=5)
        ttk.Label(self.root,text='Xbox: A, движение и камера. G HUB Lua: Alt, F, V, прыжок. G9 запускает Lua. Миникарта распознаётся автоматически.',foreground='#245').pack(anchor='w',padx=10)
        buttons=ttk.Frame(self.root,padding=10);buttons.pack(fill='x')
        ttk.Button(buttons,text='Сохранить настройки',command=self.save).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F8 Старт/пауза',command=self.toggle).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F9 СТОП',command=self.stop).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F10 Заглушить сигнал',command=self.silence).pack(side='left',padx=3)
        ttk.Button(buttons,text='ТЕСТ по двум кадрам',command=self.offline).pack(side='left',padx=3)
        journal=ttk.Frame(self.root,padding=5);journal.pack(fill='x')
        ttk.Button(journal,text='Скопировать журнал',command=self.copy_log).pack(side='left',padx=4)
        ttk.Button(journal,text='Сохранить журнал...',command=self.save_log).pack(side='left',padx=4)
        ttk.Button(journal,text='Диагностический кадр через 3 с',command=self.diagnostic).pack(side='left',padx=4)
        self.status=ttk.Label(self.root,text='Не запущено');self.status.pack(anchor='w',padx=10)
        self.box=tk.Text(self.root,height=23,wrap='word');self.box.pack(fill='both',expand=True,padx=10,pady=10)
        self.root.after(180,self.pump)
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.hotkeys=SystemHotkeys(self.q)
        self.root.after(150,self.connect_gamepad)

    def connect_gamepad(self):
        if self.gamepad:return True
        try:
            self.gamepad=GamepadInput(logger=self.log)
            self.log('Xbox готов. Оставьте программу открытой; приёмник F710 можно отключить.')
            return True
        except Exception as exc:
            self.log('Xbox не подключён: '+str(exc))
            return False

    def setup_minimap(self):
        self.stop('НАСТРОЙКА МИНИКАРТЫ')
        self.log('Снимок через 4 секунды: переключитесь в игру, откройте миникарту с видимой иконкой ресурса.')
        self.root.iconify()
        self.root.after(4000,self._capture_minimap)

    def _capture_minimap(self):
        if self._closing:return
        if self.worker and self.worker.is_alive():
            self.root.after(250,self._capture_minimap);return
        try:
            screen=ScreenCapture()
            if not screen.pick():raise RuntimeError('Окно AION2 не найдено')
            frame,_=screen.frame()
            self.root.deiconify()
            MinimapSetup(self.root,frame,self.cfg,self._minimap_saved)
        except Exception as exc:
            self.root.deiconify();self.log('Не удалось настроить миникарту: '+str(exc))

    def _minimap_saved(self):
        self.vars['minimap_search'].set(True)
        self.save()
        self.log('Миникарта сохранена. Иконок-эталонов: '+str(len(self.cfg['minimap_templates'])))
    def log(self,t):
        self.file_log.info(str(t));self.q.put(str(t))

    def copy_log(self):
        value=(ROOT/'gather.log').read_text(encoding='utf-8') if (ROOT/'gather.log').exists() else self.box.get('1.0','end')
        self.root.clipboard_clear();self.root.clipboard_append(value)
        self.log('Журнал скопирован в буфер обмена')

    def save_log(self):
        destination=filedialog.asksaveasfilename(parent=self.root,title='Сохранить журнал',
            defaultextension='.txt',initialfile='gather_log.txt',filetypes=[('Текст','*.txt'),('Все','*.*')])
        if destination:
            try:
                value=(ROOT/'gather.log').read_text(encoding='utf-8') if (ROOT/'gather.log').exists() else self.box.get('1.0','end')
                Path(destination).write_text(value,encoding='utf-8');self.log('Журнал сохранён: '+destination)
            except Exception as exc:messagebox.showerror('Журнал',str(exc),parent=self.root)

    def diagnostic(self):
        self.stop('ДИАГНОСТИЧЕСКИЙ КАДР')
        self.log('Через 3 секунды снимок игры; затем снова Ctrl+F8 для работы')
        self.root.iconify();self.root.after(3000,self._diagnostic_capture)

    def _diagnostic_capture(self):
        try:
            from diagnostics import analyze
            screen=ScreenCapture()
            if not screen.pick():raise RuntimeError('Окно игры не найдено')
            frame,_=screen.frame();path=ROOT/'debug_gather'/('diagnostic_'+time.strftime('%Y%m%d_%H%M%S'))
            data=analyze(frame,self.cfg,path)
            self.log('Диагностика: '+str(path)+'.png / .json')
            self.log('Энергия/дуга: '+str(data['flight'])+'; направление: '+str(data['radar']['heading'])+'; иконок: '+str(len(data['radar']['markers'])))
        except Exception as exc:self.log('Ошибка диагностики: '+str(exc))
        finally:self.root.deiconify()
    def pump(self):
        for _ in range(40):
            try:s=self.q.get_nowait()
            except queue.Empty:break
            if isinstance(s,tuple) and s[0]=='hotkey':
                {'toggle':self.toggle,'stop':self.stop,'silence':self.silence}[s[1]]()
                continue
            s=str(s)
            self.box.insert('end',s+'\n');self.box.see('end')
            self.status.config(text=s[:110])
        self.root.after(180,self.pump)
    def save(self):
        for k,v in self.vars.items():self.cfg[k]=bool(v.get())
        self.cfg['click_backend']=self.backend.get()
        CONF.write_text(json.dumps(self.cfg,ensure_ascii=False,indent=2),encoding='utf-8')
        self.log('Настройки сохранены')
    def toggle(self):
        active=(self._start_pending or
                (self.worker is not None and self.worker.is_alive() and
                 self.engine is not None and not self.engine.stop_event.is_set()))
        if active:
            self.stop('ПАУЗА Ctrl+F8')
        else:
            self.start()

    def start(self):
        if self._closing:return
        if self._start_pending:return
        if self.worker and self.worker.is_alive() and self.engine and not self.engine.stop_event.is_set():
            self.log('Скан уже запущен')
            return
        self._start_token+=1
        token=self._start_token
        self._start_pending=True
        self.log('Ctrl+F8: запрос запуска, после завершения прежнего цикла')
        self.root.after(10,lambda:self._launch_if_ready(token))

    def _launch_if_ready(self,token):
        if self._closing or not self._start_pending or token!=self._start_token:return
        if self.worker and self.worker.is_alive():
            self.root.after(150,lambda:self._launch_if_ready(token))
            return
        self.save()
        if not self.cfg['dry_run'] and not (self.cfg['allow_click'] or self.cfg.get('assist_manual_target') or self.cfg.get('ground_walk')):
            self._start_pending=False
            messagebox.showwarning('Режим','Для ввода включите «Автоподход» или используйте режим наблюдения.')
            return
        if self.engine:self.engine.silence() # stop prior alarm before explicit manual restart
        if not self.cfg['dry_run'] and self.cfg.get('click_backend')=='gamepad' and not self.connect_gamepad():
            self._start_pending=False;return
        self.engine=GatherEngine(dict(self.cfg),self.log,gamepad=None if self.cfg['dry_run'] else self.gamepad)
        self.log('Переключитесь в AION2. G9 включает приёмник Lua; через 3 с начнётся скан.')
        self.root.after(3000,lambda:self._go(token))

    def _go(self,token):
        if self._closing or not self._start_pending or token!=self._start_token:return
        self._start_pending=False
        if not self.engine or self.engine.stop_event.is_set():return
        self.worker=threading.Thread(target=self.engine.run,daemon=True)
        self.worker.start()

    def stop(self,reason='СТОП Ctrl+F9'):
        self._start_token+=1
        self._start_pending=False
        if self.engine:self.engine.stop()
        self.log(reason+': скан/CAPTCHA/смерть остановлены')

    def silence(self):
        if self.engine:self.engine.silence()
        self.log('Ctrl+F10: прекращён текущий звук CAPTCHA/смерти; состояние скана не изменено')

    def offline(self):
        if self._start_pending or (self.worker and self.worker.is_alive()):return
        cfg={**self.cfg,'dry_run':True,'allow_click':False,'camera_scan':False}
        self.engine=GatherEngine(cfg,self.log)
        samples=[ROOT/'testdata/orihalkon_example.jpg',ROOT/'testdata/air_gather_example.jpg']
        self.worker=threading.Thread(target=lambda:self.engine.run(offline=samples),daemon=True)
        self.worker.start()
    def close(self):
        self._closing=True
        self.stop('ЗАКРЫТИЕ')
        self.silence()
        self.hotkeys.stop()
        if self.gamepad:self.gamepad.close()
        self.root.after(500,self.root.destroy)
    def run(self):self.root.mainloop()

if __name__=='__main__':UI().run()
