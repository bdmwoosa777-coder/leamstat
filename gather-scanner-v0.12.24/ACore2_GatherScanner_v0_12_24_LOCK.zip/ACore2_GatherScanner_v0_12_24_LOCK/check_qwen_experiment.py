"""User-side real inference check: synthetic frames only, no screen/input."""
from pathlib import Path
import json,time
import numpy as np
import cv2
from qwen_experiment import MODEL,TemporalClient,View

ROOT=Path(__file__).resolve().parent

def synthetic_views():
 image=np.full((360,640,3),60,np.uint8)
 cv2.rectangle(image,(0,0),(639,120),(150,120,80),-1)
 cv2.rectangle(image,(220,120),(420,280),(75,75,75),-1)
 cv2.fillConvexPoly(image,np.array([(80,359),(230,359),(220,200),(140,200)]),(130,145,150))
 context={'mode':'synthetic_test','kind':None,'goal_epoch':0,'camp_leg':None,'goal_bearing':0,'motion_valid':True,'displacement':[0,0]}
 minimap=np.full((224,224,3),(130,145,150),np.uint8)
 cv2.arrowedLine(minimap,(112,112),(112,82),(255,255,255),3)
 cv2.circle(minimap,(75,70),5,(210,225,80),-1)
 return (View(100,0,0,context,image.copy(),minimap.copy()),View(101.5,0,0,context,image.copy(),minimap.copy()))

def check(cfg,root=ROOT,client=None):
 client=client or TemporalClient(cfg.get('analyzer_url','http://127.0.0.1:11434'),cfg.get('qwen_model',MODEL))
 client.single_frame=True
 report={'model':client.model,'synthetic_only':True,'valid_answer':False,'navigation_quality_tested':False}
 try:
  report['ollama']=client.call('/api/version',timeout=3)
  report['capabilities']=client.probe().get('capabilities',[])
  if hasattr(client,'warmup'):
   began=time.monotonic();client.warmup(timeout=90);report['load_seconds']=round(time.monotonic()-began,3)
  began=time.monotonic();report['cold_answer']=client.analyze_views(synthetic_views(),timeout=90)
  report['cold_seconds']=round(time.monotonic()-began,3);report['first_visual_stats']=getattr(client,'last_stats',{})
  began=time.monotonic();report['warm_answer']=client.analyze_views(synthetic_views(),timeout=12)
  report['warm_seconds']=round(time.monotonic()-began,3);report['warm_visual_stats']=getattr(client,'last_stats',{})
  report['valid_answer']=True
  report['warm_reply_within_use_window']=report['warm_seconds']<=8
  report['running_models']=client.call('/api/ps',timeout=3)
  report['gpu_resident']=any(m.get('size_vram',0)>0 and m.get('name',m.get('model'))==client.model for m in report['running_models'].get('models',[]))
 except Exception as exc:report['error']=str(exc)
 finally:
  try:client.unload();report['unloaded']=True
  except Exception as exc:report['unload_error']=str(exc)
 (root/'qwen_experiment_check.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(report,ensure_ascii=False,indent=2))
 print('Проверены API, формат ответа и скорость. Это НЕ проверка качества навигации в игре.')
 return report

def main():
 cfg=json.loads((ROOT/'settings_gather.json').read_text(encoding='utf-8'))
 return 0 if check(cfg)['valid_answer'] else 1

if __name__=='__main__':raise SystemExit(main())
