"""Bundled passive capture -> pipe -> telemetry. No CubeRadar or JSONL tail.

The internal module owns Npcap, reassembly and LZ4. Only decoded server frames
enter this pipe; gameplay input remains in the existing engine.
"""
import copy,hashlib,json,os,subprocess,threading,time
from pathlib import Path
from network_state import Telemetry
from spatial import Atlas

ROOT=Path(__file__).resolve().parent
MAX_LINE=2*1024*1024

class NetworkFeed:
    def __init__(self,logger=lambda _:None,command=None):
        self.log=logger;self.lock=threading.RLock()
        catalogue=json.loads((ROOT/'gather_catalogue.json').read_text(encoding='utf-8-sig'))
        self.telemetry=Telemetry(map(int,catalogue));self.closed=threading.Event()
        self.process=None;self.worker=None;self.error=None
        self.command=command
        self.latest_flow=None;self.last_packet=None;self.status={}
        self.protocol_ok=False;self.last_identity=None;self.last_status_saved=0
        self.atlas=Atlas()
        self.last_hit_note=0;self.last_gather_audit=None
        self.directory=ROOT/'network_diagnostics'/('run_'+str(time.time_ns()))

    def start(self):
        if self.command is None:
            if os.name!='nt':raise RuntimeError('Встроенный захват требует Windows и Npcap')
            exe=ROOT/'native_network'/'acore2_net.exe'
            manifest=exe.parent/'SHA256SUMS'
            if not exe.is_file() or not manifest.is_file():
                raise RuntimeError('Не найден встроенный сетевой модуль. Распакуйте ВЕСЬ архив в новую папку.')
            expected=manifest.read_text(encoding='ascii').split()[0]
            if hashlib.sha256(exe.read_bytes()).hexdigest()!=expected:
                raise RuntimeError('Повреждён сетевой модуль. Заново распакуйте архив.')
            command=[str(exe)]
        else:command=list(self.command) # injected offline backend for tests only
        self.directory.mkdir(parents=True,exist_ok=True)
        self.process=subprocess.Popen(command,cwd=ROOT,stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=65536,
            creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.stderr_worker=threading.Thread(target=self._stderr_loop,daemon=True)
        self.stderr_worker.start()
        self.worker=threading.Thread(target=self._loop,daemon=True);self.worker.start()
        self.log('Сеть: встроенный модуль запущен. Ищу соединение AION2; CubeRadar не нужен.')

    def _stderr_loop(self):
        try:
            with (self.directory/'module_stderr.txt').open('wb') as out:
                saved=0
                while not self.closed.is_set():
                    part=self.process.stderr.read(4096)
                    if not part:break
                    if saved<65536:out.write(part[:65536-saved]);out.flush();saved+=len(part)
        except (OSError,ValueError):pass

    def ingest(self,row):
        kind=row.get('type')
        if kind=='hello':
            if row.get('protocol')!=1:raise RuntimeError('Несовместимая версия встроенного сетевого модуля')
            self.protocol_ok=True;return
        if kind=='error':raise RuntimeError(str(row.get('message','Ошибка захвата'))[:1000])
        if kind=='status':
            with self.lock:self.status=dict(row)
            self._save_status();return
        if kind!='frame':return
        stamp=row.get('t');flow=row.get('flow');op=row.get('op');raw=row.get('hex')
        if (not isinstance(flow,int) or isinstance(flow,bool) or flow<1
            or not isinstance(stamp,int) or isinstance(stamp,bool)):return
        if not isinstance(op,str) or not isinstance(raw,str) or len(raw)>131072:return
        try:body=bytes.fromhex(raw)
        except ValueError:return
        note=None
        with self.lock:
            events=self.telemetry.feed(flow,op,body,stamp)
            self.latest_flow=flow
            self.last_packet=max(stamp,self.last_packet or stamp)
            state=self.telemetry.flows.get(flow)
            identity=(flow,state.own,state.identity_source) if state else None
            if identity and identity!=self.last_identity:
                self.last_identity=identity
                if state.own is not None:note='Сеть: свой персонаж определён ('+state.identity_source+').'
                elif state.identity_source=='unknown':note='Сеть: игровой поток подтверждён, поиск разрешён. ID пока неизвестен: доступны прямые сетевые признаки; гибридный сборщик дополнительно сверяет изменившийся HP HUD/сети.'
            if any(e['kind']=='own_combat_damage' for e in events) and time.monotonic()-getattr(self,'last_hit_note',0)>.5:
                self.last_hit_note=time.monotonic()
                note=(note+'; ' if note else '')+f'Сеть RX: удар по персонажу, от захвата до разбора {max(0,int(time.time()*1000)-stamp)} мс'
            if state is not None:
                node=state.nodes.get(state.collecting or state.selected)
                audit=(flow,state.own,state.selected,state.collecting,state.attempt_active,
                       node.used if node else None,node.gather_time if node else None,state.hp)
                if audit!=self.last_gather_audit and (state.collecting is not None or self.last_gather_audit and self.last_gather_audit[3] is not None):
                    own_result=any(e['kind']=='own_attempt_ended' for e in events)
                    removed=next((e for e in events if e['kind']=='resource_unavailable'),None)
                    detail=f'NET_COLLECTION: op={op}, own={state.own}, selected={state.selected}, actor={state.collecting}, used={node.used if node else None}, active={state.attempt_active}, ordinal={state.attempt_ordinal}, собственный_результат={own_result}, own_result_used={state.last_own_result_used}, удаление={removed.get("reason") if removed else None}, HP={state.hp}'
                    note=(note+'; ' if note else '')+detail
                self.last_gather_audit=audit
        if note:self.log(note)

    def confirm_own_hp(self,current,maximum,stamp):
        note=None
        with self.lock:
            view=self.view()
            if not view['ready'] or view['state'].own is not None:return False
            if not self.telemetry.confirm_own_hp(self.latest_flow,current,maximum,stamp):return False
            state=self.telemetry.flows[self.latest_flow]
            self.last_identity=(self.latest_flow,state.own,state.identity_source)
            note='Сеть: свой персонаж определён по двум совпадениям изменившегося HP HUD/сети; источник hud-hp-correlated.'
        self.log(note);return True

    def view(self,now=None):
        now=time.time()*1000 if now is None else now
        with self.lock:
            state=self.telemetry.flows.get(self.latest_flow)
            age=(now-state.last_packet)/1000 if state and state.last_packet is not None else None
            fresh=age is not None and -.5<=age<=2.5
            active=[f for f in self.telemetry.flows.values() if f.last_packet is not None
                    and -.5<=(now-f.last_packet)/1000<=2.5]
            ambiguous=state is not None and state.identity_source=='ambiguous-own-flight'
            ready=bool(state is not None and fresh and len(active)==1 and not ambiguous and not self.error and not self.closed.is_set())
            if self.error:reason=self.error
            elif self.closed.is_set():reason='захват остановлен'
            elif state is None:
                reason='ожидаю игровой поток; пакетов: '+str(self.status.get('packets',0))+', кадров: '+str(self.status.get('frames',0))
                if self.status.get('message'):reason+='; '+self._message(self.status['message'])
            elif len(active)>1:reason='несколько игровых потоков; ожидаю однозначное соединение'
            elif ambiguous:reason='противоречивые данные персонажа; управление приостановлено'
            elif not fresh:reason=f'задержка игровых пакетов {age:.1f} с; ввод приостановлен'
            else:reason='игровой поток подтверждён; '+('свой персонаж определён' if state.own is not None else 'поиск разрешён, персонаж определится при собственном сборе')
            return dict(flow=self.latest_flow,state=state.snapshot() if state else None,age=age,error=self.error,
                        ready=ready,identity_ready=bool(ready and state.own is not None),
                        reason=reason,status=dict(self.status))

    @staticmethod
    def _message(message):
        if 'Npcap is not installed' in str(message):return 'Npcap не найден. Нужен установленный Npcap. '+str(message)
        if str(message).startswith('AION2 connection/adapter not found'):return 'Не найдены соединение AION2 или подходящий адаптер. Проверьте, что персонаж уже в игре, и настройки VPN/Npcap.'
        if str(message).startswith('game connection / VPN adapter changed'):return 'Изменилось игровое соединение или адаптер VPN. Остановите и снова запустите бота.'
        if message=='capturing':return 'адаптер открыт, захват идёт'
        if str(message).startswith('waiting for AION2'):return 'ищу соединение игры и подходящий адаптер'
        return str(message)

    def describe(self):
        v=self.view();s=v['status']
        return ('Сеть: '+v['reason']+'; адаптер: '+str(s.get('device','ещё не найден'))
                +'; пакетов: '+str(s.get('packets',0))+'; кадров: '+str(s.get('frames',0))
                +'\n'+self.atlas.describe(v['state']))

    def _save_status(self,force=False):
        if not self.directory.is_dir():return
        now=time.monotonic()
        if not force and now-self.last_status_saved<1:return
        self.last_status_saved=now
        try:
            view=self.view()
            report={k:view[k] for k in ('ready','identity_ready','age','error','reason','status')}
            report['updated_utc_ms']=int(time.time()*1000)
            (self.directory/'status.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
        except OSError:pass

    def _loop(self):
        try:
            while not self.closed.is_set():
                line=self.process.stdout.readline(MAX_LINE+1)
                if not line:
                    if not self.closed.is_set():raise RuntimeError('Встроенный сетевой модуль завершился; см. network_diagnostics')
                    break
                if len(line)>MAX_LINE or not line.endswith(b'\n'):
                    raise RuntimeError('Повреждена строка встроенного сетевого модуля')
                row=json.loads(line)
                if not isinstance(row,dict):raise RuntimeError('Неверный ответ сетевого модуля')
                if row.get('type')!='hello' and not self.protocol_ok:
                    raise RuntimeError('Сетевой модуль не подтвердил версию протокола')
                self.ingest(row)
        except Exception as exc:
            if not self.closed.is_set():
                with self.lock:self.error=self._message(str(exc))
                self.log('Сеть: ошибка: '+self.error)
        finally:self._save_status(force=True)

    def close(self):
        self.closed.set()
        if self.process and self.process.poll() is None:
            try:
                self.process.stdin.write(b'q\n');self.process.stdin.flush()
                self.process.wait(timeout=2)
            except (OSError,subprocess.TimeoutExpired):
                self.process.terminate()
                try:self.process.wait(timeout=2)
                except subprocess.TimeoutExpired:self.process.kill();self.process.wait(timeout=2)
        if self.worker and self.worker is not threading.current_thread():self.worker.join(timeout=1)
        stderr_worker=getattr(self,'stderr_worker',None)
        if stderr_worker and stderr_worker is not threading.current_thread():stderr_worker.join(timeout=1)
        if self.process:
            for stream in (self.process.stdin,self.process.stdout,self.process.stderr):
                if stream:
                    try:stream.close()
                    except OSError:pass
        self._save_status(force=True)
