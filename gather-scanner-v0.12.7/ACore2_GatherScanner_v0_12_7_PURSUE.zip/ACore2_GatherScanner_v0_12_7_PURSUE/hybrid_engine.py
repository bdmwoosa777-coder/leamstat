"""Classic resource state machine + fast minimap driver + asynchronous detours."""
from dataclasses import replace
import math,time
import cv2
from gather_engine import GatherEngine,OWN_RESOURCE
from hybrid_navigation import RouteAdvisor,HybridPlanner
from navigation import Drive
from vision import gathering_panel_pair,find_resource_near,find_world_resource,fast_ether_candidates,read_world_caption,Observation
from return_exit import purple_anchor
from xbox_bridge import XboxBridge
from map_teleport import same_stamp,is_map,menu_stamp
from idle_return import map_evidence
from caption_memory import CaptionMemory

class HybridGatherEngine(GatherEngine):
 def _make_bridge(self,gamepad,cfg,emit):
  if cfg.get('control_transport','xbox')=='lua' or gamepad is None:return super()._make_bridge(gamepad,cfg,emit)
  return XboxBridge(gamepad,self.stop_event,lambda:self.screen.focused(),lambda:self.map_active and self.map_teleport is not None,cfg.get('dry_run',False),emit)
 def _wait_keyboard_alt_state(self,desired,seconds=.6):
  if not getattr(self.bridge,'controller_native',False):return super()._wait_keyboard_alt_state(desired,seconds)
  if self._focus_ok() and bool(self.bridge.alt_is_down())==desired:return True
  self.halt_reason='Режим курсора Xbox LB+LT не подтверждён в отчёте';self.say(self.halt_reason);self.stop();return False
 def _preflight_receiver(self):
  if not getattr(self.bridge,'controller_native',False):return super()._preflight_receiver()
  until=time.monotonic()+10
  while not self.stop_event.is_set() and not self.screen.focused():
   if time.monotonic()>=until:self.halt_reason='Окно AION2 не активно';return False
   if self.stop_event.wait(.05):return False
  if not self._focus_ok():return False
  self._neutral();self.receiver_ready=False
  try:
   if not self.bridge.send('ALT_DOWN') or not self._wait_alt_state(True):return False
   self.bridge.send('ALT_UP')
   if not self._wait_alt_state(False):return False
   self.receiver_ready=True;self.say('Xbox готов: отчёты LB+LT вниз/вверх переданы без A. Lua/G9 не нужны; реакция игры проверяется по кадру, это не игровой ACK')
   return True
  finally:self.bridge.send('ALT_UP')
 def __init__(self,cfg,*args,**kwargs):
  enabled=cfg.get('analyzer_enabled',True)
  super().__init__({**cfg,'analyzer_enabled':False},*args,**kwargs)
  self.cfg['analyzer_enabled']=enabled
  self.cfg['continuous_patrol_defense']=True
  self.cfg['defense_tab_limit']=max(3,min(8,int(cfg.get('defense_max_tabs',8))))
  self.map_exit_failure=None
  self.native_close_after=0
  self.analyzer=RouteAdvisor(self.cfg,self.say) if enabled and self.scene_host is not None else None
  self.hybrid=HybridPlanner(cfg.get('camera_yaw_sign',1));self.hybrid_note=-1e9;self.hybrid_camp_check=-1e9;self.hybrid_identity_note=-1e9;self.hybrid_camp_pending=False;self.caption_latch=None;self.caption_after=0
  self.fast_sight_after=0;self.scan_checked_pulse=None
  self.camp_rearm=True;self.sprint_surface_until=0
  self.continuation_watch=None;self.continuation_check_after=0
  self.caption_memory=CaptionMemory()
  if self.gamepad is not None:self.gamepad.translation_lease_floor=float(self.cfg.get('smooth_translation_seconds',.75))
  # One progress watchdog owns detours. The legacy one stores screen-band IDs,
  # which are unsuitable for avoidance across camera changes.
  self.scene_pilot.follower.observe_progress=lambda *a:False
  self.say('HYBRID 0.12.7: курс к ресурсу, приоритет свежего эфира и ударов; выход из ошибки карты без остановки поиска')
 def _no_yield_rescue_allowed(self,now):
  # Ninety seconds without loot is not evidence that walking needs takeoff.
  return self.terrain_watch.due(now)
 def bridge_cmd(self,command):
  native=getattr(self.bridge,'controller_native',False)
  free_close=(command=='END_AIR' and native and self.mode in ('SEARCH','ACQUIRE_WAIT','RESCUE','PROBE','PATROL_ESCAPE') and not self.target_confirmed and not self.resource_hold)
  if free_close and time.monotonic()<getattr(self,'native_close_after',0):return False
  sent=super().bridge_cmd(command)
  if free_close and sent:
   self.native_close_after=time.monotonic()+8;self.rescue_air_search_until=max(self.rescue_air_search_until,self.native_close_after)
  return sent
 def _service_wing_close(self,reading,now):
  if not getattr(self.bridge,'controller_native',False) or self.wing_close_pending is None:return super()._service_wing_close(reading,now)
  if not reading.confirmed:return super()._service_wing_close(reading,now)
  if now-self.wing_close_pending<3:self._neutral();return True
  self.wing_close_pending=None;self.wing_close_started=None;self.wing_close_retries=0
  self.rescue_air_search_until=max(self.rescue_air_search_until,now+5);self.nav.pause(now)
  self.say('AIR_CLOSE: одна Y уже передана; исчезновение дуги не подтверждено, повтор при падении запрещён. Продолжаю поиск без новой Y')
  return False
 def _map_teleport_failed(self,observation,reason,now):
  if self.map_teleport is None or self.map_teleport.used:
   return super()._map_teleport_failed(observation,reason,now)
  self._neutral();self.map_exit_failure={'reason':reason,'since':now,'sent':False,'absent':None}
  self.say('MAP_RECOVER: телепорт не подтверждался; закрываю карту и возвращаю поиск после проверки игрового экрана: '+reason)
 def _map_failure_exit_tick(self,frame,now):
  failure=self.map_exit_failure
  if failure is None:return False
  self._neutral()
  if not self._focus_ok():return True
  if not self._map_input_ready():
   self.halt_reason='MAP_RECOVER: сеть или сбор запрещают ввод';self.say(self.halt_reason);self.stop();return True
  opened=same_stamp(frame,self.map_menu_stamp) or is_map(frame)
  evidence=map_evidence(frame,self.minimap.bounds(frame))
  if opened:
   failure['absent']=None
   if not failure['sent']:
    if self.map_menu_stamp is None:self.map_menu_stamp=menu_stamp(frame)
    failure['sent']=True # A partially delivered toggle must not be repeated.
    if hasattr(self.bridge,'send_guarded'):self.bridge.send_guarded('MAP',lambda:self._map_input_ready(menu=True))
    else:self.bridge_cmd('MAP')
  elif evidence.usable and not evidence.loading:
   if failure['absent'] is None:failure['absent']=now
   if now-failure['absent']>=.6:
    self.bridge.send('STOP');self.map_teleport=None;self.map_active=False;self.map_exit_failure=None
    self.pitch.resume_return(now);self.return_exit_guard=False;self.exit_route=None
    self.no_yield.next_return=max(self.no_yield.next_return,self.map_return_after,now+60)
    self.nav.exclude_goal(now,30);self.nav.pause(now);self.terrain_watch.attempted(now)
    self.hybrid=HybridPlanner(self.cfg.get('camera_yaw_sign',1));self.scene_camera_epoch+=1
    self.identity_valid_after=now;self.change_mode('SEARCH')
    self.say('MAP_RECOVER: игровой экран подтверждён; продолжаю поиск, телепорт успешным не считаю')
    return True
  else:failure['absent']=None
  if now-failure['since']>8:
   self.halt_reason='MAP_RECOVER: закрытие карты не подтверждено за 8 с';self.say(self.halt_reason);self.stop()
  return True
 def _network_defense_tick(self,now):
  if self.network_defense is None and self.mode!='DEFENSE' and self.defense_restore_view is None:
   if self._net_defense(now):return True
  return super()._network_defense_tick(now)
 def _net_defense(self,now):
  if self.mode in ('RESCUE','PROBE','PATROL_ESCAPE'):
   if not self._pending_network_hits(now):return False
   self._neutral();self.caption_latch=None;self.terrain_recovery=None;self.probe=None;self.pending_probe=None;self.patrol_escape=None
   self.pitch.resume_return(now);self.change_mode('SEARCH')
  return super()._net_defense(now)
 def save_debug(self,frame,label):
  if not self.cfg.get('debug_screenshots'):return
  try:
   self.screenshot_path.mkdir(exist_ok=True)
   safe=''.join(c for c in label if c.isalnum() or c=='_')[:80]
   file=self.screenshot_path/('hybrid_'+str(time.time_ns())+'_'+safe+'.jpg')
   if not cv2.imwrite(str(file),frame,[cv2.IMWRITE_JPEG_QUALITY,90]):return
   files=sorted(self.screenshot_path.glob('hybrid_*.jpg'),key=lambda p:p.name);total=sum(p.stat().st_size for p in files)
   while files and (len(files)>60 or total>64*1024*1024):
    old=files.pop(0);total-=old.stat().st_size;old.unlink()
  except (OSError,cv2.error) as exc:self.say('DEBUG_SAVE: '+str(exc)+'; управление продолжается')

 def _caption_rejected(self,candidate):
  return bool(self.caption_memory.rejected(candidate,time.monotonic()))
 def _allowed(self,candidate,now):
  return not self._caption_rejected(candidate) and super()._allowed(candidate,now)
 def _acquire_miss(self,candidate,now):
  self.caption_latch=None
  super()._acquire_miss(candidate,now)
 def _acquire_caption_matches(self,frame,candidate):
  if candidate.name!='Эфир':return True
  if self._caption_rejected(candidate):return False
  x,y,w,h=candidate.box
  if candidate.emblem is not None:
   ex,ey,ew,eh=candidate.emblem;gap=y-ey-eh
   if not (-2<=gap<=max(12,h*1.7) and abs(ex+ew/2-x-w/2)<=max(10,w*.30)):
    self.say(f'ACQUIRE_REJECT: ромбик не привязан к подписи Эфир; caption={candidate.box}, emblem={candidate.emblem}')
    return False
  current,_=self.screen.frame();name,text=read_world_caption(current,candidate,self._owned_resource_names())
  self.say(f'ACQUIRE_POINT: ожидаю Эфир; локальное имя={name}, текст={text[:60]!r}, caption={candidate.box}, emblem={candidate.emblem}')
  if name is not None and name!=candidate.name:
   self.caption_memory.remember(candidate,name,time.monotonic())
   self.say('ACQUIRE_REJECT: локальная подпись '+name+' противоречит Эфиру; A не отправлена')
   return False
  return self._focus_ok()
 def _completed_wait_proof(self,view):
  if (not view or not view['ready'] or self.network_target is None or self.mode!='GATHER' or self.map_active
      or not self.target_confirmed or not self.resource_hold or not self.real_gather_panel_seen):return None
  state=view['state'];node=self._net_node(view);result=state.last_own_result
  if (node is None or node.actor!=self.network_target[1] or not node.visible or node.gather_time is None or node.used not in (1,2)
      or state.own is None or view['flow']!=self.network_target[0]
      or self.network_owner is not None and state.own!=self.network_owner
      or state.collecting!=node.actor or state.selected not in (0,node.actor) or state.attempt_active
      or node.actor in state.npcs or node.actor in state.players
      or not result or result[0]!=node.actor or state.last_own_result_used!=node.used
      or result[1]<max(self.network_claimed_at,node.gather_time,state.started or 0)):return None
  return (self.network_target,state.own,node.gather_time,state.started,state.attempt_ordinal,node.used,result[1])
 def _completed_point_wait_tick(self,frame,now):
  if self.stop_event.is_set() or not self._focus_ok():
   self.continuation_watch=None;return False
  if self.network is None or self.click_busy or now<self.continuation_check_after:return False
  self.continuation_check_after=now+.20
  view=self._net_view();proof=self._completed_wait_proof(view)
  if proof is None or gathering_panel_pair(frame) or self._fresh_click_candidate(frame) is not None:
   self.continuation_watch=None;return False
  if self.continuation_watch is None or self.continuation_watch['proof']!=proof:
   self.continuation_watch={'proof':proof,'since':now}
   self.say('CONTINUATION_WAIT: собственная попытка окончена, свежая точка потеряна; не более 8 с на восстановление')
   return False
  if now-self.continuation_watch['since']<8:return False
  current,_=self.screen.frame();latest=self._net_view()
  if (self._completed_wait_proof(latest)!=proof or gathering_panel_pair(current)
      or self._fresh_click_candidate(current) is not None):
   self.continuation_watch=None;return False
  # Neutral input only. Never cancel an active attempt or invent depletion.
  binding=self.network_target;node=self._net_node(latest)
  self._neutral();self.f_disable()
  self.resource_retry_after[binding]=now+45;self.abandoned_lease=(*binding,node.gather_time)
  self._clear_view_recovery();self.collection_cycle.reset();self.cycle_authorized=None;self.cycle_ui_note=None
  self.target=None;self.candidate=None;self.target_confirmed=False;self.resource_hold=False;self.collecting_visible=False
  self.resume_resource_id=None;self.reacquire_until=None;self.missing_since=None;self._reset_resource_watch()
  self.nav.exclude_goal(now,45);self.pitch.restore(now)
  self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
  self.continuation_watch=None;self.change_mode('SEARCH');self.identity_valid_after=now
  self.say('CONTINUATION_RELEASE: 8 с без точки после подтверждённого окончания; ресурс отложен на 45 с, продолжаю поиск без нового A/B/Y')
  return True
 def _resource_fast_tick(self,frame,reading,now,panel=None,slots=None):
  self._adopt_network_collection()
  if self._completed_point_wait_tick(frame,now):return True
  return super()._resource_fast_tick(frame,reading,now,panel,slots)
 def _needs_visual_hp(self):
  if self.network is None:return True
  if not hasattr(self.network,'confirm_own_hp'):return False
  view=self._net_view();return bool(view and view['ready'] and view['state'].own is None)
 def _health_identity_sample(self,value,captured,verified):
  if self.network is None or not hasattr(self.network,'confirm_own_hp') or not verified or value is None or value.current>=value.maximum or not self._focus_ok() or not self._needs_visual_hp():return
  self.network.confirm_own_hp(value.current,value.maximum,int((time.time()-time.monotonic()+captured)*1000))
 def _network_world_observation(self,frame):
  if self.mode=='RESCUE' and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE':
   return Observation(find_world_resource(frame,('Эфир',)),None,None,False,0,False,None,'HIDDEN')
  return super()._network_world_observation(frame)
 def _candidate_observed(self,candidate,captured,pose,baseline=None):
  now=time.monotonic()
  if self._caption_rejected(candidate):return
  rescue=self.mode=='RESCUE' and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE'
  if (candidate.name not in self.cfg['target_names'] or self.caption_latch is not None or self.mode not in ('SEARCH','ACQUIRE_WAIT') and not (rescue and candidate.name=='Эфир')
      or self.target_confirmed or self.resource_hold or self.click_busy or self.camera_in_progress
      or self.map_active or self.return_exit_guard or self.pitch.returning or self.pitch.failed or not self.cfg.get('allow_click',True)
      or now<self.caption_after or now<self.defense_evade_until
      or not self.policy.allows(candidate.name) or candidate.name=='Эфир' and not self.budget.can_start()
      or self.nav.is_retreating(now)
      or not self._focus_ok() or not 0<=now-captured<=1.5):return
  if any(n==candidate.name and until>now and abs(candidate.click_x-x)<80 and abs(candidate.click_y-y)<80 for n,x,y,until in self.cooldowns):return
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None or view['state'].attempt_active):return
  if now-captured>.8:
   current,_=self.screen.frame();fresh=find_resource_near(current,candidate)
   if fresh is None:return
   candidate=fresh;pose,baseline=self.pitch.capture(time.monotonic())
  self.caption_latch={'candidate':candidate,'pose':pose,'baseline':self.pitch.baseline_revision if baseline is None else baseline,'until':time.monotonic()+2.5,'restored':False,'settle':0}
  if candidate.name=='Эфир':
   self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
   self.wing_close_pending=None;self.wing_close_started=None;self.wing_close_retries=0
  self._neutral() # Stop as soon as recognition completes, not after the next full navigation tick.
  self.hybrid_camp_pending=False;self.camp_exit_until=0
  self.say(('ETHER_SIGHT' if candidate.name=='Эфир' else 'RESOURCE_SIGHT')+': '+candidate.name+' замечен; проверяю ромбик на свежем кадре без обязательного подхода вплотную')
 def _search_caption_priority(self,obs,now):
  # A fresh world caption over sky is actionable. A ground-view repair is
  # useful for walking, but must not turn away from a verified airborne node.
  return bool(self.caption_latch is not None and now<self.caption_latch['until']
              and obs.candidate is not None and self._allowed(obs.candidate,now))
 def _motion(self,plan):
  # A recognition callback can arrive after navigation has planned a turn.
  # Do not let that pending turn sweep a newly seen caption out of view.
  if getattr(self,'caption_latch',None) is not None and self.mode in ('SEARCH','ACQUIRE_WAIT'):
   self._neutral();return True
  result=super()._motion(plan)
  if (result and self.gamepad is not None and hasattr(self.gamepad,'tap_sprint')
      and math.hypot(plan.forward,plan.strafe)>=.65 and abs(plan.yaw)+abs(plan.pitch)<.001):
   self.gamepad.tap_sprint(self.stop_event,self.screen.focused,self._sprint_input_ready)
  return result
 def _sprint_input_ready(self):
  now=time.monotonic()
  if (not self.cfg.get('patrol_sprint',True) or not getattr(self.bridge,'controller_native',False)
      or self.mode!='SEARCH' or not self._focus_ok() or self.target_confirmed or self.resource_hold
      or self.collecting_visible or self.caption_latch is not None or self.click_busy or self.map_active
      or self.budget.airborne or self.return_exit_guard or self.hybrid_camp_pending or self.nav.air_since is not None
      or self.probe is not None or self.terrain_recovery is not None or self.patrol_escape is not None
      or self.network_defense is not None or self.defense_restore_view is not None
      or self.camera_in_progress or self.camera_alignment_due or self.pitch.returning
      or abs(self.pitch.offset(now))>.009 or now>=self.sprint_surface_until or self.nav.is_retreating(now)):
   return False
  if self.nav.goal is not None and self.nav.goal.distance<10*self.nav.last_scale:return False
  if self.network is not None:
   view=self._net_view()
   if not view or not view['ready'] or self._own_collection(view) is not None or view['state'].attempt_active:return False
  return self._translation_input_ready()
 def _terrain_recovery_tick(self,frame,reading,now,radar=None):
  if (self.caption_latch is not None and self.terrain_recovery is not None and self.terrain_recovery.phase=='CRUISE'
      and not self.target_confirmed and not self.resource_hold and self._own_collection() is None):
   self._neutral();self.terrain_recovery=None;self.pitch.resume_return(now);self.change_mode('SEARCH');self.nav.pause(now)
   self.rescue_air_search_until=max(self.rescue_air_search_until,now+5)
   self.say('ETHER_SIGHT: спасательный перелёт прерван свежей подписью; проверяю ресурс без закрытия крыльев')
   return False
  return super()._terrain_recovery_tick(frame,reading,now,radar)
 def _caption_frame(self,frame,obs,now):
  latch=self.caption_latch
  if latch is None:return obs,False
  if (self.target_confirmed or self.resource_hold or self.mode not in ('SEARCH','ACQUIRE_WAIT')
      or self.map_active or not self._focus_ok() or self._own_collection() is not None):
   self.caption_latch=None;return obs,False
  if now>=latch['until']:
   self.caption_latch=None;self.caption_after=now+1;self.nav.air_since=None;self.nav.scan_kind=None
   return obs,False
  if not latch['restored']:
   self._neutral();error=latch['pose']-self.pitch.offset(now) if latch.get('baseline',self.pitch.baseline_revision)==self.pitch.baseline_revision else 0;latch['restored']=True
   if abs(error)>.006:
    seconds=min(.12,abs(error)/.45)
    self.gamepad.drive(0,0,0,.45 if error>0 else -.45,lifetime=seconds)
    latch['settle']=now+seconds+.2
    return obs,True
  if now<latch['settle']:return obs,True
  fresh=find_resource_near(frame,latch['candidate'])
  if fresh is not None:return replace(obs,candidate=fresh),False
  self._neutral();return obs,True
 def _camp_update(self,frame,radar,now,visible=False):
  if not self.cfg.get('hybrid_camp_exit',True):return
  resource=visible or any(self.policy.allows('Эфир' if m.kind=='aether' else 'Самоцвет') for m in radar.markers)
  if resource:
   if self.hybrid_camp_pending:self.say('HYBRID_CAMP_EXIT: ресурс доступен; сохраняю его цель вместо обязательного выхода')
   self.hybrid_camp_pending=False;self.camp_exit_until=0
  if now-self.hybrid_camp_check>=.5:
   self.hybrid_camp_check=now;anchor=purple_anchor(frame,radar.bounds)
   if anchor is not None:
    self.camp_last_seen=now
    if now>=self.camp_exit_retry_after and self.camp_rearm and not resource:
     self.camp_exit_until=now+35;self.camp_exit_retry_after=now+65;self.camp_motion=0;self.hybrid_camp_pending=True;self.camp_rearm=False
     self.say('HYBRID_CAMP_EXIT: сначала наземный выход из области кибелиска, затем ресурсы')
   elif now-self.camp_last_seen>=3:self.camp_rearm=True
  if self.hybrid_camp_pending:
   if radar.motion_valid:self.camp_motion+=math.hypot(*radar.displacement)
   if now>=self.camp_exit_until or now-self.camp_last_seen>1.5 and self.camp_motion>8:
    expired=now>=self.camp_exit_until
    self.camp_exit_until=0;self.hybrid_camp_pending=False
    self.say('HYBRID_CAMP_EXIT: 35 с осмотра истекли; выход не подтверждён, продолжаю обычный поиск' if expired else 'HYBRID_CAMP_EXIT: удалился по миникарте; возвращаю поиск ресурсов')
 def step(self,frame,origin,obs,radar,reading,now,sequence=0):
  if self.stop_event.is_set():return
  searching=self.mode in ('SEARCH','ACQUIRE_WAIT') and not self.resource_hold and not self.target_confirmed and not self.map_active and self._focus_ok()
  self.policy.observe_map(radar.markers,now,searching)
  prefer_air=self.policy.priority and self.policy.air_on_map and self.policy.allows('Эфир')
  if searching and prefer_air and not self.click_busy:
   radar=replace(radar,markers=[m for m in radar.markers if m.kind=='aether'])
   if self.nav.goal is not None and self.nav.goal.kind!='aether':self.nav.goal=None;self.nav.best_distance=None
   if self.caption_latch is not None and self.caption_latch['candidate'].name!='Эфир':self.caption_latch=None
   if self.mode=='ACQUIRE_WAIT' and self.candidate is not None and self.candidate.name!='Эфир':
    self.candidate=None;self.change_mode('SEARCH')
  goal=self.nav.goal
  looking=self.nav.air_since is not None
  near_goal=(goal is not None and goal.kind=='aether' and goal.distance<60*self.nav.last_scale)
  if (self.cfg.get('scan_frame_checks',True) and self.mode=='SEARCH' and (looking or near_goal)
      and self.caption_latch is None and not self.target_confirmed and not self.resource_hold
      and not self.map_active and self._focus_ok() and now>=self.fast_sight_after
      and now>=self.nav.scan_pulse_end and now>=self.caption_after and not self.pitch.returning
      and not self.camera_in_progress and not self.return_exit_guard and not self.nav.is_retreating(now)):
   # This frame was captured after the last pulse expired. Inspect it before
   # Navigator can send the next pulse, especially before the down bracket.
   self.fast_sight_after=now+(.18 if looking else .65)
   h,w=frame.shape[:2];pose,baseline=self.pitch.capture(time.monotonic())
   candidates=fast_ether_candidates(frame,('Эфир',),deadline=time.monotonic()+.20,
                                   bounds=(round(w*.02),round(h*.02),round(w*.98),round(h*.55)),rejected=self._caption_rejected)
   if candidates:
    self._candidate_observed(candidates[0],now,pose,baseline)
    if self.caption_latch is not None:obs=replace(obs,candidate=candidates[0])
   self.scan_checked_pulse=(self.nav.air_since,self.nav.scan_last_pulse)
  if self.caption_latch is not None:
   obs,waiting=self._caption_frame(frame,obs,now)
   if waiting:return
  if self.mode=='SEARCH' and not self.target_confirmed and not self.resource_hold and not reading.confirmed and not self.map_active:
   self._camp_update(frame,radar,now,obs.candidate is not None and self._allowed(obs.candidate,now))
   # Actual minimap progress owns its timer. A succession of visual detours
   # must not erase the fact that the destination never gets any closer.
  return super().step(frame,origin,obs,radar,reading,now,sequence)
 def _scene_plan(self,frame,radar,reading,plan,now):
  if (self.scene_host is None or self.cfg.get('dry_run') or self.mode!='SEARCH' or self.target_confirmed
      or self.resource_hold or self.collecting_visible or self.map_active or reading.confirmed or self.budget.airborne
      or self.camera_alignment_due or self.pitch.returning or abs(self.pitch.offset(now))>.015
      or not self._focus_ok() or abs(plan.pitch)>.001 or plan.restore_pitch or plan.flight_probe
      or math.hypot(plan.forward,plan.strafe)<.05):return plan
  if gathering_panel_pair(frame):return plan
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None):return plan
  heading=radar.heading if radar.confidence>=.30 else None;pitch=self.pitch.offset(now)
  captured=time.monotonic()
  self.scene_host.offer(frame,captured,heading,pitch,self.scene_camera_epoch)
  result=self.scene_host.current(captured,heading,pitch,self.scene_camera_epoch)
  exit_mode=now<self.camp_exit_until
  if exit_mode:plan=Drive(.6,reason='ищу наземный выход из области кибелиска')
  goal=self.nav.goal
  goal_bearing=math.degrees(math.atan2(goal.x-radar.center[0],radar.center[1]-goal.y))%360 if goal else None
  context={'mode':'camp_exit' if exit_mode else 'resources','kind':goal.kind if goal else None,
           'goal_bearing':round(goal_bearing) if goal_bearing is not None else None,
           'goal_relative':round((goal_bearing-heading+180)%360-180) if goal_bearing is not None and heading is not None else None,
           'failed_bearings':[round(b) for b,t in self.hybrid.avoid if now<t]}
  hint=None;warning=None
  if result is not None and result.ground is not None:
   relative=math.degrees(math.atan2(plan.strafe,plan.forward));lane=result.lanes[0 if relative< -18 else 2 if relative>18 else 1]
   wide=(not exit_mode and abs(relative)<60 and result.ground.drop_support<.04 and lane.free>=.70 and lane.solid<.15 and lane.edge<.012
         and any(r.confidence>=.60 and r.clearance>=1 for r in result.ground.routes))
   self.sprint_surface_until=min(captured+.4,result.captured+.9) if wide else 0
  if self.analyzer is not None and result is not None and result.ground is not None:
   relative=math.degrees(math.atan2(plan.strafe,plan.forward))
   lane=result.lanes[0 if relative< -18 else 2 if relative>18 else 1]
   clear=(abs(relative)<=80 and result.ground.drop_support<.04 and lane.free>=.55 and lane.solid<.18 and lane.edge<.02
          and any(r.confidence>=.60 for r in result.ground.routes))
   if exit_mode or not clear or self.hybrid.blocked_at is not None or self.hybrid.commit is not None and now<self.hybrid.commit_until:
    self.analyzer.offer(result.source if result.source is not None else frame,result.ground,result.captured,result.heading,result.pitch,context)
   hint=self.analyzer.recommend(result.ground,frame,captured,heading,pitch,context)
   warning=self.analyzer.warning(captured,heading,pitch,context)
  face_goal=bool(goal is not None and goal.kind=='aether' and not self.nav.is_retreating(now) and now>=self.nav.escape_until)
  action=self.hybrid.choose(plan,result,radar,now,hint,exit_mode,warning,face_goal=face_goal)
  if action.recalibrate:
   if now>=self.scene_view_retry_after:
    self.scene_view_retry_after=now+3;self.scene_view_repair=True;self.nav.air_since=None;self.nav.scan_kind=None;self.view_guard.force(now)
   return Drive()
  if action.skip:
   self.nav.exclude_goal(now,25);self.nav.air_since=None;self.nav.scan_kind=None
   self.say('HYBRID_REPLAN: недоступная цель отложена; выбираю другой ресурс/наземный выход')
  if now-self.hybrid_note>=1.5:
   self.hybrid_note=now
   state='нет' if self.analyzer is None else 'занят' if self.analyzer.busy else 'ошибка' if self.analyzer.error else 'готов' if self.analyzer.ready else 'ожидание'
   self.say('HYBRID_NAV: '+action.reason+'; Qwen='+state+'; локальному кадру '+(str(round(captured-result.captured,2))+' с' if result else 'нет данных'))
  return action.drive
