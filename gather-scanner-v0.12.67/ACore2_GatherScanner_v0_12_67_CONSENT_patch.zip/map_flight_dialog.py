"""Exact flight-only consent. This never authorizes F for loot or resources."""
from dataclasses import dataclass
import cv2,numpy as np
from map_teleport import lines,canonical

QUESTION=canonical('Невозможно переместиться по земле. Переместиться с помощью полета?')

@dataclass(frozen=True)
class FlightDialog:
 accept:tuple
 cancel:tuple
 signature:object

def stamp(frame):
 # Verify the question body; gold-button hover animation is not a new dialog.
 h,w=frame.shape[:2];crop=frame[round(h*.43):round(h*.54),round(w*.35):round(w*.65)]
 return cv2.resize(cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY),(180,90))

def same(frame,signature):
 if signature is None:return False
 value=stamp(frame)
 return value.shape==signature.shape and float(np.mean(abs(value.astype(float)-signature)))<3

def flight_hint(frame):
 h,w=frame.shape[:2];crop=frame[round(h*.57):round(h*.62),round(w*.51):round(w*.63)]
 if not crop.size:return False
 gold=cv2.inRange(cv2.cvtColor(crop,cv2.COLOR_BGR2HSV),(12,100,140),(40,255,255))
 return np.mean(gold>0)>=.15

def flight_dialog(frame):
 if not flight_hint(frame):return None
 title=lines(frame,(.30,.39,.72,.52),140)
 if canonical(' '.join(x.text for x in title))!=QUESTION:return None
 cancel=next((x for x in lines(frame,(.36,.55,.50,.64),140) if canonical(x.text)=='отмена'),None)
 accept=next((x for x in lines(frame,(.50,.55,.65,.64),140,hide_gold=True) if canonical(x.text).endswith('ок') and len(canonical(x.text))<=4),None)
 if cancel is None or accept is None:return None
 h,w=frame.shape[:2];crop=frame[round(h*.57):round(h*.62),round(w*.51):round(w*.63)]
 gold=cv2.inRange(cv2.cvtColor(crop,cv2.COLOR_BGR2HSV),(12,100,140),(40,255,255))
 if np.mean(gold>0)<.15:return None
 return FlightDialog(accept.point,cancel.point,stamp(frame))

@dataclass
class ConsentWindow:
 dialog:object
 route:object
 context:object
 frame_shape:tuple
 mode:str
 binding:object
 since:float
 action:str
 reason:str
 attempts:int=0
 last_sent:float=-1e9
 last_action:str|None=None
 absent_since:float|None=None

class FlightConsent:
 """One verified modal owns input until it has visibly disappeared."""
 def __init__(self,emit):
  self.emit=emit;self.window=None;self.finished=None;self.last_cancel=None;self.own_start_seen=None
  self.check_after=0.
 @property
 def blocking(self):return self.window is not None
 def context(self,e):
  view=e._net_view()
  return (view['flow'],view['state'].own,view['state'].map_id) if view and view['ready'] else None
 def reset_retry(self):self.last_cancel=None
 def choose(self,e,now):
  view=e._net_view();owned=e._own_collection(view)
  context=self.context(e)
  if self.last_cancel is not None:
   previous,stamp=self.last_cancel
   if context==previous and 0<=now-stamp<=90:return 'repeat','повторный вопрос после отказа: разрешаю полёт независимо от энергии'
   self.last_cancel=None
  if owned is not None and view['state'].attempt_active:return 'cancel','собственный сбор ещё активен'
  if e.budget.can_probe(18):return 'accept','обычная проверка энергии пройдена'
  return 'cancel','мало энергии'
 def tick(self,e,frame,now,route,parse,looks,same_dialog):
  if self.window is None:
   view=e._net_view()
   owned=e._own_collection(view)
   if owned is not None and view['state'].attempt_active:
    proof=(view['flow'],view['state'].own,owned.actor,owned.generation,owned.gather_time)
    if proof!=self.own_start_seen:self.own_start_seen=proof;self.reset_retry()
   if now<self.check_after or not looks(frame):return False
   self.check_after=now+.2;dialog=parse(frame)
   if dialog is None:return False
   action,reason=self.choose(e,now)
   self.window=ConsentWindow(dialog,route,self.context(e),tuple(frame.shape),e.mode,e.network_target,now,action,reason)
   e.caption_latch=None
   self.emit('FLIGHT_MODAL: точный вопрос о полёте; режим='+e.mode+'; ответ='+action+'; '+reason+'; фоновые клики заблокированы')
  window=self.window;e._neutral()
  release=getattr(e,'_release_collection_cursor',None)
  if callable(release):release()
  present=same_dialog(frame,window.dialog.signature)
  hint=looks(frame)
  if (present or hint) and tuple(frame.shape)!=window.frame_shape:
   if now>=self.check_after:
    self.check_after=now+.2;current=parse(frame)
    if current is not None:window.dialog=current;window.frame_shape=tuple(frame.shape)
   return True
  if not present and hint:
   # OCR can flicker while the verified modal still covers the game. It is
   # never treated as an absent window merely because one text read failed.
   if now>=self.check_after:
    self.check_after=now+.2;current=parse(frame)
    if current is not None:window.dialog=current;present=True
   window.absent_since=None;return True
  if not present and not hint:
   if window.absent_since is None:window.absent_since=now
   if now-window.absent_since>=.35:
    self.finished=window;self.window=None
    self.emit('FLIGHT_MODAL_CLOSED: исчезновение окна подтверждено; ответ='+window.action)
   return True
  window.absent_since=None
  if e.stop_event.is_set() or not e._focus_ok() or e.cfg.get('dry_run'):return True
  if now-window.last_sent<(3 if window.attempts>=2 else 1):return True
  if self.context(e)!=window.context or window.attempts>=2 or now-window.since>=4:
   window.action='cancel';window.reason='окно осталось или изменился игровой контекст: закрываю Отменой'
  # A new own start makes accepting a different native route inappropriate,
  # but must not prevent cancelling the modal itself.
  view=e._net_view();owned=e._own_collection(view)
  if owned is not None and view['state'].attempt_active and window.action!='repeat':window.action='cancel'
  fresh,origin=e.screen.frame()
  if tuple(fresh.shape)!=window.frame_shape or not same_dialog(fresh,window.dialog.signature):return True
  shape=fresh.shape;point=window.dialog.cancel if window.action=='cancel' else window.dialog.accept
  e.bridge.cursor(origin[0]+point[0],origin[1]+point[1])
  from gamepad_input import GamepadInput
  if not GamepadInput.wait(.12,e.stop_event,e.screen.focused):return True
  def authorize():
   if self.window is not window or e.stop_event.is_set() or not e._focus_ok() or not e.bridge.cursor_matches():return False
   current,current_origin=e.screen.frame()
   return current_origin==origin and current.shape==shape and same_dialog(current,window.dialog.signature)
  sent=e.gamepad.tap_ui_a(e.stop_event,e.screen.focused,authorize)
  if sent:
   import time
   stamp=time.monotonic();window.attempts+=1;window.last_sent=stamp;window.last_action=window.action
   if window.action=='cancel' and window.attempts==1:self.last_cancel=(window.context,stamp)
   self.emit('FLIGHT_MODAL_PRESS: '+('Отмена' if window.action=='cancel' else 'ОК')+'; UI-A передана, попытка='+str(window.attempts)+'; '+window.reason)
  return True
 def resume_resource(self,e,window,now):
  # Menus consume no native-approach/reselection time. Do not reset private
  # collection identity, used attempts or completion permissions.
  if window.binding!=e.network_target or window.mode!=e.mode or window.context!=self.context(e):return
  gap=max(0,now-window.since)
  for name in ('reacquire_until','interrupted_reacquire_until','native_route_started_at','route_click_sent_at'):
   value=getattr(e,name,None)
   if value is not None:setattr(e,name,value+gap)
  pending=getattr(e,'emblem_acquisition',None)
  if pending is not None:pending['until']+=gap;pending['clicked']+=gap
  recovery=getattr(e,'view_recovery',None)
  if recovery is not None:recovery.until+=gap;recovery.next_at+=gap
  e.last_progress=now;e.identity_valid_after=now
