"""No whole-screen recognition on the input thread during own collection."""
import os,threading,time,unittest
from unittest.mock import patch
import numpy as np
import cv2
import vision
import gather_engine as ge
from test_navigation import GatherFixture
from test_network_control import Source
from test_ether_emblem import scene,ether

class BoundedCollection(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(resource_click_interaction=True,collection_cursor_hold=True)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.nodes[99].template=1500000;self.f.nodes[99].gather_time=1000
        self.f.collecting=99;self.f.attempt_active=False;self.f.nodes[99].used=2
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode='GATHER';self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
        self.frame=scene();self.e.candidate=ether(self.frame)
        self.clock=100.;self.wall=1100;self.clicks=[]
        self.e.current_size=(self.frame.shape[1],self.frame.shape[0])
        self.alt_held=True;self.e.collection_cursor_owned=True
        def wait(seconds,*args):self.clock+=seconds;return True
        def click(*args,**kwargs):self.clicks.append(self.positions[-1]);return True
        self.input.tap_a=click
        for q in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),patch.object(ge.GamepadInput,'wait',side_effect=wait)):
            q.start();self.addCleanup(q.stop)

    def erase_letters(self):
        x,y,w,h=self.e.candidate.box;self.frame[y-2:y+h+2,x-3:x+w+3]=35

    def test_third_attempt_uses_own_badge_without_ocr_or_whole_scene_search(self):
        self.erase_letters()
        with patch.object(ge,'find_world_resource',side_effect=AssertionError('whole scene')),patch.object(vision,'fast_ether_candidates',side_effect=AssertionError('whole scene')),patch.object(ge,'find_resource_near',side_effect=AssertionError('glyph')):
            self.e.f_enable()
        self.assertEqual(len(self.clicks),1);self.assertEqual(self.e.next_attempt_sent_used,2)
        self.assertEqual(self.commands,[]);self.assertEqual(self.e.mode,'GATHER')

    def test_caption_cannot_be_replaced_by_badge_without_an_own_collection(self):
        self.erase_letters();self.f.collecting=None;self.f.nodes[99].gather_time=None
        self.assertIsNone(self.e._fresh_click_candidate(self.frame))

    def test_absent_badge_and_letters_cannot_authorize_a_stale_click(self):
        self.frame[:]=35;self.e.f_enable();self.assertEqual(self.clicks,[])
        self.assertTrue(any('CLICK_WAIT' in line for line in self.log))

    def test_main_thread_never_falls_back_to_whole_frame_after_caption_moved(self):
        self.frame=scene(y=500);self.e.snapshot=None
        with patch.object(ge,'find_world_resource',side_effect=AssertionError('blocked global OCR')):
            self.e.f_enable()
        self.assertEqual(self.clicks,[]);self.assertFalse(self.e.stop_event.is_set())

    def test_blocked_background_scan_does_not_block_third_attempt(self):
        entered=threading.Event();release=threading.Event();errors=[]
        blank=np.full_like(self.frame,35)
        def blocked(*args,**kwargs):
            entered.set()
            if not release.wait(3):raise AssertionError('worker was never released')
            return None
        def worker():
            try:self.e._network_world_observation(blank)
            except BaseException as exc:errors.append(exc)
        with patch.object(ge,'find_world_resource',side_effect=blocked):
            thread=threading.Thread(target=worker);thread.start()
            try:
                self.assertTrue(entered.wait(2));self.e.f_enable()
                self.assertEqual(len(self.clicks),1);self.assertTrue(thread.is_alive())
            finally:release.set();thread.join(2)
        self.assertEqual(errors,[])

    def test_active_attempt_does_no_world_recognition(self):
        self.f.attempt_active=True
        with patch.object(ge,'find_world_resource',side_effect=AssertionError('global')),patch.object(ge,'find_resource_near',side_effect=AssertionError('local')):
            obs=self.e._network_world_observation(self.frame)
        self.assertIsNone(obs.candidate);self.assertEqual(obs.target_name,'Эфир')

    def test_active_worker_skips_even_screen_capture(self):
        self.f.attempt_active=True
        with patch.object(self.e.screen,'frame',side_effect=AssertionError('screen capture')),patch.object(self.e.stop_event,'wait',return_value=True):
            self.e._vision_loop()

    def test_search_worker_does_not_run_prompt_flight_or_lower_panel_scan(self):
        self.e.target_confirmed=False;self.e.mode='SEARCH'
        c=self.e.candidate
        with patch.object(self.e.vision,'scan',side_effect=AssertionError('legacy scan')),patch.object(ge,'find_world_resource',return_value=c):
            obs=self.e._network_world_observation(self.frame)
        self.assertIs(obs.candidate,c);self.assertFalse(obs.f_prompt);self.assertFalse(obs.gathering)

    def test_inactive_worker_prefers_local_point_to_global_search(self):
        with patch.object(ge,'find_world_resource',side_effect=AssertionError('global')):
            obs=self.e._network_world_observation(self.frame)
        self.assertIsNotNone(obs.candidate);self.assertIsNotNone(obs.candidate.emblem)

    def test_unknown_own_name_does_not_idle_the_header_name_reader(self):
        self.f.attempt_active=True;self.e.target=ge.OWN_RESOURCE
        self.assertFalse(self.e._collection_vision_idle())

    def test_unconfirmed_network_does_not_grant_badge_only_click(self):
        self.erase_letters();self.source.ready=False;self.e.f_enable()
        self.assertEqual(self.clicks,[])

    def test_completion_still_prevents_third_attempt_when_final_result_arrives(self):
        self.f.nodes[99].used=3;self.f.collecting=None
        self.e.f_enable();self.assertEqual(self.clicks,[])

    def test_own_start_before_badge_press_cancels_extra_click(self):
        cursor=self.e.bridge.cursor
        def move(x,y):cursor(x,y);self.f.attempt_active=True
        self.e.bridge.cursor=move;self.e.f_enable();self.assertEqual(self.clicks,[])

    def test_no_press_is_not_reported_as_a_sent_next_attempt(self):
        cursor=self.e.bridge.cursor
        def move(x,y):cursor(x,y);self.frame[:]=35
        self.e.bridge.cursor=move;self.e.f_enable()
        self.assertEqual(self.clicks,[]);self.assertIsNone(self.e.next_attempt_sent_used)
        self.assertEqual(self.e.next_attempt_click_tries,0)

    def test_network_diagnostics_explain_absent_own_coordinates(self):
        self.e._network_guard(self.clock)
        self.assertTrue(any('Сеть XYZ:' in line and 'живых ресурсов 0' in line and 'не получена' in line for line in self.log))

    def test_network_diagnostics_count_only_live_nonempty_nodes(self):
        self.f.nodes[99].xyz=(100.,200.,300.)
        self.e._network_guard(self.clock)
        self.assertTrue(any('живых ресурсов 1' in line for line in self.log))
        self.f.nodes[99].used=3;self.e._network_guard(self.clock+11)
        self.assertTrue(any('живых ресурсов 0' in line for line in self.log))

    def test_stale_position_is_not_reported_as_exact_navigation(self):
        self.f.xyz=(100.,200.,300.);self.f.position_at=-900;self.f.position_source='self-profile'
        self.e._network_guard(self.clock)
        self.assertTrue(any('точное наведение недоступно' in line for line in self.log))


class VisionWorkBudget(unittest.TestCase):
    def test_opencv_has_one_native_thread(self):
        self.assertEqual(cv2.getNumThreads(),1)

    def test_tesseract_has_a_default_single_thread_limit(self):
        self.assertTrue(os.environ.get('OMP_THREAD_LIMIT'))

    def test_expired_ether_budget_stops_before_segmentation(self):
        f=np.full((720,1280,3),35,np.uint8)
        with patch.object(vision,'color_mask',side_effect=AssertionError('segmentation')):
            self.assertEqual(vision.fast_ether_candidates(f,deadline=-1),[])

    def test_shape_work_is_capped_for_many_plausible_regions(self):
        f=np.full((720,1280,3),35,np.uint8)
        mask=np.zeros((547,1229),np.uint8)
        # Synthetic connected-component metadata, each valid word-sized region.
        stats=np.array([[0,0,1229,547,672263]]+[[20,30,45,15,300]]*400,np.int32)
        with patch.object(vision.cv2,'connectedComponentsWithStats',return_value=(401,None,stats,None)),patch.object(vision,'color_mask',return_value=np.full_like(mask,255)),patch.object(vision,'relaxed_caption_mask',return_value=np.full_like(mask,255)):
            # The density check must pass, so provide a striped 40% glyph sample.
            mask[:]=0;mask[:,::3]=255
            with patch.object(vision,'color_mask',return_value=mask),patch.object(vision,'relaxed_caption_mask',return_value=mask),patch.object(vision,'visual_name',return_value=(None,0)) as name:
                vision.fast_ether_candidates(f,deadline=float('inf'))
        self.assertLessEqual(name.call_count,96);self.assertGreater(name.call_count,0)


if __name__=='__main__':unittest.main()
