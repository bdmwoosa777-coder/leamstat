"""Synthetic tests; none of the user's traffic/logs are shipped as fixtures."""
import json,struct,sys,tempfile,time,unittest
from pathlib import Path
from unittest.mock import patch
from network_feed import NetworkFeed
from network_state import Telemetry,Node
from test_network_state import v,profile,gauge
from test_network_control import Source
from test_navigation import GatherFixture

def mini(actor=99,ordinal=1):return bytes(2)+v(actor)+struct.pack('<I',ordinal)+bytes(25)

class IdentityBootstrap(unittest.TestCase):
 def setUp(self):
  self.t=Telemetry({1550020});self.t.feed(1,'3436',profile(),1)
  self.t.feed(1,'3438',bytes(3)+v(99),10)
 def feed(self,op,body,t):return self.t.feed(1,op,body,t)
 def test_private_minigame_and_unique_interaction_identify_self_without_initial_profile(self):
  self.feed('3836',v(99)+v(7)+b'\1',20)
  self.assertIsNone(self.t.flows[1].own)
  self.feed('318d',mini(),25)
  f=self.t.flows[1]
  self.assertEqual((f.own,f.collecting,f.nodes[99].gather_time),(7,99,25))
  self.assertEqual(f.identity_source,'own-gather-dialog');self.assertTrue(f.attempt_active)
  self.assertIsNone(f.maximum);self.assertIsNone(f.flight_maximum)
 def test_private_minigame_may_arrive_before_broadcast_start(self):
  self.feed('318d',mini(),20);self.feed('3836',v(99)+v(7)+b'\1',20)
  self.assertEqual(self.t.flows[1].own,7)
 def test_broadcast_neighbour_start_alone_never_identifies_us(self):
  self.feed('3836',v(99)+v(8)+b'\1',20)
  self.assertIsNone(self.t.flows[1].own);self.assertIsNone(self.t.flows[1].collecting)
 def test_private_minigame_without_source_never_guesses_self(self):
  self.feed('318d',mini(),20);self.assertIsNone(self.t.flows[1].own)
 def test_ambiguous_neighbour_sources_cannot_bind_identity(self):
  self.feed('3836',v(99)+v(7)+b'\1',20);self.feed('3836',v(99)+v(8)+b'\1',25)
  self.feed('318d',mini(),30);self.assertIsNone(self.t.flows[1].own)
 def test_mob_cannot_be_bound_as_the_player(self):
  self.t.flows[1].npcs[7]={'template':123}
  self.feed('3836',v(99)+v(7)+b'\1',20);self.feed('318d',mini(),25)
  self.assertIsNone(self.t.flows[1].own)
 def test_source_and_private_minigame_for_another_node_cannot_mix(self):
  self.feed('3836',v(98)+v(7)+b'\1',20);self.feed('318d',mini(),25)
  self.assertIsNone(self.t.flows[1].own)
 def test_old_interaction_cannot_bind_a_later_attempt(self):
  self.feed('3836',v(99)+v(7)+b'\1',20);self.feed('318d',mini(),2000)
  self.assertIsNone(self.t.flows[1].own)
 def test_new_selection_clears_old_identity_candidates(self):
  self.feed('3836',v(99)+v(7)+b'\1',20)
  self.feed('3438',bytes(3)+v(98),25);self.feed('3438',bytes(3)+v(99),30)
  self.feed('318d',mini(),35);self.assertIsNone(self.t.flows[1].own)
 def test_known_identity_ignores_other_players_even_with_private_packet(self):
  self.feed('008d',gauge(),15);self.feed('3836',v(99)+v(8)+b'\1',20)
  self.feed('318d',mini(),25);self.assertEqual(self.t.flows[1].own,7)
  self.assertIsNone(self.t.flows[1].collecting)

class InternalFeed(unittest.TestCase):
 def test_closed_feed_never_keeps_a_fresh_permission(self):
  f=NetworkFeed();f.ingest(dict(type='frame',flow=1,t=1000,op='0036',hex='00'*8))
  self.assertTrue(f.view(1050)['ready']);f.close()
  self.assertFalse(f.view(1050)['ready']);self.assertIn('остановлен',f.view(1050)['reason'])
 def test_heartbeat_keeps_search_alive_without_any_self_stats(self):
  f=NetworkFeed();f.ingest(dict(type='frame',flow=1,t=1000,op='0036',hex='00'*8))
  view=f.view(1050);self.assertTrue(view['ready']);self.assertFalse(view['identity_ready'])
  self.assertIn('поиск разрешён',view['reason'])
 def test_two_current_game_flows_pause_instead_of_selecting_randomly(self):
  f=NetworkFeed()
  for flow in (1,2):f.ingest(dict(type='frame',flow=flow,t=1000,op='0036',hex='00'*8))
  self.assertFalse(f.view(1100)['ready']);self.assertIn('несколько',f.view(1100)['reason'])
 def test_error_blocks_even_fresh_frames(self):
  f=NetworkFeed();f.ingest(dict(type='frame',flow=1,t=1000,op='0036',hex='00'*8));f.error='Npcap read failed'
  self.assertFalse(f.view(1100)['ready'])
 def test_malformed_or_wrong_version_module_reports_error(self):
  with tempfile.TemporaryDirectory() as directory:
   f=NetworkFeed(command=[sys.executable,'-u','-c','print(\'{"type":"hello","protocol":2}\')'])
   f.directory=Path(directory);f.start();f.worker.join(3)
   try:self.assertIn('Несовместимая',f.error)
   finally:f.close()
 def test_missing_npcap_error_is_visible_in_main_log_and_summary(self):
  with tempfile.TemporaryDirectory() as directory:
   logs=[]
   script='print(\'{"type":"hello","protocol":1}\');print(\'{"type":"error","message":"Npcap is not installed"}\')'
   f=NetworkFeed(logger=logs.append,command=[sys.executable,'-u','-c',script]);f.directory=Path(directory)
   f.start();f.worker.join(3)
   try:
    self.assertIn('Npcap',f.describe());self.assertTrue(any('Npcap' in x for x in logs))
    self.assertTrue((Path(directory)/'status.json').is_file())
   finally:f.close()

class BootstrapControls(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp()
  self.source=Source();self.e.network=self.source
  self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='APPROACH'
  self.e._reset_resource_watch(True);self.e.network_target=(1,99);self.e.network_claimed_at=900
 def test_connected_but_unidentified_player_does_not_block_search(self):
  self.source.state.own=None;self.e.network_target=None;self.e.target_confirmed=False
  self.assertFalse(self.e._network_guard(100));self.assertFalse(self.e.stop_event.is_set())
 def test_unidentified_start_keeps_exactly_one_f_until_own_dialog(self):
  self.source.state.own=None;self.source.state.collecting=None;self.source.state.attempt_active=False
  self.source.state.nodes[99].gather_time=None
  self.e._start_resource_route();self.e._start_resource_route()
  self.assertEqual(self.commands,['TAP_F'])
  self.source.state.own=7;self.source.state.collecting=99;self.source.state.attempt_active=True
  self.source.state.nodes[99].gather_time=1000
  self.e._net_resource(self.frame,__import__('flight').FlightReading(None,False),100)
  self.assertEqual(self.e.mode,'GATHER');self.assertTrue(self.e.real_gather_panel_seen)
 def test_identity_is_pinned_after_bootstrap_and_a_later_change_stops_input(self):
  self.e.network_owner=None;self.source.state.own=7
  self.assertFalse(self.e._network_guard(100));self.assertEqual(self.e.network_owner,7)
  self.source.state.own=8;self.assertTrue(self.e._network_guard(101));self.assertTrue(self.e.stop_event.is_set())

if __name__=='__main__':unittest.main()
