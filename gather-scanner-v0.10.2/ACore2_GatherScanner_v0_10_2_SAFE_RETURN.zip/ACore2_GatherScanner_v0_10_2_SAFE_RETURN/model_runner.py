"""Local, pinned ONNX inference. No model hub, HTTP or executable model code."""
from pathlib import Path
import hashlib,json,time
import cv2
import numpy as np

ROOT=Path(__file__).resolve().parent


class SegmentationRunner:
    def __init__(self,device_id=0,cpu=False,log=lambda message:None):
        import onnxruntime as ort
        ort.disable_telemetry_events()
        self.manifest=json.loads((ROOT/'models/model.json').read_text(encoding='utf-8'))
        path=ROOT/'models'/self.manifest['file']
        if hashlib.sha256(path.read_bytes()).hexdigest()!=self.manifest['sha256']:
            raise RuntimeError('Файл модели повреждён. Распакуйте архив заново.')
        options=ort.SessionOptions();options.intra_op_num_threads=2;options.inter_op_num_threads=1
        options.enable_mem_pattern=False;options.execution_mode=ort.ExecutionMode.ORT_SEQUENTIAL
        providers=['CPUExecutionProvider']
        if not cpu and 'DmlExecutionProvider' in ort.get_available_providers():
            providers=[('DmlExecutionProvider',{'device_id':int(device_id)}),'CPUExecutionProvider']
        elif not cpu:log('DirectML недоступен: выбран CPU. Скорость будет ниже.')
        self.session=ort.InferenceSession(str(path),sess_options=options,providers=providers)
        self.backend=self.session.get_providers()[0]
        self.mean=np.array(self.manifest['mean'],np.float32).reshape(1,1,3)
        self.std=np.array(self.manifest['std'],np.float32).reshape(1,1,3)
        self.id2label=self.manifest['id2label'];self.size=int(self.manifest['size'])
        log(f'Модель готова: {self.backend}, адаптер {device_id}; кадры обрабатываются локально')

    def predict(self,frame):
        if frame is None or frame.ndim!=3 or frame.shape[2]!=3:raise ValueError('Expected a BGR image')
        began=time.perf_counter()
        rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
        rgb=cv2.resize(rgb,(self.size,self.size),interpolation=cv2.INTER_LINEAR).astype(np.float32)/255
        tensor=np.ascontiguousarray(((rgb-self.mean)/self.std).transpose(2,0,1)[None])
        logits=self.session.run(['logits'],{'pixel_values':tensor})[0][0]
        if logits.shape[0]!=len(self.id2label) or not np.isfinite(logits).all():raise RuntimeError('Invalid model output')
        # Normalize at native output resolution; do not allocate 150 full-HD
        # probability planes on the game PC just to draw the preview.
        probabilities=np.exp(logits-logits.max(axis=0,keepdims=True))
        probabilities/=probabilities.sum(axis=0,keepdims=True)
        labels=probabilities.argmax(axis=0).astype(np.uint8)
        confidence=probabilities.max(axis=0)
        h,w=frame.shape[:2]
        labels=cv2.resize(labels,(w,h),interpolation=cv2.INTER_NEAREST)
        confidence=cv2.resize(confidence,(w,h),interpolation=cv2.INTER_LINEAR)
        return labels,confidence,(time.perf_counter()-began)*1000
