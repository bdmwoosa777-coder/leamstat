"""Replay terrain paths and delayed input ticks, independent of game timing."""
import math
import time
import unittest
from unittest.mock import patch
from gamepad_input import GamepadInput
from minimap import Marker
from navigation import Navigator,Drive
from test_navigation import Pad,GatherFixture,obs
from test_exploration import radar
import gather_engine as ge


def circle_samples(nav,duration=16,walking=True,valid=True):
    triggered=[];previous=(18.,0.)
    for i in range(int(duration*10)+1):
        now=i*.1;angle=2*math.pi*now/12
        current=(18*math.cos(angle),18*math.sin(angle))
        flow=(current[0]-previous[0],current[1]-previous[1]);previous=current
        if nav.track_walk(radar(flow=flow,valid=valid),walking,now):triggered.append(now)
    return triggered


class PathReplayTests(unittest.TestCase):
    def test_moving_circle_triggers_one_straight_departure(self):
        nav=Navigator({});triggered=circle_samples(nav)
        self.assertEqual(len(triggered),1);self.assertGreaterEqual(triggered[0],12)
        for now in (16,18,22):
            plan=nav.update(radar(heading=(now*37)%360),now)
            self.assertGreater(plan.forward,.7)
            self.assertEqual((plan.strafe,plan.yaw,plan.pitch),(0,0,0))

    def test_loop_departure_cancels_an_old_retreat_turn(self):
        nav=Navigator({});nav.retreat_until=50;nav.retreat_bearing=270
        self.assertEqual(len(circle_samples(nav)),1)
        plan=nav.update(radar(heading=0),16)
        self.assertEqual(plan.yaw,0);self.assertGreater(plan.forward,.7)

    def test_actual_straight_translation_does_not_trigger(self):
        nav=Navigator({})
        for i in range(601):
            self.assertFalse(nav.track_walk(radar(flow=(-.8,0),valid=True),True,i*.1))

    def test_still_terrain_is_not_a_circle(self):
        nav=Navigator({})
        for i in range(401):
            self.assertFalse(nav.track_walk(radar(flow=(0,0),valid=True),True,i*.1))
        self.assertEqual(nav.escape_until,0)

    def test_unknown_motion_and_scan_without_walking_cannot_trigger(self):
        self.assertEqual(circle_samples(Navigator({}),valid=False),[])
        self.assertEqual(circle_samples(Navigator({}),walking=False),[])

    def test_camera_processing_gap_does_not_join_unrelated_paths(self):
        nav=Navigator({});self.assertEqual(circle_samples(nav,6),[])
        self.assertFalse(nav.track_walk(radar(flow=(0,0),valid=True),True,30))
        self.assertEqual(len(nav.trail),0)

    def test_circle_excludes_hint_and_overrides_route_turns_temporarily(self):
        nav=Navigator({});node=Marker('Самоцвет',150,100,.9,50)
        nav.update(radar([node]),0);nav.route(270)
        self.assertEqual(len(circle_samples(nav)),1)
        plan=nav.update(radar([node],heading=0),16)
        self.assertIsNone(nav.goal);self.assertGreater(plan.forward,.7);self.assertEqual(plan.yaw,0)
        # Ordinary route following resumes when the bounded departure ends.
        plan=nav.update(radar([],heading=0),30)
        self.assertLess(plan.strafe,-.7)

    def test_stationary_patrol_does_not_chain_four_second_retreats(self):
        nav=Navigator({})
        for i in range(121):
            plan=nav.update(radar(flow=(0,0),valid=True),i*.1)
            self.assertGreater(plan.forward,.7);self.assertEqual(plan.yaw,0)
            self.assertFalse(nav.is_retreating(i*.1))

    def test_resource_yaw_has_short_independent_expiry(self):
        nav=Navigator({});node=Marker('Самоцвет',150,100,.9,50)
        plan=nav.update(radar([node],heading=0),0)
        self.assertAlmostEqual(plan.yaw_lifetime,.12)
        plan=nav.update(radar([node],heading=0),.08)
        self.assertAlmostEqual(plan.yaw_lifetime,.04)

    def test_patrol_turn_does_not_extend_when_loop_is_slow(self):
        nav=Navigator({});nav.update(radar(),0)
        plan=nav.update(radar(),24)
        self.assertAlmostEqual(plan.yaw_lifetime,.24)
        plan=nav.update(radar(),24.20)
        self.assertAlmostEqual(plan.yaw_lifetime,.04)

    def test_road_edge_flicker_does_not_reverse_movement_side_each_frame(self):
        nav=Navigator({});node=Marker('Самоцвет',140,140,.9,56.6)
        nav.update(radar([node],heading=100),0)
        for i in range(1,21):
            plan=nav.update(radar([node],heading=100 if i%2 else 158),i*.1)
            self.assertGreater(plan.strafe,0)

    def test_real_stable_camera_turn_is_accepted_after_short_confirmation(self):
        nav=Navigator({});node=Marker('Самоцвет',150,100,.9,50)
        nav.update(radar([node],heading=0),0)
        nav.update(radar([node],heading=55),.1)
        plan=nav.update(radar([node],heading=55),.4)
        self.assertIn('камера 55°',plan.reason)

    def test_small_course_error_gets_shorter_pulse(self):
        nav=Navigator({});node=Marker('Самоцвет',150,100,.9,50)
        plan=nav.update(radar([node],heading=60),0)
        self.assertGreater(plan.yaw_lifetime,.03);self.assertLess(plan.yaw_lifetime,.08)


class InputTimingTests(unittest.TestCase):
    def test_yaw_expires_while_walking_continues_without_new_frames(self):
        pad=Pad();control=GamepadInput(factory=lambda:pad,a_button=0x1000)
        try:
            control.drive(.78,.2,.6,0,lifetime=.5,yaw_lifetime=.05)
            until=time.monotonic()+.3
            while pad.axes[2] and time.monotonic()<until:time.sleep(.005)
            self.assertEqual(pad.axes,(.2,.78,0,0))
            until=time.monotonic()+1
            while any(pad.axes) and time.monotonic()<until:time.sleep(.005)
            self.assertEqual(pad.axes,(0,0,0,0))
        finally:control.close()

    def test_yaw_expiry_preserves_pitch_and_does_not_reset_a_new_command(self):
        pad=Pad();control=GamepadInput(factory=lambda:pad,a_button=0x1000)
        try:
            control.drive(.78,0,.6,.45,lifetime=.5,yaw_lifetime=.03)
            until=time.monotonic()+.3
            while pad.axes[2] and time.monotonic()<until:time.sleep(.005)
            self.assertEqual(pad.axes,(0,.78,0,.45))
            control.drive(.78,0,-.6,0,lifetime=.5,yaw_lifetime=.2)
            time.sleep(.06)
            self.assertEqual(pad.axes,(0,.78,-.6,0))
            control.reset();time.sleep(.02);self.assertEqual(pad.axes,(0,0,0,0))
        finally:control.close()


class EnginePathTests(GatherFixture,unittest.TestCase):
    def test_real_sent_search_path_is_fed_to_loop_detector(self):
        self.e.cfg['auto_view_recovery']=False
        with patch.object(self.e.nav,'track_walk',return_value=True) as tracker,patch.object(ge,'gathering_panel_pair',return_value=False),patch.object(ge,'segment_count',return_value=None):
            self.e.step(self.frame,(0,0),obs(),radar(),self.sky,100)
        self.assertTrue(tracker.call_args.args[1]);self.assertTrue(any('12 с прямого' in s for s in self.log))

    def test_gather_and_native_route_never_run_patrol_loop_recovery(self):
        for mode in ('APPROACH','GATHER'):
            self.e.mode=mode;self.e.target='Сапфир';self.e.target_confirmed=True
            self.e.resource_hold=True;self.e.route_f_sent=True
            with patch.object(self.e.nav,'track_walk') as tracker:
                self.step(obs(name='Сапфир',distance=6),100,plate=3)
            tracker.assert_not_called()
        self.assertNotIn('V',self.commands);self.assertNotIn('TAP_F',self.commands)

    def test_engine_passes_yaw_expiry_to_transport(self):
        with patch.object(self.input,'drive') as drive:
            self.e._motion(Drive(.78,yaw=.6,yaw_lifetime=.07))
        self.assertEqual(drive.call_args.kwargs['yaw_lifetime'],.07)


if __name__=='__main__':unittest.main()
