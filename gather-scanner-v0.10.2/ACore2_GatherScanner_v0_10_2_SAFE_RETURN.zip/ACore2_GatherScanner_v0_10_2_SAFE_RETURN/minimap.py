"""Resource radar: coloured diamonds, white gem glyphs, camera cone, map displacement."""
from dataclasses import dataclass
from pathlib import Path
import math
import cv2
import numpy as np
from map_reference import ArrowLocator

ROOT=Path(__file__).resolve().parent


def angle_delta(target,current):return (target-current+180)%360-180


@dataclass
class Marker:
    name:str
    x:int
    y:int
    score:float
    distance:float
    kind:str='gem'


@dataclass
class Radar:
    markers:list
    center:tuple
    heading:float|None
    confidence:float
    displacement:tuple
    motion_valid:bool
    bounds:tuple
    character_heading:float|None=None
    character_confidence:float=0.0
    hostiles_near:int=0


class MinimapVision:
    def __init__(self,cfg):
        self.cfg=cfg;self.templates=[];self.previous=None
        self.previous_points=None
        self.gem_template=cv2.imread(str(ROOT/'assets/minimap_gem_mask.png'),0)
        self.arrow=ArrowLocator(cv2.imread(str(ROOT/'assets/player_arrow_mask.png'),0))
        for item in cfg.get('minimap_templates',[]):
            p=(ROOT/item.get('file','')).resolve()
            if not p.is_relative_to(ROOT) or not p.is_file():continue
            gray=cv2.imread(str(p),cv2.IMREAD_GRAYSCALE)
            if gray is not None:self.templates.append((item.get('name','Ресурс'),gray))

    @property
    def ready(self):return True

    def bounds(self,frame):
        h,w=frame.shape[:2]
        roi=self.cfg.get('minimap_roi') or [.835,.109,.153,.18]
        x,y,rw,rh=roi
        return max(0,round(x*w)),max(0,round(y*h)),min(w,round((x+rw)*w)),min(h,round((y+rh)*h))

    def player(self,frame):
        x0,y0,x1,y1=self.bounds(frame)
        cx,cy=self.cfg.get('minimap_player',[.5,.5])
        return x0+(x1-x0)*cx,y0+(y1-y0)*cy

    @staticmethod
    def cone_heading(roi,center):
        # The sector is translucent. On pale terrain its second boundary is grey,
        # not white; roads can be brighter than either boundary. Compare narrow
        # radial ridges AND the brightness on the inside of both boundaries.
        h,w=roi.shape[:2];cx,cy=center;unit=min(h,w)
        gray=cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY).astype(np.float32)
        angles=np.deg2rad(np.arange(360,dtype=np.float32))[:,None]
        radii=np.linspace(unit*.11,unit*.82,160,dtype=np.float32)[None,:]
        dx,dy=np.sin(angles),-np.cos(angles);tx,ty=np.cos(angles),np.sin(angles)
        scores=np.zeros(360,np.float32)
        def sample(x,y):
            return cv2.remap(gray,x.astype(np.float32),y.astype(np.float32),cv2.INTER_LINEAR)
        for offset in (-.016,-.008,0,.008,.016):
            x=cx+radii*dx+offset*unit*tx;y=cy+radii*dy+offset*unit*ty
            valid=(x>5)&(x<w-5)&(y>5)&(y<h-5)
            sides=(sample(x-unit*.016*tx,y-unit*.016*ty)+sample(x+unit*.016*tx,y+unit*.016*ty))/2
            contrast=np.clip(sample(x,y)-sides,-15,35)
            counts=valid.sum(axis=1)
            value=(contrast*valid).sum(axis=1)/np.maximum(1,counts)*(counts/160)**.3
            value[counts<25]=0;scores=np.maximum(scores,value)
        peaks=[];remaining=scores.copy()
        for _ in range(8):
            i=int(remaining.argmax())
            if remaining[i]<6:break
            peaks.append(i);remaining[(np.arange(i-9,i+10)%360)]=-1
        def level(deg):
            a=math.radians(deg);r=np.linspace(unit*.13,unit*.60,80,dtype=np.float32)
            x=cx+r*math.sin(a);y=cy-r*math.cos(a)
            valid=(x>5)&(x<w-5)&(y>5)&(y<h-5)
            return float(sample(x[None,:],y[None,:])[0,valid].mean()) if valid.any() else 0
        pairs=[]
        for i,a in enumerate(peaks):
            for b in peaks[i+1:]:
                delta=angle_delta(b,a)
                if not 55<=abs(delta)<=135:continue
                sign=1 if delta>0 else -1
                inside=(level(a+sign*7)-level(a-sign*7)+level(b-sign*7)-level(b+sign*7))/2
                if inside>4:
                    score=min(scores[a],scores[b])+.20*min(30,inside)
                    pairs.append((score,(a+delta/2)%360))
        if pairs:
            score,heading=max(pairs)
            return heading,min(1.0,float(score)/25)
        # Clear white lines also work in synthetic tests or with a disabled tint.
        hsv=cv2.cvtColor(roi,cv2.COLOR_BGR2HSV)
        white=cv2.inRange(hsv,np.array([0,0,205]),np.array([179,105,255]))
        h,w=white.shape;cx,cy=center;length=max(15,round(min(h,w)*.18))
        lines=cv2.HoughLinesP(white,1,np.pi/180,threshold=max(8,length//3),minLineLength=length,maxLineGap=5)
        groups=[]
        for x1,y1,x2,y2 in ([] if lines is None else lines[:,0]):
            dx,dy=float(x2-x1),float(y2-y1);size=math.hypot(dx,dy)
            if size<1:continue
            distance=abs(dy*cx-dx*cy+x2*y1-y2*x1)/size
            if distance>max(5,min(h,w)*.065):continue
            fx,fy=max(((x1,y1),(x2,y2)),key=lambda p:math.hypot(p[0]-cx,p[1]-cy))
            if math.hypot(fx-cx,fy-cy)<min(h,w)*.25:continue
            angle=math.degrees(math.atan2(fx-cx,cy-fy))%360
            near=next((g for g in groups if abs(angle_delta(angle,g[0]))<12),None)
            if near:
                near[0]=(near[0]+angle_delta(angle,near[0])*size/(near[1]+size))%360
                near[1]+=size
            else:groups.append([angle,size])
        pairs=[]
        for i,a in enumerate(groups):
            for b in groups[i+1:]:
                separation=abs(angle_delta(a[0],b[0]))
                if 55<=separation<=135:
                    # Both boundaries must contribute; one bright road isn't a cone.
                    score=min(a[1],b[1])+.15*(a[1]+b[1])
                    pairs.append((score,(a[0]+angle_delta(b[0],a[0])/2)%360))
        if not pairs:return None,0.0
        score,heading=max(pairs)
        return heading,min(1.0,score/(min(h,w)*.65))

    @staticmethod
    def gem_glyph():
        glyph=np.zeros((17,15),np.uint8)
        cv2.fillConvexPoly(glyph,np.array([[7,1],[11,6],[7,11],[3,6]]),255)
        cv2.fillConvexPoly(glyph,np.array([[3,10],[6,13],[3,16],[0,13]]),255)
        cv2.fillConvexPoly(glyph,np.array([[11,10],[14,13],[11,16],[8,13]]),255)
        return glyph

    def _markers(self,roi,offset,center,frame_width):
        x0,y0=offset;cx,cy=center;h,w=roi.shape[:2]
        hsv=cv2.cvtColor(roi,cv2.COLOR_BGR2HSV)
        colour=cv2.inRange(hsv,np.array([44,80,115]),np.array([103,255,255]))
        found=[]
        contours,_=cv2.findContours(colour,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        for c in contours:
            x,y,rw,rh=cv2.boundingRect(c);area=cv2.contourArea(c)
            if min(rw,rh)<3 or max(rw,rh)>min(h,w)*.18 or not .38<rw/max(rh,1)<1.5:continue
            extent=area/(rw*rh)
            polygon=cv2.approxPolyDP(c,.04*cv2.arcLength(c,True),True)
            # Rings/badges and camera-circle fragments must not become aether.
            if not .24<extent<.72 or len(polygon)>7 or area<max(4,20*(frame_width/2480)**2):continue
            hull_area=cv2.contourArea(cv2.convexHull(c))
            # A scaled green check can have four vertices too, but its deep
            # concavity differs from the compact convex aether diamond.
            if hull_area<=0 or area/hull_area<.66:continue
            px,py=x+rw//2,y+rh//2
            found.append(Marker('Эфир',x0+px,y0+py,.9,math.hypot(px-cx,py-cy),'aether'))
        white=cv2.inRange(hsv,np.array([0,0,185]),np.array([179,90,255]))
        real=self.gem_template
        glyphs=[(real,2480)] if real is not None else [(self.gem_glyph(),2048)]
        for glyph,reference_width in glyphs:
            for scale in (.70,.90,1.0,1.10,1.30):
                base=frame_width/reference_width
                tw,th=max(5,round(glyph.shape[1]*base*scale)),max(6,round(glyph.shape[0]*base*scale))
                tpl=cv2.resize(glyph,(tw,th),interpolation=cv2.INTER_AREA)
                if tw>=w or th>=h:continue
                scores=cv2.matchTemplate(white,tpl,cv2.TM_CCOEFF_NORMED)
                for _ in range(12):
                    _,score,_,(x,y)=cv2.minMaxLoc(scores)
                    if score<self.cfg.get('gem_icon_threshold',.74 if real is not None else .63):break
                    px,py=x+tw//2,y+th//2
                    # A simple circular dot cannot satisfy all three diamond lobes.
                    patch=white[y:y+th,x:x+tw]
                    top=patch[:max(1,round(th*.6))]
                    bottom=patch[round(th*.6):]
                    lobes=(np.count_nonzero(bottom[:,:tw//2])>2 and np.count_nonzero(bottom[:,tw//2:])>2)
                    if lobes and np.count_nonzero(top)>4:
                        found.append(Marker('Самоцвет',x0+px,y0+py,float(score),math.hypot(px-cx,py-cy),'gem'))
                    scores[max(0,y-th//2):y+th//2+1,max(0,x-tw//2):x+tw//2+1]=-1
        # Real user-captured templates remain supported as an optional refinement.
        gray=cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY);edges=cv2.Canny(gray,55,135)
        reference=self.cfg.get('minimap_reference_size',[frame_width,1])[0]
        for name,template in self.templates:
            tpl=cv2.resize(template,None,fx=frame_width/reference,fy=frame_width/reference)
            th,tw=tpl.shape
            if th>=h or tw>=w:continue
            te=cv2.Canny(tpl,55,135)
            if np.count_nonzero(te)<8:continue
            scores=cv2.matchTemplate(edges,te,cv2.TM_CCOEFF_NORMED)
            for _ in range(12):
                _,score,_,(x,y)=cv2.minMaxLoc(scores)
                if score<self.cfg.get('minimap_threshold',.80):break
                px,py=x+tw//2,y+th//2
                kind='aether' if name=='Эфир' else 'gem'
                geometric=(kind!='aether' or any(m.kind=='aether' and math.hypot(m.x-x0-px,m.y-y0-py)<max(4,frame_width*.004) for m in found))
                if geometric:found.append(Marker(name,x0+px,y0+py,float(score),math.hypot(px-cx,py-cy),kind))
                scores[max(0,y-th//2):y+th//2+1,max(0,x-tw//2):x+tw//2+1]=-1
        result=[]
        for marker in sorted(found,key=lambda m:-m.score):
            # Player and a currently selected icon may overlap; OCR handles that resource.
            if marker.distance<max(5,min(h,w)*.03):continue
            # The cyan glyph has two separated sides: do not navigate twice to
            # the left and right halves of the same icon.
            if all(math.hypot(marker.x-m.x,marker.y-m.y)>max(6,frame_width*.006) for m in result):result.append(marker)
        return sorted(result,key=lambda m:m.distance)

    def observe(self,frame):
        x0,y0,x1,y1=self.bounds(frame);roi=frame[y0:y1,x0:x1]
        center=self.player(frame);local=(center[0]-x0,center[1]-y0)
        if min(roi.shape[:2],default=0)<20:return Radar([],center,None,0,(0,0),False,(x0,y0,x1,y1))
        heading,confidence=self.cone_heading(roi,local)
        gray=cv2.GaussianBlur(cv2.cvtColor(roi,cv2.COLOR_BGR2GRAY),(3,3),0)
        displacement=(0.0,0.0);valid=False
        if self.previous is not None and self.previous.shape==gray.shape:
            points=self.previous_points
            if points is not None and len(points)>=8:
                moved,status,error=cv2.calcOpticalFlowPyrLK(self.previous,gray,points,None,
                    winSize=(15,15),maxLevel=2,criteria=(cv2.TERM_CRITERIA_EPS|cv2.TERM_CRITERIA_COUNT,20,.02))
                good=(status.ravel()>0)&(error.ravel()<25)
                flow=(moved-points).reshape(-1,2)[good]
                if len(flow)>=8:
                    median=np.median(flow,axis=0);residual=np.linalg.norm(flow-median,axis=1)
                    inliers=flow[residual<1.5]
                    if len(inliers)>=8 and len(inliers)>=len(flow)*.55:
                        shift=np.median(inliers,axis=0)
                        if np.linalg.norm(shift)<min(gray.shape)*.15:
                            displacement=tuple(map(float,shift));valid=True
        self.previous=gray
        # Track terrain features away from the character, coloured markers and
        # bright glyphs. The moving camera cone must not become fake movement.
        hsv=cv2.cvtColor(roi,cv2.COLOR_BGR2HSV)
        mask=np.where((hsv[:,:,1]<170)&(hsv[:,:,2]<220),255,0).astype(np.uint8)
        cv2.circle(mask,(round(local[0]),round(local[1])),max(10,round(min(gray.shape)*.23)),0,-1)
        mask[:3]=0;mask[-3:]=0;mask[:,:3]=0;mask[:,-3:]=0
        self.previous_points=cv2.goodFeaturesToTrack(gray,100,.02,6,mask=mask)
        markers=self._markers(roi,(x0,y0),local,frame.shape[1])
        if self.cfg.get('only_aether'):markers=[m for m in markers if m.kind=='aether']
        arrow=self.arrow.locate(roi,35*frame.shape[1]/2480,near=local,threshold=.62)
        red=cv2.inRange(hsv,(0,130,120),(10,255,255))|cv2.inRange(hsv,(170,130,120),(179,255,255))
        contours,_=cv2.findContours(red,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        hostiles=0
        for c in contours:
            x,y,rw,rh=cv2.boundingRect(c);area=cv2.contourArea(c)
            if (2<=min(rw,rh) and max(rw,rh)<min(gray.shape)*.065 and .6<rw/max(1,rh)<1.6
                and area/(rw*rh)>.40 and math.hypot(x+rw/2-local[0],y+rh/2-local[1])<min(gray.shape)*.32):hostiles+=1
        return Radar(markers,center,heading,confidence,displacement,valid,(x0,y0,x1,y1),
                     None if arrow is None else arrow[3],0.0 if arrow is None else arrow[0],hostiles)

    def scan(self,frame):return self.observe(frame).markers
