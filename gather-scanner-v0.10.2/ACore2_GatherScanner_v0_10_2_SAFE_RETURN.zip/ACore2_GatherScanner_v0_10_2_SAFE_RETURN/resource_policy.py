"""Aether-first selection with ground gathering during energy recovery."""
class ResourcePolicy:
    def __init__(self,cfg):
        self.priority=bool(cfg.get('only_aether'))
        self.low=float(cfg.get('aether_priority_low_percent',20))
        self.resume=max(self.low+5,float(cfg.get('aether_priority_resume_percent',35)))
        self.recovering=None;self.air_ready=True

    def update(self,budget):
        self.air_ready=budget.can_start()
        if not self.priority:return
        energy=budget.energy
        if not self.air_ready:self.recovering=True
        elif energy is None and self.recovering and budget.failures:
            # A missing measurement is not zero. The flight budget has already
            # enforced its bounded retry delay; allow one new measured attempt.
            self.recovering=None
        elif energy is not None:
            if self.recovering is None:self.recovering=energy<self.resume
            elif self.recovering and energy>=self.resume:self.recovering=False
            elif not self.recovering and energy<=self.low:self.recovering=True

    def allows(self,name):
        if name=='Эфир':return self.air_ready and (not self.priority or not self.recovering)
        return not self.priority or bool(self.recovering)

    def names(self,names):return tuple(n for n in names if self.allows(n))
