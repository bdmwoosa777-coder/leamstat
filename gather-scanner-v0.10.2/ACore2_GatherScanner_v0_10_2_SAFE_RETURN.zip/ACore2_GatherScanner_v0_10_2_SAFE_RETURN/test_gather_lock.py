"""Resource lifecycle regressions: no path recovery/wing toggles after collection."""
import time,unittest
from unittest.mock import patch
from contextlib import ExitStack
import cv2
import numpy as np
from test_navigation import GatherFixture,obs,radar
from test_reference_crops import canvas
from flight import FlightReading
from flight_probe import FlightProbe
from minimap import Marker
from vision import selected_target,segment_count,gathering_panel,gathering_panel_pair
import gather_engine as ge

AIR=FlightReading(50,True)
GROUND=FlightReading(None,False)

class GatherLockTests(GatherFixture,unittest.TestCase):
    def selected(self,name='Эфир'):
        self.e.target=name;self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode='APPROACH';self.e.started=99;self.e.last_progress=99
        self.e._reset_resource_watch(verified_header=True);self.e.panel_cleared=True
        self.e.route_active=True

    def test_aether_first_attempt_then_two_remaining_never_fold_or_restart_native_path(self):
        self.selected()
        with patch.object(ge,'selected_target',return_value=('Эфир',1)),patch.object(self.e,'_recover') as recover:
            self.step(obs('Эфир',distance=1),100,plate=3,panel=True,reading=AIR)
            for now in (101,103,106,110,114):
                self.step(obs('Эфир',distance=1),now,plate=2,panel=False,reading=AIR)
            self.step(obs('Эфир',distance=1),115,plate=2,panel=True,reading=AIR)
        recover.assert_not_called();self.assertEqual(self.e.mode,'GATHER')
        self.assertTrue(self.e.target_confirmed);self.assertTrue(self.e.f_on)
        self.assertNotIn('V',self.commands);self.assertNotIn('END_AIR',self.commands)
        self.assertNotIn('TAP_F',self.commands);self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_ground_detour_reaches_resource_before_pending_wall_recovery(self):
        self.selected('Сапфир');self.e.last_distance=20
        self.step(obs('Сапфир',distance=20),100,plate=3,reading=GROUND)
        # Main observation can be stale, but the live frame now contains a panel.
        with patch.object(ge,'gathering_panel',return_value=True),patch.object(ge,'gathering_panel_pair',return_value=True):
            self.e._recover(self.frame,(0,0),obs('Сапфир',distance=20),GROUND,110)
        self.assertEqual(self.e.mode,'GATHER');self.assertTrue(self.e.f_on)
        self.assertFalse(self.e.route_active);self.assertNotIn('V',self.commands)
        self.assertNotIn('JUMP',self.commands);self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_fresh_send_gate_blocks_v_when_panel_appears_after_recovery_check(self):
        self.selected('Сапфир');self.e.route_active=False
        # First read misses at recovery entry, second read at transport sees it.
        with patch.object(ge,'gathering_panel',return_value=False),patch.object(ge,'gathering_panel_pair',side_effect=[False,True]):
            self.e._recover(self.frame,(0,0),obs('Сапфир',distance=20),GROUND,110)
        self.assertNotIn('V',self.commands);self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_autopath_cancellation_cannot_move_when_collection_just_appeared(self):
        self.selected('Сапфир')
        with patch.object(ge,'gathering_panel',return_value=False),patch.object(ge,'gathering_panel_pair',side_effect=[False,True]),patch.object(self.input,'drive') as drive:
            self.e._recover(self.frame,(0,0),obs('Сапфир',distance=20),GROUND,110)
        drive.assert_not_called();self.assertNotIn('V',self.commands);self.assertNotIn('TAP_F',self.commands)
        self.step(obs('Сапфир',distance=1),111,plate=3,panel=True)
        self.assertEqual(self.e.mode,'GATHER')

    def test_fresh_near_distance_blocks_v_even_when_old_observation_is_far(self):
        self.selected('Сапфир')
        with patch.object(ge,'segment_count',return_value=3),patch.object(ge,'selected_target',return_value=('Сапфир',2)):
            self.assertFalse(self.e.bridge_cmd('V'))
        self.assertEqual(self.commands,[])

    def test_direct_v_and_end_air_are_blocked_by_actual_lower_panel(self):
        self.selected()
        with patch.object(ge,'gathering_panel_pair',return_value=True):
            self.assertFalse(self.e.bridge_cmd('V'))
            self.assertFalse(self.e.bridge_cmd('END_AIR'))
        self.assertEqual(self.commands,[])

    def test_collected_node_with_two_slots_blocks_end_air_even_between_panels(self):
        self.selected();self.e.fast_gather_seen=True;self.e.mode='GATHER'
        with patch.object(ge,'gathering_panel',return_value=False),patch.object(ge,'segment_count',return_value=2):
            self.assertFalse(self.e.bridge_cmd('END_AIR'))
            self.e.return_to_search('incorrect idle recovery',exhausted=True,reading=AIR)
        self.assertEqual(self.commands,[]);self.assertEqual(self.e.mode,'GATHER')
        self.assertTrue(self.e.target_confirmed);self.assertEqual(self.e.node_count,0)

    def test_a_missing_single_panel_frame_after_long_attempt_cannot_open_ground_wings(self):
        self.selected('Сапфир');self.e.camera_scheduler_active=True
        self.step(obs('Сапфир',distance=1),100,plate=3,panel=True)
        self.step(obs('Сапфир',distance=1),108,plate=3,panel=True)
        with patch.object(ge,'selected_target',return_value=('Сапфир',1)):
            self.step(obs('Сапфир',distance=1),108.1,plate=2,panel=False)
        self.assertEqual(self.e.mode,'GATHER');self.assertTrue(self.e.f_on)
        self.assertNotIn('V',self.commands);self.assertNotIn('JUMP',self.commands)
        self.assertNotIn('TAP_F',self.commands)

    def test_slot_loss_cannot_disable_approach_recovery_without_a_real_panel(self):
        self.selected('Сапфир')
        self.step(obs('Сапфир',distance=6),100,plate=3)
        self.step(obs('Сапфир',distance=6),101,plate=2)
        self.assertEqual(self.e.mode,'APPROACH');self.assertFalse(self.e.fast_gather_seen)
        self.step(obs('Сапфир',distance=6),107,plate=3)
        self.assertEqual(self.e.mode,'TAKEOFF');self.assertIn('V',self.commands)
        self.assertFalse(self.e.real_gather_panel_seen)

    def test_old_wrong_resource_ocr_cannot_fold_live_aether_with_remaining_slots(self):
        self.selected()
        self.step(obs('Эфир',distance=1),100,plate=3,panel=True,reading=AIR)
        self.step(obs('Сапфир',distance=20),101,plate=2,reading=AIR)
        self.assertEqual(self.e.target,'Эфир');self.assertEqual(self.e.mode,'GATHER')
        self.assertNotIn('END_AIR',self.commands)

    def test_actual_title_protects_resource_when_both_counter_and_fast_header_miss(self):
        self.selected('Сапфир');self.e.fast_gather_seen=True;self.e.mode='GATHER'
        self.frame=canvas('sapphire_target_49m_crop.png',950,40)
        self.e.screen.frame=lambda:(self.frame,(0,0))
        with patch.object(ge,'segment_count',return_value=None),patch.object(ge,'resource_header_visible',return_value=False),patch.object(ge,'gathering_panel',return_value=False):
            self.e._resource_fast_tick(self.frame,AIR,100,panel=False)
            self.e._resource_fast_tick(self.frame,AIR,101,panel=False)
        self.assertEqual(self.e.target,'Сапфир');self.assertTrue(self.e.target_confirmed)
        self.assertNotIn('END_AIR',self.commands)

    def test_fresh_title_blocks_end_air_even_if_both_fast_header_detectors_miss(self):
        self.selected('Сапфир');self.e.fast_gather_seen=True;self.e.mode='GATHER'
        self.frame=canvas('sapphire_target_49m_crop.png',950,40)
        self.e.screen.frame=lambda:(self.frame,(0,0))
        with patch.object(ge,'segment_count',return_value=None),patch.object(ge,'resource_header_visible',return_value=False),patch.object(ge,'gathering_panel',return_value=False):
            self.assertFalse(self.e.bridge_cmd('END_AIR'))
        self.assertEqual(self.commands,[])

    def test_damage_does_not_discard_resource_when_only_its_title_is_recognized(self):
        from health import HPReading
        self.selected('Сапфир');self.e.mode='GATHER'
        self.frame=canvas('sapphire_target_49m_crop.png',950,40)
        self.e.health.numeric(self.frame,HPReading(18441,18442),99.8)
        with patch.object(ge,'segment_count',return_value=None),patch.object(ge,'resource_header_visible',return_value=False),patch.object(self.e,'_defend_and_resume') as defend:
            self.e._check_route_damage(self.frame,100,panel=False,slots=None)
        defend.assert_called_once_with(resume=True)

    def test_pending_close_retry_is_cancelled_if_resource_is_visible_again(self):
        self.selected();self.e.wing_close_pending=98;self.e.wing_close_retries=0
        self.step(obs('Эфир',distance=1),100,plate=2,panel=True,reading=AIR)
        self.assertIsNone(self.e.wing_close_pending);self.assertNotIn('END_AIR',self.commands)
        self.assertEqual(self.e.mode,'GATHER')

    def test_collection_discards_old_search_probe_before_it_can_close_wings(self):
        self.selected();self.e.probe=FlightProbe(Marker('Эфир',105,100,.9,5,'aether'),99,{})
        self.e.probe.phase_to('CLOSE',99);self.e.pending_probe=self.e.probe.goal
        self.step(obs('Эфир',distance=1),100,plate=3,panel=True,reading=AIR)
        self.assertIsNone(self.e.probe);self.assertIsNone(self.e.pending_probe)
        self.assertNotIn('END_AIR',self.commands)

    def test_unchanged_camera_does_not_calibrate_during_or_after_resource(self):
        self.selected();self.e.camera_scheduler_active=True;self.e.camera_last_calibrated=1
        # Old imported option is ignored even if explicitly true.
        self.e.cfg['camera_calibrate_during_gather']=True
        with patch.object(self.e,'_calibrate_camera') as calibrate:
            for now,slots in ((100,3),(101,2),(102,1)):
                self.step(obs('Эфир',distance=1),now,plate=slots,panel=True,reading=AIR)
            self.step(obs(),103,reading=AIR)
            self.step(obs(),104,reading=AIR)
            self.e._service_wing_close(GROUND,time.monotonic()+.5)
            self.e._service_wing_close(GROUND,time.monotonic()+1)
        calibrate.assert_not_called();self.assertIsNone(self.e.camera_alignment_due)
        self.assertEqual(self.commands.count('END_AIR'),1)

    def test_real_search_pitch_offset_schedules_alignment_after_resource(self):
        self.selected();self.e.camera_scheduler_active=True;self.e.pitch.balance=.12
        self.e.return_to_search('done',exhausted=True,reading=AIR)
        self.assertIsNotNone(self.e.camera_alignment_due)
        self.assertEqual(self.commands.count('END_AIR'),1)

    def test_failed_pitch_return_does_not_recalibrate_or_stop_collection(self):
        self.selected();self.e.camera_scheduler_active=True;self.e.pitch.failed=True
        with patch.object(self.e,'_calibrate_camera') as calibrate:
            self.step(obs('Эфир',distance=1),100,plate=2,panel=True,reading=AIR)
        calibrate.assert_not_called();self.assertFalse(self.e.stop_event.is_set())
        self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_stalled_collection_stops_without_reopening_or_folding_wings(self):
        self.selected();self.step(obs('Эфир',distance=1),100,plate=3,panel=True,reading=AIR)
        self.e.repeat_rearmed=True
        self.step(obs('Эфир',distance=1),121,plate=2,reading=AIR)
        # A slot drop is real progress, so the first wait does not time out.
        self.assertFalse(self.e.stop_event.is_set())
        self.step(obs('Эфир',distance=1),142,plate=2,reading=AIR)
        self.assertTrue(self.e.stop_event.is_set())
        if self.e.release_thread:self.e.release_thread.join(timeout=1)
        self.assertNotIn('V',self.commands);self.assertNotIn('END_AIR',self.commands)

class ResourceTitleTests(unittest.TestCase):
    def test_independent_top_title_can_be_read_when_counter_is_unavailable(self):
        image=canvas('sapphire_target_49m_crop.png',950,40)
        with patch('vision.segment_count',return_value=None):
            self.assertEqual(selected_target(image), (None,None))
            self.assertEqual(selected_target(image,require_track=False),('Сапфир',49))

if __name__=='__main__':unittest.main()
