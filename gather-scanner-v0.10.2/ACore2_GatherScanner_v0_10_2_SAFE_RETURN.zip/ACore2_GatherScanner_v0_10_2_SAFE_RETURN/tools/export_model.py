"""Developer-only export; normal users already have the exported ONNX model.

Provide a local snapshot of the pinned upstream model; no network/code fetching.
Dependencies used: torch 2.9.1, transformers 4.57.1, onnx 1.19.1,
onnxruntime 1.23.2. Model derivatives retain models/LICENSE_SEGFORMER.txt.
"""
from pathlib import Path
import argparse,hashlib,json
import numpy as np
import onnx,onnxruntime as ort,torch
from transformers import SegformerForSemanticSegmentation

REVISION='489d5cd81a0b59fab9b7ea758d3548ebe99677da'
WEIGHTS_SHA='6ae39addd01de6b1b8bde2cf677d43a5cd733424b8d186de3f95d1c51fee23f9'


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--source',type=Path,required=True)
    parser.add_argument('--output',type=Path,default=Path(__file__).resolve().parents[1]/'models');args=parser.parse_args()
    source=args.source;output=args.output;output.mkdir(parents=True,exist_ok=True)
    assert hashlib.sha256((source/'model.safetensors').read_bytes()).hexdigest()==WEIGHTS_SHA
    torch.set_num_threads(2)
    model=SegformerForSemanticSegmentation.from_pretrained(source,local_files_only=True,use_safetensors=True).eval()
    class Export(torch.nn.Module):
        def __init__(self,model):super().__init__();self.model=model
        def forward(self,pixel_values):return self.model(pixel_values=pixel_values).logits
    wrapper=Export(model);sample=torch.from_numpy(np.random.default_rng(42).normal(size=(1,3,512,512)).astype(np.float32))
    path=output/'segformer-b0-ade20k.onnx'
    with torch.inference_mode():
        expected=wrapper(sample).numpy()
        torch.onnx.export(wrapper,(sample,),str(path),input_names=['pixel_values'],output_names=['logits'],opset_version=17,dynamo=False)
    onnx.checker.check_model(str(path))
    options=ort.SessionOptions();options.intra_op_num_threads=2
    session=ort.InferenceSession(str(path),sess_options=options,providers=['CPUExecutionProvider'])
    actual=session.run(None,{'pixel_values':sample.numpy()})[0]
    error=float(np.max(np.abs(expected-actual)));assert np.allclose(expected,actual,atol=1e-3,rtol=1e-3),error
    config=json.loads((source/'config.json').read_text());pre=json.loads((source/'preprocessor_config.json').read_text())
    meta=dict(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),source='nvidia/segformer-b0-finetuned-ade-512-512',revision=REVISION,
              source_weights_sha256=WEIGHTS_SHA,id2label=config['id2label'],mean=pre['image_mean'],std=pre['image_std'],size=512,opset=17,
              license='NVIDIA Source Code License for SegFormer (research/evaluation only)',export_check_max_abs_error=error,
              export_versions={'torch':torch.__version__,'onnx':onnx.__version__,'onnxruntime':ort.__version__})
    (output/'model.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Export verified; max absolute error:',error)


if __name__=='__main__':main()
