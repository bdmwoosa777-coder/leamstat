# Static map data attribution

Source: [SkeeveAN/Aion-DPS-Meter](https://github.com/SkeeveAN/Aion-DPS-Meter)
at commit `602d317929dd199f789a11ab79df20596343fab7` (MIT, SkeeveTV).
The full notice is preserved in LICENSE-MIT.txt.

Files are copied unchanged from `Client/assets/aion2/maps/`:
`gather.json`, `kibelisks.json`, `maps.json`.
These describe potential map locations, not live server availability.
Three map layers; automatic zone mapping is available only where maps.json
provides openZones. Kibelisk entries have X/Y, not resource-like XYZ.

World-coordinate units and axes were checked against the same MIT project's
`docs/protocol/position-frames.md`: 100 units per metre, X east, Y south, Z up.
Own ordinary walking/flying is not continuously echoed by those server frames.
The position reader and freshness rules in spatial.py/network_state.py are
local implementations. No game process memory reader or competitor binary
is included.
