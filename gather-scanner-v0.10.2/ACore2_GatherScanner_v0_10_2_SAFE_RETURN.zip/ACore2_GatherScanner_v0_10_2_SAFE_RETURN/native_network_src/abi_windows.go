//go:build windows && amd64

package main

import "unsafe"

// Compilation checks Windows x64 ABI; no native game/driver is used by these.
var _ [int(unsafe.Sizeof(pcapHeader{})) - 16]byte
var _ [16 - int(unsafe.Sizeof(pcapHeader{}))]byte
var _ [int(unsafe.Sizeof(bpfProgram{})) - 16]byte
var _ [16 - int(unsafe.Sizeof(bpfProgram{}))]byte
var _ [int(unsafe.Sizeof(pcapDevice{})) - 40]byte
var _ [40 - int(unsafe.Sizeof(pcapDevice{}))]byte
var _ [int(unsafe.Sizeof(processEntry{})) - 568]byte
var _ [568 - int(unsafe.Sizeof(processEntry{}))]byte
