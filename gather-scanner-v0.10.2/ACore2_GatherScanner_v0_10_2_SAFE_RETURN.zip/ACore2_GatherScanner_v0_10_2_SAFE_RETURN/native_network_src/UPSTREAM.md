# Integrated passive network module

ACore2 owns the Npcap adapter, Windows TCP/process discovery, pipe transport,
shutdown and telemetry integration. `acore2_net.exe` is built from this folder;
it is started by the bot, with no external recorder to select or run.

`wire/*.go` is vendored from **nuriland/a2kit**, MIT,
commit `b1ffe3d6a1248bc26d906983f96896f99d740195`.
The original MIT notice is in LICENSE and ../A2KIT_LICENSE.txt.
The only local wire modification adds a cumulative TCP-gap counter to Stats
and increments it when a missing segment is skipped. The bot stops on a gap.
`peel.go` adapts the MIT packet layout in a2kit/capture/peel.go, including VPN
raw-IP fallback, and adds bounded IPv6 extension traversal and strict caplen.

LZ4: github.com/pierrec/lz4/v4 v4.1.30, pinned by go.sum. Its BSD notice is
../native_network/LZ4_LICENSE.txt. Go runtime's BSD notice is GO_LICENSE.txt
in that same directory. No GPL CubeRadar or Helper application code is bundled.
Npcap is not redistributed; the user's installed capture driver is required.

## Build (Go 1.26 or newer)

```
go test ./...
set CGO_ENABLED=0
set GOOS=windows
set GOARCH=amd64
go build -buildvcs=false -trimpath -ldflags="-s -w -buildid=" -o ../native_network/acore2_net.exe .
```

On Linux/macOS use environment assignments instead of `set`. Recompute
../native_network/SHA256SUMS after building; the Python host verifies the file.
The release was built with Go 1.27.3, Windows/amd64, CGO disabled. A Go compiler
or a .NET runtime is not needed to RUN the included Windows binary.

`--stdin-packets` is an offline verification mode. Input lines contain a Unix
millisecond timestamp t, a pcap datalink number link and packet bytes as hex.
It does not open a driver. Normal operation has no packet files: Npcap reads
go through the decoder and straight to stdout, one flushed JSON line per frame.
The host sends q plus newline / closes stdin to stop. No network writes exist.
