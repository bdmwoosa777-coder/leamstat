//go:build !windows

package main

import "errors"

func capture(device string, e *engine) error {
	return errors.New("live capture requires Windows and Npcap")
}
