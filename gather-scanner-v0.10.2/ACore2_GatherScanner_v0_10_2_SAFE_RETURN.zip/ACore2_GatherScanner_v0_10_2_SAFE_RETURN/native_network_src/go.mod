module acore2.local/network

go 1.26

require github.com/pierrec/lz4/v4 v4.1.30
