// Packet peeling follows MIT a2kit capture/peel.go. Strictly no IP fragments.
package main

import (
	"acore2.local/network/wire"
	"encoding/binary"
	"net/netip"
)

func peel(link int, p []byte) (wire.Segment, bool) {
	raw := p
	switch link {
	case 1:
		if len(p) < 14 {
			return wire.Segment{}, false
		}
		off := 14
		typ := binary.BigEndian.Uint16(p[12:14])
		for (typ == 0x8100 || typ == 0x88a8) && len(p) >= off+4 {
			typ = binary.BigEndian.Uint16(p[off+2:])
			off += 4
		}
		if typ != 0x0800 && typ != 0x86dd {
			return ipSegment(raw)
		}
		p = p[off:]
	case 0, 108:
		if len(p) < 4 {
			return wire.Segment{}, false
		}
		p = p[4:]
	case 113:
		if len(p) < 16 {
			return wire.Segment{}, false
		}
		p = p[16:]
	case 276:
		if len(p) < 20 {
			return wire.Segment{}, false
		}
		p = p[20:]
	case 12, 101, 228, 229:
	default:
		return wire.Segment{}, false
	}
	s, ok := ipSegment(p)
	if !ok && link == 1 {
		return ipSegment(raw)
	}
	return s, ok
}

func ipSegment(p []byte) (wire.Segment, bool) {
	var src, dst netip.Addr
	var tcp []byte
	if len(p) == 0 {
		return wire.Segment{}, false
	}
	switch p[0] >> 4 {
	case 4:
		if len(p) < 20 || p[9] != 6 || binary.BigEndian.Uint16(p[6:8])&0x3fff != 0 {
			return wire.Segment{}, false
		}
		n := int(p[0]&15) * 4
		total := int(binary.BigEndian.Uint16(p[2:4]))
		if n < 20 || total > len(p) || total < n+20 {
			return wire.Segment{}, false
		}
		src = netip.AddrFrom4([4]byte(p[12:16]))
		dst = netip.AddrFrom4([4]byte(p[16:20]))
		tcp = p[n:total]
	case 6:
		if len(p) < 40 {
			return wire.Segment{}, false
		}
		total := 40 + int(binary.BigEndian.Uint16(p[4:6]))
		next := p[6]
		off := 40
		if total > len(p) {
			return wire.Segment{}, false
		}
		// Bound extension traversal; reject fragments rather than guessing bytes.
		for i := 0; next != 6 && i < 8; i++ {
			if off+2 > total {
				return wire.Segment{}, false
			}
			var n int
			switch next {
			case 0, 43, 60:
				n = (int(p[off+1]) + 1) * 8
			case 51:
				n = (int(p[off+1]) + 2) * 4
			default:
				return wire.Segment{}, false
			}
			next = p[off]
			off += n
		}
		if next != 6 || off+20 > total {
			return wire.Segment{}, false
		}
		src = netip.AddrFrom16([16]byte(p[8:24]))
		dst = netip.AddrFrom16([16]byte(p[24:40]))
		tcp = p[off:total]
	default:
		return wire.Segment{}, false
	}
	n := int(tcp[12]>>4) * 4
	if n < 20 || n > len(tcp) {
		return wire.Segment{}, false
	}
	return wire.Segment{Src: netip.AddrPortFrom(src, binary.BigEndian.Uint16(tcp)),
		Dst: netip.AddrPortFrom(dst, binary.BigEndian.Uint16(tcp[2:])),
		Seq: binary.BigEndian.Uint32(tcp[4:]), Ack: binary.BigEndian.Uint32(tcp[8:]),
		Flags: wire.TCPFlags(tcp[13]), Payload: tcp[n:]}, true
}
