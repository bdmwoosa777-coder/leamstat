package main

import (
	"bytes"
	"encoding/binary"
	"encoding/json"
	"fmt"
	"testing"
)

func frame(op []byte, body []byte) []byte {
	var b [5]byte
	n := binary.PutUvarint(b[:], uint64(4+len(op)+len(body)))
	out := append([]byte{}, b[:n]...)
	out = append(out, op...)
	return append(out, body...)
}
func ticks(n int) []byte {
	var b []byte
	for i := 0; i < n; i++ {
		b = append(b, frame([]byte{0, 0x36}, make([]byte, 8))...)
	}
	return b
}
func packet(seq uint32, payload []byte) []byte {
	b := make([]byte, 40+len(payload))
	b[0] = 0x45
	b[9] = 6
	binary.BigEndian.PutUint16(b[2:], uint16(len(b)))
	copy(b[12:], []byte{10, 1, 0, 2})
	copy(b[16:], []byte{10, 1, 0, 1})
	binary.BigEndian.PutUint16(b[20:], 13328)
	binary.BigEndian.PutUint16(b[22:], 50000)
	binary.BigEndian.PutUint32(b[24:], seq)
	b[32] = 0x50
	b[33] = 0x18
	copy(b[40:], payload)
	return b
}
func newTestEngine() (*engine, *bytes.Buffer) {
	b := new(bytes.Buffer)
	return newEngine(&output{enc: json.NewEncoder(b)}), b
}
func decoded(t *testing.T, b *bytes.Buffer) []map[string]any {
	t.Helper()
	d := json.NewDecoder(bytes.NewReader(b.Bytes()))
	var out []map[string]any
	for d.More() {
		var r map[string]any
		if err := d.Decode(&r); err != nil {
			t.Fatal(err)
		}
		out = append(out, r)
	}
	return out
}
func TestFramesAreEmittedBeforeEndOrFileFlush(t *testing.T) {
	e, b := newTestEngine()
	if err := e.packet(1000, 101, packet(100, ticks(3))); err != nil {
		t.Fatal(err)
	}
	rows := decoded(t, b)
	if len(rows) != 3 {
		t.Fatalf("immediate frames=%d", len(rows))
	}
	for _, r := range rows {
		if r["op"] != "0036" || r["flow"] != float64(1) {
			t.Fatal(r)
		}
	}
}
func TestEveryTCPByteCanArriveSeparately(t *testing.T) {
	e, b := newTestEngine()
	wire := ticks(5)
	for i := range wire {
		if err := e.packet(int64(1000+i), 101, packet(uint32(100+i), wire[i:i+1])); err != nil {
			t.Fatal(err)
		}
	}
	if n := len(decoded(t, b)); n != 5 {
		t.Fatalf("frames=%d", n)
	}
}
func TestRetransmittedTCPDoesNotDuplicateCommands(t *testing.T) {
	e, b := newTestEngine()
	p := packet(100, ticks(3))
	if err := e.packet(1000, 101, p); err != nil {
		t.Fatal(err)
	}
	if err := e.packet(1100, 101, p); err != nil {
		t.Fatal(err)
	}
	if n := len(decoded(t, b)); n != 3 {
		t.Fatalf("duplicate frames=%d", n)
	}
}
func TestTCPSequenceWraparound(t *testing.T) {
	e, b := newTestEngine()
	seq := uint32(0xfffffff0)
	a := ticks(3)
	if err := e.packet(1000, 101, packet(seq, a)); err != nil {
		t.Fatal(err)
	}
	if err := e.packet(1010, 101, packet(seq+uint32(len(a)), ticks(1))); err != nil {
		t.Fatal(err)
	}
	if n := len(decoded(t, b)); n != 4 {
		t.Fatalf("frames=%d", n)
	}
}
func TestOutOfOrderTCPWaitsThenDeliversExactlyOnce(t *testing.T) {
	e, b := newTestEngine()
	a := ticks(3)
	seq := uint32(100 + len(a))
	if err := e.packet(1000, 101, packet(100, a)); err != nil {
		t.Fatal(err)
	}
	more := ticks(2)
	if err := e.packet(1100, 101, packet(seq+7, more[7:])); err != nil {
		t.Fatal(err)
	}
	if n := len(decoded(t, b)); n != 3 {
		t.Fatalf("acted past hole: %d", n)
	}
	if err := e.packet(1120, 101, packet(seq, more[:7])); err != nil {
		t.Fatal(err)
	}
	rows := decoded(t, b)
	if len(rows) != 5 {
		t.Fatalf("frames=%d", len(rows))
	}
	for i := 1; i < len(rows); i++ {
		if rows[i]["t"].(float64) < rows[i-1]["t"].(float64) {
			t.Fatal("time reversed")
		}
	}
}
func TestLostTCPGapStopsInsteadOfReusingOldCollection(t *testing.T) {
	e, _ := newTestEngine()
	a := ticks(3)
	seq := uint32(100 + len(a))
	e.packet(1000, 101, packet(100, a))
	if err := e.packet(1100, 101, packet(seq+50, ticks(1))); err != nil {
		t.Fatal(err)
	}
	if err := e.packet(2300, 101, packet(seq+61, ticks(1))); err == nil {
		t.Fatal("lost gap not reported")
	}
}
func TestLinkLayersIncludingVPNRawIP(t *testing.T) {
	raw := packet(100, ticks(3))
	eth := make([]byte, 14)
	eth[12] = 8
	vlan := make([]byte, 18)
	vlan[12] = 0x81
	vlan[16] = 8
	for _, tt := range []struct {
		link int
		b    []byte
	}{
		{101, raw}, {12, raw}, {1, append(eth, raw...)}, {1, raw}, {1, append(vlan, raw...)},
		{0, append([]byte{2, 0, 0, 0}, raw...)}, {108, append([]byte{0, 0, 0, 2}, raw...)},
		{113, append(make([]byte, 16), raw...)}, {276, append(make([]byte, 20), raw...)},
	} {
		t.Run(fmt.Sprint(tt.link, len(tt.b)), func(t *testing.T) {
			s, ok := peel(tt.link, tt.b)
			if !ok || s.Src.Port() != 13328 || len(s.Payload) != len(ticks(3)) {
				t.Fatal(ok, s)
			}
		})
	}
}
func TestTruncatedAndFragmentedIPAreRejected(t *testing.T) {
	raw := packet(100, ticks(1))
	for i := 0; i < len(raw); i++ {
		if _, ok := peel(101, raw[:i]); ok {
			t.Fatalf("accepted cut %d", i)
		}
	}
	raw[6] = 0x20
	if _, ok := peel(101, raw); ok {
		t.Fatal("fragment accepted")
	}
}
func TestIPv6WithAndWithoutHopByHopHeader(t *testing.T) {
	v4 := packet(100, ticks(1))
	tcp := v4[20:]
	for _, extra := range []int{0, 8} {
		p := make([]byte, 40+extra+len(tcp))
		p[0] = 0x60
		p[6] = 6
		binary.BigEndian.PutUint16(p[4:], uint16(extra+len(tcp)))
		p[23] = 1
		p[39] = 2
		if extra > 0 {
			p[6] = 0
			p[40] = 6
		}
		copy(p[40+extra:], tcp)
		if s, ok := peel(101, p); !ok || s.Src.Port() != 13328 {
			t.Fatal(ok, s)
		}
	}
}
func TestReplayRejectsBrokenJSONAndDoesNotOpenCapture(t *testing.T) {
	e, _ := newTestEngine()
	if err := replay(bytes.NewBufferString("{broken}\n"), e); err == nil {
		t.Fatal("accepted broken input")
	}
}

func TestFreshDecodedTrafficDoesNotRequireAnUnchangedAuxiliaryTCPList(t *testing.T) {
	e, _ := newTestEngine()
	if err := e.packet(1000, 101, packet(100, ticks(3))); err != nil {
		t.Fatal(err)
	}
	if !e.serverFresh(1100) {
		t.Fatal("fresh stream would be rechecked/stopped for auxiliary TCP churn")
	}
	if e.serverFresh(4000) {
		t.Fatal("stale stream concealed a real connection failure")
	}
}
