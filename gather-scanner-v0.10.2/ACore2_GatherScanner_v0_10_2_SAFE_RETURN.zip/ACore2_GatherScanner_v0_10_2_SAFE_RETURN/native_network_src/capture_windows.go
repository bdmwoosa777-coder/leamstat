//go:build windows

// The capture adapter is ACore2 code. Calls only passive Npcap APIs.
package main

import (
	"bufio"
	"errors"
	"fmt"
	"net/netip"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"syscall"
	"time"
	"unsafe"
)

type pcapDevice struct {
	next              *pcapDevice
	name, description *byte
	addresses         *pcapAddress
	flags             uint32
}
type pcapAddress struct {
	next                   *pcapAddress
	addr, mask, broad, dst uintptr
}
type pcapHeader struct {
	seconds, micros int32
	caplen, length  uint32
}
type bpfProgram struct {
	length       uint32
	instructions uintptr
}
type adapter struct {
	name, description string
	ips               []netip.Addr
	flags             uint32
}

func cstr(p *byte) string {
	if p == nil {
		return ""
	}
	n := 0
	for n < 65536 && *(*byte)(unsafe.Add(unsafe.Pointer(p), n)) != 0 {
		n++
	}
	return string(unsafe.Slice(p, n))
}
func sockaddr(p uintptr) (netip.Addr, bool) {
	if p == 0 {
		return netip.Addr{}, false
	}
	family := *(*uint16)(unsafe.Pointer(p))
	if family == 2 {
		return netip.AddrFrom4(*(*[4]byte)(unsafe.Pointer(p + 4))), true
	}
	if family == 23 {
		return netip.AddrFrom16(*(*[16]byte)(unsafe.Pointer(p + 8))), true
	}
	return netip.Addr{}, false
}

type pcapAPI struct {
	dll                                                                                                                                                *syscall.DLL
	find, free, create, snap, promisc, timeout, buffer, immediate, activate, compile, filter, freecode, datalink, next, close, geterr, stats, nonblock *syscall.Proc
}

func loadPcap() (*pcapAPI, error) {
	dir := filepath.Join(os.Getenv("SystemRoot"), "System32", "Npcap")
	// Absolute DLL path; don't load a wpcap.dll from the archive/current folder.
	name := filepath.Join(dir, "wpcap.dll")
	if _, err := os.Stat(name); err != nil {
		return nil, errors.New("Npcap is not installed: System32/Npcap/wpcap.dll is missing")
	}
	setdir := syscall.NewLazyDLL("kernel32.dll").NewProc("SetDllDirectoryW")
	path, _ := syscall.UTF16PtrFromString(dir)
	setdir.Call(uintptr(unsafe.Pointer(path)))
	dll, err := syscall.LoadDLL(name)
	if err != nil {
		return nil, fmt.Errorf("load Npcap: %w", err)
	}
	a := &pcapAPI{dll: dll}
	procs := []struct {
		name string
		dst  **syscall.Proc
	}{
		{"pcap_findalldevs", &a.find}, {"pcap_freealldevs", &a.free}, {"pcap_create", &a.create},
		{"pcap_set_snaplen", &a.snap}, {"pcap_set_promisc", &a.promisc}, {"pcap_set_timeout", &a.timeout},
		{"pcap_set_buffer_size", &a.buffer}, {"pcap_activate", &a.activate}, {"pcap_compile", &a.compile},
		{"pcap_setfilter", &a.filter}, {"pcap_freecode", &a.freecode}, {"pcap_datalink", &a.datalink},
		{"pcap_next_ex", &a.next}, {"pcap_close", &a.close}, {"pcap_geterr", &a.geterr}, {"pcap_stats", &a.stats},
		{"pcap_setnonblock", &a.nonblock},
	}
	for _, p := range procs {
		*p.dst, err = dll.FindProc(p.name)
		if err != nil {
			dll.Release()
			return nil, err
		}
	}
	a.immediate, _ = dll.FindProc("pcap_set_immediate_mode")
	return a, nil
}
func (a *pcapAPI) devices() ([]adapter, error) {
	var first *pcapDevice
	var errbuf [256]byte
	r, _, _ := a.find.Call(uintptr(unsafe.Pointer(&first)), uintptr(unsafe.Pointer(&errbuf[0])))
	if int32(r) != 0 {
		return nil, errors.New(cstr(&errbuf[0]))
	}
	defer a.free.Call(uintptr(unsafe.Pointer(first)))
	var all []adapter
	for d, n := first, 0; d != nil && n < 256; d, n = d.next, n+1 {
		x := adapter{name: cstr(d.name), description: cstr(d.description), flags: d.flags}
		for addr, count := d.addresses, 0; addr != nil && count < 256; addr, count = addr.next, count+1 {
			if ip, ok := sockaddr(addr.addr); ok {
				x.ips = append(x.ips, ip.Unmap())
			}
		}
		all = append(all, x)
	}
	return all, nil
}
func (a *pcapAPI) message(h uintptr) string {
	p, _, _ := a.geterr.Call(h)
	return cstr((*byte)(unsafe.Pointer(p)))
}
func (a *pcapAPI) open(dev adapter, filter string) (uintptr, error) {
	var errbuf [256]byte
	name, _ := syscall.BytePtrFromString(dev.name)
	h, _, _ := a.create.Call(uintptr(unsafe.Pointer(name)), uintptr(unsafe.Pointer(&errbuf[0])))
	runtime.KeepAlive(name)
	if h == 0 {
		return 0, fmt.Errorf("open Npcap: %s", cstr(&errbuf[0]))
	}
	good := false
	defer func() {
		if !good {
			a.close.Call(h)
		}
	}()
	for _, opt := range []struct {
		p *syscall.Proc
		v uintptr
	}{{a.snap, 1 << 20}, {a.promisc, 0}, {a.timeout, 100}, {a.buffer, 16 << 20}} {
		r, _, _ := opt.p.Call(h, opt.v)
		if int32(r) != 0 {
			return 0, fmt.Errorf("Npcap setting: %s", a.message(h))
		}
	}
	if a.immediate != nil {
		r, _, _ := a.immediate.Call(h, 1)
		if int32(r) != 0 {
			return 0, fmt.Errorf("Npcap immediate mode: %s", a.message(h))
		}
	}
	r, _, _ := a.activate.Call(h)
	if int32(r) < 0 {
		return 0, fmt.Errorf("Npcap activate: %s", a.message(h))
	}
	var program bpfProgram
	expr, _ := syscall.BytePtrFromString(filter)
	r, _, _ = a.compile.Call(h, uintptr(unsafe.Pointer(&program)), uintptr(unsafe.Pointer(expr)), 1, 0xffffffff)
	runtime.KeepAlive(expr)
	if int32(r) != 0 {
		return 0, fmt.Errorf("Npcap filter compile: %s", a.message(h))
	}
	defer a.freecode.Call(uintptr(unsafe.Pointer(&program)))
	r, _, _ = a.filter.Call(h, uintptr(unsafe.Pointer(&program)))
	if int32(r) != 0 {
		return 0, fmt.Errorf("Npcap filter: %s", a.message(h))
	}
	r, _, _ = a.nonblock.Call(h, 1, uintptr(unsafe.Pointer(&errbuf[0])))
	if int32(r) != 0 {
		return 0, fmt.Errorf("Npcap nonblocking read: %s", cstr(&errbuf[0]))
	}
	good = true
	return h, nil
}

func chooseAdapter(all []adapter, conns []gameConnection, forced string) (adapter, bool) {
	if forced != "" {
		for _, a := range all {
			if a.name == forced {
				return a, true
			}
		}
		return adapter{}, false
	}
	// Prefer the actual game port, then a local relay/accelerator connection.
	for _, wantPort := range []bool{true, false} {
		for _, c := range conns {
			if (c.remote.Port() == 13328) != wantPort {
				continue
			}
			for _, a := range all {
				if c.local.Addr().IsLoopback() || c.remote.Addr().IsLoopback() {
					if a.flags&1 != 0 || strings.Contains(strings.ToLower(a.name+" "+a.description), "loopback") {
						return a, true
					}
				} else {
					for _, ip := range a.ips {
						if ip == c.local.Addr().Unmap() {
							return a, true
						}
					}
				}
			}
		}
	}
	return adapter{}, false
}
func bpf(conns []gameConnection) string {
	parts := []string{"port 13328"}
	seen := map[string]bool{}
	for _, c := range conns {
		// Include only endpoints from the game's own TCP table, e.g. a relay.
		s := fmt.Sprintf("(host %s and port %d)", c.remote.Addr(), c.remote.Port())
		if c.remote.Port() != 13328 && !seen[s] {
			parts = append(parts, s)
			seen[s] = true
		}
	}
	return "tcp and (" + strings.Join(parts, " or ") + ")"
}

func capture(forced string, e *engine) error {
	a, err := loadPcap()
	if err != nil {
		return err
	}
	defer a.dll.Release()
	stop := make(chan struct{})
	go func() {
		r := bufio.NewScanner(os.Stdin)
		for r.Scan() {
			if strings.TrimSpace(r.Text()) == "q" {
				break
			}
		}
		close(stop)
	}()
	var dev adapter
	var conns []gameConnection
	deadline := time.Now().Add(20 * time.Second)
	for {
		select {
		case <-stop:
			return nil
		default:
		}
		all, err := a.devices()
		if err != nil {
			return fmt.Errorf("Npcap adapters: %w", err)
		}
		conns, err = gameConnections()
		if err != nil {
			return err
		}
		if found, ok := chooseAdapter(all, conns, forced); ok {
			dev = found
			break
		}
		e.out.send(map[string]any{"type": "status", "message": "waiting for AION2 connection / matching Npcap adapter"})
		if time.Now().After(deadline) {
			return errors.New("AION2 connection/adapter not found in 20 s; game must be running; check Npcap and VPN")
		}
		time.Sleep(500 * time.Millisecond)
	}
	filter := bpf(conns)
	h, err := a.open(dev, filter)
	if err != nil {
		return err
	}
	defer a.close.Call(h)
	link, _, _ := a.datalink.Call(h)
	e.out.send(map[string]any{"type": "status", "message": "capturing", "device": dev.description, "link": link})
	lastStatus := time.Now()
	lastCheck := lastStatus
	for {
		select {
		case <-stop:
			return nil
		default:
		}
		var head *pcapHeader
		var data *byte
		r, _, _ := a.next.Call(h, uintptr(unsafe.Pointer(&head)), uintptr(unsafe.Pointer(&data)))
		switch int32(r) {
		case 1:
			if head == nil || data == nil || head.caplen > 1<<20 {
				return errors.New("invalid Npcap packet header")
			}
			if head.caplen < head.length {
				return errors.New("truncated Npcap packet; capture must restart")
			}
			stamp := int64(head.seconds)*1000 + int64(head.micros)/1000
			if err := e.packet(stamp, int(link), unsafe.Slice(data, int(head.caplen))); err != nil {
				return err
			}
		case 0:
			time.Sleep(5 * time.Millisecond)
		case -2:
			return nil
		default:
			return fmt.Errorf("Npcap read: %s", a.message(h))
		}
		if time.Since(lastStatus) >= time.Second {
			var st [32]byte
			r, _, _ := a.stats.Call(h, uintptr(unsafe.Pointer(&st[0])))
			var drops uint32
			if int32(r) == 0 {
				drops = *(*uint32)(unsafe.Pointer(&st[4])) + *(*uint32)(unsafe.Pointer(&st[8]))
			}
			if err := e.status(dev.description, drops); err != nil {
				return err
			}
			if drops > 0 {
				return errors.New("Npcap dropped packets; current collection state is no longer reliable")
			}
			lastStatus = time.Now()
		}
		if time.Since(lastCheck) > 2*time.Second {
			if e.serverFresh(time.Now().UnixMilli()) {
				lastCheck = time.Now()
				continue
			}
			current, err := gameConnections()
			if err != nil {
				return err
			}
			all, err := a.devices()
			if err != nil {
				return err
			}
			selected, ok := chooseAdapter(all, current, forced)
			if !ok || selected.name != dev.name {
				return errors.New("game connection / VPN adapter changed; stop and start scanner to reopen capture")
			}
			// An auxiliary endpoint disappearing does not invalidate this filter:
			// it always retains the game port. Do not stop for chat/HTTP churn.
			lastCheck = time.Now()
		}
	}
}
