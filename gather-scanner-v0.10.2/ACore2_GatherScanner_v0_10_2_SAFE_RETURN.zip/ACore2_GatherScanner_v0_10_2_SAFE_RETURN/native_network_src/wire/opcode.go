package wire

import (
	"encoding/binary"
	"encoding/hex"
	"fmt"
)

// Opcode is the two bytes that begin a frame's body, read little-endian: wire bytes 04 38 are 0x3804. The high byte is the family.
type Opcode uint16

// opcode reads the opcode at the start of b.
func opcode(b []byte) Opcode { return Opcode(binary.LittleEndian.Uint16(b)) }

// Bytes returns the opcode's two bytes in wire order.
func (o Opcode) Bytes() [2]byte { return [2]byte{byte(o), byte(o >> 8)} }

// String is the opcode in wire order, "04 38".
func (o Opcode) String() string { return fmt.Sprintf("%02X %02X", byte(o), byte(o>>8)) }

// MarshalText is String.
func (o Opcode) MarshalText() ([]byte, error) { return []byte(o.String()), nil }

// UnmarshalText reads the form String writes, "04 38", in either case.
func (o *Opcode) UnmarshalText(b []byte) error {
	var p [2]byte
	if len(b) != 5 || b[2] != ' ' {
		return fmt.Errorf("wire: opcode %q is not two hex bytes, like \"04 38\"", b)
	}
	if _, err := hex.Decode(p[:], []byte{b[0], b[1], b[3], b[4]}); err != nil {
		return fmt.Errorf("wire: opcode %q: %w", b, err)
	}
	*o = opcode(p[:])
	return nil
}

// Known reports whether o is in the table of known opcodes.
func (o Opcode) Known() bool { return knownBits[o>>6]&(1<<(o&63)) != 0 }

// knownBits is known as a bitmap, one bit an opcode.
var knownBits = func() (bits [1 << 10]uint64) {
	for _, o := range known {
		bits[o>>6] |= 1 << (o & 63)
	}
	return bits
}()

// known lists the opcodes the lock counts and KnownOnly keeps
var known = [...]Opcode{
	0x3804, 0x3805, 0x3802, 0x3806, 0x3822, 0x382A, 0x382B, 0x382C, 0x3835, 0x3847, 0x3817,
	0x3603, 0x361A, 0x3623, 0x3633, 0x3634, 0x3640, 0x3641, 0x3642, 0x3645, 0x3646, 0x3647, 0x3649, 0x364A, 0x3656,
	0x3600, // Server tick
	0x371A, 0x371B, 0x371C,
	0x561D,
	0x8D00, 0x8D04, 0x8D21,
	0x921B, 0x9200, 0x920D,
	0x3901, 0x3903, 0x3906, 0x3909, 0x390B, 0x390D, 0x390F, // Lobby opcodes
}

// inFamily reports whether b, an opcode's high byte, is one of the families. Unless KnownOnly
// is set, an opcode in a family is plausible. Every known opcode is in one.
func inFamily(b byte) bool {
	switch b {
	case 0x36, 0x37, 0x38, 0x39, 0x56, 0x8A, 0x8D, 0x92, 0x96, 0x97:
		return true
	}
	return false
}

// combat reports whether o is damage: 04 38, or damage over time, 05 38.
func combat(o Opcode) bool { return o == 0x3804 || o == 0x3805 }
