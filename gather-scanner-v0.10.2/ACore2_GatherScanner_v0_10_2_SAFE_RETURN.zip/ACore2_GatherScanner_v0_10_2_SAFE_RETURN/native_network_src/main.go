// ACore2 passive network module. Only Npcap reads and local stdout writes.
// Protocol decoder: vendored MIT a2kit wire; see LICENSE and UPSTREAM.md.
package main

import (
	"bufio"
	"encoding/hex"
	"encoding/json"
	"errors"
	"flag"
	"fmt"
	"io"
	"os"
	"sync"
	"time"

	"acore2.local/network/wire"
)

type output struct {
	mu  sync.Mutex
	enc *json.Encoder
}

func (o *output) send(v any) error { o.mu.Lock(); defer o.mu.Unlock(); return o.enc.Encode(v) }

type engine struct {
	decoder   *wire.Decoder
	out       *output
	flow      int
	locks     int
	frames    int64
	packets   int64
	gaps      int
	failed    bool
	lastStamp int64
}

func newEngine(out *output) *engine {
	return &engine{decoder: wire.NewDecoder(wire.Config{}), out: out}
}

func (e *engine) packet(stamp int64, link int, data []byte) error {
	e.packets++
	s, ok := peel(link, data)
	if !ok {
		return nil
	}
	s.Time = time.UnixMilli(stamp)
	e.decoder.FeedSegment(s)
	return e.drain()
}

func (e *engine) drain() error {
	st := e.decoder.Stats()
	if st.Gaps > e.gaps {
		e.failed = true
		return errors.New("TCP capture gap: capture lost bytes; stop and restart the scanner")
	}
	e.gaps = st.Gaps
	if st.Locks != e.locks {
		e.locks = st.Locks
		e.flow++
	}
	for f := range e.decoder.Frames() {
		if f.Flags&wire.FromServer == 0 {
			continue
		}
		op := f.Opcode.Bytes()
		e.frames++
		// Encoder writes directly to the pipe. No buffered file or 10 s flush.
		stamp := f.Time.UnixMilli()
		if stamp < e.lastStamp {
			stamp = e.lastStamp
		}
		e.lastStamp = stamp
		if err := e.out.send(map[string]any{"type": "frame", "t": stamp,
			"flow": e.flow, "op": fmt.Sprintf("%02x%02x", op[0], op[1]),
			"hex": hex.EncodeToString(f.Payload), "n": e.frames}); err != nil {
			return err
		}
	}
	return nil
}

func (e *engine) status(device string, dropped uint32) error {
	st := e.decoder.Stats()
	return e.out.send(map[string]any{"type": "status", "device": device,
		"packets": e.packets, "frames": e.frames, "locked": st.Locked,
		"gaps": st.Gaps, "resyncs": st.Resyncs, "dropped": dropped})
}

// A live decoded server stream is stronger evidence than the auxiliary TCP
// connections list (chat/HTTP/launcher relays routinely appear/disappear).
func (e *engine) serverFresh(now int64) bool {
	return e.decoder.Stats().Locked && e.lastStamp > 0 && now-e.lastStamp >= -500 && now-e.lastStamp <= 2500
}

func replay(in io.Reader, e *engine) error {
	scanner := bufio.NewScanner(in)
	scanner.Buffer(make([]byte, 65536), 4<<20)
	for scanner.Scan() {
		var row struct {
			T    int64  `json:"t"`
			Link int    `json:"link"`
			Hex  string `json:"hex"`
		}
		if err := json.Unmarshal(scanner.Bytes(), &row); err != nil {
			return err
		}
		b, err := hex.DecodeString(row.Hex)
		if err != nil {
			return err
		}
		if err = e.packet(row.T, row.Link, b); err != nil {
			return err
		}
	}
	if err := scanner.Err(); err != nil {
		return err
	}
	e.decoder.Flush()
	if err := e.drain(); err != nil {
		return err
	}
	return e.status("offline replay", 0)
}

func main() {
	replayMode := flag.Bool("stdin-packets", false, "offline packet replay; never opens a capture device")
	device := flag.String("device", "", "optional exact Npcap adapter name")
	flag.Parse()
	out := &output{enc: json.NewEncoder(os.Stdout)}
	out.send(map[string]any{"type": "hello", "protocol": 1, "module": "ACore2 integrated passive network"})
	e := newEngine(out)
	var err error
	if *replayMode {
		err = replay(os.Stdin, e)
	} else {
		err = capture(*device, e)
	}
	if err != nil {
		out.send(map[string]any{"type": "error", "message": err.Error()})
		os.Exit(1)
	}
}
