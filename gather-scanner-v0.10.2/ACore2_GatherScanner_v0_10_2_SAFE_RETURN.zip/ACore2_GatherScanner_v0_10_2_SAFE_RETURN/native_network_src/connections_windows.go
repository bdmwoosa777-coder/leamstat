//go:build windows

package main

import (
	"encoding/binary"
	"fmt"
	"net/netip"
	"sort"
	"strings"
	"syscall"
	"unsafe"
)

type gameConnection struct{ local, remote netip.AddrPort }
type processEntry struct {
	size, usage, pid        uint32
	heap                    uintptr
	module, threads, parent uint32
	priority                int32
	flags                   uint32
	exe                     [260]uint16
}

func gamePIDs() (map[uint32]bool, error) {
	k := syscall.NewLazyDLL("kernel32.dll")
	snap := k.NewProc("CreateToolhelp32Snapshot")
	first := k.NewProc("Process32FirstW")
	next := k.NewProc("Process32NextW")
	close := k.NewProc("CloseHandle")
	h, _, err := snap.Call(2, 0)
	if h == ^uintptr(0) {
		return nil, fmt.Errorf("process list: %w", err)
	}
	defer close.Call(h)
	p := processEntry{}
	p.size = uint32(unsafe.Sizeof(p))
	ids := map[uint32]bool{}
	r, _, _ := first.Call(h, uintptr(unsafe.Pointer(&p)))
	for r != 0 {
		name := strings.ToLower(syscall.UTF16ToString(p.exe[:]))
		if strings.HasPrefix(name, "aion2") && strings.HasSuffix(name, ".exe") {
			ids[p.pid] = true
		}
		r, _, _ = next.Call(h, uintptr(unsafe.Pointer(&p)))
	}
	return ids, nil
}
func gameConnections() ([]gameConnection, error) {
	pids, err := gamePIDs()
	if err != nil {
		return nil, err
	}
	proc := syscall.NewLazyDLL("iphlpapi.dll").NewProc("GetExtendedTcpTable")
	var out []gameConnection
	for _, family := range []uintptr{2, 23} {
		var size uint32
		r, _, _ := proc.Call(0, uintptr(unsafe.Pointer(&size)), 0, family, 5, 0)
		if r != 0 && r != 122 {
			return nil, fmt.Errorf("TCP table query failed: %d", r)
		}
		if size < 4 || size > 16<<20 {
			continue
		}
		b := make([]byte, size)
		r, _, _ = proc.Call(uintptr(unsafe.Pointer(&b[0])), uintptr(unsafe.Pointer(&size)), 0, family, 5, 0)
		if r == 122 {
			continue
		}
		if r != 0 {
			return nil, fmt.Errorf("TCP table read failed: %d", r)
		}
		count := int(binary.LittleEndian.Uint32(b))
		rowSize := 24
		if family == 23 {
			rowSize = 56
		}
		if count > (len(b)-4)/rowSize {
			return nil, fmt.Errorf("truncated TCP table")
		}
		for i := 0; i < count; i++ {
			row := b[4+i*rowSize : 4+(i+1)*rowSize]
			if !pids[binary.LittleEndian.Uint32(row[rowSize-4:])] {
				continue
			}
			var local, remote netip.Addr
			var lp, rp uint16
			var state uint32
			if family == 2 {
				state = binary.LittleEndian.Uint32(row)
				local = netip.AddrFrom4([4]byte(row[4:8]))
				lp = binary.BigEndian.Uint16(row[8:10])
				remote = netip.AddrFrom4([4]byte(row[12:16]))
				rp = binary.BigEndian.Uint16(row[16:18])
			} else {
				local = netip.AddrFrom16([16]byte(row[0:16]))
				lp = binary.BigEndian.Uint16(row[20:22])
				remote = netip.AddrFrom16([16]byte(row[24:40]))
				rp = binary.BigEndian.Uint16(row[44:46])
				state = binary.LittleEndian.Uint32(row[48:52])
			}
			if state == 5 && rp > 0 {
				out = append(out, gameConnection{netip.AddrPortFrom(local.Unmap(), lp), netip.AddrPortFrom(remote.Unmap(), rp)})
			}
		}
	}
	sort.Slice(out, func(i, j int) bool {
		return out[i].local.String()+out[i].remote.String() < out[j].local.String()+out[j].remote.String()
	})
	return out, nil
}
