"""Remember useful areas only when fresh server XYZ support real ground progress."""
import math
from collections import deque

class WorkingAreaMemory:
 def __init__(self):self.key=None;self.seen=None;self.candidate=None;self.area=None;self.samples=0;self.last_position_stamp=None;self.motion=deque()
 def update(self,view,reading,now_ms,ground_result=False):
  if not view or not view['ready']:return False
  state=view['state'];key=(view['flow'],state.own,state.map_id)
  if key!=self.key:
   self.key=key;self.seen=None;self.candidate=None;self.area=None;self.samples=0;self.last_position_stamp=None;self.motion.clear()
  if state.own is None or state.map_id is None or state.xyz is None or state.position_at is None:return False
  if not -.1<=(now_ms-state.position_at)/1000<=.8 or not all(math.isfinite(x) for x in state.xyz):return False
  if reading.confirmed:self.motion.clear()
  elif not self.motion or self.motion[-1][0]!=state.position_at:
   self.motion.append((state.position_at,tuple(state.xyz)))
   while self.motion and state.position_at-self.motion[0][0]>2000:self.motion.popleft()
  result=state.last_own_result
  if ground_result and result and (self.seen is None or result[1]>self.seen) and -.1<=(now_ms-result[1])/1000<=2:
   self.seen=result[1]
   if not reading.confirmed:self.candidate=(tuple(state.xyz),now_ms);self.samples=0;self.last_position_stamp=state.position_at
  if reading.confirmed:self.candidate=None;return False
  if self.candidate is None:return False
  position,stamp=self.candidate
  if now_ms-stamp>20000:self.candidate=None;return False
  if self.last_position_stamp==state.position_at:return False
  self.last_position_stamp=state.position_at
  distance=math.dist(position[:2],state.xyz[:2])/100
  if abs(position[2]-state.xyz[2])/100>1.2:self.candidate=None;return False
  self.samples+=1
  if distance>=2 and self.samples>=3:
   self.area=(tuple(state.xyz),now_ms);self.candidate=None;return True
  return False
 def bearing(self,view,now_ms):
  if not self.area or not view or not view['ready']:return None
  s=view['state']
  if ((view['flow'],s.own,s.map_id)!=self.key or s.xyz is None or s.position_at is None
      or not 0<=now_ms-self.area[1]<=300000 or not -.1<=(now_ms-s.position_at)/1000<=.8):return None
  if not all(math.isfinite(x) for x in s.xyz):return None
  xyz,_=self.area;dx,dy=xyz[0]-s.xyz[0],xyz[1]-s.xyz[1]
  if math.hypot(dx,dy)>20000:return None
  return math.degrees(math.atan2(dx,-dy))%360

 def height_gap(self,view,now_ms):
  if self.bearing(view,now_ms) is None:return None
  return (self.area[0][2]-view['state'].xyz[2])/100

 def rapid_drop(self,now_ms):
  if len(self.motion)<2 or not 0<=now_ms-self.motion[-1][0]<=800:return False
  return (max(xyz[2] for stamp,xyz in self.motion)-self.motion[-1][1][2])/100>=8
