"""Small camera viewpoints share one deadline across select/approach retries."""
from dataclasses import dataclass

# Each pulse is only a small offset. The full sequence returns both axes.
VIEW_PULSES=((.30,0,.12),(0,.30,.10),(-.30,0,.12),(-.30,0,.12),
             (0,-.30,.10),(0,-.30,.10),(.30,0,.12),(0,.30,.10))

@dataclass
class ResourceViewRecovery:
    binding:tuple
    until:float
    next_at:float
    step:int=0
    settle_until:float=0
    paused_at:float|None=None
    point_attempt_at:float|None=None
