"""Regressions for full-HP Tab spam, Alt refresh misses and lost resource state."""
import unittest,time
from unittest.mock import patch
from pathlib import Path
import cv2
import numpy as np
from test_navigation import GatherFixture,obs
from test_reference_crops import canvas
from health import HealthMonitor,HPReading
from flight import FlightReading
from gamepad_input import GamepadInput
from vision import find_world_resource,find_resource_near,gathering_panel_pair
import gather_engine as ge

ROOT=Path(__file__).resolve().parent
HIDDEN=FlightReading(None,False)

class VerifiedDamageTests(GatherFixture,unittest.TestCase):
    def worker(self,readings):
        def wait(*args):self.e.stop_event.set()
        with patch.object(ge,'read_hp',side_effect=readings) as reader,patch.object(self.e.health.suspect_ready,'wait',side_effect=wait):
            self.e._health_numeric_loop()
        return reader

    def test_repeated_full_hp_18442_cannot_trigger_defense_from_pixel_noise(self):
        image=np.zeros((30,110,3),np.uint8)
        for i in range(5):image[2:12,i*20+4:i*20+14]=255
        self.e.health.numeric(image,HPReading(18442,18442,(0,0,100,15)),99)
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.mode='APPROACH'
        with patch.object(self.e,'_defend_and_resume') as defend:
            for i in range(30):
                changed=image.copy();changed[4:6,86:88]=0;t=100+i*.3
                self.e.health.fast(changed,t);self.e.health.fast(image,t+.05)
                self.e.health.numeric(image,HPReading(18442,18442),t+.1,verified=False)
                self.e._check_route_damage(self.frame,t+.12,panel=False,slots=3)
        defend.assert_not_called();self.assertEqual(self.e.health.sequence,0)

    def test_disagreeing_numeric_ocr_cannot_authorize_tab(self):
        self.worker([HPReading(18441,18442),HPReading(18442,18442)])
        self.assertEqual(self.e.health.sequence,0);self.assertEqual(self.e.health.unverified_low,1)

    def test_two_numeric_reads_of_one_hp_loss_latch_after_regeneration(self):
        reader=self.worker([HPReading(18441,18442),HPReading(18441,18442)])
        self.assertEqual(reader.call_count,2)
        stamp=time.monotonic();self.e.health.numeric(self.frame,HPReading(18442,18442),stamp)
        self.assertTrue(self.e.health.pending(0,stamp));self.assertEqual(self.e.health.damage_current,18441)

    def test_a_saved_changed_frame_is_checked_even_if_live_hp_is_full_again(self):
        old=np.ones_like(self.frame);self.e.health.request_check(old,time.monotonic())
        reader=self.worker([HPReading(18441,18442),HPReading(18441,18442)])
        for call in reader.call_args_list:self.assertTrue(np.array_equal(call.args[0],old))
        self.assertEqual(self.e.health.sequence,1)

    def test_steady_low_hp_does_not_generate_new_damage_every_ocr_cycle(self):
        h=HealthMonitor()
        for i in range(10):h.numeric(self.frame,HPReading(18441,18442),i*.2)
        self.assertEqual(h.sequence,1)

    def test_maximum_change_is_compared_to_current_right_hand_value(self):
        h=HealthMonitor();h.numeric(self.frame,HPReading(18442,18442),0);h.begin_gather()
        h.numeric(self.frame,HPReading(18000,18000),1)
        self.assertEqual(h.sequence,0)

class TargetRecoveryTests(GatherFixture,unittest.TestCase):
    def selected(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode='APPROACH';self.e.started=99;self.e.last_progress=100
        self.e._reset_resource_watch(verified_header=True)
        self.e.panel_cleared=True

    def test_first_alt_refresh_miss_retries_fresh_frame_before_clicking(self):
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(ge,'find_resource_near',return_value=None),patch.object(ge,'find_world_resource',side_effect=[None,self.c]) as find,patch.object(ge,'selected_target',return_value=('Сапфир',30)):
            self.assertTrue(self.e.click_candidate(self.c,(0,0)))
        self.assertEqual(find.call_count,2);self.assertEqual(self.pad.presses,1)
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP','TAP_F'])

    def test_three_fresh_caption_misses_never_click_old_coordinates(self):
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(ge,'find_resource_near',return_value=None),patch.object(ge,'find_world_resource',return_value=None) as find:
            self.assertFalse(self.e.click_candidate(self.c,(0,0)))
        self.assertEqual(find.call_count,3);self.assertEqual(self.pad.presses,0)
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP'])

    def test_failed_acquisition_preserves_minimap_goal_and_avoids_long_exclusion(self):
        from minimap import Marker
        goal=Marker('Самоцвет',140,100,.9,40);self.e.nav.goal=goal
        self.e._acquire_miss(self.c,100)
        self.assertIs(self.e.nav.goal,goal);self.assertFalse(self.e.nav.is_retreating(100))
        self.assertEqual(self.e.cooldowns,[]);self.assertEqual(self.e.mode,'SEARCH')

    def test_target_loss_clears_every_permission_before_reacquisition(self):
        self.selected();self.e.collecting_visible=True;self.e.f_repeat_allowed=True;self.e.f_on=True
        self.e.route_active=True;self.e.candidate=self.c
        self.e._begin_reacquire('target changed')
        self.assertEqual(self.e.mode,'REACQUIRE');self.assertFalse(self.e.target_confirmed)
        self.assertFalse(self.e.resource_hold);self.assertFalse(self.e.f_repeat_allowed)
        self.assertFalse(self.e.route_active);self.assertFalse(self.e.collecting_visible)
        self.e.f_enable();self.assertEqual(self.commands,['F_OFF'])

    def test_red_target_reacquires_resource_without_tab_or_attack(self):
        self.selected();self.e.f_on=True
        with patch.object(ge,'enemy_hp',return_value=(True,500)):
            self.e._resource_fast_tick(self.frame,HIDDEN,100,panel=False,slots=None)
        self.assertEqual(self.e.mode,'REACQUIRE');self.assertEqual(self.commands,['F_OFF'])

    def test_reacquisition_timeout_folds_owned_flight_without_waiting_for_ocr(self):
        self.selected();self.e.target='Эфир';self.e.resource_flight_owned=True
        self.e._begin_reacquire('lost');deadline=self.e.reacquire_until
        self.e._resource_fast_tick(self.frame,FlightReading(50,True),deadline+.1,panel=False,slots=None)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIn('END_AIR',self.commands)
        self.assertIsNotNone(self.e.wing_close_pending);self.assertFalse(self.e.target_confirmed)

    def test_remaining_resource_keeps_f_repeat_without_timer_restart(self):
        self.selected();self.e._start_resource_route()
        self.step(obs('Сапфир',distance=1),100,plate=3,panel=True)
        with patch.object(ge,'selected_target',return_value=('Сапфир',1)):
            self.step(obs('Сапфир',distance=1),102,plate=2)
            self.step(obs('Сапфир',distance=1),103,plate=2)
        self.assertEqual(self.commands,['TAP_F','F_ON'])
        self.assertEqual(self.e.mode,'GATHER');self.assertTrue(self.e.target_confirmed)

    def test_ambiguous_identity_cannot_rearm_f_or_send_tab(self):
        self.selected();self.e._start_resource_route()
        self.step(obs('Сапфир',distance=1),100,plate=3,panel=True)
        with patch.object(ge,'selected_target',return_value=(None,None)):
            self.step(obs('Сапфир',distance=1),102,plate=2)
        self.assertEqual(self.commands,['TAP_F','F_ON'])

    def test_reacquisition_wait_cannot_keep_a_stale_gather_mode(self):
        self.selected();self.e.collecting_visible=True;self.e._begin_reacquire('lost')
        self.e.return_to_search('not found',reading=HIDDEN)
        self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.f_on)

class RecognitionRecoveryTests(unittest.TestCase):
    def test_actual_faint_caption_near_left_edge_and_below_old_roi(self):
        for x,y in ((120,335),(1160,920)):
            with self.subTest(x=x,y=y):
                frame=canvas('far_sapphire_crop.png',x,y);found=find_world_resource(frame)
                self.assertIsNotNone(found);self.assertEqual(found.name,'Сапфир')
                local=find_resource_near(frame,found);self.assertIsNotNone(local)
                self.assertEqual((found.click_x,found.click_y),(local.click_x,local.click_y))
                self.assertIsNone(find_resource_near(np.zeros_like(frame),found))

    def panel(self,scale=1,paired=True):
        image=np.zeros((1438,2558,3),np.uint8)
        for file,y in [('gather_failure_label.png',1170),('gather_success_label.png',1125)]:
            if not paired and 'success' in file:continue
            label=cv2.imread(str(ROOT/'assets'/file),0);label=cv2.resize(label,None,fx=scale,fy=scale,interpolation=cv2.INTER_AREA)
            patch=image[y:y+label.shape[0],1150:1150+label.shape[1]];patch[:]=label[:,:,None]
        return image

    def test_shifted_gather_panel_at_multiple_ui_scales(self):
        for scale in (.75,1,1.3):
            with self.subTest(scale=scale):self.assertTrue(gathering_panel_pair(self.panel(scale)))

    def test_failure_label_alone_is_insufficient_for_broad_roi_fallback(self):
        self.assertFalse(gathering_panel_pair(self.panel(paired=False)))
        self.assertFalse(gathering_panel_pair(np.zeros((720,1280,3),np.uint8)))

if __name__=='__main__':unittest.main()
