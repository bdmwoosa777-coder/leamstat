"""One-time calibration from the user's actual game image, in game-client coordinates."""
from pathlib import Path
import time
import cv2
from PIL import Image, ImageTk
import tkinter as tk
from tkinter import ttk, messagebox

ROOT=Path(__file__).resolve().parent


class MinimapSetup:
    def __init__(self,parent,frame,cfg,on_save):
        self.frame,self.cfg,self.on_save=frame,cfg,on_save
        self.stage=0;self.start=None;self.rect=None
        self.window=tk.Toplevel(parent);self.window.title('Настройка миникарты')
        sw=min(1400,parent.winfo_screenwidth()-100)
        sh=min(820,parent.winfo_screenheight()-180)
        self.scale=min(sw/frame.shape[1],sh/frame.shape[0],1.0)
        img=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB))
        img=img.resize((round(img.width*self.scale),round(img.height*self.scale)))
        self.photo=ImageTk.PhotoImage(img)
        self.label=ttk.Label(self.window,text='1/3: протяните прямоугольник ТОЛЬКО вокруг области миникарты (без заголовка/кнопок).')
        self.label.pack(anchor='w',padx=8,pady=6)
        options=ttk.Frame(self.window);options.pack(fill='x',padx=8)
        ttk.Label(options,text='Тип иконки:').pack(side='left')
        self.name=tk.StringVar(value='Ресурс')
        ttk.Combobox(options,textvariable=self.name,values=['Ресурс']+list(cfg['target_names']),state='readonly',width=16).pack(side='left')
        ttk.Label(options,text='«Ресурс» — общий значок; название объекта затем проверяется OCR.').pack(side='left',padx=8)
        self.canvas=tk.Canvas(self.window,width=img.width,height=img.height,cursor='crosshair')
        self.canvas.pack();self.canvas.create_image(0,0,anchor='nw',image=self.photo)
        self.canvas.bind('<ButtonPress-1>',self.down)
        self.canvas.bind('<B1-Motion>',self.drag)
        self.canvas.bind('<ButtonRelease-1>',self.up)

    def point(self,event):
        return (max(0,min(self.frame.shape[1]-1,round(event.x/self.scale))),
                max(0,min(self.frame.shape[0]-1,round(event.y/self.scale))))

    def down(self,event):
        self.start=self.point(event)
        if self.stage==1:
            x,y=self.start;x0,y0,x1,y1=self.roi
            if not(x0<=x<x1 and y0<=y<y1):return
            self.player=[(x-x0)/(x1-x0),(y-y0)/(y1-y0)]
            self.stage=2
            self.label.config(text='3/3: обведите ОДНУ иконку ресурса на миникарте, плотно, без соседних значков.')
            self.start=None
            return
        if self.rect:self.canvas.delete(self.rect)
        self.rect=self.canvas.create_rectangle(event.x,event.y,event.x,event.y,outline='#00ffff',width=2)

    def drag(self,event):
        if self.start and self.stage!=1 and self.rect:
            x,y=self.start
            self.canvas.coords(self.rect,x*self.scale,y*self.scale,event.x,event.y)

    def up(self,event):
        if self.start is None or self.stage==1:return
        a,b=self.start;self.start=None;c,d=self.point(event)
        x0,x1=sorted((a,c));y0,y1=sorted((b,d))
        if self.stage==0:
            if x1-x0<60 or y1-y0<60:return
            self.roi=(x0,y0,x1,y1);self.stage=1
            self.label.config(text='2/3: щёлкните по центру значка ВАШЕГО персонажа на миникарте.')
            return
        rx0,ry0,rx1,ry1=self.roi
        if not(rx0<=x0<x1<=rx1 and ry0<=y0<y1<=ry1) or min(x1-x0,y1-y0)<5:
            messagebox.showerror('Иконка','Выберите иконку внутри миникарты, размером не меньше 5×5.',parent=self.window);return
        crop=self.frame[y0:y1,x0:x1]
        if cv2.countNonZero(cv2.Canny(cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY),55,135))<8:
            messagebox.showerror('Иконка','В выделении недостаточно деталей. Обведите значок целиком.',parent=self.window);return
        folder=ROOT/'assets/minimap';folder.mkdir(parents=True,exist_ok=True)
        file=folder/f'icon_{time.time_ns()}.png'
        if not cv2.imwrite(str(file),crop):raise OSError('Не удалось сохранить иконку')
        h,w=self.frame.shape[:2];rx0,ry0,rx1,ry1=self.roi
        roi=[rx0/w,ry0/h,(rx1-rx0)/w,(ry1-ry0)/h]
        # New geometry replaces old templates so samples from another UI scale aren't mixed.
        templates=list(self.cfg.get('minimap_templates',[])) if self.cfg.get('minimap_roi')==roi else []
        templates.append({'name':self.name.get(),'file':file.relative_to(ROOT).as_posix()})
        self.cfg.update(minimap_roi=roi,minimap_player=self.player,
                        minimap_reference_size=[w,h],minimap_templates=templates,minimap_search=True)
        self.on_save();self.window.destroy()
