import threading,unittest
from unittest.mock import patch
import cv2,numpy as np
import gather_engine as ge
from gamepad_input import GamepadInput
from idle_return import NoYieldWatch,ReturnSequence,MapEvidence,map_evidence,changed
from flight import FlightReading
from test_navigation import GatherFixture,Pad,obs,radar
from test_network_control import Source

GROUND=FlightReading(None,False);AIR=FlightReading(80,True)

class IdleWatchTests(unittest.TestCase):
    def test_three_minutes_without_result_is_independent_of_motion(self):
        w=NoYieldWatch();w.observe(0,(1,7))
        for t in range(1,180):w.observe(t,(1,7));self.assertFalse(w.return_due(t))
        w.observe(180,(1,7));self.assertTrue(w.return_due(180));self.assertTrue(w.rescue_due())
    def test_only_new_own_result_resets_progress_not_selection_or_attempt(self):
        w=NoYieldWatch();w.observe(0,(1,7));w.observe(170,(1,7),(99,1000))
        self.assertEqual(w.idle,0);w.observe(180,(1,7),(99,1000));self.assertEqual(w.idle,10)
        w.observe(190,(1,7),(99,999));self.assertEqual(w.idle,20)
    def test_pause_excludes_time_in_another_window(self):
        w=NoYieldWatch();w.observe(0,(1,7));w.observe(50,(1,7));w.pause();w.observe(1000,(1,7))
        self.assertEqual(w.idle,50)
    def test_rescue_once_per_gap_does_not_postpone_return(self):
        w=NoYieldWatch();w.observe(0,(1,7));w.observe(90,(1,7));self.assertTrue(w.rescue_due())
        w.rescue_used=True;w.observe(180,(1,7));self.assertFalse(w.rescue_due());self.assertTrue(w.return_due(180))
    def test_one_attempt_sets_cooldown_but_does_not_invent_resource_progress(self):
        w=NoYieldWatch();w.observe(0,(1,7));w.observe(180,(1,7));w.attempted(180)
        self.assertEqual(w.idle,180);self.assertFalse(w.return_due(181));self.assertTrue(w.return_due(360))
        w.relocated(200);self.assertEqual(w.idle,0)
    def test_initial_identity_discovery_does_not_reset_idle(self):
        w=NoYieldWatch();w.observe(0,(1,None));w.observe(100,(1,7));self.assertEqual(w.idle,100)

class ReturnPolicyTests(unittest.TestCase):
    def ground_use(self):
        s=ReturnSequence(0);self.assertIsNotNone(s.step(0,False).drive)
        s.step(.4,False);self.assertEqual(s.step(1,False).command,'RETURN');return s
    def test_ground_scroll_is_requested_once_then_waits_fifteen_seconds(self):
        s=self.ground_use();s.sent(1.2)
        for t in (2,5,10,15):self.assertIsNone(s.step(t,False,MapEvidence(usable=True)).command)
        a=s.step(16.3,False,MapEvidence(usable=True));self.assertTrue(a.done);self.assertFalse(a.verified)
    def test_new_purple_marker_confirms_arrival_after_cast_and_stability(self):
        s=self.ground_use();s.baseline=MapEvidence(usable=True,purple=False)
        self.assertFalse(s.step(5,False,MapEvidence(usable=True,purple=True)).done)
        self.assertFalse(s.step(8,False,MapEvidence(usable=True,purple=True)).done)
        self.assertTrue(s.step(8.7,False,MapEvidence(usable=True,purple=True)).verified)
    def test_old_purple_marker_alone_does_not_confirm_a_teleport(self):
        s=self.ground_use();s.baseline=MapEvidence(usable=True,purple=True)
        self.assertFalse(s.step(10,False,MapEvidence(usable=True,purple=True)).verified)
    def test_loading_is_not_followed_by_blind_movement(self):
        s=self.ground_use();a=s.step(20,False,MapEvidence(loading=True))
        self.assertFalse(a.done);self.assertIsNone(a.drive)
        s.step(21,False,MapEvidence(usable=True))
        self.assertTrue(s.step(21.7,False,MapEvidence(usable=True)).verified)
    def test_in_air_fold_and_landing_delay_precede_scroll(self):
        s=ReturnSequence(0,True);s.step(0,True)
        self.assertEqual(s.step(.4,True).command,'END_AIR');s.sent(1.6)
        self.assertIsNone(s.step(2,False).command);self.assertIsNone(s.step(4.9,False).command)
        self.assertEqual(s.step(5.1,False).command,'RETURN')
    def test_failed_landing_never_consumes_scroll_or_halts_by_itself(self):
        s=ReturnSequence(0,True);s.step(0,True);s.step(.4,True)
        self.assertEqual(s.step(3.5,True).command,'END_AIR')
        a=s.step(8.6,True);self.assertTrue(a.done);self.assertTrue(a.failed_landing);self.assertIsNone(a.command)

class ReturnVisionTests(unittest.TestCase):
    def frame(self):
        g=np.tile((np.arange(400)%180+50).astype(np.uint8),(300,1))
        return np.dstack([g,g,g])
    def test_center_purple_obelisk_hint_and_dark_loading(self):
        f=self.frame();cv2.rectangle(f,(194,138),(204,161),(230,60,200),-1)
        self.assertTrue(map_evidence(f,(0,0,400,300)).purple)
        self.assertTrue(map_evidence(np.zeros_like(f),(0,0,400,300)).loading)
    def test_edge_purple_ui_does_not_count_as_nearby_obelisk(self):
        f=self.frame();cv2.rectangle(f,(5,5),(18,28),(230,60,200),-1)
        self.assertFalse(map_evidence(f,(0,0,400,300)).purple)
    def test_real_terrain_change_is_required_not_just_brightness(self):
        f=self.frame();a=map_evidence(f,(0,0,400,300))
        b=map_evidence(cv2.add(f,20),(0,0,400,300));self.assertFalse(changed(a,b))
        c=map_evidence(255-f,(0,0,400,300));self.assertTrue(changed(a,c))

class DpadTests(unittest.TestCase):
    def control(self):
        pad=Pad();reports=[];update=pad.update
        def report():reports.append((pad.buttons,pad.lt,*pad.axes));return update()
        pad.update=report;g=GamepadInput(factory=lambda:pad,a_button=0x1000);self.addCleanup(g.close)
        return g,pad,reports
    def test_dpad_down_is_plain_and_always_released(self):
        g,pad,reports=self.control();g.native_cursor=True;g.cursor_held=True
        pad.buttons=0x0100;pad.lt=1
        with patch.object(GamepadInput,'wait',return_value=True):self.assertTrue(g.tap_dpad_down(threading.Event(),lambda:True))
        self.assertTrue(any(r[0]==2 and r[1]==0 for r in reports));self.assertEqual(pad.buttons,0);self.assertEqual(pad.lt,0)
        self.assertEqual(g.a_down_count,0)
    def test_fresh_resource_guard_prevents_key(self):
        g,pad,reports=self.control()
        self.assertFalse(g.tap_dpad_down(threading.Event(),lambda:True,lambda:False))
        self.assertFalse(any(r[0]&2 for r in reports))

class ReturnEngineTests(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(no_yield_return_enabled=True,terrain_rescue_enabled=True,preserve_owned_resource=True,auto_view_recovery=False)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.collecting=None;self.f.attempt_active=False;self.f.selected=0
        self.clock=100.;self.wall=2000;self.e.no_yield.at=self.clock
        self.e.return_panel_absent=95;self.e.no_yield.idle=180
        g=np.tile((np.arange(1280)%180+50).astype(np.uint8),(720,1));self.frame=np.dstack([g,g,g])
        self.reports=[];update=self.pad.update
        def record():self.reports.append((self.pad.buttons,*self.pad.axes));return update()
        self.pad.update=record
        def wait(seconds,*args):self.clock+=seconds;return True
        for p in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),patch.object(GamepadInput,'wait',side_effect=wait)):
            p.start();self.addCleanup(p.stop)
    def tick(self,dt=0,reading=GROUND):
        self.clock+=dt;self.wall+=int(dt*1000);return self.e._no_yield_tick(self.frame,reading,self.clock)
    def use(self):self.tick();self.tick(.4);self.tick(.6)
    def test_no_results_requests_one_key_and_waits_without_other_input(self):
        self.use();self.assertTrue(any(r[0]==2 for r in self.reports));self.assertEqual(self.e.mode,'RETURN')
        count=sum(r[0]==2 for r in self.reports)
        for _ in range(5):self.tick(1)
        self.assertEqual(sum(r[0]==2 for r in self.reports),count);self.assertEqual(self.pad.axes,(0,0,0,0))
        self.assertFalse({'TAB','TAP_F','F_ON','ATTACK_PAIR'}&set(self.commands));self.assertFalse(self.e.stop_event.is_set())
    def test_fifteen_seconds_without_confirmation_returns_to_guarded_search_not_stop(self):
        self.use();self.tick(16)
        self.assertEqual(self.e.mode,'SEARCH');self.assertTrue(self.e.return_exit_guard)
        self.assertFalse(self.e.stop_event.is_set());self.assertIsNone(self.e.return_sequence)
        self.tick();self.assertIsNone(self.e.return_sequence)
    def test_active_real_collection_blocks_return_scroll(self):
        self.f.collecting=99;self.f.selected=99;self.f.attempt_active=True;self.f.nodes[99].gather_time=self.wall
        self.tick();self.assertIsNone(self.e.return_sequence);self.assertFalse(any(r[0]==2 for r in self.reports))
    def test_actual_lower_panel_blocks_return_even_with_stale_network_active(self):
        with patch.object(ge,'gathering_panel_pair',return_value=True):self.tick()
        self.assertIsNone(self.e.return_sequence)
    def test_new_collection_during_preparation_cancels_return(self):
        self.tick();self.f.collecting=99;self.f.selected=99;self.f.attempt_active=True;self.f.nodes[99].gather_time=self.wall
        self.tick(.4);self.assertIsNone(self.e.return_sequence);self.assertFalse(any(r[0]==2 for r in self.reports))
        self.assertFalse(self.e.stop_event.is_set())
    def test_new_own_result_resets_idle_but_duplicate_does_not(self):
        self.f.last_own_result=(99,self.wall);self.f.last_own_result_used=1
        self.tick();self.assertEqual(self.e.no_yield.idle,0)
        self.tick(20);self.assertEqual(self.e.no_yield.idle,20)
    def test_big_terrain_displacement_does_not_reset_no_yield_rescue(self):
        self.e.no_yield.idle=91;self.e.budget.energy=80
        self.tick();self.assertEqual(self.e.mode,'RESCUE');self.assertTrue(self.e.no_yield.rescue_used)
        self.assertFalse(any(r[0]==2 for r in self.reports))
    def test_post_return_guard_survives_two_ether_results(self):
        self.e.return_exit_guard=True;self.e.target_confirmed=True;self.e.route_f_sent=True
        for used in (1,2):
            self.wall+=100;self.f.last_own_result=(99,self.wall);self.f.last_own_result_used=used;self.tick()
            self.assertTrue(self.e.return_exit_guard)
    def test_post_return_scan_never_runs_straight_off_platform(self):
        self.e.return_exit_guard=True;self.assertTrue(self.e._return_exit_scan(self.clock))
        self.assertEqual(self.pad.axes[:2],(0,0));self.assertNotEqual(self.pad.axes[2],0)
    def test_network_or_focus_loss_cannot_send_return(self):
        self.source.ready=False;self.tick();self.assertFalse(any(r[0]==2 for r in self.reports))
        self.source.ready=True;self.e.screen.focused=lambda:False;self.tick()
        self.assertFalse(any(r[0]==2 for r in self.reports))

    def test_new_resource_approach_gets_only_one_short_return_grace(self):
        self.e.target_confirmed=True;self.e.mode='APPROACH';self.e.native_route_started_at=self.clock
        self.tick();self.assertIsNone(self.e.return_sequence)
        self.tick(5);self.e.native_route_started_at=self.clock
        self.tick(6);self.assertIsNotNone(self.e.return_sequence)
    def test_real_own_result_resets_return_grace(self):
        self.e.return_grace_used=True;self.e.return_grace_until=999
        self.f.last_own_result=(99,self.wall);self.f.last_own_result_used=1
        self.tick();self.assertFalse(self.e.return_grace_used);self.assertEqual(self.e.return_grace_until,0)

if __name__=='__main__':unittest.main()
