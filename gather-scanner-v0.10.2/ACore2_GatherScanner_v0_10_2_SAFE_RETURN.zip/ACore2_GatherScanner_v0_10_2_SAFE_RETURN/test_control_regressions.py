"""No live game required: clicks, attempt boundaries, death races and policy."""
import struct
import time
import json
import tempfile
from pathlib import Path
import unittest
from unittest.mock import patch
import cv2
import numpy as np
import gather_engine as ge
import vision
from flight import FlightBudget,FlightReading
from flight_probe import FlightProbe
from navigation import Drive
from minimap import Marker
from network_state import Telemetry
from resource_policy import ResourcePolicy
from test_navigation import GatherFixture,obs,radar
from test_network_control import Source
from test_network_state import profile,v,gauge


def caption_frame(colour=(120,180,70)):
    frame=np.full((720,1280,3),35,np.uint8)
    mask=cv2.imread(str(vision.ROOT/'assets/name_masks/sapphire.png'),0)
    h,w=mask.shape;frame[250:250+h,600:600+w][mask>100]=colour
    return frame,(600,250,w,h)


class CaptionIdentity(unittest.TestCase):
    def test_diagnostic_report_does_not_serialize_binary_tracking_signature(self):
        import diagnostics
        frame,box=caption_frame();candidate=vision.caption_candidate(frame,'Сапфир',box,95)
        with tempfile.TemporaryDirectory() as directory,patch.object(vision.WorldVision,'scan',return_value=obs(candidate=candidate)),patch.object(diagnostics.MinimapVision,'observe',return_value=radar()),patch.object(diagnostics,'read_hp',return_value=None):
            path=Path(directory)/'report'
            diagnostics.analyze(frame,{'target_names':['Сапфир']},path)
            report=json.loads(path.with_suffix('.json').read_text())
        self.assertEqual(report['vision']['candidate']['name'],'Сапфир')
        self.assertNotIn('glyph',report['vision']['candidate'])

    def test_blue_flag_under_caption_does_not_change_click_position(self):
        frame,box=caption_frame();before=vision.resource_click_point(frame,box,'Сапфир')
        cv2.rectangle(frame,(600,295),(640,370),(230,150,40),-1)
        after=vision.resource_click_point(frame,box,'Сапфир')
        self.assertEqual(before,after);self.assertLess(after[1],295)

    def test_fresh_caption_tracks_locally_without_any_ocr(self):
        frame,box=caption_frame();candidate=vision.caption_candidate(frame,'Сапфир',box,95)
        moved=np.roll(frame,9,axis=1)
        with patch.object(vision.pytesseract,'image_to_string',side_effect=AssertionError('no OCR')):
            found=vision.find_resource_near(moved,candidate)
        self.assertIsNotNone(found);self.assertAlmostEqual(found.click_x,candidate.click_x+9,delta=2)

    def test_yellow_title_with_blue_body_cannot_replace_green_resource_caption(self):
        frame,box=caption_frame();candidate=vision.caption_candidate(frame,'Сапфир',box,95)
        other,_=caption_frame((0,190,230));cv2.rectangle(other,(600,290),(640,360),(230,150,40),-1)
        with patch.object(vision.pytesseract,'image_to_string',side_effect=AssertionError('no OCR')):
            self.assertIsNone(vision.find_resource_near(other,candidate))


class ControlRegressions(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.source=Source();self.e.network=self.source
        self.f=self.source.state;self.f.nodes[99].gather_time=1000
        self.e.network_target=(1,99);self.e.network_claimed_at=900
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.real_gather_panel_seen=True;self.e.mode='GATHER'
        self.wall=1100;self.clock=100.
        for p in (patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),
                  patch.object(ge.time,'monotonic',side_effect=lambda:self.clock)):
            p.start();self.addCleanup(p.stop)

    def test_no_background_f_and_one_request_per_completed_attempt(self):
        self.e.f_enable();self.assertEqual(self.commands,[])
        self.f.attempt_active=False;self.f.nodes[99].used=1
        for i in range(60):self.clock=100+i*.1;self.e.f_enable()
        self.assertEqual(self.commands,['TAP_F'])
        self.f.attempt_active=True
        for i in range(10):self.e.f_enable()
        self.assertEqual(self.commands,['TAP_F'])
        self.f.attempt_active=False;self.f.nodes[99].used=2;self.e.f_enable()
        self.assertEqual(self.commands,['TAP_F','TAP_F']);self.assertNotIn('F_ON',self.commands)

    def test_completed_resource_cannot_request_a_fourth_attempt(self):
        self.f.nodes[99].used=3;self.f.attempt_active=False
        self.assertFalse(self.e.f_enable());self.assertEqual(self.commands,[])

    def test_new_attempt_arriving_during_transmission_revokes_repeat(self):
        self.f.nodes[99].used=1;self.f.attempt_active=False
        def guarded(command,authorize):
            self.f.attempt_active=True
            self.assertFalse(authorize());return False
        self.e.bridge.send_guarded=guarded;self.e.f_enable()
        self.assertIsNone(self.e.next_attempt_sent_used);self.assertEqual(self.commands,[])

    def test_foreign_selection_revokes_next_attempt(self):
        self.f.nodes[99].used=1;self.f.attempt_active=False;self.f.selected=55
        self.assertFalse(self.e.f_enable());self.assertEqual(self.commands,[])

    def test_no_movement_when_internal_mode_lost_collection_flags(self):
        self.e.mode='SEARCH';self.e.resource_hold=False;self.e.collecting_visible=False;self.e.target_confirmed=False
        self.e._motion(Drive(forward=.8));self.assertEqual(self.pad.axes,(0,0,0,0))
        self.f.attempt_active=False;self.e._motion(Drive(strafe=.8))
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertFalse(self.e._wing_action_allowed('V'))

    def test_adoption_requires_no_ocr_and_sends_no_route_f(self):
        self.e.target_confirmed=False;self.e.mode='SEARCH';self.e.target=None
        with patch.object(ge,'selected_target',side_effect=AssertionError('no OCR')):
            self.assertTrue(self.e._adopt_network_collection());self.e.f_enable()
        self.assertEqual(self.e.target,'Сапфир');self.assertEqual(self.commands,[])

    def test_adopting_same_pending_attempt_does_not_send_its_f_again(self):
        self.f.nodes[99].used=1;self.f.attempt_active=False
        self.e.f_enable();self.assertEqual(self.commands,['TAP_F'])
        self.e.target_confirmed=False;self.e.mode='SEARCH'
        self.assertTrue(self.e._adopt_network_collection());self.e.real_gather_panel_seen=True
        self.e.f_enable();self.assertEqual(self.commands,['TAP_F'])

    def test_stale_feed_blocks_final_motion(self):
        self.source.ready=False;self.e._motion(Drive(forward=.8))
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_selected_flag_unknown_or_wrong_resource_is_not_sapphire(self):
        self.e.network_selection_after=1000;self.f.selection_time=1100
        self.f.selected=55;self.assertFalse(self.e._selected_resource(self.source.view(),'Сапфир'))
        self.f.selected=99;self.assertFalse(self.e._selected_resource(self.source.view(),'Эфир'))
        self.assertTrue(self.e._selected_resource(self.source.view(),'Сапфир'))
        self.f.nodes[99].visible=False;self.assertFalse(self.e._selected_resource(self.source.view(),'Сапфир'))

    def test_missing_spawn_profile_requires_new_id_bound_hud_proof(self):
        self.f.nodes.clear();self.f.selected=55;self.f.selection_time=1100
        self.e.network_selection_after=1000;self.e.acquisition_clicked_at=100
        self.assertFalse(self.e._selected_resource(self.source.view(),'Сапфир'))
        self.e.visual_selection=(1,55,'Сапфир',99.9)
        self.assertFalse(self.e._selected_resource(self.source.view(),'Сапфир'))
        self.e.visual_selection=(1,56,'Сапфир',100.2)
        self.assertFalse(self.e._selected_resource(self.source.view(),'Сапфир'))
        self.e.visual_selection=(1,55,'Сапфир',100.2)
        self.assertTrue(self.e._selected_resource(self.source.view(),'Сапфир'))
        self.f.npcs[55]={'template':123,'dead':False}
        self.assertFalse(self.e._selected_resource(self.source.view(),'Сапфир'))

    def test_resource_selection_uses_network_profile_without_top_title_ocr(self):
        self.f.collecting=None;self.f.attempt_active=False;self.f.nodes[99].gather_time=None
        self.e.target_confirmed=False;self.e.resource_hold=False
        self.e._reset_resource_watch()
        frame,box=caption_frame();candidate=vision.caption_candidate(frame,'Сапфир',box,95)
        self.e.screen.frame=lambda:(frame,(0,0))
        def select(*args):self.f.selected=99;self.f.selection_time=self.wall;return True
        with patch.object(self.input,'tap_a',side_effect=select),patch.object(ge.GamepadInput,'wait',return_value=True),patch.object(ge,'selected_target',side_effect=AssertionError('no top OCR')):
            self.assertTrue(self.e.click_candidate(candidate,(0,0)))
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP','TAP_F'])

    def test_death_during_last_attack_check_returns_to_resource(self):
        self.f.selected=55;self.f.attacks[55]=1000;self.f.collecting=None;self.f.attempt_active=False
        self.e.network_attacker=55;self.e._begin_network_defense(True)
        self.e._network_defense_tick(100)
        def guarded(command,authorize):
            self.f.deaths[55]=1200;self.assertFalse(authorize());return False
        self.e.bridge.send_guarded=guarded;self.wall=1300;self.clock=100.2
        self.e._network_defense_tick(self.clock)
        self.assertEqual(self.e.mode,'REACQUIRE');self.assertEqual(self.e.target,'Сапфир')
        self.assertFalse(any('неудачной защиты' in line for line in self.log))

    def test_failed_attacker_cooldown_does_not_hide_a_different_attacker(self):
        self.f.collecting=None;self.f.attempt_active=False;self.f.attacks={55:1000,56:1100}
        self.f.selected=56;self.e.hp_next_defense=108;self.e.attacker_retry_after[55]=108
        self.assertEqual(self.e._pending_network_hits(100),[(1100,56)])

    def test_cancelling_end_air_when_a_collection_starts_during_send(self):
        self.f.collecting=None;self.f.attempt_active=False;self.e.target_confirmed=False
        self.assertTrue(self.e._end_air_still_allowed())
        self.f.collecting=99;self.f.attempt_active=True
        self.assertFalse(self.e._end_air_still_allowed())

    def test_orphan_flight_is_closed_before_free_patrol(self):
        self.f.collecting=None;self.f.attempt_active=False;self.e.target_confirmed=False;self.e.mode='SEARCH'
        with patch.object(ge,'gathering_panel_pair',return_value=False),patch.object(ge,'resource_header_visible',return_value=False):
            self.assertTrue(self.e._resource_fast_tick(self.frame,FlightReading(60,True),100))
        self.assertEqual(self.commands,['END_AIR']);self.assertIsNotNone(self.e.wing_close_pending)

    def test_approach_distance_does_not_run_ocr_in_control_thread(self):
        self.f.collecting=None;self.f.attempt_active=False;self.f.nodes[99].gather_time=None
        self.e.real_gather_panel_seen=False;self.e.mode='APPROACH';self.e.started=100
        self.e.last_progress=100;self.e.native_route_started_at=100
        self.e.snapshot=(obs('Сапфир',distance=6),100,1,100)
        with patch.object(ge,'read_target_distance',side_effect=AssertionError('no main OCR')):
            self.e._approach_fast_tick(self.frame,(0,0),FlightReading(None,False),100.1)
        self.assertEqual(self.e.distance_live,6)

    def test_stale_network_energy_does_not_reset_recovery_every_tick(self):
        self.f.flight=1000;self.f.flight_maximum=10000;self.f.flight_at=0
        self.wall=5000;self.e.budget.energy=25
        self.e._budget_update(FlightReading(None,False),100)
        self.assertEqual(self.e.budget.energy,25)


class AttemptBoundaries(unittest.TestCase):
    def test_duplicate_old_completion_cannot_end_the_new_attempt(self):
        t=Telemetry({1550020});t.feed(1,'008d',gauge(),0)
        t.feed(1,'3436',profile(),10);t.feed(1,'3438',b'\0\0\0'+v(99),20)
        def start(ordinal,stamp):
            t.feed(1,'3836',v(99)+v(7)+b'\1',stamp)
            t.feed(1,'318d',b'\0\0'+v(99)+struct.pack('<I',ordinal)+bytes(25),stamp+1)
        start(1,30);t.feed(1,'3a36',v(99)+v(7)+struct.pack('<II',1,0),40)
        start(2,50);events=t.feed(1,'3a36',v(99)+v(7)+struct.pack('<II',1,0),55)
        self.assertTrue(t.flows[1].attempt_active);self.assertEqual(events,[])


class PriorityPolicy(unittest.TestCase):
    def setUp(self):self.p=ResourcePolicy({'only_aether':True});self.b=FlightBudget()
    def energy(self,value):self.b.energy=value;self.b.blocked=False;self.p.update(self.b)
    def test_low_energy_selects_ground_until_35_percent_then_returns_to_aether(self):
        self.energy(10);self.assertEqual(self.p.names(('Эфир','Алмаз')),('Алмаз',))
        self.energy(34);self.assertTrue(self.p.allows('Алмаз'));self.assertFalse(self.p.allows('Эфир'))
        self.energy(35);self.assertTrue(self.p.allows('Эфир'));self.assertFalse(self.p.allows('Алмаз'))
        self.energy(25);self.assertTrue(self.p.allows('Эфир'))
        self.energy(20);self.assertTrue(self.p.allows('Алмаз'))
    def test_failed_takeoff_allows_ground_even_when_energy_unknown(self):
        self.b.failed_takeoff(100);self.p.update(self.b)
        self.assertTrue(self.p.allows('Сапфир'));self.assertFalse(self.p.allows('Эфир'))
    def test_normal_mixed_mode_keeps_both_resource_types(self):
        self.p=ResourcePolicy({});self.energy(50)
        self.assertTrue(self.p.allows('Эфир'));self.assertTrue(self.p.allows('Алмаз'))
    def test_unknown_energy_permits_one_normal_aether_attempt(self):
        self.p.update(self.b);self.assertTrue(self.p.allows('Эфир'));self.assertFalse(self.p.allows('Алмаз'))
    def test_unknown_energy_can_retry_after_the_flight_budget_backoff(self):
        self.b.failed_takeoff(100);self.p.update(self.b)
        self.assertFalse(self.p.allows('Эфир'))
        self.b.update(FlightReading(None,False),104);self.p.update(self.b)
        self.assertTrue(self.p.allows('Эфир'))


class ReverseLift(unittest.TestCase):
    def test_lift_looks_down_and_flies_back_with_a_two_second_cap(self):
        p=FlightProbe(Marker('Эфир',106,100,.9,6,'aether'),0,{'probe_retreat_rise_seconds':20})
        p.phase_to('TILT',0);a=p.step(.1,FlightReading(None,False),0,90,90)
        self.assertLess(a.drive.pitch,0);self.assertEqual(a.drive.forward,0)
        self.assertEqual(p.step(.2,FlightReading(None,False),-.20,90,90).command,'V')
        a=p.step(.3,FlightReading(50,True),-.20,90,90)
        self.assertLess(a.drive.forward,0);self.assertTrue(a.drive.tilted_motion)
        self.assertIsNone(p.step(2.4,FlightReading(49,True),-.20,90,90).drive)
        a=p.step(2.5,FlightReading(49,True),-.20,90,90)
        self.assertGreater(a.drive.pitch,0);self.assertEqual(a.drive.forward,0)


if __name__=='__main__':unittest.main()
