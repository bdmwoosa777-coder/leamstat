from pathlib import Path
import unittest,math
from unittest.mock import patch
import cv2
import numpy as np
from flight import FlightBudget,FlightReading
from defense import GatherInterrupts,Threat
from vision import gather_result_full,Candidate
from navigation import Navigator
from minimap import Marker
from test_navigation import GatherFixture,obs
from test_exploration import radar
import gather_engine as ge

ROOT=Path(__file__).resolve().parent
HIDDEN=FlightReading(None,False)


class RecoveryTests(unittest.TestCase):
    def test_incomplete_panel_disappearance_triggers_probe_even_when_a_hit_used_one_slot(self):
        tracker=GatherInterrupts();tracker.update(True,3,0,full=False)
        tracker.update(True,3,.4,full=False)
        tracker.update(False,2,.6)
        self.assertFalse(tracker.ready(0,.7))
        self.assertTrue(tracker.ready(0,1.0))

    def test_partial_bar_still_visible_does_not_trigger_tab(self):
        tracker=GatherInterrupts()
        for now in (0,.5,1):tracker.update(True,3,now,full=False)
        self.assertFalse(tracker.ready(3,1.5))

    def test_full_seen_before_disappearance_is_normal_even_if_last_frame_was_partial(self):
        tracker=GatherInterrupts();tracker.update(True,3,0,full=False)
        tracker.update(True,3,1,full=True);tracker.update(True,3,1.1,full=False)
        tracker.update(False,2,1.2)
        self.assertFalse(tracker.ready(3,1.6))

    def test_either_result_track_must_reach_the_end(self):
        image=cv2.imread(str(ROOT/'testdata/air_gather_example.jpg'))
        self.assertTrue(gather_result_full(image))
        h,w=image.shape[:2]
        image[round(h*1080/1438):round(h*1154/1438),round(w*1540/2558):round(w*1602/2558)]=20
        self.assertFalse(gather_result_full(image))
        # The failure track alone is a completed attempt too.
        image[round(h*1130/1438):round(h*1140/1438),round(w*1540/2558):round(w*1602/2558)]=(0,140,245)
        self.assertTrue(gather_result_full(image))

    def test_unknown_failed_takeoff_has_a_global_backoff_without_inventing_zero(self):
        budget=FlightBudget();budget.failed_takeoff(0)
        for t in range(1,3):budget.update(HIDDEN,t);self.assertFalse(budget.can_start())
        self.assertIsNone(budget.energy)
        budget.update(HIDDEN,3);self.assertTrue(budget.can_start())

    def test_repeated_failures_increase_backoff_without_fabricating_energy(self):
        budget=FlightBudget();budget.failed_takeoff(0)
        for t in range(1,4):budget.update(HIDDEN,t)
        budget.failed_takeoff(3)
        for t in range(4,9):budget.update(HIDDEN,t);self.assertFalse(budget.can_start())
        budget.update(HIDDEN,9);self.assertTrue(budget.can_start());self.assertIsNone(budget.energy)

    def test_regenerated_energy_does_not_have_an_arbitrary_ten_second_wait(self):
        budget=FlightBudget(recovery=10);budget.update(FlightReading(2,True),0)
        for t in range(1,5):budget.update(HIDDEN,t)
        self.assertTrue(budget.can_start())

    def test_ten_percent_is_not_treated_as_empty(self):
        budget=FlightBudget();budget.update(FlightReading(10,True),0)
        self.assertTrue(budget.can_start());self.assertEqual(budget.energy,10)

    def test_paused_monitor_does_not_invent_full_regeneration(self):
        budget=FlightBudget();budget.update(FlightReading(2,True),0)
        budget.update(HIDDEN,1);budget.update(HIDDEN,1000)
        self.assertLess(budget.energy,4);self.assertFalse(budget.can_start())

    def test_real_high_energy_arc_resolves_a_failed_recognition(self):
        budget=FlightBudget();budget.failed_takeoff(0)
        budget.update(FlightReading(80,True),1)
        self.assertTrue(budget.can_start())

    def test_failed_sky_sweep_skips_target_and_retreats_before_reacquiring_it(self):
        nav=Navigator({});node=Marker('Эфир',106,100,.9,6,'aether')
        nav.update(radar([node]),0)
        self.assertTrue(nav.update(radar([node]),9.5).flight_probe)
        # Engine abandons the goal when the flight budget refuses the probe.
        nav.abandon_goal(9.5,60)
        # Engine pause after returning the viewing level starts the full retreat.
        nav.pause(10)
        plan=nav.update(radar([node]),11)
        self.assertLess(plan.forward,0);self.assertIsNone(nav.goal)
        self.assertTrue(nav.is_retreating(14))
        self.assertEqual(nav.excluded[0][3],69.5)

    def test_wall_causes_a_sustained_opposite_run_not_a_single_strafe(self):
        nav=Navigator({});node=Marker('Самоцвет',150,100,.9,50)
        nav.update(radar([node]),0)
        self.assertFalse(nav.update(radar([node]),7).flight_probe)
        self.assertTrue(nav.update(radar([node]),12.1).restore_pitch)
        nav.abandon_goal(12.1,60)
        for t in (12.2,13,14,15):
            plan=nav.update(radar([node]),t)
            self.assertLess(plan.forward,-.5);self.assertIsNone(nav.goal)

    def test_blind_retreat_goes_back_instead_of_forward_into_wall(self):
        nav=Navigator({});nav.abandon_goal(0)
        plan=nav.update(radar(heading=None),1)
        self.assertLess(plan.forward,0)


class RecoveryStateTests(GatherFixture,unittest.TestCase):
    def test_defense_waits_for_both_hud_panels_to_disappear(self):
        self.e.target='Сапфир';self.e.target_confirmed=True
        own=Threat(True,'Darkleam',True,300)
        owner_only=Threat(True,'Darkleam',False,0);gone=Threat(False,'',False,0)
        clock=[100.0];resumed=[]
        def wait(seconds,*args):clock[0]+=seconds;return True
        def resume(*args,**kwargs):resumed.append(clock[0]);return True
        with patch.object(self.e.threat,'check',side_effect=[own,own]+[owner_only]*3+[gone]*4),patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(ge.GamepadInput,'wait',side_effect=wait),patch.object(ge,'find_world_resource',return_value=self.c),patch.object(self.e,'_begin_reacquire',side_effect=resume):
            self.e._defend_and_resume()
        self.assertGreaterEqual(resumed[0],101.8)
        self.assertEqual(self.commands.count('ATTACK_PAIR'),1)

    def test_old_selected_hud_does_not_recapture_a_skipped_resource_during_retreat(self):
        self.e.nav.abandon_goal(100)
        self.step(obs('Сапфир',distance=1,prompt=True),101,plate=3,panel=False)
        self.assertEqual(self.e.mode,'SEARCH');self.assertNotIn('F_ON',self.commands)

    def test_failed_v_blocks_takeoff_on_another_resource_and_unknown_energy_log_is_safe(self):
        self.e.target='Сапфир';self.e.target_confirmed=True
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=12),HIDDEN,100)
        self.e.started=100
        self.step(obs('Сапфир',distance=12),105,plate=3)
        self.assertFalse(self.e.budget.can_start())
        ether=Candidate('Эфир',600,300,95,(580,270,40,12))
        self.assertFalse(self.e._allowed(ether,106))
        self.e.flight_attempted=False;self.e.jump_attempted=False;self.e.target='Рубин';self.e.target_confirmed=True
        self.e._recover(self.frame,(0,0),obs('Рубин',distance=12),HIDDEN,106)
        self.assertEqual(self.commands.count('V'),1);self.assertIn('JUMP',self.commands)

    def test_incomplete_attempt_requests_hp_verification_instead_of_blind_tab(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER';self.e.started=99
        with patch.object(ge,'gather_result_full',return_value=False),patch.object(self.e,'_defend_and_resume') as defend:
            self.step(obs('Сапфир',distance=1),100,plate=3,panel=True)
            self.step(obs('Сапфир',distance=1),100.5,plate=2,panel=False)
            self.step(obs('Сапфир',distance=1),101,plate=2,panel=False)
        defend.assert_not_called();self.assertTrue(self.e.health.suspect_ready.is_set())

    def test_last_consumed_attempt_without_hp_proof_does_not_tab(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.mode='GATHER'
        self.e.interrupts.update(True,1,99,full=False);self.e.interrupts.update(False,None,99.5)
        with patch.object(self.e,'_defend_and_resume') as defend:
            self.step(obs(),100,plate=None,panel=False)
        defend.assert_not_called();self.assertNotIn('TAB',self.commands)


if __name__=='__main__':unittest.main()
