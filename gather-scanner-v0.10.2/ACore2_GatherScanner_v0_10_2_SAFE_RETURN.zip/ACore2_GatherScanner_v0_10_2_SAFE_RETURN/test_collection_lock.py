"""A stays repeatable; missing names cannot authorize movement or wing folding."""
import struct,unittest
from unittest.mock import patch
from pathlib import Path
import cv2
import gather_engine as ge
from input_audit import GameplayInputAudit,GAME_KEYS
from flight import FlightReading
from network_feed import NetworkFeed
from test_navigation import GatherFixture
from test_network_control import Source
from test_ether_emblem import scene,ether
from test_cursor_camera import selected_scene
from test_network_state import v,gauge,profile

AIR=FlightReading(50,True)
GROUND=FlightReading(None,False)

class CollectionLock(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(resource_click_interaction=True,repeat_owned_clicks=True,preserve_owned_resource=True,collection_cursor_hold=True,calibrate_during_collection=False)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.nodes[99].template=1500000;self.f.nodes[99].gather_time=1000;self.f.nodes[99].used=1
        self.f.collecting=99;self.f.attempt_active=False
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
        self.frame=scene();self.e.candidate=ether(self.frame);self.e.current_size=(2480,1395)
        self.clock=100.;self.wall=1100;self.clicks=[]
        def wait(seconds,*args):self.clock+=seconds;return True
        def click(*args,**kwargs):self.clicks.append(self.positions[-1]);return True
        self.input.tap_a=click
        for q in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),patch.object(ge.GamepadInput,'wait',side_effect=wait)):
            q.start();self.addCleanup(q.stop)

    def test_unknown_owned_name_finds_selected_badge_without_placeholder_ocr(self):
        self.e.target=ge.OWN_RESOURCE;self.e.candidate=None;self.frame=selected_scene(letters=False)
        with patch.object(ge,'find_world_resource',side_effect=AssertionError('literal placeholder OCR')):
            obs=self.e._network_world_observation(self.frame)
        self.assertIsNotNone(obs.candidate);self.assertEqual(obs.candidate.name,ge.OWN_RESOURCE)
        self.e.snapshot=(obs,self.clock,1,self.clock)
        self.e.f_enable();self.assertGreater(len(self.clicks),0)

    def test_unknown_without_badge_does_not_search_literal_placeholder(self):
        self.e.target=ge.OWN_RESOURCE;self.e.candidate=None;self.frame[:]=35
        with patch.object(ge,'find_world_resource',side_effect=AssertionError('placeholder')):
            self.assertIsNone(self.e._network_world_observation(self.frame).candidate)

    def test_no_point_does_not_toggle_alt_while_waiting(self):
        self.e.target=ge.OWN_RESOURCE;self.e.candidate=None;self.frame[:]=35
        for _ in range(5):self.e.f_enable();self.clock+=.5
        self.assertEqual(self.commands,[]);self.assertEqual(self.clicks,[])

    def test_known_active_resource_still_accepts_repeat_a(self):
        self.f.attempt_active=True
        for _ in range(4):self.e.f_enable();self.clock+=1
        self.assertEqual(len(self.clicks),4);self.assertTrue(self.f.attempt_active)

    def test_give_up_timeout_does_not_fold_or_move_after_own_attempt(self):
        self.e.resource_flight_owned=True
        self.e.return_to_search('point missing',self.frame,reading=AIR,abandon=True)
        self.assertEqual(self.e.mode,'GATHER');self.assertTrue(self.e.target_confirmed)
        self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.e.resource_retry_after,{})
        self.assertNotIn('END_AIR',self.commands);self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_expired_camera_recovery_keeps_partially_used_resource(self):
        self.e.next_attempt_wait_at=95;self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.assertIsNotNone(self.e.view_recovery);self.clock=self.e.view_recovery.until+.1
        self.e._view_recovery_tick(self.frame,AIR,self.clock)
        self.assertIsNone(self.e.view_recovery);self.assertEqual(self.e.mode,'GATHER')
        self.assertIsNotNone(self.e._own_collection());self.assertNotIn('END_AIR',self.commands)

    def test_abandon_permission_cannot_override_own_collection(self):
        self.e.abandoning_binding=(1,99)
        self.assertFalse(self.e._can_abandon_resource());self.assertFalse(self.e._end_air_still_allowed())
        self.assertFalse(self.e._cancel_autopath(allow_inactive_collection=True))
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_all_direct_left_stick_reports_are_blocked_during_owned_collection(self):
        for forward,side in ((-.35,0),(.7,0),(0,.5)):
            self.assertFalse(self.input.drive(forward,side,0,0,lifetime=.05))
            self.assertEqual(self.pad.axes,(0,0,0,0))
        self.assertTrue(any('COLLECTION_GUARD' in message for message in self.log))

    def test_gather_hold_alone_blocks_translation_during_transient_network_change(self):
        self.f.collecting=None
        self.assertFalse(self.input.drive(.7,0,lifetime=.05));self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_before_first_collection_native_recovery_remains_available(self):
        self.f.collecting=None;self.f.nodes[99].gather_time=None
        self.e.mode='APPROACH';self.e.real_gather_panel_seen=False
        self.input.drive(-.35,0,lifetime=.05)
        self.assertNotEqual(self.pad.axes,(0,0,0,0))

    def test_lost_target_does_not_erase_known_partial_collection_guard(self):
        self.f.collecting=None;self.f.selected=55;self.e.resource_hold=False;self.e.mode='REACQUIRE'
        self.assertFalse(self.input.drive(-.35,0,lifetime=.05))
        self.assertFalse(self.e._end_air_still_allowed())
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_network_uncertainty_blocks_direct_translation(self):
        self.source.ready=False;self.e.resource_hold=False;self.e.mode='SEARCH'
        self.assertFalse(self.input.drive(.7,0,lifetime=.05));self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_server_exhaustion_still_closes_wings(self):
        self.f.nodes[99].used=3;self.f.collecting=None;self.e.resource_flight_owned=True
        self.e._net_resource(self.frame,AIR,self.clock)
        self.assertIn('END_AIR',self.commands);self.assertEqual(self.e.mode,'SEARCH')

    def test_direct_wing_fold_cannot_bypass_remaining_resource_guard(self):
        self.f.collecting=None;self.f.selected=0;self.frame[:]=35
        self.e.mode='REACQUIRE';self.e.resource_hold=False
        self.assertFalse(self.e.bridge_cmd('END_AIR'))
        self.assertNotIn('END_AIR',self.commands)

    def test_no_keyboard_f_can_be_requested_in_click_mode(self):
        self.assertFalse(self.e.bridge_cmd('TAP_F'));self.assertFalse(self.e.bridge_cmd('F_ON'))
        self.assertEqual(self.commands,[])

    def test_audit_records_nonzero_camera_but_no_blocked_translation(self):
        self.input.drive(0,0,.25,.15,lifetime=.05)
        self.assertTrue(any('PAD_REPORT:' in message for message in self.log))
        n=len([message for message in self.log if 'PAD_REPORT:' in message])
        self.clock+=1;self.input.drive(.5,0,lifetime=.05)
        self.assertEqual(len([message for message in self.log if 'PAD_REPORT:' in message]),n)

    def test_audit_loop_only_reads_selected_gameplay_keys(self):
        states={0x46:True};self.e.input_audit=GameplayInputAudit(lambda key:states.get(key,False))
        with patch.object(self.e.stop_event,'wait',return_value=True):self.e._input_audit_loop()
        self.assertTrue(any('INPUT_STATE: F DOWN' in message for message in self.log))
        self.assertEqual(set(self.e.input_audit.previous),set(GAME_KEYS))

    def test_audit_loop_suspends_outside_the_game(self):
        self.e.screen.focused=lambda:False
        self.e.input_audit=GameplayInputAudit(lambda key:(_ for _ in ()).throw(AssertionError('read outside game')))
        with patch.object(self.e.stop_event,'wait',return_value=True):self.e._input_audit_loop()


class PassiveInputAudit(unittest.TestCase):
    def test_real_down_and_up_are_distinct_and_steady_holds_do_not_spam(self):
        states={};audit=GameplayInputAudit(lambda key:states.get(key,False))
        self.assertEqual(audit.sample(),[]);states[0x46]=True
        self.assertEqual(audit.sample(),[('F',True)]);self.assertEqual(audit.sample(),[])
        states[0x46]=False;self.assertEqual(audit.sample(),[('F',False)])

    def test_initially_held_movement_is_observed(self):
        audit=GameplayInputAudit(lambda key:key==0x57)
        self.assertEqual(audit.sample(),[('W',True)])

    def test_only_gameplay_control_subset_is_read(self):
        called=[];audit=GameplayInputAudit(lambda key:called.append(key) or False);audit.sample()
        self.assertEqual(set(called),set(GAME_KEYS));self.assertNotIn(ord('P'),called)


class NativeAHoldGuard(GatherFixture,unittest.TestCase):
    def test_lost_alt_before_press_sends_no_a(self):
        self.alt_held=False
        self.assertFalse(self.input.tap_a(self.e.stop_event,self.e.screen.focused,hold=.01))
        self.assertEqual(self.pad.presses,0);self.assertEqual(self.pad.buttons,0)

    def test_alt_lost_during_hold_releases_a(self):
        self.alt_held=True
        def wait(seconds,stop,focused):
            self.alt_held=False;return focused()
        with patch.object(self.input,'wait',side_effect=wait):
            self.assertFalse(self.input.tap_a(self.e.stop_event,self.e.screen.focused,hold=.01))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.buttons,0)
        self.assertTrue(any('A_ABORT' in message for message in self.log))

    def test_alt_held_throughout_delivers_a_normally(self):
        self.alt_held=True
        self.assertTrue(self.input.tap_a(self.e.stop_event,self.e.screen.focused,hold=.01))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.buttons,0)


class NetworkCollectionAudit(unittest.TestCase):
    def test_owned_result_and_foreign_counter_update_are_distinguished(self):
        log=[];feed=NetworkFeed(log.append)
        def row(op,body,t):feed.ingest(dict(type='frame',flow=1,op=op,hex=body.hex(),t=t))
        row('008d',gauge(),1);row('3436',profile(kind=1500000),900)
        row('3438',bytes(3)+v(99),950);row('3836',v(99)+v(7)+b'\1',990)
        row('318d',bytes(2)+v(99)+struct.pack('<I',1)+bytes(25),1000)
        row('3a36',v(99)+v(8)+struct.pack('<II',1,0),1100)
        self.assertTrue(any('NET_COLLECTION:' in s and 'used=1' in s and 'собственный_результат=False' in s for s in log))
        row('3a36',v(99)+v(7)+struct.pack('<II',2,0),1200)
        self.assertTrue(any('NET_COLLECTION:' in s and 'used=2' in s and 'собственный_результат=True' in s for s in log))


if __name__=='__main__':unittest.main()
