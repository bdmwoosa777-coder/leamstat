"""Own context-F substitution, bounded click retries, Lua startup gate."""
import threading
import unittest
from unittest.mock import Mock,patch
from types import SimpleNamespace
from pathlib import Path
import gather_engine as ge
from receiver_check import check_receiver
from camera_pitch import PitchLedger
from resource_policy import ResourcePolicy
from flight import FlightReading
from network_state import Node
from network_state import Telemetry
from test_network_state import v,gauge,profile
import struct
from test_network_control import Source
from test_navigation import GatherFixture,obs,radar
from test_control_regressions import caption_frame
from vision import caption_candidate
from test_lua_transport import LuaRuntime,Wire
from bridge import GHubBridge,frame_codes


class Clock:
    def __init__(self):self.now=0.;self.cancelled=False
    def wait(self,seconds):self.now+=seconds;return self.cancelled
    def is_set(self):return self.cancelled


class ProbeBridge:
    def __init__(self,clock,lost_down=0,lost_up=0):
        self.clock=clock;self.lost_down=lost_down;self.lost_up=lost_up
        self.held=False;self.commands=[];self.syncs=0
    def send(self,command):
        self.commands.append(command)
        if command=='STOP':self.held=False
        elif command=='ALT_DOWN':
            if self.lost_down:self.lost_down-=1
            else:self.held=True
        elif command=='ALT_UP':
            if self.lost_up:self.lost_up-=1
            else:self.held=False
        else:raise AssertionError('Unexpected gameplay command '+command)
        return True
    def send_guarded(self,command,authorize):return self.send(command) if authorize() else False
    def alt_is_down(self):return self.held
    def resync_receiver(self,stop,focused):
        self.syncs+=1;self.clock.wait(.95)
        return not stop.is_set() and focused()


class ReceiverChecks(unittest.TestCase):
    def setUp(self):
        self.clock=Clock();self.p=patch('receiver_check.time.monotonic',side_effect=lambda:self.clock.now)
        self.p.start();self.addCleanup(self.p.stop)
    def test_observed_down_and_up_are_required(self):
        b=ProbeBridge(self.clock);result=check_receiver(b,self.clock,lambda:True)
        self.assertTrue(result.ok);self.assertEqual(result.attempts,1)
        self.assertEqual(b.commands,['STOP','ALT_DOWN','ALT_UP']);self.assertFalse(b.held)
    def test_missing_receiver_is_bounded_and_never_tries_f_v_or_a(self):
        b=ProbeBridge(self.clock,lost_down=10);result=check_receiver(b,self.clock,lambda:True)
        self.assertFalse(result.ok);self.assertEqual(result.attempts,2);self.assertEqual(b.syncs,2)
        self.assertEqual(b.commands,['STOP','ALT_DOWN','ALT_UP']*2);self.assertLess(self.clock.now,5)
    def test_first_lost_alt_frame_has_only_one_idempotent_retry(self):
        b=ProbeBridge(self.clock,lost_down=1);result=check_receiver(b,self.clock,lambda:True)
        self.assertTrue(result.ok);self.assertEqual(result.attempts,2);self.assertFalse(b.held)
    def test_failed_release_aborts_and_sends_a_final_stop(self):
        b=ProbeBridge(self.clock,lost_up=1);result=check_receiver(b,self.clock,lambda:True)
        self.assertFalse(result.ok);self.assertFalse(b.held);self.assertEqual(b.commands[-1],'STOP')
    def test_no_input_is_sent_without_focus(self):
        b=ProbeBridge(self.clock);result=check_receiver(b,self.clock,lambda:False)
        self.assertFalse(result.ok);self.assertEqual(b.commands,[])
    def test_focus_loss_during_probe_still_releases_alt(self):
        b=ProbeBridge(self.clock);result=check_receiver(b,self.clock,lambda:not b.held)
        self.assertFalse(result.ok);self.assertFalse(b.held);self.assertIn('ALT_UP',b.commands)
    def test_stop_before_probe_sends_nothing(self):
        self.clock.cancelled=True;b=ProbeBridge(self.clock)
        self.assertFalse(check_receiver(b,self.clock,lambda:True).ok);self.assertEqual(b.commands,[])
    def test_resync_keeps_scroll_low_until_lua_partial_frame_timeout(self):
        b=GHubBridge.__new__(GHubBridge);b.lock=threading.RLock();b.dry_run=False
        b._toggle=Mock()
        self.assertTrue(b.resync_receiver(self.clock,lambda:True))
        b._toggle.assert_called_once_with(145,False);self.assertGreaterEqual(self.clock.now,.95)


class EngineReceiverGate(GatherFixture,unittest.TestCase):
    def test_failed_receiver_prevents_network_camera_and_navigation_start(self):
        clock=Clock();b=ProbeBridge(clock,lost_down=10);self.e.bridge=b
        self.e.screen.pick=lambda:'game';self.e.network=SimpleNamespace(start=Mock(),close=Mock())
        self.e.cfg['network_enabled']=True
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock.now),patch.object(self.e.stop_event,'wait',side_effect=clock.wait),patch.object(self.e,'stop'),patch.object(self.e,'_prepare_working_view') as camera,patch.object(self.input,'drive') as drive:
            self.e.run()
        self.e.network.start.assert_not_called();camera.assert_not_called();drive.assert_not_called()
        self.assertEqual(self.pad.presses,0);self.assertIn('G9',self.e.halt_reason)
    def test_runtime_lost_alt_retries_only_alt_state_without_gameplay(self):
        clock=Clock();b=ProbeBridge(clock,lost_down=1);b.send('ALT_DOWN');self.e.bridge=b
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock.now),patch.object(self.e.stop_event,'wait',side_effect=clock.wait):
            self.assertTrue(self.e._wait_alt_state(True))
        self.assertEqual(b.commands,['ALT_DOWN','ALT_DOWN']);self.assertEqual(self.pad.presses,0)
    def test_observation_mode_does_not_send_probe_commands(self):
        self.e.cfg['dry_run']=True
        self.assertTrue(self.e._preflight_receiver());self.assertEqual(self.commands,[])


class ContextHandoff(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='APPROACH'
        self.e.network_target=(1,99);self.e.network_claimed_at=900;self.e.route_f_sent=True
        self.f.nodes[99].template=1550000
        self.f.nodes[100]=Node(100,used=0,time=1050,gather_time=1050)
        self.f.collecting=100;self.f.selected=100;self.f.attempt_active=True
        self.clock=100.;self.wall=1100
        for p in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000)):
            p.start();self.addCleanup(p.stop)
    def test_unknown_actual_resource_replaces_intended_ether_without_new_start_f(self):
        self.assertTrue(self.e._adopt_network_collection())
        self.e._resource_fast_tick(self.frame,FlightReading(None,False),100)
        self.assertEqual(self.e.network_target,(1,100));self.assertEqual(self.e.target,ge.OWN_RESOURCE)
        self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.commands,[])
        self.assertTrue(self.e.real_gather_panel_seen)
    def test_three_actual_attempts_complete_without_reselecting_ether(self):
        self.e._resource_fast_tick(self.frame,FlightReading(None,False),100)
        for used in (1,2):
            self.f.nodes[100].used=used;self.f.attempt_active=False
            for i in range(4):self.e._resource_fast_tick(self.frame,FlightReading(None,False),100+used)
            self.assertEqual(self.commands,['TAP_F']*used)
            self.f.attempt_active=True
        self.f.nodes[100].used=3;self.f.attempt_active=False;self.f.collecting=None
        self.e._resource_fast_tick(self.frame,FlightReading(None,False),104)
        self.assertEqual(self.e.node_count,1);self.assertEqual(self.e.mode,'SEARCH')
        self.assertEqual(self.commands,['TAP_F','TAP_F']);self.assertFalse(self.e.stop_event.is_set())
    def test_known_diamond_is_adopted_even_in_ether_priority(self):
        self.f.nodes[100].template=1550021;self.e.cfg['only_aether']=True
        self.assertTrue(self.e._adopt_network_collection());self.assertEqual(self.e.target,'Алмаз')
    def test_resuming_diamond_after_defense_does_not_get_filtered_by_ether_priority(self):
        self.e.policy=ResourcePolicy({'only_aether':True});self.e.budget.energy=60
        self.e.policy.update(self.e.budget);self.e.target='Алмаз';self.e.mode='REACQUIRE'
        self.assertEqual(self.e._vision_names(),('Алмаз',))
    def test_other_gatherer_without_own_lease_is_not_adopted(self):
        self.f.collecting=None
        self.assertFalse(self.e._adopt_network_collection());self.assertEqual(self.e.network_target,(1,99))
    def test_context_interaction_before_private_panel_is_adopted_when_panel_arrives(self):
        self.f.nodes[100].gather_time=None
        self.assertFalse(self.e._adopt_network_collection())
        self.e._resource_fast_tick(self.frame,FlightReading(None,False),100)
        self.assertEqual(self.e.mode,'REACQUIRE')
        self.f.nodes[100].gather_time=1050
        self.e._resource_fast_tick(self.frame,FlightReading(None,False),100.1)
        self.assertEqual(self.e.mode,'GATHER');self.assertIsNone(self.e.reacquire_until)
        self.assertEqual(self.commands,[])
    def test_display_name_resolution_does_not_reset_attempt_request(self):
        self.e._adopt_network_collection();self.f.nodes[100].used=1;self.f.attempt_active=False
        self.e._resource_fast_tick(self.frame,FlightReading(None,False),100)
        self.e.visual_selection=(1,100,'Алмаз',101);self.e._adopt_network_collection()
        self.e.f_enable()
        self.assertEqual(self.e.target,'Алмаз');self.assertEqual(self.commands,['TAP_F'])
    def test_wrong_actor_hud_cannot_name_unknown_actual_collection(self):
        self.e._adopt_network_collection();self.e.visual_selection=(1,99,'Эфир',101)
        self.e._adopt_network_collection();self.assertEqual(self.e.target,ge.OWN_RESOURCE)
    def test_existing_actual_collection_cannot_be_clicked_away(self):
        self.assertTrue(self.e.click_candidate(self.c,(0,0)))
        self.assertEqual(self.pad.presses,0);self.assertEqual(self.commands,[])
    def test_last_attempt_of_context_resource_is_not_mistaken_for_old_ether_path(self):
        self.f.nodes[100].used=3;self.f.collecting=None;self.f.attempt_active=False
        self.f.last_own_result=(100,1100)
        self.e._resource_fast_tick(self.frame,FlightReading(None,False),100)
        self.assertEqual(self.e.node_count,1);self.assertEqual(self.e.mode,'SEARCH');self.assertEqual(self.commands,[])
    def test_own_interaction_grace_blocks_retargeting_before_private_panel(self):
        self.f.nodes[100].gather_time=None;self.f.started=1050
        self.assertTrue(self.e._resource_fast_tick(self.frame,FlightReading(None,False),100))
        self.assertEqual(self.e.mode,'APPROACH');self.assertEqual(self.commands,[])
    def test_interaction_grace_is_bounded_when_no_gather_proof_arrives(self):
        self.f.nodes[100].gather_time=None;self.f.started=100;self.wall=3100
        self.e._resource_fast_tick(self.frame,FlightReading(None,False),100)
        self.assertEqual(self.e.mode,'REACQUIRE');self.assertEqual(self.commands,[])


class ResultProof(unittest.TestCase):
    def telemetry(self):
        t=Telemetry({1550021});t.feed(1,'008d',gauge(),0)
        t.feed(1,'3438',b'\0\0\0'+v(100),10)
        t.feed(1,'3836',v(100)+v(7)+b'\1',20)
        return t
    def test_own_completed_attempt_is_proof_if_initial_private_panel_was_not_captured(self):
        t=self.telemetry();events=t.feed(1,'3a36',v(100)+v(7)+struct.pack('<II',1,0),100)
        self.assertEqual(t.flows[1].nodes[100].gather_time,20)
        self.assertEqual(t.flows[1].last_own_result,(100,100))
        self.assertIn('own_gather_confirmed_by_result',[e['kind'] for e in events])
    def test_foreign_completion_does_not_grant_own_gather_permission(self):
        t=self.telemetry();t.feed(1,'3a36',v(100)+v(8)+struct.pack('<II',1,0),100)
        self.assertIsNone(t.flows[1].nodes[100].gather_time);self.assertIsNone(t.flows[1].last_own_result)
    def test_unpaired_completion_and_reward_payload_do_not_grant_permission(self):
        for payload in (struct.pack('<II',1,123),struct.pack('<II',0,0)):
            t=self.telemetry();t.feed(1,'3a36',v(100)+v(7)+payload,100)
            self.assertIsNone(t.flows[1].nodes[100].gather_time)
    def test_completion_without_own_paired_interaction_cannot_be_adopted(self):
        t=Telemetry({1550021});t.feed(1,'008d',gauge(),0)
        t.feed(1,'3436',profile(actor=100,kind=1550021),10)
        t.feed(1,'3a36',v(100)+v(7)+struct.pack('<II',1,0),100)
        self.assertIsNone(t.flows[1].nodes[100].gather_time);self.assertIsNone(t.flows[1].last_own_result)
    def test_known_npc_interaction_is_not_promoted_to_resource_by_result(self):
        t=self.telemetry();t.flows[1].npcs[100]={'template':123,'dead':False}
        t.feed(1,'3a36',v(100)+v(7)+struct.pack('<II',1,0),100)
        self.assertIsNone(t.flows[1].nodes[100].gather_time)


class CaptionRetry(GatherFixture,unittest.TestCase):
    def test_missed_ether_click_retries_under_fresh_caption_before_f(self):
        source=Source();self.e.network=source;source.state.collecting=None;source.state.attempt_active=False
        source.state.nodes[99].gather_time=None;source.state.nodes[99].template=1550000;source.state.selected=0
        frame,box=caption_frame();candidate=caption_candidate(frame,'Эфир',box,95)
        self.e.screen.frame=lambda:(frame,(0,0));clock=Clock();presses=[0]
        def tap(*args):
            presses[0]+=1
            if presses[0]==2:source.state.selected=99;source.state.selection_time=1100
            return True
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock.now),patch.object(ge.time,'time',return_value=1.1),patch.object(self.e.stop_event,'wait',side_effect=clock.wait),patch.object(self.input,'tap_a',side_effect=tap):
            self.assertTrue(self.e.click_candidate(candidate,(0,0)))
        self.assertEqual(presses[0],2);self.assertEqual(self.commands,['ALT_DOWN','ALT_UP','TAP_F'])
        self.assertEqual(self.positions[0][0],self.positions[1][0]);self.assertGreater(self.positions[1][1],self.positions[0][1])


class SlowCameraReturn(unittest.TestCase):
    def test_measured_pulses_finish_with_three_quarter_second_control_gaps(self):
        ledger=PitchLedger();ledger.balance=.20;ledger.restore(0)
        for i in range(10):
            now=i*.75;command=ledger.correction(now)
            if not command:break
            lease=ledger.correction_lifetime();self.assertLessEqual(lease,.18)
            ledger.apply(command,now,lease)
        self.assertFalse(ledger.failed);self.assertFalse(ledger.returning);self.assertLess(abs(ledger.balance),.006)
    def test_no_progress_still_has_a_finite_timeout_and_retains_residual(self):
        ledger=PitchLedger();ledger.balance=.5;ledger.restore(0);ledger.correction(20)
        self.assertTrue(ledger.failed);self.assertEqual(ledger.balance,.5)


@unittest.skipIf(LuaRuntime is None,'Optional lupa is unavailable')
class PartialFrameTimeout(unittest.TestCase):
    def test_actual_lua_ignores_old_partial_frame_after_quiet_gap(self):
        wire=Wire([]);wire.events=[];wire.index=0;start=100
        for codes in ([3,0],frame_codes('STOP'),frame_codes('ALT_DOWN'),frame_codes('ALT_UP')):
            for code in codes:
                wire.events.extend([(start,{'capslock':bool(code&2),'numlock':bool(code&1),'scrolllock':False}),
                                    (start+24,{'scrolllock':True}),(start+84,{'scrolllock':False})]);start+=120
            start+=1000
        wire.end=start+1200
        lua=LuaRuntime();g=lua.globals();g.IsKeyLockOn=wire.lock;g.GetRunningTime=lambda:wire.now;g.Sleep=wire.sleep
        g.PressKey=wire.press;g.ReleaseKey=wire.release;g.OutputLogMessage=lambda *args:None
        lua.execute((Path(__file__).parent/'GHUB_GATHER_SCANNER.lua').read_text());g.OnEvent('MOUSE_BUTTON_PRESSED',9)
        self.assertEqual(sum(a=='down' and k=='lalt' for _,a,k in wire.keys),1)
        self.assertFalse(any(k in ('f','v','tab') for _,_,k in wire.keys));self.assertFalse(wire.held)


if __name__=='__main__':unittest.main()
