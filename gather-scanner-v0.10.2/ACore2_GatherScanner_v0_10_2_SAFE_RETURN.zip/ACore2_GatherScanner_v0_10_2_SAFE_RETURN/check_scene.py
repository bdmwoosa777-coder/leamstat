"""No capture or game input: verify both models and one actual local inference."""
import json,os,time,numpy as np
from model_runner import SegmentationRunner
from depth import DepthRunner
from scene import interpret
from scene_navigation import assess
from win_capture import adapters

def main():
 cards=adapters();device=next((c['id'] for c in cards if '4080' in c['name']),next((c['id'] for c in cards if c['vendor']==0x10de),0))
 print('Адаптер:',device,next((c['name'] for c in cards if c['id']==device),'авто'))
 semantic=SegmentationRunner(device,False,print);depth=DepthRunner(device,False,print)
 if os.name=='nt' and (semantic.backend!='DmlExecutionProvider' or depth.backend!='DmlExecutionProvider'):
  raise RuntimeError('Обеим моделям нужен DirectML. Проверьте установку и драйвер видеокарты.')
 frame=np.full((360,640,3),80,np.uint8);start=time.perf_counter()
 labels,confidence,_=semantic.predict(frame);groups=interpret(labels,confidence,semantic.id2label).groups
 raw,_=depth.predict(frame);lanes=assess(groups,raw)
 print(json.dumps(dict(semantic=semantic.backend,depth=depth.backend,total_ms=round((time.perf_counter()-start)*1000,1),lanes=[l.__dict__ for l in lanes],game_input=False)))
if __name__=='__main__':main()
