"""Bounded ascent/inspection cycles. No folding wings on a cruise timer."""
from dataclasses import replace
from navigation import Drive
from terrain_recovery import TerrainRecovery,RecoveryAction
from camera_control import PITCH_STRENGTH

class AreaRecovery(TerrainRecovery):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.started=args[0];self.cycles=0;self.scan_pulse=-1
  self.descent_start=None;self.descent_absent=None;self.resume_search=False
 def step(self,now,reading,balance,heading=None,bearing=None,height_gap=None):
  if now-self.started>=45 and not self.resume_search and self.phase!='GROUND':
   self.resume_search=True;self.homed=False;self.level_start=None;self.to('LEVEL',now)
  action=self._step(now,reading,balance,heading,bearing,height_gap)
  if self.resume_search and action.levelled:
   return RecoveryAction(done=True,levelled=True,reason='спасение ограничено по времени; возвращаю поиск с открытыми крыльями, посадку не предполагаю')
  if action.drive and (abs(action.drive.forward)+abs(action.drive.strafe)>.01):
   action.drive=replace(action.drive,lifetime=max(.65,action.drive.lifetime))
  elif action.drive and abs(action.drive.pitch)>.01:
   left=None
   if self.phase=='DOWN' and self.pitch_start is not None:left=2-(self.pitch_start-balance)/PITCH_STRENGTH
   elif self.phase=='DESC_DOWN' and self.descent_start is not None:left=2-(self.descent_start-balance)/PITCH_STRENGTH
   elif self.phase=='LEVEL' and self.level_start is not None:
    left=self.working-(balance-self.level_start)/PITCH_STRENGTH if self.homed else abs(balance)/PITCH_STRENGTH
   if left is not None and left>0:action.drive=replace(action.drive,lifetime=min(.35,left))
  return action
 def _step(self,now,reading,balance,heading=None,bearing=None,height_gap=None):
  # The final minimum pulse is 20 ms plus scheduling jitter. Do not alternate
  # its sign forever to chase a smaller axis-time residual.
  if self.phase=='LEVEL' and not self.homed and abs(balance)<.012:
   self.to('SCAN' if reading.confirmed else 'GROUND',now)
   return RecoveryAction(levelled=True,reason='малый остаток наклона принят в пределах длительности одного минимального импульса')
  if self.phase=='LEVEL' and now-self.since>=6 and not self.homed:
   return RecoveryAction(done=True,camera_failed=True,reason='возврат наклона не выполнен за 6 с; нужна одна полная калибровка вместо нового спасения')
  elapsed=now-self.since
  if self.phase=='RISE' and height_gap is not None and height_gap<=2:
   self.to('LEVEL',now)
  if self.phase=='CRUISE' and (not reading.confirmed or reading.energy is not None and reading.energy<=20 or elapsed>=4):
   self.to('SCAN',now);self.scan_pulse=-1;elapsed=0
  if self.phase=='SCAN':
   if not reading.confirmed:
    if self.absent is None:self.absent=now
    if now-self.absent>=.8:self.fly=False;self.to('GROUND',now)
    else:return RecoveryAction(reason='проверяю исчезновение дуги без переключения V')
   elif elapsed<6 and (reading.energy is None or reading.energy>20):
    slot=int(elapsed/1.5)
    if slot!=self.scan_pulse:
     self.scan_pulse=slot
     return RecoveryAction(drive=Drive(yaw=.30*self.side,lifetime=.12),reason='осмотр после перелёта: ищу ресурс, крылья сохраняю')
    return RecoveryAction(reason='жду свежую подпись ресурса после короткого осмотра')
   elif (height_gap is not None and height_gap>2 and self.cycles<3 and now-self.started<40
         and reading.energy is not None and reading.energy>=50):
    self.homed=False;self.pitch_start=None;self.level_start=None;self.to('DOWN',now)
   else:
    return RecoveryAction(done=True,levelled=True,reason='после перелёта ресурс не найден; продолжаю обычный поиск без повторного подъёма и без V')
  if self.phase=='DESC_DOWN':
   if self.descent_start is None:self.descent_start=balance
   left=2-(self.descent_start-balance)/PITCH_STRENGTH
   if left>.005:
    if now-self.since>=6:
     self.resume_search=True;self.homed=False;self.level_start=None;self.to('LEVEL',now)
     return RecoveryAction(reason='опускание камеры не подтверждено: возвращаю прежний обзор, без нового спасения')
    return RecoveryAction(drive=Drive(pitch=-PITCH_STRENGTH,lifetime=min(.15,left)),reason='выход не найден: готовлю управляемый спуск, V не нажимаю')
   self.to('DESCEND',now);self.descent_absent=None
  if self.phase=='DESCEND':
   if not reading.confirmed:
    if self.descent_absent is None:self.descent_absent=now
    if now-self.descent_absent>=.8:
     self.fly=False;self.homed=True;self.level_start=None;self.to('LEVEL',now)
    else:return RecoveryAction(reason='дуга исчезла; прекращаю полётный ввод и проверяю состояние')
   elif now-self.since>=8:
    self.to('DRIFT',now)
   else:
    self.descent_absent=None
    return RecoveryAction(drive=Drive(.45,.18*self.side,0,0,lifetime=.18,tilted_motion=True),reason='управляемый спуск при взгляде вниз; без END_AIR')
  if self.phase=='DRIFT':
   if now-self.since>=2:
    self.resume_search=True;self.homed=True;self.level_start=None;self.to('LEVEL',now)
   else:
    # Camera still looks down: lateral input avoids reversing vertical motion.
    return RecoveryAction(drive=Drive(0,.4*self.side,0,0,lifetime=.18,tilted_motion=True),reason='спуск упёрся: коротко смещаюсь вбок, затем продолжаю')
  prior=self.phase
  result=super().step(now,reading,balance,heading,bearing)
  if prior in ('DOWN','WAIT') and self.phase=='RISE':self.cycles+=1
  if self.phase in ('CLOSE','WAIT_CLOSE','AIR_EXIT') or result.command=='END_AIR':
   self.to('DESC_DOWN' if reading.confirmed else 'GROUND',now);self.descent_start=None
   return RecoveryAction(levelled=result.levelled,reason='таймер перелёта не доказывает посадку; END_AIR отменён')
  return result
