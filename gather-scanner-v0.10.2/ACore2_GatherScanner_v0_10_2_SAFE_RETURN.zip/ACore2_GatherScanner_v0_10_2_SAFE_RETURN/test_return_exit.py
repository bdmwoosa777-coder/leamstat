import unittest
from unittest.mock import patch
import numpy as np,cv2
from dataclasses import replace
from return_exit import BridgeExit,DEFAULT_EXIT,matches_place,purple_anchor
from navigation import Drive
from test_navigation import radar
from test_idle_return import ReturnEngineTests,GROUND,AIR
import gather_engine as ge

class BridgeRouteTests(unittest.TestCase):
    def setUp(self):
        self.route=BridgeExit(0,(100,100),200,DEFAULT_EXIT,{})
        self.r=replace(radar(heading=303.3),bounds=(0,0,200,200))
    def test_route_matches_known_location_only(self):
        self.assertTrue(matches_place('Штаб торговцев стального...',DEFAULT_EXIT))
        self.assertFalse(matches_place('Месторождение фанита',DEFAULT_EXIT))
        self.assertFalse(matches_place('',DEFAULT_EXIT))
    def test_first_leg_is_north_west_and_turns_without_translation(self):
        a=self.route.step(0,replace(self.r,heading=90),(100,100))
        self.assertEqual((a.drive.forward,a.drive.strafe),(0,0))
        a=self.route.step(.1,self.r,(100,100));self.assertGreater(a.drive.forward,0)
        self.assertLess(abs(a.drive.strafe),.02)
    def test_static_map_cannot_complete_by_elapsed_time(self):
        for t in (0,10,30,120):
            self.assertFalse(self.route.step(t,self.r,(100,100)).done)
            self.assertEqual(self.route.index,0)
    def test_landmark_moves_opposite_character_then_west_leg(self):
        a=self.route.step(1,self.r,(135,123))
        self.assertEqual(self.route.position,(-35,-23));self.assertEqual(self.route.index,1)
        self.assertEqual((a.drive.forward,a.drive.strafe),(0,0))
        a=self.route.step(1.2,replace(self.r,heading=270),(135,123))
        self.assertGreater(a.drive.forward,0);self.assertAlmostEqual(a.drive.strafe,0)
        self.assertTrue(self.route.step(5,replace(self.r,heading=270),(188,123)).done)
    def test_missing_landmark_stops_after_half_second_and_cannot_certify_finish(self):
        a=self.route.step(1,self.r,None);self.assertIsNone(a.drive);self.assertFalse(a.done)
        self.route.position=self.route.points[0]
        self.assertFalse(self.route.step(1.1,self.r,None).done);self.assertEqual(self.route.index,0)
    def test_optical_flow_bridges_short_occlusion_with_correct_sign(self):
        r=replace(self.r,displacement=(2,1),motion_valid=True)
        self.route.step(.2,r,None);self.assertEqual(self.route.position,(-2,-1))
    def test_zoom_change_blocks_motion(self):
        a=self.route.step(1,replace(self.r,bounds=(0,0,300,300)),(100,100))
        self.assertIsNone(a.drive);self.assertFalse(a.done)
    def test_stale_heading_never_uses_blind_forward(self):
        self.route.step(0,self.r,(100,100))
        a=self.route.step(1,replace(self.r,heading=None),(100,100))
        self.assertEqual((a.drive.forward,a.drive.strafe),(0,0))
    def test_stuck_on_bridge_retraces_toward_confirmed_entrance(self):
        self.route.step(0,self.r,(135,123));self.route.step(.1,replace(self.r,heading=270),(150,123))
        a=self.route.step(7,replace(self.r,heading=90),(150,123))
        self.assertIn('отхожу',a.reason);self.assertGreater(a.drive.forward,0)
    def test_anchor_tracker_can_follow_icon_away_from_minimap_center(self):
        f=np.full((200,300,3),100,np.uint8)
        cv2.rectangle(f,(146,94),(153,109),(230,60,200),-1)
        first=purple_anchor(f,(0,0,300,200));self.assertIsNotNone(first)
        cv2.rectangle(f,(146,94),(153,109),(100,100,100),-1)
        cv2.rectangle(f,(216,124),(223,139),(230,60,200),-1)
        self.assertIsNone(purple_anchor(f,(0,0,300,200)))
        point=purple_anchor(f,(0,0,300,200),(218,130));self.assertIsNotNone(point)
        self.assertGreater(point[0],210)

class ExitEngineTests(ReturnEngineTests):
    # Reuse the input/network fixture but do not re-run the inherited test set.
    def test_guard_blocks_other_rescues_and_unrelated_translation(self):
        self.e.return_exit_guard=True
        self.assertFalse(self.e._start_terrain_recovery(self.clock,GROUND))
        self.e._motion(Drive(1,1));self.assertEqual(self.pad.axes[:2],(0,0))
    def test_unknown_location_scans_without_straight_patrol(self):
        self.e.return_exit_guard=True
        with patch.object(ge,'place_title',return_value='Другая область'):
            self.assertTrue(self.e._return_exit_tick(self.frame,GROUND,self.clock))
        self.assertEqual(self.pad.axes[:2],(0,0));self.assertIsNone(self.e.exit_route)
        self.assertTrue(self.e.return_exit_guard)
    def test_known_location_starts_bridge_route_and_not_resource_search(self):
        self.e.return_exit_guard=True
        r=replace(radar(heading=303),bounds=(0,0,200,200))
        with patch.object(ge,'place_title',return_value='Штаб торговцев стального...'),patch.object(ge,'purple_anchor',return_value=(100,100)),patch.object(self.e.exit_minimap,'observe',return_value=r),patch.object(self.e.exit_minimap,'bounds',return_value=(0,0,200,200)):
            self.assertTrue(self.e._return_exit_tick(self.frame,GROUND,self.clock))
        self.assertIsNotNone(self.e.exit_route);self.assertTrue(self.e.return_exit_guard)
        self.assertGreater(self.pad.axes[1],0);self.assertFalse(self.e.stop_event.is_set())
    def test_only_second_confirmed_waypoint_unlocks_patrol(self):
        self.e.return_exit_guard=True;self.e.exit_route=BridgeExit(0,(100,100),200,DEFAULT_EXIT,{})
        r=replace(radar(heading=270),bounds=(0,0,200,200))
        with patch.object(self.e.exit_minimap,'observe',return_value=r),patch.object(ge,'purple_anchor',return_value=(135,123)):
            self.e._return_exit_tick(self.frame,GROUND,self.clock)
        self.assertTrue(self.e.return_exit_guard)
        with patch.object(self.e.exit_minimap,'observe',return_value=r),patch.object(ge,'purple_anchor',return_value=(188,123)):
            self.e._return_exit_tick(self.frame,GROUND,self.clock+1)
        self.assertFalse(self.e.return_exit_guard);self.assertIsNone(self.e.exit_route)
        self.assertEqual(self.pad.axes,(0,0,0,0))
    def test_fresh_collection_is_never_interrupted_by_bridge_route(self):
        self.e.return_exit_guard=True;self.e.target_confirmed=True;self.e.resource_hold=True
        self.assertFalse(self.e._return_exit_tick(self.frame,GROUND,self.clock))
        self.assertIsNone(self.e.exit_route);self.assertEqual(self.commands,[])
    def test_air_exit_is_bounded_folding_without_forward_or_scroll(self):
        self.e.return_exit_guard=True
        for t in (0,4,8,20):self.e._return_exit_tick(self.frame,AIR,self.clock+t)
        self.assertLessEqual(self.commands.count('END_AIR'),2)
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertFalse(self.e.stop_event.is_set())
    def test_exact_old_collection_lease_cannot_freeze_exit_but_new_start_blocks(self):
        self.e.return_exit_guard=True;self.e.exit_route_driving=True
        self.f.collecting=99;self.f.attempt_active=True;self.f.nodes[99].gather_time=1
        self.e.ignored_collection_lease=(1,99,1)
        self.e._motion(Drive(.5,0));self.assertGreater(self.pad.axes[1],0)
        self.f.nodes[99].gather_time=2
        self.e._motion(Drive(.5,0));self.assertEqual(self.pad.axes,(0,0,0,0))

# unittest discovers inherited methods too; expose only the additional cases.
for _name in tuple(vars(ReturnEngineTests)):
    if _name.startswith('test_'):setattr(ExitEngineTests,_name,None)
del ReturnEngineTests

if __name__=='__main__':unittest.main()
