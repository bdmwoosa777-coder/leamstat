"""A user-marked, north-up bridge route; never a general cliff detector."""
from dataclasses import dataclass
import math
import cv2
import numpy as np
from minimap import angle_delta
from navigation import Drive,Navigator
from vision import _ocr_text,norm


DEFAULT_EXIT={'place':'Штаб торговцев стального',
              'waypoints':[[-.175,-.115],[-.44,-.115]]}


def place_title(frame,bounds):
    x0,y0,x1,_=bounds
    crop=frame[max(0,y0-round(frame.shape[0]*.028)):max(0,y0-2),x0:x1]
    if not crop.size:return ''
    gray=cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY)
    text=cv2.resize(cv2.threshold(gray,190,255,cv2.THRESH_BINARY)[1],None,fx=3,fy=3)
    return _ocr_text(text,lang='rus',config='--oem 3 --psm 7')


def matches_place(title,spec):
    expected=norm(spec.get('place',''))
    # Require the distinctive words, not an arbitrary short OCR coincidence.
    return len(expected)>=12 and expected in norm(title)


def purple_anchor(frame,bounds,near=None):
    x0,y0,x1,y1=bounds;crop=frame[y0:y1,x0:x1]
    if not crop.size:return None
    hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV);h,w=crop.shape[:2]
    mask=cv2.inRange(hsv,(125,75,125),(168,255,255))
    count,_,stats,centers=cv2.connectedComponentsWithStats(mask)
    center=(w/2,h/2) if near is None else (near[0]-x0,near[1]-y0)
    radius=min(h,w)*.23 if near is None else max(7,w*.065)
    found=[]
    for i in range(1,count):
        area=stats[i,cv2.CC_STAT_AREA];height=stats[i,cv2.CC_STAT_HEIGHT]
        distance=math.dist(centers[i],center)
        if (max(4,h*w*.00012)<=area<=h*w*.025 and height>=max(4,h*.025)
            and distance<=radius):found.append((distance,centers[i]))
    if not found:return None
    _,point=min(found,key=lambda p:p[0])
    return float(point[0]+x0),float(point[1]+y0)


@dataclass
class ExitAction:
    drive:Drive|None=None
    done:bool=False
    reason:str=''


class BridgeExit:
    def __init__(self,now,anchor,width,spec,cfg):
        self.initial=anchor;self.anchor=anchor;self.width=width
        self.points=[(float(x)*width,float(y)*width) for x,y in spec['waypoints']]
        if not self.points or not all(math.isfinite(v) for p in self.points for v in p):raise ValueError('empty/invalid bridge route')
        self.position=(0.,0.);self.index=0;self.at=now;self.seen=now
        self.best=None;self.progress=now;self.back_until=0.;self.retries=0
        self.heading=None;self.heading_at=now;self.scan_at=now
        self.nav=Navigator({**cfg,'resource_walk_speed':.60})

    def step(self,now,radar,anchor):
        if abs((radar.bounds[2]-radar.bounds[0])/self.width-1)>.02:
            return ExitAction(reason='масштаб миникарты изменился; маршрут не продолжаю вслепую')
        if anchor is not None:
            self.anchor=anchor;self.seen=now
            self.position=(self.initial[0]-anchor[0],self.initial[1]-anchor[1])
        # The landmark is the absolute position check. Optical flow is only a
        # short bridge across a one-frame occlusion; it cannot certify arrival.
        elif radar.motion_valid and now-self.seen<=.5:
            dx,dy=radar.displacement
            if math.hypot(dx,dy)<self.width*.05:
                self.position=(self.position[0]-dx,self.position[1]-dy)
                self.anchor=(self.initial[0]-self.position[0],self.initial[1]-self.position[1])
        if anchor is None and now-self.seen>.5:
            return ExitAction(reason='кибелиск потерян на миникарте: движение приостановлено, ищу ориентир')
        target=self.points[self.index];distance=math.dist(self.position,target)
        tolerance=max(1.5,self.width*.009)
        if distance<=tolerance and anchor is not None:
            self.index+=1;self.best=None;self.progress=now;self.retries=0
            if self.index==len(self.points):return ExitAction(done=True,reason='обе точки мостика пройдены по смещению кибелиска')
            target=self.points[self.index];distance=math.dist(self.position,target)
        if self.best is None or distance<self.best-self.width*.004:
            self.best=distance;self.progress=now
        if radar.heading is not None and radar.confidence>=.30:
            self.heading=radar.heading;self.heading_at=now
        if self.heading is None or now-self.heading_at>.6:
            yaw=.25 if now>=self.scan_at else 0
            if yaw:self.scan_at=now+.8
            return ExitAction(Drive(yaw=yaw,lifetime=.1),reason='направление камеры не читается; только короткий обзор без шага')
        if now-self.progress>6 and self.index>0 and now>=self.back_until:
            # Retrace the confirmed bridge, never sidestep off its edge.
            self.back_until=now+.7;self.progress=now;self.retries+=1
        retreat=now<self.back_until
        if retreat:
            target=self.points[self.index-1]
            if math.dist(self.position,target)<=tolerance:return ExitAction(reason='у входа в мост: повторяю проверку пути')
        desired=math.degrees(math.atan2(target[0]-self.position[0],self.position[1]-target[1]))%360
        error=angle_delta(desired,self.heading)
        if abs(error)>18:
            return ExitAction(Drive(yaw=self.nav._yaw(error,now),lifetime=.12),reason='сначала разворачиваю камеру вдоль мостика, без движения к краю')
        speed=.35 if distance<self.width*.04 or retreat else .60
        r=math.radians(error)
        drive=Drive(speed*math.cos(r),speed*math.sin(r),0,0,lifetime=.12)
        return ExitAction(drive,reason=('коротко отхожу по уже пройденной части мостика' if retreat else
                                       f'выход через мост: точка {self.index+1}/{len(self.points)}, осталось {distance/self.width:.3f} ширины миникарты'))
