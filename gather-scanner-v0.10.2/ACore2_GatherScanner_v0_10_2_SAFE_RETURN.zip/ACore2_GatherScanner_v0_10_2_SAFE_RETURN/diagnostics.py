"""Offline, no-input frame report for real icon/heading/flight verification."""
import json
from pathlib import Path
import cv2
from dataclasses import asdict
from flight import read_flight
from minimap import MinimapVision
from health import read_hp
from view_guard import scene_view
from vision import WorldVision,segment_count,gathering_panel,resource_header_visible,gather_result_full,gathering_panel_pair
from camera_working_view import working_view_ms


def analyze(frame,cfg,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    radar=MinimapVision(cfg).observe(frame)
    obs=WorldVision(tuple(cfg['target_names'])).scan(frame)
    reading=read_flight(frame)
    hp=read_hp(frame,cfg.get('hp_roi'))
    data={'flight':asdict(reading),'radar':asdict(radar),'vision':asdict(obs),
          'segments':segment_count(frame),'gather_panel':gathering_panel(frame),
          'gather_panel_pair':gathering_panel_pair(frame),
          'player_hp':asdict(hp) if hp else None,'scene_view':scene_view(frame),
          'resource_header':resource_header_visible(frame),'attempt_full':gather_result_full(frame),
          'working_view_ms':working_view_ms(cfg)}
    if data['vision']['candidate']:
        # The local tracking signature contains bytes, not report metadata.
        data['vision']['candidate'].pop('glyph',None)
    drawn=frame.copy();x0,y0,x1,y1=radar.bounds
    cv2.rectangle(drawn,(x0,y0),(x1,y1),(255,100,0),2)
    for m in radar.markers:
        colour=(0,255,0) if m.kind=='aether' else (255,255,255)
        cv2.circle(drawn,(m.x,m.y),10,colour,2)
    if obs.candidate:cv2.drawMarker(drawn,(int(obs.candidate.click_x),int(obs.candidate.click_y)),(0,0,255),cv2.MARKER_CROSS,18,2)
    cv2.imwrite(str(path.with_suffix('.png')),drawn)
    path.with_suffix('.json').write_text(json.dumps(data,ensure_ascii=False,indent=2,default=lambda x:int(x)),encoding='utf-8')
    return data


if __name__=='__main__':
    import sys
    root=Path(__file__).resolve().parent
    cfg=json.loads((root/'settings_gather.json').read_text(encoding='utf-8'))
    image=cv2.imread(sys.argv[1])
    if image is None:raise SystemExit('Не удалось прочитать кадр')
    print(json.dumps(analyze(image,cfg,Path(sys.argv[1]).with_name('diagnostic')),ensure_ascii=False,default=lambda x:int(x)))
