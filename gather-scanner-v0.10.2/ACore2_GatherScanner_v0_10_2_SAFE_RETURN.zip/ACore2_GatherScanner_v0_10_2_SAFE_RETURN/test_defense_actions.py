"""Regression: Tab selected the real attacker but no NPC spawn was captured."""
import struct,time,unittest
from unittest.mock import patch
from network_state import Flow,Telemetry,Node
from network_defense import NetworkDefense,attack_reason
from gamepad_input import TranslationKeeper
from test_navigation import GatherFixture
from test_network_control import Source
from test_network_state import v,gauge
import gather_engine as ge

def hit(actor,target,damage=1):
 return (v(target)+v(4)+v(0)+v(actor)+struct.pack('<I',100)+b'\0'+v(2)
         +struct.pack('<II',1,1)+v(10000)+v(damage)+b'\1\0')

def npc(actor=55,template=123):
 return (v(actor)+b'\0\0'+v(0)+struct.pack('<I',template)+b'\0\2'
         +struct.pack('<ffff',1,2,3,90)+b'\0\0\1'+v(200)+v(200))

class DefensePlans(unittest.TestCase):
 def setUp(self):
  self.f=Flow(own=7,selected=55);self.f.attacks[55]=1000
  self.d=NetworkDefense(55,1,7,100)
 def test_unknown_initial_npc_profile_does_not_block_a_verified_selected_attacker(self):
  self.assertIsNone(attack_reason(self.f,55,1100))
  self.assertEqual(self.d.plan(self.f,1100,100),'WAIT')
  self.assertEqual(self.d.plan(self.f,1300,100.2),'PAIR')
 def test_known_mob_without_a_hit_never_authorizes_attack(self):
  self.f.attacks.clear();self.f.npcs[55]={'dead':False,'summoned':False}
  self.assertIsNotNone(attack_reason(self.f,55,1100));self.assertEqual(self.d.plan(self.f,1100,100),'ABORT')
 def test_known_player_pet_and_resource_are_rejected(self):
  self.f.players[55]=900;self.assertIsNotNone(attack_reason(self.f,55,1100));self.f.players.clear()
  self.f.npcs[55]={'summoned':True};self.assertIsNotNone(attack_reason(self.f,55,1100));self.f.npcs.clear()
  self.f.nodes[55]=Node(55);self.assertIsNotNone(attack_reason(self.f,55,1100))
 def test_changed_selection_cannot_pass_the_second_confirmation(self):
  self.d.plan(self.f,1100,100);self.f.selected=56
  self.assertEqual(self.d.plan(self.f,1300,100.2),'TAB')
  self.assertIsNotNone(attack_reason(self.f,55,1300))
 def test_tab_is_not_repeated_before_its_reply(self):
  self.f.selected=0;self.assertEqual(self.d.plan(self.f,1100,100),'TAB');self.d.sent_tab(1100,100)
  self.assertEqual(self.d.plan(self.f,1200,100.1),'WAIT')
  self.assertEqual(self.d.plan(self.f,2700,101.6),'ABORT')
 def test_three_nonmatching_tab_replies_are_bounded(self):
  self.f.selected=0
  for i in range(3):
   self.assertEqual(self.d.plan(self.f,1100+i,100+i),'TAB')
   self.d.sent_tab(1100+i,100+i);self.f.selection_time=1100+i
  self.assertEqual(self.d.plan(self.f,1300,103),'ABORT')
 def test_retries_are_spaced_and_limited_to_three_pairs(self):
  self.d.plan(self.f,1100,100)
  self.assertEqual(self.d.plan(self.f,1300,100.2),'PAIR');self.d.sent_pair(1300,100.2)
  self.assertEqual(self.d.plan(self.f,1400,101),'WAIT')
  for now in (102.3,104.4):
   self.assertEqual(self.d.plan(self.f,4000,now),'PAIR');self.d.sent_pair(4000,now)
  self.assertEqual(self.d.plan(self.f,7000,107),'WAIT');self.assertEqual(self.d.pairs,3)
 def test_death_without_initial_profile_finishes_the_episode(self):
  self.f.deaths[55]=1200;self.assertEqual(self.d.plan(self.f,1250,100.3),'DONE')
 def test_old_damage_or_unknown_own_identity_does_not_authorize_attack(self):
  self.assertIsNotNone(attack_reason(self.f,55,14000));self.f.own=None
  self.assertIsNotNone(attack_reason(self.f,55,1100))

class DefenseTelemetry(unittest.TestCase):
 def setUp(self):self.t=Telemetry();self.t.feed(1,'008d',gauge(),900)
 def test_death_is_seen_when_the_attackers_spawn_predated_capture(self):
  self.t.feed(1,'0438',hit(55,7),1000)
  self.t.feed(1,'4236',v(55)+b'\0'+v(3),1100)
  self.assertEqual(self.t.flows[1].deaths[55],1100)
  self.assertNotIn(55,self.t.flows[1].npcs)
 def test_zero_hp_of_known_attacker_is_also_a_death_proof(self):
  self.t.feed(1,'0438',hit(55,7),1000)
  self.t.feed(1,'008d',v(55)+b'\2\1\0'+struct.pack('<Q',0),1100)
  self.assertEqual(self.t.flows[1].deaths[55],1100)
 def test_player_profile_is_negative_evidence_without_storing_its_name(self):
  self.t.feed(1,'4536',v(55)+bytes(40),950);self.t.feed(1,'0438',hit(55,7),1000)
  f=self.t.flows[1];f.selected=55
  self.assertEqual(f.players[55],950);self.assertIn('игрок',attack_reason(f,55,1100))
 def test_late_initial_npc_profile_preserves_actual_hit_evidence(self):
  self.t.feed(1,'0438',hit(55,7),1000);self.t.feed(1,'4136',npc(),1100)
  f=self.t.flows[1];f.selected=55
  self.assertIsNone(attack_reason(f,55,1200));self.assertEqual(f.npcs[55]['born_at'],1000)
 def test_respawn_cannot_reuse_an_old_hit_as_attack_permission(self):
  self.t.feed(1,'0438',hit(55,7),1000);self.t.feed(1,'4236',v(55)+b'\0'+v(3),1100)
  self.t.feed(1,'4136',npc(),1200);f=self.t.flows[1];f.selected=55
  self.assertNotIn(55,f.attacks);self.assertIsNotNone(attack_reason(f,55,1250))
 def test_our_outgoing_hit_is_distinct_from_damage_to_us(self):
  events=self.t.feed(1,'0438',hit(7,55,20),1100)
  self.assertEqual(self.t.flows[1].outgoing[55],(1100,20));self.assertEqual(self.t.flows[1].attacks,{})
  self.assertEqual(events[0]['kind'],'own_outgoing_hit')

class DefenseActions(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.source=Source();self.e.network=self.source
  self.source.state.collecting=None;self.source.state.attempt_active=False;self.source.state.selected=0
  self.source.state.attacks[55]=1000;self.e.network_attacker=55
  self.clock=100.;self.wall=1100
  self.patches=[patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),patch.object(ge.time,'time',side_effect=lambda:self.wall/1000)]
  for p in self.patches:p.start();self.addCleanup(p.stop)
 def tearDown(self):self.e._stop_defense_motion();super().tearDown()
 def tick(self,now,wall=None):
  self.clock=now
  if wall is not None:self.wall=wall
  self.e._network_defense_tick(now)
 def test_log_reproduction_one_tab_then_attack_without_initial_npc_profile(self):
  self.e.target='Сапфир';self.e.target_confirmed=True;self.e.network_target=(1,99);self.e.mode='APPROACH'
  self.e._defend_and_resume(resume=True)
  self.tick(100);self.assertEqual(self.commands,['TAB'])
  self.source.state.selected=55;self.source.state.selection_time=1100
  self.tick(100.1);self.tick(100.31,1300)
  self.assertEqual(self.commands,['TAB','ATTACK_PAIR']);self.assertEqual(self.e.mode,'DEFENSE')
  self.source.state.deaths[55]=1400;self.tick(100.4,1400)
  self.assertEqual(self.e.mode,'REACQUIRE');self.assertFalse(self.e.stop_event.is_set())
  self.assertNotIn('TAP_F',self.commands)
 def test_already_selected_attacker_is_attacked_without_another_tab(self):
  self.source.state.selected=55;self.e._defend_and_resume(resume=False)
  self.tick(100);self.tick(100.2,1300)
  self.assertEqual(self.commands,['ATTACK_PAIR'])
 def test_selection_change_at_final_guard_cancels_attack(self):
  self.source.state.selected=55;self.e._defend_and_resume(resume=False);self.tick(100)
  def guarded(command,authorize):
   self.source.state.selected=56
   if authorize():self.commands.append(command);return True
   return False
  self.e.bridge.send_guarded=guarded;self.tick(100.2,1300)
  self.assertNotIn('ATTACK_PAIR',self.commands);self.assertEqual(self.e.mode,'SEARCH')
 def test_unconfirmed_tab_does_not_hold_the_whole_scanner_forever(self):
  self.e._defend_and_resume(resume=False);self.tick(100);self.tick(101.6,2700)
  self.assertEqual(self.commands,['TAB']);self.assertIsNone(self.e.network_defense)
  self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.stop_event.is_set())
 def test_outgoing_confirmation_is_logged_without_claiming_keyboard_ack(self):
  self.source.state.selected=55;self.e._defend_and_resume(resume=False);self.tick(100);self.tick(100.2,1300)
  self.source.state.outgoing[55]=(1350,20);self.tick(100.4,1400)
  self.assertTrue(any('Сеть подтверждает наш удар' in x for x in self.log))
 def test_connection_change_revokes_the_combat_episode(self):
  self.e._defend_and_resume(resume=False);self.source.state.own=8;self.tick(100)
  self.assertIsNone(self.e.network_defense);self.assertNotIn('ATTACK_PAIR',self.commands)
 def test_resource_with_remaining_attempts_is_reacquired_after_death(self):
  self.e.target='Эфир';self.e.target_confirmed=True;self.e.network_target=(1,99)
  self.source.state.nodes[99].used=1;self.e._defend_and_resume(resume=True)
  self.source.state.deaths[55]=1200;self.tick(100.2,1300)
  self.assertEqual(self.e.mode,'REACQUIRE');self.assertNotIn('V',self.commands);self.assertNotIn('END_AIR',self.commands)

class MovingDefense(GatherFixture,unittest.TestCase):
 def test_collecting_never_gets_forward_movement_for_defense(self):
  source=Source();source.state.selected=55;source.state.attacks[55]=int(time.time()*1000)
  self.e.network=source;self.e.network_attacker=55;self.e.target='Эфир';self.e.target_confirmed=True
  self.e.mode='GATHER';self.e.collecting_visible=True;self.e.network_target=(1,99)
  self.input.drive(.6,0,0,0,lifetime=.3)
  self.e._defend_and_resume(resume=True)
  self.assertIsNone(self.e.defense_motion);self.assertEqual(self.pad.axes,(0,0,0,0))
  self.assertNotIn('V',self.commands);self.assertNotIn('END_AIR',self.commands)
 def test_self_collection_proof_revokes_a_patrol_translation_keeper(self):
  source=Source();source.state.selected=55;source.state.collecting=None;source.state.attempt_active=False
  source.state.attacks[55]=int(time.time()*1000);self.e.network=source;self.e.network_attacker=55
  self.input.drive(.6,0,0,0,lifetime=.3);self.e._defend_and_resume(resume=False)
  try:
   self.assertIsNotNone(self.e.defense_motion)
   source.state.attempt_active=True;time.sleep(.5)
   self.assertEqual(self.pad.axes,(0,0,0,0))
  finally:self.e._stop_defense_motion()
 def test_translation_continues_past_one_motion_lease_without_turning_camera(self):
  self.input.drive(.6,.1,.4,.2,lifetime=.1)
  keeper=TranslationKeeper(self.input,self.input.current_translation(),lambda:True)
  keeper.start()
  try:
   time.sleep(.45)
   self.assertEqual(self.pad.axes,(.1,.6,0,0))
  finally:keeper.close()
  self.assertEqual(self.pad.axes,(0,0,0,0))
 def test_lost_focus_ends_translation_and_watchdog_releases_it(self):
  allowed=[True];keeper=TranslationKeeper(self.input,(.6,0),lambda:allowed[0]);keeper.start()
  try:
   time.sleep(.1);allowed[0]=False;keeper.worker.join(1);time.sleep(.4)
   self.assertFalse(keeper.worker.is_alive());self.assertEqual(self.pad.axes,(0,0,0,0))
  finally:keeper.close()
 def test_ground_patrol_keeps_existing_translation_while_selecting_and_attacking(self):
  source=Source();source.state.selected=55;source.state.collecting=None;source.state.attempt_active=False
  source.state.attacks[55]=int(time.time()*1000);self.e.network=source;self.e.network_attacker=55
  self.e.mode='SEARCH';self.input.drive(.6,0,0,0,lifetime=.3)
  self.e._defend_and_resume(resume=False)
  try:
   self.assertIsNotNone(self.e.defense_motion)
   self.e._network_defense_tick(time.monotonic());time.sleep(.2)
   self.e._network_defense_tick(time.monotonic());time.sleep(.2)
   self.assertIn('ATTACK_PAIR',self.commands);self.assertEqual(self.pad.axes[1],.6)
  finally:self.e._stop_defense_motion()

if __name__=='__main__':unittest.main()
