"""Ten seconds of measured terrain stagnation -> one short side-flight."""
from dataclasses import dataclass
import math
from navigation import Drive

class PatrolStall:
    def __init__(self):
        self.at=None;self.since=None;self.valid_seconds=0;self.samples=0
        self.position=[0.,0.];self.anchor=[0.,0.];self.release_anchor=[0.,0.];self.used=False
    def reset(self,now=None,clear_used=False):
        self.at=now;self.since=now;self.valid_seconds=0;self.samples=0;self.anchor=list(self.position)
        if clear_used:self.used=False;self.release_anchor=list(self.position)
    def consume(self):
        self.used=True;self.release_anchor=list(self.position)
    def update(self,radar,walking,now):
        if not walking:self.reset(now);return False
        if self.at is None or now-self.at>1.2:self.reset(now)
        dt=max(0,min(.5,now-self.at));self.at=now
        scale=max(.5,(radar.bounds[2]-radar.bounds[0])/313)
        if radar.motion_valid:
            dx,dy=radar.displacement;self.position[0]+=dx;self.position[1]+=dy
            self.valid_seconds+=dt;self.samples+=1
        if self.used and math.dist(self.position,self.release_anchor)>8*scale:self.used=False
        if math.dist(self.position,self.anchor)>2.5*scale:
            self.reset(now);return False
        if (not self.used and self.since is not None and now-self.since>=10
            and self.valid_seconds>=6 and self.samples>=12):
            return True
        return False

@dataclass
class EscapeAction:
    drive:Drive|None=None
    command:str|None=None
    done:bool=False
    stop:bool=False
    failed_takeoff:bool=False
    reason:str=''

class PatrolEscape:
    def __init__(self,now,side=1):self.phase='OPEN';self.since=now;self.side=side;self.absent=None
    def phase_to(self,phase,now):self.phase=phase;self.since=now
    def step(self,now,reading):
        if self.phase=='OPEN':
            self.phase_to('WAIT',now);return EscapeAction(command='V',reason='одна попытка раскрыть крылья для выхода из деревьев')
        if self.phase=='WAIT':
            if reading.confirmed:
                if reading.energy is None or reading.energy<8:
                    self.phase_to('CLOSE',now)
                else:self.phase_to('MOVE',now)
            elif now-self.since>3.5:
                return EscapeAction(stop=True,failed_takeoff=True,reason='дуга не подтвердилась: остановка без повторного V')
            else:return EscapeAction()
        if self.phase=='MOVE':
            if not reading.confirmed or reading.energy is not None and reading.energy<8:self.phase_to('CLOSE',now)
            elif now-self.since>=1.0:self.phase_to('CLOSE',now)
            else:return EscapeAction(drive=Drive(-.35,.70*self.side,0,0,lifetime=.12,tilted_motion=True),reason='короткий отлёт назад/вбок без поворота камеры')
        if self.phase=='CLOSE':
            if reading.confirmed:
                self.phase_to('WAIT_CLOSE',now);return EscapeAction(command='END_AIR',reason='манёвр закончен: сразу складываю крылья')
            self.phase_to('WAIT_CLOSE',now)
        if self.phase=='WAIT_CLOSE':
            if not reading.confirmed:
                if self.absent is None:self.absent=now
                if now-self.absent>=.2:return EscapeAction(done=True,reason='крылья закрыты, продолжаю патруль')
            else:self.absent=None
            if now-self.since>2.5:return EscapeAction(stop=True,reason='закрытие не подтвердилось: остановка вместо повторных V')
            return EscapeAction()
        return EscapeAction(stop=True,reason='неизвестное состояние выхода из застревания')
