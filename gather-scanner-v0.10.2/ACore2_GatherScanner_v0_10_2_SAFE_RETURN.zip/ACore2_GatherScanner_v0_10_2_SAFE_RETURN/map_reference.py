"""Opt-in visual map registration. No game coordinates or memory access.

A user-captured reference and patrol polygon are required. Failed or ambiguous
registrations do not produce a direction. Full-map checks are performed at rest.
"""
from dataclasses import dataclass
from pathlib import Path
import math
import cv2
import numpy as np

ROOT=Path(__file__).resolve().parent


def arrow_mask(image):
    b,g,r=cv2.split(image.astype(np.int16))
    return np.where((r<=np.minimum(b,g)+3)&(np.minimum(b,g)>170),255,0).astype(np.uint8)


class ArrowLocator:
    def __init__(self,template):
        self.template=template
        self.rotations=[]
        if template is not None:
            n=template.shape[0]
            for angle in range(0,360,15):
                matrix=cv2.getRotationMatrix2D((n/2,n/2),-angle,1)
                self.rotations.append((angle,cv2.warpAffine(template,matrix,(n,n))))

    def locate(self,image,size,near=None,threshold=.60):
        if self.template is None:return None
        x0=y0=0
        if near is not None:
            x,y=near;r=round(size*1.0)
            x0,y0=max(0,round(x-r)),max(0,round(y-r))
            image=image[y0:min(image.shape[0],round(y+r)),x0:min(image.shape[1],round(x+r))]
        mask=arrow_mask(image);found=[]
        for factor in (.8,1.0,1.2):
            n=max(10,round(size*factor))
            if n>=min(mask.shape[:2]):continue
            for angle,rotation in self.rotations:
                tpl=cv2.resize(rotation,(n,n),interpolation=cv2.INTER_AREA)
                scores=cv2.matchTemplate(mask,tpl,cv2.TM_CCOEFF_NORMED)
                # Retain a second spatial peak as an ambiguity check on the map.
                for _ in range(2 if near is None else 1):
                    _,score,_,(x,y)=cv2.minMaxLoc(scores)
                    if score<threshold:break
                    found.append((float(score),x+n/2+x0,y+n/2+y0,float(angle)))
                    scores[max(0,y-n//2):y+n//2+1,max(0,x-n//2):x+n//2+1]=-1
        if not found:return None
        best=max(found)
        others=[p for p in found if math.hypot(p[1]-best[1],p[2]-best[2])>size*.65]
        if near is None and others and best[0]-max(p[0] for p in others)<.045:return None
        return best


@dataclass
class Registration:
    matrix:object
    matches:int
    inliers:int
    coverage:float


class TerrainMatcher:
    def __init__(self,reference):
        self.reference=reference
        self.scale=min(1,1500/reference.shape[1])
        self.small=cv2.resize(reference,None,fx=self.scale,fy=self.scale)
        self.orb=cv2.ORB_create(nfeatures=3500,fastThreshold=10)
        self.keypoints,self.descriptors=self.orb.detectAndCompute(self.gray(self.small),None)
        self.matcher=cv2.BFMatcher(cv2.NORM_HAMMING)

    @staticmethod
    def gray(image):
        return cv2.createCLAHE(2,(8,8)).apply(cv2.cvtColor(image,cv2.COLOR_BGR2GRAY))

    def register(self,image,mini=False):
        scale=min(1,1500/image.shape[1]);small=cv2.resize(image,None,fx=scale,fy=scale)
        kp,desc=self.orb.detectAndCompute(self.gray(small),None)
        if desc is None or self.descriptors is None or len(desc)<20:return None
        pairs=self.matcher.knnMatch(self.descriptors,desc,k=2)
        good=[a for pair in pairs if len(pair)==2 for a,b in [pair] if a.distance<.72*b.distance and a.distance<75]
        if len(good)<(12 if mini else 20):return None
        a=np.float32([self.keypoints[m.queryIdx].pt for m in good]);b=np.float32([kp[m.trainIdx].pt for m in good])
        matrix,mask=cv2.findHomography(a,b,cv2.RANSAC,3.5)
        if matrix is None or mask is None:return None
        valid=mask.ravel()>0;n=int(valid.sum())
        if n<(10 if mini else 16) or n/len(good)<.50:return None
        coverage=cv2.contourArea(cv2.convexHull(a[valid]))/(self.small.shape[0]*self.small.shape[1])
        if coverage<(.001 if mini else .02):return None
        spread=np.ptp(b[valid],axis=0)
        if not mini and (spread[0]<small.shape[1]*.25 or spread[1]<small.shape[0]*.20):return None
        # Convert the small-image transformation back to actual pixel units.
        matrix=np.diag([1/scale,1/scale,1])@matrix@np.diag([self.scale,self.scale,1])
        corners=np.float32([[[0,0],[self.reference.shape[1],0],[self.reference.shape[1],self.reference.shape[0]],[0,self.reference.shape[0]]]])
        projected=cv2.perspectiveTransform(corners,matrix)[0]
        if not np.isfinite(projected).all() or not cv2.isContourConvex(projected):return None
        ratio=abs(cv2.contourArea(projected))/(self.reference.shape[0]*self.reference.shape[1])
        if not (.0025 if mini else .04)<ratio<25:return None
        # A match confined to the game's little minimap is not evidence that
        # the full M map is open. Require the projected reference to fill it.
        if not mini and abs(cv2.contourArea(projected))/(image.shape[0]*image.shape[1])<.15:return None
        return Registration(matrix,len(good),n,float(coverage))


def transform(point,matrix):
    return tuple(map(float,cv2.perspectiveTransform(np.float32([[point]]),matrix)[0,0]))


@dataclass
class MapFix:
    position:tuple
    character_heading:float
    goal:tuple
    bearing:float
    outside:bool
    inliers:int
    arrow_score:float


class MapReference:
    def __init__(self,cfg):
        self.cfg=cfg;self.ready=False;self.matcher=None;self.waypoint=0;self.last_fix=None
        spec=cfg.get('world_map',{})
        file=(ROOT/spec.get('file','')).resolve()
        if not file.is_relative_to(ROOT) or not file.is_file():return
        image=cv2.imread(str(file));points=spec.get('waypoints',[]);zone=spec.get('zone',[])
        if image is None or len(points)<1 or len(zone)<3:return
        self.image=image;self.spec=spec;self.points=points;self.zone=np.array(zone,np.float32)
        arrow_file=(ROOT/spec.get('arrow_file','')).resolve()
        if not arrow_file.is_relative_to(ROOT):return
        arrow=cv2.imread(str(arrow_file),0)
        if arrow is None:return
        self.arrow=ArrowLocator(arrow);self.matcher=TerrainMatcher(image)
        self.ready=True;self.returning=False;self.next_check=0;self.next_terrain=0

    def choose_goal(self,position):
        outside=cv2.pointPolygonTest(self.zone,position,False)<0
        if outside:
            self.waypoint=min(range(len(self.points)),key=lambda i:math.hypot(self.points[i][0]-position[0],self.points[i][1]-position[1]))
            goal=self.points[self.waypoint]
        else:
            goal=self.points[self.waypoint%len(self.points)]
            if math.hypot(goal[0]-position[0],goal[1]-position[1])<self.spec.get('arrival_pixels',20):
                self.waypoint=(self.waypoint+1)%len(self.points);goal=self.points[self.waypoint]
        return tuple(goal),outside

    def locate(self,frame):
        if not self.ready:return None
        registration=self.matcher.register(frame)
        if registration is None:return None
        scale=frame.shape[1]/self.spec['frame_width']
        arrow=self.arrow.locate(frame,self.spec['arrow_size']*scale)
        if arrow is None:return None
        score,x,y,heading=arrow
        inverse=np.linalg.inv(registration.matrix)
        position=transform((x,y),inverse)
        # The player arrow is a CHARACTER heading, never a camera measurement.
        tip=(x+20*math.sin(math.radians(heading)),y-20*math.cos(math.radians(heading)))
        end=transform(tip,inverse)
        facing=math.degrees(math.atan2(end[0]-position[0],position[1]-end[1]))%360
        goal,outside=self.choose_goal(position)
        bearing=math.degrees(math.atan2(goal[0]-position[0],position[1]-goal[1]))%360
        fix=MapFix(position,facing,goal,bearing,outside,registration.inliers,score)
        self.last_fix=fix;self.returning=outside
        return fix

    def terrain_bearing(self,frame,radar,now):
        if not self.ready or self.last_fix is None or now<self.next_terrain:return None
        self.next_terrain=now+1.5
        x0,y0,x1,y1=radar.bounds;mini=frame[y0:y1,x0:x1]
        reg=self.matcher.register(mini,mini=True)
        if reg is None:return None
        position=transform((radar.center[0]-x0,radar.center[1]-y0),np.linalg.inv(reg.matrix))
        if not(-20<position[0]<self.image.shape[1]+20 and -20<position[1]<self.image.shape[0]+20):return None
        # Reject implausible jumps compared with the last full-map observation.
        if math.hypot(position[0]-self.last_fix.position[0],position[1]-self.last_fix.position[1])>self.image.shape[1]*.35:return None
        goal,outside=self.choose_goal(position)
        target=transform(goal,reg.matrix);cx,cy=radar.center[0]-x0,radar.center[1]-y0
        if math.hypot(target[0]-cx,target[1]-cy)<8:return None
        self.returning=outside
        return math.degrees(math.atan2(target[0]-cx,cy-target[1]))%360
