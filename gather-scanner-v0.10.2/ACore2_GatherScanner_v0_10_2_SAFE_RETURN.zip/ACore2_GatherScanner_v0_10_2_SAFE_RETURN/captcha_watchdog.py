# -*- coding: utf-8 -*-
"""Visual safety stop for Aion 2 Daevan verification.

Matches only FIXED Russian dialog text and layout from user's own genuine
screenshots. Does not identify or enter CAPTCHA challenge characters.
"""
import threading
import time
from pathlib import Path
import cv2
import numpy as np

class CenterDialogDetector:
    """Require TWO stable labels from the actual Russian Global dialog.

    Prior 'bright rectangle + dark surroundings' classifier was demonstrably
    overbroad: 3/3 normal battle screenshots incorrectly passed it.
    This one never examines the CAPTCHA answer or its distorted characters.
    """
    def __init__(self, template_dir=None):
        home=Path(template_dir) if template_dir else Path(__file__).resolve().parent
        self.header=cv2.imread(str(home/'captcha_header_reference.png'),cv2.IMREAD_GRAYSCALE)
        self.prompt=cv2.imread(str(home/'captcha_prompt_reference.png'),cv2.IMREAD_GRAYSCALE)
        if self.header is None or self.prompt is None:
            raise FileNotFoundError('Нет captcha_header_reference.png / captcha_prompt_reference.png — нужны оба файла патча!')
        self.last_debug={}

    def check(self,bgr):
        if bgr is None or bgr.size == 0:
            return False, 0.0
        h,w=bgr.shape[:2]
        # Scaling to common 1280-width coordinates makes different screen
        # resolutions comparable with the original screenshot (2048x1152).
        if w != 1280:
            f=1280.0/w
            bgr=cv2.resize(bgr,(1280,max(1,round(h*f))),interpolation=cv2.INTER_AREA)
        gray=cv2.cvtColor(bgr,cv2.COLOR_BGR2GRAY)
        H,W=gray.shape
        search_x=int(W*.25);search_y=int(H*.07)
        x_end=int(W*.75);y_end=int(H*.55)
        area=gray[search_y:y_end,search_x:x_end]
        best_header=-1.0
        best_location=None
        best_scale=1.0
        # Mild UI-scale variation tolerated without risking scanning the
        # entire screen or matching colorful AoE spell effects.
        for scale in (.80,.85,.90,.95,1.0,1.05,1.10,1.15,1.20):
            t=cv2.resize(self.header,None,fx=scale,fy=scale,interpolation=cv2.INTER_LINEAR)
            if t.shape[0]>=area.shape[0] or t.shape[1]>=area.shape[1]:
                continue
            _,score,_,p=cv2.minMaxLoc(cv2.matchTemplate(area,t,cv2.TM_CCOEFF_NORMED))
            if score>best_header:
                best_header=float(score)
                best_location=(search_x+p[0],search_y+p[1])
                best_scale=scale
        # An ordinary dialog, combat text or UI effect cannot trigger based
        # just on something vaguely light or rectangular anymore.
        if best_header<.76 or best_location is None:
            self.last_debug={'header':round(best_header,3),'prompt':None,'scale':best_scale,'detected':False}
            return False,max(0.0,best_header)
        # The static instruction appears 31px left and 59px down relative
        # to the header reference at baseline 1280x720. Search within +/-9px.
        xx=round(best_location[0]-31*best_scale)
        yy=round(best_location[1]+59*best_scale)
        t2=cv2.resize(self.prompt,None,fx=best_scale,fy=best_scale,interpolation=cv2.INTER_LINEAR)
        tol=max(7,round(10*best_scale))
        xa=max(0,xx-tol);ya=max(0,yy-tol)
        xb=min(W,xx+t2.shape[1]+tol);yb=min(H,yy+t2.shape[0]+tol)
        parea=gray[ya:yb,xa:xb]
        if parea.shape[0]<t2.shape[0] or parea.shape[1]<t2.shape[1]:
            self.last_debug={'header':round(best_header,3),'prompt':None,'scale':best_scale,'detected':False}
            return False,max(0.0,best_header)
        _,prompt_score,_,_=cv2.minMaxLoc(cv2.matchTemplate(parea,t2,cv2.TM_CCOEFF_NORMED))
        good=best_header>=.76 and prompt_score>=.70
        combined=float(.55*best_header+.45*prompt_score)
        self.last_debug={'header':round(best_header,3),'prompt':round(float(prompt_score),3),
                         'score':round(combined,3),'scale':best_scale,
                         'location':best_location,'detected':good}
        return good,combined


class AudioAlarm:
    """Direct warning tone to a named Windows output instead of default AE-7."""
    def __init__(self, logger=None):
        self.logger = logger or (lambda msg: None)
        self.stop_event = threading.Event()
        self.worker = None
        self.device_match = "AG271QG4"
        self._test_lock = threading.Lock()
        self._alert_lock = threading.Lock()

    def outputs(self):
        import sounddevice as sd
        devices = sd.query_devices()
        hostapis = sd.query_hostapis()
        result=[]
        for i, item in enumerate(devices):
            if item['max_output_channels'] > 0:
                host=hostapis[item['hostapi']]['name']
                result.append((i,item['name'],host))
        return result

    def choose_device(self, name=None):
        needle=(name if name is not None else self.device_match).strip().lower()
        candidates=[v for v in self.outputs() if needle and needle in (v[1]+' '+v[2]).lower()]
        if not candidates:
            raise RuntimeError("Аудиоустройство не найдено: "+repr(needle)+
                               ". Проверь имя в списке выходов; Sound Blaster не используется как запасной выход.")
        # Prefer WASAPI (low-latency Windows endpoint), DirectSound if not available.
        candidates.sort(key=lambda v: (0 if 'wasapi' in v[2].lower()
                                        else 1 if 'directsound' in v[2].lower()
                                        else 2, v[0]))
        return candidates[0]

    @staticmethod
    def tone(sr):
        # 3 strong warning bursts with silence between.
        chunks=[]
        for freq in (880,1100,880):
            n=int(sr*.25)
            t=np.arange(n,dtype=np.float32)/sr
            env=np.minimum(1, t/.018)*np.minimum(1, (n/sr-t)/.025)
            chunks.append((.31*np.sin(2*np.pi*freq*t)*env).astype('float32'))
            chunks.append(np.zeros(int(sr*.09),dtype='float32'))
        return np.concatenate(chunks)

    def _play(self, name, repeat=False):
        import sounddevice as sd
        ident, label, host = self.choose_device(name)
        info=sd.query_devices(ident)
        sr=int(info['default_samplerate']) if info['default_samplerate'] else 48000
        signal=self.tone(sr)
        channels = 2 if info['max_output_channels'] >= 2 else 1
        signal = np.repeat(signal.reshape(-1, 1), channels, axis=1)
        self.logger(f'ЗВУК: {label} [{host}], индекс={ident}, частота={sr}, каналов={channels}')
        try:
            with sd.OutputStream(device=ident, samplerate=sr,
                                 channels=channels, dtype='float32') as stream:
                while not self.stop_event.is_set():
                    stream.write(signal)
                    if not repeat: break
                    if self.stop_event.wait(.9): break
        except Exception as exc:
            self.logger(f'ОШИБКА ЗВУКА (монитор): {exc}')
            raise

    def test(self, name, error_cb=None):
        if not self._test_lock.acquire(blocking=False): return False
        def run():
            try:
                # Test never changes or cancels the ongoing CAPTCHA alarm.
                if self.worker and self.worker.is_alive():
                    self.logger('ТЕСТ: тревога уже играет; тест отложен.')
                    return
                self.stop_event.clear()
                self._play(name,repeat=False)
                self.logger('ТЕСТ ЗВУКА: сигнал отправлен на монитор.')
            except Exception as exc:
                if error_cb: error_cb(str(exc))
            finally:
                self._test_lock.release()
        threading.Thread(target=run,daemon=True).start()
        return True

    def start(self,name,error_cb=None):
        with self._alert_lock:
            if self.worker and self.worker.is_alive(): return
            self.stop_event.clear()
            def run():
                try:
                    self._play(name,repeat=True)
                except Exception as exc:
                    if error_cb: error_cb(str(exc))
            self.worker=threading.Thread(target=run,daemon=True)
            self.worker.start()

    def stop(self):
        self.stop_event.set()
