"""Use one measured stick magnitude; vary duration rather than assume linear gain.

The user's rough readings support comparisons at 0.45, not an angle model
across 0.30/0.35/0.60. Error is a delivered-axis-time balance, never degrees.
"""
PITCH_STRENGTH=.45


def pitch_pulse(error,max_seconds=.06):
    if abs(error)<.006:return 0.0,.02
    direction=1 if error>0 else -1
    return direction*PITCH_STRENGTH,max(.02,min(max_seconds,abs(error)/PITCH_STRENGTH))
