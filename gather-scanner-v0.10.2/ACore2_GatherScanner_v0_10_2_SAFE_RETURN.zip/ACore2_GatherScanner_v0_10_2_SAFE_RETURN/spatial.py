"""Map-scoped static atlas and freshness-limited server coordinates.

World axes: +X east, +Y south, +Z up; 100 world units per metre.
Static points are potential spawns, never proof that a live node exists.
"""
from pathlib import Path
import json
import math
import time
from functools import lru_cache

ROOT=Path(__file__).resolve().parent
POSITION_MAX_AGE=.8


@lru_cache(maxsize=1)
def resource_names():
    data=json.loads((ROOT/'assets'/'atlas'/'gather.json').read_text(encoding='utf-8'))
    return {int(key):value.get('names',{}).get('ru') for key,value in data['objects'].items() if key.isdigit()}


def geometry(state,node,now_ms=None,max_age=POSITION_MAX_AGE):
    now_ms=time.time()*1000 if now_ms is None else now_ms
    if (state is None or state.own is None or state.xyz is None or state.position_at is None
        or node is None or not node.visible or node.used==3 or node.xyz is None):return None
    age=(now_ms-state.position_at)/1000
    if not -.1<=age<=max_age:return None
    if not all(math.isfinite(v) for v in (*state.xyz,*node.xyz)):return None
    dx,dy,dz=((b-a)/100 for a,b in zip(state.xyz,node.xyz))
    planar=math.hypot(dx,dy)
    return dict(planar_m=planar,distance_m=math.hypot(planar,dz),height_m=dz,
                bearing=math.degrees(math.atan2(dx,-dy))%360,age=age,source=state.position_source)


class Atlas:
    def __init__(self,root=ROOT/'assets'/'atlas'):
        self.maps=json.loads((root/'maps.json').read_text(encoding='utf-8'))['maps']
        data=json.loads((root/'gather.json').read_text(encoding='utf-8'))
        self.objects=data['objects'];self.points=data['maps']
        self.kibelisks=json.loads((root/'kibelisks.json').read_text(encoding='utf-8'))

    def map_for_zone(self,zone):
        return next((name for name,meta in self.maps.items() if zone in meta.get('openZones',[])),None)

    def nearest(self,zone,xyz,templates=None,limit=5):
        name=self.map_for_zone(zone)
        if name is None:return []
        rows=self.points.get(self.maps[name]['table'],{});result=[]
        for template,points in rows.items():
            if templates is not None and template not in {str(t) for t in templates}:continue
            label=self.objects.get(template,{}).get('names',{}).get('ru',template)
            for point in points:
                if len(point)!=3:continue
                dx,dy,dz=((b-a)/100 for a,b in zip(xyz,point))
                result.append(dict(template=template,name=label,xyz=tuple(point),map=name,
                    planar_m=math.hypot(dx,dy),height_m=dz,live=False))
        return sorted(result,key=lambda row:row['planar_m'])[:limit]

    def describe(self,state,now_ms=None):
        if state is None:return 'Координаты: игровой поток ещё не определён.'
        layer=self.map_for_zone(state.map_id)
        text=f'Координаты: зона {state.map_id}, слой базы {layer or "не определён"}; живых ресурсов с XYZ: '+str(sum(n.visible and n.used!=3 and n.xyz is not None for n in state.nodes.values()))
        if state.position_at is None or state.xyz is None:return text+'; собственная позиция ещё не получена.'
        age=((time.time()*1000 if now_ms is None else now_ms)-state.position_at)/1000
        usable=state.own is not None and -.1<=age<=POSITION_MAX_AGE
        text+=f'; XYZ {tuple(round(v,1) for v in state.xyz)}, возраст {max(0,age):.2f} с ({state.position_source}); '+('свежая' if usable else 'устарела, точное наведение по ней отключено')
        node=state.nodes.get(state.collecting or state.selected)
        relative=geometry(state,node,now_ms)
        if relative:text+=f'; до ресурса {relative["distance_m"]:.1f} м, по высоте {relative["height_m"]:+.1f} м'
        if layer:
            count=sum(len(points) for points in self.points.get(self.maps[layer]['table'],{}).values())
            text+=f'; справочных точек на карте {count} (наличие ресурса не подтверждают)'
        return text
