"""Continuation has no hidden second press or downward probe burst."""
from dataclasses import replace
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from unittest.mock import patch
import cv2
import numpy as np
import gather_engine as ge
from test_navigation import GatherFixture
from test_network_control import Source
from test_ether_emblem import scene,ether


class FreshOwnPoint(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp()
        self.e.cfg.update(resource_click_interaction=True,repeat_owned_clicks=True,
                          preserve_owned_resource=True,collection_cursor_hold=True,
                          calibrate_during_collection=False)
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.nodes[99].template=1500000;self.f.nodes[99].gather_time=1000;self.f.nodes[99].used=1
        self.f.collecting=99;self.f.attempt_active=False
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
        self.frame=scene();self.e.candidate=ether(self.frame);self.e.current_size=(2480,1395)
        self.alt_held=True;self.e.collection_cursor_owned=True
        self.clock=100.;self.clicks=[];self.callback=lambda:None
        def wait(seconds,*args):self.clock+=seconds;return True
        def click(*args,**kwargs):
            self.clicks.append(self.positions[-1]);self.callback();return True
        self.input.tap_a=click
        for p in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),
                  patch.object(ge.time,'time',return_value=1.1),
                  patch.object(ge.GamepadInput,'wait',side_effect=wait)):
            p.start();self.addCleanup(p.stop)

    def test_zero_selection_does_not_prepend_a_second_a(self):
        self.f.selected=0;self.e.f_enable()
        self.assertEqual(len(self.clicks),1);self.assertEqual(self.e.owned_click_count,1)

    def test_zero_selection_with_stale_active_still_delivers_one_click(self):
        self.f.selected=0;self.f.attempt_active=True;self.e.f_enable()
        self.assertEqual(len(self.clicks),1);self.assertTrue(self.f.attempt_active)

    def test_first_click_starting_attempt_does_not_need_a_second_press(self):
        self.f.selected=0;self.callback=lambda:setattr(self.f,'attempt_active',True)
        self.e.f_enable();self.assertEqual(len(self.clicks),1);self.assertTrue(self.f.attempt_active)

    def test_caption_only_repeats_the_bound_point_without_four_downward_probes(self):
        self.frame=scene(badge=False);c=ether(self.frame)
        self.e.candidate=replace(c,click_y=c.click_y+20)
        expected=(self.e.candidate.click_x,self.e.candidate.click_y)
        self.e.f_enable();self.assertEqual(self.clicks,[expected])

    def test_caption_only_point_missing_after_cursor_settle_is_not_clicked(self):
        self.frame=scene(badge=False);self.e.candidate=ether(self.frame)
        cursor=self.e.bridge.cursor
        def moved(x,y):cursor(x,y);self.frame[:]=35
        self.e.bridge.cursor=moved;self.e.f_enable()
        self.assertEqual(self.clicks,[])

    def test_next_tick_reanchors_after_first_press_moves_the_scene(self):
        old=(self.e.candidate.click_x,self.e.candidate.click_y)
        def changed():
            self.frame=scene(y=450);fresh=self.e._network_world_observation(self.frame)
            self.e.snapshot=(fresh,self.clock,1,self.clock)
        self.callback=changed;self.e.f_enable();self.e.f_enable()
        self.assertEqual(self.clicks,[old])
        self.clock+=1;self.callback=lambda:None;self.e.f_enable()
        self.assertEqual(len(self.clicks),2);self.assertGreater(self.clicks[1][1],old[1]+150)

    def test_disappearing_point_between_ticks_does_not_reuse_the_last_coordinate(self):
        self.callback=lambda:self.frame.fill(35)
        self.e.f_enable();self.clock+=1;self.e.f_enable()
        self.assertEqual(len(self.clicks),1)

    def test_foreign_id_after_a_ends_the_series(self):
        self.callback=lambda:setattr(self.f,'selected',55)
        self.e.f_enable();self.clock+=1;self.e.f_enable()
        self.assertEqual(len(self.clicks),1)

    def test_active_ether_relocated_outside_roi_uses_shape_without_general_ocr(self):
        self.f.attempt_active=True;self.frame=scene(y=650)
        with patch.object(ge,'find_world_resource',side_effect=AssertionError('general OCR')):
            found=self.e._network_world_observation(self.frame).candidate
        self.assertIsNotNone(found);self.assertEqual(found.name,'Эфир')
        self.assertGreater(found.box[1],self.e.candidate.box[1]+350)

    def test_active_shape_recovery_chooses_the_caption_closest_to_the_previous_point(self):
        self.f.attempt_active=True;self.frame=scene(y=450)
        other=scene(x=2000,y=750);self.frame[other[:,:,0]!=35]=other[other[:,:,0]!=35]
        found=self.e._network_world_observation(self.frame).candidate
        self.assertIsNotNone(found);self.assertLess(found.click_x,1500)

    def test_repeat_records_actual_point_and_post_click_selected_id(self):
        point=(self.e.candidate.click_x,self.e.candidate.click_y)
        self.callback=lambda:setattr(self.f,'selected',0)
        self.e.f_enable()
        before=next(s for s in self.log if 'CLICK_POINT:' in s)
        after=next(s for s in self.log if 'CLICK_FEEDBACK:' in s)
        self.assertIn(f'point=({point[0]},{point[1]})',before)
        self.assertIn('stage=repeat',before);self.assertIn('selected=99',before)
        self.assertIn('selected=0',after);self.assertIn('delivered=True',after)

    def test_debug_stores_only_bounded_crops_and_retains_at_most_24(self):
        self.e.cfg['debug_screenshots']=True
        with TemporaryDirectory() as folder,patch.object(ge,'ROOT',Path(folder)):
            for _ in range(26):self.e.f_enable();self.clock+=1
            files=list((Path(folder)/'debug_clicks').glob('*.jpg'))
            self.assertEqual(len(files),24)
            for file in files:
                image=cv2.imread(str(file));self.assertLessEqual(image.shape[0],500)
                self.assertLessEqual(image.shape[1],560)
            self.assertEqual(len(list(Path(folder).rglob('*'))),25)

    def test_no_translation_or_contextual_f_in_any_owned_repeat(self):
        self.f.selected=0
        for _ in range(5):self.e.f_enable();self.clock+=1
        self.assertEqual(len(self.clicks),5);self.assertEqual(self.pad.axes,(0,0,0,0))
        self.assertFalse({'F_ON','TAP_F','V','END_AIR','TAB'}&set(self.commands))

    def test_pointer_drift_aborts_only_this_request_without_stopping_the_scanner(self):
        valid=[True];self.e.bridge.cursor_matches=lambda:valid[0]
        def click(*args,**kwargs):valid[0]=False;return False
        self.input.tap_a=click;self.e.f_enable()
        self.assertFalse(self.e.stop_event.is_set());self.assertEqual(self.e.network_target,(1,99))
        self.assertIsNone(self.e.halt_reason)
        self.assertTrue(any('следующий запрос заново проверит точку' in s for s in self.log))

    def test_final_cursor_move_settles_before_a(self):
        last_move=[None];cursor=self.e.bridge.cursor;delays=[]
        def moved(x,y):last_move[0]=self.clock;cursor(x,y)
        self.e.bridge.cursor=moved
        self.callback=lambda:delays.append(self.clock-last_move[0])
        self.e.f_enable();self.assertEqual(len(delays),1);self.assertGreaterEqual(delays[0],.059)

    def test_marker_leaving_the_hover_point_aborts_without_chasing_it_into_a_press(self):
        shifted=[False]
        def wait(seconds,*args):
            self.clock+=seconds
            if seconds==.06 and not shifted[0]:
                self.frame=np.roll(self.frame,60,axis=1);shifted[0]=True
            return True
        with patch.object(ge.GamepadInput,'wait',side_effect=wait):self.e.f_enable()
        self.assertEqual(self.clicks,[]);self.assertFalse(self.e.stop_event.is_set())
        self.assertTrue(any('CLICK_REANCHOR:' in s for s in self.log))

    def test_small_badge_motion_keeps_the_already_settled_interior_point(self):
        old=(self.e.candidate.click_x,self.e.candidate.click_y);shifted=[False]
        def wait(seconds,*args):
            self.clock+=seconds
            if seconds==.06 and not shifted[0]:
                self.frame=np.roll(self.frame,3,axis=1);shifted[0]=True
            return True
        with patch.object(ge.GamepadInput,'wait',side_effect=wait):self.e.f_enable()
        self.assertEqual(self.clicks,[old]);self.assertEqual(self.positions[-1],old)


class HoldPointGuard(GatherFixture,unittest.TestCase):
    def test_pointer_drift_during_a_hold_releases_the_button(self):
        self.alt_held=True;valid=[True]
        self.e.bridge.cursor_matches=lambda:valid[0]
        def wait(seconds,stop,focused):valid[0]=False;return focused()
        with patch.object(self.input,'wait',side_effect=wait):
            self.assertFalse(self.input.tap_a(self.e.stop_event,self.e.screen.focused,hold=.01))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.buttons,0)
        self.assertTrue(any('CURSOR_MISS' in s for s in self.log))


if __name__=='__main__':unittest.main()
