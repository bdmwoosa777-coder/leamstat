"""No gathering results -> one recovery, then one guarded return-scroll use."""
from dataclasses import dataclass
import cv2
import numpy as np
from navigation import Drive


class NoYieldWatch:
    def __init__(self,rescue_after=90,return_after=180):
        self.rescue_after=rescue_after;self.return_after=return_after
        self.idle=0.;self.at=None;self.result_stamp=None;self.identity=None
        self.rescue_used=False;self.next_return=0
    def pause(self):self.at=None
    def observe(self,now,identity,result=None):
        if self.at is not None:self.idle+=max(0,now-self.at)
        self.at=now
        if self.identity is not None and identity[0]!=self.identity[0]:
            self.idle=0.;self.rescue_used=False;self.result_stamp=None
        if self.identity and self.identity[1] is not None and identity[1] is not None and identity[1]!=self.identity[1]:
            self.idle=0.;self.rescue_used=False;self.result_stamp=None
        self.identity=identity
        if result is not None and (self.result_stamp is None or result[1]>self.result_stamp):
            self.result_stamp=result[1];self.idle=0.;self.rescue_used=False
            return True
        return False
    def rescue_due(self):return self.idle>=self.rescue_after and not self.rescue_used
    def return_due(self,now):return self.idle>=self.return_after and now>=self.next_return
    def attempted(self,now):self.next_return=now+self.return_after;self.rescue_used=True
    def relocated(self,now):self.idle=0.;self.at=now;self.rescue_used=False


@dataclass
class MapEvidence:
    signature:object=None
    purple:bool=False
    usable:bool=False
    loading:bool=False


def map_evidence(frame,bounds):
    gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
    loading=bool(np.mean(gray<35)>.92 and np.std(gray)<25)
    x0,y0,x1,y1=bounds;crop=frame[y0:y1,x0:x1]
    if crop.size==0 or min(crop.shape[:2])<24:return MapEvidence(loading=loading)
    g=cv2.cvtColor(crop,cv2.COLOR_BGR2GRAY);usable=not loading and float(np.std(g))>7
    signature=cv2.resize(cv2.GaussianBlur(g,(0,0),3),(32,32)).astype(np.float32)
    hsv=cv2.cvtColor(crop,cv2.COLOR_BGR2HSV);h,w=g.shape
    mask=cv2.inRange(hsv,(125,75,125),(168,255,255))
    yy,xx=np.ogrid[:h,:w];mask[(xx-w*.5)**2+(yy-h*.5)**2>(min(h,w)*.23)**2]=0
    count,labels,stats,centers=cv2.connectedComponentsWithStats(mask)
    purple=any(max(4,h*w*.00012)<=stats[i,cv2.CC_STAT_AREA]<=h*w*.025
               and stats[i,cv2.CC_STAT_HEIGHT]>=max(4,h*.025) for i in range(1,count))
    return MapEvidence(signature,purple,usable,loading)


def changed(before,after):
    if not before or not before.usable or not after.usable:return False
    a,b=before.signature,after.signature
    if a is None or b is None or a.shape!=b.shape:return False
    difference=float(np.mean(np.abs(a-b)))
    a=a-a.mean();b=b-b.mean();den=float(np.linalg.norm(a)*np.linalg.norm(b))
    correlation=float((a*b).sum()/den) if den>1 else 1
    return difference>16 and correlation<.80


@dataclass
class ReturnAction:
    drive:Drive|None=None
    command:str|None=None
    done:bool=False
    verified:bool=False
    failed_landing:bool=False
    reason:str=''


class ReturnSequence:
    def __init__(self,now,airborne=False):
        self.phase='CANCEL';self.since=now;self.airborne=airborne
        self.ground_since=None;self.folds=0;self.baseline=None;self.loading_seen=False;self.arrival_since=None
    def sent(self,now):self.since=now
    def step(self,now,airborne,evidence=None):
        elapsed=now-self.since
        if self.phase=='CANCEL':
            self.phase='SETTLE';self.since=now
            return ReturnAction(drive=Drive(-.25,0,0,0,lifetime=.18,tilted_motion=True))
        if self.phase=='SETTLE':
            if elapsed<.3:return ReturnAction()
            self.phase='LAND';self.since=now;elapsed=0
        if self.phase=='LAND':
            if airborne:
                self.airborne=True;self.ground_since=None
                if self.folds==0 or self.folds<2 and elapsed>=3:
                    self.folds+=1;self.since=now;return ReturnAction(command='END_AIR')
                if self.folds>=2 and elapsed>=5:
                    return ReturnAction(done=True,failed_landing=True,reason='посадка не подтверждена; свиток не нажимал')
                return ReturnAction()
            if self.ground_since is None:self.ground_since=now
            if now-self.ground_since<(3 if self.airborne else .5):return ReturnAction()
            self.phase='USE'
        if self.phase=='USE':
            self.phase='WAIT';self.since=now
            return ReturnAction(command='RETURN')
        if self.phase=='WAIT':
            if evidence:
                self.loading_seen|=evidence.loading
                hint=(changed(self.baseline,evidence)
                      or evidence.purple and self.baseline is not None and not self.baseline.purple
                      or self.loading_seen and evidence.usable)
                if elapsed>=6 and evidence.usable and hint:
                    if self.arrival_since is None:self.arrival_since=now
                    if now-self.arrival_since>=.6:return ReturnAction(done=True,verified=True,reason='изменение миникарты/кибелиск подтвердили перемещение')
                else:self.arrival_since=None
                if elapsed>=15 and evidence.usable and self.arrival_since is None:
                    return ReturnAction(done=True,reason='15 секунд ожидания: перенос не подтверждён, повторного нажатия нет')
            return ReturnAction()
        return ReturnAction()
