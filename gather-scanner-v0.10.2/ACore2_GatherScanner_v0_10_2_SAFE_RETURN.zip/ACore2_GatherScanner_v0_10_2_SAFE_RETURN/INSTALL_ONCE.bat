@echo off
cd /d "%~dp0"
call SETUP.bat
exit /b %errorlevel%
