"""Dark terrain must not claim wings are already open and block obstacle V."""
from pathlib import Path
import unittest
from unittest.mock import patch
import cv2,numpy as np
from flight import read_flight
from test_navigation import GatherFixture
import gather_engine as ge

ROOT=Path(__file__).resolve().parent

def track_image(fill_points=0):
    image=np.full((720,1280,3),(145,155,140),np.uint8)
    y=np.arange(476,727,dtype=float);x=1047+46*((y-597)/123)**2
    points=np.column_stack((np.rint(x*.5),np.rint((y+160)*.5))).astype('int32')
    cv2.polylines(image,[points],False,(15,15,15),6)
    if fill_points:cv2.polylines(image,[points[-fill_points:]],False,(240,255,50),4)
    return image

class FlightPresenceTests(unittest.TestCase):
    def test_perfect_curved_dark_terrain_without_coloured_energy_is_not_flight(self):
        value=read_flight(track_image())
        self.assertFalse(value.confirmed);self.assertIsNone(value.energy)
        self.assertGreater(value.evidence,110)
    def test_real_nearly_empty_coloured_gauge_still_blocks_new_takeoff(self):
        value=read_flight(track_image(12))
        self.assertTrue(value.confirmed);self.assertLess(value.energy,8)
    def test_real_flying_reference_still_has_a_confirmed_track(self):
        value=read_flight(cv2.imread(str(ROOT/'testdata/air_gather_example.jpg')))
        self.assertTrue(value.confirmed);self.assertGreater(value.energy,70)

class GroundStallFlightTests(GatherFixture,unittest.TestCase):
    def test_false_dark_arc_cannot_block_six_metre_obstacle_recovery(self):
        self.frame=track_image();self.e.screen.frame=lambda:(self.frame,(0,0))
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='APPROACH'
        self.e._reset_resource_watch(verified_header=True)
        self.e.last_distance=6;self.e.last_progress=0;self.e.native_route_started_at=0
        self.e.started=0;self.e.route_f_sent=True;self.e.route_active=True
        reading=read_flight(self.frame);self.assertFalse(reading.confirmed)
        with patch.object(ge,'read_target_distance',return_value=6),patch.object(ge,'segment_count',return_value=3),patch.object(ge.time,'monotonic',return_value=6.2):
            self.e._approach_fast_tick(self.frame,(0,0),reading,6.2)
        self.assertEqual(self.commands,['V']);self.assertEqual(self.e.mode,'TAKEOFF')
        self.assertTrue(self.e.wing_route_restart_pending)

if __name__=='__main__':unittest.main()
