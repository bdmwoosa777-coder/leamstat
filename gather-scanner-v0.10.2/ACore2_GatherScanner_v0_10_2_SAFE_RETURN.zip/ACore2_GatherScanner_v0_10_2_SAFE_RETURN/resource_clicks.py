"""Four downward probes relative to the current caption, independent of old misses."""
def ether_click_points(candidate,width,height):
    x,y,w,h=candidate.box;cx=round(x+w/2);bottom=round(y+h)
    gap=max(6,min(12,round(h*.6)));gaps=[gap]
    for minimum,factor in ((10,.75),(14,1.1),(18,1.5)):
        gap+=max(minimum,round(h*factor));gaps.append(gap)
    return tuple(dict.fromkeys((max(0,min(width-1,cx)),max(0,min(height-1,bottom+int(g)))) for g in gaps))
