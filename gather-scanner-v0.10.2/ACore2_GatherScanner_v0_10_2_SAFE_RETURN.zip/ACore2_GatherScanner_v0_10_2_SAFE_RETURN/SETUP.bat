@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
 python launch_setup.py
) else (
 py -3 launch_setup.py
)
if errorlevel 1 (
 echo Установка не завершилась. Скопируйте ошибку выше.
 pause
 exit /b 1
)
pause
