"""Observed Alt/camera overlap and loss of selected-resource world anchors."""
from pathlib import Path
from types import SimpleNamespace
import unittest,time
from unittest.mock import patch
import cv2,numpy as np
import vision
import gather_engine as ge
from bridge import GHubBridge
from test_navigation import GatherFixture
from test_network_control import Source
from test_ether_emblem import scene,ether

ROOT=Path(__file__).resolve().parent


def selected_scene(scale=1,letters=True,x=970,y=230):
    crop=cv2.imread(str(ROOT/'testdata/selected_resource_badge_crop.png'))
    if not letters:crop[120:143,137:216]=35
    crop=cv2.resize(crop,None,fx=scale,fy=scale)
    f=np.full((round(1395*scale),round(2480*scale),3),35,np.uint8)
    h,w=crop.shape[:2];x,y=round(x*scale),round(y*scale);f[y:y+h,x:x+w]=crop
    return f


class CursorCamera(GatherFixture,unittest.TestCase):
    def camera_held(self):
        self.alt_held=True;self.e.collection_cursor_owned=True

    def own(self):
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.nodes[99].template=1500000;self.f.nodes[99].gather_time=1000;self.f.nodes[99].used=1
        self.f.collecting=99;self.f.attempt_active=False
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
        self.e.cfg.update(resource_click_interaction=True,collection_cursor_hold=True,calibrate_during_collection=False)
        self.frame=scene();self.e.candidate=ether(self.frame)
        self.e.current_size=(2480,1395)

    def test_right_stick_releases_alt_before_any_nonzero_report(self):
        self.camera_held();events=[];original=self.pad.right_joystick_float
        def report(**kw):events.append((self.alt_held,kw));return original(**kw)
        self.pad.right_joystick_float=report
        self.input.drive(yaw=.3,pitch=.2,lifetime=.04)
        self.assertEqual(self.commands,['ALT_UP']);self.assertFalse(self.e.collection_cursor_owned)
        self.assertTrue(events);self.assertTrue(all(not alt for alt,kw in events))

    def test_camera_does_not_request_alt_when_it_is_already_up(self):
        self.input.drive(pitch=.3,lifetime=.04);self.assertEqual(self.commands,[])
        self.assertFalse(self.alt_held)

    def test_failed_alt_release_never_sends_camera_report(self):
        self.camera_held();self.e.bridge.send=lambda command:None
        with patch.object(self.e,'_wait_alt_state',return_value=False),patch.object(self.pad,'right_joystick_float') as report:
            self.assertFalse(self.input.drive(yaw=.3,lifetime=.04))
        report.assert_not_called();self.assertEqual(self.pad.axes,(0,0,0,0));self.assertTrue(self.e.stop_event.is_set())

    def test_translation_without_right_stick_does_not_release_alt(self):
        self.camera_held();self.input.drive(forward=.4,lifetime=.04)
        self.assertEqual(self.commands,[]);self.assertTrue(self.alt_held)

    def test_owned_cursor_cannot_be_rearmed_inside_camera_release(self):
        self.own();self.f.attempt_active=True;self.camera_held();send=self.e.bridge.send
        def release(command):
            result=send(command);self.e._prepare_collection_cursor();return result
        self.e.bridge.send=release;self.assertTrue(self.e._camera_input_ready())
        self.assertEqual(self.commands,['ALT_UP']);self.assertFalse(self.alt_held)

    def test_default_network_collection_never_recalibrates_its_current_view(self):
        self.own();self.f.attempt_active=True;self.camera_held()
        self.e.camera_search_revision=2;self.e.camera_aligned_revision=1
        with patch.object(self.e,'_hold_pitch_up') as up:
            self.assertTrue(self.e._calibrate_camera('while gathering',allow_gather=True))
        up.assert_not_called();self.assertFalse(self.e._gather_camera_needed());self.assertEqual(self.commands,[])

    def test_new_calibration_releases_cursor_before_first_pitch_command(self):
        self.camera_held();self.e.target_confirmed=False;self.e.resource_hold=False;self.e.mode='SEARCH'
        states=[]
        with patch.object(self.e,'_hold_pitch_up',side_effect=lambda *a:states.append(self.alt_held) or False),patch.object(self.e.cap,'check',return_value=(False,0)),patch.object(self.e.death,'check',return_value=(False,0)):
            self.e._calibrate_camera('test')
        self.assertEqual(states,[False]);self.assertEqual(self.commands,['ALT_UP'])

    def test_stuck_os_cursor_prevents_activation_and_does_not_reserve_request(self):
        self.own();self.camera_held();self.e.bridge.cursor_matches=lambda:False
        self.e.bridge.last_cursor_target=(1200,300);self.e.bridge.last_cursor_actual=(1280,720)
        self.e.f_enable()
        self.assertEqual(self.pad.presses,0);self.assertIsNone(self.e.next_attempt_sent_used)
        self.assertTrue(any('CURSOR_MISS' in message for message in self.log))

    def test_matching_os_cursor_allows_resource_activation(self):
        self.own();self.camera_held();self.e.bridge.cursor_matches=lambda:True
        self.e.f_enable();self.assertGreater(self.pad.presses,0)

    def test_selection_click_also_requires_cursor_readback(self):
        self.own();self.f.collecting=None;self.f.nodes[99].gather_time=None
        self.e.network_target=None;self.e.target_confirmed=False
        self.e.bridge.cursor_matches=lambda:False
        self.assertFalse(self.e.click_candidate(self.e.candidate,(0,0)))
        self.assertEqual(self.pad.presses,0)

    def test_visual_native_activation_also_requires_cursor_readback(self):
        self.own();self.f.collecting=None;self.f.selected=0;self.e.cfg['visual_route_hold']=True
        self.camera_held();now=time.monotonic();self.e.acquisition_clicked_at=now-1
        self.e.visual_selection=(1,0,'Эфир',now);self.e.bridge.cursor_matches=lambda:False
        self.assertFalse(self.e._start_visual_route(self.e.candidate,(0,0)))
        self.assertEqual(self.pad.presses,0);self.assertIsNone(self.e.visual_route)

    def test_far_moved_owned_plate_is_refound_during_active_attempt_without_name(self):
        self.own();self.f.attempt_active=True;self.frame=selected_scene(letters=False,x=1450,y=500)
        with patch.object(ge,'find_world_resource',side_effect=AssertionError('name OCR')):
            obs=self.e._network_world_observation(self.frame)
        self.assertIsNotNone(obs.candidate);self.assertIsNone(obs.candidate.glyph)
        self.assertIsNotNone(obs.candidate.emblem);self.assertEqual(obs.candidate.name,'Эфир')

    def test_badge_only_worker_anchor_can_continue_the_third_attempt(self):
        self.own();self.f.nodes[99].used=2;self.frame=selected_scene(letters=False,x=1450,y=500)
        obs=self.e._network_world_observation(self.frame);self.assertIsNotNone(obs.candidate)
        self.e.snapshot=(obs,time.monotonic(),1,time.monotonic());self.camera_held()
        self.e.f_enable();self.assertGreater(self.pad.presses,0)
        self.assertEqual(self.e.next_attempt_sent_used,2)

    def test_badge_only_anchor_lost_before_press_does_not_run_global_ocr(self):
        self.own();self.frame=selected_scene(letters=False)
        c=vision.find_selected_resource_badge(self.frame,'Эфир');self.assertIsNotNone(c)
        self.e.candidate=c;self.frame[:]=35
        with patch.object(ge,'find_resource_near',side_effect=AssertionError('global fallback')):
            self.assertIsNone(self.e._fresh_click_candidate(self.frame))

    def test_wait_snapshot_is_saved_once_per_remaining_attempt(self):
        self.own();self.frame[:]=35;self.e.cfg['debug_screenshots']=True
        self.e.click_retry_at=0
        with patch.object(self.e,'save_debug') as saved:
            self.e.f_enable();self.e.click_retry_at=0;self.e.f_enable()
        self.assertEqual(saved.call_count,1)


class PointerReadback(unittest.TestCase):
    def bridge(self,actual=(100,200),ok=True):
        b=object.__new__(GHubBridge);b.dry_run=False;b.last_cursor_target=(100,200);b.last_cursor_actual=None
        b._point_type=lambda:SimpleNamespace(x=0,y=0);b._byref=lambda p:p
        def get(p):p.x,p.y=actual;return ok
        b.win=SimpleNamespace(GetCursorPos=get);return b

    def test_matches_exact_target(self):self.assertTrue(self.bridge().cursor_matches())
    def test_accepts_small_settling_error(self):self.assertTrue(self.bridge((105,197)).cursor_matches())
    def test_detects_pointer_clamped_to_screen_center(self):self.assertFalse(self.bridge((1280,720)).cursor_matches())
    def test_failed_windows_read_cannot_authorize_a(self):self.assertFalse(self.bridge(ok=False).cursor_matches())


class SelectedBadgeReferences(unittest.TestCase):
    def test_real_selected_plate_in_four_scales_without_readable_caption(self):
        for scale in (.7,1,1.25,1.5):
            with self.subTest(scale=scale):
                c=vision.find_selected_resource_badge(selected_scene(scale,False),'Эфир')
                self.assertIsNotNone(c);self.assertIsNone(c.glyph);self.assertIsNotNone(c.emblem)

    def test_plain_resource_emblem_without_selection_arrows_is_insufficient(self):
        self.assertIsNone(vision.find_selected_resource_badge(scene(),'Эфир'))

    def test_paired_arrows_without_gather_emblem_are_insufficient(self):
        f=selected_scene();f[285:345,1100:1170]=35
        self.assertIsNone(vision.find_selected_resource_badge(f,'Эфир'))


if __name__=='__main__':unittest.main()
