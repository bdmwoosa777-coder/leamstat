import unittest
from unittest.mock import patch
from types import SimpleNamespace
from test_navigation import GatherFixture
from gamepad_input import GamepadInput
from bridge import GHubBridge
import gather_engine as ge

class AltSelectionGateTests(GatherFixture,unittest.TestCase):
    def test_missing_receiver_alt_stops_without_any_a_or_f(self):
        self.e.bridge.alt_is_down=lambda:False;self.e.cfg['alt_wait_seconds']=0
        clock=[100.]
        def wait(seconds,*args):clock[0]+=seconds;return True
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(GamepadInput,'wait',side_effect=wait):
            self.assertFalse(self.e.click_candidate(self.c,(0,0),refresh=False))
        if self.e.release_thread:self.e.release_thread.join(timeout=1)
        self.assertEqual(self.pad.presses,0);self.assertNotIn('TAP_F',self.commands)
        self.assertTrue(self.e.stop_event.is_set());self.assertTrue(any('Alt фактически не зажат' in line for line in self.log))
    def test_observed_alt_down_allows_a_but_release_must_be_observed_before_f(self):
        with patch.object(GamepadInput,'wait',return_value=True):
            self.assertTrue(self.e.click_candidate(self.c,(0,0),refresh=False))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.commands,['ALT_DOWN','ALT_UP','TAP_F'])
    def test_stuck_alt_after_a_blocks_path_f(self):
        self.e.bridge.alt_is_down=lambda:True;clock=[100.]
        def wait(seconds,*args):clock[0]+=seconds;return True
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(GamepadInput,'wait',side_effect=wait):
            self.assertFalse(self.e.click_candidate(self.c,(0,0),refresh=False))
        self.assertEqual(self.pad.presses,1);self.assertNotIn('TAP_F',self.commands)
        self.assertTrue(self.e.stop_event.is_set())
    def test_alt_disappearing_before_the_button_is_not_ignored(self):
        states=iter([True]+[False]*100)
        self.e.bridge.alt_is_down=lambda:next(states);clock=[100.]
        def wait(seconds,*args):clock[0]+=seconds;return True
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(GamepadInput,'wait',side_effect=wait):
            self.assertFalse(self.e.click_candidate(self.c,(0,0),refresh=False))
        self.assertEqual(self.pad.presses,0)

class BridgeAltStateTests(unittest.TestCase):
    def test_dry_bridge_models_down_and_up(self):
        b=GHubBridge(dry_run=True)
        self.assertFalse(b.alt_is_down());b.send('ALT_DOWN');self.assertTrue(b.alt_is_down())
        b.send('ALT_UP');self.assertFalse(b.alt_is_down())
    def test_live_reader_uses_key_high_bit_instead_of_packet_log(self):
        b=GHubBridge.__new__(GHubBridge);b.dry_run=False
        b.win=SimpleNamespace(GetAsyncKeyState=lambda key:-32768 if key==0xA4 else 0)
        self.assertTrue(b.alt_is_down())
        b.win.GetAsyncKeyState=lambda key:1
        self.assertFalse(b.alt_is_down())

if __name__=='__main__':unittest.main()
