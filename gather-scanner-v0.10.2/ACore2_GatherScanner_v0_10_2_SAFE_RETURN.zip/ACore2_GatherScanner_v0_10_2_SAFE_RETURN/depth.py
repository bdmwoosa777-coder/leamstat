"""Relative inverse depth and visible discontinuities, not metric height or a path."""
from pathlib import Path
import hashlib,json,time
import cv2,numpy as np
from scene import world_mask
ROOT=Path(__file__).resolve().parent

class DepthRunner:
 def __init__(self,device_id=0,cpu=False,log=lambda m:None):
  import onnxruntime as ort
  ort.disable_telemetry_events()
  self.manifest=json.loads((ROOT/'models/depth/model.json').read_text())
  p=ROOT/'models/depth'/self.manifest['file']
  if hashlib.sha256(p.read_bytes()).hexdigest()!=self.manifest['sha256']:raise RuntimeError('Повреждена модель глубины')
  o=ort.SessionOptions();o.intra_op_num_threads=2;o.inter_op_num_threads=1;o.enable_mem_pattern=False
  o.execution_mode=ort.ExecutionMode.ORT_SEQUENTIAL
  # Extended LayerNorm fusion fails for this upstream FP16 graph on ORT 1.23.
  o.graph_optimization_level=ort.GraphOptimizationLevel.ORT_ENABLE_BASIC
  for name,size in [('batch_size',1),('height',294),('width',518)]:o.add_free_dimension_override_by_name(name,size)
  providers=['CPUExecutionProvider']
  if not cpu and 'DmlExecutionProvider' in ort.get_available_providers():providers=[('DmlExecutionProvider',{'device_id':device_id}),'CPUExecutionProvider']
  self.session=ort.InferenceSession(str(p),sess_options=o,providers=providers);self.backend=self.session.get_providers()[0]
  self.mean=np.array([.485,.456,.406],np.float32)[None,None];self.std=np.array([.229,.224,.225],np.float32)[None,None]
  log('Глубина готова: '+self.backend)
 def predict(self,frame):
  start=time.perf_counter();rgb=cv2.cvtColor(frame,cv2.COLOR_BGR2RGB)
  rgb=cv2.resize(rgb,(518,294),interpolation=cv2.INTER_CUBIC).astype(np.float32)/255
  tensor=np.ascontiguousarray(((rgb-self.mean)/self.std).transpose(2,0,1)[None])
  result=self.session.run(['predicted_depth'],{'pixel_values':tensor})[0][0]
  if result.shape!=(294,518) or not np.isfinite(result).all():raise ValueError('Некорректная карта глубины')
  return result.astype(np.float32),(time.perf_counter()-start)*1000

def inspect_depth(raw,shape):
 if raw.ndim!=2 or not np.isfinite(raw).all():raise ValueError('Invalid depth')
 valid=world_mask(raw.shape);h,w=raw.shape
 # The avatar and HUD must not create a reported ledge at their outlines.
 valid[round(h*.38):round(h*.86),round(w*.43):round(w*.57)]=False
 values=raw[valid];low,high=np.percentile(values,[5,95]);span=float(high-low)
 norm=np.zeros_like(raw,np.float32)
 if span>1e-5:norm=np.clip((raw-low)/span,0,1).astype(np.float32)
 smooth=cv2.GaussianBlur(norm,(5,5),0);offset=max(2,round(h*.018))
 delta=np.zeros_like(norm);delta[offset:-offset]=smooth[2*offset:]-smooth[:-2*offset]
 paired=np.zeros_like(valid);paired[offset:-offset]=valid[2*offset:]&valid[:-2*offset]
 edge=(delta>.16)&paired&valid
 edge[:round(h*.30)]=False;edge[round(h*.83):]=False
 count,labels,stats,_=cv2.connectedComponentsWithStats(edge.astype(np.uint8))
 keep=np.zeros_like(edge)
 for i in range(1,count):
  if stats[i,cv2.CC_STAT_AREA]>=max(4,h*w*.00006):keep|=labels==i
 H,W=shape[:2];depth=cv2.resize(norm,(W,H),interpolation=cv2.INTER_LINEAR)
 edges=cv2.resize(keep.astype(np.uint8),(W,H),interpolation=cv2.INTER_NEAREST).astype(bool)
 view=cv2.applyColorMap(np.round(depth*255).astype(np.uint8),cv2.COLORMAP_INFERNO)
 view[~world_mask((H,W))]=0
 meta={'relative_only':True,'larger_is_nearer':True,'metric_height_m':None,'fall_detected':None,
       'path_certified':False,'usable_contrast':span>1e-5,'edge_pixels':int(edges.sum()),
       'edge_kind':'near_below_far_above_candidate','normalization':'per-frame 5th/95th percentiles',
       'sectors':{name:float(np.mean(edges[round(H*.4):round(H*.82),round(W*a):round(W*b)])) for name,a,b in [('left',.18,.4),('center',.4,.62),('right',.62,.8)]}}
 return depth,edges,view,meta
