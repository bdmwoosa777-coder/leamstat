import unittest
from unittest.mock import patch
from patrol_escape import PatrolStall,PatrolEscape
from flight import FlightReading
from test_navigation import GatherFixture,obs
from test_exploration import radar
import gather_engine as ge

AIR=FlightReading(50,True)
GROUND=FlightReading(None,False)

class PatrolStallTests(unittest.TestCase):
    def test_ten_seconds_of_measured_stagnation_allows_one_attempt_per_blockage(self):
        t=PatrolStall();due=[]
        for i in range(22):
            value=t.update(radar(flow=(0,0),valid=True),True,i*.5)
            if value:due.append(i*.5);t.consume()
        self.assertEqual(due,[10])
        for i in range(22,50):self.assertFalse(t.update(radar(flow=(0,0),valid=True),True,i*.5))
        self.assertTrue(t.used)
    def test_real_progress_does_not_trigger_short_flight(self):
        t=PatrolStall()
        for i in range(61):self.assertFalse(t.update(radar(flow=(-.5,0),valid=True),True,i*.5))
    def test_unknown_map_motion_cannot_authorize_blind_escape(self):
        t=PatrolStall()
        for i in range(61):self.assertFalse(t.update(radar(valid=False),True,i*.5))
    def test_standing_to_scan_is_not_a_patrol_stall(self):
        t=PatrolStall()
        for i in range(61):self.assertFalse(t.update(radar(flow=(0,0),valid=True),False,i*.5))
    def test_after_real_translation_another_blockage_can_be_handled(self):
        t=PatrolStall()
        for i in range(21):due=t.update(radar(flow=(0,0),valid=True),True,i*.5)
        self.assertTrue(due);t.consume()
        t.update(radar(flow=(-9,0),valid=True),True,10.5);self.assertFalse(t.used)
        for i in range(22,42):due=t.update(radar(flow=(0,0),valid=True),True,i*.5)
        self.assertTrue(due)
    def test_skipped_attempt_does_not_consume_the_future_permission(self):
        t=PatrolStall()
        for i in range(21):due=t.update(radar(flow=(0,0),valid=True),True,i*.5)
        self.assertTrue(due);self.assertFalse(t.used)
        self.assertTrue(t.update(radar(flow=(0,0),valid=True),True,10.5))

class ShortFlightTests(unittest.TestCase):
    def test_one_open_confirmed_short_side_move_one_close(self):
        e=PatrolEscape(0)
        self.assertEqual(e.step(0,GROUND).command,'V')
        move=e.step(.1,AIR);self.assertIsNotNone(move.drive)
        self.assertGreater(abs(move.drive.strafe),.5);self.assertEqual(move.drive.pitch,0)
        self.assertEqual(e.step(1.2,AIR).command,'END_AIR')
        self.assertFalse(e.step(1.3,GROUND).done)
        self.assertTrue(e.step(1.6,GROUND).done)
    def test_unknown_flight_never_moves_and_never_repeatedly_toggles_v(self):
        e=PatrolEscape(0);self.assertEqual(e.step(0,GROUND).command,'V')
        self.assertIsNone(e.step(1,GROUND).drive)
        action=e.step(3.6,GROUND);self.assertTrue(action.stop);self.assertTrue(action.failed_takeoff)
        self.assertIsNone(action.command)
    def test_low_energy_after_open_closes_without_motion(self):
        e=PatrolEscape(0);e.step(0,GROUND)
        action=e.step(.1,FlightReading(4,True))
        self.assertEqual(action.command,'END_AIR');self.assertIsNone(action.drive)
    def test_failed_close_stops_instead_of_an_endless_hover(self):
        e=PatrolEscape(0);e.step(0,GROUND);e.step(.1,AIR);e.step(1.2,AIR)
        self.assertTrue(e.step(4,AIR).stop)

class PatrolEngineTests(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg['auto_view_recovery']=False
    def step_stationary(self,now,reading=GROUND):
        with patch.object(ge,'gathering_panel_pair',return_value=False),patch.object(ge,'segment_count',return_value=None):
            self.e.step(self.frame,(0,0),obs(),radar(flow=(0,0),valid=True),reading,now)
    def test_ground_avoidance_does_not_reset_the_ten_second_patrol_watch(self):
        for i in range(21):self.step_stationary(i*.5)
        self.assertEqual(self.e.mode,'PATROL_ESCAPE');self.assertIsNotNone(self.e.patrol_escape)
        self.assertTrue(self.e.patrol_stall.used)
        self.assertNotIn('F_ON',self.commands);self.assertNotIn('TAP_F',self.commands)
        self.step_stationary(10.1,GROUND)
        self.assertEqual(self.commands,['V'])
        self.step_stationary(10.2,AIR)
        self.assertGreater(abs(self.pad.axes[0]),.5)
        self.step_stationary(11.4,AIR)
        self.assertEqual(self.commands,['V','END_AIR'])
        self.step_stationary(11.5,GROUND);self.step_stationary(11.8,GROUND)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.patrol_escape)
        for i in range(25,55):self.step_stationary(i*.5)
        self.assertEqual(self.commands.count('V'),1)
    def test_gathering_appearing_mid_escape_stops_without_fold_or_movement(self):
        self.e.patrol_escape=PatrolEscape(0);self.e.mode='PATROL_ESCAPE'
        with patch.object(ge,'gathering_panel_pair',return_value=True):
            self.e._patrol_escape_tick(self.frame,AIR,1)
        self.assertTrue(self.e.stop_event.is_set());self.assertNotIn('V',self.commands);self.assertNotIn('END_AIR',self.commands)
    def test_low_budget_keeps_escape_available_until_energy_recovers(self):
        self.e.budget.energy=3;self.e.budget.blocked=True
        for i in range(21):self.step_stationary(i*.5)
        self.assertIsNone(self.e.patrol_escape);self.assertFalse(self.e.patrol_stall.used)
        self.e.budget.energy=30;self.e.budget.blocked=False
        self.step_stationary(10.5)
        self.assertIsNotNone(self.e.patrol_escape)

if __name__=='__main__':unittest.main()
