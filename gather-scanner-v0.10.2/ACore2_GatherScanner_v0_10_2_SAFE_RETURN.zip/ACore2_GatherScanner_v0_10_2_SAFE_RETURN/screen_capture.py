import os
import numpy as np


class ScreenCapture:
    def __init__(self):
        self.hwnd=None;self.title=''
        if os.name=='nt':
            import win32gui
            self.win32gui=win32gui

    def pick(self):
        if os.name!='nt':return 'OFFLINE'
        options=[]
        def cb(h,_):
            if self.win32gui.IsWindowVisible(h):
                name=self.win32gui.GetWindowText(h)
                if 'aion2' in name.lower() or 'aion 2' in name.lower():options.append((h,name))
        self.win32gui.EnumWindows(cb,None)
        if not options:return None
        self.hwnd,self.title=options[0];return self.title

    def focused(self):
        return os.name!='nt' or self.hwnd is not None and self.win32gui.GetForegroundWindow()==self.hwnd

    def frame(self):
        if os.name!='nt':raise RuntimeError('Захват игры доступен только на Windows')
        if not self.hwnd or not self.win32gui.IsWindow(self.hwnd):raise RuntimeError('Окно AION2 не найдено')
        left,top=self.win32gui.ClientToScreen(self.hwnd,(0,0))
        _,_,w,h=self.win32gui.GetClientRect(self.hwnd)
        import mss
        with mss.mss() as capture:
            frame=np.array(capture.grab({'left':left,'top':top,'width':w,'height':h}))[:,:,:3].copy()
        return frame,(left,top)
