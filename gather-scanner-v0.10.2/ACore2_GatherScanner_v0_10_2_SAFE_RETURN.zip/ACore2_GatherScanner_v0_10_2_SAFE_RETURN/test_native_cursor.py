"""A must be a cursor click, never the game's unmodified flight accelerator."""
from pathlib import Path
from types import SimpleNamespace
import threading,time,unittest
from unittest.mock import patch
import cv2,numpy as np
import vision
import gather_engine as ge
from app import DEFAULT
from gamepad_input import GamepadInput
from test_navigation import Pad,GatherFixture
from test_network_control import Source
from test_ether_emblem import scene,ether

LB=0x0100;A=0x1000

class Reports(Pad):
    def __init__(self):super().__init__();self.reports=[]
    def update(self):
        self.reports.append((self.buttons,self.lt,self.axes));super().update()

class NativeTransport(unittest.TestCase):
    def setUp(self):
        self.pad=Reports();self.logs=[];self.stop=threading.Event()
        self.input=GamepadInput(factory=lambda:self.pad,a_button=A,logger=self.logs.append)
        self.input.native_cursor=True;self.addCleanup(self.input.close)

    def begin(self):
        with patch.object(self.input,'wait',return_value=True):
            return self.input.begin_cursor(self.stop,lambda:True)

    def test_bare_a_is_blocked_without_native_cursor(self):
        self.assertFalse(self.input.tap_a(self.stop,lambda:True,hold=.01))
        self.assertEqual(self.pad.presses,0);self.assertEqual(self.pad.buttons,0)

    def test_begin_holds_lb_and_lt_without_a_or_movement(self):
        self.assertTrue(self.begin());self.assertEqual(self.pad.buttons,LB)
        self.assertEqual(self.pad.lt,1);self.assertEqual(self.pad.presses,0)
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_every_a_down_and_up_report_retains_cursor_modifiers(self):
        self.begin();start=len(self.pad.reports)
        with patch.object(self.input,'wait',return_value=True):
            self.assertTrue(self.input.tap_a(self.stop,lambda:True))
        reports=self.pad.reports[start:]
        self.assertTrue(any(buttons&A for buttons,lt,axes in reports))
        self.assertTrue(all(buttons&LB and lt==1 and axes==(0,0,0,0) for buttons,lt,axes in reports))
        self.assertEqual(self.pad.buttons,LB);self.assertEqual(self.pad.lt,1)
        self.input.release_cursor();self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.lt,0)

    def test_repeated_a_never_gets_an_unmodified_report(self):
        self.begin()
        with patch.object(self.input,'wait',return_value=True):
            for _ in range(3):self.assertTrue(self.input.tap_a(self.stop,lambda:True))
        self.assertEqual(self.pad.presses,3)
        self.assertTrue(all(buttons&LB and lt==1 for buttons,lt,axes in self.pad.reports if buttons&A))

    def test_existing_cursor_is_renewed_without_an_extra_a(self):
        self.begin();n=len(self.pad.reports);self.assertTrue(self.begin())
        self.assertEqual(len(self.pad.reports),n);self.assertEqual(self.pad.presses,0)

    def test_stop_during_cursor_prepare_releases_all(self):
        def wait(*args):self.stop.set();return False
        with patch.object(self.input,'wait',side_effect=wait):self.assertFalse(self.input.begin_cursor(self.stop,lambda:True))
        self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.lt,0)

    def test_focus_loss_during_a_releases_all(self):
        self.begin();focused=[True]
        def wait(*args):focused[0]=False;return False
        with patch.object(self.input,'wait',side_effect=wait):self.assertFalse(self.input.tap_a(self.stop,lambda:focused[0]))
        self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.lt,0)

    def test_driver_failure_after_partial_press_releases_all(self):
        self.begin();self.pad.fail=True
        with self.assertRaises(RuntimeError):self.input.tap_a(self.stop,lambda:True)
        self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.lt,0)

    def test_watchdog_expires_abandoned_cursor(self):
        self.begin();self.input.cursor_deadline=time.monotonic()-.01
        until=time.monotonic()+.5
        while self.input.cursor_held and time.monotonic()<until:time.sleep(.01)
        self.assertFalse(self.input.cursor_held);self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.lt,0)

    def test_reset_releases_both_modifiers(self):
        self.begin();self.input.reset()
        self.assertFalse(self.input.cursor_held);self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.lt,0)


class NativeEngine(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(native_cursor_chord=True,resource_click_interaction=True,
            repeat_owned_clicks=True,preserve_owned_resource=True,collection_cursor_hold=True)
        self.input.native_cursor=True
        self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.nodes[99].template=1500000;self.f.nodes[99].gather_time=1000;self.f.nodes[99].used=1
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
        self.frame=scene();self.e.candidate=ether(self.frame);self.e.current_size=(2480,1395)
        self.alt_held=True

    def test_enabled_in_default_application_policy(self):self.assertTrue(DEFAULT['native_cursor_chord'])

    def test_keyboard_alt_alone_does_not_authorize_a(self):
        self.assertFalse(self.e._a_input_ready());self.assertEqual(self.pad.presses,0)

    def test_native_cursor_is_ready_before_engine_moves_pointer(self):
        old=self.e.bridge.cursor;states=[]
        def cursor(x,y):states.append((self.pad.buttons,self.pad.lt));old(x,y)
        self.e.bridge.cursor=cursor
        with patch.object(GamepadInput,'wait',return_value=True):self.e.f_enable()
        self.assertTrue(states);self.assertTrue(all(buttons&LB and lt==1 for buttons,lt in states))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.buttons,LB)
        self.assertFalse({'F_ON','TAP_F','V','END_AIR'}&set(self.commands))

    def test_camera_releases_native_cursor_and_alt_before_report(self):
        with patch.object(GamepadInput,'wait',return_value=True):
            self.assertTrue(self.e._wait_alt_state(True))
            self.input.drive(0,0,.2,.1,lifetime=.05)
        self.assertFalse(self.input.cursor_held);self.assertFalse(self.alt_held)
        self.assertEqual(self.pad.buttons,0);self.assertEqual(self.pad.lt,0)
        self.assertNotEqual(self.pad.axes[2:],(0,0))

    def test_leaving_alt_releases_native_modifiers_before_lua_command(self):
        observed=[];send=self.e.bridge.send
        def command(name):observed.append((name,self.pad.buttons,self.pad.lt));return send(name)
        self.e.bridge.send=command
        with patch.object(GamepadInput,'wait',return_value=True):self.e._wait_alt_state(True)
        self.e.bridge_cmd('ALT_UP')
        self.assertEqual(observed[-1],('ALT_UP',0,0));self.assertFalse(self.input.cursor_held)

    def test_visible_owned_marker_gets_a_click_before_camera_recovery(self):
        self.f.attempt_active=False;now=time.monotonic();self.e._arm_view_recovery(now)
        self.e.view_recovery.next_at=now-.1
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(self.input,'drive',wraps=self.input.drive) as drive:
            self.assertTrue(self.e._view_recovery_tick(self.frame,None,now))
        self.assertEqual(self.pad.presses,1);drive.assert_not_called()
        self.assertIsNotNone(self.e.view_recovery.point_attempt_at)

    def test_visible_but_unresponsive_point_can_still_recover_after_one_second(self):
        self.f.attempt_active=False;now=time.monotonic();self.e._arm_view_recovery(now)
        self.e.view_recovery.point_attempt_at=now-2;self.e.view_recovery.next_at=now-.1
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(self.input,'drive',wraps=self.input.drive) as drive:
            self.assertTrue(self.e._view_recovery_tick(self.frame,None,now))
        drive.assert_called_once()

    def test_new_shape_fallback_is_not_available_before_own_collection(self):
        self.e.candidate=None;self.f.collecting=None;self.f.nodes[99].gather_time=None
        self.e.mode='APPROACH';self.e.route_f_sent=False
        with patch.object(ge,'find_world_resource',return_value=None),patch.object(ge,'find_owned_resource_emblem') as owned:
            self.assertIsNone(self.e._network_world_observation(self.frame).candidate)
        owned.assert_not_called()


class OccludedCaption(unittest.TestCase):
    def frame(self,scale=1,selected=True,x=1175,y=529):
        file='selected_green_marker.png' if selected else 'resource_emblem_close.png'
        crop=cv2.imread(str(Path(vision.ROOT)/'testdata'/file))
        crop=cv2.resize(crop,None,fx=scale,fy=scale)
        image=np.full((round(1440*scale),round(2560*scale),3),(125,95,65),np.uint8)
        x,y=round(x*scale),round(y*scale);h,w=crop.shape[:2];image[y:y+h,x:x+w]=crop
        return image

    def test_green_chevrons_work_without_readable_caption_in_three_scales(self):
        with patch.object(vision.pytesseract,'image_to_string',side_effect=AssertionError('OCR')):
            for scale in (.6,1,1.4):
                c=vision.find_selected_resource_badge(self.frame(scale),'Эфир')
                self.assertIsNotNone(c,scale);self.assertIsNotNone(c.emblem)

    def test_unselected_emblem_survives_missing_name_and_arrows(self):
        c=vision.find_owned_resource_emblem(self.frame(selected=False),'Эфир')
        self.assertIsNotNone(c);self.assertIsNone(c.glyph)

    def test_unknown_owned_name_can_use_an_emblem(self):
        self.assertEqual(vision.find_owned_resource_emblem(self.frame(selected=False),ge.OWN_RESOURCE).name,ge.OWN_RESOURCE)

    def test_empty_sky_is_not_an_emblem(self):
        frame=np.full((1440,2560,3),(125,95,65),np.uint8)
        self.assertIsNone(vision.find_owned_resource_emblem(frame,'Эфир'))

    def test_emblem_in_chat_or_minimap_cannot_authorize_continuation(self):
        for x,y in ((100,1100),(2200,180)):
            self.assertIsNone(vision.find_owned_resource_emblem(self.frame(selected=False,x=x,y=y),'Эфир'))

    def test_npc_flag_is_not_a_resource_emblem(self):
        frame=np.full((1440,2560,3),(125,95,65),np.uint8)
        cv2.line(frame,(1300,500),(1300,680),(220,220,220),4)
        cv2.rectangle(frame,(1300,510),(1355,555),(230,170,40),-1)
        self.assertIsNone(vision.find_owned_resource_emblem(frame,'Эфир'))


if __name__=='__main__':unittest.main()
