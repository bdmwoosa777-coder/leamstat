"""Own results grant continuation; delivery remains pending until real progress."""
class CollectionCycle:
    def __init__(self):self.reset()

    def reset(self):
        self.binding=None;self.attempt=None;self.panel_seen=False;self.partial_seen=False
        self.absent_since=None;self.consumed=set();self.reservations={}
        self.clear_pending()

    def clear_pending(self):
        self.pending=None;self.pending_since=None
        self.waiting_kind=None;self.waiting_used=None;self.waiting_since=None

    def failed(self,now):
        if self.pending_since is not None:return now-self.pending_since>=8
        return self.waiting_since is not None and now-self.waiting_since>=12

    def observe(self,binding,attempt,now,panel,full,result_used=None,result_valid=False,resume_allowed=False,current_used=None):
        if binding!=self.binding:
            self.reset();self.binding=binding
        if attempt!=self.attempt:
            self.clear_pending()
            self.attempt=attempt;self.partial_seen=False;self.absent_since=None
        if result_valid and self.waiting_used is not None and result_used>self.waiting_used:
            self.clear_pending()
        if panel:
            self.panel_seen=True;self.absent_since=None
            if not full:
                self.clear_pending();self.partial_seen=True;self.full_since=None
                return None
        elif self.panel_seen and self.absent_since is None:self.absent_since=now
        if not self.panel_seen:return None
        # A full-looking stripe is never sufficient: real logs show false full
        # detections several seconds before the server finishes an attempt.
        token=('end',result_used) if result_valid and result_used in (1,2) else None
        if (token is None or token in self.consumed) and (resume_allowed and not panel
            and self.absent_since is not None and now-self.absent_since>=2):
            token=('resume',*attempt)
        if token is not None and token not in self.consumed and self.pending is None:
            kind=token[0];used=result_used if kind=='end' else current_used
            if self.waiting_kind!=kind or self.waiting_used!=used:
                self.waiting_kind=kind;self.waiting_used=used;self.waiting_since=now
        if self.pending is not None:
            # Neither delivery nor selection acknowledges an interaction start.
            # A new attempt or a rendered partial panel clears this pending state.
            return None
        return token if token is not None and token not in self.consumed else None

    def consume(self,token,now=None):
        if token is None or token in self.consumed:return False
        self.reservations[token]=(self.attempt,self.waiting_kind,self.waiting_used,self.pending,self.pending_since)
        self.consumed.add(token)
        if now is not None:
            if token[0] in ('end','resume'):
                self.pending=token;self.pending_since=now
        return True

    def unsent(self,token):
        self.consumed.discard(token)
        saved=self.reservations.pop(token,None)
        if saved and saved[:3]==(self.attempt,self.waiting_kind,self.waiting_used):
            _,_,_,self.pending,self.pending_since=saved
