"""Verify Lua via observed Alt down AND up before any navigation.

This is a round-trip state check for Alt, not a general ACK for F/V.
It cannot arm a physical G9 receiver or choose a G HUB profile.
"""
from dataclasses import dataclass
import time


@dataclass
class ReceiverResult:
    ok:bool
    reason:str
    attempts:int=0


def check_receiver(bridge,stop,focused,log=lambda _:None):
    check=getattr(bridge,'alt_is_down',None)
    if not callable(check):return ReceiverResult(False,'Нет проверки фактического Alt')

    def observe(desired,seconds=.55):
        until=time.monotonic()+seconds
        while not stop.is_set() and focused():
            if bool(check())==desired:return True
            if time.monotonic()>=until:return False
            if stop.wait(.025):return False
        return False

    for attempt in (1,2):
        if stop.is_set() or not focused():return ReceiverResult(False,'Проверка Lua отменена: стоп или потеря фокуса',attempt-1)
        sync=getattr(bridge,'resync_receiver',None)
        if callable(sync) and not sync(stop,focused):return ReceiverResult(False,'Синхронизация Lua отменена: стоп или потеря фокуса',attempt-1)
        log(f'Проверка Lua {attempt}/2: сброс удержаний, наблюдаемый Alt вниз и вверх; без F/V/A')
        down=False;up=False
        try:
            if bridge.send('STOP') is False:return ReceiverResult(False,'Не отправлен сброс удержаний Lua',attempt)
            if not observe(False):return ReceiverResult(False,'Alt не отпускается. Отпусти физический Alt; проверь G9 и профиль Lua',attempt)
            if stop.is_set() or not focused():return ReceiverResult(False,'Проверка Lua отменена: стоп или потеря фокуса',attempt)
            guard=lambda:not stop.is_set() and focused()
            sender=getattr(bridge,'send_guarded',None)
            sent=sender('ALT_DOWN',guard) if callable(sender) else bridge.send('ALT_DOWN')
            down=sent is not False and observe(True)
        finally:
            # Release is allowed after focus loss/cancellation too. Never
            # leave a successful down half of the probe without cleanup.
            bridge.send('ALT_UP')
            up=observe(False)
        if down and up:return ReceiverResult(True,'Lua подтвердил Alt вниз и вверх',attempt)
        if down:
            bridge.send('STOP');observe(False)
            return ReceiverResult(False,'Lua зажал Alt, но отпускание не подтвердилось',attempt)
        if attempt==1:log('Ответа Alt нет: один повтор после очистки незаконченного кадра; игровые действия не повторяются')
    return ReceiverResult(False,'Lua не подтвердил Alt. Нужны активный профиль бота, выключенная встроенная память и физический G9',2)
