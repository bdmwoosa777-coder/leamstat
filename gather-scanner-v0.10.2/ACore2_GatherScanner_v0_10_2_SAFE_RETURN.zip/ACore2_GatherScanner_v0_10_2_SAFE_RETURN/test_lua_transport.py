"""Run the actual G HUB receiver against a virtual clock/lock-key wire.
Optional test dependency: pip install lupa. Never sends OS or game input.
"""
from pathlib import Path
import unittest
from bridge import COMMANDS,frame_codes
try:
    from lupa import LuaRuntime
except ImportError:LuaRuntime=None


class Wire:
    def __init__(self,commands):
        self.wheel=[];self.now=0;self.events=[];self.keys=[];self.held=set();self.states={};self.index=0
        start=100
        for name in commands:
            for code in frame_codes(name):
                self.events.extend([(start,{'capslock':bool(code&2),'numlock':bool(code&1),'scrolllock':False}),
                                    (start+24,{'scrolllock':True}),(start+84,{'scrolllock':False})])
                start+=120
            start+=180
        self.end=start+1200

    def lock(self,name):
        while self.index<len(self.events) and self.events[self.index][0]<=self.now:
            self.states.update(self.events[self.index][1]);self.index+=1
        return self.states.get(name,False)

    def sleep(self,ms):
        self.now+=ms
        if self.now>self.end:self.now+=1800100

    def press(self,key):self.keys.append((self.now,'down',key));self.held.add(key)
    def release(self,key):self.keys.append((self.now,'up',key));self.held.discard(key)


def run(commands):
    wire=Wire(commands);lua=LuaRuntime();g=lua.globals()
    g.IsKeyLockOn=wire.lock;g.GetRunningTime=lambda:wire.now;g.Sleep=wire.sleep
    g.PressKey=wire.press;g.ReleaseKey=wire.release;g.OutputLogMessage=lambda *args:None
    g.MoveMouseWheel=lambda value:wire.wheel.append((wire.now,value))
    g.MoveMouseRelative=lambda *args:None;g.PressMouseButton=lambda *args:None;g.ReleaseMouseButton=lambda *args:None
    lua.execute((Path(__file__).parent/'GHUB_GATHER_SCANNER.lua').read_text())
    g.OnEvent('MOUSE_BUTTON_PRESSED',9)
    return wire


@unittest.skipIf(LuaRuntime is None,'Optional lupa is not installed')
class LuaReceiverTests(unittest.TestCase):
    def test_end_air_disables_f_and_taps_v_in_one_received_command(self):
        wire=run(['F_ON','END_AIR'])
        self.assertEqual(sum(action=='down' and key=='v' for _,action,key in wire.keys),1)
        when=next(t for t,a,k in wire.keys if a=='down' and k=='v')
        self.assertFalse(any(t>when and a=='down' and k=='f' for t,a,k in wire.keys))
        self.assertFalse(wire.held)

    def test_attack_pair_is_two_bracket_presses_and_receiver_stays_live(self):
        wire=run(['TAB','ATTACK_PAIR','PING','STOP'])
        self.assertEqual(sum(a=='down' and k==0x1b for _,a,k in wire.keys),2)
        self.assertEqual(sum(a=='down' and k=='tab' for _,a,k in wire.keys),1)
        self.assertFalse(wire.held)

    def test_map_wheel_is_gated_and_never_presses_walk_keys(self):
        wire=run(['MAP_SCROLL_DOWN','MAP','MAP_SCROLL_DOWN','MAP_SCROLL_UP','STOP','MAP_SCROLL_DOWN'])
        self.assertEqual([v for _,v in wire.wheel],[-3,3])
        self.assertFalse(any(key in ('w','a','d') for _,_,key in wire.keys))
    def test_ui_can_be_armed_for_a_map_that_was_already_open(self):
        wire=run(['MAP_UI_ARM','MAP_SCROLL_DOWN'])
        self.assertEqual([v for _,v in wire.wheel],[-3])
        self.assertFalse(wire.held)

    def test_map_is_accepted_only_with_f_disabled(self):
        wire=run(['F_ON','MAP','F_OFF','MAP'])
        self.assertEqual(sum(a=='down' and k=='m' for _,a,k in wire.keys),1)
        self.assertFalse(wire.held)


if __name__=='__main__':unittest.main()
