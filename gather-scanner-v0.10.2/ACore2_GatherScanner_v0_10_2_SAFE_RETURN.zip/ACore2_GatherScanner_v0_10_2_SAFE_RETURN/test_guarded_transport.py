"""Cancel a delayed V/recovery-F before its final checksum reaches Lua."""
import threading,unittest
from unittest.mock import patch
from bridge import GHubBridge,frame_codes
from test_lua_transport import LuaRuntime,Wire
from pathlib import Path

class GuardedTransportTests(unittest.TestCase):
    def setUp(self):
        self.clock=0.;self.states={};self.codes=[];self.log=[]
        self.b=GHubBridge.__new__(GHubBridge);self.b.lock=threading.RLock()
        self.b.dry_run=False;self.b.log=self.log.append;self.b.sent=[]
        def toggle(key,value):
            self.states[key]=value
            if key==145 and value:self.codes.append((2 if self.states.get(20) else 0)+(1 if self.states.get(144) else 0))
        self.b._toggle=toggle
    def sleep(self,seconds):self.clock+=seconds
    def send(self,command,authorize):
        with patch('bridge.time.sleep',side_effect=self.sleep),patch('bridge.time.monotonic',side_effect=lambda:self.clock):
            return self.b.send_guarded(command,authorize)
    def test_rejected_initial_check_sends_nothing(self):
        self.assertFalse(self.send('V',lambda:False));self.assertEqual(self.codes,[])
    def test_panel_arriving_before_final_strobe_invalidates_frame(self):
        approvals=iter([True,True,False])
        self.assertFalse(self.send('V',lambda:next(approvals)))
        expected=frame_codes('V');self.assertEqual(self.codes[:3],expected[:3])
        self.assertNotEqual(self.codes[3],expected[3]);self.assertNotEqual(self.codes[3],3)
    def test_genuine_permission_sends_original_frame(self):
        self.assertTrue(self.send('TAP_F',lambda:True));self.assertEqual(self.codes,frame_codes('TAP_F'))
    def test_slow_last_authorization_cancels_instead_of_desynchronizing_receiver(self):
        calls=[0]
        def slow():
            calls[0]+=1
            if calls[0]==2:self.clock+=1
            return True
        self.assertFalse(self.send('V',slow));self.assertNotEqual(self.codes[-1],3)
        self.assertNotEqual(self.codes[-1],frame_codes('V')[-1])
    def test_capture_error_cancels_frame(self):
        calls=[0]
        def fail():
            calls[0]+=1
            if calls[0]>1:raise RuntimeError('capture lost')
            return True
        self.assertFalse(self.send('TAP_F',fail));self.assertNotEqual(self.codes[-1],frame_codes('TAP_F')[-1])
    def test_unguarded_release_commands_are_not_rejected_by_timing_guard(self):
        with patch('bridge.time.sleep',side_effect=self.sleep),patch('bridge.time.monotonic',side_effect=lambda:self.clock):
            self.assertTrue(self.b.send('STOP'))
        self.assertEqual(self.codes,frame_codes('STOP'))

@unittest.skipIf(LuaRuntime is None,'Optional lupa is not installed')
class CancelledFrameLuaTests(unittest.TestCase):
    def test_bad_final_checksum_never_runs_v_and_next_frame_still_works(self):
        bad=frame_codes('V');bad[-1]=next(v for v in range(3) if v!=bad[-1])
        wire=Wire([]);wire.events=[];wire.index=0;start=100
        for frame in (bad,frame_codes('MAP')):
            for code in frame:
                wire.events.extend([(start,{'capslock':bool(code&2),'numlock':bool(code&1),'scrolllock':False}),
                                    (start+24,{'scrolllock':True}),(start+84,{'scrolllock':False})]);start+=120
            start+=180
        wire.end=start+1200
        lua=LuaRuntime();g=lua.globals()
        g.IsKeyLockOn=wire.lock;g.GetRunningTime=lambda:wire.now;g.Sleep=wire.sleep
        g.PressKey=wire.press;g.ReleaseKey=wire.release;g.OutputLogMessage=lambda *args:None
        lua.execute((Path(__file__).parent/'GHUB_GATHER_SCANNER.lua').read_text())
        g.OnEvent('MOUSE_BUTTON_PRESSED',9)
        self.assertFalse(any(a=='down' and k=='v' for _,a,k in wire.keys))
        self.assertEqual(sum(a=='down' and k=='m' for _,a,k in wire.keys),1)

if __name__=='__main__':unittest.main()
