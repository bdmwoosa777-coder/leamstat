"""One path F, then wait for the first actual lower success/failure panel.
The latch survives pauses BETWEEN attempts and is revoked for the next target.
"""
from pathlib import Path
import unittest
from unittest.mock import patch
import cv2
from flight import FlightReading
from test_navigation import GatherFixture,obs
from test_exploration import radar
from vision import gathering_panel_pair
import gather_engine as ge

ROOT=Path(__file__).resolve().parent
AIR=FlightReading(50,True)
GROUND=FlightReading(None,False)

class FirstPanelFTests(GatherFixture,unittest.TestCase):
    def selected(self,name='Эфир'):
        self.e.target=name;self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode='APPROACH';self.e.started=99;self.e.last_progress=100
        self.e._reset_resource_watch(verified_header=True)

    def test_air_arrival_and_many_stall_checks_send_exactly_one_f_before_panel(self):
        self.selected();self.assertTrue(self.e._start_resource_route())
        for now,dist in ((100,40),(105,20),(110,6),(115,1),(120,1)):
            self.step(obs('Эфир',distance=dist),now,plate=3,reading=AIR)
            self.e._recover(self.frame,(0,0),obs('Эфир',distance=dist),AIR,now)
        self.assertEqual(self.commands,['TAP_F']);self.assertFalse(self.e.real_gather_panel_seen)
        self.assertFalse(self.e.f_on);self.assertTrue(self.e.route_f_sent)

    def test_unreadable_flight_arc_does_not_authorize_another_f(self):
        self.selected();self.e._start_resource_route()
        for now in (106,112,118):
            self.e._recover(self.frame,(0,0),obs('Эфир',distance=7),GROUND,now)
        self.assertEqual(self.commands.count('TAP_F'),1);self.assertNotIn('F_ON',self.commands)

    def test_route_active_flag_loss_cannot_reset_consumed_initial_f(self):
        self.selected();self.assertTrue(self.e._start_resource_route())
        self.e.route_active=False
        self.assertFalse(self.e._start_resource_route())
        self.assertFalse(self.e.bridge_cmd('TAP_F'))
        self.assertEqual(self.commands,['TAP_F'])

    def test_near_distance_upper_slots_f_prompt_and_slot_loss_are_not_first_panel(self):
        self.selected();self.e._start_resource_route()
        for now,slots in ((100,3),(101,2),(102,1)):
            self.step(obs('Эфир',distance=1,prompt=True),now,plate=slots)
            self.e.f_enable()
        self.assertEqual(self.commands,['TAP_F']);self.assertFalse(self.e.f_on)
        self.assertFalse(self.e.real_gather_panel_seen)

    def test_legacy_single_label_false_positive_cannot_enable_repeat(self):
        self.selected();self.e._start_resource_route()
        with patch.object(ge,'gathering_panel',return_value=True),patch.object(ge,'gathering_panel_pair',return_value=False),patch.object(ge,'segment_count',return_value=3):
            self.e.panel_cleared=True
            self.e._resource_fast_tick(self.frame,AIR,101,panel=True,slots=3)
            self.e.f_enable()
        self.assertEqual(self.commands,['TAP_F']);self.assertFalse(self.e.real_gather_panel_seen)
        self.assertFalse(self.e.f_repeat_allowed);self.assertFalse(self.e.f_on)

    def test_even_direct_f_on_is_rejected_until_the_real_first_panel(self):
        self.selected();self.e.f_repeat_allowed=True;self.e.fast_gather_seen=True;self.e.mode='GATHER'
        self.assertFalse(self.e.bridge_cmd('F_ON'))
        self.assertFalse(self.e.f_enable());self.assertEqual(self.commands,[])

    def test_real_lower_panel_latches_repeat_between_attempts_until_target_disappears(self):
        self.selected();self.e._start_resource_route()
        self.step(obs('Эфир',distance=1),100,plate=3,panel=True,reading=AIR)
        self.assertTrue(self.e.real_gather_panel_seen);self.assertTrue(self.e.f_on)
        for now,slots in ((102,2),(104,2),(106,1)):
            self.step(obs('Эфир',distance=1),now,plate=slots,panel=False,reading=AIR)
        self.assertEqual(self.commands,['TAP_F','F_ON']);self.assertTrue(self.e.f_on)
        self.step(obs(),107,panel=False,reading=AIR)
        self.step(obs(),108,panel=False,reading=AIR)
        self.assertEqual(self.commands.count('END_AIR'),1)
        self.assertFalse(self.e.f_on);self.assertFalse(self.e.real_gather_panel_seen)

    def test_new_selection_resets_previous_resource_permission(self):
        self.selected();self.step(obs('Эфир',distance=1),100,plate=3,panel=True)
        self.assertTrue(self.e.real_gather_panel_seen)
        self.e.f_disable();self.e._reset_resource_watch(verified_header=True)
        self.e.target='Сапфир';self.e.mode='APPROACH';self.e.collecting_visible=False
        self.assertTrue(self.e._start_resource_route());self.e.f_enable()
        self.assertEqual(self.commands.count('F_ON'),1);self.assertEqual(self.commands.count('TAP_F'),1)
        self.assertFalse(self.e.real_gather_panel_seen)

    def test_defense_reacquisition_revokes_repeat_before_changing_target(self):
        self.selected();self.step(obs('Эфир',distance=1),100,plate=3,panel=True)
        self.e._begin_reacquire('defense')
        self.assertFalse(self.e.real_gather_panel_seen);self.assertFalse(self.e.f_on)
        self.assertFalse(self.e.bridge_cmd('F_ON'))

    def test_ground_obstacle_own_v_then_confirmed_arc_allows_one_extra_f(self):
        self.selected('Сапфир');self.e._start_resource_route()
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=5),GROUND,107)
        self.assertEqual(self.e.mode,'TAKEOFF')
        with patch.object(ge,'read_flight',return_value=AIR):
            self.step(obs('Сапфир',distance=5),108,plate=3,reading=AIR)
        self.assertEqual(self.commands,['TAP_F','V','TAP_F']);self.assertTrue(self.e.route_active)
        self.assertEqual(self.e.mode,'APPROACH')

    def test_real_fixture_panel_enables_repeat_at_user_screen_width(self):
        self.selected();self.e._start_resource_route()
        image=cv2.imread(str(ROOT/'testdata/air_gather_example.jpg'))
        self.frame=cv2.resize(image,(2048,round(image.shape[0]*2048/image.shape[1])))
        self.e.screen.frame=lambda:(self.frame,(0,0))
        self.assertTrue(self.e.f_enable())
        self.assertEqual(self.commands,['TAP_F','F_ON']);self.assertTrue(self.e.real_gather_panel_seen)

    def test_one_observed_real_panel_is_remembered_when_next_frame_is_between_attempts(self):
        self.selected();self.e._start_resource_route()
        image=cv2.imread(str(ROOT/'testdata/air_gather_example.jpg'))
        # The live tick saw the panel; a later capture already has no panel.
        # Do not lose the first observation by demanding a second identical frame.
        self.e._resource_fast_tick(image,AIR,101,panel=True,slots=2)
        self.assertTrue(self.e.real_gather_panel_seen);self.assertTrue(self.e.f_on)
        self.assertEqual(self.commands,['TAP_F','F_ON'])

    def test_unverified_panel_cannot_trigger_gather_camera_correction_either(self):
        self.selected();self.e.mode='GATHER';self.e.camera_scheduler_active=True
        self.e.camera_search_revision=1
        with patch.object(ge,'segment_count',return_value=3),patch.object(ge,'gathering_panel',return_value=True),patch.object(ge,'gathering_panel_pair',return_value=False),patch.object(self.e,'_calibrate_camera') as calibrate:
            self.e.step(self.frame,(0,0),obs('Эфир',distance=1),radar(),AIR,101)
        calibrate.assert_not_called();self.assertFalse(self.e.real_gather_panel_seen)

    def test_native_automatic_flight_is_not_permission_for_a_second_path_f(self):
        self.selected();self.e._start_resource_route()
        with patch.object(ge,'read_flight',return_value=AIR):
            self.assertFalse(self.e._start_resource_route(restart_after_wings=True))
        self.assertEqual(self.commands,['TAP_F'])

    def test_consumed_wing_restart_token_cannot_be_used_again(self):
        self.selected('Сапфир');self.e._start_resource_route()
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=5),GROUND,107)
        with patch.object(ge,'read_flight',return_value=AIR):
            self.step(obs('Сапфир',distance=5),108,plate=3,reading=AIR)
            self.e.route_active=False;self.e.mode='TAKEOFF'
            self.assertFalse(self.e._start_resource_route(restart_after_wings=True))
        self.assertEqual(self.commands,['TAP_F','V','TAP_F'])

    def test_stale_arc_observation_without_fresh_arc_cannot_restart_path_f(self):
        self.selected('Сапфир');self.e._start_resource_route()
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=5),GROUND,107)
        with patch.object(ge,'read_flight',return_value=GROUND):
            self.step(obs('Сапфир',distance=5),108,plate=3,reading=AIR)
        self.assertEqual(self.commands,['TAP_F','V']);self.assertEqual(self.e.mode,'TAKEOFF')

    def test_first_panel_arrives_after_v_before_replacement_f(self):
        self.selected('Сапфир');self.e._start_resource_route()
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=5),GROUND,107)
        self.step(obs('Сапфир',distance=1),108,plate=3,panel=True,reading=AIR)
        self.assertEqual(self.commands,['TAP_F','V','F_ON'])
        self.assertFalse(self.e.wing_route_restart_pending)

    def test_cancelled_v_packet_does_not_grant_a_replacement_f(self):
        self.selected('Сапфир');self.e._start_resource_route()
        self.e.bridge.send_guarded=lambda command,authorize:False
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=5),GROUND,107)
        self.assertFalse(self.e.wing_route_restart_pending);self.assertFalse(self.e.flight_attempted)
        self.assertEqual(self.commands,['TAP_F'])

    def test_native_flight_appearing_during_v_request_does_not_get_toggled_closed(self):
        self.selected();self.e._start_resource_route()
        with patch.object(ge,'read_flight',return_value=AIR):
            self.e._recover(self.frame,(0,0),obs('Эфир',distance=5),GROUND,107)
        self.assertEqual(self.commands,['TAP_F']);self.assertFalse(self.e.wing_route_restart_pending)

    def test_failed_new_acquisition_cannot_reuse_old_resource_gather_permission(self):
        self.selected();self.step(obs('Эфир',distance=1),100,plate=3,panel=True)
        self.assertTrue(self.e.real_gather_panel_seen)
        self.e._acquire_miss(self.c,101)
        self.e.target='Сапфир';self.e.target_confirmed=True
        self.assertFalse(self.e.f_enable());self.assertFalse(self.e.real_gather_panel_seen)
        self.assertEqual(self.commands.count('F_ON'),1);self.assertIn('F_OFF',self.commands)

    def test_final_v_check_is_revoked_by_actual_collection_or_native_flight(self):
        self.selected()
        with patch.object(ge,'gathering_panel',return_value=False),patch.object(ge,'gathering_panel_pair',return_value=False),patch.object(ge,'read_flight',return_value=GROUND):
            self.assertTrue(self.e._wing_send_still_allowed())
            with patch.object(ge,'gathering_panel_pair',return_value=True):
                self.assertFalse(self.e._wing_send_still_allowed())
            with patch.object(ge,'read_flight',return_value=AIR):
                self.assertFalse(self.e._wing_send_still_allowed())
            self.e.real_gather_panel_seen=True
            self.assertFalse(self.e._wing_send_still_allowed())

class PairedPanelVisionTests(unittest.TestCase):
    def test_real_panel_is_recognized_across_resolutions(self):
        image=cv2.imread(str(ROOT/'testdata/air_gather_example.jpg'))
        for width in (1280,1600,1920,2048,2480,2558):
            with self.subTest(width=width):
                frame=cv2.resize(image,(width,round(image.shape[0]*width/image.shape[1])))
                self.assertTrue(gathering_panel_pair(frame))
                # Before flight arrival the world/header can be identical;
                # remove only the lower panel and forbid authorizing repeats.
                h,w=frame.shape[:2];frame[round(h*.69):round(h*.856),round(w*.28):round(w*.80)]=70
                self.assertFalse(gathering_panel_pair(frame))

if __name__=='__main__':unittest.main()
