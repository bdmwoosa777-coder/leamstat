"""Read only selected gameplay control states while own collection is active."""
import os

GAME_KEYS={0x57:'W',0x41:'A',0x53:'S',0x44:'D',0x46:'F',0x56:'V',0x10:'SHIFT',
           0x20:'SPACE',0x09:'TAB',0x12:'ALT',0x25:'LEFT',0x26:'UP',0x27:'RIGHT',0x28:'DOWN'}

class GameplayInputAudit:
    def __init__(self,read_key=None):
        if read_key is None and os.name=='nt':
            import ctypes
            from ctypes import wintypes
            api=ctypes.windll.user32.GetAsyncKeyState
            api.argtypes=[ctypes.c_int];api.restype=ctypes.c_short
            read_key=lambda key:bool(api(key)&0x8000)
        self.read_key=read_key;self.previous={}

    def sample(self):
        if self.read_key is None:return []
        changed=[]
        for key,name in GAME_KEYS.items():
            down=bool(self.read_key(key))
            if down!=self.previous.get(key,False):changed.append((name,down))
            self.previous[key]=down
        return changed

    def reset(self):self.previous.clear()
