# Network attribution

The bundled module is **ACore2 integrated passive network**, built from
`native_network_src`. Npcap access, Windows process/TCP discovery, adapter
selection, pipe transport and bot integration belong to this project.

Its wire decoder is vendored from [nuriland/a2kit](https://github.com/nuriland/a2kit),
MIT, copyright (c) 2026 nuri, commit
`b1ffe3d6a1248bc26d906983f96896f99d740195`. The MIT notice is preserved in
`A2KIT_LICENSE.txt` and `native_network_src/LICENSE`. Packet peeling and the
Python Hit layout are adapted from the same MIT project. Local modifications
are documented in `native_network_src/UPSTREAM.md`.

LZ4 is `github.com/pierrec/lz4/v4 v4.1.30`; its BSD notice is included in
`native_network/LZ4_LICENSE.txt`. Go runtime's notice is GO_LICENSE.txt.
The Windows binary is built with CGO disabled; no .NET/Go runtime install is
required. Npcap itself is not bundled or installed by the bot.

`gather_catalogue.json` is the display-only catalogue from
[Carchutin19/Aion-2-Helper](https://github.com/Carchutin19/Aion-2-Helper/tree/main/assets/gathering),
whose attribution identifies the MIT data source
[SkeeveAN/Aion-DPS-Meter](https://github.com/SkeeveAN/Aion-DPS-Meter).
The source notice is retained in GATHER_METADATA_LICENSE.txt. Game names remain
content of their respective rights holders.

The static coordinate atlas in assets/atlas is copied from the MIT
SkeeveAN/Aion-DPS-Meter commit 602d317929dd199f789a11ab79df20596343fab7.
Its MIT license and exact source paths are retained in that directory.

Resource/player fields were cross-checked with private Global captures,
CubeRadar's published object documentation and Helper's public protocol
observations. CubeRadar, Helper and Wingbeat application classes/binaries are
not included. CubeRadar is no longer a runtime dependency.

The internal module reads packets and writes to a local pipe. It does not
send game packets. Gameplay input remains G HUB / virtual Xbox.
No user capture, raw traffic, private decoded packet, user log, player ID,
position, IP, account key or local user settings path is embedded in this release.
