# -*- coding: utf-8 -*-
"""AION 2 — independent low-frequency visual death-window observer.

Recognizes only fixed Russian UI fragments from the supplied real screenshot.
No OCR of names, no character memory access, and no automated resurrection.
"""
from pathlib import Path
import cv2
import numpy as np
from captcha_watchdog import AudioAlarm


class DeathDialogDetector:
    """Require two independent fixed labels in the same central death panel.

    The killer, resurrection cooldown, and the unavailable upper resurrection
    button are deliberately excluded from visual checks. This also works for
    deaths to monsters or players (upper resurrection may be gray).
    """
    SCALES = (.85, .90, .95, 1.0, 1.05, 1.10, 1.15, 1.20)

    def __init__(self, template_dir=None):
        home=Path(template_dir) if template_dir else Path(__file__).resolve().parent
        self.header=cv2.imread(str(home/'death_header_reference.png'),cv2.IMREAD_GRAYSCALE)
        self.revive=cv2.imread(str(home/'death_resurrection_reference.png'),cv2.IMREAD_GRAYSCALE)
        if self.header is None or self.revive is None:
            raise FileNotFoundError('Отсутствуют шаблоны death_header_reference.png / death_resurrection_reference.png')
        # Templates recorded from a true 2048x1151 screenshot; normalize to 1280 width.
        self.header=cv2.resize(self.header,(round(self.header.shape[1]*.625),round(self.header.shape[0]*.625)),interpolation=cv2.INTER_AREA)
        self.revive=cv2.resize(self.revive,(round(self.revive.shape[1]*.625),round(self.revive.shape[0]*.625)),interpolation=cv2.INTER_AREA)
        self.last_debug={}

    def _find(self,gray,template,region):
        h,w=gray.shape
        x1,y1,x2,y2=region
        ax=int(x1*w); bx=int(x2*w); ay=int(y1*h); by=int(y2*h)
        area=gray[ay:by,ax:bx]
        best_score=-1.0; best_pos=None; best_scale=None
        for scale in self.SCALES:
            t=cv2.resize(template,None,fx=scale,fy=scale,interpolation=cv2.INTER_LINEAR)
            if t.shape[0]>area.shape[0] or t.shape[1]>area.shape[1]:
                continue
            _,score,_,loc=cv2.minMaxLoc(cv2.matchTemplate(area,t,cv2.TM_CCOEFF_NORMED))
            if score>best_score:
                best_score=float(score); best_pos=(ax+loc[0],ay+loc[1]); best_scale=scale
        return best_score,best_pos,best_scale

    def check(self,bgr):
        if bgr is None or bgr.size==0:
            return False,0.0
        h,w=bgr.shape[:2]
        if w<500 or h<300:
            return False,0.0
        if w!=1280:
            bgr=cv2.resize(bgr,(1280,round(h*1280/w)),interpolation=cv2.INTER_AREA)
        gray=cv2.cvtColor(bgr,cv2.COLOR_BGR2GRAY)
        a,pa,sa=self._find(gray,self.header,(.36,.30,.62,.39))
        if a<.80 or pa is None:
            self.last_debug={'title':round(a,3),'button':None,'detected':False}
            return False,max(0.0,a)
        b,pb,sb=self._find(gray,self.revive,(.32,.45,.63,.58))
        # Relative geometry from user's actual 1280-wide capture:
        # lower fixed label starts 54px left and 116px beneath heading.
        same_panel=(pb is not None and abs((pb[0]-pa[0])+54*sa)<30 and
                    abs((pb[1]-pa[1])-116*sa)<30 and abs(sb-sa)<=.21)
        good=(b>=.78 and same_panel)
        score=.5*a+.5*max(0.0,b)
        self.last_debug={'title':round(a,3),'button':round(b,3),
                         'geometry':same_panel,'detected':good,'score':round(score,3)}
        return good,float(score)


class DeathAudioAlarm(AudioAlarm):
    """Use CAPTCHA's precise output routing, but a clearly different tone."""
    @staticmethod
    def tone(sr):
        # Descending low alarm (CAPTCHA uses three high 880/1100/880 beeps).
        chunks=[]
        for freq in (620,430,310):
            n=int(sr*.36)
            t=np.arange(n,dtype=np.float32)/sr
            envelope=np.minimum(1.,t/.025)*np.minimum(1.,(n/sr-t)/.035)
            signal=(.34*np.sin(2*np.pi*freq*t)*envelope).astype('float32')
            chunks.extend((signal,np.zeros(int(sr*.10),dtype='float32')))
        return np.concatenate(chunks)
