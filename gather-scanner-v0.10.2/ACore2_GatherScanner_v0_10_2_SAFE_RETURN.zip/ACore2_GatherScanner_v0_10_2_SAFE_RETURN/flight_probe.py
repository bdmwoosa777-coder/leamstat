"""A single bounded lift to look over terrain, using only visible flight state."""
from dataclasses import dataclass
from navigation import Drive
from minimap import angle_delta
from camera_control import pitch_pulse


@dataclass
class ProbeAction:
    drive:Drive|None=None
    command:str|None=None
    done:bool=False
    stop:bool=False
    failed_takeoff:bool=False
    reason:str=''


class FlightProbe:
    def __init__(self,goal,now,cfg):
        self.goal=goal;self.cfg=cfg;self.phase='ALIGN';self.since=now
        self.opened=False;self.peek_ready_at=None;self.failure='подпись ресурса после подъёма не найдена'

    def phase_to(self,phase,now):self.phase=phase;self.since=now

    def step(self,now,reading,pitch_offset,heading,desired):
        elapsed=now-self.since
        if self.phase=='ALIGN':
            if heading is None or abs(angle_delta(desired,heading))<20 or elapsed>1.2:
                self.phase_to('TILT',now)
                return ProbeAction(reason='готовлю короткий подъём')
            return ProbeAction(drive=Drive(yaw=max(-.45,min(.45,angle_delta(desired,heading)/100))*self.cfg.get('camera_yaw_sign',1),lifetime=.065),reason='разворачиваюсь к ресурсу перед подъёмом')
        if self.phase=='TILT':
            # Cap old settings too: avoid pitching all the way to the limit,
            # where inverse input cannot recover the lost excess command.
            # Looking down + backwards movement gives ascent AND clearance
            # from the wall in front, instead of flying further into it.
            target=-max(.12,min(.24,abs(self.cfg.get('probe_retreat_pitch_offset',.20))))
            error=target-pitch_offset
            if abs(error)<.009:
                if reading.confirmed:self.phase_to('WAIT_ARC',now);return ProbeAction()
                self.phase_to('WAIT_ARC',now)
                return ProbeAction(command='V',reason='одна попытка раскрыть крылья')
            if elapsed>6:
                self.failure='наклон для подъёма не подготовлен';self.phase_to('CLOSE',now);return ProbeAction()
            pitch,lease=pitch_pulse(error,.18)
            return ProbeAction(drive=Drive(pitch=pitch,lifetime=lease),reason='подъём: короткие импульсы наклона')
        if self.phase=='WAIT_ARC':
            if reading.confirmed:
                self.opened=True
                if reading.energy is None or reading.energy<self.cfg.get('flight_probe_min_percent',18):
                    self.failure='для пробного подъёма недостаточно подтверждённого запаса энергии'
                    self.phase_to('CLOSE',now);return ProbeAction()
                self.phase_to('RISE',now)
            elif elapsed>3.5:
                self.failure='крылья не подтверждены: повтор V запрещён'
                self.phase_to('CLOSE',now)
                return ProbeAction(failed_takeoff=True)
            else:return ProbeAction()
        if self.phase=='RISE':
            if not reading.confirmed:
                self.failure='дуга полёта пропала во время подъёма';self.phase_to('CLOSE',now);return ProbeAction()
            if reading.energy is not None and reading.energy<self.cfg.get('flight_low_percent',8):
                self.failure='энергия на исходе, прекращаю пробный подъём';self.phase_to('CLOSE',now);return ProbeAction()
            if now-self.since>=max(.5,min(2.,self.cfg.get('probe_retreat_rise_seconds',1.5))):
                self.phase_to('PEEK',now);return ProbeAction()
            return ProbeAction(drive=Drive(forward=-.60,lifetime=.4,tilted_motion=True),reason='короткий подъём назад от препятствия; камера направлена вниз')
        if self.phase=='PEEK':
            if elapsed>6:self.phase_to('CLOSE',now);return ProbeAction()
            yaw=0 if heading is None else max(-.3,min(.3,angle_delta(desired,heading)/100))*self.cfg.get('camera_yaw_sign',1)
            peek_target=-.045 if self.goal.kind=='gem' else .07
            error=peek_target-pitch_offset
            if abs(error)<.009:
                if self.peek_ready_at is None:self.peek_ready_at=now
                if now-self.peek_ready_at>=max(1.8,self.cfg.get('probe_peek_seconds',.8)):
                    self.phase_to('CLOSE',now);return ProbeAction()
                return ProbeAction(reason='ракурс после подъёма готов: даю распознаванию увидеть ресурс')
            pitch,lease=pitch_pulse(error,.18)
            return ProbeAction(drive=Drive(yaw=yaw,pitch=pitch,lifetime=lease),reason='остановился: возвращаю взгляд к ресурсу после подъёма назад')
        if self.phase=='CLOSE':
            if reading.confirmed:
                self.phase_to('WAIT_CLOSE',now)
                return ProbeAction(command='END_AIR',reason='подпись не найдена: закрываю подтверждённые крылья')
            return ProbeAction(done=True,reason=self.failure)
        if self.phase=='WAIT_CLOSE':
            if not reading.confirmed:return ProbeAction(done=True,reason=self.failure)
            if elapsed>2.5:return ProbeAction(stop=True,reason='закрытие крыльев не подтверждено; повтор V не отправляю')
            return ProbeAction()
        return ProbeAction(stop=True,reason='неизвестное состояние подъёма')
