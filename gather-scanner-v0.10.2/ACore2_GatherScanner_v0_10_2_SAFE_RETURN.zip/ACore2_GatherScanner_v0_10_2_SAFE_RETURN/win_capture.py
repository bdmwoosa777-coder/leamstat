"""Read-only foreground-window capture and DXGI adapter enumeration."""
from dataclasses import dataclass
import os,time
import numpy as np


@dataclass
class Window:
    hwnd:int
    title:str


class PausedCapture(Exception):pass


def _user32():
    if os.name!='nt':raise RuntimeError('Живой захват доступен в Windows. Здесь можно открыть изображение или видео.')
    import ctypes
    from ctypes import wintypes as wt
    u=ctypes.WinDLL('user32',use_last_error=True)
    u.GetForegroundWindow.restype=wt.HWND
    u.IsWindowVisible.argtypes=[wt.HWND];u.IsIconic.argtypes=[wt.HWND]
    u.GetWindowTextW.argtypes=[wt.HWND,wt.LPWSTR,ctypes.c_int]
    u.GetClientRect.argtypes=[wt.HWND,ctypes.POINTER(wt.RECT)]
    u.ClientToScreen.argtypes=[wt.HWND,ctypes.POINTER(wt.POINT)]
    return u


def windows():
    if os.name!='nt':return []
    import ctypes
    from ctypes import wintypes as wt
    user=_user32();found=[]
    callback=ctypes.WINFUNCTYPE(wt.BOOL,wt.HWND,wt.LPARAM)
    def inspect(hwnd,lparam):
        title=ctypes.create_unicode_buffer(1024);user.GetWindowTextW(hwnd,title,len(title))
        if user.IsWindowVisible(hwnd) and 'aion2' in title.value.casefold().replace(' ',''):
            rect=wt.RECT()
            if user.GetClientRect(hwnd,ctypes.byref(rect)) and rect.right>=640 and rect.bottom>=360:
                found.append(Window(int(hwnd),title.value))
        return True
    cb=callback(inspect);user.EnumWindows.argtypes=[callback,wt.LPARAM];user.EnumWindows(cb,0)
    return found


class WindowCapture:
    def __init__(self,window):
        import mss
        self.window=window;self.user=_user32();self.mss=mss.mss()
    def grab(self):
        import ctypes
        from ctypes import wintypes as wt
        hwnd=self.window.hwnd
        if self.user.GetForegroundWindow()!=hwnd or self.user.IsIconic(hwnd):
            raise PausedCapture('Пауза: переключитесь в выбранное окно AION2')
        rect=wt.RECT();point=wt.POINT(0,0)
        if not self.user.GetClientRect(hwnd,ctypes.byref(rect)) or not self.user.ClientToScreen(hwnd,ctypes.byref(point)):
            raise PausedCapture('Окно игры закрыто или недоступно')
        width,height=rect.right-rect.left,rect.bottom-rect.top
        if width<320 or height<200:raise PausedCapture('Окно игры свёрнуто или слишком мало')
        image=np.asarray(self.mss.grab(dict(left=point.x,top=point.y,width=width,height=height)))[:,:,:3].copy()
        # Recheck after capture; a focus switch must not save the newly exposed desktop.
        if self.user.GetForegroundWindow()!=hwnd:raise PausedCapture('Пауза: фокус сменился во время захвата')
        if float(image.mean())<8 and float(image.std())<2:
            raise PausedCapture('Чёрный кадр: попробуйте оконный режим без рамки; анализ приостановлен')
        return image
    def close(self):self.mss.close()


def pressed(vk):
    if os.name!='nt':return False
    # Read the actual key state; never synthesize or suppress a key.
    return bool(_user32().GetAsyncKeyState(vk)&0x8000)


def shortcut_edges(previous,active=True):
    # Plain F6/F7 are game quick slots. Never treat them as our commands.
    modifiers=pressed(0x11) and pressed(0x12)
    actions=[]
    for vk in (0x75,0x76,0x79):
        down=pressed(vk)
        if active and modifiers and down and not previous.get(vk,False):actions.append(vk)
        previous[vk]=down
    return actions


def adapters():
    """DXGI order is also the DirectML device_id order; avoid WMI reordering."""
    if os.name!='nt':return []
    import ctypes as c
    class GUID(c.Structure):_fields_=[('a',c.c_uint32),('b',c.c_uint16),('d',c.c_uint16),('e',c.c_ubyte*8)]
    class LUID(c.Structure):_fields_=[('low',c.c_uint32),('high',c.c_int32)]
    class DESC(c.Structure):
        _fields_=[('name',c.c_wchar*128),('vendor',c.c_uint32),('device',c.c_uint32),('subsystem',c.c_uint32),
                  ('revision',c.c_uint32),('vram',c.c_size_t),('system',c.c_size_t),('shared',c.c_size_t),('luid',LUID),('flags',c.c_uint32)]
    def method(ptr,index,result,*args):
        table=c.cast(ptr,c.POINTER(c.POINTER(c.c_void_p))).contents
        return c.WINFUNCTYPE(result,c.c_void_p,*args)(table[index])
    factory=c.c_void_p();iid=GUID(0x770aae78,0xf26f,0x4dba,(c.c_ubyte*8)(0xa8,0x29,0x25,0x3c,0x83,0xd1,0xb3,0x87))
    dxgi=c.WinDLL('dxgi');create=dxgi.CreateDXGIFactory1
    create.argtypes=[c.POINTER(GUID),c.POINTER(c.c_void_p)];create.restype=c.c_int32
    if create(c.byref(iid),c.byref(factory))<0:return []
    result=[]
    try:
        for index in range(16):
            adapter=c.c_void_p()
            if method(factory,12,c.c_int32,c.c_uint32,c.POINTER(c.c_void_p))(factory,index,c.byref(adapter))<0:break
            try:
                desc=DESC()
                if method(adapter,10,c.c_int32,c.POINTER(DESC))(adapter,c.byref(desc))>=0 and not desc.flags&2:
                    result.append(dict(id=index,name=desc.name,vram_gb=round(desc.vram/1024**3,1),vendor=desc.vendor))
            finally:method(adapter,2,c.c_uint32)(adapter)
    finally:method(factory,2,c.c_uint32)(factory)
    return result
