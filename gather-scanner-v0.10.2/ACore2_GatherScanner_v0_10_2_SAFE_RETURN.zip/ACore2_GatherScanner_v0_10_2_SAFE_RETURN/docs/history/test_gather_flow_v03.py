"""Offline integration: target selection, interruptible A, depletion, minimap navigation."""
import tempfile
import threading
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import cv2
import numpy as np
from app import DEFAULT, GatherEngine
from gamepad_input import GamepadInput
from minimap import MinimapVision, Marker
from vision import Candidate, Observation

ROOT=Path(__file__).resolve().parent


class Pad:
    def __init__(self):self.reports=[];self.buttons=0;self.presses=0;self.fail=False
    def press_button(self,button):self.buttons=button;self.presses+=1
    def reset(self):self.buttons=0
    def update(self):
        self.reports.append(self.buttons)
        if self.fail and self.buttons:raise RuntimeError('report partially delivered')


def observation(name=None,prompt=False,gathering=False,candidate=None,distance=None):
    return Observation(candidate,name,distance,prompt,1.0 if prompt else 0.0,gathering,None,'HIDDEN')


class GatherFlowTests(unittest.TestCase):
    def setUp(self):
        self.logs=[];self.commands=[];self.positions=[];self.focus=True
        self.pad=Pad()
        self.input=GamepadInput(factory=lambda:self.pad,a_button=0x1000)
        cfg={**DEFAULT,'debug_screenshots':False,'camera_scan':False,'minimap_search':False,'ground_walk':False}
        self.engine=GatherEngine(cfg,self.logs.append,gamepad=self.input)
        self.engine.bridge=SimpleNamespace(send=self.commands.append,cursor=lambda x,y:self.positions.append((x,y)))
        self.engine.screen=SimpleNamespace(focused=lambda:self.focus)
        self.engine.safety_threads=[None]
        self.current=observation()
        self.engine.vision=SimpleNamespace(scan=lambda _,**kwargs:self.current)
        self.frame=np.zeros((1440,2560,3),np.uint8)
        self.candidate=Candidate('Сапфир',800,450,95,(770,410,60,20))

    def select(self):
        with patch.object(self.engine.stop_event,'wait',return_value=False), patch.object(GamepadInput,'wait',return_value=True):
            self.engine.click_candidate(self.candidate,(20,30))

    def test_two_a_at_existing_ocr_coordinates_not_mouse_click(self):
        self.select()
        self.assertEqual(self.pad.presses,2)
        self.assertEqual(self.pad.buttons,0)
        self.assertEqual(self.positions,[(820,480),(820,480)])
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP'])
        self.assertEqual(self.engine.mode,'APPROACH')
        self.assertFalse(self.engine.target_confirmed)

    def test_cancel_between_a_presses_suppresses_second_and_releases_alt(self):
        calls=[]
        def wait(*args):
            calls.append(1)
            if len(calls)==2:
                self.engine.stop_event.set();return False
            return True
        with patch.object(self.engine.stop_event,'wait',return_value=False), patch.object(GamepadInput,'wait',side_effect=wait):
            self.engine.click_candidate(self.candidate,(0,0))
        self.assertEqual(self.pad.presses,1)
        self.assertEqual(self.pad.buttons,0)
        self.assertEqual(self.commands[-1],'ALT_UP')
        self.assertEqual(self.engine.mode,'SEARCH')

    def test_report_error_after_press_still_releases_a_and_alt(self):
        self.pad.fail=True
        with patch.object(self.engine.stop_event,'wait',return_value=False):
            with self.assertRaises(RuntimeError):self.engine.click_candidate(self.candidate,(0,0))
        self.assertEqual(self.pad.buttons,0)
        self.assertEqual(self.commands[-1],'ALT_UP')

    def test_dry_run_performs_no_a_alt_or_cursor(self):
        self.engine.cfg['dry_run']=True
        self.select()
        self.assertEqual(self.pad.presses,0)
        self.assertEqual(self.commands,[])
        self.assertEqual(self.positions,[])

    def test_target_then_prompt_enables_f_without_waiting_for_three_attempts(self):
        self.engine.target='Сапфир';self.engine.mode='APPROACH';self.engine.started=100
        self.current=observation('Сапфир',distance=20)
        self.engine.process(self.frame,(0,0),101)
        self.assertTrue(self.engine.target_confirmed)
        self.assertNotIn('F_ON',self.commands)
        self.current=observation('Сапфир',prompt=True,distance=1)
        self.engine.process(self.frame,(0,0),102)
        self.assertIn('F_ON',self.commands)
        self.assertEqual(self.engine.mode,'GATHER')

    def gathering(self):
        self.engine.mode='GATHER';self.engine.target='Сапфир';self.engine.f_on=True
        self.engine.started=90;self.engine.last_seen=99;self.engine.target_confirmed=True

    def test_depleted_target_stops_f_even_if_stale_f_prompt_remains(self):
        self.gathering();self.current=observation(prompt=True)
        for now in (100,101,102):self.engine.process(self.frame,(0,0),now)
        self.assertIn('F_OFF',self.commands)
        self.assertEqual(self.engine.mode,'SEARCH')
        self.assertEqual(self.engine.node_count,1)

    def test_single_ocr_miss_does_not_restart_or_interrupt_gather(self):
        self.gathering();self.current=observation()
        self.engine.process(self.frame,(0,0),100)
        self.current=observation('Сапфир',gathering=True)
        self.engine.process(self.frame,(0,0),101)
        self.assertEqual(self.engine.mode,'GATHER')
        self.assertNotIn('F_OFF',self.commands)
        self.assertIsNone(self.engine.target_missing_since)

    def test_wrong_target_stops_f_without_counting_success(self):
        self.gathering();self.current=observation('Рубин')
        self.engine.process(self.frame,(0,0),100)
        self.assertIn('F_OFF',self.commands)
        self.assertEqual(self.engine.node_count,0)

    def test_unconfirmed_a_does_not_start_f(self):
        self.engine.mode='APPROACH';self.engine.target='Сапфир';self.engine.started=100
        self.current=observation(prompt=True)
        self.engine.process(self.frame,(0,0),106)
        self.assertNotIn('F_ON',self.commands)
        self.assertEqual(self.engine.mode,'SEARCH')

    def test_map_navigation_uses_marker_coordinates_and_two_a(self):
        marker=Marker('Ресурс',2300,250,.96,60)
        with patch.object(GamepadInput,'wait',return_value=True):
            self.engine.map_navigate(marker,(10,20),100)
        self.assertEqual(self.positions,[(2310,270),(2310,270)])
        self.assertEqual(self.pad.presses,2)
        self.assertEqual(self.engine.mode,'MAP_TRAVEL')

    def test_map_stall_returns_to_search_and_temporarily_skips_marker(self):
        marker=Marker('Ресурс',2300,250,.96,60)
        self.engine.map_goal=marker;self.engine.map_best_distance=60
        self.engine.mode='MAP_TRAVEL';self.engine.started=100;self.engine.last_progress=100
        self.engine.minimap=SimpleNamespace(scan=lambda _:[])
        self.engine.map_travel(self.frame,(0,0),observation(),110)
        self.assertEqual(self.engine.mode,'SEARCH')
        self.assertTrue(self.engine.map_excluded(marker,110))

    def test_world_name_interrupts_map_travel(self):
        self.engine.mode='MAP_TRAVEL'
        self.engine.map_travel(self.frame,(0,0),observation(candidate=self.candidate),100)
        self.assertEqual(self.engine.mode,'SEARCH')
        self.assertEqual(self.pad.presses,0)

    def test_stopped_engine_does_not_issue_more_commands(self):
        self.engine.stop_event.set();self.current=observation(candidate=self.candidate)
        self.engine.process(self.frame,(0,0),100)
        self.assertEqual(self.commands,[])
        self.assertEqual(self.pad.presses,0)


class MinimapTests(unittest.TestCase):
    def test_actual_saved_template_on_shifted_background_and_blank_negative(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as folder:
            icon=np.full((23,23,3),35,np.uint8)
            cv2.polylines(icon,[np.array([[11,5],[17,11],[11,17],[5,11]])],True,(240,240,240),2)
            file=Path(folder)/'resource.png';cv2.imwrite(str(file),icon)
            cfg={'minimap_roi':[.6,.1,.35,.6],'minimap_player':[.1,.1],
                 'minimap_reference_size':[300,200],'minimap_threshold':.90,
                 'minimap_templates':[{'name':'Сапфир','file':file.relative_to(ROOT).as_posix()}]}
            vision=MinimapVision(cfg)
            frame=np.full((200,300,3),35,np.uint8)
            self.assertEqual(vision.scan(frame),[])
            frame[69:92,229:252]=icon
            found=vision.scan(frame)
            self.assertEqual(len(found),1)
            self.assertEqual(found[0].name,'Сапфир')
            self.assertLess(abs(found[0].x-240),3)
            self.assertLess(abs(found[0].y-80),3)


if __name__=='__main__':unittest.main()
