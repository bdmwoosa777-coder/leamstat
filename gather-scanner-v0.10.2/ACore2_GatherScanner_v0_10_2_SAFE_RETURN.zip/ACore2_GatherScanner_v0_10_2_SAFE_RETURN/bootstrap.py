from pathlib import Path
import os,subprocess,sys,venv
ROOT=Path(__file__).resolve().parent

def main():
 if not (3,10)<=sys.version_info[:2]<(3,14) or sys.maxsize<=2**32:raise RuntimeError('Нужен Python 3.12 x64; поддерживаются 3.10–3.13')
 env=ROOT/'.venv'
 if not env.exists():venv.EnvBuilder(with_pip=True).create(env)
 python=env/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
 install_env=os.environ.copy();install_env['VGAMEPAD_SKIP_VIGEMBUS_INSTALL']='true'
 subprocess.run([str(python),'-m','pip','install','--disable-pip-version-check','-r',str(ROOT/'requirements.txt')],check=True,env=install_env)
 subprocess.run([str(python),str(ROOT/'check_scene.py')],check=True)
 print('Готово. Запустите START.bat')
if __name__=='__main__':main()
