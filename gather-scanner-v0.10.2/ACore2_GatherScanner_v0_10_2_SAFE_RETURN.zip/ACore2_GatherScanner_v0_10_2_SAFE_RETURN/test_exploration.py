from pathlib import Path
import math,tempfile,unittest
import cv2
import numpy as np
from camera_pitch import PitchLedger
from minimap import Radar,Marker,MinimapVision,angle_delta
from navigation import Navigator
from map_reference import TerrainMatcher,MapReference,ArrowLocator,transform

ROOT=Path(__file__).resolve().parent


def radar(markers=None,heading=90,flow=(0,0),valid=False):
    return Radar(markers or [],(100,100),heading,1,flow,valid,(0,0,200,200))


class ExplorationTests(unittest.TestCase):
    def test_no_icons_make_a_long_straight_run(self):
        nav=Navigator({})
        for i in range(200):
            plan=nav.update(radar(),i*.1)
            self.assertGreater(plan.forward,.7);self.assertEqual(plan.yaw,0)

    def test_camera_turns_are_rare_between_patrol_legs(self):
        nav=Navigator({});turns=0
        for i in range(800):
            plan=nav.update(radar(),i*.1);turns+=bool(plan.yaw)
            self.assertGreater(plan.forward,.7)
        self.assertLess(turns,15)

    def test_near_aligned_noisy_camera_does_not_twitch(self):
        nav=Navigator({});node=Marker('Самоцвет',150,100,.9,50)
        for i in range(30):
            plan=nav.update(radar([node],80 if i%2 else 100),i*.1)
            self.assertEqual(plan.yaw,0);self.assertGreater(plan.forward,.6)

    def test_large_camera_error_does_not_block_movement(self):
        plan=Navigator({}).update(radar([Marker('Самоцвет',150,100,.9,50)],0),0)
        self.assertGreater(plan.strafe,.7);self.assertGreater(abs(plan.yaw),.3)

    def test_single_heading_flip_is_not_a_command_to_reverse(self):
        nav=Navigator({});node=Marker('Самоцвет',150,100,.9,50)
        nav.update(radar([node],90),0)
        plan=nav.update(radar([node],270),.1)
        self.assertEqual(plan.yaw,0);self.assertGreater(plan.forward,.7)

    def test_camera_pulses_have_a_settling_interval(self):
        nav=Navigator({});node=Marker('Самоцвет',150,100,.9,50)
        self.assertNotEqual(nav.update(radar([node],0),0).yaw,0)
        self.assertEqual(nav.update(radar([node],0),.2).yaw,0)
        self.assertEqual(nav.update(radar([node],0),.5).yaw,0)

    def test_small_opposite_heading_error_does_not_reverse_camera(self):
        nav=Navigator({});node=Marker('Самоцвет',150,100,.9,50)
        nav.update(radar([node],0),0)
        self.assertEqual(nav._yaw(-20,1),0)

    def test_aether_near_player_is_a_bounded_up_and_down_search(self):
        nav=Navigator({});node=Marker('Эфир',106,100,.9,6,'aether')
        plan=nav.update(radar([node]),0)
        self.assertEqual(plan.forward,0);self.assertGreater(plan.pitch,0);self.assertLessEqual(plan.lifetime,.07)
        self.assertEqual(nav.update(radar([node]),.1).pitch,0)
        self.assertGreater(nav.update(radar([node]),1.2).pitch,0)
        self.assertLess(nav.update(radar([node]),3.8).pitch,0)
        result=nav.update(radar([node]),9.5)
        self.assertTrue(result.restore_pitch);self.assertTrue(result.flight_probe);self.assertIsNotNone(nav.goal)

    def test_aether_icon_hidden_by_player_arrow_does_not_abort_sky_search(self):
        nav=Navigator({});node=Marker('Эфир',106,100,.9,6,'aether')
        nav.update(radar([node]),0)
        plan=nav.update(radar(),1.5)
        self.assertGreater(plan.pitch,0);self.assertLessEqual(plan.lifetime,.07);self.assertIsNotNone(nav.goal)

    def test_aether_behind_camera_is_approached_before_sky_sweep(self):
        nav=Navigator({});node=Marker('Эфир',120,100,.9,20,'aether')
        plan=nav.update(radar([node],270),0)
        self.assertEqual(plan.pitch,0)
        self.assertGreater(math.hypot(plan.forward,plan.strafe),.7)

    def test_unknown_map_orientation_holds_motion(self):
        nav=Navigator({});nav.route(None,'',priority=True)
        plan=nav.update(radar(),0)
        self.assertEqual((plan.forward,plan.strafe,plan.yaw),(0,0,0))

    def test_outside_zone_return_has_priority_over_resource_icons(self):
        nav=Navigator({});nav.route(90,'возврат',priority=True)
        plan=nav.update(radar([Marker('Самоцвет',50,100,.9,50)],90),0)
        self.assertGreater(plan.forward,.7);self.assertIsNone(nav.goal)


class PitchTests(unittest.TestCase):
    def test_delayed_loop_counts_only_input_until_lease_expiry(self):
        pitch=PitchLedger();pitch.apply(.6,0,lifetime=.45);pitch.neutral(3)
        self.assertAlmostEqual(pitch.balance,.27)

    def test_return_reverses_delivered_pitch_and_finishes(self):
        pitch=PitchLedger();pitch.apply(.6,0);pitch.neutral(.3);pitch.restore(.4)
        now=.4
        for _ in range(30):
            command=pitch.correction(now)
            if not command:break
            pitch.apply(command,now);now+=.1
        self.assertFalse(pitch.returning);self.assertLess(abs(pitch.balance),.018)

    def test_camera_return_is_bounded_even_after_a_long_control_gap(self):
        pitch=PitchLedger();pitch.balance=.5;pitch.restore(0)
        pitch.correction(20)
        self.assertFalse(pitch.returning)
        self.assertTrue(pitch.failed);self.assertEqual(pitch.balance,.5)


class MapTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.crop=cv2.imread(str(ROOT/'testdata/minimap_ground_crop.png'))
        cls.background=cv2.resize(cls.crop,(900,600))
        # Remove the original character marker from this terrain test crop.
        cls.background[250:350,380:520]=cls.background[50:150,30:170]
        cls.template=cv2.imread(str(ROOT/'assets/player_arrow_mask.png'),0)

    def test_terrain_registration_handles_zoom_pan_and_rotation(self):
        ref=self.crop;h,w=ref.shape[:2]
        matrix=cv2.getRotationMatrix2D((w/2,h/2),4,1.15);matrix[:,2]+=(35,25)
        target=cv2.warpAffine(ref,matrix,(550,400))
        result=TerrainMatcher(ref).register(target)
        self.assertIsNotNone(result)
        expected=matrix@np.array([180,120,1]);actual=transform((180,120),result.matrix)
        self.assertLess(math.hypot(actual[0]-expected[0],actual[1]-expected[1]),4)

    def test_blank_screenshot_does_not_create_a_location(self):
        self.assertIsNone(TerrainMatcher(self.crop).register(np.zeros((500,800,3),np.uint8)))

    def test_closed_map_with_a_small_minimap_is_not_full_map_confirmation(self):
        image=np.zeros((1000,1600,3),np.uint8);small=cv2.resize(self.crop,(190,126))
        image[100:226,1300:1490]=small
        self.assertIsNone(TerrainMatcher(self.crop).register(image))

    def test_character_arrow_and_camera_cone_are_distinct(self):
        image=np.full((1395,2480,3),90,np.uint8);image[152:403,2071:2450]=self.crop
        result=MinimapVision({}).observe(image)
        self.assertIsNotNone(result.character_heading)
        self.assertLess(abs(angle_delta(result.character_heading,30)),16)
        self.assertGreater(abs(angle_delta(result.character_heading,result.heading)),120)

    def test_minimap_terrain_translation_is_measured_separately_from_player(self):
        first=np.full((1395,2480,3),90,np.uint8);first[152:403,2071:2450]=self.crop
        moved=cv2.warpAffine(self.crop,np.float32([[1,0,3],[0,1,-2]]),(379,251))
        second=first.copy();second[152:403,2071:2450]=moved
        vision=MinimapVision({});vision.observe(first);result=vision.observe(second)
        self.assertTrue(result.motion_valid)
        self.assertLess(math.hypot(result.displacement[0]-3,result.displacement[1]+2),.8)

    def test_identical_two_player_arrows_are_ambiguous(self):
        image=np.full((300,400,3),70,np.uint8)
        for x in (80,240):
            patch=image[100:164,x:x+64];patch[self.template>128]=(250,250,250)
        self.assertIsNone(ArrowLocator(self.template).locate(image,64))

    def test_zone_route_from_full_map_registration(self):
        with tempfile.TemporaryDirectory(dir=ROOT) as directory:
            folder=Path(directory);ref=self.background.copy();current=self.background.copy()
            ref[180:244,280:344][self.template>128]=(250,250,250)
            current[268:332,808:872][self.template>128]=(250,250,250)
            cv2.imwrite(str(folder/'map.png'),ref);cv2.imwrite(str(folder/'arrow.png'),self.template)
            cfg={'world_map':{'file':str((folder/'map.png').relative_to(ROOT)),
                'arrow_file':str((folder/'arrow.png').relative_to(ROOT)),
                'arrow_size':64,'frame_width':900,'zone':[[100,100],[750,100],[750,500],[100,500]],
                'waypoints':[[250,300],[650,300]],'north_up':True}}
            region=MapReference(cfg);self.assertTrue(region.ready)
            fix=region.locate(current)
            self.assertIsNotNone(fix)
            self.assertTrue(fix.outside)
            self.assertLess(abs(fix.position[0]-840),8)
            self.assertLess(abs(angle_delta(fix.bearing,270)),6)


if __name__=='__main__':unittest.main()
