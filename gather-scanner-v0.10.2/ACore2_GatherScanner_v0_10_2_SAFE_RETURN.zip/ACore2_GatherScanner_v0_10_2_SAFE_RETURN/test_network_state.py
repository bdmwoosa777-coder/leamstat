"""Synthetic protocol tests. Private player captures are never test fixtures."""
import struct,unittest
from network_state import Telemetry,Flow,stats,Invalid

def v(n):
 b=bytearray()
 while n>=128:b.append((n&127)|128);n>>=7
 b.append(n);return bytes(b)

def profile(actor=99,kind=1550020,used=0):
 b=bytearray(52);struct.pack_into('<HIfff',b,0,4,kind,10000.,20000.,3000.);struct.pack_into('<I',b,37,used)
 return v(actor)+b

def gauge(actor=7,flags=1,items=((3,120000),)):
 return v(actor)+bytes((flags,len(items)))+b''.join(bytes((k,))+int(n).to_bytes(4,'little') for k,n in items)

class TelemetryTests(unittest.TestCase):
 def setUp(self):
  self.t=Telemetry({1550020,1550000});self.t.feed(1,'008d',gauge(),0)
 def feed(self,op,b,t=100):return self.t.feed(1,op,b,t)
 def start(self):
  self.feed('3436',profile(),10);self.feed('3438',b'\0\0\0'+v(99),20)
  self.feed('3836',v(99)+v(7)+b'\1',30)
  self.feed('318d',b'\0\0'+v(99)+struct.pack('<I',1)+bytes(25),35)
 def done(self,used,t):return self.feed('3a36',v(99)+v(7)+struct.pack('<II',used,0),t)
 def test_no_fixed_identity_or_maximum(self):
  f=self.t.flows[1];self.assertEqual(f.own,7);self.assertIsNone(f.maximum);self.assertIsNone(f.flight_maximum)
 def test_flight_alone_does_not_guess_own_identity(self):
  t=Telemetry();t.feed(1,'008d',gauge(items=((6,20000),)),1)
  self.assertIsNone(t.flows[1].own)
 def test_progress_message_may_precede_start_at_same_timestamp(self):
  self.feed('3436',profile(),10);self.feed('3438',bytes(3)+v(99),20)
  self.feed('318d',bytes(2)+v(99)+struct.pack('<I',1)+bytes(25),30)
  self.assertFalse(any(e['kind']=='own_gather_started' for e in self.t.events))
  events=self.feed('3836',v(99)+v(7)+b'\1',30)
  self.assertEqual([e['kind'] for e in events],['own_interaction_start','own_gather_started'])
 def test_pending_progress_does_not_authorize_a_neighbour(self):
  self.feed('3436',profile(),10);self.feed('3438',bytes(3)+v(99),20)
  self.feed('318d',bytes(2)+v(99)+struct.pack('<I',1)+bytes(25),30)
  events=self.feed('3836',v(99)+v(8)+b'\1',30)
  self.assertEqual(events,[]);self.assertIsNone(self.t.flows[1].collecting)
 def test_clear_selection_between_attempts_preserves_resource(self):
  self.start();self.done(1,40);self.feed('3438',bytes(4),45)
  self.assertEqual(self.t.flows[1].collecting,99);self.assertEqual(self.t.flows[1].nodes[99].used,1)
  self.assertFalse(any(e['kind']=='own_resource_exhausted' for e in self.t.events))
 def test_third_attempt_is_exhaustion(self):
  self.start();self.done(1,40);self.done(2,50);events=self.done(3,60)
  self.assertEqual([e['kind'] for e in events],['own_attempt_ended','own_resource_exhausted'])
  self.assertIsNone(self.t.flows[1].collecting)
 def test_old_lower_counter_cannot_restore_attempts(self):
  self.start();self.done(2,40);events=self.done(1,50)
  self.assertEqual(self.t.flows[1].nodes[99].used,2);self.assertEqual(events,[])
 def test_other_gatherer_cannot_enable_our_collection(self):
  self.feed('3436',profile(),10);self.feed('3836',v(99)+v(55)+b'\1',20)
  self.assertIsNone(self.t.flows[1].collecting)
 def test_other_gatherer_updates_known_counter_without_own_reward_or_permission(self):
  self.start();events=self.feed('3a36',v(99)+v(55)+struct.pack('<II',2,0),40)
  self.assertEqual(self.t.flows[1].nodes[99].used,2);self.assertEqual(events,[])
 def test_fall_is_explicit_noncombat_event(self):
  events=self.feed('1738',v(7)+v(280),100)
  self.assertEqual(events[0]['kind'],'own_fall_damage');self.assertEqual(events[0]['damage'],280)
  self.assertFalse(any(e['kind']=='own_combat_damage' for e in events))
 def test_area_hit_on_our_character_does_not_require_attacker_to_target_us(self):
  # An ignored target-of-target packet can name a spirit; actual hit target is ours.
  self.feed('3538',v(55)+b'\0'+v(8),40)
  body=v(7)+v(4)+v(0)+v(55)+struct.pack('<I',100)+b'\0'+v(2)+struct.pack('<II',1,1)+v(10000)+v(1)+b'\1\0'
  events=self.feed('0438',body,50)
  self.assertEqual(events[0]['kind'],'own_combat_damage');self.assertEqual(events[0]['actor'],55)
  self.assertEqual(self.t.flows[1].attacks,{55:50})
 def test_damage_only_to_spirit_does_not_start_our_defense(self):
  body=v(8)+v(4)+v(0)+v(55)+struct.pack('<I',100)+b'\0'+v(2)+struct.pack('<II',1,1)+v(10000)+v(1)+b'\1\0'
  self.assertEqual(self.feed('0438',body),[]);self.assertEqual(self.t.flows[1].attacks,{})
 def test_profile_refresh_preserves_current_gather_permission(self):
  self.start();self.feed('3436',profile(used=0),50)
  self.assertEqual(self.t.flows[1].nodes[99].gather_time,35)
 def test_foreign_fall_is_ignored(self):self.assertEqual(self.feed('1738',v(8)+v(280)),[])
 def test_flight_and_hp_lists_use_their_separate_widths(self):
  b=v(7)+b'\3\1\6'+struct.pack('<I',250000)+b'\1\0'+struct.pack('<Q',17000)
  actor,rows=stats(b);self.assertEqual(actor,7);self.assertEqual(rows[4,6],250000);self.assertEqual(rows[8,0],17000)
  events=self.feed('008d',b);self.assertEqual(events[0]['hp'],17000);self.assertEqual(events[0]['flight'],250000)
 def test_flight_updates_for_foreign_actor_do_not_change_ours(self):
  self.feed('008d',gauge(actor=8,items=((6,1),)));self.assertIsNone(self.t.flows[1].flight)
 def test_cube_item_reward_is_not_used_count(self):
  self.start();self.feed('3a36',v(99)+v(7)+struct.pack('<II',1,123),40)
  self.assertEqual(self.t.flows[1].nodes[99].used,0)
 def test_unavailable_offscreen_node_is_not_exhaustion(self):
  self.start();events=self.feed('3536',v(99)+bytes((1,1,0)),40)
  self.assertFalse(events[0]['exhausted']);self.assertIsNone(self.t.flows[1].collecting)
 def test_truncated_rows_are_rejected_without_changing_stats(self):
  before=self.t.flows[1].flight
  self.feed('008d',v(7)+b'\1\1\6\1')
  self.assertEqual(self.t.flows[1].flight,before);self.assertEqual(self.t.rejected,1)
 def test_cross_flow_and_stale_identity_are_not_reused(self):
  self.t.feed(2,'3836',v(99)+v(7)+b'\1',50)
  self.assertIsNone(self.t.flows[2].own)
  self.feed('3836',v(99)+v(7)+b'\1',31000);self.assertIsNone(self.t.flows[1].own)

if __name__=='__main__':unittest.main()
