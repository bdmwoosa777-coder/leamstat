# -*- coding: utf-8 -*-
"""Ctrl+F8/F9/F10 using Win32 RegisterHotKey, matching TargetScanner v26.
No keyboard injection. Executes callbacks in Tk UI thread through queue.
"""
import ctypes
import os
import threading
from ctypes import wintypes

HOTKEYS={"toggle":0x77,"stop":0x78,"silence":0x79}
MOD_CONTROL=0x0002
MOD_NOREPEAT=0x4000
WM_HOTKEY=0x0312
WM_QUIT=0x0012

class SystemHotkeys:
    def __init__(self, queue):
        self.queue=queue
        self.thread_id=0
        self.registered={}
        self.ready=threading.Event()
        self.thread=threading.Thread(target=self._main,daemon=True)
        if os.name=='nt':
            self.thread.start()
            self.ready.wait(2)
        else:
            self.queue.put('Горячие клавиши Win32 работают только в Windows')

    def _main(self):
        u32=ctypes.windll.user32
        kernel32=ctypes.windll.kernel32
        u32.RegisterHotKey.argtypes=[wintypes.HWND,ctypes.c_int,wintypes.UINT,wintypes.UINT]
        u32.RegisterHotKey.restype=wintypes.BOOL
        u32.UnregisterHotKey.argtypes=[wintypes.HWND,ctypes.c_int]
        u32.UnregisterHotKey.restype=wintypes.BOOL
        u32.PeekMessageW.argtypes=[ctypes.POINTER(wintypes.MSG),wintypes.HWND,wintypes.UINT,wintypes.UINT,wintypes.UINT]
        u32.GetMessageW.argtypes=[ctypes.POINTER(wintypes.MSG),wintypes.HWND,wintypes.UINT,wintypes.UINT]
        u32.GetMessageW.restype=ctypes.c_int
        u32.PostThreadMessageW.argtypes=[wintypes.DWORD,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]
        self._u32=u32
        msg=wintypes.MSG()
        self.thread_id=kernel32.GetCurrentThreadId()
        u32.PeekMessageW(ctypes.byref(msg),None,0,0,0)
        for i,(name,vk) in enumerate(HOTKEYS.items(),start=101):
            if u32.RegisterHotKey(None,i,MOD_CONTROL|MOD_NOREPEAT,vk):
                self.registered[i]=name
            else:
                self.queue.put(f'Не зарегистрирован Ctrl+F{vk-0x6F}: WinError={kernel32.GetLastError()}')
        self.queue.put('Горячие клавиши: '+(', '.join(f'Ctrl+F{HOTKEYS[n]-0x6F}' for n in self.registered.values()) if self.registered else 'НЕ зарегистрированы'))
        self.ready.set()
        try:
            while True:
                result=u32.GetMessageW(ctypes.byref(msg),None,0,0)
                if result<=0:break
                if msg.message==WM_HOTKEY:
                    name=self.registered.get(int(msg.wParam))
                    if name:self.queue.put(('hotkey',name))
        finally:
            for i in self.registered:u32.UnregisterHotKey(None,i)

    def stop(self):
        if self.thread_id and os.name=='nt':
            self._u32.PostThreadMessageW(self.thread_id,WM_QUIT,0,0)
