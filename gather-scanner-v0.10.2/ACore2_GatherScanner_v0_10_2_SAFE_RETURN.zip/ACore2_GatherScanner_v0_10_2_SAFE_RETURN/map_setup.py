"""Capture a map reference, patrol boundary, and road waypoints on a still image."""
from pathlib import Path
import math
import tkinter as tk
from tkinter import ttk,messagebox
import cv2
import numpy as np
from PIL import Image,ImageTk
from map_reference import arrow_mask

ROOT=Path(__file__).resolve().parent


class MapSetup:
    def __init__(self,parent,frame,cfg,on_save):
        self.frame,self.cfg,self.on_save=frame,cfg,on_save;self.stage=0;self.start=None
        self.zone=[];self.points=[];self.rect=None
        self.window=tk.Toplevel(parent);self.window.title('Зона поиска по большой карте')
        self.scale=min(1400/frame.shape[1],800/frame.shape[0],1)
        image=Image.fromarray(cv2.cvtColor(frame,cv2.COLOR_BGR2RGB));image=image.resize((round(image.width*self.scale),round(image.height*self.scale)))
        self.photo=ImageTk.PhotoImage(image)
        self.label=ttk.Label(self.window,text='1/5: обведите область самой большой карты без меню и панелей.');self.label.pack(anchor='w',padx=8,pady=5)
        self.canvas=tk.Canvas(self.window,width=image.width,height=image.height,cursor='crosshair');self.canvas.pack();self.canvas.create_image(0,0,anchor='nw',image=self.photo)
        self.canvas.bind('<ButtonPress-1>',self.down);self.canvas.bind('<B1-Motion>',self.drag);self.canvas.bind('<ButtonRelease-1>',self.up)
        buttons=ttk.Frame(self.window);buttons.pack(fill='x',padx=8,pady=5)
        self.north=tk.BooleanVar(value=True);ttk.Checkbutton(buttons,text='Север обеих карт сверху',variable=self.north).pack(side='left')
        ttk.Button(buttons,text='Граница готова → точки маршрута',command=self.finish_zone).pack(side='left',padx=5)
        ttk.Button(buttons,text='Убрать последнюю точку',command=self.undo).pack(side='left')
        ttk.Button(buttons,text='Сохранить зону',command=self.save).pack(side='right')

    def point(self,event):return max(0,min(self.frame.shape[1]-1,round(event.x/self.scale))),max(0,min(self.frame.shape[0]-1,round(event.y/self.scale)))

    def down(self,event):
        point=self.point(event)
        if self.stage in (3,4):
            x0,y0,x1,y1=self.roi;x,y=point
            if not(x0<=x<x1 and y0<=y<y1):return
            local=(x-x0,y-y0)
            if self.stage==4 and cv2.pointPolygonTest(np.array(self.zone,np.float32),local,False)<0:
                messagebox.showerror('Маршрут','Точка должна быть внутри границы зоны.',parent=self.window);return
            (self.zone if self.stage==3 else self.points).append(local);self.draw_points();return
        if self.stage==2:
            x,y=point;cx,cy=self.arrow_center
            if math.hypot(x-cx,y-cy)<5:return
            self.arrow_heading=math.degrees(math.atan2(x-cx,cy-y))%360
            self.stage=3;self.label.config(text='4/5: отметьте вершины границы зоны поиска по порядку (минимум 3), затем «Граница готова».');return
        self.start=point
        if self.rect:self.canvas.delete(self.rect)
        self.rect=self.canvas.create_rectangle(event.x,event.y,event.x,event.y,outline='#00ffff',width=2)

    def drag(self,event):
        if self.start and self.stage<2:
            x,y=self.start;self.canvas.coords(self.rect,x*self.scale,y*self.scale,event.x,event.y)

    def up(self,event):
        if self.start is None or self.stage>1:return
        a,b=self.start;self.start=None;c,d=self.point(event);x0,x1=sorted((a,c));y0,y1=sorted((b,d))
        if self.stage==0:
            if min(x1-x0,y1-y0)<200 or (x1-x0)*(y1-y0)<self.frame.shape[0]*self.frame.shape[1]*.20:return
            self.roi=(x0,y0,x1,y1);self.stage=1
            self.label.config(text='2/5: плотно обведите ТОЛЬКО белую стрелку своего персонажа (без соседних значков).')
        else:
            if min(x1-x0,y1-y0)<12 or max(x1-x0,y1-y0)>180:return
            self.arrow_box=(x0,y0,x1,y1);self.arrow_center=((x0+x1)/2,(y0+y1)/2)
            self.stage=2;self.label.config(text='3/5: щёлкните по носику стрелки — куда смотрит персонаж, не камера.')

    def draw_points(self):
        self.canvas.delete('route');x0,y0,_,_=self.roi
        for points,colour in [(self.zone,'#ffff00'),(self.points,'#00ff88')]:
            coords=[]
            for i,(x,y) in enumerate(points):
                x,y=(x+x0)*self.scale,(y+y0)*self.scale;coords.extend((x,y))
                self.canvas.create_oval(x-4,y-4,x+4,y+4,fill=colour,tags='route')
                self.canvas.create_text(x+8,y-8,text=str(i+1),fill=colour,tags='route')
            if len(coords)>=4:self.canvas.create_line(*coords,fill=colour,width=2,tags='route')

    def finish_zone(self):
        if self.stage!=3 or len(self.zone)<3:return
        if not cv2.isContourConvex(np.array(self.zone,np.int32)):
            messagebox.showerror('Граница','Для первой настройки выберите простую выпуклую границу без пересечений.',parent=self.window);return
        self.stage=4;self.label.config(text='5/5: отметьте точки прохода по дорогам ВНУТРИ зоны (минимум 2), затем сохраните.');self.draw_points()

    def undo(self):
        points=self.zone if self.stage==3 else self.points
        if points:points.pop();self.draw_points()

    def save(self):
        if self.stage!=4 or len(self.points)<2:return
        folder=ROOT/'assets/world_map';folder.mkdir(parents=True,exist_ok=True)
        x0,y0,x1,y1=self.roi;reference=self.frame[y0:y1,x0:x1]
        ax,ay,bx,by=self.arrow_box;cx,cy=self.arrow_center;n=max(bx-ax,by-ay)+8
        # Pad to a square centred on the arrow; all rotations share this anchor.
        source=arrow_mask(self.frame[ay:by,ax:bx]);square=np.zeros((n,n),np.uint8)
        left=(n-source.shape[1])//2;top=(n-source.shape[0])//2
        square[top:top+source.shape[0],left:left+source.shape[1]]=source
        matrix=cv2.getRotationMatrix2D((n/2,n/2),self.arrow_heading,1)
        template=cv2.resize(cv2.warpAffine(square,matrix,(n,n)),(64,64))
        if np.count_nonzero(template)>64*64*.65 or np.count_nonzero(template)<40:
            messagebox.showerror('Стрелка','Стрелка выделена неустойчиво. Повторите настройку с чётким масштабом карты.',parent=self.window);return
        if not cv2.imwrite(str(folder/'reference.png'),reference) or not cv2.imwrite(str(folder/'arrow.png'),template):raise OSError('Не удалось сохранить карту')
        self.cfg['world_map']={'file':'assets/world_map/reference.png','arrow_file':'assets/world_map/arrow.png',
            'arrow_size':n,'frame_width':self.frame.shape[1],'zone':self.zone,'waypoints':self.points,
            'north_up':self.north.get(),'arrival_pixels':20}
        self.cfg['world_map_enabled']=True
        self.on_save();self.window.destroy()
