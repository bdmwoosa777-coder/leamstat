"""Resolve an actually installed compatible interpreter, including Python Manager."""
from pathlib import Path
import json,os,shutil,subprocess,sys
ROOT=Path(__file__).resolve().parent

def probe(command):
 try:
  result=subprocess.run([*command,'-c','import json,sys;print(json.dumps({"version":list(sys.version_info[:2]),"exe":sys.executable,"bits":64 if sys.maxsize>2**32 else 32}))'],capture_output=True,text=True,timeout=20)
  if result.returncode:return None
  data=json.loads(result.stdout.strip());version=data['version']
  if version[0]!=3 or not 10<=version[1]<=13 or data['bits']!=64:return None
  return data['exe'] if Path(data['exe']).is_file() else None
 except (OSError,ValueError,KeyError,subprocess.TimeoutExpired):return None

def main():
 candidates=[]
 if shutil.which('py'):
  candidates += [['py','-'+v] for v in ('3.12','3.13','3.11','3.10')]
 candidates.append([sys.executable])
 local=Path(os.environ.get('LOCALAPPDATA',''))
 for v in ('3.12','3.13','3.11','3.10'):
  candidates.append([str(local/'Python'/f'pythoncore-{v}-64'/'python.exe')])
 for candidate in candidates:
  executable=probe(candidate)
  if executable:
   print('Python:',executable,flush=True)
   return subprocess.run([executable,str(ROOT/'bootstrap.py')]).returncode
 print('Нужен Python 3.12 x64. Установка: py install 3.12',flush=True);return 1

if __name__=='__main__':raise SystemExit(main())
