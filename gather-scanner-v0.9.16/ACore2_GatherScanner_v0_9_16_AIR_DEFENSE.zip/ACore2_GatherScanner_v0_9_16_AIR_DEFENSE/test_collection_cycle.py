"""Rendered attempt progress must never be interrupted by periodic input."""
from pathlib import Path
from tempfile import TemporaryDirectory
import struct,unittest
from unittest.mock import patch
import cv2,numpy as np
import gather_engine as ge
from app import DEFAULT
from collection_cycle import CollectionCycle
from gamepad_input import GamepadInput
from test_navigation import GatherFixture
from test_network_control import Source
from test_network_state import gauge,profile,v
from network_state import Telemetry
from vision import find_selected_resource_badge,gathering_panel_pair,gather_result_full

class CyclePolicy(unittest.TestCase):
    def setUp(self):self.p=CollectionCycle();self.key=((1,99),900);self.attempt=(1000,1)
    def see(self,t=0,panel=True,full=False,used=None,valid=False,resume=False,attempt=None,key=None):
        return self.p.observe(key or self.key,attempt or self.attempt,t,panel,full,used,valid,resume)

    def test_partial_panel_blocks_even_a_reported_result(self):
        self.assertIsNone(self.see(used=1,valid=True))
    def test_active_partial_for_26_seconds_never_grants_a_click(self):
        for t in range(26):self.assertIsNone(self.see(t))
    def test_result_requires_a_real_panel_observation_first(self):
        self.assertIsNone(self.see(panel=False,used=1,valid=True))
    def test_own_result_allows_one_request_after_panel_disappears(self):
        self.see();token=self.see(1,panel=False,used=1,valid=True)
        self.assertEqual(token,('end',1));self.assertTrue(self.p.consume(token))
        self.assertIsNone(self.see(10,panel=False,used=1,valid=True))
    def test_duplicate_result_cannot_grant_another_click(self):
        self.see();token=self.see(1,panel=False,used=1,valid=True);self.p.consume(token)
        for t in range(2,10):self.assertIsNone(self.see(t,panel=False,used=1,valid=True))
    def test_full_track_must_follow_partial_and_remain_full(self):
        self.see();self.assertIsNone(self.see(1,full=True));self.assertIsNone(self.see(1.2,full=True))
        self.assertEqual(self.see(1.3,full=True),('end',1))
    def test_initial_full_track_without_partial_cannot_invent_an_end(self):
        for t in (0,1,5):self.assertIsNone(self.see(t,full=True))
    def test_new_attempt_rejects_the_previous_full_ui(self):
        self.see();token=self.see(1,panel=False,used=1,valid=True);self.p.consume(token)
        for t in (2,3):self.assertIsNone(self.see(t,full=True,attempt=(1200,2)))
    def test_second_result_gets_its_own_single_token(self):
        self.see();self.p.consume(self.see(1,panel=False,used=1,valid=True))
        self.see(2,attempt=(1200,2));self.assertEqual(self.see(3,panel=False,used=2,valid=True,attempt=(1200,2)),('end',2))
    def test_last_attempt_does_not_click_again_on_full_track(self):
        self.see(attempt=(1300,3))
        for t in (1,2,3):self.assertIsNone(self.see(t,full=True,attempt=(1300,3)))
    def test_two_seconds_of_missing_partial_panel_can_grant_one_resume(self):
        self.see();self.assertIsNone(self.see(1,panel=False,resume=True))
        self.assertIsNone(self.see(2.9,panel=False,resume=True))
        token=self.see(3,panel=False,resume=True);self.assertEqual(token,('resume',1000,1))
        self.p.consume(token);self.assertIsNone(self.see(7,panel=False,resume=True))
    def test_missing_ui_alone_without_resume_authority_does_not_grant_input(self):
        self.see();self.see(1,panel=False)
        self.assertIsNone(self.see(5,panel=False))
    def test_new_resource_does_not_inherit_ui_permission(self):
        self.see();self.assertIsNone(self.see(1,panel=False,used=1,valid=True,key=((1,100),1000)))
    def test_proven_unsent_request_can_be_retried(self):
        self.see();token=self.see(1,panel=False,used=1,valid=True);self.p.consume(token)
        self.p.unsent(token);self.assertEqual(self.see(2,panel=False,used=1,valid=True),token)
    def test_unresponsive_completed_request_gets_only_one_separate_resume_token(self):
        self.see();self.p.consume(self.see(1,panel=False,used=1,valid=True,resume=True))
        token=self.see(3,panel=False,used=1,valid=True,resume=True)
        self.assertEqual(token,('resume',1000,1));self.p.consume(token)
        self.assertIsNone(self.see(7,panel=False,used=1,valid=True,resume=True))


class CycleEngine(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.e.cfg.update(collection_event_driven=True,native_cursor_chord=True,
            resource_click_interaction=True,repeat_owned_clicks=True,preserve_owned_resource=True,
            collection_cursor_hold=True,calibrate_during_collection=False)
        self.input.native_cursor=True;self.source=Source();self.e.network=self.source;self.f=self.source.state
        self.f.nodes[99].template=1500000;self.f.nodes[99].gather_time=1000;self.f.nodes[99].used=0
        self.f.started=1000;self.f.attempt_ordinal=1
        self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
        self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
        self.frame=np.full((1440,2560,3),(125,95,65),np.uint8)
        crop=cv2.imread(str(Path(ge.ROOT)/'testdata/selected_green_marker.png'))
        self.frame[529:660,1175:1400]=crop;self.base=self.frame.copy()
        self.panel=cv2.imread(str(Path(ge.ROOT)/'testdata/current_gather_panel.png'))
        self.partial();self.e.candidate=find_selected_resource_badge(self.frame,'Эфир');self.e.current_size=(2560,1440)
        self.clock=100.;self.wall=1100
        def wait(seconds,*args):self.clock+=seconds;return True
        for p in (patch.object(ge.time,'monotonic',side_effect=lambda:self.clock),
                  patch.object(ge.time,'time',side_effect=lambda:self.wall/1000),
                  patch.object(GamepadInput,'wait',side_effect=wait)):
            p.start();self.addCleanup(p.stop)

    def partial(self):self.frame=self.base.copy();self.frame[1014:1172,930:1630]=self.panel
    def absent(self):self.frame=self.base.copy()
    def full(self):
        self.partial();roi=self.frame[1087:1111,1034:1606];white=cv2.inRange(roi,(175,175,175),(255,255,255))>0
        roi[~white]=(245,210,75)
    def ended(self,used=1):
        self.f.nodes[99].used=used;self.f.attempt_active=False
        self.f.last_own_result=(99,self.wall);self.f.last_own_result_used=used
    def new_attempt(self,ordinal):
        self.wall+=100;self.f.started=self.wall;self.f.nodes[99].gather_time=self.wall
        self.f.attempt_ordinal=ordinal;self.f.attempt_active=True;self.f.selected=99;self.partial()

    def test_actual_current_panel_is_detected_as_partial_and_full(self):
        self.assertTrue(gathering_panel_pair(self.frame));self.assertFalse(gather_result_full(self.frame))
        self.full();self.assertTrue(gathering_panel_pair(self.frame));self.assertTrue(gather_result_full(self.frame))
    def test_complete_live_attempt_has_no_a_alt_or_native_cursor_activity(self):
        for _ in range(26):self.e.f_enable();self.clock+=1
        self.assertEqual(self.pad.presses,0);self.assertEqual(self.commands,[])
        self.assertFalse(self.input.cursor_held);self.assertEqual(self.pad.axes,(0,0,0,0))
        self.assertTrue(any('COLLECTION_UI:' in s and 'lower=partial' in s for s in self.log))
    def test_zero_selected_during_real_partial_panel_is_not_an_end(self):
        self.f.selected=0
        for _ in range(8):self.e.f_enable();self.clock+=1
        self.assertEqual(self.pad.presses,0);self.assertEqual(self.commands,[])
    def test_first_own_end_grants_one_a_and_duplicate_result_does_not_interrupt_next_attempt(self):
        self.e.f_enable();self.ended();self.absent();self.e.f_enable()
        self.assertEqual(self.pad.presses,1);self.assertFalse(self.input.cursor_held)
        self.new_attempt(2)
        for _ in range(8):self.clock+=1;self.f.last_own_result=(99,self.wall+1);self.e.f_enable()
        self.assertEqual(self.pad.presses,1)
    def test_three_attempts_need_only_two_continuation_clicks(self):
        self.e.f_enable()
        for used in (1,2):
            self.wall+=100;self.ended(used);self.absent();self.clock+=1;self.e.f_enable()
            self.new_attempt(used+1)
            for _ in range(5):self.clock+=1;self.e.f_enable()
        self.assertEqual(self.pad.presses,2)
        self.ended(3);self.absent();self.e.f_enable();self.assertEqual(self.pad.presses,2)
        self.assertFalse({'F_ON','TAP_F','V','END_AIR','TAB'}&set(self.commands))
    def test_real_partial_panel_overrides_early_network_completion(self):
        self.e.f_enable();self.ended()
        for _ in range(4):self.e.f_enable();self.clock+=1
        self.assertEqual(self.pad.presses,0)
    def test_foreign_counter_change_is_not_own_result(self):
        self.e.f_enable();self.f.nodes[99].used=1;self.absent()
        for _ in range(5):self.e.f_enable();self.clock+=1
        self.assertEqual(self.pad.presses,0)
    def test_full_track_can_continue_with_stale_active_and_missing_result_packet(self):
        self.e.f_enable();self.full();self.e.f_enable();self.clock+=.3;self.e.f_enable()
        self.assertEqual(self.pad.presses,1);self.assertTrue(self.f.attempt_active)
        self.clock+=2;self.e.f_enable();self.assertEqual(self.pad.presses,1)
    def test_camera_recovery_cannot_move_during_actual_partial_panel(self):
        self.e._arm_view_recovery(self.clock);self.e.view_recovery.next_at=self.clock-1
        with patch.object(self.input,'drive',wraps=self.input.drive) as drive:
            self.assertFalse(self.e._view_recovery_tick(self.frame,None,self.clock))
        drive.assert_not_called();self.assertIsNone(self.e.view_recovery)
    def test_new_panel_during_cursor_prepare_cancels_request_without_stopping(self):
        self.e.f_enable();self.ended();self.absent()
        def wait(seconds,*args):
            self.clock+=seconds
            if seconds==.14:self.partial()
            return True
        with patch.object(GamepadInput,'wait',side_effect=wait):self.e.f_enable()
        self.assertEqual(self.pad.presses,0);self.assertFalse(self.e.stop_event.is_set())
    def test_direct_periodic_repeat_cannot_bypass_cycle_authorization(self):
        self.assertFalse(self.e._repeat_owned_click());self.assertEqual(self.pad.presses,0)
    def test_missing_interrupted_ui_gets_one_resume_not_an_unbounded_repeat(self):
        self.e.f_enable();self.f.selected=0;self.absent();self.e.f_enable()
        self.clock+=2.1;self.e.f_enable();self.assertEqual(self.pad.presses,1)
        for _ in range(5):self.clock+=1;self.e.f_enable()
        self.assertEqual(self.pad.presses,1)
    def test_zero_selection_after_unresponsive_end_click_gets_one_recovery_only(self):
        self.e.f_enable();self.ended();self.f.selected=0;self.absent();self.e.f_enable()
        self.assertEqual(self.pad.presses,1)
        self.clock+=2.1;self.e.f_enable();self.assertEqual(self.pad.presses,2)
        for _ in range(4):self.clock+=1;self.e.f_enable()
        self.assertEqual(self.pad.presses,2)
    def test_defense_reacquisition_revokes_old_real_panel_permission(self):
        self.e.f_enable();self.e._begin_reacquire('defense');self.e.target_confirmed=True;self.e.mode='GATHER'
        self.e.real_gather_panel_seen=True;self.ended();self.absent();self.e.f_enable()
        self.assertEqual(self.pad.presses,0)
    def test_defaults_are_event_driven_and_940ms_in_app_and_file(self):
        import json
        self.assertTrue(DEFAULT['collection_event_driven']);self.assertEqual(DEFAULT['camera_working_view_ms'],940)
        cfg=json.loads((Path(ge.ROOT)/'settings_gather.json').read_text())
        self.assertTrue(cfg['collection_event_driven']);self.assertEqual(cfg['camera_working_view_ms'],940)
    def test_almost_full_track_cannot_trigger_the_visual_fallback(self):
        self.e.f_enable();roi=self.frame[1087:1111,1034:1588]
        white=cv2.inRange(roi,(175,175,175),(255,255,255))>0;roi[~white]=(245,210,75)
        self.assertTrue(gather_result_full(self.frame));self.assertFalse(gather_result_full(self.frame,strict=True))
        for _ in range(5):self.clock+=1;self.e.f_enable()
        self.assertEqual(self.pad.presses,0)
    def test_new_partial_panel_at_final_send_boundary_cancels_without_a_or_stop(self):
        self.e.f_enable();self.ended();self.absent();self.e.cfg['debug_screenshots']=True
        def write(*args,**kwargs):self.partial();return True
        with TemporaryDirectory() as folder,patch.object(ge,'ROOT',Path(folder)),patch.object(cv2,'imwrite',side_effect=write):
            self.e.f_enable()
        self.assertEqual(self.pad.presses,0);self.assertFalse(self.e.stop_event.is_set())
        self.assertFalse(self.input.cursor_held);self.assertNotIn(('end',1),self.e.collection_cycle.consumed)
        self.assertTrue(any('COLLECTION_CANCEL:' in s for s in self.log))
    def test_reentrant_tick_during_delivery_cannot_duplicate_the_completed_token(self):
        self.e.f_enable();self.ended();self.absent()
        with patch.object(self.input,'tap_a',side_effect=lambda *a,**k:self.e.f_enable() or True) as tap:
            self.e.f_enable()
        self.assertEqual(tap.call_count,1);self.assertIn(('end',1),self.e.collection_cycle.consumed)


class OwnResultUsed(unittest.TestCase):
    def test_foreign_result_does_not_overwrite_last_own_result_counter(self):
        t=Telemetry({1500000})
        t.feed(1,'008d',gauge(),0);t.feed(1,'3436',profile(kind=1500000),900)
        t.feed(1,'3438',bytes(3)+v(99),950);t.feed(1,'3836',v(99)+v(7)+b'\1',990)
        t.feed(1,'318d',bytes(2)+v(99)+struct.pack('<I',1)+bytes(25),1000)
        t.feed(1,'3a36',v(99)+v(7)+struct.pack('<II',1,0),1100)
        t.feed(1,'3a36',v(99)+v(8)+struct.pack('<II',2,0),1200)
        self.assertEqual(t.flows[1].nodes[99].used,2)
        self.assertEqual(t.flows[1].last_own_result_used,1);self.assertEqual(t.flows[1].last_own_result,(99,1100))


if __name__=='__main__':unittest.main()
