"""One continuation per completed attempt, using rendered UI and own results."""
class CollectionCycle:
    def __init__(self):self.reset()

    def reset(self):
        self.binding=None;self.attempt=None;self.panel_seen=False;self.partial_seen=False
        self.full_since=None;self.absent_since=None;self.consumed=set()

    def observe(self,binding,attempt,now,panel,full,result_used=None,result_valid=False,resume_allowed=False):
        if binding!=self.binding:
            self.reset();self.binding=binding
        if attempt!=self.attempt:
            self.attempt=attempt;self.partial_seen=False;self.full_since=None;self.absent_since=None
        if panel:
            self.panel_seen=True;self.absent_since=None
            if not full:
                self.partial_seen=True;self.full_since=None
                return None
            if self.partial_seen and self.full_since is None:self.full_since=now
        else:
            self.full_since=None
            if self.partial_seen and self.absent_since is None:self.absent_since=now
        if not self.panel_seen:return None
        token=None
        if result_valid and result_used in (1,2):token=('end',result_used)
        elif (panel and full and self.partial_seen and self.full_since is not None
              and now-self.full_since>=.25 and attempt[1] in (1,2)):
            token=('end',attempt[1])
        if (token is None or token in self.consumed) and (resume_allowed and not panel
            and self.partial_seen and self.absent_since is not None and now-self.absent_since>=2):
            token=('resume',*attempt)
        return token if token is not None and token not in self.consumed else None

    def consume(self,token):
        if token is None or token in self.consumed:return False
        self.consumed.add(token);return True

    def unsent(self,token):self.consumed.discard(token)
