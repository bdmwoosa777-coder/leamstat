"""User-selected view, measured DOWN from the upper pitch limit in manual tests.

Runtime first applies a bounded upward hold; this assumes the limit is reached.
No absolute angle or limit detector is claimed.
"""
WORKING_VIEW_PRESETS=tuple(range(650,801,10))
DEFAULT_WORKING_VIEW_MS=700


def working_view_ms(cfg):
    value=cfg.get('camera_working_view_ms',DEFAULT_WORKING_VIEW_MS)
    try:
        number=float(value)
        if number in WORKING_VIEW_PRESETS:return int(number)
    except (ValueError,TypeError):pass
    return DEFAULT_WORKING_VIEW_MS
