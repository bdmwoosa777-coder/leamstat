"""Track actual delivered pitch pulses and retain residuals until returned."""
import threading
from camera_control import pitch_pulse


class PitchLedger:
    def __init__(self):
        self.lock=threading.RLock()
        self.balance=0.0;self.command=0.0;self.at=None;self.deadline=0
        self.returning=False;self.return_end=0;self.measured=False;self.failed=False

    def _integrate(self,now):
        if self.at is not None:
            end=now if self.measured else min(now,self.deadline)
            self.balance+=self.command*max(0,end-self.at)
        self.at=now

    def apply(self,pitch,now,lifetime=.45):
        with self.lock:
            self._integrate(now);self.command=float(pitch);self.deadline=now+lifetime

    def report(self,pitch,now,lifetime=0):
        # Called on actual report/reset delivery by the gamepad watchdog too.
        with self.lock:
            self._integrate(now);self.measured=True
            self.command=float(pitch);self.deadline=now+lifetime

    def neutral(self,now):self.apply(0,now)

    def restore(self,now):
        with self.lock:
            self.neutral(now);self.failed=False;self.returning=abs(self.balance)>.006
            self.return_end=now+max(3,min(8,abs(self.balance)/.08+1))

    def correction(self,now):
        with self.lock:
            self._integrate(now)
            if not self.returning:return None
            if abs(self.balance)<.006:
                self.balance=0;self.returning=False;return 0.0
            if now>=self.return_end:
                # The old implementation erased this residual and allowed
                # walking with the camera still raised. Preserve it and stop.
                self.returning=False;self.failed=True;return 0.0
            return pitch_pulse(-self.balance)[0]

    def correction_lifetime(self):
        with self.lock:return pitch_pulse(-self.balance)[1]

    def offset(self,now):
        with self.lock:self._integrate(now);return self.balance

    def accept_visible_ground(self,now):
        # Only after the scene check has confirmed ground in the viewing field.
        self.set_working_baseline(now)

    def set_working_baseline(self,now):
        # A completed down-pulse after the bounded upward homing hold
        # establishes a new zero for subsequent relative searches.
        with self.lock:
            self.neutral(now);self.balance=0;self.returning=False;self.failed=False
