"""Fast navigation loop with independent OCR, heartbeat and dialog watchers."""
from pathlib import Path
from dataclasses import replace
import threading
import time
import traceback
import math
import cv2
from bridge import GHubBridge
from gamepad_input import GamepadInput
from screen_capture import ScreenCapture
from minimap import MinimapVision
from navigation import Navigator,Drive
from camera_pitch import PitchLedger
from camera_control import PITCH_STRENGTH
from camera_working_view import working_view_ms
from flight_probe import FlightProbe
from health import HealthMonitor,read_hp
from view_guard import ViewGuard
from map_reference import MapReference
from defense import ThreatDetector,GatherInterrupts
from flight import read_flight,FlightBudget
from vision import (WorldVision,find_world_resource,selected_target,segment_count,
                    gathering_panel,gather_result_full,resource_header_visible,Observation)
from captcha_watchdog import CenterDialogDetector,AudioAlarm
from death_watchdog import DeathDialogDetector,DeathAudioAlarm

ROOT=Path(__file__).resolve().parent


class GatherEngine:
    def __init__(self,cfg,emit,gamepad=None):
        self.cfg,self.emit=cfg,emit
        self.stop_event=threading.Event();self.screen=ScreenCapture()
        self.bridge=GHubBridge(dry_run=cfg.get('dry_run',False),logger=emit)
        self.gamepad=gamepad
        self.vision=WorldVision(tuple(cfg['target_names']))
        self.minimap=MinimapVision(cfg);self.nav=Navigator(cfg)
        self.pitch=PitchLedger()
        self.pitch_observed=isinstance(gamepad,GamepadInput)
        if self.pitch_observed:gamepad.motion_listener=self.pitch.report
        self.health=HealthMonitor();self.hp_handled_event=0;self.hp_next_defense=0
        self.probe=None;self.pending_probe=None
        self.view_guard=ViewGuard()
        self.camera_scheduler_active=False;self.camera_last_calibrated=None
        self.camera_alignment_due=None;self.camera_requested_at=0
        self.calibration_resource_ended=False
        self.fast_header_seen=False;self.fast_last_slots=None;self.fast_gather_seen=False
        self.fast_absent_since=None;self.last_flight_seen_at=None;self.last_flight_energy=None
        self.wing_close_pending=None;self.wing_close_retries=0;self.wing_absent_since=None
        self.arrival_camera_corrected=False
        self.f_repeat_allowed=False;self.route_active=False;self.last_path_motion=None
        self.calibration_defense_interrupted=False
        self.region=MapReference(cfg);self.map_active=False
        self.threat=ThreatDetector(cfg);self.interrupts=GatherInterrupts()
        self.collecting_visible=False;self.resource_hold=False;self.panel_cleared=False
        self.defense_cycles=0;self.next_defense=0;self.post_gather_until=0
        self.last_hold_note=0
        self.budget=FlightBudget(cfg.get('flight_low_percent',8),cfg.get('flight_resume_percent',18),
                                 retry_delay=cfg.get('flight_retry_delay',3))
        self.cap=CenterDialogDetector(template_dir=ROOT);self.death=DeathDialogDetector(template_dir=ROOT)
        self.cap_alarm=AudioAlarm(logger=emit);self.death_alarm=DeathAudioAlarm(logger=emit)
        self.cap_alarm.device_match=self.death_alarm.device_match=cfg.get('audio_device','AG271QG4')
        self.mode='SEARCH';self.started=time.monotonic();self.target=None;self.target_confirmed=False
        self.f_on=False;self.folded=False;self.flight_attempted=False;self.jump_attempted=False;self.reselected=False
        self.last_distance=None;self.last_progress=self.started;self.missing_since=None
        self.last_segments=None;self.one_segment_armed=False;self.node_count=0
        self.candidate=None;self.candidate_since=None;self.candidate_sequence=None
        self.cooldowns=[];self.last_note=0;self.last_energy_note=0
        self.snapshot_lock=threading.Lock();self.snapshot=None;self.sequence=0
        self.observation_captured_at=0
        self.identity_valid_after=0
        self.safety_threads=[];self.release_thread=None;self.release_lock=threading.Lock()
        self.alert=None;self.alert_lock=threading.Lock();self.current_size=None
        self.screenshot_path=ROOT/'debug_gather'
        if cfg.get('debug_screenshots'):self.screenshot_path.mkdir(exist_ok=True)

    def say(self,text):self.emit('['+self.mode+'] '+text)

    def change_mode(self,mode):self.mode=mode;self.started=time.monotonic()

    def bridge_cmd(self,command):
        release=command in ('STOP','F_OFF','ALT_UP')
        if not release and (self.stop_event.is_set() or not self.screen.focused()):return False
        self.bridge.send(command);return True

    def f_enable(self):
        # F toggles the game's autopath. Repetition is permitted only after
        # the current resource's actual lower gathering panel has appeared.
        if not self.f_repeat_allowed:return False
        if not self.f_on and self.bridge_cmd('F_ON'):
            self.f_on=True;self.say('F включено: Lua-таймер 1000 мс')
        return self.f_on

    def f_disable(self):
        if self.f_on:self.bridge_cmd('F_OFF');self.f_on=False

    def save_debug(self,frame,label):
        if self.cfg.get('debug_screenshots'):
            self.screenshot_path.mkdir(exist_ok=True)
            # Preserve full resolution: the old 1280 resize damaged short Ether text.
            cv2.imwrite(str(self.screenshot_path/(time.strftime('%H%M%S')+'_'+label+'.jpg')),frame,[cv2.IMWRITE_JPEG_QUALITY,94])

    def _release_inputs(self):
        try:self.bridge.send('STOP');self.bridge.restore_locks()
        except Exception as exc:self.emit('Ошибка освобождения Lua: '+str(exc))

    def stop(self):
        self.stop_event.set()
        if self.gamepad:self.gamepad.reset()
        with self.release_lock:
            if self.release_thread is None:
                self.release_thread=threading.Thread(target=self._release_inputs,daemon=True)
                self.release_thread.start()

    def silence(self):self.cap_alarm.stop();self.death_alarm.stop()

    def trigger_alarm(self,kind,frame):
        with self.alert_lock:
            if self.alert is not None or self.stop_event.is_set():return
            self.alert=kind
        self.stop();self.save_debug(frame,kind.lower())
        self.say('ТРЕВОГА '+kind+' — остановлено, требуется ручное продолжение')
        alarm=self.cap_alarm if kind=='CAPTCHA' else self.death_alarm
        try:alarm.start(self.cfg.get('audio_device','AG271QG4'),error_cb=self.emit)
        except Exception as exc:self.emit('Ошибка звука: '+str(exc))

    def _dialog_loop(self,kind,detector,interval):
        hits=0
        while not self.stop_event.is_set():
            if self.screen.focused():
                try:
                    frame,_=self.screen.frame();present,_=detector.check(frame)
                    hits=hits+1 if present else 0
                    if hits>=2:self.trigger_alarm(kind,frame);return
                except Exception as exc:self.emit(kind+' / проверка: '+str(exc));hits=0
            else:hits=0
            if self.stop_event.wait(interval):return

    def _heartbeat_loop(self):
        while not self.stop_event.is_set():
            try:
                if self._focus_ok():self.bridge.ping_if_idle()
            except Exception as exc:self.emit('Ошибка heartbeat: '+str(exc));self.stop();return
            if self.stop_event.wait(2):return

    def _vision_loop(self):
        failures=0
        while not self.stop_event.is_set():
            if self.map_active:
                if self.stop_event.wait(.1):return
                continue
            if not self.screen.focused():
                if self.stop_event.wait(.15):return
                continue
            try:
                captured=time.monotonic();frame,_=self.screen.frame()
                obs=self.vision.scan(frame,candidates=self.mode!='GATHER')
                if obs.candidate and obs.candidate.name=='Эфир' and not self.budget.can_start() and self.mode in ('SEARCH','ACQUIRE_WAIT'):
                    names=tuple(n for n in self.cfg['target_names'] if n!='Эфир')
                    obs.candidate=find_world_resource(frame,names)
                with self.snapshot_lock:
                    self.sequence+=1;self.snapshot=(obs,captured,self.sequence,time.monotonic())
                failures=0
            except Exception as exc:
                failures+=1;self.emit('OCR / ошибка: '+str(exc))
                if failures>=3:self.stop();return
            if self.stop_event.wait(.08):return

    def _health_fast_loop(self):
        while not self.stop_event.is_set():
            if self.cfg.get('protect_player',True) and self.screen.focused() and not self.map_active:
                try:
                    frame,_=self.screen.frame();self.health.fast(frame,time.monotonic())
                except Exception:pass
            if self.stop_event.wait(max(.02,min(.05,self.cfg.get('hp_fast_seconds',.05)))):return

    def _health_numeric_loop(self):
        last_error=0
        while not self.stop_event.is_set():
            if self.cfg.get('protect_player',True) and self.screen.focused() and not self.map_active:
                try:
                    frame,_=self.screen.frame();value=read_hp(frame,self.cfg.get('hp_roi'))
                    self.health.numeric(frame,value,time.monotonic())
                except Exception as exc:
                    if time.monotonic()-last_error>10:self.say('HP OCR: '+str(exc));last_error=time.monotonic()
            if self.stop_event.wait(max(.10,min(.20,self.cfg.get('hp_ocr_seconds',.20)))):return

    def _focus_ok(self):return not self.stop_event.is_set() and self.screen.focused()

    def _reset_resource_watch(self,verified_header=False):
        self.fast_header_seen=verified_header;self.fast_last_slots=None;self.fast_gather_seen=False
        self.fast_absent_since=None;self.last_flight_seen_at=None;self.last_flight_energy=None
        self.arrival_camera_corrected=False
        self.f_repeat_allowed=False;self.route_active=False;self.last_path_motion=None

    def _start_resource_route(self):
        if not self.target_confirmed or self.route_active or not self._focus_ok():return False
        self.f_disable()
        self.f_repeat_allowed=False;self.fast_gather_seen=False
        if not self.bridge_cmd('TAP_F'):return False
        self.route_active=True
        self.say('Один F: штатный путь запущен; повтор ждёт нижнюю шкалу сбора')
        return True

    def _check_route_damage(self,frame,now,panel=None,slots=None):
        resource=self.target_confirmed and self.target in self.cfg['target_names']
        roaming=(self.mode in ('SEARCH','ACQUIRE_WAIT') and self.cfg.get('ground_walk',True)
                 and self.probe is None and self.wing_close_pending is None)
        if (not self.cfg.get('protect_player',True) or not (resource or roaming)
            or self.mode not in ('SEARCH','ACQUIRE_WAIT','APPROACH','TAKEOFF','JUMP_RETRY','GATHER')
            or now<self.hp_next_defense or self.defense_cycles>=self.cfg.get('defense_max_cycles',6)
            or not self.health.pending(self.hp_handled_event,now)):return False
        if panel is None:panel=gathering_panel(frame)
        if slots is None:slots=segment_count(frame)
        remaining=resource and (self.mode!='GATHER' or panel or slots is not None or resource_header_visible(frame))
        state=self.health.state()
        self.say(f'HP изменилось во время {self.mode}: {state["current"]}/{state["maximum"]}; Tab и проверка агрессора')
        self._defend_and_resume(resume=remaining)
        return True

    def _service_wing_close(self,reading,now):
        if self.wing_close_pending is None:return False
        self._neutral()
        if not reading.confirmed:
            if self.wing_absent_since is None:self.wing_absent_since=now
            if now-self.wing_absent_since>=.2:
                self.wing_close_pending=None;self.say('Закрытие крыльев подтверждено отсутствием дуги');return False
            return True
        self.wing_absent_since=None
        elapsed=now-self.wing_close_pending
        if elapsed>=1.5 and self.wing_close_retries==0:
            # Retry only on a NEW still-visible flight arc, never blindly V.
            if self.bridge_cmd('END_AIR'):
                self.f_on=False;self.wing_close_retries=1;self.wing_close_pending=time.monotonic()
                self.say('Дуга всё ещё видна: один повтор закрытия крыльев')
        elif elapsed>=2.5 and self.wing_close_retries:
            self.say('Крылья всё ещё открыты после двух команд: остановка ввода вместо зависания');self.stop()
        return True

    def _resource_fast_tick(self,frame,reading,now,panel=None,slots=None):
        """Live resource UI must run even when OCR is slow or camera is moving."""
        if self._service_wing_close(reading,now):return True
        if (not self.target_confirmed or self.target not in self.cfg['target_names']
            or self.mode not in ('APPROACH','TAKEOFF','JUMP_RETRY','GATHER')):return False
        if panel is None:panel=gathering_panel(frame)
        if slots is None:slots=segment_count(frame)
        self.collecting_visible=panel
        if reading.confirmed:
            self.last_flight_seen_at=now;self.last_flight_energy=reading.energy
            self.flight_attempted=True
        header=slots is not None or resource_header_visible(frame)
        if header:self.fast_header_seen=True
        if slots is not None:
            if self.fast_last_slots is not None and slots<self.fast_last_slots:self.fast_gather_seen=True
            self.fast_last_slots=slots
        valid_panel=panel and (self.panel_cleared or self.mode=='GATHER' or self.fast_gather_seen)
        if not panel:self.panel_cleared=True
        if valid_panel:
            self.fast_gather_seen=True;self.f_repeat_allowed=True;self.route_active=False
            self.f_enable()
        self.interrupts.update(valid_panel,slots,now,gather_result_full(frame) if valid_panel else None)
        if valid_panel or self.fast_gather_seen:
            if self.mode!='GATHER':
                self.change_mode('GATHER');self.missing_since=None
                self.say('Свежий кадр подтверждает сбор независимо от OCR дистанции')
        if panel or header:
            self.fast_absent_since=None;return False
        if not (self.fast_header_seen or self.fast_gather_seen or self.mode=='GATHER'):return False
        if self.fast_absent_since is None:self.fast_absent_since=now
        if now-self.fast_absent_since>=self.cfg.get('target_missing_seconds',.6):
            self.return_to_search('Свежий кадр: плашка/полоски и окно сбора исчезли',
                                  exhausted=True,reading=reading,frame_time=now)
            return True
        return False

    def _check_world_map(self):
        self._neutral();self.f_disable();self.map_active=True
        try:
            frame,_=self.screen.frame();fix=self.region.locate(frame)
            if fix is None:
                if not self.bridge_cmd('MAP'):return
                if not GamepadInput.wait(.65,self.stop_event,self.screen.focused):return
                frame,_=self.screen.frame();fix=self.region.locate(frame)
            if fix is None:
                self.say('Карта/стрелка не подтверждена: остановка. Проверьте M, новый Lua v0.5 и эталон зоны; закройте карту вручную.')
                self.stop();return
            if not self.bridge_cmd('MAP'):return
            if not GamepadInput.wait(.55,self.stop_event,self.screen.focused):return
            frame,_=self.screen.frame()
            if self.region.matcher.register(frame) is not None:
                self.say('Большая карта осталась открытой: остановка ввода, закройте M вручную.')
                self.stop();return
            distance=((fix.goal[0]-fix.position[0])**2+(fix.goal[1]-fix.position[1])**2)**.5
            interval=min(4 if fix.outside else self.cfg.get('world_map_check_seconds',12),max(1.5,distance/30))
            self.region.next_check=time.monotonic()+interval
            bearing=fix.bearing if self.region.spec.get('north_up',True) else None
            self.nav.route(bearing,'возврат в зону по карте' if fix.outside else 'точка маршрута по карте',fix.outside or bearing is None)
            self.say(f'Карта: положение ({fix.position[0]:.0f},{fix.position[1]:.0f}), персонаж {fix.character_heading:.0f}°, '+
                     ('снаружи, возвращаюсь в зону' if fix.outside else 'внутри зоны, продолжаю маршрут'))
            self.minimap.previous=None;self.minimap.previous_points=None
            self.identity_valid_after=time.monotonic()
            with self.snapshot_lock:self.snapshot=None
        finally:
            self.map_active=False;self.nav.pause(time.monotonic())

    def _motion(self,plan):
        if self.cfg.get('dry_run'):return
        if self.gamepad and self._focus_ok():
            if self.collecting_visible or (self.resource_hold and self.mode=='GATHER'):
                if any(abs(v)>.01 for v in (plan.forward,plan.strafe,plan.yaw,plan.pitch)) and time.monotonic()-self.last_hold_note>2:
                    self.say('Блокировка: окно/режим сбора запрещает команды стиков');self.last_hold_note=time.monotonic()
                self._neutral();return
            if self.resource_hold:
                plan=replace(plan,forward=0,strafe=0,yaw=0)
            if (not plan.tilted_motion and math.hypot(plan.forward,plan.strafe)>.01
                and abs(self.pitch.offset(time.monotonic()))>.009):
                self._neutral();self._restore_pitch();return
            self.gamepad.drive(plan.forward,plan.strafe,plan.yaw,plan.pitch,lifetime=plan.lifetime)
            if not self.pitch_observed:self.pitch.apply(plan.pitch,time.monotonic(),plan.lifetime)

    def _neutral(self):
        if self.gamepad:self.gamepad.reset()
        self.pitch.neutral(time.monotonic())

    def _restore_pitch(self):
        self.nav.air_since=None;self.nav.scan_kind=None
        self.pitch.restore(time.monotonic())

    def _request_probe(self,now):
        self._neutral()
        if (self.nav.goal is None or not self.cfg.get('flight_probe_enabled',True)
            or not self.cfg.get('ground_walk',True) or not self.cfg.get('camera_scan',True)
            or not self.budget.can_probe(self.cfg.get('flight_probe_min_percent',18))):
            self.nav.abandon_goal(now,60);self._restore_pitch();return
        self.pending_probe=self.nav.goal
        self._restore_pitch()

    def _probe_step(self,frame,origin,obs,radar,reading,now):
        probe=self.probe
        if probe is None:return
        if self.collecting_visible:
            self._neutral()
            if obs.target_name in self.cfg['target_names']:
                self.target=obs.target_name;self.target_confirmed=True;self.resource_hold=True
                self.f_repeat_allowed=True;self.route_active=False
                self.probe=None;self.change_mode('GATHER');self.f_enable();self._restore_pitch()
            else:
                if not hasattr(probe,'panel_since'):probe.panel_since=now
                if now-probe.panel_since>5:
                    self.say('Окно сбора видно, но имя не подтверждено: остановка без движения');self.stop()
            return
        if radar.motion_valid:
            probe.goal.x+=radar.displacement[0];probe.goal.y+=radar.displacement[1]
        matches=[m for m in radar.markers if m.kind==probe.goal.kind and math.hypot(m.x-probe.goal.x,m.y-probe.goal.y)<35]
        if matches:probe.goal=min(matches,key=lambda m:math.hypot(m.x-probe.goal.x,m.y-probe.goal.y))
        if (probe.phase not in ('CLOSE','WAIT_CLOSE') and obs.candidate
            and self._allowed(obs.candidate,now)):
            self._neutral()
            if self.click_candidate(obs.candidate,origin):
                self.probe=None;self.pending_probe=None;return
            self.target_confirmed=False;self.resource_hold=False;probe.phase_to('CLOSE',now)
            self.change_mode('PROBE')
        desired=math.degrees(math.atan2(probe.goal.x-radar.center[0],radar.center[1]-probe.goal.y))%360
        heading=self.nav._heading(radar,now)
        if math.hypot(probe.goal.x-radar.center[0],probe.goal.y-radar.center[1])<5:desired=heading if heading is not None else desired
        action=probe.step(now,reading,self.pitch.offset(time.monotonic()),heading,desired)
        if action.failed_takeoff:self.budget.failed_takeoff(now)
        if action.command:
            self._neutral();self.bridge_cmd(action.command)
            if action.command=='END_AIR':self.f_on=False
        elif action.drive:self._motion(action.drive)
        else:self._neutral()
        if action.stop:
            self.say(action.reason);self.stop();return
        if action.done:
            self.say(action.reason+'; закрытие/возврат наклона, затем отход')
            self.nav.goal=probe.goal;self.nav.abandon_goal(now,60)
            self.probe=None;self.pending_probe=None;self.target=None;self.target_confirmed=False;self.resource_hold=False
            self.change_mode('SEARCH');self._restore_pitch()
        elif action.reason and now-self.last_note>.7:
            self.say(action.reason);self.last_note=now

    def _allowed(self,candidate,now):
        if candidate.name not in self.cfg['target_names']:return False
        if self.cfg.get('only_aether') and candidate.name!='Эфир':return False
        if candidate.name=='Эфир' and not self.budget.can_start():
            if now-self.last_energy_note>4:
                self.say(self.budget.describe(now)+'; эфир отложен, ищу доступный наземный ресурс')
                self.last_energy_note=now
            return False
        self.cooldowns=[p for p in self.cooldowns if p[3]>now]
        return not any(n==candidate.name and abs(candidate.click_x-x)<80 and abs(candidate.click_y-y)<80 for n,x,y,until in self.cooldowns)

    def click_candidate(self,candidate,origin,refresh=True,retry=False):
        if self.cfg.get('dry_run'):
            self.say(f'НАБЛЮДЕНИЕ: {candidate.name}, точка ({candidate.click_x},{candidate.click_y})');return False
        if not self.gamepad:raise RuntimeError('Виртуальный Xbox не подключён')
        self._neutral();self.f_disable()
        if not self._focus_ok():return False
        if not retry:
            self.target=candidate.name;self.target_confirmed=False;self.folded=False
            self.flight_attempted=False;self.jump_attempted=False;self.reselected=False
            self.last_distance=None;self.last_segments=None;self.one_segment_armed=False
            self.interrupts.reset();self.panel_cleared=False
            self.defense_cycles=0
            self.health.begin_gather()
        self.change_mode('ACQUIRE')
        self.bridge_cmd('ALT_DOWN')
        selected=False
        try:
            if not GamepadInput.wait(.16,self.stop_event,self.screen.focused):return False
            frame=None
            if refresh:
                frame,origin=self.screen.frame()
                self.panel_cleared=not gathering_panel(frame)
                fresh=find_world_resource(frame,(candidate.name,))
                if fresh is None:
                    self.say('Свежая подпись после Alt не найдена; старые координаты не нажимаю');return False
                candidate=fresh
            h=self.current_size[1] if self.current_size else 1440
            offsets=(0,round(h*.010),-round(h*.008)) if candidate.name=='Эфир' else (0,round(h*.009))
            points=[(candidate.click_x,candidate.click_y)]
            bx,by,bw,bh=map(int,candidate.box)
            caption=(bx+bw//2,by+bh+max(18,round(h*(.035 if candidate.name=='Эфир' else .010))))
            if abs(caption[0]-candidate.click_x)+abs(caption[1]-candidate.click_y)>4:
                points.append(caption)
            points.extend((candidate.click_x,candidate.click_y+offset) for offset in offsets[1:])
            for px,py in points:
                if not self._focus_ok():return False
                x=origin[0]+int(px);y=origin[1]+int(py)
                self.bridge.cursor(x,y)
                if not GamepadInput.wait(.12,self.stop_event,self.screen.focused):return False
                if not self.gamepad.tap_a(self.stop_event,self.screen.focused):return False
                if not GamepadInput.wait(.20,self.stop_event,self.screen.focused):return False
                if refresh:
                    frame,_=self.screen.frame();name,_=selected_target(frame,tuple(self.cfg['target_names']))
                    if name is not None:
                        if name not in self.cfg['target_names']:
                            self.say('Верхняя плашка не подтверждает разрешённый ресурс');break
                        confirmed=replace(candidate,name=name)
                        if not self._allowed(confirmed,time.monotonic()):break
                        if name!=candidate.name:
                            self.say(f'Дальняя подпись: {candidate.name}; верхняя плашка уточнила: {name}')
                        candidate=confirmed;selected=True
                else:selected=True
                if selected:break
            if not selected:
                self.say('Имя ресурса в верхней плашке не подтверждено; F не отправляю')
                return False
        finally:self.bridge_cmd('ALT_UP')
        if not self._focus_ok():return False
        # F must come AFTER Lua releases Alt, so it cannot become Alt+F.
        self.target=candidate.name;self.candidate=candidate;self.target_confirmed=True;self.missing_since=None
        self.resource_hold=True
        self._reset_resource_watch(verified_header=True)
        if not self._start_resource_route():return False
        self.identity_valid_after=time.monotonic()
        self.last_progress=time.monotonic();self.change_mode('APPROACH')
        self.say(f'{candidate.name}: плашка подтверждена, Alt отпущен; один F до появления нижней шкалы')
        self._restore_pitch()
        return True

    def return_to_search(self,reason,frame=None,exhausted=False,reading=None,frame_time=None):
        if self.collecting_visible and not exhausted:
            self._neutral();self.change_mode('GATHER');self.f_enable()
            self.say('Окно сбора видно: возврат к патрулю и движение запрещены');return
        was_aether=self.target=='Эфир'
        stamp=time.monotonic() if frame_time is None else frame_time
        recent_air=(self.last_flight_seen_at is not None and stamp-self.last_flight_seen_at<=1.2
                    and (self.last_flight_energy is None or self.last_flight_energy>1))
        collected_air=was_aether and (self.mode=='GATHER' or self.fast_gather_seen)
        self._neutral()
        # A full result stripe is not depletion. Keep aether wings open until
        # the resource itself disappears; never toggle V from sky colours.
        ended_air=False
        known_air=(reading is not None and reading.confirmed) or recent_air or collected_air
        if known_air and self.target_confirmed and not self.folded and (exhausted or was_aether):
            if self.bridge_cmd('END_AIR'):
                self.folded=True;self.f_on=False;ended_air=True
                self.wing_close_pending=time.monotonic();self.wing_close_retries=0
                self.wing_absent_since=(self.wing_close_pending if reading is not None and not reading.confirmed else None)
        if not ended_air:self.f_disable()
        if not exhausted and self.mode in ('APPROACH','JUMP_RETRY','TAKEOFF'):
            self._cancel_autopath()
        self.say(reason)
        now=time.monotonic()
        if exhausted:self.node_count+=1
        if self.candidate:
            self.cooldowns.append((self.candidate.name,self.candidate.click_x,self.candidate.click_y,now+(12 if exhausted else 30)))
        if exhausted:self.nav.exclude_goal(now,30)
        else:self.nav.abandon_goal(now,60)
        if frame is not None and not exhausted:self.save_debug(frame,'failed')
        self.target=None;self.candidate=None;self.target_confirmed=False
        self.resource_hold=False;self.interrupts.reset()
        self._reset_resource_watch()
        if exhausted:self.post_gather_until=time.monotonic()+.8
        if exhausted and was_aether and self._automatic_camera_enabled():
            self.camera_alignment_due='после сбора эфира';self.camera_requested_at=time.monotonic()
        self.missing_since=None;self.change_mode('SEARCH')
        self._restore_pitch()

    def _cancel_autopath(self):
        # Neutral reports alone do not cancel a route already owned by the game.
        # A short manual movement requests cancellation before the next patrol.
        if self.collecting_visible or self.cfg.get('dry_run') or not self.gamepad or not self._focus_ok():return
        try:
            self.gamepad.drive(-.35,0,0,0,lifetime=.25)
            if GamepadInput.wait(.20,self.stop_event,self.screen.focused):self.route_active=False
        finally:self._neutral()

    def _confirmed_aggressor(self):
        first,_=self.screen.frame();a=self.threat.check(first)
        if not(a.matches and a.hp):return False
        if not GamepadInput.wait(.18,self.stop_event,self.screen.focused):return False
        second,_=self.screen.frame();b=self.threat.check(second)
        return b.matches and b.hp

    def _defend_and_resume(self,resume=True):
        if not self._focus_ok() or self.cfg.get('dry_run'):return
        resource=self.target;self.defense_cycles+=1
        self._neutral()
        if not resume and not self.folded:
            frame,_=self.screen.frame()
            if read_flight(frame).confirmed and self.bridge_cmd('END_AIR'):
                self.folded=True;self.f_on=False
        self.f_disable();self.route_active=False;self.change_mode('DEFENSE')
        self.say('Проверяю агрессора через Tab: смена цели останавливает путь к ресурсу')
        try:
            for index in range(self.cfg.get('defense_max_tabs',8)):
                if index>=3 and not self.health.ongoing(time.monotonic()):break
                if not self.bridge_cmd('TAB'):return
                if not GamepadInput.wait(.25,self.stop_event,self.screen.focused):return
                if not self._confirmed_aggressor():
                    if self.health.ongoing(time.monotonic()):self.say('Чужой/неподтверждённый таргет, HP ещё снижен: проверяю следующий Tab')
                    continue
                if not self.bridge_cmd('ATTACK_PAIR'):return
                self.say('Плашка Darkleam и HP моба подтверждены дважды: два нажатия ], жду духа')
                until=time.monotonic()+6;absent=None;defeated=False
                while self._focus_ok() and time.monotonic()<until:
                    frame,_=self.screen.frame();evidence=self.threat.check(frame)
                    if not evidence.matches and not evidence.hp:
                        if absent is None:absent=time.monotonic()
                        if time.monotonic()-absent>.6:defeated=True;break
                    else:absent=None
                    if not GamepadInput.wait(.25,self.stop_event,self.screen.focused):return
                if not defeated:
                    self.say('Исчезновение обеих боевых плашек не подтверждено: остановка перед возвратом к сбору')
                    self.stop();return
                break
            if not self._focus_ok():return
            if not resume:
                if resource not in self.cfg['target_names']:
                    self.target=None;self.target_confirmed=False;self.resource_hold=False
                    self.defense_cycles=0
                    self._reset_resource_watch();self.change_mode('SEARCH');self.nav.pause(time.monotonic())
                    self.say('Защита патруля закончена: продолжаю поиск ресурса');return
                frame,_=self.screen.frame();self.collecting_visible=False
                self.return_to_search('Последняя попытка ресурса уже потрачена: следующая цель',
                                      exhausted=True,reading=read_flight(frame))
                return
            self.say('Защита закончена; заново ищу сохранённый ресурс '+str(resource))
            self.target_confirmed=False;self.interrupts.reset()
            until=time.monotonic()+5
            while self._focus_ok() and time.monotonic()<until:
                frame,origin=self.screen.frame()
                candidate=find_world_resource(frame,(resource,))
                if candidate and self.click_candidate(candidate,origin,retry=True):
                    self.next_defense=time.monotonic()+8;return
                if not GamepadInput.wait(.20,self.stop_event,self.screen.focused):return
            if self._focus_ok():
                self.collecting_visible=False
                self.return_to_search('Ресурс после защиты не найден: следующая цель',frame)
        finally:
            self.next_defense=time.monotonic()+8
            self.hp_handled_event=self.health.state()['damage_sequence'];self.hp_next_defense=time.monotonic()+1

    def _recover(self,frame,origin,obs,reading,now):
        self._neutral();self.f_disable()
        # An intentional path retry first cancels the old route. A second F
        # against a still-active route would merely stop it.
        if self.route_active:self._cancel_autopath()
        if (reading.confirmed or self.target=='Эфир') and not self.reselected:
            if reading.confirmed:self.flight_attempted=True
            self.reselected=True
            if self._start_resource_route():
                self.last_distance=obs.distance_m;self.last_progress=now;self.change_mode('APPROACH')
                self.say('Повтор F по выбранному ресурсу; для эфира взлёт выполняет игра, лишнее V не отправляю')
                return
        if self.target!='Эфир' and not reading.confirmed and not self.flight_attempted and self.budget.can_start():
            self.flight_attempted=True
            if not self.bridge_cmd('V'):return
            self.change_mode('TAKEOFF')
            self.say('Упор в препятствие: V, проверка раскрытых крыльев, затем F по выбранному таргету')
            return
        if not self.jump_attempted and self.target!='Эфир' and not reading.confirmed and not self.flight_attempted:
            self.jump_attempted=True;self.bridge_cmd('JUMP')
            self.change_mode('JUMP_RETRY');self.say('Энергии для облёта мало: одна попытка перепрыгнуть препятствие')
            return
        if self.target=='Эфир' and not reading.confirmed and not self.flight_attempted:
            self.budget.failed_takeoff(now)
        self.return_to_search('Нет сближения с ресурсом: пропускаю и патрулирую дальше',frame,reading=reading)

    def step(self,frame,origin,obs,radar,reading,now,sequence=0):
        if self.stop_event.is_set():return
        self.current_size=(frame.shape[1],frame.shape[0])
        self.budget.update(reading,now)
        if not self.screen.focused():
            self._neutral();self.f_disable();self.nav.pause(now);return
        plate=segment_count(frame)
        panel=gathering_panel(frame)
        self.collecting_visible=panel
        if self._check_route_damage(frame,now,panel,plate):return
        if self._resource_fast_tick(frame,reading,now,panel,plate):return
        if panel and self.mode=='SEARCH' and self.target is None and self.probe is None:
            returning=self.cfg.get('world_map_enabled') and self.region.ready and self.region.returning
            if (self.cfg.get('assist_manual_target') and obs.target_name in self.cfg['target_names']
                and plate is not None and not self.nav.is_retreating(now) and not returning
                and (not self.cfg.get('only_aether') or obs.target_name=='Эфир')):
                self.target=obs.target_name;self.target_confirmed=True;self.resource_hold=True
                self.defense_cycles=0;self.interrupts.reset();self.missing_since=None
                self.folded=False;self.health.begin_gather();self.change_mode('GATHER')
                self.f_repeat_allowed=True;self.route_active=False
                self.say('Уже идёт сбор выбранного ресурса: принимаю управление независимо от старой дистанции OCR')
            else:
                self._neutral();return
        if not panel:self.panel_cleared=True
        if panel and self.target_confirmed and (self.panel_cleared or self.mode=='GATHER'):
            self._neutral()
            if self.mode!='GATHER':self.change_mode('GATHER');self.missing_since=None
            self.f_enable()
        if now<self.post_gather_until:
            self._neutral();return
        if (self.camera_scheduler_active and self._automatic_camera_enabled()
            and self.camera_alignment_due and self.mode=='SEARCH' and not panel
            and not self.resource_hold and self.probe is None):
            if reading.confirmed:
                self._neutral()
                if now-self.camera_requested_at>5:
                    self.say('Полёт ещё подтверждён после завершения ресурса: остановка перед калибровкой');self.stop()
                return
            if not self._calibrate_camera(self.camera_alignment_due):self.stop()
            return
        if self.pitch.failed:
            safe=(self.mode=='SEARCH' and not self.resource_hold and self.probe is None) or (self.mode=='GATHER' and panel)
            if self.camera_scheduler_active and self._automatic_camera_enabled() and safe:
                if not self._calibrate_camera('нет подтверждённого возврата наклона',allow_gather=panel):self.stop()
            else:
                self.say('Возврат наклона не подтверждён: остановка ввода');self.stop()
            return
        if self.probe is not None:
            self._probe_step(frame,origin,obs,radar,reading,now);return
        if self.pitch.returning and not panel and self.mode!='GATHER' and not self.resource_hold:
            correction=self.pitch.correction(time.monotonic())
            if correction:
                self._motion(Drive(pitch=correction,lifetime=self.pitch.correction_lifetime(),reason='возвращаю прежний наклон камеры той же силой стика'))
            else:
                self._neutral();self.nav.pause(now);self.last_progress=now
                self.identity_valid_after=time.monotonic()
                if self.pitch.failed:
                    self.say('Не удалось вернуть наклон камеры: остановка');self.stop()
            return
        if self.pending_probe is not None:
            goal=self.pending_probe;self.pending_probe=None
            if self.budget.can_probe(self.cfg.get('flight_probe_min_percent',18)):
                self.probe=FlightProbe(goal,now,self.cfg);self.change_mode('PROBE')
            else:self.nav.abandon_goal(now,60)
            self._neutral();return
        if (self.mode=='SEARCH' and not self.resource_hold and self.cfg.get('auto_view_recovery',True)
            and self.nav.air_since is None and (self.view_guard.active or abs(self.pitch.offset(time.monotonic()))<.009)):
            action,accepted,failed=self.view_guard.update(frame,now)
            if failed:
                recent=self.camera_last_calibrated is not None and now-self.camera_last_calibrated<10
                if self.camera_scheduler_active and self._automatic_camera_enabled() and not recent:
                    if not self._calibrate_camera('земля в поле зрения не найдена'):self.stop()
                else:
                    self.say('Земля не подтверждена после коррекции камеры: остановка ввода');self.stop()
                return
            if accepted:
                self._neutral();self.pitch.accept_visible_ground(time.monotonic());self.nav.pause(now)
                self.identity_valid_after=time.monotonic();return
            if action is not None:
                self._motion(action);return
        near=(obs.distance_m is not None and obs.distance_m<=3)
        # Being two metres from a node can still mean being behind a rock.
        # Near distance enables F, but does not disable obstacle recovery.
        gather_ready=obs.f_prompt or (panel and (obs.distance_m is None or near))
        if self.target_confirmed and self.mode in ('APPROACH','JUMP_RETRY','TAKEOFF') and plate is not None:
            if self.last_segments is not None and plate<self.last_segments:
                gather_ready=True
                self.say('Полосок ресурса стало меньше: сбор подтверждён независимо от окна/OCR')
            self.last_segments=plate
        if reading.confirmed and self.target_confirmed and self.mode in ('APPROACH','TAKEOFF','GATHER'):
            self.flight_attempted=True
        fresh_progress=(obs.target_name==self.target and obs.distance_m is not None
                        and (self.last_distance is None or obs.distance_m<self.last_distance-.3))
        if (self.target=='Эфир' and self.target_confirmed and not panel
            and self.mode in ('APPROACH','GATHER') and not fresh_progress
            and self.camera_scheduler_active and self._automatic_camera_enabled()
            and not self.arrival_camera_corrected
            and ((near or obs.f_prompt) and now-self.last_progress>=1.2
                 or reading.confirmed and now-self.last_progress>=2.0)):
            self.arrival_camera_corrected=True
            self.say('Подход к эфиру: F не повторяю; корректирую только наклон камеры')
            if not self._calibrate_camera('ожидание начала сбора эфира',allow_gather=True):self.stop()
            self.last_progress=time.monotonic();return
        if (self.camera_scheduler_active and self._automatic_camera_enabled()
            and self.cfg.get('camera_calibrate_during_gather',True)
            and self.mode=='GATHER' and panel and self.target_confirmed
            and now-self.started>.35
            and not self.health.pending(self.hp_handled_event,now)
            and (self.camera_alignment_due or self.pitch.returning or self.camera_last_calibrated is None
                 or now-self.camera_last_calibrated>=60)):
            if not self._calibrate_camera('во время сбора',allow_gather=True):self.stop()
            self.last_progress=time.monotonic();return
        if self.mode in ('SEARCH','ACQUIRE_WAIT'):
            returning=self.cfg.get('world_map_enabled') and self.region.ready and self.region.returning
            if (not returning and not self.nav.is_retreating(now)
                and self.cfg.get('assist_manual_target') and obs.target_name in self.cfg['target_names']
                and plate is not None
                and (not self.cfg.get('only_aether') or obs.target_name=='Эфир')
                and gather_ready):
                self.target=obs.target_name;self.target_confirmed=True;self.missing_since=None
                self.resource_hold=True
                self.defense_cycles=0;self.interrupts.reset()
                self.folded=False;self._neutral()
                if panel:
                    self.f_repeat_allowed=True;self.route_active=False
                    self.f_enable();self.change_mode('GATHER')
                else:
                    self._reset_resource_watch(verified_header=True)
                    self.route_active=True;self.change_mode('APPROACH')
                    self.say('Уже выбран ручной таргет: F не повторяю, наблюдаю текущий подход')
                return
            candidate=obs.candidate
            if (not returning and not self.nav.is_retreating(now) and candidate
                and self.cfg.get('allow_click',True) and self._allowed(candidate,now)):
                self._neutral();self.nav.pause(now)
                if self.mode=='SEARCH':
                    self.candidate=candidate;self.candidate_sequence=sequence
                    self.candidate_since=now;self.change_mode('ACQUIRE_WAIT')
                    self.say('Вижу '+candidate.name+'; остановил движение, уточняю координаты')
                elif sequence!=self.candidate_sequence and candidate.name==self.candidate.name:
                    if not self.click_candidate(candidate,origin):
                        self.return_to_search('Ресурс не выбран: поиск другой цели',frame,reading=reading)
                return
            if self.mode=='ACQUIRE_WAIT':
                if now-self.candidate_since<2.5:return
                self.candidate=None;self.change_mode('SEARCH')
            if not self.cfg.get('minimap_search',True):radar.markers=[]
            if self.cfg.get('world_map_enabled') and self.region.ready:
                bearing=self.region.terrain_bearing(frame,radar,now)
                if bearing is not None:
                    self.nav.route(bearing,'курс по сопоставлению рельефа миникарты',self.region.returning)
            plan=self.nav.update(radar,now,self.budget.can_start())
            if plan.flight_probe:
                self._request_probe(now);return
            if plan.restore_pitch:
                self._neutral();self._restore_pitch();return
            if not self.cfg.get('ground_walk',True):plan.forward=0;plan.strafe=0
            if not self.cfg.get('camera_scan',True):plan.yaw=0;plan.pitch=0
            self._motion(plan)
            if now-self.last_note>1.5:
                self.say(f'{plan.reason}; ресурсы на карте: {len(radar.markers)}, ход={plan.forward:.2f}, бок={plan.strafe:.2f}, камера={plan.yaw:.2f}, наклон={plan.pitch:.2f}')
                self.last_note=now
            return
        if self.mode in ('APPROACH','JUMP_RETRY','TAKEOFF'):
            if obs.target_name and obs.target_name!=self.target:
                self.return_to_search('В таргете другой ресурс',frame,reading=reading);return
            if obs.distance_m is not None and obs.target_name==self.target:
                # Track a new best distance, not alternating OCR values such
                # as 12/13/12/13 which otherwise reset the wall timer forever.
                if self.last_distance is None or obs.distance_m<self.last_distance-.3:
                    self.last_progress=now;self.last_distance=obs.distance_m
            if self.target_confirmed and panel and (self.panel_cleared or self.fast_gather_seen):
                self.f_repeat_allowed=True;self.route_active=False
                self._neutral();self.f_enable();self.missing_since=None;self.change_mode('GATHER')
                self.say('Сбор доступен; F работает независимо от OCR');return
            if self.mode=='TAKEOFF':
                if reading.confirmed:
                    if self._start_resource_route():
                        self.reselected=True;self.last_distance=obs.distance_m;self.last_progress=now;self.change_mode('APPROACH')
                        self.say('Крылья подтверждены: F запускает штатный автополёт к выбранному ресурсу')
                    return
                if now-self.started>3.5:
                    self.budget.failed_takeoff(now)
                    self.say(self.budget.describe(now))
                    self.return_to_search('Крылья не подтверждены дугой; повторно V не переключаю',frame,reading=reading)
                return
            if self.mode=='JUMP_RETRY':
                if now-self.started>1.5:
                    self._start_resource_route();self.last_distance=obs.distance_m;self.last_progress=now;self.change_mode('APPROACH')
                return
            if (near and self.f_on and self.cfg.get('protect_player',True) and radar.hostiles_near
                and not panel and (plate is not None or resource_header_visible(frame))
                and self.defense_cycles<self.cfg.get('defense_max_cycles',6) and now>=self.next_defense and now-self.last_progress>4):
                self._defend_and_resume();return
            if plate is None and obs.target_name is None:
                if self.missing_since is None:self.missing_since=now
                if now-self.missing_since>2:
                    self.return_to_search('Плашка выбранного ресурса исчезла до сбора',frame,reading=reading);return
            else:self.missing_since=None
            if radar.motion_valid and math.hypot(*radar.displacement)>.15:
                self.last_path_motion=now
            progress=max(self.last_progress,self.last_path_motion or self.last_progress)
            if now-progress>self.cfg.get('approach_stall_seconds',6):
                self._recover(frame,origin,obs,reading,now)
            elif now-self.started>max(60,self.cfg.get('approach_timeout',60)):
                self.return_to_search('Таймаут подхода',frame,reading=reading)
            return
        if self.mode=='GATHER':
            if obs.target_name is not None and obs.target_name!=self.target:
                self.return_to_search('Таргет сменился: выключаю F',frame,reading=reading);return
            if not self.f_on:self.f_enable()
            remaining=plate is not None or resource_header_visible(frame)
            if (self.cfg.get('protect_player',True) and not panel and self.defense_cycles<self.cfg.get('defense_max_cycles',6)
                and now>=self.next_defense and (self.interrupts.ready(radar.hostiles_near,now)
                    or (remaining and near and radar.hostiles_near and now-self.last_progress>4))):
                self._defend_and_resume(resume=remaining);return
            if plate is not None and plate!=self.last_segments:
                self.last_segments=plate;self.last_progress=now;self.say(f'Осталось попыток: {plate}/3')
            # Ground gathering may continue with folded wings. Aether stays in
            # flight until depletion, irrespective of its last result stripe.
            if reading.confirmed and not self.folded and self.target!='Эфир':
                if self.bridge_cmd('V'):
                    self.folded=True
                    self.say('Наземный сбор доступен: складываю крылья, F продолжает сбор')
            # Require BOTH the resource track and its target identity to disappear.
            header=plate is not None or resource_header_visible(frame)
            if not header:
                if self.missing_since is None:self.missing_since=now
                identity_absent=obs.target_name is None
                stale_identity=self.observation_captured_at<self.missing_since
                if not panel and (identity_absent or stale_identity) and now-self.missing_since>self.cfg.get('target_missing_seconds',.6):
                    self.return_to_search('Плашка и полоски исчезли: ресурс закончен',exhausted=True,reading=reading)
            else:self.missing_since=None
            if not panel and now-self.last_progress>self.cfg.get('gather_idle_seconds',6) and self.mode=='GATHER':
                self.change_mode('APPROACH')
                self.say('Сбор не возобновился после F: проверяю подход, вместо долгого ожидания')
                self._recover(frame,origin,obs,reading,now);return
            if now-self.started>self.cfg.get('gather_timeout',55):
                if panel:
                    self.say('Окно сбора не исчезло за отведённое время: остановка ввода без движения')
                    self.stop()
                else:self.return_to_search('Сбор не завершился за отведённое время',frame,reading=reading)

    def process(self,frame,origin,now):
        if self.stop_event.is_set():return
        obs=self.vision.scan(frame)
        self.observation_captured_at=now
        self.sequence+=1
        self.step(frame,origin,obs,self.minimap.observe(frame),read_flight(frame),now,self.sequence)

    def current_observation(self,obs,captured):
        if captured>=self.identity_valid_after:return obs
        # OCR started before A may finish later; it must not undo the new selection.
        return Observation(None,None,None,False,0,False,None,'HIDDEN')

    def _automatic_camera_enabled(self):
        return (not self.cfg.get('dry_run') and self.cfg.get('camera_scan',True)
                and self.cfg.get('camera_auto_calibrate',True) and self.gamepad is not None)

    def _camera_wait(self,seconds):
        """Camera-only motion cannot postpone depletion or wing closure."""
        until=time.monotonic()+seconds
        while self._focus_ok():
            if self.target_confirmed:
                frame,_=self.screen.frame();now=time.monotonic()
                if self._check_route_damage(frame,now):
                    self.calibration_defense_interrupted=True
                    self.camera_alignment_due='после защиты от моба'
                    self.camera_requested_at=time.monotonic();self._neutral();return False
                self._resource_fast_tick(frame,read_flight(frame),now)
                if not self.target_confirmed:
                    self.calibration_resource_ended=True
                    self.camera_alignment_due='ресурс закончился во время коррекции камеры'
                    self.camera_requested_at=time.monotonic();self._neutral();return False
            remaining=until-time.monotonic()
            if remaining<=0:return True
            if not GamepadInput.wait(min(.06,remaining),self.stop_event,self.screen.focused):return False
        return False

    def _hold_pitch_up(self,seconds):
        # Count actual delivered input, not a wall-clock pause while the
        # watchdog may already have released the stick. Overlapping leases
        # keep the upward command continuous during a responsive loop.
        if not self.pitch_observed:return False
        before=self.pitch.offset(time.monotonic());end=time.monotonic()+seconds+2
        try:
            while self._focus_ok() and time.monotonic()<end:
                delivered=(self.pitch.offset(time.monotonic())-before)/PITCH_STRENGTH
                remaining=seconds-delivered
                if remaining<=.005:return True
                self.gamepad.drive(0,0,0,PITCH_STRENGTH,lifetime=min(.15,remaining))
                if not self._camera_wait(min(.08,remaining)):return False
            return False
        finally:self._neutral()

    def _calibrate_camera(self,reason,allow_gather=False):
        if not self._automatic_camera_enabled():return True
        self.calibration_resource_ended=False
        self.calibration_defense_interrupted=False
        self._neutral()
        if not self._focus_ok():return False
        frame,_=self.screen.frame()
        if gathering_panel(frame) and not allow_gather:
            self.say('Калибровка отложена: окно сбора требует отдельного разрешения вертикального обзора')
            return False
        for kind,detector in (('CAPTCHA',self.cap),('DEATH',self.death)):
            if detector.check(frame)[0]:self.trigger_alarm(kind,frame);return False
        if not self._focus_ok():return False
        seconds=2.0
        milliseconds=working_view_ms(self.cfg)
        self.say(f'Калибровка камеры ({reason}): около {seconds:.0f} с вверх до предполагаемого упора, затем {milliseconds} мс вниз; только вертикальная ось')
        if not self._hold_pitch_up(seconds):
            if self.calibration_resource_ended or self.calibration_defense_interrupted:return True
            self.say('Подъём камеры прерван; частичная калибровка не принята');return False
        if not self._camera_wait(.10):return self.calibration_resource_ended or self.calibration_defense_interrupted
        before=self.pitch.offset(time.monotonic());completed=False
        try:
            self.gamepad.drive(0,0,0,-PITCH_STRENGTH,lifetime=milliseconds/1000)
            completed=self._camera_wait(milliseconds/1000)
        finally:self._neutral()
        if not completed or not self._focus_ok():
            if self.calibration_resource_ended or self.calibration_defense_interrupted:return True
            self.say('Опускание камеры прервано; частичная калибровка не принята');return False
        delivered=(before-self.pitch.offset(time.monotonic()))/PITCH_STRENGTH*1000
        self.say(f'Камера: вниз задано {milliseconds} мс; фактически передано около {delivered:.1f} мс')
        if not self.pitch_observed or abs(delivered-milliseconds)>25:
            self.say('Длительность импульса не подтверждена: калибровка не принята');return False
        self.pitch.set_working_baseline(time.monotonic())
        self.camera_last_calibrated=time.monotonic();self.camera_alignment_due=None
        self.identity_valid_after=self.camera_last_calibrated;self.nav.pause(self.identity_valid_after)
        self.nav.air_since=None;self.nav.scan_kind=None;self.view_guard=ViewGuard()
        with self.snapshot_lock:self.snapshot=None
        self.say('Рабочий наклон камеры восстановлен по временному ориентиру; угол непосредственно не измеряется')
        return True

    def _prepare_working_view(self):
        if not self._automatic_camera_enabled():return True
        if not self._focus_ok():return False
        frame,_=self.screen.frame();panel=gathering_panel(frame)
        if not panel:
            name,distance=selected_target(frame,tuple(self.cfg['target_names']))
            reading=read_flight(frame)
            if reading.confirmed or name in self.cfg['target_names']:
                self.camera_alignment_due='после текущего подхода/полёта'
                self.camera_requested_at=time.monotonic()
                if name in self.cfg['target_names'] and self.cfg.get('assist_manual_target'):
                    self.target=name;self.target_confirmed=True;self.resource_hold=True
                    self.last_distance=distance;self.last_progress=time.monotonic()
                    self.flight_attempted=reading.confirmed;self.change_mode('APPROACH')
                    self._reset_resource_watch(verified_header=True)
                    self.route_active=True
                    self.say('Путь к уже выбранному ресурсу принят без второго F')
                self.say('Калибровка отложена до сбора или остановки: текущий подход/полёт продолжается')
                return True
        return self._calibrate_camera('при запуске',allow_gather=panel)

    def run(self,offline=None):
        try:
            if offline:
                for file in offline:
                    if self.stop_event.is_set():break
                    frame=cv2.imread(str(file))
                    if frame is not None:self.process(frame,(0,0),time.monotonic())
                return
            if self.screen.pick() is None:raise RuntimeError('Окно AION2 не найдено')
            if not self.cfg.get('dry_run') and self.gamepad is None:raise RuntimeError('Нажмите «Подключить Xbox»')
            self.say('Навигация стиками; миникарта включена с готовыми цветами/формами, отдельный OCR-поток')
            self.safety_threads=[
                threading.Thread(target=self._vision_loop,daemon=True),
                threading.Thread(target=self._health_fast_loop,daemon=True),
                threading.Thread(target=self._health_numeric_loop,daemon=True),
                threading.Thread(target=self._heartbeat_loop,daemon=True),
                threading.Thread(target=self._dialog_loop,args=('CAPTCHA',self.cap,1.0),daemon=True),
                threading.Thread(target=self._dialog_loop,args=('DEATH',self.death,3.0),daemon=True)]
            for worker in self.safety_threads:worker.start()
            self.camera_scheduler_active=True
            if not self._prepare_working_view():return
            while not self.stop_event.is_set():
                frame,origin=self.screen.frame();now=time.monotonic()
                if not self.screen.focused():
                    self._neutral();self.f_disable();self.nav.pause(now)
                    self.stop_event.wait(.1);continue
                reading=read_flight(frame)
                if self._check_route_damage(frame,now):
                    self.stop_event.wait(.06);continue
                if self._resource_fast_tick(frame,reading,now):
                    self.stop_event.wait(.06);continue
                if (self.cfg.get('world_map_enabled') and self.region.ready and not self.cfg.get('dry_run')
                    and self.mode=='SEARCH' and not self.resource_hold and not self.collecting_visible
                    and not self.nav.is_retreating(now)
                    and now>=self.post_gather_until and not self.pitch.returning and self.nav.air_since is None
                    and self.probe is None and self.pending_probe is None and not self.view_guard.active
                    and self.camera_alignment_due is None
                    and self.wing_close_pending is None
                    and now>=self.region.next_check):
                    self._check_world_map();continue
                with self.snapshot_lock:snapshot=self.snapshot
                if snapshot is None or now-snapshot[3]>3:
                    self._neutral();self.stop_event.wait(.08);continue
                obs,captured,sequence,completed=snapshot
                if captured<self.identity_valid_after:
                    self._neutral();self.stop_event.wait(.08);continue
                self.observation_captured_at=captured
                obs=self.current_observation(obs,captured)
                radar=self.minimap.observe(frame)
                if not self.cfg.get('minimap_search',True):radar.markers=[]
                self.step(frame,origin,obs,radar,reading,now,sequence)
                if self.stop_event.wait(.09):break
        except Exception as exc:self.emit('ОШИБКА: '+repr(exc)+'\n'+traceback.format_exc())
        finally:
            self.stop()
            if self.release_thread:self.release_thread.join(timeout=5)
            self.emit('Сканер остановлен; A и стики сброшены')
