import time,unittest
from unittest.mock import patch
from contextlib import ExitStack
import numpy as np
from health import HealthMonitor,HPReading
from flight import FlightReading
from minimap import Marker
from navigation import Navigator
from flight_probe import FlightProbe
from defense import Threat
from gamepad_input import GamepadInput
from test_navigation import GatherFixture,obs
from test_exploration import radar
import gather_engine as ge

HIDDEN=FlightReading(None,False)


class RouteDefenseTests(GatherFixture,unittest.TestCase):
    def selected(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode='APPROACH';self.e.started=99;self.e.last_progress=100
        self.e._reset_resource_watch(verified_header=True)

    def damage(self,now=100):
        self.e.health.numeric(self.frame,HPReading(20000,20000),now-.2)
        self.e.health.numeric(self.frame,HPReading(19999,20000),now-.1)
        self.e.health.numeric(self.frame,HPReading(20000,20000),now)

    def test_one_path_f_then_no_more_f_until_the_actual_lower_panel(self):
        self.selected();self.assertTrue(self.e._start_resource_route())
        for i in range(20):
            self.step(obs('Сапфир',distance=30-i,prompt=True),100+i*.1,plate=3)
        self.assertEqual(self.commands,['TAP_F']);self.assertFalse(self.e.f_on)
        self.assertTrue(self.e.route_active);self.assertFalse(self.e.f_repeat_allowed)
        self.step(obs('Сапфир',distance=1),102.1,plate=3,panel=True)
        self.step(obs('Сапфир',distance=1),102.2,plate=3,panel=True)
        self.step(obs('Сапфир',distance=1),102.4,plate=2,panel=False)
        self.assertEqual(self.commands,['TAP_F','F_ON'])
        self.assertTrue(self.e.f_on);self.assertTrue(self.e.f_repeat_allowed)

    def test_slot_loss_does_not_unlock_f_repeat_without_the_lower_panel(self):
        self.selected();self.e._start_resource_route()
        self.step(obs('Сапфир',distance=20),100,plate=3)
        self.step(obs('Сапфир',distance=20),101,plate=2)
        self.assertFalse(self.e.f_repeat_allowed);self.assertFalse(self.e.f_on)
        self.assertEqual(self.commands,['TAP_F'])

    def test_duplicate_route_start_cannot_toggle_a_running_route_off(self):
        self.selected();self.assertTrue(self.e._start_resource_route())
        self.assertFalse(self.e._start_resource_route());self.e.f_enable()
        self.assertEqual(self.commands,['TAP_F'])

    def test_native_path_keeps_running_during_short_detour_with_map_motion(self):
        self.selected();self.e.last_distance=20;self.e._start_resource_route()
        with patch.object(ge,'segment_count',return_value=3),patch.object(ge,'gathering_panel',return_value=False):
            for i in range(111):
                self.e.step(self.frame,(0,0),obs('Сапфир',distance=20),radar(flow=(-.3,0),valid=True),HIDDEN,100+i*.1,i)
        self.assertEqual(self.commands,['TAP_F']);self.assertEqual(self.e.mode,'APPROACH')
        self.assertTrue(self.e.route_active);self.assertFalse(self.e.f_on)

    def test_wall_recovery_cancels_the_previous_route_before_v_and_one_new_f(self):
        self.selected();self.e.route_active=True;events=[];drive=self.input.drive
        def cancel(*args,**kwargs):events.append('cancel');return drive(*args,**kwargs)
        self.e.bridge.send=events.append
        with patch.object(self.input,'drive',side_effect=cancel),patch.object(GamepadInput,'wait',return_value=True):
            self.e._recover(self.frame,(0,0),obs('Сапфир',distance=20),HIDDEN,100)
        self.assertEqual(events,['cancel','V']);self.assertFalse(self.e.route_active)
        self.step(obs('Сапфир',distance=20),101,plate=3,reading=FlightReading(70,True))
        self.assertEqual(events,['cancel','V','TAP_F']);self.assertTrue(self.e.route_active)

    def test_one_hp_hit_while_far_from_resource_is_checked_even_after_regeneration(self):
        self.selected();self.damage(100)
        with patch.object(self.e,'_defend_and_resume') as defend:
            self.step(obs('Сапфир',distance=40),100,plate=3)
        defend.assert_called_once_with(resume=True)

    def test_damage_during_minimap_patrol_is_checked_without_a_resource_target(self):
        self.damage(100)
        with patch.object(self.e,'_defend_and_resume') as defend:
            self.step(obs(),100)
        defend.assert_called_once_with(resume=False)

    def test_live_damage_check_does_not_wait_for_world_ocr_or_near_distance(self):
        self.selected();self.damage(100);self.e.screen.pick=lambda:'game'
        def defend(**kwargs):self.e.stop_event.set()
        with patch.object(ge.time,'monotonic',return_value=100),patch.object(ge.threading,'Thread'),patch.object(self.e,'_prepare_working_view',return_value=True),patch.object(self.e,'_defend_and_resume',side_effect=defend) as defense,patch.object(ge,'gathering_panel',return_value=False),patch.object(ge,'segment_count',return_value=3),patch.object(ge,'read_flight',return_value=HIDDEN):
            self.e.run()
        self.assertIsNone(self.e.snapshot);defense.assert_called_once_with(resume=True)

    def test_damage_is_handled_by_route_loop_with_camera_calibration_deferred(self):
        self.selected();self.damage(time.monotonic())
        with patch.object(self.e,'_defend_and_resume') as defend,patch.object(ge,'gathering_panel',return_value=False),patch.object(ge,'segment_count',return_value=3),patch.object(self.e.cap,'check',return_value=(False,0)),patch.object(self.e.death,'check',return_value=(False,0)),patch.object(self.e.pitch,'set_working_baseline') as accept:
            self.assertTrue(self.e._calibrate_camera('damage',allow_gather=True))
            self.step(obs('Сапфир',distance=20),time.monotonic(),plate=3)
        defend.assert_called_once_with(resume=True);accept.assert_not_called()
        self.assertIsNone(self.e.camera_alignment_due)
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_after_attacker_death_resource_is_reselected_and_only_one_f_restarts_path(self):
        self.selected();self.e.route_active=True;clock=[100.0]
        def wait(seconds,*args):clock[0]+=max(.3,seconds);return True
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(GamepadInput,'wait',side_effect=wait),patch.object(self.e,'_confirmed_aggressor',return_value=True),patch.object(self.e.threat,'check',return_value=Threat(False,'',False,0)),patch.object(ge,'find_world_resource',return_value=self.c),patch.object(ge,'selected_target',return_value=('Сапфир',30)):
            self.e._defend_and_resume()
            self.assertEqual(self.e.mode,'REACQUIRE');self.assertFalse(self.e.target_confirmed)
            self.e._reacquire_step(self.frame,(0,0),obs(candidate=self.c),clock[0])
        self.assertEqual(self.commands.count('TAB'),1);self.assertEqual(self.commands.count('ATTACK_PAIR'),1)
        self.assertEqual(self.commands.count('TAP_F'),1);self.assertNotIn('F_ON',self.commands)
        self.assertTrue(self.e.route_active);self.assertFalse(self.e.f_on)
        self.assertEqual(self.e.mode,'APPROACH');self.assertTrue(self.e.target_confirmed)

    def test_roaming_defense_preserves_minimap_goal_and_does_not_count_a_resource(self):
        goal=Marker('Самоцвет',140,100,.9,40);self.e.nav.goal=goal;clock=[100.0]
        def wait(*args):clock[0]+=.3;return True
        with patch.object(ge.time,'monotonic',side_effect=lambda:clock[0]),patch.object(GamepadInput,'wait',side_effect=wait),patch.object(self.e,'_confirmed_aggressor',return_value=True),patch.object(self.e.threat,'check',return_value=Threat(False,'',False,0)):
            self.e._defend_and_resume(resume=False)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIs(self.e.nav.goal,goal)
        self.assertEqual(self.e.node_count,0);self.assertNotIn('TAP_F',self.commands)


class SmallDamageTests(unittest.TestCase):
    def test_four_changed_pixels_in_one_digit_are_not_hidden_by_the_full_hp_counter(self):
        image=np.zeros((30,110,3),np.uint8)
        for i in range(5):image[2:12,i*20+4:i*20+14]=255
        health=HealthMonitor();health.numeric(image,HPReading(20000,20000,(0,0,100,15)),0)
        changed=image.copy();changed[4:6,86:88]=0
        self.assertEqual(np.count_nonzero(np.any(image!=changed,axis=2)),4)
        health.fast(changed,.05);health.fast(image,.10)
        self.assertFalse(health.pending(0,.11));self.assertTrue(health.suspect_ready.is_set());self.assertTrue(health.visually_full)


class CloserNavigationTests(unittest.TestCase):
    def test_a_ground_obstacle_probe_looks_down_after_the_lift(self):
        probe=FlightProbe(Marker('Самоцвет',105,100,.9,5),0,{})
        probe.phase_to('PEEK',0)
        action=probe.step(.1,FlightReading(50,True),.02,90,90)
        self.assertLess(action.drive.pitch,0);self.assertEqual(action.drive.forward,0)

    def test_ground_marker_is_approached_through_the_old_scan_radius(self):
        nav=Navigator({})
        for now,distance in [(0,30),(1,25),(2,20),(3,15),(4,10),(5,7)]:
            plan=nav.update(radar([Marker('Самоцвет',100+distance,100,.9,distance)]),now)
            self.assertGreater(plan.forward,.5);self.assertEqual(plan.pitch,0)
            self.assertFalse(plan.flight_probe)

    def test_motion_around_terrain_does_not_trigger_flight_just_because_distance_is_constant(self):
        nav=Navigator({});node=Marker('Самоцвет',130,100,.9,30)
        for i in range(151):
            plan=nav.update(radar([node],flow=(-.5,0),valid=True),i*.1)
            self.assertGreater(plan.forward,.5);self.assertFalse(plan.flight_probe)

    def test_close_ground_search_looks_down_then_changes_position_before_trying_wings(self):
        nav=Navigator({});node=Marker('Самоцвет',105,100,.9,5)
        first=nav.update(radar([node]),0)
        self.assertLess(first.pitch,0);self.assertEqual(first.forward,0)
        end=nav.update(radar([node]),3.1)
        self.assertTrue(end.restore_pitch);self.assertFalse(end.flight_probe)
        side=nav.update(radar([node]),3.2)
        self.assertGreater(abs(side.strafe),.3);self.assertEqual(side.pitch,0)
        self.assertFalse(side.flight_probe)
        nav.update(radar([node]),4.5)
        self.assertTrue(nav.update(radar([node]),7.6).flight_probe)

    def test_confirmed_wall_gets_a_ground_detour_before_a_flight_request(self):
        nav=Navigator({});node=Marker('Самоцвет',150,100,.9,50);detour=False;probe=False
        for i in range(105):
            plan=nav.update(radar([node],flow=(0,0),valid=True),i*.1)
            if plan.restore_pitch and not plan.flight_probe:detour=True
            if plan.flight_probe:probe=True;break
        self.assertTrue(detour);self.assertTrue(probe)

    def test_close_occluded_icon_tracks_terrain_flow_instead_of_disappearing_after_one_second(self):
        nav=Navigator({});nav.update(radar([Marker('Самоцвет',105,100,.9,5)]),0)
        nav.update(radar([],flow=(-.5,0),valid=True),1.5)
        self.assertIsNotNone(nav.goal);self.assertAlmostEqual(nav.goal.x,104.5)

    def test_old_air_radius_cannot_stop_a_far_air_marker_early(self):
        plan=Navigator({'air_search_map_radius':34}).update(radar([Marker('Эфир',120,100,.9,20,'aether')]),0)
        self.assertGreater(plan.forward,.5);self.assertEqual(plan.pitch,0)


if __name__=='__main__':unittest.main()
