"""Search tilt -> one in-gather alignment; approach may still use obstacle flight."""
import time,unittest
from unittest.mock import patch
from contextlib import ExitStack
from gamepad_input import GamepadInput
from flight import FlightReading
from navigation import Drive
from health import HPReading
from test_navigation import GatherFixture,obs
from test_exploration import radar
import gather_engine as ge

AIR=FlightReading(50,True)
GROUND=FlightReading(None,False)

class CameraOnceTests(GatherFixture,unittest.TestCase):
    def gather(self):
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode='GATHER';self.e.started=99;self.e.last_progress=100
        self.e.panel_cleared=True;self.e.f_on=True;self.e.f_repeat_allowed=True
        self.e.camera_scheduler_active=True

    def search_pitch(self):
        self.e.mode='SEARCH';self.e.target_confirmed=False;self.e.resource_hold=False;self.e.collecting_visible=False
        self.e._motion(Drive(pitch=.4,lifetime=.05));self.e._neutral()

    def test_actual_search_tilt_authorizes_one_full_alignment_during_gather(self):
        self.search_pitch();revision=self.e.camera_search_revision;self.assertGreater(revision,0)
        self.gather();reports=[];listener=self.input.motion_listener
        def record(pitch,now,lease):reports.append((pitch,self.pad.axes));listener(pitch,now,lease)
        self.input.motion_listener=record
        with patch.object(ge,'gathering_panel',return_value=True),patch.object(ge,'segment_count',return_value=3),patch.object(ge,'read_flight',return_value=AIR),patch.object(self.e.cap,'check',return_value=(False,0)),patch.object(self.e.death,'check',return_value=(False,0)):
            self.step(obs('Эфир',distance=1),100,plate=3,panel=True,reading=AIR)
        self.assertEqual(self.e.camera_aligned_revision,revision)
        self.assertEqual(self.e.camera_gather_tried_revision,revision)
        self.assertEqual(self.e.camera_search_revision,revision)
        self.assertFalse(self.e._gather_camera_needed());self.assertTrue(self.e.f_on)
        self.assertTrue(any(p>0 for p,a in reports));self.assertEqual(sum(p<0 for p,a in reports),1)
        self.assertTrue(all(a[:3]==(0,0,0) for p,a in reports));self.assertNotIn('V',self.commands)
        self.assertNotIn('END_AIR',self.commands)
        with patch.object(self.e,'_calibrate_camera') as again:
            for now,slots in ((101,3),(104,2),(108,1)):
                self.step(obs('Эфир',distance=1),now,plate=slots,panel=True,reading=AIR)
        again.assert_not_called()

    def test_attempt_or_new_resource_without_search_does_not_request_alignment(self):
        self.gather();self.e.camera_search_revision=5;self.e.camera_aligned_revision=5
        with patch.object(self.e,'_calibrate_camera') as calibrate:
            for now,slots in ((100,3),(101,2),(102,1)):
                self.step(obs('Эфир',distance=1),now,plate=slots,panel=True,reading=AIR)
            self.e._reset_resource_watch(verified_header=True)
            self.step(obs('Эфир',distance=1),103,plate=3,panel=True,reading=AIR)
        calibrate.assert_not_called()

    def test_calibration_pulses_do_not_mark_a_new_search_revision(self):
        with patch.object(self.e,'_hold_pitch_up',return_value=True),patch.object(ge,'gathering_panel',return_value=False),patch.object(self.e.cap,'check',return_value=(False,0)),patch.object(self.e.death,'check',return_value=(False,0)):
            self.assertTrue(self.e._calibrate_camera('startup'))
        self.assertEqual(self.e.camera_search_revision,0);self.assertFalse(self.e._gather_camera_needed())

    def test_next_search_pitch_allows_next_alignment(self):
        self.search_pitch();first=self.e.camera_search_revision
        self.e.camera_aligned_revision=first;self.e.camera_gather_tried_revision=first
        self.assertFalse(self.e._gather_camera_needed())
        self.search_pitch();self.assertGreater(self.e.camera_search_revision,first)
        self.assertTrue(self.e._gather_camera_needed())

    def test_forward_motion_and_yaw_only_do_not_change_working_pitch(self):
        self.e._motion(Drive(forward=.6,yaw=.3));self.e._neutral()
        self.assertEqual(self.e.camera_search_revision,0)

    def test_return_pulses_are_not_another_search(self):
        self.e.pitch.balance=.1;self.e.pitch.restore(time.monotonic())
        self.e._motion(Drive(pitch=-.4));self.e._neutral()
        self.assertEqual(self.e.camera_search_revision,0)

    def test_pending_alignment_does_not_run_on_approach_or_without_bottom_panel(self):
        self.search_pitch();self.gather();self.e.mode='APPROACH'
        with patch.object(self.e,'_calibrate_camera') as calibrate:
            self.step(obs('Эфир',distance=20),100,plate=3,reading=AIR)
            self.e.mode='GATHER';self.e.fast_gather_seen=True
            self.step(obs('Эфир',distance=1),101,plate=2,panel=False,reading=AIR)
        calibrate.assert_not_called();self.assertTrue(self.e._gather_camera_needed())

    def test_repeated_explicit_alignment_request_is_blocked_after_same_revision_was_tried(self):
        self.search_pitch();self.gather();revision=self.e.camera_search_revision
        self.e.camera_gather_tried_revision=revision
        with patch.object(ge,'gathering_panel',return_value=True),patch.object(self.input,'drive') as drive:
            self.assertTrue(self.e._calibrate_camera('duplicate',allow_gather=True))
        drive.assert_not_called()

    def test_interrupted_alignment_is_not_repeated_during_same_search_revision(self):
        self.search_pitch();self.gather()
        def interrupted(*args):self.e.calibration_defense_interrupted=True;return False
        with patch.object(ge,'gathering_panel',return_value=True),patch.object(self.e.cap,'check',return_value=(False,0)),patch.object(self.e.death,'check',return_value=(False,0)),patch.object(self.e,'_hold_pitch_up',side_effect=interrupted):
            self.assertTrue(self.e._calibrate_camera('one attempt',allow_gather=True))
        self.assertFalse(self.e._gather_camera_needed());self.assertEqual(self.e.camera_aligned_revision,0)
        with patch.object(self.e,'_calibrate_camera') as again:
            self.step(obs('Эфир',distance=1),100,plate=3,panel=True,reading=AIR)
        again.assert_not_called()

    def test_damage_protection_has_priority_over_alignment(self):
        self.search_pitch();self.gather();self.e.health.numeric(self.frame,HPReading(18441,18442),99.9)
        with patch.object(self.e,'_defend_and_resume') as defend,patch.object(self.e,'_calibrate_camera') as calibrate:
            self.step(obs('Эфир',distance=1),100,plate=3,panel=True,reading=AIR)
        defend.assert_called_once_with(resume=True);calibrate.assert_not_called()

class ApproachFlightTests(GatherFixture,unittest.TestCase):
    def selected(self,distance):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.resource_hold=True
        self.e.mode='APPROACH';self.e.started=99;self.e.last_progress=100;self.e.last_distance=distance
        self.e._reset_resource_watch(verified_header=True);self.e.route_active=True

    def step_flow(self,distance,now,panel=False):
        with patch.object(ge,'segment_count',return_value=3),patch.object(ge,'gathering_panel',return_value=panel):
            self.e.step(self.frame,(0,0),obs('Сапфир',distance=distance),radar(flow=(.3,0),valid=True),GROUND,now)

    def test_selected_target_at_five_metres_can_use_wings_after_six_seconds_without_gather(self):
        self.selected(5)
        with patch.object(GamepadInput,'wait',return_value=True):
            self.step_flow(5,100);self.step_flow(5,106.2)
        self.assertIn('V',self.commands);self.assertEqual(self.e.mode,'TAKEOFF')
        self.assertTrue(self.e.target_confirmed)

    def test_sustained_far_distance_stall_is_not_hidden_forever_by_map_motion(self):
        self.selected(20)
        with patch.object(GamepadInput,'wait',return_value=True):
            self.step_flow(20,100);self.step_flow(20,111)
            self.assertNotIn('V',self.commands)
            self.step_flow(20,112.2)
        self.assertIn('V',self.commands)

    def test_decreasing_metres_keep_native_path_running(self):
        self.selected(20)
        for now,dist in ((100,20),(105,18),(110,15),(115,10),(120,5)):
            self.step_flow(dist,now)
        self.assertNotIn('V',self.commands);self.assertTrue(self.e.route_active)

    def test_bottom_panel_at_five_metres_overrides_stale_distance_and_stall(self):
        self.selected(5);self.e.panel_cleared=True
        self.step_flow(5,106.2,panel=True)
        self.assertEqual(self.e.mode,'GATHER');self.assertNotIn('V',self.commands)

    def test_near_resource_cannot_open_wings_even_after_long_stall(self):
        self.selected(2)
        self.step_flow(2,100);self.step_flow(2,110)
        self.assertNotIn('V',self.commands)

    def test_blocked_v_does_not_count_as_an_actual_takeoff_attempt(self):
        self.selected(5);self.e.route_active=False
        with patch.object(ge,'segment_count',return_value=3),patch.object(ge,'selected_target',return_value=('Сапфир',2)):
            self.e._recover(self.frame,(0,0),obs('Сапфир',distance=5),GROUND,107)
        self.assertFalse(self.e.flight_attempted);self.assertNotIn('V',self.commands)

if __name__=='__main__':unittest.main()
