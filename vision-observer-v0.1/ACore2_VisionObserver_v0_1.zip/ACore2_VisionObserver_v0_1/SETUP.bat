@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if not errorlevel 1 (
  for %%V in (3.12 3.13 3.11 3.10) do (
    py -%%V -c "import sys" >nul 2>nul
    if not errorlevel 1 (
      py -%%V bootstrap.py
      goto result
    )
  )
)
python bootstrap.py
:result
if errorlevel 1 (
  echo Установка не завершилась. Ошибка указана выше. Нужен Python 3.12 x64.
  pause
  exit /b 1
)
pause
