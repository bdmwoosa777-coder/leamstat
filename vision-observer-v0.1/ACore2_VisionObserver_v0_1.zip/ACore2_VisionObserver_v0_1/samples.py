"""User-requested local examples. No uploads or network calls."""
from datetime import datetime
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import json,os,threading,uuid
import cv2
import numpy as np

ROOT=Path(__file__).resolve().parent


def write_image(path,image,extension='.png',quality=95):
    parameters=[cv2.IMWRITE_JPEG_QUALITY,quality] if extension=='.jpg' else []
    ok,data=cv2.imencode(extension,image,parameters)
    if not ok:raise OSError('Не удалось закодировать изображение')
    path.write_bytes(data.tobytes())


class SampleStore:
    def __init__(self,folder=None):
        self.folder=Path(folder or ROOT/'samples');self.lock=threading.Lock()
    def save(self,frame,overlay,scene,metadata):
        self.folder.mkdir(parents=True,exist_ok=True)
        name=datetime.now().strftime('%Y%m%d_%H%M%S_')+uuid.uuid4().hex[:6]
        temporary=self.folder/('.writing_'+name);destination=self.folder/name
        with self.lock:
            temporary.mkdir()
            try:
                write_image(temporary/'frame.jpg',frame,'.jpg')
                write_image(temporary/'overlay.jpg',overlay,'.jpg',quality=88)
                write_image(temporary/'classes.png',scene.labels)
                write_image(temporary/'confidence.png',np.round(np.clip(scene.confidence,0,1)*255).astype(np.uint8))
                (temporary/'summary.json').write_text(json.dumps({**metadata,'scene':scene.summary},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
                temporary.rename(destination)
            except Exception:
                import shutil
                shutil.rmtree(temporary,ignore_errors=True);raise
        return destination
    def export(self):
        self.folder.mkdir(parents=True,exist_ok=True)
        destination=self.folder.parent/('vision_examples_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:6]+'.zip')
        with self.lock,ZipFile(destination,'w',ZIP_DEFLATED,compresslevel=5) as archive:
            for directory in sorted(self.folder.iterdir()):
                if directory.is_symlink() or not directory.is_dir() or directory.name.startswith('.'):continue
                for name in ('frame.jpg','overlay.jpg','classes.png','confidence.png','summary.json'):
                    path=directory/name
                    if path.is_file() and not path.is_symlink():archive.write(path,directory.name+'/'+name)
        return destination
