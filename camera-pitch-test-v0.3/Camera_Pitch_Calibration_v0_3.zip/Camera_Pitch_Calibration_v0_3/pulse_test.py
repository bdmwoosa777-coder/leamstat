"""Single stationary camera pulse with a renewable-input watchdog and timing."""
from dataclasses import dataclass
import threading,time
from gamepad_input import GamepadInput


CASES=[('14',.45,.60)]+[(str(15+i),.45,ms/1000) for i,ms in enumerate(range(610,701,10))]


@dataclass
class PulseResult:
    pitch:float
    requested_ms:float
    delivered_ms:float|None
    completed:bool


class PulseTester:
    def __init__(self,control=None,logger=None):
        self.pad=control or GamepadInput(logger=logger)
        self.guard=threading.Lock();self.abort=threading.Event()
        self.timing_lock=threading.Lock();self.began=None;self.ended=None
        self.pad.motion_listener=self._report

    def _report(self,pitch,now,lifetime):
        with self.timing_lock:
            if pitch and self.began is None:self.began=now
            elif not pitch and self.began is not None and self.ended is None:self.ended=now

    def cancel(self):
        self.abort.set();self.pad.reset()

    def pulse(self,pitch,seconds,focused):
        if not .01<=abs(pitch)<=.60 or not .02<=seconds<=.70:
            raise ValueError('Допустимы сила до 0.60 и длительность 20–700 мс')
        if not self.guard.acquire(blocking=False):raise RuntimeError('Предыдущий импульс ещё выполняется')
        try:
            self.abort.clear()
            with self.timing_lock:self.began=None;self.ended=None
            if not focused():return PulseResult(pitch,seconds*1000,None,False)
            completed=False
            try:
                # Left stick is always zero; A and keyboard are never pressed.
                self.pad.drive(0,0,0,pitch,lifetime=seconds)
                completed=GamepadInput.wait(seconds,self.abort,focused)
            finally:self.pad.reset()
            with self.timing_lock:
                delivered=None if self.began is None or self.ended is None else 1000*(self.ended-self.began)
            return PulseResult(pitch,seconds*1000,delivered,completed)
        finally:self.guard.release()

    def close(self):self.cancel();self.pad.close()
