"""Failed faint Ether: close in, retire one point, prefer fresh alternatives to TP."""
import copy,unittest
from dataclasses import replace
from unittest.mock import patch
import gather_engine as ge,hybrid_engine as he
import test_camp_departure as fixture
from navigation import Navigator
from test_navigation import radar,obs
from test_lookup import marker
from test_patrol import GROUND

class RetryDistance(unittest.TestCase):
 def setUp(self):
  self.n=Navigator({'ether_quick_search':True,'air_search_wide':True,'air_search_map_radius':22})
  self.now=100.
 def scan(self,x):
  r=radar([marker(x)])
  for _ in range(16):
   d=self.n.update(r,self.now)
   if d.restore_pitch:return d
   self.now=self.n.scan_next_at+.001
  self.fail('scan did not finish')
 def walk(self):
  r=radar([marker(113)])
  for _ in range(7):self.now+=.3;self.n.track_walk(r,True,self.now)
  self.assertEqual(self.n.lookup_walk_remaining,0)
 def test_first_miss_requires_closer_marker_even_after_delivered_walk(self):
  self.scan(113);self.walk();d=self.n.update(radar([marker(113)]),self.now+.1)
  self.assertEqual(d.pitch,0);self.assertGreater(d.forward,.5);self.assertEqual(self.n.lookup_failures,1)
 def test_closer_marker_can_unlock_second_upward_look(self):
  self.scan(113);self.walk();d=self.n.update(radar([marker(105)]),self.now+.1)
  self.assertGreater(d.pitch,0)
 def test_second_miss_requires_more_closing_instead_of_same_radius(self):
  self.scan(113);self.walk();self.scan(105);self.walk()
  d=self.n.update(radar([marker(105)]),self.now+.1)
  self.assertEqual(d.pitch,0);self.assertGreater(d.forward,.5);self.assertEqual(self.n.lookup_failures,2)
 def test_third_miss_retires_only_current_point_and_selects_close_neighbor(self):
  self.scan(113);self.walk();self.scan(105);self.walk();d=self.scan(102)
  self.assertIn('ETHER_NEXT',d.reason);self.assertFalse(d.flight_probe);self.assertIsNone(self.n.goal)
  self.now+=.5;other=marker(106);self.n.update(radar([marker(102),other]),self.now)
  self.assertIs(self.n.goal,other)
 def test_failed_scan_does_not_renew_total_goal_deadline(self):
  self.scan(113);self.assertEqual(self.n.goal_started,100)
 def test_total_timeout_selects_another_point_without_flight(self):
  self.n.update(radar([marker(140)]),100)
  d=self.n.update(radar([marker(140)]),146)
  self.assertTrue(d.restore_pitch);self.assertFalse(d.flight_probe);self.assertIsNone(self.n.goal)
 def test_bad_point_is_temporarily_excluded_not_permanently_removed(self):
  self.n.update(radar([marker(140)]),100);self.n.update(radar([marker(140)]),146)
  self.assertFalse(self.n.available_markers(radar([marker(140)]),147))
  self.assertTrue(self.n.available_markers(radar([marker(140)]),267))
 def test_availability_query_is_read_only_and_matches_nearest_exclusion(self):
  self.n.goal=marker(113);self.n.last_scale=1;self.n.exclude_goal(100,120)
  state=copy.deepcopy(self.n.excluded);bad,other=marker(113),marker(116)
  self.assertEqual(self.n.available_markers(radar([bad,other]),101),[other]);self.assertEqual(self.n.excluded,state)
 def test_availability_query_projects_latest_map_motion_only_once(self):
  self.n.goal=marker(113);self.n.exclude_goal(100,120)
  r=radar([marker(123),marker(126)]);r.motion_valid=True;r.displacement=(10,0)
  self.assertEqual(self.n.available_markers(r,101),[r.markers[1]])
  self.n.update(r,101);self.assertEqual(self.n.available_markers(r,101),[r.markers[1]])

class ReturnAlternatives(unittest.TestCase):
 def setUp(self):
  self.f=fixture.DepartureControl('test_existing_map_ether_does_not_prevent_initial_departure');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.e.budget.energy=80
 def sample(self,points,now=100):self.e.resource_radar=(radar(points),now)
 def test_fresh_second_ether_blocks_old_no_yield_teleport(self):
  self.sample([marker(113),marker(116)])
  with patch.object(ge.GatherEngine,'_start_return') as start:
   self.assertFalse(self.e._start_return(self.f.frame,GROUND,101,{}))
  start.assert_not_called()
 def test_bad_point_does_not_hide_neighbor_from_return_gate(self):
  self.e.nav.goal=marker(113);self.e.nav.exclude_goal(100,120);self.sample([marker(113),marker(116)])
  self.assertEqual(len(self.e._resource_options(101)),1)
 def test_all_points_tried_or_no_points_allow_normal_return(self):
  self.e.nav.goal=marker(113);self.e.nav.exclude_goal(100,120);self.sample([marker(113)])
  with patch.object(ge.GatherEngine,'_start_return',return_value=True) as start:
   self.assertTrue(self.e._start_return(self.f.frame,GROUND,101,{}))
  start.assert_called_once()
 def test_stale_map_cannot_keep_blocking_necessary_return(self):
  self.sample([marker(113)])
  with patch.object(ge.GatherEngine,'_start_return',return_value=True) as start:
   self.assertTrue(self.e._start_return(self.f.frame,GROUND,102,{}))
  start.assert_called_once()
 def test_fresh_resource_prevents_generic_rescue_but_not_proven_wall_escape(self):
  self.sample([marker(113)]);self.assertFalse(self.e._no_yield_rescue_allowed(101))
  with patch.object(ge.GatherEngine,'_start_terrain_recovery') as rescue:
   self.assertFalse(self.e._start_terrain_recovery(101,GROUND))
  rescue.assert_not_called()
  self.e.hybrid.wall_flight_proven_until=102
  with patch.object(ge.GatherEngine,'_start_terrain_recovery',return_value=True) as rescue:
   self.assertTrue(self.e._start_terrain_recovery(101,GROUND,short=True))
  rescue.assert_called_once()
 def test_resource_observation_does_not_fake_or_reset_own_result(self):
  self.sample([marker(113)]);before=(self.e.no_yield.idle,self.e.no_yield.result_stamp)
  self.e._start_return(self.f.frame,GROUND,101,{})
  self.assertEqual((self.e.no_yield.idle,self.e.no_yield.result_stamp),before)
 def test_exact_bridge_guard_is_not_overridden_by_generic_map_resources(self):
  self.sample([marker(113)]);self.e.return_exit_guard=True
  self.assertFalse(self.e._resource_options(101))
 def test_new_marker_before_opening_map_cancels_return_sequence(self):
  self.sample([marker(113)]);self.e.return_sequence=object();self.e.mode='RETURN'
  with patch.object(ge.GatherEngine,'_start_map_teleport') as start:
   self.assertFalse(self.e._start_map_teleport(101))
  start.assert_not_called();self.assertIsNone(self.e.return_sequence);self.assertEqual(self.e.mode,'SEARCH')
