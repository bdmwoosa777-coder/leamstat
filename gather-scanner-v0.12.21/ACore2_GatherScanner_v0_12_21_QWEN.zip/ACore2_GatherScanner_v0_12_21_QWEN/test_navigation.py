import threading
import time
from types import SimpleNamespace
import unittest
from unittest.mock import patch
import cv2
import numpy as np
from app import DEFAULT
import gather_engine as ge
from flight import FlightReading,FlightBudget,read_flight
from gamepad_input import GamepadInput
from minimap import Marker,Radar,MinimapVision,angle_delta
from navigation import Navigator
from vision import Candidate,Observation,gathering_panel


class Pad:
    def __init__(self):self.buttons=0;self.axes=(0,0,0,0);self.presses=0;self.fail=False;self.lt=0
    def reset(self):self.buttons=0;self.axes=(0,0,0,0);self.lt=0
    def update(self):
        if self.fail and self.buttons:raise RuntimeError('driver failed after report')
    def press_button(self,button):self.buttons|=button;self.presses+=int(bool(button&0x1000))
    def release_button(self,button):self.buttons&=~button
    def left_trigger_float(self,value_float):self.lt=value_float
    def left_joystick_float(self,x_value_float,y_value_float):self.axes=(x_value_float,y_value_float,*self.axes[2:])
    def right_joystick_float(self,x_value_float,y_value_float):self.axes=(*self.axes[:2],x_value_float,y_value_float)


def obs(name=None,candidate=None,distance=None,prompt=False,gather=False):
    return Observation(candidate,name,distance,prompt,1 if prompt else 0,gather,None,'HIDDEN')


def radar(markers=None,heading=90):return Radar(markers or [],(100,100),heading,1,(0,0),False,(0,0,200,200))


class NavigationTests(unittest.TestCase):
    def test_camera_cone_gives_bisector_not_player_arrow(self):
        image=np.full((200,200,3),(70,100,120),np.uint8)
        cv2.line(image,(115,85),(170,30),(255,255,255),2)
        cv2.line(image,(115,115),(170,170),(255,255,255),2)
        heading,confidence=MinimapVision.cone_heading(image,(100,100))
        self.assertIsNotNone(heading);self.assertLess(abs(angle_delta(heading,90)),10)
        self.assertGreater(confidence,.3)

    def test_aligned_marker_produces_real_forward_motion(self):
        marker=Marker('Самоцвет',150,100,.9,50)
        nav=Navigator({});plan=nav.update(radar([marker],90),0)
        self.assertGreater(plan.forward,.5);self.assertLess(abs(plan.yaw),.1)

    def test_behind_marker_keeps_moving_while_camera_pulse_turns(self):
        marker=Marker('Эфир',50,100,.9,50,'aether')
        plan=Navigator({}).update(radar([marker],90),0)
        self.assertGreater(abs(plan.forward)+abs(plan.strafe),.6);self.assertGreater(abs(plan.yaw),.3)

    def test_empty_map_patrol_is_not_stationary_camera_twitch(self):
        plan=Navigator({}).update(radar(),0)
        self.assertGreater(plan.forward,.4)

    def test_low_energy_chooses_ground_marker(self):
        nodes=[Marker('Эфир',120,100,.9,20,'aether'),Marker('Самоцвет',150,100,.9,50)]
        nav=Navigator({});nav.update(radar(nodes),0,allow_air=False)
        self.assertEqual(nav.goal.kind,'gem')

    def test_unmeasured_progress_does_not_fly_after_only_seven_seconds(self):
        marker=Marker('Самоцвет',150,100,.9,50)
        nav=Navigator({});nav.update(radar([marker]),0)
        plan=nav.update(radar([marker]),7)
        self.assertFalse(plan.flight_probe);self.assertGreater(plan.forward,.5);self.assertIsNotNone(nav.goal)

    def test_white_circular_dots_are_not_gem_icons(self):
        image=np.full((720,1280,3),(70,100,120),np.uint8)
        for x,y in [(1090,100),(1110,100),(1130,110)]:cv2.circle(image,(x,y),3,(250,250,250),-1)
        found=MinimapVision({}).observe(image).markers
        self.assertFalse(any(m.kind=='gem' for m in found),found)

    def test_builtin_coloured_diamond_and_three_lobed_gem(self):
        image=np.full((720,1280,3),(70,100,120),np.uint8)
        cv2.fillConvexPoly(image,np.array([[1220,95],[1226,104],[1220,113],[1214,104]]),(160,235,50))
        glyph=cv2.resize(MinimapVision.gem_glyph(),(9,11),interpolation=cv2.INTER_AREA)
        patch=image[100:111,1100:1109];patch[glyph>150]=(255,255,255)
        found=MinimapVision({}).observe(image).markers
        self.assertTrue(any(m.kind=='aether' and abs(m.x-1220)<4 for m in found),found)
        self.assertTrue(any(m.kind=='gem' and abs(m.x-1104)<4 for m in found),found)


class FlightTests(unittest.TestCase):
    def test_nearly_empty_real_shaped_track_reports_low_energy(self):
        image=np.full((720,1280,3),(145,155,140),np.uint8)
        y=np.arange(476,727,dtype=float);x=1047+46*((y-597)/123)**2
        points=np.column_stack((np.rint(x*.5),np.rint((y+160)*.5))).astype('int32')
        cv2.polylines(image,[points],False,(15,15,15),6)
        cv2.polylines(image,[points[-12:]],False,(240,255,50),4)
        reading=read_flight(image)
        self.assertTrue(reading.confirmed);self.assertLess(reading.energy,8)

    def test_absent_gauge_is_not_zero_energy(self):
        reading=read_flight(np.full((720,1280,3),(220,170,100),np.uint8))
        self.assertFalse(reading.confirmed);self.assertIsNone(reading.energy)

    def test_low_energy_hysteresis_recovers_on_ground(self):
        b=FlightBudget();b.update(FlightReading(3,True),0)
        self.assertFalse(b.can_start())
        b.update(FlightReading(None,False),1);b.update(FlightReading(None,False),5)
        self.assertFalse(b.can_start())
        for second in range(6,41):b.update(FlightReading(None,False),second)
        self.assertTrue(b.can_start());self.assertGreaterEqual(b.energy,18)


class InputLeaseTests(unittest.TestCase):
    def test_motion_lease_expires_without_new_vision(self):
        pad=Pad();control=GamepadInput(factory=lambda:pad,a_button=0x1000)
        try:
            control.drive(.7,0,.2,0,lifetime=.05)
            self.assertNotEqual(pad.axes,(0,0,0,0))
            until=time.monotonic()+1
            while pad.axes!=(0,0,0,0) and time.monotonic()<until:time.sleep(.01)
            self.assertEqual(pad.axes,(0,0,0,0))
        finally:control.close()

    def test_failed_a_update_still_releases_button_and_sticks(self):
        pad=Pad();control=GamepadInput(factory=lambda:pad,a_button=0x1000);pad.fail=True
        try:
            with self.assertRaises(RuntimeError):control.tap_a(threading.Event(),lambda:True)
            self.assertEqual(pad.buttons,0);self.assertEqual(pad.axes,(0,0,0,0))
        finally:control.close()


class GatherFixture:
    def setUp(self):
        self.pad=Pad();self.input=GamepadInput(factory=lambda:self.pad,a_button=0x1000)
        self.log=[];self.commands=[];self.positions=[]
        # Legacy F/instant-defense fixtures. Default click/arrival policy has
        # separate end-to-end controller coverage in test_click_collection.py.
        self.e=ge.GatherEngine({**DEFAULT,'isolate_vision_processes':False,'responsive_control':False,'ground_route_navigation':False,'analyzer_enabled':False,'flight_probe_enabled':True,'map_safe_return_enabled':False,'scene_navigation_enabled':False,'area_search_rescue':False,'no_yield_return_enabled':False,'terrain_rescue_enabled':False,'defense_air_search':False,'collection_event_driven':False,'native_cursor_chord':False,'debug_screenshots':False,'network_enabled':False,'resource_click_interaction':False,'defense_during_approach':True,'visual_route_hold':False,'air_search_wide':False,'collection_cursor_hold':False,'calibrate_during_collection':True,'repeat_owned_clicks':False,'preserve_owned_resource':False},self.log.append,self.input)
        self.alt_held=False
        def send(command):
            self.commands.append(command)
            if command=='ALT_DOWN':self.alt_held=True
            elif command in ('ALT_UP','STOP','END_AIR'):self.alt_held=False
        self.e.bridge=SimpleNamespace(send=send,cursor=lambda x,y:self.positions.append((x,y)),restore_locks=lambda:None,alt_is_down=lambda:self.alt_held)
        self.frame=np.zeros((720,1280,3),np.uint8)
        self.e.screen=SimpleNamespace(focused=lambda:True,frame=lambda:(self.frame,(0,0)))
        self.c=Candidate('Сапфир',700,400,95,(670,360,60,20))
        self.sky=FlightReading(None,False)

    def tearDown(self):
        # Runtime-recovery cases may start the actual observation workers.
        # Do not leave one querying the next test's process-wide OCR mocks.
        self.e.stop_event.set()
        for worker in getattr(self.e,'safety_threads',()):
            if isinstance(worker,threading.Thread) and worker is not threading.current_thread() and worker.ident is not None:
                worker.join(1)
        self.input.close()

    def step(self,ob,now=100,plate=None,panel=False,reading=None):
        with patch.object(ge,'segment_count',return_value=plate),patch.object(ge,'gathering_panel',return_value=panel),patch.object(ge,'gathering_panel_pair',return_value=panel):
            self.e.step(self.frame,(0,0),ob,radar(),reading or self.sky,now,1)


class GatherStateTests(GatherFixture,unittest.TestCase):
    def test_one_a_then_alt_release_then_f(self):
        with patch.object(GamepadInput,'wait',return_value=True):
            self.assertTrue(self.e.click_candidate(self.c,(10,20),refresh=False))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.buttons,0)
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP','TAP_F'])
        self.assertTrue(self.e.target_confirmed);self.assertEqual(self.e.mode,'APPROACH')

    def test_nonresource_header_never_sends_f(self):
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(ge,'find_world_resource',return_value=self.c),patch.object(ge,'selected_target',return_value=('Страж',10)):
            self.assertFalse(self.e.click_candidate(self.c,(0,0)))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.commands[-1],'ALT_UP')
        self.assertNotIn('TAP_F',self.commands)

    def test_body_miss_retries_known_hitbox_below_resource_caption(self):
        body=Candidate('Сапфир',700,450,95,(670,360,60,20))
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(ge,'find_world_resource',return_value=body),patch.object(ge,'selected_target',side_effect=[(None,None),('Сапфир',20)]):
            self.assertTrue(self.e.click_candidate(body,(0,0)))
        self.assertEqual(self.positions,[(700,450),(700,398)])
        self.assertEqual(self.pad.presses,2)
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP','TAP_F'])

    def test_selected_resource_starts_one_path_without_waiting_for_pitch_return(self):
        self.e.pitch.balance=.24;self.e.nav.air_since=90
        with patch.object(GamepadInput,'wait',return_value=True):
            self.assertTrue(self.e.click_candidate(self.c,(0,0),refresh=False))
        self.assertTrue(self.e.pitch.returning);self.assertIsNone(self.e.nav.air_since)
        self.step(obs('Сапфир',distance=20),100,plate=3)
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertFalse(self.e.f_on)
        self.assertTrue(self.e.route_active);self.assertTrue(self.e.pitch.returning)

    def test_map_check_opens_closes_and_fences_old_ocr(self):
        fix=SimpleNamespace(position=(100,200),goal=(500,200),character_heading=30,bearing=90,outside=True)
        self.e.region=SimpleNamespace(locate=lambda frame:None,spec={'north_up':True},
            matcher=SimpleNamespace(register=lambda frame:None),next_check=0)
        with patch.object(self.e.region,'locate',side_effect=[None,fix]),patch.object(GamepadInput,'wait',return_value=True):
            self.e._check_world_map()
        self.assertEqual(self.commands,['MAP','MAP'])
        self.assertTrue(self.e.nav.route_priority);self.assertEqual(self.e.nav.route_bearing,90)
        self.assertGreater(self.e.identity_valid_after,0);self.assertFalse(self.e.map_active)

    def test_unconfirmed_map_stops_without_blind_second_m(self):
        self.e.region=SimpleNamespace(locate=lambda frame:None)
        with patch.object(GamepadInput,'wait',return_value=True):self.e._check_world_map()
        if self.e.release_thread:self.e.release_thread.join(timeout=1)
        self.assertTrue(self.e.stop_event.is_set());self.assertEqual(self.commands.count('MAP'),1)
        self.assertFalse(self.e.map_active);self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_stop_after_a_suppresses_f(self):
        def wait(seconds,*args):
            if seconds==.20:self.e.stop_event.set();return False
            return True
        with patch.object(GamepadInput,'wait',side_effect=wait):
            self.assertFalse(self.e.click_candidate(self.c,(0,0),refresh=False))
        self.assertEqual(self.pad.presses,1);self.assertEqual(self.pad.buttons,0)
        self.assertEqual(self.commands[-1],'ALT_UP')
        self.assertNotIn('TAP_F',self.commands)

    def test_header_corrects_an_imprecise_far_caption(self):
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(ge,'find_world_resource',return_value=self.c),patch.object(ge,'selected_target',return_value=('Рубин',25)):
            self.assertTrue(self.e.click_candidate(self.c,(0,0)))
        self.assertEqual(self.e.target,'Рубин');self.assertEqual(self.pad.presses,1)
        self.assertEqual(self.commands,['ALT_DOWN','ALT_UP','TAP_F'])

    def test_unreadable_header_does_not_send_f_even_if_world_caption_was_read(self):
        with patch.object(GamepadInput,'wait',return_value=True),patch.object(ge,'find_world_resource',return_value=self.c),patch.object(ge,'selected_target',return_value=(None,None)):
            self.assertFalse(self.e.click_candidate(self.c,(0,0)))
        self.assertNotIn('TAP_F',self.commands);self.assertEqual(self.commands[-1],'ALT_UP')

    def test_sky_does_not_toggle_wings_when_ether_selection_failed(self):
        self.e.target='Эфир';self.e.budget.airborne=True
        self.e.return_to_search('выбор не подтвердился',reading=self.sky)
        self.assertNotIn('V',self.commands)

    def test_near_target_waits_for_lower_panel_before_repeating_f(self):
        self.e.mode='APPROACH';self.e.target='Сапфир';self.e.target_confirmed=True
        self.step(obs('Сапфир',distance=1),plate=3)
        self.assertEqual(self.e.mode,'APPROACH');self.assertNotIn('F_ON',self.commands)
        self.step(obs('Сапфир',distance=1,gather=True),101,plate=3,panel=True)
        self.assertEqual(self.e.mode,'GATHER')

    def test_depletion_needs_track_and_identity_to_disappear(self):
        self.e.mode='GATHER';self.e.target='Сапфир';self.e.target_confirmed=True;self.e.f_on=True;self.e.started=99
        self.step(obs(),100,plate=1)
        self.assertEqual(self.e.mode,'GATHER')
        self.step(obs(),101);self.step(obs(),102)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIn('F_OFF',self.commands)
        self.assertEqual(self.e.node_count,1)

    def test_ground_gather_keeps_wings_unchanged_and_keeps_f(self):
        self.e.mode='GATHER';self.e.target='Сапфир';self.e.f_on=True;self.e.started=99
        reading=FlightReading(60,True)
        self.step(obs('Сапфир',gather=True),100,plate=3,panel=True,reading=reading)
        self.step(obs('Сапфир',gather=True),101,plate=2,panel=True,reading=reading)
        self.assertNotIn('V',self.commands);self.assertNotIn('F_OFF',self.commands)

    def test_ether_keeps_wings_on_last_attempt_and_folds_only_after_depletion(self):
        self.e.mode='GATHER';self.e.target='Эфир';self.e.target_confirmed=True;self.e.f_on=True;self.e.started=99
        with patch.object(ge,'gather_result_full',return_value=True):
            self.step(obs('Эфир',gather=True),100,plate=1,panel=True,reading=FlightReading(50,True))
            self.step(obs('Эфир',gather=True),101,plate=1,panel=True,reading=FlightReading(50,True))
        self.assertNotIn('V',self.commands)
        self.step(obs(),102,reading=FlightReading(49,True))
        self.assertNotIn('V',self.commands)
        self.step(obs(),103,reading=FlightReading(49,True))
        self.assertEqual(self.commands.count('END_AIR'),1)
        self.assertEqual(self.e.mode,'SEARCH');self.assertFalse(self.e.f_on)

    def test_obstacle_recovery_opens_wings_when_energy_is_available(self):
        self.e.target='Сапфир';self.e.target_confirmed=True
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=12),self.sky,100)
        self.assertEqual(self.e.mode,'TAKEOFF');self.assertIn('V',self.commands)
        self.assertNotIn('JUMP',self.commands)

    def test_low_energy_uses_jump_instead_of_opening_wings(self):
        self.e.target='Сапфир';self.e.target_confirmed=True
        self.e.budget.update(FlightReading(3,True),99)
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=12),self.sky,100)
        self.assertEqual(self.e.mode,'JUMP_RETRY');self.assertIn('JUMP',self.commands)
        self.assertNotIn('V',self.commands)

    def test_confirmed_own_v_allows_one_replacement_route_f(self):
        self.e.target='Сапфир';self.e.target_confirmed=True
        self.e._recover(self.frame,(0,0),obs('Сапфир',candidate=self.c,distance=12),self.sky,100)
        self.assertEqual(self.commands,['V'])
        with patch.object(ge,'read_flight',return_value=FlightReading(70,True)):
            self.step(obs('Сапфир',candidate=self.c,distance=12),101,plate=3,reading=FlightReading(70,True))
        self.assertEqual(self.commands,['V','TAP_F'])
        self.assertEqual(self.e.mode,'APPROACH');self.assertEqual(self.pad.presses,0)

    def test_automatic_aether_takeoff_never_gets_an_extra_v(self):
        self.e.target='Эфир';self.e.target_confirmed=True
        self.e._recover(self.frame,(0,0),obs('Эфир',distance=12),FlightReading(70,True),100)
        self.assertEqual(self.commands,[])
        self.assertFalse(self.e.reselected);self.assertTrue(self.e.flight_attempted)

    def test_aether_with_unreadable_gauge_never_retries_f(self):
        self.e.target='Эфир';self.e.target_confirmed=True;self.e.mode='APPROACH'
        self.e.route_f_sent=True;self.e.route_active=True
        self.e._recover(self.frame,(0,0),obs('Эфир',distance=12),self.sky,100)
        self.e._recover(self.frame,(0,0),obs('Эфир',distance=12),self.sky,107)
        self.assertNotIn('TAP_F',self.commands);self.assertEqual(self.e.mode,'TAKEOFF')
        self.assertTrue(self.e.wing_route_restart_pending)

    def test_distance_ocr_jitter_does_not_reset_wall_timer_forever(self):
        self.e.mode='APPROACH';self.e.target='Сапфир';self.e.target_confirmed=True;self.e.started=99
        for now,distance in [(100,12),(101,13),(102,12),(103,13),(107,12)]:
            self.step(obs('Сапфир',distance=distance),now,plate=3)
        self.assertEqual(self.e.mode,'TAKEOFF');self.assertIn('V',self.commands)

    def test_close_node_without_confirmed_gather_does_not_toggle_wings(self):
        self.e.mode='APPROACH';self.e.target='Сапфир';self.e.target_confirmed=True;self.e.started=99
        self.step(obs('Сапфир',distance=2),100,plate=3)
        self.assertEqual(self.e.mode,'APPROACH')
        self.step(obs('Сапфир',distance=2),107,plate=3)
        self.assertEqual(self.e.mode,'APPROACH');self.assertNotIn('V',self.commands)
        self.assertNotIn('F_ON',self.commands)

    def test_abandoning_autopath_requests_manual_cancel_and_releases_sticks(self):
        self.e.mode='APPROACH';self.e.target='Сапфир';self.e.target_confirmed=True;self.e.reselected=True
        with patch.object(self.input,'drive',wraps=self.input.drive) as drive,patch.object(GamepadInput,'wait',return_value=True):
            self.e.return_to_search('bounded path timeout',reading=FlightReading(70,True))
            drive.assert_called_once_with(-.35,0,0,0,lifetime=.25)
        self.assertEqual(self.e.mode,'SEARCH');self.assertEqual(self.pad.axes,(0,0,0,0))
        self.assertNotIn('V',self.commands)

    def test_unverified_lingering_single_label_does_not_claim_collection_at_49m(self):
        self.e.mode='APPROACH';self.e.target='Сапфир';self.e.target_confirmed=True
        with patch.object(ge,'segment_count',return_value=3),patch.object(ge,'gathering_panel',return_value=True),patch.object(ge,'gathering_panel_pair',return_value=False):
            self.e.step(self.frame,(0,0),obs('Сапфир',distance=49),radar(),self.sky,100)
        self.assertEqual(self.e.mode,'APPROACH');self.assertNotIn('F_ON',self.commands)

    def test_takeoff_timeout_does_not_toggle_v_again(self):
        self.e.target='Сапфир';self.e.target_confirmed=True;self.e.jump_attempted=True
        self.e._recover(self.frame,(0,0),obs('Сапфир',distance=12),self.sky,100)
        self.assertEqual(self.e.mode,'TAKEOFF');self.e.started=100
        self.step(obs('Сапфир',distance=12),105,plate=3)
        self.assertEqual(self.commands.count('V'),1);self.assertEqual(self.e.mode,'SEARCH')

    def test_dry_run_never_presses_a(self):
        self.e.cfg['dry_run']=True
        self.e.click_candidate(self.c,(0,0),refresh=False)
        self.assertEqual(self.pad.presses,0);self.assertEqual(self.commands,[])

    def test_old_ocr_result_cannot_undo_new_a_selection(self):
        self.e.identity_valid_after=100
        old=self.e.current_observation(obs('Сапфир',distance=1),99)
        self.assertIsNone(old.target_name)
        fresh=self.e.current_observation(obs('Эфир',distance=20),101)
        self.assertEqual(fresh.target_name,'Эфир')

    def test_visible_gather_blocks_search_even_when_old_ocr_and_slot_counter_miss(self):
        self.e.mode='GATHER';self.e.target='Сапфир';self.e.target_confirmed=True;self.e.f_on=True;self.e.started=99
        self.e.observation_captured_at=99
        self.step(obs('Сапфир',distance=1),100,plate=None,panel=True)
        self.step(obs('Сапфир',distance=1),101,plate=None,panel=True)
        self.assertEqual(self.e.mode,'GATHER');self.assertNotIn('F_OFF',self.commands)
        self.step(obs('Сапфир',distance=1),102,plate=None,panel=False)
        self.assertEqual(self.e.mode,'GATHER');self.assertNotIn('F_OFF',self.commands)
        self.step(obs(),102.8,plate=None,panel=False)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIn('F_OFF',self.commands)


if __name__=='__main__':unittest.main()
