"""Windows API contract tests; no OS setting is changed by this test suite."""
import ctypes,unittest
from types import SimpleNamespace
from background_runtime import BackgroundRuntime,PowerState

class Call:
 def __init__(self,fn):self.fn=fn;self.calls=[]
 def __call__(self,*a):self.calls.append(a);return self.fn(*a)
class Kernel:
 def __init__(self,priority=0x4000,power=(1,1,1),allow=True,query=True):
  self.priority=priority;self.power=power;self.allow=allow;self.query=query
  self.GetCurrentProcess=Call(lambda:123)
  self.GetPriorityClass=Call(lambda handle:self.priority)
  self.SetPriorityClass=Call(self.priority_set)
  self.GetProcessInformation=Call(self.power_get);self.SetProcessInformation=Call(self.power_set)
 def priority_set(self,handle,value):
  if self.allow:self.priority=value
  return self.allow
 def power_get(self,handle,kind,ptr,size):
  assert handle==123 and kind==4 and size==12
  if not self.query:return False
  ptr._obj.Version,ptr._obj.ControlMask,ptr._obj.StateMask=self.power;return True
 def power_set(self,handle,kind,ptr,size):
  assert handle==123 and kind==4 and size==12
  if self.allow:self.power=(ptr._obj.Version,ptr._obj.ControlMask,ptr._obj.StateMask)
  return self.allow

class ProcessContract(unittest.TestCase):
 def test_win32_power_structure_has_exact_twelve_byte_layout(self):self.assertEqual(ctypes.sizeof(PowerState),12)
 def test_low_priority_and_execution_throttle_are_changed_then_restored(self):
  k=Kernel();r=BackgroundRuntime(kernel=k);r.start()
  self.assertEqual(k.priority,0x20);self.assertEqual(k.power,(1,1,0))
  r.close();self.assertEqual(k.priority,0x4000);self.assertEqual(k.power,(1,1,1))
 def test_other_power_bits_are_preserved(self):
  k=Kernel(power=(1,3,3));r=BackgroundRuntime(kernel=k);r.start()
  self.assertEqual(k.power,(1,3,2));r.close();self.assertEqual(k.power,(1,3,3))
 def test_normal_and_higher_priorities_are_not_changed(self):
  for priority in (0x20,0x8000,0x80,0x100):
   k=Kernel(priority);r=BackgroundRuntime(kernel=k);r.start();r.close()
   self.assertFalse(k.SetPriorityClass.calls)
 def test_denied_changes_are_not_reported_as_applied_or_restored(self):
  k=Kernel(allow=False);messages=[];r=BackgroundRuntime(messages.append,k);r.start()
  self.assertIsNone(r.old_priority);self.assertIsNone(r.old_power);r.close()
  self.assertEqual(k.priority,0x4000);self.assertEqual(k.power,(1,1,1))
  self.assertTrue(any('отключено=False' in m for m in messages))
 def test_unsupported_power_api_does_not_block_priority_cleanup(self):
  k=Kernel(query=False);r=BackgroundRuntime(kernel=k);r.start();r.close()
  self.assertEqual(k.priority,0x4000);self.assertFalse(k.SetProcessInformation.calls)
 def test_later_explicit_external_changes_are_not_overwritten(self):
  k=Kernel();r=BackgroundRuntime(kernel=k);r.start();k.priority=0x80;k.power=(1,3,2);r.close()
  self.assertEqual(k.priority,0x80);self.assertEqual(k.power,(1,3,2))
 def test_idempotent_start_close_and_reuse_do_not_duplicate_restores(self):
  k=Kernel();r=BackgroundRuntime(kernel=k);r.start();r.start();r.close();r.close()
  self.assertEqual(len(k.SetPriorityClass.calls),2);self.assertEqual(len(k.SetProcessInformation.calls),2)
  r.start();r.close();self.assertEqual(len(k.SetPriorityClass.calls),4)
