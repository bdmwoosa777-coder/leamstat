@echo off
chcp 65001 >nul
cd /d "%~dp0"
call RUN_PYTHON.bat check_qwen_experiment.py
pause
