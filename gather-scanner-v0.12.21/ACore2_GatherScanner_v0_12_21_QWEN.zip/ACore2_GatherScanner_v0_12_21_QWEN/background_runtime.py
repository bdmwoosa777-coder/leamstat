"""Reversible Windows process hints; no realtime priority or system settings."""
import ctypes,os

class PowerState(ctypes.Structure):
 _fields_=[('Version',ctypes.c_uint32),('ControlMask',ctypes.c_uint32),('StateMask',ctypes.c_uint32)]

class BackgroundRuntime:
 def __init__(self,emit=lambda message:None,kernel=None):
  self.emit=emit;self.kernel=kernel;self.started=False;self.process=None
  self.old_priority=None;self.old_power=None;self.applied_power=None
 def _power(self):
  value=PowerState(1,0,0)
  if not self.kernel.GetProcessInformation(self.process,4,ctypes.byref(value),ctypes.sizeof(value)):
   raise RuntimeError('GetProcessInformation не поддержан/отклонён')
  return value.Version,value.ControlMask,value.StateMask
 def _set_power(self,value):
  state=PowerState(*value)
  return bool(self.kernel.SetProcessInformation(self.process,4,ctypes.byref(state),ctypes.sizeof(state)))
 def start(self):
  if self.started:return
  self.started=True
  if self.kernel is None:
   if os.name!='nt':return
   self.kernel=ctypes.WinDLL('kernel32',use_last_error=True)
  from ctypes import wintypes
  k=self.kernel
  try:
   k.GetCurrentProcess.restype=wintypes.HANDLE;self.process=k.GetCurrentProcess()
   k.GetPriorityClass.argtypes=[wintypes.HANDLE];k.GetPriorityClass.restype=ctypes.c_uint32
   k.SetPriorityClass.argtypes=[wintypes.HANDLE,ctypes.c_uint32];k.SetPriorityClass.restype=ctypes.c_int
   priority=k.GetPriorityClass(self.process);applied=False
   if priority in (0x40,0x4000):
    applied=bool(k.SetPriorityClass(self.process,0x20))
    if applied:self.old_priority=priority
   self.emit('OS_BACKGROUND: PID='+str(os.getpid())+'; класс приоритета='+hex(priority)+'; NORMAL применён='+str(applied))
  except Exception as exc:self.emit('OS_BACKGROUND: приоритет не изменён: '+str(exc))
  try:
   k.GetProcessInformation.argtypes=[wintypes.HANDLE,ctypes.c_int,ctypes.c_void_p,ctypes.c_uint32]
   k.GetProcessInformation.restype=ctypes.c_int
   k.SetProcessInformation.argtypes=k.GetProcessInformation.argtypes;k.SetProcessInformation.restype=ctypes.c_int
   original=self._power()
   if original[0]!=1:raise RuntimeError('неизвестная версия PowerThrottling')
   wanted=(1,original[1]|1,original[2]&~1)
   applied=wanted==original or self._set_power(wanted)
   if wanted!=original and applied:self.old_power=original;self.applied_power=wanted
   self.emit('OS_BACKGROUND: PowerThrottling до='+str(original[1:])+'; ограничение скорости отключено='+str(applied))
  except Exception as exc:self.emit('OS_BACKGROUND: PowerThrottling не изменён: '+str(exc))
 def close(self):
  if self.old_power is not None:
   original=self.old_power;self.old_power=None
   try:
    if self._power()==self.applied_power:self._set_power(original)
   except Exception as exc:self.emit('OS_BACKGROUND: восстановление PowerThrottling: '+str(exc))
  if self.old_priority is not None:
   original=self.old_priority;self.old_priority=None
   try:
    # A later explicit priority change by another program wins.
    if self.kernel.GetPriorityClass(self.process)==0x20:self.kernel.SetPriorityClass(self.process,original)
   except Exception as exc:self.emit('OS_BACKGROUND: восстановление приоритета: '+str(exc))
  self.started=False
