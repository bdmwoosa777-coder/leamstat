"""Known interface text is not an Ether acquisition target."""
import unittest
from dataclasses import replace
from unittest.mock import patch
import numpy as np
import hybrid_engine as he
import test_camp_departure as fixtures
from scene_navigation import near_water_fraction,SceneReading,Lane

class UiCaption(unittest.TestCase):
 def setUp(self):
  self.f=fixtures.DepartureControl('test_existing_map_ether_does_not_prevent_initial_departure');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  mask=np.zeros((16,64),np.uint8);mask[3:13,4:10]=255;mask[6:13,12:29]=255
  self.c=replace(self.f.c,name='Эфир',glyph=(mask.shape,mask.tobytes()))
 def test_logged_enter_caption_is_rejected_before_any_a_and_remembered(self):
  with patch.object(he,'read_world_caption',return_value=(None,'Войти')):
   self.assertFalse(self.e._acquire_caption_matches(self.f.frame,self.c))
  self.assertEqual(self.f.pad.presses,0);self.assertTrue(self.e._caption_rejected(self.c))
 def test_known_interface_labels_are_rejected_even_with_punctuation(self):
  for text in (' Войти! ','Отмена','Закрыть'):
   self.e.caption_memory.entries=()
   with patch.object(he,'read_world_caption',return_value=(None,text)):
    self.assertFalse(self.e._acquire_caption_matches(self.f.frame,self.c))
 def test_unreadable_real_caption_keeps_existing_body_path(self):
  with patch.object(he,'read_world_caption',return_value=(None,'')):
   self.assertTrue(self.e._acquire_caption_matches(self.f.frame,self.c))
 def test_confirmed_ether_is_not_rejected(self):
  with patch.object(he,'read_world_caption',return_value=('Эфир','Эфир')):
   self.assertTrue(self.e._acquire_caption_matches(self.f.frame,self.c))

 def test_actual_initial_acquisition_aborts_before_gamepad_a_for_enter(self):
  from gamepad_input import GamepadInput
  with patch.object(he,'read_world_caption',return_value=(None,'Войти')),patch.object(GamepadInput,'wait',return_value=True),patch.object(self.f.input,'tap_a',side_effect=AssertionError('UI must not receive acquisition A')):
   self.assertFalse(self.e.click_candidate(self.c,(0,0),refresh=False))
  self.assertEqual(self.f.pad.presses,0)

class SurfaceDiagnostic(unittest.TestCase):
 def test_water_fraction_uses_nearby_world_region_not_minimap_or_sky(self):
  groups=np.zeros((100,100),np.uint8);groups[:30]=3;groups[:,85:]=3
  self.assertEqual(near_water_fraction(groups),0)
  groups[49:79,30:70]=3;self.assertEqual(near_water_fraction(groups),1)
 def test_existing_scene_callers_default_water_evidence_to_zero(self):
  self.assertEqual(SceneReading(0,0,0,1,(Lane(1,0,0,0),)*3).water,0)
