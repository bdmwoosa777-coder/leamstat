-- ACore2 Gather Scanner v0.10.2: ISOLATED G HUB profile.
-- DO NOT install over GHUB_AION2_SCANNER_V26.lua or existing PUBG macros.
-- Physically click G9 once while AION2 profile active to arm receiver.
-- Python sends 4 ScrollLock rising-edge strobes: SOF(3), HI, LO, CHECK.
-- Commands: 0 PING, 1 ALT_DOWN, 2 TAB, 3 ALT_UP,
-- 4 F_ON, 5 F_OFF, 6 V, 7 STOP, 8 ATTACK_PAIR ], 9 END_AIR (F off + V), 10 TAP_F.
-- v0.10.2: 11/12 are map-list wheel down/up. Legacy step names in Python
-- remain wire aliases; these codes never press W/A/D. 13 arms map UI after Python verifies its title.
-- 14 JUMP. Navigation/camera now use the virtual Xbox sticks from Python.
-- 15 MAP: toggle M only when F and Alt are not held.

local G9=9
local POLL_MS=12
local RX_GAP_MS=850
local WATCHDOG_MS=6500
local MAX_IDLE_MS=1800000
local F_INTERVAL_MS=1000
local F_HOLD_MS=85
local DOUBLE_CLICK_GAP_MS=105
local CAMERA_STEP=160
local WALK_STEP_MS=430
local STRAFE_STEP_MS=220
local running=false

local function receiver()
    local prev=IsKeyLockOn("scrolllock")
    local phase=0
    local hi=0
    local lo=0
    local last_edge=GetRunningTime()
    local last_rx=last_edge
    local last_f=last_rx
    local last_f_press=-1
    local attack_remaining=0
    local attack_held=false
    local attack_at=0
    local attack_release=0
    local f_enabled=false
    local alt_held=false
    local num_commands=0
    local map_context=false
    local receiver_active=true
    local walking_key=nil
    local walking_release_ms=-1

    local function release_all()
        map_context=false
        if last_f_press>=0 then ReleaseKey("f");last_f_press=-1 end
        if alt_held then ReleaseKey("lalt");alt_held=false end
        f_enabled=false
        attack_remaining=0
        if attack_held then ReleaseKey(0x1b);attack_held=false end
        if walking_key then ReleaseKey(walking_key);walking_key=nil;walking_release_ms=-1 end
    end

    local function dispatch(cmd)
        num_commands=num_commands+1
        if cmd~=0 then
            OutputLogMessage("[GATHER RX] t=%d cmd=%d alt=%s f=%s\n",
                GetRunningTime(),cmd,tostring(alt_held),tostring(f_enabled))
        end
        if cmd==0 then
            -- Heartbeat; watchdog counts all validated commands.
        elseif cmd==1 then
            if not alt_held then PressKey("lalt");alt_held=true end
        elseif cmd==2 then
            if not alt_held and not f_enabled then PressKey("tab");Sleep(70);ReleaseKey("tab") end
        elseif cmd==3 then
            if alt_held then ReleaseKey("lalt");alt_held=false end
        elseif cmd==4 then
            f_enabled=true
            last_f=GetRunningTime()-F_INTERVAL_MS -- first F immediately
        elseif cmd==5 then
            f_enabled=false
            if last_f_press>=0 then ReleaseKey("f");last_f_press=-1 end
        elseif cmd==6 then
            if not alt_held then PressKey("v");Sleep(70);ReleaseKey("v") end
        elseif cmd==7 then
            release_all()
            OutputLogMessage("[GATHER STOP] F/ALT released; receiver remains armed for next Ctrl+F8\n")
        elseif cmd==8 then
            if not alt_held and not f_enabled and attack_remaining==0 and not attack_held then
                attack_remaining=2
                attack_at=GetRunningTime()
            end
        elseif cmd==9 then
            release_all()
            PressKey("v");Sleep(70);ReleaseKey("v")
        elseif cmd==10 then
            if last_f_press<0 and not alt_held then
                PressKey("f");last_f_press=GetRunningTime()
            end
        elseif cmd==11 or cmd==12 then
            if map_context and not alt_held and not f_enabled then
                MoveMouseWheel(cmd==11 and -3 or 3)
            end
        elseif cmd==13 then
            if not alt_held and not f_enabled then map_context=true end
            -- No legacy keyboard movement.
        elseif cmd==14 then
            if not alt_held then PressKey("space");Sleep(70);ReleaseKey("space") end
        elseif cmd==15 then
            if not alt_held and not f_enabled then
                PressKey("m");Sleep(70);ReleaseKey("m");map_context=not map_context
            end
        end
        if num_commands<=6 or num_commands%30==0 then
            OutputLogMessage("[GATHER] cmd=%d total=%d F=%s\n",cmd,num_commands,tostring(f_enabled))
        end
    end

    OutputLogMessage("[GATHER] G9 ARMED; F=%dms; protocol=4-strobe\n",F_INTERVAL_MS)
    while receiver_active do
        local now=GetRunningTime()
        if attack_held and now>=attack_release then
            ReleaseKey(0x1b);attack_held=false
        end
        if attack_remaining>0 and not attack_held and now>=attack_at and not alt_held and not f_enabled then
            PressKey(0x1b);attack_held=true
            attack_release=now+85
            attack_at=now+350
            attack_remaining=attack_remaining-1
        end
        if walking_key and now>=walking_release_ms then
            ReleaseKey(walking_key)
            walking_key=nil
            walking_release_ms=-1
        end
        if last_f_press>=0 and now-last_f_press>=F_HOLD_MS then
            ReleaseKey("f");last_f_press=-1
        end
        if now-last_rx>WATCHDOG_MS then
            if f_enabled or alt_held or attack_held or attack_remaining>0 then
                release_all()
                OutputLogMessage("[GATHER] WATCHDOG: released F/ALT\n")
            end
        end
        if now-last_rx>MAX_IDLE_MS then break end
        if phase~=0 and now-last_edge>RX_GAP_MS then phase=0 end
        local scroll=IsKeyLockOn("scrolllock")
        if scroll and not prev then
            local code=(IsKeyLockOn("capslock") and 2 or 0)+
                       (IsKeyLockOn("numlock") and 1 or 0)
            last_edge=GetRunningTime()
            if phase==0 then
                if code==3 then phase=1 end
            elseif phase==1 then
                hi=code;phase=2
            elseif phase==2 then
                lo=code;phase=3
            elseif phase==3 then
                phase=0
                local expected=(hi+2*lo+1)%4
                local value=hi*4+lo
                if code==expected and value<=15 then
                    last_rx=GetRunningTime()
                    dispatch(value)
                else
                    OutputLogMessage("[GATHER] bad frame/checksum: %d,%d,%d\n",hi,lo,code)
                end
            end
        end
        prev=scroll
        now=GetRunningTime()
        if f_enabled and not alt_held and last_f_press<0 and now-last_f>=F_INTERVAL_MS then
            PressKey("f");last_f_press=now;last_f=now
        end
        Sleep(POLL_MS)
    end
    release_all()
    OutputLogMessage("[GATHER] receiver finished\n")
end

function OnEvent(event,arg)
    if event=="MOUSE_BUTTON_PRESSED" and arg==G9 then
        receiver()
    end
end
