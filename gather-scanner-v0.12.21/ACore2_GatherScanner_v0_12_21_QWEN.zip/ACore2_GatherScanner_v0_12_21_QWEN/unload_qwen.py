"""Unload only the configured experiment model; never uninstall anything."""
from pathlib import Path
import json
from qwen_experiment import MODEL,TemporalClient

def main():
 root=Path(__file__).resolve().parent
 cfg=json.loads((root/'settings_gather.json').read_text(encoding='utf-8'))
 client=TemporalClient(cfg.get('analyzer_url','http://127.0.0.1:11434'),cfg.get('qwen_model',MODEL))
 try:client.unload();print('Выгружена из памяти: '+client.model+'. Файлы модели сохранены.');return 0
 except Exception as exc:print('Не удалось подтвердить выгрузку:',exc);return 1
if __name__=='__main__':raise SystemExit(main())
