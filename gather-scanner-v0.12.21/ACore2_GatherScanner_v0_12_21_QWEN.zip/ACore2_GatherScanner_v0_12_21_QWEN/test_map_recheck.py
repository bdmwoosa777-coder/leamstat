"""Retry recognition only before input; never repeat ambiguous confirmations."""
import unittest
from unittest.mock import patch
import gather_engine as ge
import test_map_teleport as fixtures
from map_teleport import MapTeleport,MapObservation,menu_stamp
from gamepad_input import GamepadInput
from test_patrol import GROUND

class BeforeInput(unittest.TestCase):
 def test_row_preflight_failure_rearms_discovery_before_any_click(self):
  t=MapTeleport(100);t.step(100,MapObservation(True,row=(100,500)))
  self.assertEqual(t.phase,'WAIT_ROW');t.retry_unissued('ROW',101,'row unreadable')
  self.assertEqual(t.phase,'FIND');self.assertEqual(t.clicks,0);self.assertFalse(t.used)
  self.assertEqual(t.step(102,MapObservation(True,row=(100,510))).kind,'ROW')
 def test_rechecks_have_a_global_finite_limit(self):
  t=MapTeleport(100)
  for i in range(4):t.retry_unissued('ROW',101+i,'unreadable')
  self.assertEqual(t.phase,'FAILED');self.assertEqual(t.ui_rechecks,4)
 def test_unissued_first_confirmation_can_be_revalidated(self):
  t=MapTeleport(100);o=MapObservation(True,popup=True,destination=t.destination,confirm=(1000,500))
  self.assertEqual(t.step(100,o).kind,'CONFIRM');t.retry_unissued('CONFIRM',101,'changed popup')
  self.assertFalse(t.used);self.assertEqual(t.step(102,o).kind,'CONFIRM')
 def test_unissued_modal_does_not_repeat_already_sent_first_confirmation(self):
  t=MapTeleport(100);t.phase='WAIT_TRANSFER';t.used=True;t.dialog_used=True
  t.retry_unissued('CONFIRM_DIALOG',101,'modal unclear')
  self.assertTrue(t.used);self.assertFalse(t.dialog_used);self.assertEqual(t.phase,'WAIT_TRANSFER')

class EngineRecheck(unittest.TestCase):
 def setUp(self):
  self.f=fixtures.MapEngine('test_start_never_uses_the_nearest_scroll');self.f.setUp();self.f.start()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
  self.e=self.f.e;self.f.frame=fixtures.map_frame();self.e.map_menu_stamp=menu_stamp(self.f.frame)
  self.e.map_teleport.phase='FIND'
 def tick(self,observations,now=102):
  with patch.object(ge,'observe_map',side_effect=observations),patch.object(ge.time,'monotonic',return_value=now),patch.object(GamepadInput,'wait',return_value=True):
   self.e._map_teleport_tick(self.f.frame,GROUND,now)
 def test_transient_unreadable_row_keeps_map_open_without_a(self):
  self.tick([MapObservation(True,row=(100,500)),MapObservation(True)])
  self.assertEqual(self.f.pad.presses,0);self.assertEqual(self.e.map_teleport.phase,'FIND')
  self.assertNotIn('MAP',self.f.commands);self.assertEqual(self.e.map_teleport.ui_rechecks,1)
 def test_row_stabilizing_on_next_frame_can_be_clicked_once(self):
  self.tick([MapObservation(True,row=(100,500)),MapObservation(True)])
  self.tick([MapObservation(True,row=(100,510)),MapObservation(True,row=(100,510))],103)
  self.assertEqual(self.f.pad.presses,1);self.assertEqual(self.e.map_teleport.phase,'WAIT_ROW')
 def test_fresh_row_check_reuses_verified_map_and_list_only_recognition(self):
  calls=[]
  def observe(*a,**kw):calls.append(kw);return MapObservation(True,row=(100,500))
  with patch.object(ge,'observe_map',side_effect=observe),patch.object(ge.time,'monotonic',return_value=102),patch.object(GamepadInput,'wait',return_value=True):
   self.e._map_teleport_tick(self.f.frame,GROUND,102)
  self.assertTrue(calls[-1]['verified_map']);self.assertTrue(calls[-1]['list_only'])
 def test_ambiguous_a_delivery_is_not_retried(self):
  with patch.object(self.f.input,'tap_ui_a',return_value=False):
   self.tick([MapObservation(True,row=(100,500)),MapObservation(True,row=(100,500))])
  self.assertEqual(self.e.map_teleport.phase,'FAILED');self.assertEqual(self.e.map_teleport.ui_rechecks,0)
