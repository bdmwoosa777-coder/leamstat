VultrVPNFinder 2.7 — Windows 11, HY2 + VLESS Reality

1. Распакуйте архив целиком в отдельную папку. Нужен Python 3.10+ и компонент Windows «Клиент OpenSSH» (ssh, scp, ssh-keygen). Сторонние Python-пакеты программе не нужны.

2. Включите рабочий профиль в v2rayN. В config.json указан SOCKS 127.0.0.1:10808 и физический шлюз 192.168.0.1 — это параметры из присланной переписки. Если порт другой, измените management_socks_port; значение 0 включает поиск. Если роутер другой, задайте gateway="auto" либо его IPv4. direct_interface_index обычно оставляют null.

3. Откройте PowerShell от имени администратора, перейдите в распакованную папку и выполните:

   $env:VULTR_API_KEY="ВАШ_КЛЮЧ"
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\check.ps1

   check.ps1 проверяет каталог Vultr, тариф, шлюз, SSH-ключ и серверную конфигурацию Xray; скачивает и проверяет необходимые бинарники. VPS он не создаёт и ничего в Vultr не изменяет. Первое скачивание Windows Xray, Linux Xray и Hysteria занимает время; затем используется кэш bin/.

4. Если CHECK PASSED, в том же окне:

   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_visible.ps1

   Обычный запуск может создать один платный VPS. В конфиге оставлены good_target=1, max_total_attempts=1, provision_pipeline_size=1. Массовый поиск не включён.

Что должно появиться в логе:

   Generated Linux cloud-config preflight OK
   Created ... autonomous_user_data=cloud-config
   Instance READY
   Bootstrap ... DOWNLOAD_ATTEMPT_1 / XRAY_CONFIG_TEST / READY

Если установка с GitHub не подтвердилась, включается резерв с ПК:

   SOCKS relay 127.0.0.1:... -> v2rayN 127.0.0.1:10808 -> VPS:22
   Local-PC bootstrap: trying SSH via VPN/SOCKS-RELAY
   Local-PC bootstrap SUCCESS ...

Потом идут два реальных раунда HTTP через HY2 и VLESS с прямым /32-маршрутом. GOOD_DIRECT требует успешной проверки хотя бы одного протокола в обоих раундах. Ссылки импорта сохраняются в logs/good_servers.json, все результаты — в logs/all_candidates.csv.

Основные изменения:

- Вместо shell user-data — #cloud-config с package_update=false и package_upgrade=false. Установка запускается отдельной задачей systemd, чтобы не держать cloud-final.
- Windows ssh/scp подключаются к локальному TCP-реле. ProxyCommand, .cmd-переходник и буферизация stdin больше не используются.
- SSH через SOCKS ожидается до 60 секунд, напрямую — до 25. Отказ в доступе по ключу выводится отдельно от таймаута. Сбой скачивания на VPS не отменяет резервную установку с ПК.
- GitHub и SCP используют один установщик и блокировку финальной установки. Поздний загрузчик не перезаписывает уже работающий сервер.
- Xray и HTTP-диагностика устанавливаются как постоянные службы systemd. Они запускаются после перезагрузки; Xray перезапускается при аварии.
- HEALTH.json подтверждает именно текущую конфигурацию, а не оставшийся от прошлой попытки файл READY.
- Проверки curl требуют успешного завершения команды и HTTP 2xx/3xx. HTTP 407 и ошибки передачи больше не засчитываются.
- Контрольный VLESS действительно идёт через найденный SOCKS. HY2 использует UDP: TCP-реле его не переносит. Параметр existing_vpn_uses_tun=true ставьте только при реально включённом TUN. По умолчанию HY2-контроль помечается как непроверенный системный маршрут.
- /32-маршрут привязан к физическому интерфейсу. Программа удаляет только свой записанный маршрут; чужой маршрут не заменяет.
- Ключи и данные кандидата записываются до запроса создания. Неопределённый результат POST не вызывает повторное создание VPS. При перезапуске используется сохранённый кандидат, без создания нового VPS в этом прогоне.
- GOOD защищён по state.json, сохранённым результатам и метке в API. Ошибка записи CSV не превращает GOOD в BAD. Ошибки установки сохраняются для диагностики (delete_setup_failed=false).
- SSH-ключ создаётся в keys/id_ed25519 и применяется при создании VPS. Можно указать свой ssh_private_key/ssh_public_key в config.json. Сохраняйте keys/, state.json и logs/ между запусками этой версии.
- Xray 26.6.27 и Hysteria 2.13.0 закреплены по версии и SHA256. Минимальные 2 ТБ в каталоге проверяются как 2000 ГБ.

Другие команды из папки программы:

   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\self_test.ps1
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_hidden.ps1
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\watch_log.ps1
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\stop.ps1
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\collect_diagnostics.ps1

stop.ps1 запрашивает штатную остановку. Текущая SSH/SCP/API-операция имеет ограниченный таймаут; остановка может произойти не мгновенно. Тестовый VPS сохраняется для продолжения. Службы на GOOD продолжают работать.

Если GOOD не появился, выполните collect_diagnostics.ps1 и пришлите diagnostics.zip. В него входят логи и краткие сведения о состоянии; state.json, SSH-ключи и файлы с доступами в архив диагностики не включаются.

Старая версия 2.5 не сохраняла ключи каждого кандидата. Автоматическое продолжение предусмотрено для кандидатов, сохранённых этой версией 2.7. VPS из прежних попыток остаются в вашем аккаунте; их состояние нельзя восстановить только из данного исходного ZIP.

Что проверено при подготовке сборки: см. TEST_REPORT_RU.txt. Полный запуск на Windows 11 с вашим аккаунтом Vultr требует проверки у вас.
