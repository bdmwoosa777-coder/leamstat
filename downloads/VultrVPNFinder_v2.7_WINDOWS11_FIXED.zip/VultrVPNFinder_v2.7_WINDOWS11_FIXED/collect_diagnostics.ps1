﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'common.ps1')
$pythonPath = Get-FinderPython
& $pythonPath (Join-Path $PSScriptRoot 'finder.py') --diagnostics
exit $LASTEXITCODE
