"""Exercise real Xray/Hysteria binaries on loopback. No Vultr account is used.

python tests/protocol_smoke.py --xray /path/to/xray --hysteria /path/to/hysteria
"""
from __future__ import annotations

import argparse
import contextlib
import http.server
import json
import os
from pathlib import Path
import socket
import socketserver
import ssl
import subprocess
import sys
import tempfile
import threading
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import finder
from net_helpers import serve, SocksHandler


def free_port(kind=socket.SOCK_STREAM):
    with socket.socket(socket.AF_INET, kind) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class Origin(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        self.server.requests += 1
        self.send_response(204)
        self.end_headers()

    def log_message(self, *args):
        pass


class TLSTarget(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(3)
        try:
            with self.server.tls_context.wrap_socket(self.request, server_side=True) as conn:
                if conn.recv(8192):
                    conn.sendall(b"HTTP/1.1 200 OK\r\nContent-Length: 2\r\nConnection: close\r\n\r\nOK")
        except (OSError, ssl.SSLError):
            pass


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--xray", type=Path, required=True)
    parser.add_argument("--hysteria", type=Path, required=True)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    f = finder.Finder.__new__(finder.Finder)
    f.cfg = json.loads(finder.CONFIG_PATH.read_text(encoding="utf-8-sig"))
    f.cfg.update(http_tests_per_protocol_per_round=2, client_start_timeout_sec=5, http_max_time_sec=2)
    f.xray_exe, f.hy_exe = args.xray.resolve(), args.hysteria.resolve()
    private, public = f.x25519()
    c = {"attempt": 1, "hy_auth": "loopback-test-only", "vless_uuid": "0edfe929-d2a6-4740-90f1-dda669c0d2e6",
         "short_id": "0123456789abcdef", "reality_private": private, "reality_public": public,
         "reality_sni": "www.example.com", "fingerprint": "firefox"}
    original_run = finder.run
    def native_run(cmd, **kwargs):
        cmd = [("curl" if arg == "curl.exe" else os.devnull if arg == "NUL" else arg) for arg in cmd]
        return original_run(cmd, **kwargs)
    with tempfile.TemporaryDirectory(prefix="vpnfinder-protocols-") as td, contextlib.ExitStack() as stack:
        root = Path(td)
        stack.enter_context(patch.object(finder, "LOG_DIR", root))
        stack.enter_context(patch.object(finder, "run", side_effect=native_run))
        origin = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Origin)
        origin.requests = 0
        worker = threading.Thread(target=origin.serve_forever, daemon=True)
        worker.start()
        stack.callback(origin.server_close)
        stack.callback(origin.shutdown)
        f.cfg["test_urls"] = [f"http://127.0.0.1:{origin.server_port}/one", f"http://127.0.0.1:{origin.server_port}/two"]
        cert, key = root/"tls.crt", root/"tls.key"
        subprocess.run(["openssl", "req", "-x509", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:prime256v1",
                        "-nodes", "-keyout", str(key), "-out", str(cert), "-days", "1", "-subj", "/CN=www.example.com"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
        vl_port, hy_port = free_port(), free_port(socket.SOCK_DGRAM)
        log = stack.enter_context((root/"server.log").open("wb"))
        tls_context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        tls_context.minimum_version = ssl.TLSVersion.TLSv1_3
        tls_context.set_ecdh_curve("X25519")
        tls_context.load_cert_chain(cert, key)
        tls = stack.enter_context(serve(TLSTarget))
        tls.tls_context = tls_context
        tls_port = tls.server_address[1]
        config = f.xray_server_config(c)
        config["log"]["loglevel"] = "debug"
        # Xray 26.6.27 blocks private destinations by default. Permit only this
        # local origin in the test configuration; production keeps its defaults.
        config["outbounds"][0]["settings"] = {"finalRules": [
            {"action": "allow", "network": "tcp", "ip": ["127.0.0.1/32"], "port": origin.server_port}
        ]}
        config["inbounds"][0]["port"] = hy_port
        config["inbounds"][1]["port"] = vl_port
        for inbound in config["inbounds"]:
            inbound["listen"] = "127.0.0.1"
        tls_settings = config["inbounds"][0]["streamSettings"]["tlsSettings"]
        tls_settings["certificates"] = [{"certificateFile": str(cert), "keyFile": str(key)}]
        config["inbounds"][1]["streamSettings"]["realitySettings"]["dest"] = f"127.0.0.1:{tls_port}"
        config_path = root/"server.json"
        config_path.write_text(json.dumps(config))
        cp = original_run([str(f.xray_exe), "run", "-test", "-config", str(config_path)], timeout=20)
        if cp.returncode:
            raise RuntimeError(finder.decode_output(cp.stdout))
        server = subprocess.Popen([str(f.xray_exe), "run", "-config", str(config_path)], stdout=log, stderr=log)
        stack.callback(f.stop_client, server)
        if not f.wait_client(server, vl_port):
            raise RuntimeError("Local Xray server did not start")
        report = {}
        report["hy2"] = f.test_hy2(c, "127.0.0.1", server_port=hy_port)
        report["vless"] = f.test_vless(c, "127.0.0.1", server_port=vl_port)
        with serve(SocksHandler) as proxy:
            report["vless_via_existing_socks"] = f.test_vless(c, "127.0.0.1", upstream_socks_port=proxy.server_address[1], server_port=vl_port)
            report["socks_connects"] = len(proxy.targets)
        expected_count = origin.requests
        f.cfg.update(client_start_timeout_sec=2, http_max_time_sec=2)
        wrong = dict(c, vless_uuid="bfe09a49-20e6-4f22-b993-b5ba6e80656d", hy_auth="wrong-password")
        report["wrong_vless_credentials"] = f.test_vless(wrong, "127.0.0.1", tests_override=1, server_port=vl_port)
        report["wrong_hy2_credentials"] = f.test_hy2(wrong, "127.0.0.1", tests_override=1, server_port=hy_port)
        report["origin_requests"] = origin.requests
        report["passed"] = (all(report[k]["ok"] == 2 for k in ("hy2", "vless", "vless_via_existing_socks")) and
                            report["socks_connects"] >= 1 and expected_count == 6 and origin.requests == expected_count and
                            report["wrong_vless_credentials"]["ok"] == 0 and report["wrong_hy2_credentials"]["ok"] == 0)
        if not report["passed"]:
            for path in root.glob("*.log"):
                print(path.name, path.read_text(errors="replace")[-6000:])
        print(json.dumps(report, indent=2))
        if args.report:
            args.report.parent.mkdir(parents=True, exist_ok=True)
            args.report.write_text(json.dumps(report, indent=2)+"\n")
        return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
