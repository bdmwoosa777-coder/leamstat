"""Real OpenSSH/SFTP through the relay on loopback; optional test dependency: paramiko==4.0.0.

This is a development check, separate from the stdlib-only --self-test.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import socketserver
import subprocess
import sys
import tempfile
import threading
import time
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import paramiko
import finder
from socks_relay import SocksRelay
from net_helpers import serve, SocksHandler


class FileHandle(paramiko.SFTPHandle):
    def stat(self):
        return paramiko.SFTPAttributes.from_stat(os.fstat(self.writefile.fileno()))

    def chattr(self, attr):
        return paramiko.SFTP_OK


class FileServer(paramiko.SFTPServerInterface):
    def __init__(self, server, *args, **kwargs):
        super().__init__(server, *args, **kwargs)
        self.root = server.root

    def local(self, path):
        return self.root / Path(path).name

    def stat(self, path):
        try:
            return paramiko.SFTPAttributes.from_stat(self.local(path).stat())
        except OSError as exc:
            return paramiko.SFTPServer.convert_errno(exc.errno)

    lstat = stat

    def open(self, path, flags, attr):
        try:
            fd = os.open(self.local(path), flags, 0o600)
            mode = "r+b" if flags & os.O_RDWR else "wb" if flags & os.O_WRONLY else "rb"
            fp = os.fdopen(fd, mode)
            handle = FileHandle(flags)
            handle.readfile = handle.writefile = fp
            return handle
        except OSError as exc:
            return paramiko.SFTPServer.convert_errno(exc.errno)

    def chattr(self, path, attr):
        return paramiko.SFTP_OK


class Authentication(paramiko.ServerInterface):
    def __init__(self, root, public):
        self.root, self.public = root, public

    def get_allowed_auths(self, username):
        return "publickey"

    def check_auth_publickey(self, username, key):
        return paramiko.AUTH_SUCCESSFUL if username == "root" and key.get_base64() == self.public else paramiko.AUTH_FAILED

    def check_channel_request(self, kind, chanid):
        return paramiko.OPEN_SUCCEEDED if kind == "session" else paramiko.OPEN_FAILED_ADMINISTRATIVELY_PROHIBITED

    def check_channel_exec_request(self, channel, command):
        if command != b"printf VPNFINDER_SSH_OK":
            return False
        def reply():
            time.sleep(0.03)
            channel.sendall(b"VPNFINDER_SSH_OK")
            channel.send_exit_status(0)
            channel.close()
        threading.Thread(target=reply, daemon=True).start()
        return True


class SFTPSubsystem(paramiko.SFTPServer):
    def finish_subsystem(self):
        self.sock.send_exit_status(0)
        super().finish_subsystem()


class SSHServer(socketserver.BaseRequestHandler):
    def handle(self):
        transport = paramiko.Transport(self.request)
        try:
            transport.add_server_key(self.server.host_key)
            transport.set_subsystem_handler("sftp", SFTPSubsystem, FileServer)
            transport.start_server(server=Authentication(self.server.root, self.server.public))
            while transport.is_active():
                time.sleep(0.02)
        finally:
            transport.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    f = finder.Finder.__new__(finder.Finder)
    f.cfg = json.loads(finder.CONFIG_PATH.read_text(encoding="utf-8-sig"))
    real_run = finder.run
    def native(cmd, **kwargs):
        cmd = [os.devnull if a == "NUL" else a.removesuffix(".exe") if a in ("ssh.exe", "scp.exe") else a for a in cmd]
        return real_run(cmd, **kwargs)
    with tempfile.TemporaryDirectory(prefix="vpnfinder ssh spaces-") as td:
        root = Path(td)
        f.ssh_private_key = root/"key with spaces"
        subprocess.run(["ssh-keygen", "-q", "-t", "ed25519", "-N", "", "-f", str(f.ssh_private_key)], check=True)
        public = Path(str(f.ssh_private_key)+".pub").read_text().split()[1]
        payload = bytes(range(256))*4096
        source = root/"payload with spaces.tgz"
        source.write_bytes(payload)
        sink = root/"remote"
        sink.mkdir()
        with serve(SSHServer) as ssh, serve(SocksHandler) as proxy:
            ssh.root, ssh.public, ssh.host_key = sink, public, paramiko.RSAKey.generate(2048)
            with SocksRelay(proxy.server_address[1], "127.0.0.1", ssh.server_address[1]) as relay:
                f.management_relay = relay
                with patch.object(finder, "run", side_effect=native):
                    ssh_ok = f._management_ssh_ready("192.0.2.55", explicit_socks=True)
                    cmd = f._management_scp_args("192.0.2.55", explicit_socks=True) + [source.name, "root@127.0.0.1:/tmp/upload.tgz"]
                    cp = finder.run(cmd, cwd=str(root), timeout=20)
                    if cp.returncode:
                        print(finder.decode_output(cp.stdout))
                received = (sink/"upload.tgz").read_bytes() if (sink/"upload.tgz").exists() else b""
                report = {"ssh_publickey_auth": ssh_ok, "scp_exit": cp.returncode,
                          "bytes": len(received), "sha256_match": hashlib.sha256(received).digest() == hashlib.sha256(payload).digest(),
                          "socks_connections": len(proxy.targets), "relay_errors": list(relay.errors)}
                report["passed"] = ssh_ok and cp.returncode == 0 and received == payload and not relay.errors
        print(json.dumps(report, indent=2))
        if args.report:
            args.report.write_text(json.dumps(report, indent=2)+"\n")
        return 0 if report["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
