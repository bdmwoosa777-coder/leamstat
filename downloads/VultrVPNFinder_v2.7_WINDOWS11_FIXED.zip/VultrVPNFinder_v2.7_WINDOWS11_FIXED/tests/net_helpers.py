"""Local test servers. No external addresses or Vultr requests are used."""
import contextlib
import select
import socket
import socketserver
import threading
import time


def readn(sock, n):
    out = b""
    while len(out) < n:
        data = sock.recv(n-len(out))
        if not data:
            raise EOFError()
        out += data
    return out


class Server(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


class SocksHandler(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(5)
        try:
            version, size = readn(self.request, 2)
            assert version == 5
            readn(self.request, size)
            for byte in b"\x05\x00":
                self.request.sendall(bytes([byte]))
                time.sleep(0.002)
            head = readn(self.request, 4)
            if head[3] == 1:
                host = socket.inet_ntop(socket.AF_INET, readn(self.request, 4))
            elif head[3] == 4:
                host = socket.inet_ntop(socket.AF_INET6, readn(self.request, 16))
            else:
                host = readn(self.request, readn(self.request, 1)[0]).decode("ascii")
            port = int.from_bytes(readn(self.request, 2), "big")
            self.server.targets.append((host, port))
            if self.server.deny:
                self.request.sendall(b"\x05\x05\x00\x01" + b"\0"*6)
                return
            with socket.create_connection((host, port), timeout=5) as target:
                # Exercise fragmented CONNECT responses, including its variable-size tail.
                for byte in b"\x05\x00\x00\x03\x03abc\x00\x00":
                    self.request.sendall(bytes([byte]))
                    time.sleep(0.001)
                target.settimeout(None)
                self.request.settimeout(None)
                sockets = [self.request, target]
                while sockets:
                    ready, _, _ = select.select(sockets, [], [], 5)
                    if not ready:
                        return
                    for src in ready:
                        dst = target if src is self.request else self.request
                        data = src.recv(4096)
                        if not data:
                            sockets.remove(src)
                            dst.shutdown(socket.SHUT_WR)
                        else:
                            dst.sendall(data)
        except (OSError, EOFError):
            pass


@contextlib.contextmanager
def serve(handler):
    server = Server(("127.0.0.1", 0), handler)
    server.targets, server.deny = [], False
    thread = threading.Thread(target=server.serve_forever, kwargs={"poll_interval": 0.02}, daemon=True)
    thread.start()
    try:
        yield server
    finally:
        server.shutdown()
        server.server_close()
        thread.join(1)


class Echo(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.sendall(b"SSH-2.0-test-server\r\n")
        try:
            while True:
                data = self.request.recv(16384)
                if not data:
                    break
                self.request.sendall(data)
            self.request.sendall(b"EOF")
        except OSError:
            pass
