﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-FinderAdmin
Assert-FinderKey
$pythonPath = Get-FinderPython
New-Item -ItemType Directory -Force -Path (Join-Path $PSScriptRoot 'logs') | Out-Null
$arguments = '"' + (Join-Path $PSScriptRoot 'finder.py') + '"'
$p = Start-Process -FilePath $pythonPath -ArgumentList $arguments -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -PassThru -RedirectStandardOutput (Join-Path $PSScriptRoot 'logs\console.out.log') -RedirectStandardError (Join-Path $PSScriptRoot 'logs\console.err.log')
Start-Sleep -Seconds 1
$p.Refresh()
if ($p.HasExited) { throw 'Finder exited during startup. See logs/finder.log and logs/console.err.log.' }
Write-Host "VPNFinder launched. PID=$($p.Id)"
Write-Host "Log: $PSScriptRoot\logs\finder.log"
