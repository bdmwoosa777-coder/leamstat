﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$path = Join-Path $PSScriptRoot 'logs\finder.log'
if (-not (Test-Path $path)) { Write-Host 'No log yet. Start run_visible.ps1 first.'; exit 0 }
Get-Content -Path $path -Tail 80 -Wait
