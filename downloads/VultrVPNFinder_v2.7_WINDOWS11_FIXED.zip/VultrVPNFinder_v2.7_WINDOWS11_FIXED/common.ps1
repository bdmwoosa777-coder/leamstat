﻿$ErrorActionPreference = 'Stop'
function Get-FinderPython {
    $launcher = Get-Command py.exe -ErrorAction SilentlyContinue
    if ($launcher) {
        $result = & $launcher.Source -3 -c 'import sys; assert sys.version_info >= (3,10); print(sys.executable)'
        if ($LASTEXITCODE -eq 0 -and $result) { return ([string]($result | Select-Object -Last 1)).Trim() }
    }
    $pythonCommand = Get-Command python.exe -ErrorAction SilentlyContinue
    if ($pythonCommand) {
        $result = & $pythonCommand.Source -c 'import sys; assert sys.version_info >= (3,10); print(sys.executable)'
        if ($LASTEXITCODE -eq 0 -and $result) { return ([string]($result | Select-Object -Last 1)).Trim() }
    }
    throw 'Install Python 3.10 or newer from python.org (include the Python launcher).'
}
function Assert-FinderAdmin {
    $admin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $admin) { throw 'Open PowerShell as Administrator to add temporary direct routes.' }
}
function Assert-FinderKey {
    if (-not $env:VULTR_API_KEY) { throw 'VULTR_API_KEY is missing. Set it in this same PowerShell window.' }
}
