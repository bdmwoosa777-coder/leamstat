"""Single-instance lock and cooperative stop, without terminating an unrelated PID."""
from __future__ import annotations

import json
import os
from pathlib import Path
import time

BASE = Path(__file__).resolve().parent
STOP_PATH = BASE / "stop.requested"


class StopRequested(KeyboardInterrupt):
    pass


def check_stop():
    if STOP_PATH.exists():
        raise StopRequested("Stop requested")


def pause(seconds):
    deadline = time.monotonic() + max(0, float(seconds))
    while True:
        check_stop()
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return
        time.sleep(min(remaining, 0.2))


class RuntimeLock:
    def __init__(self, path=None):
        self.path = path or BASE / "finder.lock"
        self.file = None

    def __enter__(self):
        self.file = self.path.open("a+b")
        self.file.seek(0, os.SEEK_END)
        if not self.file.tell():
            self.file.write(b" ")
            self.file.flush()
        self.file.seek(0)
        try:
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            self.file.close()
            self.file = None
            raise RuntimeError("VPNFinder is already running in this folder") from None
        self.file.seek(0)
        self.file.truncate()
        self.file.write(json.dumps({"pid": os.getpid()}).encode("ascii"))
        self.file.flush()
        return self

    def __exit__(self, *exc):
        if self.file is not None:
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt
                msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl
                fcntl.flock(self.file.fileno(), fcntl.LOCK_UN)
            self.file.close()
            self.file = None
