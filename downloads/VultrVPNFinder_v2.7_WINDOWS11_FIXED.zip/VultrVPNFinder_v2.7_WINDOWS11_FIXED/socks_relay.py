"""SOCKS5 connections and a local TCP relay for Windows OpenSSH.

No shell, ProxyCommand or stdio buffering is involved. Each accepted connection
gets its own SOCKS CONNECT, so ssh and scp can share the relay.
"""
from __future__ import annotations

import ipaddress
import select
import socket
import threading


def recv_exact(sock, size):
    data = bytearray()
    while len(data) < size:
        chunk = sock.recv(size - len(data))
        if not chunk:
            raise ConnectionError("SOCKS5 connection closed during handshake")
        data.extend(chunk)
    return bytes(data)


def socks_connect(proxy_port, host=None, port=22, timeout=5, proxy_host="127.0.0.1"):
    sock = socket.create_connection((proxy_host, int(proxy_port)), timeout=timeout)
    try:
        sock.sendall(b"\x05\x01\x00")
        if recv_exact(sock, 2) != b"\x05\x00":
            raise ConnectionError("SOCKS5 proxy does not allow unauthenticated access")
        if host is not None:
            try:
                addr = ipaddress.ip_address(host)
                dest = (b"\x01" if addr.version == 4 else b"\x04") + addr.packed
            except ValueError:
                encoded = host.encode("idna")
                if len(encoded) > 255:
                    raise ValueError("SOCKS5 hostname is too long")
                dest = b"\x03" + bytes([len(encoded)]) + encoded
            sock.sendall(b"\x05\x01\x00" + dest + int(port).to_bytes(2, "big"))
            head = recv_exact(sock, 4)
            if head[0] != 5 or head[1] != 0 or head[2] != 0:
                raise ConnectionError(f"SOCKS5 CONNECT failed (reply={head[1]})")
            if head[3] == 1:
                size = 4
            elif head[3] == 4:
                size = 16
            elif head[3] == 3:
                size = recv_exact(sock, 1)[0]
            else:
                raise ConnectionError("Invalid SOCKS5 address type")
            recv_exact(sock, size + 2)
        sock.settimeout(None)
        return sock
    except BaseException:
        sock.close()
        raise


class SocksRelay:
    def __init__(self, proxy_port, target_host, target_port, timeout=5):
        self.proxy_port = int(proxy_port)
        self.target_host = target_host
        self.target_port = int(target_port)
        self.timeout = timeout
        self.errors = []
        self._stopped = threading.Event()
        self._lock = threading.Lock()
        self._sockets = set()
        self._workers = []
        self.listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.listener.bind(("127.0.0.1", 0))
        self.listener.listen(8)
        self.listener.settimeout(0.25)
        self.port = self.listener.getsockname()[1]
        self.thread = threading.Thread(target=self._accept, daemon=True)

    def __enter__(self):
        self.thread.start()
        return self

    def __exit__(self, *exc):
        self.close()

    def _accept(self):
        while not self._stopped.is_set():
            try:
                client, _ = self.listener.accept()
            except socket.timeout:
                continue
            except OSError:
                break
            worker = threading.Thread(target=self._handle, args=(client,), daemon=True)
            self._workers.append(worker)
            worker.start()

    def _handle(self, client):
        upstream = None
        with self._lock:
            self._sockets.add(client)
        try:
            upstream = socks_connect(self.proxy_port, self.target_host, self.target_port, self.timeout)
            with self._lock:
                self._sockets.add(upstream)
            peers = {client: upstream, upstream: client}
            for sock in peers:
                sock.setblocking(False)
            reading = set(peers)
            pending = {sock: bytearray() for sock in peers}
            write_closed = set()
            while (reading or any(pending.values())) and not self._stopped.is_set():
                # Bounded queues avoid blocking the other direction during SCP.
                to_read = [s for s in reading if len(pending[peers[s]]) < 256 * 1024]
                to_write = [s for s in peers if pending[s]]
                ready, writable, _ = select.select(to_read, to_write, [], 0.25)
                for src in ready:
                    data = src.recv(65536)
                    if data:
                        pending[peers[src]].extend(data)
                    else:
                        reading.remove(src)
                for dst in writable:
                    try:
                        sent = dst.send(pending[dst])
                        del pending[dst][:sent]
                    except BlockingIOError:
                        pass
                for dst in peers:
                    if peers[dst] not in reading and not pending[dst] and dst not in write_closed:
                        try:
                            dst.shutdown(socket.SHUT_WR)
                        except OSError:
                            pass
                        write_closed.add(dst)
        except (OSError, ValueError, ConnectionError) as exc:
            if not self._stopped.is_set():
                with self._lock:
                    self.errors.append(f"{type(exc).__name__}: {exc}")
                    self.errors[:] = self.errors[-5:]
        finally:
            for sock in (client, upstream):
                if sock is not None:
                    with self._lock:
                        self._sockets.discard(sock)
                    sock.close()

    def close(self):
        self._stopped.set()
        self.listener.close()
        with self._lock:
            sockets = list(self._sockets)
        for sock in sockets:
            try:
                sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            sock.close()
        if self.thread.is_alive():
            self.thread.join(1)
        for worker in self._workers:
            worker.join(self.timeout + 0.5)
