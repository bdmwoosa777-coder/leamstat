﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-FinderKey
$pythonPath = Get-FinderPython
& $pythonPath (Join-Path $PSScriptRoot 'finder.py') --check
exit $LASTEXITCODE
