﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
try {
    . (Join-Path $PSScriptRoot 'common.ps1')
    Assert-FinderAdmin
    Assert-FinderKey
    $pythonPath = Get-FinderPython
    & $pythonPath (Join-Path $PSScriptRoot 'finder.py')
    $result = $LASTEXITCODE
    if ($result -eq 2) {
        Write-Host 'Search finished before the GOOD target was reached. See logs/finder.log and run collect_diagnostics.ps1.' -ForegroundColor Yellow
    } elseif ($result -ne 0 -and $result -ne 130) {
        throw "finder.py exited with code $result. See logs/finder.log."
    }
    exit $result
} catch {
    Write-Host "VPNFinder ERROR: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host "Log: $PSScriptRoot\logs\finder.log" -ForegroundColor Yellow
    exit 1
}
