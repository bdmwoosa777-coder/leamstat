"""Loopback SOCKS5 UDP server for tests; refuses destinations outside loopback."""
import contextlib
import select
import socket
import socketserver
from net_helpers import readn, serve
from udp_control import decode_datagram, encode_datagram


class UDPProxyHandler(socketserver.BaseRequestHandler):
    def handle(self):
        front = outbound = None
        try:
            version, size = readn(self.request, 2)
            readn(self.request, size)
            self.request.sendall(b"\x05\x00")
            header = readn(self.request, 4)
            if header != b"\x05\x03\x00\x01":
                return
            readn(self.request, 6)
            if self.server.reject_udp:
                self.request.sendall(b"\x05\x07\x00\x01" + b"\0"*6)
                return
            front = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            front.bind(("127.0.0.1", 0))
            outbound = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            outbound.bind(("127.0.0.2", 0))
            self.request.sendall(b"\x05\x00\x00\x01" + socket.inet_aton("127.0.0.1") + front.getsockname()[1].to_bytes(2, "big"))
            client = None
            while True:
                ready, _, _ = select.select([self.request, front, outbound], [], [], 5)
                if not ready:
                    continue
                if self.request in ready and not self.request.recv(1):
                    return
                if front in ready:
                    packet, client = front.recvfrom(65535)
                    host, port, payload = decode_datagram(packet)
                    if not host.startswith("127."):
                        return
                    self.server.targets.append((host, port))
                    outbound.sendto(payload, (host, port))
                if outbound in ready:
                    payload, target = outbound.recvfrom(65535)
                    if client:
                        front.sendto(encode_datagram(*target, payload), client)
        except (OSError, EOFError, ValueError):
            pass
        finally:
            if front:
                front.close()
            if outbound:
                outbound.close()


@contextlib.contextmanager
def udp_proxy(reject=False):
    with serve(UDPProxyHandler) as server:
        server.reject_udp = reject
        yield server
