from __future__ import annotations

import base64
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import threading
import types
import unittest
from unittest.mock import Mock, patch
import urllib.error
import zipfile

import finder
import runtime_support
import server_bootstrap
from socks_relay import SocksRelay, socks_connect
from net_helpers import serve, SocksHandler, Echo, readn


REAL_BASE = finder.BASE
IID = "c6ec7243-c0d6-471f-91f0-9828cae07ee6"


def candidate():
    return {"attempt": 1, "region": "fra", "plan_id": "vhp-1c-1gb-amd", "hy_auth": "test-auth",
            "vless_uuid": "21a60af2-d51c-4243-b0a4-aa2c5b062ceb", "short_id": "0123456789abcdef",
            "reality_private": base64.urlsafe_b64encode(b"A"*32).decode().rstrip("="),
            "reality_public": base64.urlsafe_b64encode(b"B"*32).decode().rstrip("="),
            "reality_sni": "www.example.com", "fingerprint": "firefox"}


class FinderTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="vpnfinder-test-")
        self.addCleanup(self.temp.cleanup)
        root = Path(self.temp.name)
        names = {"CONFIG_PATH": root/"config.json", "LOG_DIR": root/"logs", "BIN_DIR": root/"bin",
                 "STATE_PATH": root/"state.json", "GOOD_PATH": root/"good.json", "BAD_PATH": root/"bad.json",
                 "LOG_PATH": root/"logs/finder.log", "CSV_PATH": root/"logs/all.csv",
                 "CREDENTIAL_DIR": root/"credentials", "CURRENT_IP_PATH": root/"current_ip.txt", "ROUTE_PATH": root/"direct_route.json", "PID_PATH": root/"finder.pid"}
        for name, value in names.items():
            p = patch.object(finder, name, value)
            p.start(); self.addCleanup(p.stop)
        p = patch.object(runtime_support, "STOP_PATH", root/"stop.requested")
        p.start(); self.addCleanup(p.stop)
        p = patch.dict(os.environ, {"VULTR_API_KEY": "test-key-never-sent"})
        p.start(); self.addCleanup(p.stop)
        p = patch.object(finder, "log")
        p.start(); self.addCleanup(p.stop)
        cfg = json.loads((REAL_BASE/"config.json").read_text(encoding="utf-8-sig"))
        finder.save_json(finder.CONFIG_PATH, cfg)
        finder.LOG_DIR.mkdir(); finder.BIN_DIR.mkdir()
        self.f = finder.Finder()
        diagnostic_patch = patch.object(self.f, "collect_remote_diagnostics")
        diagnostic_patch.start(); self.addCleanup(diagnostic_patch.stop)
        retest_patch = patch.object(self.f, "run_hy2_retest", return_value=[{"ok": False}]*4)
        retest_patch.start(); self.addCleanup(retest_patch.stop)
        self.f.cfg["paired_hy2_control"] = False
        self.f.api = Mock()
        self.f.xray_linux_sha256 = "a"*64
        self.f.ssh_private_key = root/"key with spaces"
        self.f.ssh_key_id = "test-key-id"
        self.f.os_id = 2284

    def test_cloud_config_disables_updates_and_embeds_exact_config(self):
        c = candidate()
        cloud = json.loads(self.f.startup_script_body(c).split("\n", 1)[1])
        self.assertIs(cloud["package_update"], False)
        self.assertIs(cloud["package_upgrade"], False)
        files = {Path(f["path"]).name: base64.b64decode(f["content"]) for f in cloud["write_files"]}
        compile(files["server_bootstrap.py"], "remote", "exec")
        self.assertEqual(json.loads(files["xray.json"]), self.f.xray_server_config(c))
        self.assertNotIn("private key", " ".join(cloud["runcmd"][0]).lower())

    def test_credentials_saved_before_paid_create(self):
        c = candidate()
        def create(payload):
            self.assertEqual(payload["sshkey_id"], [self.f.ssh_key_id])
            self.assertNotIn("ssh_key_ids", payload)
            saved = finder.load_json(finder.STATE_PATH, {})
            self.assertEqual(saved["pending_creates"][payload["label"]]["hy_auth"], c["hy_auth"])
            return {"id": IID}
        self.f.api.create_instance.side_effect = create
        self.f.api.get_instance_user_data.return_value = None
        with patch.object(self.f, "validate_server_config_local"):
            self.f.create(c)
        self.assertEqual(self.f.state["pending_creates"], {})
        self.assertEqual(self.f.state["candidates"][IID]["candidate"]["hy_auth"], c["hy_auth"])

    def test_uncertain_create_keeps_unique_intent_for_recovery(self):
        self.f.api.create_instance.side_effect = finder.AmbiguousCreateError("network failed")
        with patch.object(self.f, "validate_server_config_local"), self.assertRaises(finder.AmbiguousCreateError):
            self.f.create(candidate())
        label = next(iter(self.f.state["pending_creates"]))
        self.f.api.list_instances.return_value = [{"id": IID, "label": label}]
        self.f.recover_create_intents()
        self.assertIn(IID, self.f.state["created_ids"])
        self.assertFalse(self.f.state["pending_creates"])
        self.f.api.create_instance.assert_called_once()

    def test_good_protected_by_api_label_even_with_incomplete_local_state(self):
        self.f.state["created_ids"] = [IID]
        self.f.api.get_instance.return_value = {"label": "vpnfinder-GOOD-01-fra"}
        with self.assertRaises(RuntimeError):
            self.f.safe_delete(IID)
        self.f.api.delete_instance.assert_not_called()

    def test_good_protected_by_saved_results(self):
        self.f.good = [{"instance_id": IID}]
        with self.assertRaises(RuntimeError):
            self.f.safe_delete(IID)
        self.f.api.get_instance.assert_not_called()

    def test_good_record_survives_interruption_between_state_and_results_files(self):
        result = {"instance_id": IID, "links": {"vless": "test-link"}}
        self.f.state["good_ids"] = [IID]
        self.f.state["candidates"][IID] = {"phase": "good", "candidate": candidate(), "result": result}
        finder.save_json(finder.STATE_PATH, self.f.state)
        restored = finder.Finder()
        self.assertEqual(restored.good, [result])

    def test_setup_failure_retained_when_configured(self):
        self.f.remember_candidate(candidate(), IID)
        self.f.record_provision_failure({"c": candidate(), "iid": IID}, "timeout")
        self.assertEqual(self.f.state["candidates"][IID]["phase"], "setup_failed")
        self.f.api.delete_instance.assert_not_called()

    def test_csv_failure_does_not_reclassify_or_delete_good(self):
        self.f.cfg["round_delay_sec"] = 0
        self.f.regions = {"fra": {"city": "Frankfurt"}}
        self.f.remember_candidate(candidate(), IID)
        result = {"ssh": {"ok": 0, "total": 3}, "hy2": {"ok": 2, "total": 2}, "vless": {"ok": 0, "total": 2}}
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(self.f, "ensure_candidate_bootstrap", return_value={"ok": True, "via": "TEST"}))
            for name in ("route_add_direct", "route_delete"):
                stack.enter_context(patch.object(self.f, name))
            stack.enter_context(patch.object(self.f, "ping_test", return_value={"avg_ms": 1, "loss_pct": 0}))
            stack.enter_context(patch.object(self.f, "direct_round", return_value=result))
            stack.enter_context(patch.object(self.f, "append_csv", side_effect=OSError("disk full")))
            self.assertTrue(self.f.process_created_candidate(candidate(), IID, {"main_ip": "192.0.2.1"}))
        self.assertIn(IID, self.f.state["good_ids"])
        self.assertFalse(self.f.bad)
        self.f.api.delete_instance.assert_not_called()

    def test_remote_failure_still_tries_local_fallback(self):
        with patch.object(self.f, "wait_autonomous_bootstrap", return_value={"ok": False, "via": "REMOTE_FAILED"}), \
             patch.object(self.f, "try_local_scp_bootstrap", return_value=True) as fallback:
            self.assertTrue(self.f.ensure_candidate_bootstrap(candidate(), "192.0.2.1")["ok"])
        fallback.assert_called_once_with(candidate(), "192.0.2.1", "VPN")

    def test_health_for_another_config_is_not_accepted(self):
        with patch.object(self.f, "diag_http_text", return_value=json.dumps({"ready": True, "config_sha256": "wrong"})):
            self.assertFalse(self.f.bootstrap_state(candidate(), "192.0.2.1", False, 1)["ok"])

    def test_health_for_current_config_is_accepted(self):
        digest = hashlib.sha256(json.dumps(self.f.xray_server_config(candidate()), sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        with patch.object(self.f, "diag_http_text", return_value=json.dumps({"ready": True, "config_sha256": digest})):
            self.assertTrue(self.f.bootstrap_state(candidate(), "192.0.2.1", False, 1)["ok"])

    def test_route_delete_leaves_unowned_route_untouched(self):
        with patch.object(finder, "run") as run:
            self.f.route_delete("192.0.2.1")
        run.assert_not_called()

    def test_route_is_added_once_per_phase_and_uses_interface(self):
        self.f.direct_gateway, self.f.direct_interface_index = "192.168.0.1", 7
        with patch.object(self.f, "query_host_routes", return_value=[]), \
             patch.object(finder, "run", return_value=types.SimpleNamespace(returncode=0, stdout=b"")) as run:
            self.f.route_add_direct("192.0.2.1")
            self.f.route_add_direct("192.0.2.1")
            self.assertEqual(run.call_count, 1)
            self.assertEqual(run.call_args.args[0][-2:], ["IF", "7"])
            self.f.route_delete("192.0.2.1")
        self.assertFalse(finder.ROUTE_PATH.exists())

    def test_curl_rejects_407_and_partial_transfer(self):
        self.f.cfg["http_tests_per_protocol_per_round"] = 1
        for rc, out in ((0, b"407|0.05"), (60, b"200|0.1")):
            with self.subTest(rc=rc), patch.object(finder, "run", return_value=types.SimpleNamespace(returncode=rc, stdout=out)):
                self.assertEqual(self.f.curl_proxy_tests(1234)["ok"], 0)

    def test_curl_success_forces_own_proxy_despite_no_proxy_environment(self):
        with patch.object(finder, "run", return_value=types.SimpleNamespace(returncode=0, stdout=b"204|0.05")) as run:
            self.assertEqual(self.f.curl_proxy_tests(1234, tests_override=1)["ok"], 1)
        args = run.call_args.args[0]
        self.assertEqual(args[args.index("--noproxy")+1], "")

    def test_management_commands_use_same_relay_and_no_proxycommand(self):
        self.f.management_relay = types.SimpleNamespace(port=41234)
        ssh = self.f._management_ssh_args("192.0.2.1", explicit_socks=True)
        scp = self.f._management_scp_args("192.0.2.1", explicit_socks=True)
        self.assertEqual(ssh[ssh.index("-p")+1], "41234")
        self.assertEqual(scp[scp.index("-P")+1], "41234")
        self.assertEqual(ssh[-1], "root@127.0.0.1")
        self.assertNotIn("ProxyCommand", " ".join(ssh+scp))

    def test_ssh_error_explains_authentication_failure(self):
        self.f.cfg["management_ssh_wait_direct_sec"] = 10
        with patch.object(finder, "run", return_value=types.SimpleNamespace(returncode=255, stdout=b"Permission denied (publickey).")) as run:
            self.assertFalse(self.f._management_ssh_ready("192.0.2.1"))
        run.assert_called_once()

    def test_provision_timeout_applies_even_when_api_is_unreachable(self):
        self.f.remember_candidate(candidate(), IID)
        pending = [{"iid": IID, "c": candidate(), "created_monotonic": -100000000000}]
        self.assertEqual(self.f.wait_any_ready(pending), (None, None))
        self.f.api.get_instance.assert_not_called()

    def test_invalid_threshold_is_rejected_before_any_vps(self):
        self.f.cfg["min_http_passes_per_round"] = 3
        with self.assertRaises(RuntimeError):
            self.f.validate_config()

    def test_restart_reuses_saved_candidate_without_another_create(self):
        self.f.remember_candidate(candidate(), IID)
        def ready(pending):
            return pending[0], {"main_ip": "192.0.2.1"}
        def good(c, iid, inst):
            self.f.good.append({"instance_id": iid, "classification": "GOOD_DIRECT",
                                "round1": {"hy2": {"ok": 2, "total": 2}, "vless": {"ok": 2, "total": 2}},
                                "round2": {"hy2": {"ok": 2, "total": 2}, "vless": {"ok": 2, "total": 2}}})
            return True
        with patch.object(self.f, "preflight"), patch.object(self.f, "wait_any_ready", side_effect=ready), \
             patch.object(self.f, "process_created_candidate", side_effect=good), \
             patch.object(self.f, "create_pending_candidate") as create:
            self.assertTrue(self.f.main_loop())
        create.assert_not_called()

    def test_diagnostics_exclude_state_and_redact_known_credentials(self):
        c = candidate()
        self.f.remember_candidate(c, IID)
        self.f.persist_state()
        finder.LOG_PATH.write_text("test-key-never-sent " + c["hy_auth"] + " " + c["reality_private"])
        with patch.object(finder, "BASE", Path(self.temp.name)), contextlib.redirect_stdout(io.StringIO()):
            finder.write_diagnostics()
        with zipfile.ZipFile(Path(self.temp.name)/"diagnostics.zip") as z:
            self.assertNotIn("state.json", z.namelist())
            log = z.read("logs/finder.log").decode()
        self.assertNotIn(c["hy_auth"], log)
        self.assertNotIn(c["reality_private"], log)
        self.assertNotIn("test-key-never-sent", log)


    def test_deleted_saved_vps_is_reconciled_before_new_attempt(self):
        self.f.remember_candidate(candidate(), IID, "setup_failed")
        self.f.api.get_instance.side_effect = finder.APIError(404, "not found")
        self.f.reconcile_deleted_candidates()
        self.assertEqual(self.f.state["candidates"][IID]["phase"], "deleted")

    def test_api_denial_is_not_treated_as_a_deleted_vps(self):
        self.f.remember_candidate(candidate(), IID, "setup_failed")
        self.f.api.get_instance.side_effect = finder.APIError(403, "denied")
        with self.assertRaises(finder.APIError):
            self.f.reconcile_deleted_candidates()
        self.assertEqual(self.f.state["candidates"][IID]["phase"], "setup_failed")

    def test_authentication_denial_activates_password_fallback(self):
        self.f.last_ssh_auth_denied = True
        with patch.object(self.f, "route_delete"), patch.object(self.f, "discover_v2rayn_socks", return_value=None), \
             patch.object(self.f, "_management_ssh_ready", return_value=False), \
             patch.object(self.f, "try_password_bootstrap", return_value=True) as fallback:
            self.assertTrue(self.f.try_local_scp_bootstrap(candidate(), "192.0.2.1", "VPN"))
        fallback.assert_called_once()

    def test_network_failure_does_not_attempt_password_authentication(self):
        self.f.last_ssh_auth_denied = False
        with patch.object(self.f, "route_delete"), patch.object(self.f, "discover_v2rayn_socks", return_value=None), \
             patch.object(self.f, "_management_ssh_ready", return_value=False), \
             patch.object(self.f, "try_password_bootstrap") as fallback:
            self.assertFalse(self.f.try_local_scp_bootstrap(candidate(), "192.0.2.1", "VPN"))
        fallback.assert_not_called()

    def test_no_password_does_not_install_backend_or_persist_credentials(self):
        self.f.api.get_instance.return_value = {}
        c = dict(candidate(), instance_id=IID)
        with patch.dict(os.environ, {"VULTR_ROOT_PASSWORD": ""}), patch.object(self.f, "ensure_password_backend") as backend:
            self.assertFalse(self.f.try_password_bootstrap(c, "192.0.2.1", False, "TEST"))
        backend.assert_not_called()
        self.assertNotIn("default_password", json.dumps(self.f.state))


    def test_protocol_failure_on_both_paths_retains_vps_and_results(self):
        self.f.cfg["round_delay_sec"] = 0
        self.f.regions = {"fra": {"city": "Frankfurt"}}
        self.f.remember_candidate(candidate(), IID)
        fail = {"ok": 0, "total": 2, "avg_ms": None}
        rounds = {"ssh": {"ok": 1, "total": 3}, "hy2": fail, "vless": fail}
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(self.f, "ensure_candidate_bootstrap", return_value={"ok": True}))
            for name in ("route_add_direct", "route_delete"):
                stack.enter_context(patch.object(self.f, name))
            stack.enter_context(patch.object(self.f, "ping_test", return_value={"avg_ms": 20, "loss_pct": 0}))
            stack.enter_context(patch.object(self.f, "direct_round", return_value=rounds))
            stack.enter_context(patch.object(self.f, "via_vpn_control", return_value={"hy2": fail, "vless": dict(fail, path="EXPLICIT_SOCKS")}))
            self.assertFalse(self.f.process_created_candidate(candidate(), IID, {"main_ip": "192.0.2.1"}))
        self.f.api.delete_instance.assert_not_called()
        self.assertEqual(self.f.state["candidates"][IID]["phase"], "protocol_failed")
        self.assertEqual(self.f.bad[-1]["classification"], "PROTOCOL_UNCONFIRMED")
        self.assertEqual(self.f.bad[-1]["round1"]["hy2"]["ok"], 0)
        self.f.collect_remote_diagnostics.assert_any_call(unittest.mock.ANY, "192.0.2.1", "after_failed_tests")


    def test_staged_hy2_and_optional_vless_grading(self):
        a = {"hy2": {"ok": 2, "total": 2}, "vless": {"ok": 2, "total": 2}}
        b = {"hy2": {"ok": 1, "total": 2, "results": [{"ok": True}, {"ok": False}]}, "vless": {"ok": 2, "total": 2}}
        self.assertEqual(self.f.direct_grade(a, a), "GOOD_BOTH")
        self.assertEqual(self.f.direct_grade(dict(a, vless={"ok": 0, "total": 2}), a), "GOOD_HY2")
        self.assertEqual(self.f.hy2_assessment(a, b)["status"], "RETEST")
        self.assertIsNone(self.f.direct_grade(a, b))
        extra = [{"ok": True}]*4
        self.assertEqual(self.f.hy2_assessment(a, b, extra)["passed"], 7)
        self.assertEqual(self.f.direct_grade(a, b, extra), "GOOD_BOTH")
        self.assertIsNone(self.f.direct_grade(a, b, [{"ok": True}, {"ok": False}, {"ok": True}, {"ok": False}]))
        self.assertEqual(self.f.hy2_assessment(b, b)["status"], "NOT_GOOD")
        zero = dict(a, hy2={"ok": 0, "total": 2})
        self.assertEqual(self.f.hy2_assessment(a, zero)["status"], "NOT_GOOD")
        valid = {"classification": "GOOD_BOTH", "round1": a, "round2": b, "hy2_retest": extra}
        vpn = dict(valid, classification="FILTERED_DIRECT")
        pending = dict(valid, hy2_retest=None)
        self.f.good = [valid, vpn, pending]
        self.assertEqual(self.f.good_count(), 1)

    def test_consecutive_failures_are_detected_across_round_and_retest_boundaries(self):
        a = {"hy2": {"ok": 1, "total": 2, "results": [{"ok": True}, {"ok": False}]}}
        b = {"hy2": {"ok": 1, "total": 2, "results": [{"ok": False}, {"ok": True}]}}
        self.assertTrue(self.f.hy2_assessment(a, b)["consecutive_failures"])
        good = {"hy2": {"ok": 2, "total": 2}}
        evaluated = self.f.hy2_assessment(good, a, [{"ok": False}]+[{"ok": True}]*3)
        self.assertTrue(evaluated["consecutive_failures"])
        self.assertEqual(evaluated["status"], "NOT_GOOD")

    def test_retest_runs_four_fresh_attempts_with_intervals(self):
        result = {"ok": 1, "total": 1, "results": [{"ok": True, "ms": 1}]}
        with patch.object(self.f, "test_hy2", return_value=result) as test, patch.object(finder, "pause") as pause:
            outcomes = finder.Finder.run_hy2_retest(self.f, candidate(), "192.0.2.1")
        self.assertEqual(test.call_count, 4)
        self.assertEqual(len(outcomes), 4)
        self.assertEqual(pause.call_count, 3)
        self.assertTrue(all(call.kwargs["tests_override"] == 1 for call in test.call_args_list))

    def test_each_initial_hy2_attempt_uses_a_separate_session(self):
        result = {"ok": 1, "total": 1, "results": [{"ok": True, "ms": 1}]}
        with patch.object(self.f, "_test_hy2_session", return_value=result) as session:
            result = self.f.test_hy2(candidate(), "192.0.2.1")
        self.assertEqual(session.call_count, 2)
        self.assertEqual(result["fresh_hy2_sessions"], 2)
        self.assertEqual(result["ok"], 2)


    def test_old_three_of_four_hy2_candidate_is_preserved_but_not_counted(self):
        record = {"classification": "GOOD_DIRECT", "instance_id": IID, "ip": "78.141.216.156",
                  "round1": {"hy2": {"ok": 1, "total": 2}, "vless": {"ok": 2, "total": 2}},
                  "round2": {"hy2": {"ok": 2, "total": 2}, "vless": {"ok": 2, "total": 2}}}
        self.f.good = [record]
        self.f.state["good_ids"] = [IID]
        self.f.persist_state()
        restored = finder.Finder()
        self.assertEqual(restored.good_count(), 0)
        self.assertEqual(restored.good[0]["ip"], "78.141.216.156")
        with self.assertRaises(RuntimeError):
            restored.safe_delete(IID)

    def test_minimum_one_does_not_weaken_staged_hy2_selection(self):
        self.f.cfg["min_http_passes_per_round"] = 1
        self.assertFalse(self.f.strict_protocol_round({"ok": 1, "total": 2}))
        self.assertFalse(self.f.strict_protocol_round({"ok": 2, "total": 3}))
        self.assertTrue(self.f.strict_protocol_round({"ok": 2, "total": 2}))


    def test_single_protocol_direct_success_is_not_saved_as_good(self):
        self.f.cfg.update(round_delay_sec=0, delete_bad=False)
        self.f.regions = {"fra": {"city": "Frankfurt"}}
        self.f.remember_candidate(candidate(), IID)
        rounds = {"ssh": {"ok": 3, "total": 3}, "hy2": {"ok": 0, "total": 2}, "vless": {"ok": 2, "total": 2}}
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(self.f, "ensure_candidate_bootstrap", return_value={"ok": True}))
            for name in ("route_add_direct", "route_delete"):
                stack.enter_context(patch.object(self.f, name))
            stack.enter_context(patch.object(self.f, "ping_test", return_value={"avg_ms": 1, "loss_pct": 0}))
            stack.enter_context(patch.object(self.f, "direct_round", return_value=rounds))
            stack.enter_context(patch.object(self.f, "via_vpn_control", return_value={"hy2": {"ok": 2}, "vless": {"ok": 2, "path": "EXPLICIT_SOCKS"}}))
            self.assertFalse(self.f.process_created_candidate(candidate(), IID, {"main_ip": "192.0.2.1"}))
        self.assertEqual(self.f.good_count(), 0)
        self.assertNotIn(IID, self.f.state["good_ids"])


    def test_new_near_good_candidate_is_retained_without_occupying_target(self):
        self.f.cfg["round_delay_sec"] = 0
        self.f.regions = {"fra": {"city": "Frankfurt"}}
        self.f.remember_candidate(candidate(), IID)
        a = {"ssh": {"ok": 0, "total": 3}, "hy2": {"ok": 1, "total": 2}, "vless": {"ok": 2, "total": 2}}
        b = {"ssh": {"ok": 0, "total": 3}, "hy2": {"ok": 2, "total": 2}, "vless": {"ok": 2, "total": 2}}
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(self.f, "ensure_candidate_bootstrap", return_value={"ok": True}))
            for name in ("route_add_direct", "route_delete"):
                stack.enter_context(patch.object(self.f, name))
            stack.enter_context(patch.object(self.f, "ping_test", return_value={"avg_ms": 1, "loss_pct": 0}))
            stack.enter_context(patch.object(self.f, "direct_round", side_effect=[a, b]))
            stack.enter_context(patch.object(self.f, "via_vpn_control", return_value={"hy2": {"ok": 2}, "vless": {"ok": 2, "path": "EXPLICIT_SOCKS"}}))
            self.assertFalse(self.f.process_created_candidate(candidate(), IID, {"main_ip": "192.0.2.1"}))
        self.assertEqual(self.f.bad[-1]["classification"], "NEAR_GOOD_HY2")
        self.assertEqual(self.f.state["candidates"][IID]["phase"], "near_good_retained")
        self.f.api.delete_instance.assert_not_called()
        self.assertEqual(self.f.good_count(), 0)


    def test_saved_three_of_four_uses_only_four_extra_attempts_and_is_upserted(self):
        self.f.cfg["round_delay_sec"] = 0
        self.f.retest_saved_mode = True
        self.f.regions = {"fra": {"city": "Frankfurt"}}
        r1 = {"hy2": {"ok": 1, "total": 2}, "vless": {"ok": 2, "total": 2}, "ssh": {"ok": 0, "total": 3}}
        r2 = {"hy2": {"ok": 2, "total": 2}, "vless": {"ok": 2, "total": 2}, "ssh": {"ok": 0, "total": 3}}
        self.f.good = [{"instance_id": IID, "ip": "192.0.2.1", "classification": "GOOD_DIRECT",
                        "time": "previous-test", "round1": r1, "round2": r2, "ping": {"avg_ms": 42, "loss_pct": 0}}]
        self.f.state["good_ids"] = [IID]
        self.f.remember_candidate(candidate(), IID, "good")
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(self.f, "ensure_candidate_bootstrap", return_value={"ok": True}))
            for name in ("route_add_direct", "route_delete"):
                stack.enter_context(patch.object(self.f, name))
            rounds = stack.enter_context(patch.object(self.f, "direct_round"))
            extra = stack.enter_context(patch.object(self.f, "run_hy2_retest", return_value=[{"ok": True}]*4))
            self.assertTrue(self.f.process_created_candidate(candidate(), IID, {"main_ip": "192.0.2.1"}))
        rounds.assert_not_called()
        extra.assert_called_once()
        self.assertEqual(len(self.f.good), 1)
        self.assertEqual(self.f.good_count(), 1)
        self.assertEqual(self.f.good[0]["hy2_assessment"]["passed"], 7)
        self.assertEqual(self.f.good[0]["classification"], "GOOD_BOTH")
        self.assertTrue(self.f.good[0]["initial_rounds_reused"])


    def test_explicit_retest_is_not_skipped_when_target_is_already_reached(self):
        result = {"hy2": {"ok": 2, "total": 2}, "vless": {"ok": 2, "total": 2}}
        self.f.good = [{"instance_id": IID, "classification": "GOOD_BOTH", "round1": result, "round2": result}]
        self.f.state["good_ids"] = [IID]
        self.f.remember_candidate(candidate(), IID, "good")
        def ready(pending):
            return pending[0], {"main_ip": "192.0.2.1"}
        with patch.object(self.f, "preflight"), patch.object(self.f, "wait_any_ready", side_effect=ready), \
             patch.object(self.f, "process_created_candidate", return_value=True) as process, \
             patch.object(self.f, "create_pending_candidate") as create:
            self.assertTrue(self.f.main_loop(retest_saved=True))
        process.assert_called_once()
        create.assert_not_called()


class APITest(unittest.TestCase):
    def test_uncertain_post_is_never_blindly_repeated(self):
        api = finder.VultrAPI("unused-test-key")
        with patch.object(finder.urllib.request, "urlopen", side_effect=urllib.error.URLError("timeout")) as request:
            with self.assertRaises(finder.AmbiguousCreateError):
                api.create_instance({"label": "test"})
        request.assert_called_once()

    def test_pagination_does_not_forward_authorization_to_foreign_url(self):
        api = finder.VultrAPI("unused-test-key")
        with patch.object(api, "request", return_value={"instances": [], "meta": {"links": {"next": "https://example.com/steal"}}}):
            with self.assertRaises(RuntimeError):
                api.list_instances()


class RelayTest(unittest.TestCase):
    def test_small_ssh_banner_and_fragmented_handshakes(self):
        with serve(Echo) as target, serve(SocksHandler) as proxy:
            with SocksRelay(proxy.server_address[1], "127.0.0.1", target.server_address[1]) as relay:
                with socket.create_connection(("127.0.0.1", relay.port), timeout=3) as client:
                    self.assertEqual(readn(client, 21), b"SSH-2.0-test-server\r\n")
                    message = b"SSH-2.0-windows-client\r\n"
                    client.sendall(message)
                    self.assertEqual(readn(client, len(message)), message)
                    client.shutdown(socket.SHUT_WR)
                    self.assertEqual(readn(client, 3), b"EOF")
                self.assertFalse(relay.errors)
            self.assertEqual(len(proxy.targets), 1)

    def test_large_binary_transfer_and_multiple_connections(self):
        payload = bytes(range(256))*4096
        with serve(Echo) as target, serve(SocksHandler) as proxy:
            with SocksRelay(proxy.server_address[1], "127.0.0.1", target.server_address[1]) as relay:
                for _ in range(2):
                    with socket.create_connection(("127.0.0.1", relay.port), timeout=5) as client:
                        readn(client, 21)
                        def upload():
                            client.sendall(payload)
                            client.shutdown(socket.SHUT_WR)
                        sender = threading.Thread(target=upload, daemon=True)
                        sender.start()
                        self.assertEqual(readn(client, len(payload)), payload)
                        self.assertEqual(readn(client, 3), b"EOF")
                        sender.join(3)
                        self.assertFalse(sender.is_alive())
            self.assertEqual(len(proxy.targets), 2)

    def test_rejected_connect_is_reported(self):
        with serve(SocksHandler) as proxy:
            proxy.deny = True
            with self.assertRaisesRegex(ConnectionError, "reply=5"):
                socks_connect(proxy.server_address[1], "192.0.2.1", 22)

    def test_socks_discovery_does_not_need_ssh(self):
        with serve(SocksHandler) as proxy:
            with socks_connect(proxy.server_address[1]):
                pass
            self.assertFalse(proxy.targets)


class RuntimeTest(unittest.TestCase):
    def test_duplicate_run_is_rejected_and_lock_can_be_reused(self):
        with tempfile.TemporaryDirectory() as td:
            path = Path(td)/"finder.lock"
            with runtime_support.RuntimeLock(path):
                with self.assertRaises(RuntimeError):
                    with runtime_support.RuntimeLock(path):
                        pass
            with runtime_support.RuntimeLock(path):
                pass

    def test_stop_interrupts_wait_instead_of_killing_pid(self):
        with tempfile.TemporaryDirectory() as td, patch.object(runtime_support, "STOP_PATH", Path(td)/"stop"):
            runtime_support.STOP_PATH.touch()
            with self.assertRaises(runtime_support.StopRequested):
                runtime_support.pause(60)

    def test_remote_services_are_persistent_and_diagnostic_port_is_respected(self):
        self.assertIn("Restart=on-failure", server_bootstrap.service_text("xray"))
        self.assertIn("WantedBy=multi-user.target", server_bootstrap.service_text("xray"))
        self.assertIn("http.server 8080 ", server_bootstrap.service_text("diag", 8080))


if __name__ == "__main__":
    unittest.main()


class FirewallTest(unittest.TestCase):
    def test_active_ufw_opens_only_required_application_ports(self):
        with patch.object(server_bootstrap.shutil, "which", return_value="ufw"), \
             patch.object(server_bootstrap.subprocess, "run", return_value=types.SimpleNamespace(returncode=0, stdout=b"Status: active")), \
             patch.object(server_bootstrap, "command") as command:
            server_bootstrap.ensure_firewall(8080)
        self.assertEqual([c.args[0] for c in command.call_args_list], [
            ["ufw", "allow", "443/udp"], ["ufw", "allow", "8443/tcp"], ["ufw", "allow", "8080/tcp"]])

    def test_inactive_ufw_is_not_enabled_or_modified(self):
        with patch.object(server_bootstrap.shutil, "which", return_value="ufw"), \
             patch.object(server_bootstrap.subprocess, "run", return_value=types.SimpleNamespace(returncode=0, stdout=b"Status: inactive")), \
             patch.object(server_bootstrap, "command") as command:
            server_bootstrap.ensure_firewall(80)
        command.assert_not_called()
