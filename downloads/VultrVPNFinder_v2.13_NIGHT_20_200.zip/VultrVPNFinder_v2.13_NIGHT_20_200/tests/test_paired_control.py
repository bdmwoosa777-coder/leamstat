import contextlib
import io
import json
from pathlib import Path
import socket
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch

import finder
from password_vault import PasswordVault
import password_vault
from udp_control import SocksUDPRelay, decode_datagram
from paired_hy2 import assess, hy2_peers
from udp_helpers import udp_proxy
import test_regressions as regressions
IID, candidate = regressions.IID, regressions.candidate


class PairedAssessmentTest(unittest.TestCase):
    def pairs(self, direct, control, same_ip=False):
        return [{"direct": {"ok": i<direct, "attempted": True, "transport": "DIRECT_ROUTE", "server_peers": ["192.0.2.10"] if i<direct else []},
                 "control": {"ok": i<control, "attempted": True, "transport": "SOCKS5_UDP",
                             "server_peers": ["192.0.2.10" if same_ip else "198.51.100.20"] if i<control else []}}
                for i in range(8)]

    def test_eight_control_successes_are_verified_by_distinct_observed_egress(self):
        result = assess(self.pairs(4,8), "198.51.100.20")
        self.assertTrue(result["control_verified"])
        self.assertEqual(result["verdict"], "DIRECT_PATH_SPECIFIC_FAILURE")
        self.assertFalse(result["good_hy2"])

    def test_same_egress_is_never_claimed_as_verified_vpn(self):
        result = assess(self.pairs(4,8,same_ip=True), "192.0.2.10")
        self.assertFalse(result["control_verified"])
        self.assertEqual(result["verdict"], "CONTROL_UNVERIFIED")

    def test_zero_direct_needs_independent_direct_source_for_verification(self):
        pairs = self.pairs(0,8)
        self.assertFalse(assess(pairs,"198.51.100.20")["control_verified"])
        self.assertTrue(assess(pairs,"198.51.100.20","192.0.2.10")["control_verified"])

    def test_good_direct_is_preserved_when_control_is_unstable(self):
        result = assess(self.pairs(8,4), "198.51.100.20")
        self.assertTrue(result["good_hy2"])
        self.assertEqual(result["verdict"], "GOOD_DIRECT_CONTROL_UNSTABLE")

    def test_shared_failure_is_not_attributed_to_direct_filtering(self):
        result = assess(self.pairs(4,4), "198.51.100.20")
        self.assertEqual(result["verdict"], "SHARED_OR_CONTROL_INSTABILITY")
        self.assertEqual(assess(self.pairs(0,0))["verdict"], "CHECK_SERVER_CONFIG_AND_NETWORK")

    def test_seven_of_eight_without_consecutive_failures_passes(self):
        self.assertTrue(assess(self.pairs(7,8), "198.51.100.20")["good_hy2"])

    def test_real_access_log_peer_parser_ignores_unrelated_traffic(self):
        text = "from 192.0.2.1:53211 accepted tcp:example.com:443 [hy2-in >> direct] email: test\nfrom 192.0.2.2:1234 accepted tcp:example.com:443 [vless-reality-in >> direct]"
        self.assertEqual(hy2_peers(text), ["192.0.2.1"])


class UDPRelayTest(unittest.TestCase):
    def test_datagrams_traverse_udp_associate_and_keep_binary_payload(self):
        target = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        target.bind(("127.0.0.1",0)); target.settimeout(3)
        seen = []
        def echo():
            data, addr = target.recvfrom(65535)
            seen.append(addr[0]); target.sendto(data,addr)
        worker = threading.Thread(target=echo,daemon=True); worker.start()
        try:
            with udp_proxy() as proxy, SocksUDPRelay(proxy.server_address[1], "127.0.0.1", target.getsockname()[1]) as relay:
                with socket.socket(socket.AF_INET,socket.SOCK_DGRAM) as client:
                    client.settimeout(3); data=bytes(range(256))*4
                    client.sendto(data,("127.0.0.1",relay.port))
                    self.assertEqual(client.recvfrom(65535)[0],data)
                self.assertGreaterEqual(relay.sent,1)
                self.assertGreaterEqual(relay.received,1)
            worker.join(1)
            self.assertEqual(seen,["127.0.0.2"])
        finally:
            target.close()

    def test_unsupported_udp_fails_without_direct_fallback(self):
        with udp_proxy(reject=True) as proxy:
            with self.assertRaises(ConnectionError):
                with SocksUDPRelay(proxy.server_address[1],"192.0.2.1",443):
                    self.fail("UDP association should have failed")

    def test_fragmented_udp_packets_are_rejected(self):
        with self.assertRaises(ValueError):
            decode_datagram(b"\0\0\x01\x01"+b"\0"*6)


class VaultTest(unittest.TestCase):
    def test_vault_writes_only_ciphertext_and_recovers_password(self):
        def crypto(data,protect):
            if protect:
                return b"mock-dpapi:"+bytes(x^165 for x in data)
            return bytes(x^165 for x in data[len(b"mock-dpapi:"):])
        with tempfile.TemporaryDirectory() as td,patch.object(password_vault,"crypt",side_effect=crypto):
            vault=PasswordVault(td); vault.save(IID,"unit-test-password")
            self.assertNotIn(b"unit-test-password",vault.path(IID).read_bytes())
            self.assertEqual(vault.load(IID),"unit-test-password")

    def test_encryption_failure_never_creates_plaintext_file(self):
        with tempfile.TemporaryDirectory() as td,patch.object(password_vault,"crypt",side_effect=OSError("unsupported")):
            vault=PasswordVault(td)
            with self.assertRaises(OSError):vault.save(IID,"unit-test-password")
            self.assertFalse(vault.path(IID).exists())


# Reuse the setup function, without importing the entire regression TestCase as a second discovered class.
class FinderPairedTest(unittest.TestCase):
    setUp = regressions.FinderTest.setUp

    def test_good_paired_result_is_saved_when_ssh_fails(self):
        self.f.cfg["paired_hy2_control"]=True
        self.f.regions={"fra":{"city":"Frankfurt"}}
        pairs=PairedAssessmentTest().pairs(7,8)
        paired={"pairs":pairs,"assessment":assess(pairs,"198.51.100.20")}
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(self.f,"ensure_candidate_bootstrap",return_value={"ok":True}))
            for method in ("route_add_direct","route_delete"):
                stack.enter_context(patch.object(self.f,method))
            stack.enter_context(patch.object(self.f,"run_paired_hy2",return_value=paired))
            stack.enter_context(patch.object(self.f,"ping_test",return_value={"avg_ms":20,"loss_pct":0}))
            stack.enter_context(patch.object(self.f,"test_vless",return_value={"ok":2,"total":2}))
            stack.enter_context(patch.object(self.f,"ssh_test",return_value={"ok":0,"total":3}))
            self.assertTrue(self.f.process_created_candidate(candidate(),IID,{"main_ip":"192.0.2.1"}))
        self.assertEqual(self.f.good_count(),1)
        self.assertEqual(self.f.good[0]["classification"],"GOOD_BOTH")
        self.assertTrue(self.f.good[0]["paired_hy2"]["assessment"]["control_verified"])

    def test_failed_paired_result_is_retained_for_diagnostics(self):
        self.f.cfg["paired_hy2_control"]=True
        self.f.regions={"fra":{"city":"Frankfurt"}}
        pairs=PairedAssessmentTest().pairs(4,8)
        paired={"pairs":pairs,"assessment":assess(pairs,"198.51.100.20")}
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(self.f,"ensure_candidate_bootstrap",return_value={"ok":True}))
            for method in ("route_add_direct","route_delete"):
                stack.enter_context(patch.object(self.f,method))
            stack.enter_context(patch.object(self.f,"run_paired_hy2",return_value=paired))
            stack.enter_context(patch.object(self.f,"ping_test",return_value={"avg_ms":20,"loss_pct":0}))
            stack.enter_context(patch.object(self.f,"test_vless",return_value={"ok":2,"total":2}))
            stack.enter_context(patch.object(self.f,"ssh_test",return_value={"ok":0,"total":3}))
            self.assertFalse(self.f.process_created_candidate(candidate(),IID,{"main_ip":"192.0.2.1"}))
        self.f.api.delete_instance.assert_not_called()
        self.assertEqual(self.f.bad[-1]["classification"],"DIRECT_PATH_SPECIFIC_FAILURE")
        self.assertEqual(self.f.state["candidates"][IID]["phase"],"paired_failed_retained")

    def test_active_vps_cap_prevents_another_paid_create(self):
        self.f.cfg["max_active_candidates"]=3
        for iid in (IID,"8a0c629e-56fd-4fb6-ac50-5b7312c47498","2a4e8009-0e3b-4659-9a58-ac76f1f29b78"):
            self.f.remember_candidate(candidate(),iid,"near_good_retained")
        with patch.object(self.f,"preflight"),patch.object(self.f,"create_pending_candidate") as create:
            self.assertFalse(self.f.main_loop())
        create.assert_not_called()

    def test_diagnostic_archive_never_includes_password_vault(self):
        finder.CREDENTIAL_DIR.mkdir()
        (finder.CREDENTIAL_DIR/(IID+".dpapi")).write_bytes(b"example-ciphertext")
        with patch.object(finder,"BASE",Path(self.temp.name)),contextlib.redirect_stdout(io.StringIO()):
            finder.write_diagnostics()
        import zipfile
        with zipfile.ZipFile(Path(self.temp.name)/"diagnostics.zip") as archive:
            self.assertFalse(any("credentials" in name or name.endswith(".dpapi") for name in archive.namelist()))

    def test_create_caches_returned_password_without_persisting_it_in_state(self):
        self.f.password_vault = Mock()
        self.f.api.create_instance.return_value={"id":IID,"default_password":"creation-only-password"}
        self.f.api.get_instance_user_data.return_value=None
        with patch.object(self.f,"validate_server_config_local"):
            self.f.create(candidate())
        self.f.password_vault.save.assert_called_once_with(IID,"creation-only-password")
        self.assertNotIn("creation-only-password",finder.STATE_PATH.read_text())
        self.f.password_cache={}
        self.f.password_vault.load.return_value="creation-only-password"
        self.f.api.get_instance.side_effect=AssertionError("API must not be needed for cached password")
        self.assertEqual(self.f.instance_password(IID),"creation-only-password")

    def test_pairs_alternate_routes_and_never_mark_unobserved_control_verified(self):
        self.f.cfg["paired_attempt_delay_sec"]=0
        observer=Mock(proxy_egress="198.51.100.20")
        observer.peers_after.side_effect=[["192.0.2.10"],["198.51.100.20"]]*8
        relay=Mock(port=30000,sent=1,received=1,proxy_udp_endpoint=("127.0.0.1",50000))
        relay_context=Mock();relay_context.__enter__=Mock(return_value=relay);relay_context.__exit__=Mock(return_value=False)
        events=[]
        def test(c,ip,**kwargs):
            events.append("V" if ip=="127.0.0.1" else "D")
            return {"ok":1,"total":1,"results":[{"ok":True}]}
        with patch.object(self.f,"discover_v2rayn_socks",return_value=10808),patch.object(self.f,"route_add_direct"), \
             patch.object(self.f,"route_delete"),patch.object(self.f,"instance_password",return_value="test"), \
             patch.object(self.f,"paired_management_client",side_effect=OSError("baseline unavailable")), \
             patch.object(self.f,"test_hy2",side_effect=test),patch.object(finder,"SocksUDPRelay",return_value=relay_context):
            result=self.f.run_paired_hy2(dict(candidate(),instance_id=IID),"192.0.2.1",observer=observer)
        self.assertEqual(events,["D","V"]*8)
        self.assertTrue(result["assessment"]["control_verified"])
        self.assertEqual(result["assessment"]["direct_ok"],8)
