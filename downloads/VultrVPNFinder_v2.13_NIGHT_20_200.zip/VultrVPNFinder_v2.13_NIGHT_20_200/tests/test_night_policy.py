import contextlib
import json
import unittest
from unittest.mock import patch, Mock

import finder
import runtime_support
import test_regressions as base
import test_paired_control as paired_tests

IID, candidate = base.IID, base.candidate


class NightPolicyTest(unittest.TestCase):
    def setUp(self):
        base.FinderTest.setUp(self)
        self.f.cfg.update(delete_all_failed=True, delete_setup_failed=True, delete_confirm_timeout_sec=0,
                          account_wide_active_limit=True, max_active_candidates=20)

    def deletable(self):
        self.f.api.get_instance.side_effect = [{"label": "vpnfinder-test-owned", "main_ip": "192.0.2.1"}, finder.APIError(404,"gone")]
        self.f.cfg["delete_confirm_timeout_sec"] = 1

    def paired_probes(self, direct=4, control=4):
        self.f.cfg["paired_hy2_control"] = True
        self.f.regions = {"fra": {"city": "Frankfurt"}}
        pairs = paired_tests.PairedAssessmentTest().pairs(direct,control)
        data={"pairs":pairs,"assessment":finder.assess_pairs(pairs,"198.51.100.20")}
        stack=contextlib.ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(patch.object(self.f,"ensure_candidate_bootstrap",return_value={"ok":True}))
        for name in ("route_add_direct","route_delete"):
            stack.enter_context(patch.object(self.f,name))
        stack.enter_context(patch.object(self.f,"run_paired_hy2",return_value=data))
        stack.enter_context(patch.object(self.f,"ping_test",return_value={"avg_ms":1,"loss_pct":0}))
        stack.enter_context(patch.object(self.f,"test_vless",return_value={"ok":0,"total":2}))
        stack.enter_context(patch.object(self.f,"ssh_test",return_value={"ok":0,"total":3}))
        return stack

    def test_shared_or_unverified_failure_is_deleted_after_diagnostic(self):
        self.paired_probes()
        self.deletable()
        self.assertFalse(self.f.process_created_candidate(candidate(),IID,{"main_ip":"192.0.2.1"}))
        self.f.collect_remote_diagnostics.assert_any_call(unittest.mock.ANY,"192.0.2.1","after_failed_tests")
        self.f.api.delete_instance.assert_called_once_with(IID)
        self.assertEqual(self.f.state["candidates"][IID]["phase"],"deleted")

    def test_generic_setup_or_client_error_is_deleted(self):
        self.deletable()
        with patch.object(self.f,"ensure_candidate_bootstrap",side_effect=OSError("local failure")),patch.object(self.f,"route_delete"):
            self.assertFalse(self.f.process_created_candidate(candidate(),IID,{"main_ip":"192.0.2.1"}))
        self.f.api.delete_instance.assert_called_once_with(IID)

    def test_hy2_good_is_saved_before_optional_checks_can_fail(self):
        stack=self.paired_probes(7,8)
        stack.enter_context(patch.object(self.f,"ping_test",side_effect=OSError("ping unavailable")))
        self.assertTrue(self.f.process_created_candidate(candidate(),IID,{"main_ip":"192.0.2.1"}))
        self.assertEqual(self.f.good_count(),1)
        self.assertIn(IID,self.f.state["good_ids"])
        self.assertTrue(self.f.good[0]["secondary_checks_pending"])
        self.f.api.delete_instance.assert_not_called()
        with self.assertRaises(RuntimeError):self.f.safe_delete(IID)

    def test_ctrl_c_after_hy2_success_cannot_delete_the_good(self):
        stack=self.paired_probes(8,8)
        stack.enter_context(patch.object(self.f,"ping_test",side_effect=KeyboardInterrupt()))
        with self.assertRaises(KeyboardInterrupt):
            self.f.process_created_candidate(candidate(),IID,{"main_ip":"192.0.2.1"})
        self.assertEqual(self.f.good_count(),1)
        self.assertTrue(self.f.cleanup_failed_candidates(include_unfinished=True))
        self.f.api.delete_instance.assert_not_called()

    def test_deletion_is_not_counted_complete_before_404(self):
        self.f.remember_candidate(candidate(),IID,"paired_failed_retained")
        self.f.api.get_instance.return_value={"label":"vpnfinder-test-owned"}
        self.assertFalse(self.f.safe_delete(IID))
        self.assertEqual(self.f.state["candidates"][IID]["phase"],"deleting")
        self.assertEqual(self.f.active_candidate_count(),1)

    def test_old_failed_candidates_are_cleaned_but_historical_good_is_protected(self):
        other="8a0c629e-56fd-4fb6-ac50-5b7312c47498"
        self.f.remember_candidate(candidate(),IID,"paired_failed_retained")
        self.f.remember_candidate(candidate(),other,"paired_failed_retained")
        self.f.state["good_ids"]=[other]
        self.deletable()
        self.assertTrue(self.f.cleanup_failed_candidates())
        self.f.api.delete_instance.assert_called_once_with(IID)
        self.assertNotEqual(self.f.state["candidates"][other]["phase"],"deleted")

    def test_unresolved_cleanup_stops_creation(self):
        self.f.remember_candidate(candidate(),IID,"delete_failed")
        self.f.api.get_instance.side_effect=finder.APIError(503,"unavailable")
        with patch.object(self.f,"preflight"),patch.object(self.f,"create_pending_candidate") as create:
            with self.assertRaisesRegex(RuntimeError,"cleanup"):
                self.f.main_loop()
        create.assert_not_called()
        self.assertEqual(self.f.state["candidates"][IID]["phase"],"delete_failed")

    def test_account_wide_limit_counts_unrelated_servers_without_touching_them(self):
        self.f.api.list_instances.return_value=[{"id":f"external-{i}"} for i in range(20)]
        with patch.object(self.f,"preflight"),patch.object(self.f,"create_pending_candidate") as create:
            self.assertFalse(self.f.main_loop())
        create.assert_not_called()
        self.f.api.delete_instance.assert_not_called()

    def test_ambiguous_create_is_reconciled_and_cleaned_on_exit(self):
        label="vpnfinder-test-001-fra-deadbeef"
        self.f.api.list_instances.side_effect=[[],[{"id":IID,"label":label}]]
        def uncertain(*args):
            self.f.state["pending_creates"][label]=dict(candidate(),label=label)
            self.f.persist_state()
            raise finder.AmbiguousCreateError("POST outcome unknown")
        self.deletable()
        self.f.api.get_instance.side_effect=[{"label":label},finder.APIError(404,"gone")]
        with patch.object(self.f,"preflight"),patch.object(self.f,"plan_for_region",return_value={"id":"test-plan"}), \
             patch.object(self.f,"create_pending_candidate",side_effect=uncertain):
            with self.assertRaises(finder.AmbiguousCreateError):self.f.main_loop()
        self.assertFalse(self.f.state["pending_creates"])
        self.assertEqual(self.f.state["candidates"][IID]["phase"],"deleted")
        self.f.api.delete_instance.assert_called_once_with(IID)

    def test_shutdown_cleanup_can_run_after_cooperative_stop(self):
        self.f.remember_candidate(candidate(),IID,"testing")
        self.deletable()
        runtime_support.STOP_PATH.touch()
        with runtime_support.cleanup_mode():
            runtime_support.check_stop()
            self.assertTrue(self.f.cleanup_failed_candidates(include_unfinished=True))
        self.assertEqual(self.f.state["candidates"][IID]["phase"],"deleted")


class APIDeadlineTest(unittest.TestCase):
    def test_expired_cleanup_deadline_prevents_any_http_request(self):
        api=finder.VultrAPI("test-key")
        api.request_deadline=1
        with patch.object(finder.urllib.request,"urlopen") as request:
            with self.assertRaises(TimeoutError):api.get_instance(IID)
        request.assert_not_called()
