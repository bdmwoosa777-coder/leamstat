﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-FinderAdmin
Assert-FinderKey
$pythonPath = Get-FinderPython
$budget = Get-Content (Join-Path $PSScriptRoot 'config_search_10.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$current = Get-Content (Join-Path $PSScriptRoot 'config.json') -Raw -Encoding UTF8 | ConvertFrom-Json
$backup = Join-Path $PSScriptRoot 'backups'
New-Item -ItemType Directory -Force -Path $backup | Out-Null
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
Copy-Item (Join-Path $PSScriptRoot 'config.json') (Join-Path $backup "config-before-night-$stamp.json")
$settings = @('good_target','max_total_attempts','max_runtime_hours','provision_pipeline_size','max_active_candidates','delete_bad','delete_setup_failed','delete_verified_filtered','delete_unconfirmed_protocols','delete_all_failed','account_wide_active_limit','delete_confirm_timeout_sec')
foreach ($name in $settings) {
    $current | Add-Member -NotePropertyName $name -NotePropertyValue $budget.$name -Force
}
$current | ConvertTo-Json -Depth 20 | Set-Content (Join-Path $PSScriptRoot 'config.json') -Encoding UTF8
Write-Host 'NIGHT: target 10 GOOD, max 200 new attempts, 10h, pipeline 3, account active limit 20.'
Write-Host 'Owned failed/untested candidates will be deleted. GOOD are protected. Check runs first.'
& $pythonPath (Join-Path $PSScriptRoot 'finder.py') --check
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
& $pythonPath (Join-Path $PSScriptRoot 'finder.py')
exit $LASTEXITCODE
