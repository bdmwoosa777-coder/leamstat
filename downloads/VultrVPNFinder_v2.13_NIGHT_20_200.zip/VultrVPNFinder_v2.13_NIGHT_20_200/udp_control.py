"""SOCKS5 UDP ASSOCIATE transport. Unsupported UDP never falls back to direct."""
import ipaddress
import select
import socket
import threading
from socks_relay import recv_exact


def address(sock):
    kind = recv_exact(sock, 1)[0]
    if kind == 1:
        return socket.inet_ntop(socket.AF_INET, recv_exact(sock, 4))
    if kind == 4:
        return socket.inet_ntop(socket.AF_INET6, recv_exact(sock, 16))
    if kind == 3:
        return recv_exact(sock, recv_exact(sock, 1)[0]).decode("ascii")
    raise ConnectionError("Invalid SOCKS UDP endpoint")


def encode_datagram(host, port, payload):
    ip = ipaddress.ip_address(host)
    return b"\0\0\0" + (b"\x01" if ip.version == 4 else b"\x04") + ip.packed + int(port).to_bytes(2, "big") + payload


def decode_datagram(data):
    if len(data) < 4 or data[:3] != b"\0\0\0":
        raise ValueError("Fragmented/invalid SOCKS UDP packet")
    kind, offset = data[3], 4
    if kind in (1, 4):
        length = 4 if kind == 1 else 16
        if len(data) < offset+length+2:
            raise ValueError("Truncated SOCKS UDP packet")
        host = socket.inet_ntop(socket.AF_INET if kind == 1 else socket.AF_INET6, data[offset:offset+length])
        offset += length
    elif kind == 3:
        if len(data) < 5:
            raise ValueError("Truncated SOCKS UDP packet")
        length = data[4]
        offset = 5
        if len(data) < offset+length+2:
            raise ValueError("Truncated SOCKS UDP packet")
        host = data[offset:offset+length].decode("ascii")
        offset += length
    else:
        raise ValueError("Invalid SOCKS UDP address")
    return host, int.from_bytes(data[offset:offset+2], "big"), data[offset+2:]


class SocksUDPRelay:
    def __init__(self, proxy_port, target_host, target_port=443):
        self.proxy_port, self.target = int(proxy_port), (target_host, int(target_port))
        self.front = self.upstream = self.control = None
        self.stopped = threading.Event()
        self.errors = []
        self.sent = self.received = 0
        self.thread = None

    def __enter__(self):
        try:
            self.front = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self.front.bind(("127.0.0.1", 0))
            self.port = self.front.getsockname()[1]
            self.control = socket.create_connection(("127.0.0.1", self.proxy_port), timeout=5)
            self.control.sendall(b"\x05\x01\x00")
            if recv_exact(self.control, 2) != b"\x05\x00":
                raise ConnectionError("SOCKS5 authentication unavailable")
            self.control.sendall(b"\x05\x03\x00\x01" + b"\0"*6)
            head = recv_exact(self.control, 3)
            if head != b"\x05\x00\x00":
                raise ConnectionError(f"SOCKS5 UDP ASSOCIATE unsupported/refused: {head.hex()}")
            host = address(self.control)
            port = int.from_bytes(recv_exact(self.control, 2), "big")
            if host in ("0.0.0.0", "::"):
                host = "127.0.0.1"
            self.upstream = socket.socket(socket.AF_INET6 if ":" in host else socket.AF_INET, socket.SOCK_DGRAM)
            self.upstream.connect((host, port))
            self.proxy_udp_endpoint = (host, port)
            self.thread = threading.Thread(target=self._run, daemon=True)
            self.thread.start()
            return self
        except BaseException:
            self.close()
            raise

    def _run(self):
        client = None
        try:
            while not self.stopped.is_set():
                ready, _, _ = select.select([self.front, self.upstream], [], [], 0.2)
                if self.front in ready:
                    data, client = self.front.recvfrom(65535)
                    self.upstream.send(encode_datagram(*self.target, data))
                    self.sent += 1
                if self.upstream in ready:
                    packet = self.upstream.recv(65535)
                    try:
                        host, port, payload = decode_datagram(packet)
                    except ValueError:
                        continue
                    if (host, port) == self.target and client is not None:
                        self.front.sendto(payload, client)
                        self.received += 1
        except OSError as exc:
            if not self.stopped.is_set():
                self.errors.append(type(exc).__name__)

    def close(self):
        self.stopped.set()
        if self.thread:
            self.thread.join(1)
        for sock in (self.front, self.upstream, self.control):
            if sock:
                sock.close()

    def __exit__(self, *exc):
        self.close()
