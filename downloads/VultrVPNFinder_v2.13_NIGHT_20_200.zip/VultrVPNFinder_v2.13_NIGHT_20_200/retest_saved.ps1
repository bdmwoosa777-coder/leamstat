﻿$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-FinderAdmin
Assert-FinderKey
$pythonPath = Get-FinderPython
Write-Host 'Retest saved candidates only. No new VPS will be created.'
& $pythonPath (Join-Path $PSScriptRoot 'finder.py') --retest-saved
exit $LASTEXITCODE
