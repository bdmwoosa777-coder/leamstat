"""Runs on Ubuntu, from cloud-init or the local SCP bundle (Python stdlib only)."""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import urllib.request
import zipfile

READY = Path("/var/lib/vpnfinder-ready")
CONF = Path("/etc/vpnfinder")
XRAY = Path("/usr/local/lib/vpnfinder-xray/xray")
UNITS = Path("/etc/systemd/system")


def command(args, timeout=30):
    cp = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=timeout)
    if cp.returncode:
        raise RuntimeError(f"{args[0]} failed (exit {cp.returncode}): " + cp.stdout.decode(errors="replace")[-2000:])
    return cp.stdout


def public_file(name, text):
    path = READY / name
    tmp = READY / f".{name}.{os.getpid()}.tmp"
    tmp.write_text(text[-8000:] + "\n", encoding="utf-8")
    tmp.chmod(0o644)
    tmp.replace(path)


def status(text):
    # A late downloader must not overwrite the success of the SCP fallback.
    if not (READY / "READY").exists():
        public_file("STATUS", text)
        public_file("HEALTH.json", json.dumps({"status": text, "ready": False}))
    print(text, flush=True)


@contextlib.contextmanager
def install_lock():
    import fcntl
    with open("/run/vpnfinder-install.lock", "a") as lock:
        deadline = time.monotonic() + 30
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    raise TimeoutError("Another VPNFinder installer is still running")
                time.sleep(0.2)
        try:
            yield
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)


def service_text(kind, diagnostic_port=80):
    if kind == "xray":
        return """[Unit]
Description=VPNFinder Xray HY2 and VLESS Reality
Wants=network-online.target
After=network-online.target
StartLimitIntervalSec=0
[Service]
Type=simple
ExecStart=/usr/local/lib/vpnfinder-xray/xray run -config /etc/vpnfinder/xray.json
Restart=on-failure
RestartSec=2
LimitNOFILE=65535
NoNewPrivileges=true
UMask=0077
[Install]
WantedBy=multi-user.target
"""
    if not 1 <= int(diagnostic_port) <= 65535 or int(diagnostic_port) in (443, 8443):
        raise ValueError("Invalid diagnostic HTTP port")
    return f"""[Unit]
Description=VPNFinder public bootstrap status
After=network.target
[Service]
Type=simple
User=nobody
ExecStart=/usr/bin/python3 -m http.server {int(diagnostic_port)} --bind 0.0.0.0 --directory /var/lib/vpnfinder-ready
Restart=on-failure
RestartSec=2
AmbientCapabilities=CAP_NET_BIND_SERVICE
CapabilityBoundingSet=CAP_NET_BIND_SERVICE
NoNewPrivileges=true
ProtectSystem=strict
ProtectHome=true
PrivateTmp=true
[Install]
WantedBy=multi-user.target
"""


def active():
    return subprocess.run(["systemctl", "is-active", "--quiet", "vpnfinder-xray.service"], timeout=10).returncode == 0


def installed_ready(stage):
    try:
        return ((READY / "READY").exists() and
                (CONF / "xray.json").read_bytes() == (stage / "xray.json").read_bytes() and active())
    except FileNotFoundError:
        return False


def ensure_firewall(diagnostic_port):
    # Respect UFW's own rule management; never disable the firewall or flush rules.
    if shutil.which("ufw"):
        cp = subprocess.run(["ufw", "status"], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, timeout=10)
        if cp.returncode == 0 and "status: active" in cp.stdout.decode(errors="replace").lower():
            for rule in ("443/udp", "8443/tcp", f"{int(diagnostic_port)}/tcp"):
                command(["ufw", "allow", rule], timeout=15)
            print("Active UFW: allowed HY2 UDP/443, VLESS TCP/8443 and diagnostic HTTP", flush=True)


def download_binary(stage, url, expected):
    archive = stage / "xray.zip"
    last = None
    for attempt in range(1, 4):
        try:
            status(f"DOWNLOAD_ATTEMPT_{attempt}")
            req = urllib.request.Request(url, headers={"User-Agent": "VPNFinder/2.7"})
            with urllib.request.urlopen(req, timeout=30) as src, archive.open("wb") as dst:
                shutil.copyfileobj(src, dst)
            digest = sha256_file(archive)
            if digest != expected:
                raise RuntimeError("Linux Xray archive SHA256 mismatch")
            with zipfile.ZipFile(archive) as z, z.open("xray") as src, (stage / "xray").open("wb") as dst:
                shutil.copyfileobj(src, dst)
            return
        except Exception as exc:
            last = exc
            if installed_ready(stage):
                return
            print(f"Download attempt {attempt} failed: {exc}", flush=True)
            if attempt < 3:
                time.sleep(attempt * 2)
    raise RuntimeError(f"Xray download failed: {last}")


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def install(stage, diagnostic_port):
    with install_lock():
        ensure_firewall(diagnostic_port)
        if installed_ready(stage):
            return
        for name in ("READY", "FAILED"):
            (READY / name).unlink(missing_ok=True)
        status("INSTALLING")
        CONF.mkdir(parents=True, exist_ok=True)
        CONF.chmod(0o700)
        XRAY.parent.mkdir(parents=True, exist_ok=True)
        for src, dst, mode in ((stage / "xray", XRAY, 0o755), (stage / "xray.json", CONF / "xray.json", 0o600)):
            temp = dst.with_name(dst.name + f".{os.getpid()}.new")
            shutil.copyfile(src, temp)
            temp.chmod(mode)
            temp.replace(dst)
        # Every VPS gets its own certificate; the distributed template is for local parsing only.
        if not (CONF / "hy.crt").exists() or not (CONF / "hy.key").exists():
            command(["openssl", "req", "-x509", "-newkey", "ec", "-pkeyopt", "ec_paramgen_curve:prime256v1",
                     "-nodes", "-keyout", str(CONF / "hy.key"), "-out", str(CONF / "hy.crt"),
                     "-days", "3650", "-subj", "/CN=vpnfinder.local"])
        (CONF / "hy.key").chmod(0o600)
        (CONF / "hy.crt").chmod(0o644)
        status("XRAY_CONFIG_TEST")
        command([str(XRAY), "run", "-test", "-config", str(CONF / "xray.json")], timeout=20)
        (UNITS / "vpnfinder-xray.service").write_text(service_text("xray"), encoding="utf-8")
        command(["systemctl", "daemon-reload"])
        command(["systemctl", "enable", "vpnfinder-xray.service"])
        command(["systemctl", "restart", "vpnfinder-xray.service"])
        for _ in range(3):
            time.sleep(1)
            if not active():
                detail = command(["journalctl", "-u", "vpnfinder-xray.service", "-n", "15", "--no-pager"])
                raise RuntimeError("Xray service failed: " + detail.decode(errors="replace")[-2000:])
        public_file("READY", "READY")
        public_file("STATUS", "READY")
        config_hash = hashlib.sha256(json.dumps(json.loads((CONF / "xray.json").read_text()),
                                               sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        public_file("HEALTH.json", json.dumps({"status": "READY", "ready": True, "config_sha256": config_hash}))
        print("READY: HY2 UDP/443, VLESS Reality TCP/8443; systemd enabled", flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--download-url")
    parser.add_argument("--sha256")
    parser.add_argument("--diagnostic-port", type=int, default=80)
    args = parser.parse_args()
    os.umask(0o077)
    READY.mkdir(parents=True, exist_ok=True)
    READY.chmod(0o755)
    try:
        with install_lock():
            ensure_firewall(args.diagnostic_port)
            if installed_ready(args.stage):
                return 0
            (READY / "READY").unlink(missing_ok=True)
            (READY / "FAILED").unlink(missing_ok=True)
            (UNITS / "vpnfinder-diag.service").write_text(service_text("diag", args.diagnostic_port), encoding="utf-8")
            command(["systemctl", "daemon-reload"])
            command(["systemctl", "enable", "--now", "vpnfinder-diag.service"])
        status("BOOTSTRAP_STARTED")
        if not (args.stage / "xray").exists():
            if not args.download_url or not args.sha256:
                raise RuntimeError("No Linux binary or download URL/checksum was supplied")
            download_binary(args.stage, args.download_url, args.sha256)
        install(args.stage, args.diagnostic_port)
        return 0
    except Exception as exc:
        with install_lock():
            if installed_ready(args.stage):
                return 0
            public_file("FAILED", f"{type(exc).__name__}: {exc}")
            public_file("BOOTSTRAP.log", f"{type(exc).__name__}: {exc}")
            status("FAILED")
            public_file("HEALTH.json", json.dumps({"status": "FAILED", "ready": False, "error": f"{type(exc).__name__}: {exc}"}))
        print(f"BOOTSTRAP FAILED: {type(exc).__name__}: {exc}", flush=True)
        return 1
    finally:
        shutil.rmtree(args.stage, ignore_errors=True)


if __name__ == "__main__":
    raise SystemExit(main())
