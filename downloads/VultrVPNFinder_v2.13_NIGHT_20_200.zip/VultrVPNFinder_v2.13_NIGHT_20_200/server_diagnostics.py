"""Read-only server checks; prints no authentication or private-key material."""
import json
import shutil
import subprocess
import urllib.request
import urllib.error


def capture(argv, timeout=6):
    if not shutil.which(argv[0]):
        return {"error": "command unavailable"}
    try:
        cp = subprocess.run(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=timeout)
        return {"exit": cp.returncode, "output": cp.stdout.decode(errors="replace")[-2500:]}
    except subprocess.TimeoutExpired:
        return {"error": "timeout"}


def collect(sni, urls):
    result = {}
    for key, argv in {
        "listeners": ["ss", "-lntup"],
        "service_state": ["systemctl", "show", "vpnfinder-xray.service", "-p", "ActiveState", "-p", "SubState", "-p", "NRestarts", "-p", "ExecMainStatus"],
        "server_core_version": ["/usr/local/lib/vpnfinder-xray/xray", "version"],
        "server_config_test": ["/usr/local/lib/vpnfinder-xray/xray", "run", "-test", "-config", "/etc/vpnfinder/xray.json"],
        "ufw": ["ufw", "status", "verbose"],
        "iptables": ["iptables", "-S", "INPUT"],
        "nft": ["nft", "list", "ruleset"],
        "xray_journal": ["journalctl", "-u", "vpnfinder-xray.service", "-n", "25", "--no-pager"],
        "diag_journal": ["journalctl", "-u", "vpnfinder-diag.service", "-n", "15", "--no-pager"],
    }.items():
        result[key] = capture(argv)
    result["reality_target_tls"] = capture(["openssl", "s_client", "-connect", sni+":443", "-servername", sni, "-brief"], timeout=8)
    result["internet_http"] = []
    for url in urls[:2]:
        try:
            with urllib.request.urlopen(url, timeout=6) as response:
                result["internet_http"].append({"url": url, "status": response.status})
        except Exception as exc:
            result["internet_http"].append({"url": url, "error": type(exc).__name__})
    return result
