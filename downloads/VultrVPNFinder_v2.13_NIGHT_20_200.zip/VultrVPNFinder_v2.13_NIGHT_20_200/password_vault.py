"""Current Windows user's DPAPI vault. No plaintext fallback on other systems."""
import ctypes
from ctypes import wintypes
import os
from pathlib import Path
import uuid


class Blob(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]


def crypt(data, protect):
    if os.name != "nt":
        raise OSError("DPAPI is available only on Windows")
    crypt32 = ctypes.WinDLL("crypt32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    buffer = (ctypes.c_ubyte * len(data)).from_buffer_copy(data)
    source, output = Blob(len(data), buffer), Blob()
    flags = 1  # CRYPTPROTECT_UI_FORBIDDEN; scope is CurrentUser, not LocalMachine.
    if protect:
        function = crypt32.CryptProtectData
        function.argtypes = [ctypes.POINTER(Blob), wintypes.LPCWSTR, ctypes.c_void_p,
                             ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        args = (ctypes.byref(source), "VPNFinder server password", None, None, None, flags, ctypes.byref(output))
    else:
        function = crypt32.CryptUnprotectData
        function.argtypes = [ctypes.POINTER(Blob), ctypes.c_void_p, ctypes.c_void_p,
                             ctypes.c_void_p, ctypes.c_void_p, wintypes.DWORD, ctypes.POINTER(Blob)]
        args = (ctypes.byref(source), None, None, None, None, flags, ctypes.byref(output))
    function.restype = wintypes.BOOL
    if not function(*args):
        raise OSError("Windows DPAPI operation failed", ctypes.get_last_error())
    try:
        return ctypes.string_at(output.pbData, output.cbData)
    finally:
        kernel32.LocalFree.argtypes = [ctypes.c_void_p]
        kernel32.LocalFree.restype = ctypes.c_void_p
        kernel32.LocalFree(output.pbData)


class PasswordVault:
    def __init__(self, root):
        self.root = Path(root)

    def path(self, instance_id):
        return self.root / (str(uuid.UUID(instance_id)) + ".dpapi")

    def save(self, instance_id, password):
        path = self.path(instance_id)
        encrypted = crypt(password.encode("utf-8"), True)
        self.root.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".tmp")
        tmp.write_bytes(encrypted)
        tmp.chmod(0o600)
        tmp.replace(path)

    def load(self, instance_id):
        path = self.path(instance_id)
        if not path.exists():
            return ""
        return crypt(path.read_bytes(), False).decode("utf-8")
