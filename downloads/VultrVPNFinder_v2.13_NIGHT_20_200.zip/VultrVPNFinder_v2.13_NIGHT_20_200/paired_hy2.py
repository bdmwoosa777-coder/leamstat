"""Paired results and remote observation; conclusions describe paths, not a censor."""
import ipaddress
import re
import password_ssh


def hy2_peers(text):
    result = set()
    for line in text.splitlines():
        if "hy2-in" not in line or "accepted" not in line:
            continue
        match = re.search(r"from (?:tcp:|udp:)?(\[[^]]+\]|[^\s]+):(\d+) accepted", line)
        if match:
            try:
                result.add(str(ipaddress.ip_address(match[1].strip("[]"))))
            except ValueError:
                pass
    return sorted(result)


class JournalObserver:
    def __init__(self, client):
        self.client = client
        rc, output = password_ssh.execute(client, 'printf "%s" "$SSH_CONNECTION"', timeout=10)
        self.proxy_egress = str(ipaddress.ip_address(output.split()[0])) if rc == 0 and output.split() else None

    def checkpoint(self):
        rc, output = password_ssh.execute(self.client,
            "journalctl -u vpnfinder-xray.service -n 0 --show-cursor --no-pager -o cat", timeout=10)
        match = re.search(r"-- cursor: ([A-Za-z0-9=;:_-]+)", output)
        return match[1] if rc == 0 and match else None

    def peers_after(self, cursor):
        if cursor is None:
            return []
        rc, output = password_ssh.execute(self.client,
            "journalctl -u vpnfinder-xray.service --after-cursor='"+cursor+"' --no-pager -o cat", timeout=10)
        return hy2_peers(output) if rc == 0 else []


def assess(pairs, proxy_egress=None, direct_baseline=None):
    direct_ips = {ip for p in pairs for ip in p["direct"].get("server_peers", [])}
    if direct_baseline:
        direct_ips.add(direct_baseline)
    control_ips = {ip for p in pairs for ip in p["control"].get("server_peers", [])}
    success_rows = [p["control"] for p in pairs if p["control"].get("ok")]
    control_attempted = sum(bool(p["control"].get("attempted")) for p in pairs)
    verified = bool(len(pairs) == 8 and control_attempted == 8 and proxy_egress and direct_ips and proxy_egress not in direct_ips and success_rows and
                    control_ips == {proxy_egress} and
                    all(r.get("transport") == "SOCKS5_UDP" and r.get("server_peers") == [proxy_egress] for r in success_rows))
    direct = sum(bool(p["direct"].get("ok")) for p in pairs)
    control = sum(bool(p["control"].get("ok")) for p in pairs)
    outcomes = [bool(p["direct"].get("ok")) for p in pairs]
    consecutive = any(not a and not b for a, b in zip(outcomes, outcomes[1:]))
    good = len(pairs) == 8 and direct >= 7 and not consecutive
    if good:
        verdict = "GOOD_DIRECT" if not verified or control >= 7 else "GOOD_DIRECT_CONTROL_UNSTABLE"
    elif direct == 0 and control == 0:
        verdict = "CHECK_SERVER_CONFIG_AND_NETWORK" if control_attempted else "CONTROL_UNAVAILABLE_CHECK_DIRECT_AND_SERVER"
    elif not verified:
        verdict = "CONTROL_UNVERIFIED"
    elif control == 8:
        verdict = "DIRECT_PATH_SPECIFIC_FAILURE"
    elif direct == 0 and control == 0:
        verdict = "CHECK_SERVER_CONFIG_AND_NETWORK"
    else:
        verdict = "SHARED_OR_CONTROL_INSTABILITY"
    return {"direct_ok": direct, "control_ok": control, "total": len(pairs), "control_verified": verified,
            "control_attempted": control_attempted, "direct_baseline": direct_baseline, "proxy_egress": proxy_egress, "direct_peers": sorted(direct_ips), "control_peers": sorted(control_ips),
            "consecutive_direct_failures": consecutive, "good_hy2": good, "verdict": verdict}
