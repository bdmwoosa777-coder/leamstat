"""Summary is about observed samples, never continuous availability between probes."""
from datetime import datetime

def when(r):return datetime.fromisoformat(r['timestamp']).timestamp()

def summarize(rows):
    out={}
    for ip in dict.fromkeys(r['ip'] for r in rows):
        rr=sorted([r for r in rows if r['ip']==ip],key=when)
        cold=[r for r in rr if r['test_type']=='COLD'];hot=[r for r in rr if r['test_type']=='HOT'];vless=[r for r in rr if r['test_type']=='VLESS_CONTROL']
        item={}
        for port in (443,8443):
            r=[r for r in cold if r['port']==port];fail_start=None;longest=0;max_count=count=0
            for x in r:
                if not x['ok']:
                    fail_start=when(x) if fail_start is None else fail_start;count+=1;max_count=max(max_count,count);longest=max(longest,when(x)-fail_start)
                else:fail_start=None;count=0
            item['cold_udp'+str(port)]={'success':sum(bool(x['ok']) for x in r),'verified_success':sum(bool(x.get('direct_verified')) for x in r),'total':len(r),'longest_sampled_failure_span_seconds':longest,'max_consecutive_failed_samples':max_count}
        interruptions=0;was_broken=False;uptime=0
        for n,r in enumerate(hot):
            broken=r.get('state')!='HOT_SESSION_ALIVE' or not r.get('direct_verified')
            if broken and not was_broken:interruptions+=1
            was_broken=broken
            if n and not broken:
                prev=hot[n-1]
                if prev.get('state')=='HOT_SESSION_ALIVE' and prev.get('direct_verified') and prev.get('session_identifier')==r.get('session_identifier') and prev.get('pid')==r.get('pid'):
                    uptime+=when(r)-when(prev)
        pairs={}
        for r in cold:pairs.setdefault(r['cycle'],{})[r['port']]=r
        complete=[p for p in pairs.values() if 443 in p and 8443 in p]
        after=[]
        for r in cold:
            if not r['ok']:
                alive=next((h for h in hot if 0<=when(h)-when(r)<=180 and h.get('state')=='HOT_SESSION_ALIVE' and h.get('direct_verified')),None)
                if alive:after.append({'cold_time':r['timestamp'],'port':r['port'],'hot_time':alive['timestamp'],'session_identifier':alive['session_identifier']})
        item.update(hot_sampled_alive_span_seconds=uptime,hot_interruptions=interruptions,
                    hot_reconnected_samples=sum(h.get('state')=='HOT_RECONNECTED' for h in hot),
                    vless={'success':sum(bool(r['ok']) for r in vless),'total':len(vless)},
                    cold_both_failed_cycles=sum(not p[443]['ok'] and not p[8443]['ok'] for p in complete),
                    complete_port_pairs=len(complete),cold_fail_then_verified_hot_ok=after)
        out[ip]=item
    return {'servers':out,'limits':['HOT uptime is the span bracketed by verified successful samples; interruptions between samples may be missed.',
                                   'Failure spans are first-to-last failed samples, not exact outage duration.',
                                   'Port pairs are separated by 60-120 seconds and are not simultaneous.',
                                   'PID/session_identifier names a client generation, not a cryptographically observed QUIC connection ID.',
                                   'Fresh process starts and successful reconnect counts are lower bounds on network connection attempts. Failed internal reconnects may not emit a successful count.']}
