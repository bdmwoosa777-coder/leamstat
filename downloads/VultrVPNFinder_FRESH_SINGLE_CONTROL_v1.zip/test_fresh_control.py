import copy,json,tempfile,types,unittest
from pathlib import Path
from unittest.mock import Mock,patch
import fresh_control as c
import ab_server

class Tests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup)
  root=Path(self.temp.name)
  for name,value in [('ROOT',root),('RECORD',root/'control.json')]:
   p=patch.object(c,name,value);p.start();self.addCleanup(p.stop)
  self.f=types.SimpleNamespace(api=Mock(),os_id=2284,ssh_key_id='existing-key',state={'candidates':{'old':{'candidate':{'ip':'192.0.2.1'}}}})
  self.f.api.list_instances.return_value=[{'id':'old','main_ip':'192.0.2.1'}]
  self.f.api.request.return_value={'instance':{'id':'new','main_ip':'192.0.2.2','default_password':'test-only'}}
  self.cfg={'plan_id':'vhp-1c-1gb-amd'};self.vault=Mock()
 def test_exactly_one_post_and_separate_state(self):
  before=copy.deepcopy(self.f.state);record=c.create_once(self.f,self.cfg,self.vault)
  again=c.create_once(self.f,self.cfg,self.vault)
  self.assertEqual(record['instance_id'],again['instance_id']);self.assertEqual(self.f.state,before)
  self.f.api.request.assert_called_once();args,kw=self.f.api.request.call_args
  self.assertEqual(args[:2],('POST','/instances'));self.assertEqual(kw['retries'],1)
  self.assertEqual(args[2]['region'],'ams');self.assertEqual(args[2]['sshkey_id'],['existing-key'])
  self.assertFalse(args[2]['enable_ipv6']);self.assertNotIn('test-only',c.RECORD.read_text())
 def test_timeout_cannot_trigger_second_post(self):
  self.f.api.request.side_effect=TimeoutError('unknown')
  with self.assertRaises(TimeoutError):c.create_once(self.f,self.cfg,self.vault)
  with self.assertRaises(RuntimeError):c.create_once(self.f,self.cfg,self.vault)
  self.f.api.request.assert_called_once();self.assertTrue(json.loads(c.RECORD.read_text())['post_armed'])
 def test_armed_before_post(self):
  def request(*args,**kw):
   self.assertTrue(json.loads(c.RECORD.read_text())['post_armed']);return {'instance':{'id':'new','main_ip':'192.0.2.2'}}
  self.f.api.request.side_effect=request;c.create_once(self.f,self.cfg,self.vault)
 def test_recovery_uses_label_without_creation(self):
  self.f.api.request.side_effect=TimeoutError()
  with self.assertRaises(TimeoutError):c.create_once(self.f,self.cfg,self.vault)
  record=json.loads(c.RECORD.read_text());self.f.api.list_instances.return_value=[{'id':'new','label':record['label'],'main_ip':'192.0.2.2'}]
  restored=c.create_once(self.f,self.cfg,self.vault);self.assertEqual(restored['instance_id'],'new');self.f.api.request.assert_called_once()
 def test_original_instance_cannot_be_modified(self):
  record={'kind':'fresh-clean-control-v1','instance_id':'old','original_instance_ids':['old'],'label':'clean'}
  with self.assertRaises(RuntimeError):c.owned_instance(self.f,record)
  self.f.api.get_instance.assert_not_called()
 def test_wrong_label_or_region_refused(self):
  record={'kind':'fresh-clean-control-v1','instance_id':'new','original_instance_ids':['old'],'label':'clean','plan_id':'p'}
  for change in ({'label':'old-vpn'},{'region':'fra'}):
   self.f.api.get_instance.return_value=dict({'id':'new','label':'clean','region':'ams','main_ip':'192.0.2.2'},**change)
   with self.subTest(change=change),self.assertRaises(RuntimeError):c.owned_instance(self.f,record)
 def test_test_is_never_repeated_after_fail(self):
  with self.assertRaises(RuntimeError):c.four_checks(self.f,{'test_armed':True},self.cfg,{}, {})
 def test_fresh_udp_validation_needs_no_fake_vless_listener(self):
  from test_ab import Checks
  nft=Checks().nft_fixture()
  result=ab_server.validate_network('UNCONN 0 0 0.0.0.0:443 0.0.0.0:*','',nft,require_vless=False)
  self.assertFalse(result['vless_tcp8443_listener']);self.assertTrue(result['udp8443_redirect_to_443'])
  with self.assertRaises(RuntimeError):ab_server.validate_network('UNCONN 0 0 0.0.0.0:443 0.0.0.0:*','',nft)
 def test_four_attempts_order_retains_vps_and_does_not_retry_failed_direct(self):
  import contextlib
  from unittest.mock import MagicMock
  events=[];record={'instance_id':'new','phase':'prepared'};server={'ip':'192.0.2.2','domain':'fresh.example.org','expected_direct_peer':'192.0.2.10'}
  root=c.ROOT
  class Run:
   def __init__(self,*args):self.id='test';self.starts=0;self.dir=root/'run';self.dir.mkdir()
  class Session:
   def __init__(self,f,s,candidate,port,actor,run):events.append(('D',port));run.starts+=1;self.port=port
   def request(self):return {'ok':False,'code':0}
   def count(self):return 1
   def close(self):pass
  observer=Mock();observer.proxy_peer=c.control.EXPECTED_PEER;observer.after.return_value=[]
  def control(f,s,candidate,port,*args):events.append(('C',port));return {'process_started':True,'proxy_http_success':True}
  self.f.cfg={'test_urls':['https://example.com/']}
  with patch.object(c.ab,'ROUTES',root/'routes.json'),patch.object(c.ab,'quiet_check'),patch.object(c.ab,'Routes'),patch.object(c.ab,'Run',Run),patch.object(c.ab,'Session',Session),patch.object(c.ab,'Observer',return_value=observer),patch.object(c.ab,'management',return_value=contextlib.nullcontext(Mock())),patch.object(c.control,'one',side_effect=control),patch.object(c.core,'BASE',root),patch('builtins.print'):
   c.four_checks(self.f,record,{'quiet_minutes':120},{},server)
  self.assertEqual(events,[('D',443),('D',8443),('C',443),('C',8443)])
  self.assertEqual(record['phase'],'tested_retained');self.assertTrue(record['test_armed'])
  self.assertTrue((root/'FRESH_CONTROL_RESULTS.zip').exists());self.f.api.delete_instance.assert_not_called()
