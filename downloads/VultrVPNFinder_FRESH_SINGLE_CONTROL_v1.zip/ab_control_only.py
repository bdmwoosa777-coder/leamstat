"""Exactly six SOCKS5 UDP checks. No DIRECT HY2, route edits, server writes or quiet marker."""
import contextlib
import copy
import json
import os
from pathlib import Path
import subprocess
import tempfile
import uuid
import zipfile
import finder as core
from udp_control import SocksUDPRelay

EXPECTED_PEER='82.47.60.219'
URL='https://www.gstatic.com/generate_204'
PROXY_PORT=10808

def connection_count(path):
    counts=[]
    for line in path.read_text(encoding='utf-8',errors='replace').splitlines():
        try:
            r=json.loads(line)
            if r.get('msg')=='connected to server':counts.append(int(r['count']))
        except (ValueError,TypeError,KeyError):pass
    return max(counts,default=0)

def one(f,server,candidate,port,observer,directory):
    logfile=directory/f"control-{server['ip']}-{port}.log"
    row={'ip':server['ip'],'port':port,'transport':'SOCKS5_UDP','proxy':'127.0.0.1:10808',
         'expected_control_peer':EXPECTED_PEER,'handshake_auth':False,'proxy_http_success':False,
         'server_peer_verified':False,'server_peers':[],'http_code':0,'error':'','process_started':False}
    try:
        cursor=observer.cursor()
        # Relay failure/unsupported UDP never falls back to an IP endpoint.
        with SocksUDPRelay(PROXY_PORT,server['ip'],port) as relay:
            with tempfile.TemporaryDirectory(prefix='hy2-control-only-') as td:
                socks=f.free_port();config=Path(td)/'client.json'
                config.write_text(json.dumps({'server':f'127.0.0.1:{relay.port}',
                    'auth':f'cold{port}:'+candidate['hy_auth'],
                    'tls':{'sni':server['domain'],'insecure':False},'lazy':False,
                    'socks5':{'listen':f'127.0.0.1:{socks}'}}));os.chmod(config,0o600)
                with logfile.open('wb') as stream:
                    process=subprocess.Popen([str(f.hy_exe),'--disable-update-check','--log-format','json','client','-c',str(config)],
                        stdout=stream,stderr=subprocess.STDOUT,creationflags=core.CREATE_NO_WINDOW)
                    row.update(process_started=True,pid=process.pid,process_start=core.now_iso())
                    try:
                        if f.wait_client(process,socks):
                            result=f.curl_proxy_tests(socks,tests_override=1)['results'][0]
                            row.update(proxy_http_success=bool(result.get('ok')),http_code=result.get('code',0),
                                       latency_ms=result.get('ms'),error=result.get('error',''))
                        else:row['error']='Client unavailable; see individual client log'
                        count=connection_count(logfile)
                        row.update(handshake_auth=count>=1,connection_count=count,reconnect_observed=count>1)
                        evidence=observer.after(cursor)
                        peers=sorted({e['peer'] for e in evidence if e['event']=='client connected' and e['actor']==f'cold{port}'})
                        row.update(server_evidence=evidence,server_peers=peers,
                                   server_peer_verified=peers==[EXPECTED_PEER],
                                   udp_sent=relay.sent,udp_received=relay.received)
                    finally:f.stop_client(process)
    except Exception as e:
        row['error']=type(e).__name__ # No credentials / exception command payloads.
    row['timestamp']=core.now_iso()
    print(f"CONTROL {server['ip']} UDP{port}: AUTH={row['handshake_auth']} HTTP={row['proxy_http_success']} PEER_VERIFIED={row['server_peer_verified']} PEERS={row['server_peers']}",flush=True)
    return row

def collect(f,cohort,management):
    from ab_client import Observer
    # A separate folder: the quiet scanner intentionally watches hy2_ab_* and
    # hy2-client-* DIRECT/mixed logs, not this control-only namespace.
    directory=core.LOG_DIR/('hy2_control_'+uuid.uuid4().hex);directory.mkdir(parents=True)
    client=copy.copy(f);client.cfg=dict(f.cfg,test_urls=[URL]);client.discover_v2rayn_socks=lambda:PROXY_PORT;rows=[]
    for server,candidate in cohort:
        try:
            with management(client,server,candidate) as ssh:
                observer=Observer(ssh)
                if observer.proxy_peer!=EXPECTED_PEER:raise RuntimeError('Unexpected management control egress')
                for port in (443,8443):rows.append(one(client,server,candidate,port,observer,directory))
        except Exception as e:
            for port in (443,8443):
                if not any(r['ip']==server['ip'] and r['port']==port for r in rows):
                    rows.append({'ip':server['ip'],'port':port,'error':type(e).__name__,
                                 'handshake_auth':False,'proxy_http_success':False,'server_peer_verified':False,'process_started':False})
    report={'time':core.now_iso(),'direct_hy2_attempts':0,'control_process_starts':sum(r['process_started'] for r in rows),
            'expected_control_peer':EXPECTED_PEER,'url':URL,'results':rows,
            'all_six_passed':len(rows)==6 and all(r['handshake_auth'] and r['proxy_http_success'] and r['server_peer_verified'] for r in rows)}
    core.save_json(directory/'control_results.json',report)
    target=core.BASE/'HY2_AB_CONTROL_ONLY.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
        for path in directory.iterdir():archive.write(path,path.name)
    print('Saved '+str(target)+'; no DIRECT HY2 attempts, server changes or quiet-marker writes',flush=True)
    return report
