FRESH CLEAN CONTROL v1 — РОВНО ОДИН НОВЫЙ VPS, ЗАПУСК НА WINDOWS-ПК

Из среды ChatGPT/Codex VPS не создан: Vultr API connector и VULTR_API_KEY
здесь отсутствуют. Этот пакет выполняет разрешенное создание на вашем ПК,
где API key уже настроен. Ничего не запускается автоматически при распаковке.

Цель: один новый Amsterdam IP для сравнения, без поиска/перебора/удаления.
Не является обычным Finder кандидатом: label hy2-clean-control-<nonce>,
отдельный fresh-control/control-candidate.json, отдельный DPAPI vault.
Finder state.json и список GOOD/BAD не перезаписываются. Старые VPS/домены
не настраиваются. Новая платная машина остается при любом исходе теста.

УСТАНОВКА
Распакуйте в ту же папку Finder с последним HY2 addon. Существующий config.json,
state.json, hy2_ab_config.json, ключи и credentials пакет не содержит.
Новые настройки: fresh_control_config.json. Домен уже задан:
nordhy2a26.duckdns.org. Email пустой: он берется из вашего hy2_ab_config.json,
либо заполните acme_email вручную в новом fresh_control_config.json.
План vhp-1c-1gb-amd, Ubuntu ID2284. Проверяются по каталогу Finder; используется
тот же существующий SSH key. Несовпадение ОС/плана или отсутствие SSH key в
Vultr останавливает запуск до платного POST, новый ключ не создается.
План проверяется штатным ценовым лимитом Finder (по прежним логам $6/мес).
Нужны Windows11, PowerShell администратора, VULTR_API_KEY в этом же окне,
существующий SOCKS5 127.0.0.1:10808 с UDP. Старые мониторы должны быть остановлены.

1. СОЗДАТЬ РОВНО ОДИН VPS:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_fresh_control.ps1 -Create

Команда выполняет один POST /instances с retries=1 и заранее сохраненным
/fsync intent. При обрыве/HTTPошибке повторного POST не будет. Повторный -Create
читает существующий ID либо пытается восстановить единственный label по GET.
Если результат POST неопределен и сервер еще не появился в inventory, скрипт
останавливается. Не удаляйте fresh-control/ ради новой попытки: это может
создать второй VPS. Посмотрите label в панели Vultr и пришлите вывод ошибки.

ОС может еще готовиться, main_ip появится позднее. В этом случае только:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_fresh_control.ps1 -Status
-Status не создает VPS. Не запускайте массовый Finder ради этого сервера.
JSON сохраняет metadata без plaintext HY2/root passwords; секреты — в
fresh-control/vault/*.dpapi (Windows CurrentUser). Сохраните эту папку локально,
не публикуйте/не удаляйте ее. Она также препятствует повторному созданию.

2. DNS
В DuckDNS измените ТОЛЬКО A-запись nordhy2a26.duckdns.org на НОВЫЙ IP,
который вывела команда. Не нажимайте update с автоматически подставленным
домашним/VPN IP. Уберите AAAA для этого имени. Старые четыре имени не менять.
Дождитесь DNS propagation. DuckDNS token программе/чату не нужен.

3. ПРОДУКЦИОННЫЙ HY2 НА НОВОМ VPS:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_fresh_control.ps1 -Setup

Перед SSH проверяются текущий ID/label/region по GET API и original_instance_ids
из snapshot до создания. ID старого VPS всегда отклоняется. SSH управление
идет через существующий SOCKS. Серверный installer дополнительно отказывается
работать при наличии Xray config или существующего hy2-ab.service.
Устанавливается ТОЛЬКО официальный Hysteria2 2.13.0, pinned SHA256, валидный LE
TLS, SNI домена и file HTTP/3 masquerade, HTTP/HTTPS. Self-signed/obfs не используются.
UDP443 один listener; UDP8443 перенаправляется nft на тот же backend UDP443.
Проверяются отдельный IPv4 UDP443 socket и реальное JSON nft правило.
VLESS намеренно не ставится. UFW при активности получает недостающие разрешения
TCP80/TCP443/UDP443/UDP8443. Vultr cloud firewall по умолчанию не назначается;
если политика аккаунта все же назначила firewall, разрешите эти порты ТОЛЬКО
для нового VPS. Старые группы firewall скрипт не меняет.
Backup/metadata: /var/lib/hy2-fresh-backup. Ошибка setup вызывает откат только
созданного HY2/cert/rules, VPS НЕ удаляется. Backup не перетирается.
Некоторые пакеты после rollback остаются установленными; это не удаление VPS.

4. ПАУЗА И РОВНО ЧЕТЫРЕ КЛИЕНТСКИЕ ПРОВЕРКИ
Нужно >=120 минут с последней реальной DIRECT/mixed HY2 активности по локальным
логам. -Create/-Status/-Setup не генерируют HY2 client flows и не сбрасывают
quiet period. Если пауза уже выдержана, заново отсчитывать ее после -Setup
не требуется. Это не гарантирует сброс состояния фильтра. -ControlOnly логи
прежнего опыта не сбрасывают эту паузу. Не запускайте другие HY2 параллельно.

powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_fresh_control.ps1 -Test

Порядок строго:
DIRECT UDP443 -> DIRECT UDP8443 -> CONTROL UDP443 -> CONTROL UDP8443.
По одному новому official client process. Никакого 8+8, повторов после FAIL,
HOT, VLESS или отдельных HTTP/3 client probes. Валидный TLS проверяется самим
HY2 client. HTTP generate_204 одинаков для всех. Эффективный DIRECT /32
проверяется, source peer сравнивается с ранее доверенным baseline; контроль
через SOCKS10808 должен иметь peer82.47.60.219. Если исходящий IP провайдера
изменился, source не выдается за verified — не подменяйте baseline наугад.
Встроенный reconnect официального клиента может создать дополнительные
QUIC-попытки внутри PID; connection_count сохраняется. Программных повторов нет.
Если среда/SSH/маршрут сломаны, скрипт может остановиться раньше четырех стартов.

До первого теста сохраняется test_armed. После FAIL/прерывания повторный -Test
запрещен до анализа логов. Это специально исключает скрытый перебор попыток.
Не очищайте control-candidate.json, чтобы обойти запрет. ID и VPS сохраняются
независимо от успеха. Никакой GOOD/BAD классификации/автоудаления нет.
Результат: FRESH_CONTROL_RESULTS.zip. Пришлите его и IP новой машины.
Не присылайте fresh-control/vault или другие credentials.

5. ОТКАТ УСТАНОВКИ, БЕЗ УДАЛЕНИЯ МАШИНЫ:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_fresh_control.ps1 -Rollback

Откатывает только installer нового ID: собственные systemd/nft/UFW изменения
и созданный сертификат. Backup и control-candidate остаются; VPS остается.
Команды удаления VPS у этого пакета НЕТ.

ОГРАНИЧЕНИЯ ЭКСПЕРИМЕНТА
Свежий успешный DIRECT на фоне старых отказов усиливает версию endpoint/IP
state, но различия времени/маршрута и малая выборка тоже имеют значение.
Свежий DIRECT fail + verified CONTROL success показывает более широкую
проблему прямого пути, но не определяет виновный узел/ТСПУ на 100%.
Сам факт создания нового VPS не гарантирует новый для всей сети IP: адрес
мог использоваться прежними клиентами Vultr, историю/reputation мы не знаем.

ПРОВЕРКИ: 9 новых локальных regression tests — PASS: единственный POST,
fsync intent до POST, recovery без второго POST, timeout без повторения,
исходный state неизменен, запрет старых IDs/неверной region/label, порядок
D443,D8443,C443,C8443 даже при DIRECT FAIL, удержание VPS и NAT без VLESS.
45 существующих тестов HY2 addon — PASS. Компиляция Python — PASS.
Native Windows/DPAPI/Let’s Encrypt/nft и реальный paid create из среды Codex
не запускались. Проверки API моделировались. Не утверждается, что сервер уже создан.

СОСТАВ
fresh_control.py — durable at-most-once create, отдельный state/DPAPI, ownership guard,
                 setup/status/four tests/rollback без VPS delete.
fresh_server.py — standalone installer только на пустом новом сервере, backup/rollback.
fresh_control_config.json — один план, один домен, quiet120, Ubuntu2284.
run_fresh_control.ps1 — явные ручные команды, никакого default/autostart.
test_fresh_control.py — новые regression tests.
Совместимые helpers включены: ab_client.py, ab_route.py, ab_control_only.py,
ab_server.py, ab_report.py, ab_diagnose.py, test_ab.py. Изменение ab_server.validate_network —
только необязательный require_vless=False для свежего VPS; default=True
сохраняет прежнюю проверку старого A/B addon. На старых VPS код не выполняется.
