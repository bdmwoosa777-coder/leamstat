param([switch]$Create,[switch]$Status,[switch]$Setup,[switch]$Test,[switch]$Rollback)
$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-FinderAdmin
Assert-FinderKey
$selected=@($Create,$Status,$Setup,$Test,$Rollback | Where-Object { $_ })
if ($selected.Count -ne 1) { throw 'Choose exactly one: -Create, -Status, -Setup, -Test, -Rollback.' }
$mode=if ($Create) {'create'} elseif ($Status) {'status'} elseif ($Setup) {'setup'} elseif ($Test) {'test'} else {'rollback'}
$pythonPath=Get-FinderPython
& $pythonPath (Join-Path $PSScriptRoot 'fresh_control.py') --mode $mode
exit $LASTEXITCODE
