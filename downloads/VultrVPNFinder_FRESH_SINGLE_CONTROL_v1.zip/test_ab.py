import copy
import contextlib
import json
from pathlib import Path
import tempfile
import types
import unittest
import os
from unittest.mock import Mock,patch,MagicMock
import ab_client as a
import ab_server as s
from ab_report import summarize

class Checks(unittest.TestCase):
    def setUp(self):
        self.scratch=tempfile.TemporaryDirectory();self.addCleanup(self.scratch.cleanup)
        root=Path(self.scratch.name)
        for target,name,value in [(a,'QUIET',root/'activity.json'),(a,'GATE',root/'gate.json'),
                                  (a,'STOP_PATH',root/'stop.requested'),(a.core,'LOG_DIR',root/'logs')]:
            patcher=patch.object(target,name,value);patcher.start();self.addCleanup(patcher.stop)
        a.core.LOG_DIR.mkdir()
    def test_two_owned_routes_can_coexist(self):
        f=Mock(direct_gateway='192.168.0.1',direct_interface_index=8);f.query_host_routes.return_value=[]
        with tempfile.TemporaryDirectory() as d,patch.object(a,'ROUTES',Path(d)/'r.json'),patch.object(a,'verify_route'),patch.object(a.core,'run',return_value=types.SimpleNamespace(returncode=0)) as run:
            r=a.Routes(f);r.add('192.0.2.1');r.add('192.0.2.2')
            self.assertEqual(len(json.loads(a.ROUTES.read_text())),2)
            self.assertTrue(all(c.args[0][1]=='ADD' for c in run.call_args_list))
            r.cleanup();self.assertFalse(a.ROUTES.exists())
    def test_existing_route_never_replaced(self):
        f=Mock();f.query_host_routes.return_value=[{'index':8,'gateway':'192.168.0.1'}]
        with patch.object(a.core,'run') as run:
            with self.assertRaises(a.RouteError):a.Routes(f).add('192.0.2.1')
            run.assert_not_called()
    def test_cleanup_failure_preserves_metadata(self):
        f=Mock();f.query_host_routes.return_value=[{'index':8,'gateway':'192.168.0.1'}]
        with tempfile.TemporaryDirectory() as d,patch.object(a,'ROUTES',Path(d)/'r.json'),patch.object(a.core,'run'):
            a.core.save_json(a.ROUTES,[{'ip':'192.0.2.1','index':8,'gateway':'192.168.0.1'}])
            with self.assertRaises(a.RouteError):a.Routes(f).cleanup()
            self.assertTrue(a.ROUTES.exists())
    def test_wrong_effective_interface_rejected(self):
        f=types.SimpleNamespace(direct_gateway='192.168.0.1',direct_interface_index=8)
        out=b'{"InterfaceIndex":40,"NextHop":"192.168.0.1","DestinationPrefix":"192.0.2.1/32"}'
        with patch.object(a.core,'run',return_value=types.SimpleNamespace(returncode=0,stdout=out)):
            with self.assertRaises(a.RouteError):a.verify_route(f,'192.0.2.1')
    def test_vless_configuration_unchanged(self):
        cfg={'inbounds':[{'tag':'hy2-in','port':443,'protocol':'hysteria'},{'tag':'vless-in','protocol':'vless','port':8443,'settings':{'x':'y'}}],'outbounds':[{'protocol':'freedom'}]}
        before=copy.deepcopy(cfg);after=s.xray_without_hy2(cfg)
        self.assertEqual(cfg,before);self.assertEqual(after['inbounds'],[before['inbounds'][1]])
        self.assertEqual(after['outbounds'],before['outbounds'])
    def test_unknown_xray_shape_rejected(self):
        with self.assertRaises(RuntimeError):s.xray_without_hy2({'inbounds':[]})
    def test_both_ports_share_one_backend(self):
        cfg=s.server_config('real.example.org','secret')
        self.assertEqual(cfg['listen'],'0.0.0.0:443')
        fw=s.firewall_script();self.assertIn('udp dport 8443 redirect to :443',fw);self.assertNotIn('tcp dport 8443',fw)
        self.assertNotIn('obfs',cfg);self.assertNotIn('acme',cfg)
        self.assertEqual(cfg['masquerade']['type'],'file')
    def test_server_evidence_omits_secret_fields(self):
        raw=json.dumps({'msg':'client connected','addr':'192.0.2.1:12345','id':'hot','password':'secret'})
        row=a.events(raw)[0];self.assertEqual(row['peer'],'192.0.2.1');self.assertNotIn('password',row)
    def test_hot_reconnect_not_continuity(self):
        self.assertEqual(a.hot_state(1,True,True),'HOT_SESSION_ALIVE')
        self.assertEqual(a.hot_state(2,True,True),'HOT_RECONNECTED')
        self.assertEqual(a.hot_state(1,False,True),'HOT_SESSION_BROKEN')
        self.assertEqual(a.hot_state(1,True,True,True),'HOT_SESSION_BROKEN')
    def test_counter_uses_reconnect_count(self):
        text='\n'.join(json.dumps({'msg':'connected to server','count':i}) for i in (1,2))
        self.assertEqual(a.log_connection_count(text),2)
    def test_hot_http_requests_never_start_process(self):
        obj=a.Session.__new__(a.Session);obj.f=Mock();obj.s={'ip':'192.0.2.1'};obj.closed=False;obj.ready=True;obj.proc=Mock();obj.proc.poll.return_value=None;obj.socks=123;obj.actor='hot';obj.run=types.SimpleNamespace(id='test')
        obj.f.curl_proxy_tests.return_value={'results':[{'ok':True,'code':204}]}
        with patch.object(a,'verify_route'),patch.object(a.subprocess,'Popen') as popen:
            obj.request();obj.request();popen.assert_not_called();self.assertEqual(obj.f.curl_proxy_tests.call_count,2)
    def test_closed_hot_is_never_restarted(self):
        obj=a.Session.__new__(a.Session);obj.f=Mock();obj.s={'ip':'192.0.2.1'};obj.closed=True
        with patch.object(a,'verify_route'),patch.object(a.subprocess,'Popen') as popen:
            self.assertFalse(obj.request()['ok']);popen.assert_not_called()
    def test_budget_blocks_new_process(self):
        obj=a.Run.__new__(a.Run);obj.cfg={'max_fresh_hy2':2};obj.starts=2;obj.reconnects=0
        with self.assertRaises(RuntimeError):obj.spend()
    def test_report_cold_fail_hot_still_ok(self):
        base={'ip':'192.0.2.1','cycle':1,'port':443,'direct_verified':True,'pid':1,'session_identifier':'original'}
        cold=dict(base,timestamp='2026-11-08T12:00:00+03:00',test_type='COLD',ok=False)
        hot=dict(base,timestamp='2026-11-08T12:00:30+03:00',test_type='HOT',ok=True,state='HOT_SESSION_ALIVE')
        report=summarize([cold,hot])['servers']['192.0.2.1'];self.assertEqual(len(report['cold_fail_then_verified_hot_ok']),1)
        hot['state']='HOT_RECONNECTED';report=summarize([cold,hot])['servers']['192.0.2.1'];self.assertFalse(report['cold_fail_then_verified_hot_ok'])
    def test_local_quiet_period_enforced(self):
        with patch.object(a.core,'load_json',return_value={'time':100}),patch.object(a.time,'time',return_value=200):
            with self.assertRaises(RuntimeError):a.quiet_check({'quiet_minutes':120})
    def test_blank_domains_prevent_run_but_allow_rollback(self):
        cfg=json.loads((Path(a.__file__).parent/'hy2_ab_config.json').read_text())
        cfg['acme_email']='test@example.org'
        for server in cfg['servers']:server['domain']=''
        with patch.object(a.core,'load_json',return_value=cfg):
            with self.assertRaises(ValueError):a.load_config('run')
            a.load_config('rollback')
    def test_baseline_requires_trusted_distinct_source(self):
        rec={'paired_hy2':{'assessment':{'control_verified':True,'direct_baseline':'192.0.2.1','proxy_egress':'198.51.100.1'}}}
        self.assertEqual(a.trusted_baseline([rec]),'192.0.2.1')
        rec['paired_hy2']['assessment']['control_verified']=False
        with self.assertRaises(RuntimeError):a.trusted_baseline([rec])
    def test_constructor_starts_exactly_one_process_and_cleans(self):
        f=Mock();f.free_port.return_value=12345;f.wait_client.return_value=True;f.hy_exe=Path('hysteria.exe')
        s={'ip':'192.0.2.1','domain':'real.example.org'}
        with tempfile.TemporaryDirectory() as d,patch.object(a,'verify_route'),patch.object(a.subprocess,'Popen') as popen:
            run=Mock();run.dir=Path(d)
            obj=a.Session(f,s,{'hy_auth':'test-only'},443,'hot',run)
            text=json.loads((Path(obj.temp.name)/'client.json').read_text())
            self.assertFalse(text['tls']['insecure']);self.assertEqual(text['tls']['sni'],'real.example.org')
            obj.close();obj.close();popen.assert_called_once();f.stop_client.assert_called_once();self.assertFalse(Path(obj.temp.name).exists())
    def test_failed_client_start_is_closed_not_retried(self):
        f=Mock();f.free_port.return_value=12345;f.wait_client.return_value=False;f.hy_exe=Path('hysteria.exe')
        with tempfile.TemporaryDirectory() as d,patch.object(a,'verify_route'),patch.object(a.subprocess,'Popen') as popen:
            run=Mock();run.dir=Path(d)
            obj=a.Session(f,{'ip':'192.0.2.1','domain':'real.example.org'},{'hy_auth':'test-only'},443,'hot',run)
            self.assertTrue(obj.closed);popen.assert_called_once();f.stop_client.assert_called_once()
    def nft_fixture(self):
        return {'nftables':[
            {'chain':{'family':'ip','table':'hy2_ab','name':'prerouting','type':'nat','hook':'prerouting','prio':-100,'policy':'accept'}},
            {'rule':{'family':'ip','table':'hy2_ab','chain':'prerouting','expr':[
                {'match':{'op':'==','left':{'payload':{'protocol':'udp','field':'dport'}},'right':8443}},
                {'redirect':{'port':443}}]}}]}
    def test_prepare_rejects_missing_redirect_despite_vless_tcp8443(self):
        udp=b'UNCONN 0 0 0.0.0.0:443 0.0.0.0:*\n'
        tcp=b'LISTEN 0 4096 *:8443 *:*\n'
        nft=self.nft_fixture();nft['nftables'].pop()
        with patch.object(s,'run',side_effect=[udp,tcp,json.dumps(nft).encode()]):
            with self.assertRaises(RuntimeError):s.check_prepared_network()
    def test_correct_redirect_passes_without_udp8443_socket(self):
        result=s.validate_network('UNCONN 0 0 0.0.0.0:443 0.0.0.0:*','LISTEN 0 4096 *:8443 *:*',self.nft_fixture())
        self.assertTrue(result['udp8443_redirect_to_443'])
    def test_tcp443_does_not_substitute_udp_listener(self):
        with self.assertRaises(RuntimeError):s.validate_network('', 'LISTEN 0 4096 *:443 *:*\nLISTEN 0 4096 *:8443 *:*', self.nft_fixture())
    def test_redirect_wrong_protocol_or_port_rejected(self):
        for what in ('protocol','source_port','target_port','hook'):
            nft=self.nft_fixture();rule=nft['nftables'][1]['rule'];chain=nft['nftables'][0]['chain']
            if what=='protocol':rule['expr'][0]['match']['left']['payload']['protocol']='tcp'
            if what=='source_port':rule['expr'][0]['match']['right']=8444
            if what=='target_port':rule['expr'][1]['redirect']['port']=444
            if what=='hook':chain['hook']='output'
            with self.subTest(what=what),self.assertRaises(RuntimeError):s.validate_network('UNCONN 0 0 0.0.0.0:443 0.0.0.0:*','LISTEN 0 4096 *:8443 *:*',nft)
    def test_other_rule_cannot_hide_in_experiment_table(self):
        nft=self.nft_fixture();nft['nftables'].append(copy.deepcopy(nft['nftables'][1]))
        with self.assertRaises(RuntimeError):s.validate_network('UNCONN 0 0 0.0.0.0:443 0.0.0.0:*','LISTEN 0 4096 *:8443 *:*',nft)
    def test_port_substring_is_not_listener_evidence(self):
        with self.assertRaises(RuntimeError):s.validate_network('UNCONN 0 0 0.0.0.0:4430 0.0.0.0:*','LISTEN 0 4096 *:8443 *:*',self.nft_fixture())
    def selection_fixture(self):
        inst={'id':'live-id','main_ip':'192.0.2.1','region':'ams','status':'active'}
        state={'candidates':{
            'old-id':{'ip':inst['main_ip'],'phase':'paired_failed_retained','candidate':{'instance_id':'old-id','hy_auth':'old-test-only'}},
            'deleted-id':{'ip':inst['main_ip'],'phase':'deleted','candidate':{'hy_auth':'deleted-test-only'}},
            'live-id':{'phase':'paired_failed_retained','candidate':{'instance_id':'live-id','ip':inst['main_ip'],'region':'ams','hy_auth':'live-test-only'}}}}
        f=types.SimpleNamespace(state=state,api=Mock(),good=[])
        f.api.list_instances.return_value=[dict(inst)]
        f.api.get_instance.return_value=dict(inst)
        return f,inst
    def test_multiple_historical_entries_select_only_current_api_instance(self):
        f,inst=self.selection_fixture();before=copy.deepcopy(f.state)
        with patch('builtins.print'):
            cohort=a.resolve_cohort(f,[{'ip':inst['main_ip']}])
        self.assertEqual(cohort[0][1]['instance_id'],'live-id')
        self.assertEqual(cohort[0][1]['hy_auth'],'live-test-only')
        self.assertEqual(f.state,before);f.api.list_instances.assert_called_once_with()
        f.api.get_instance.assert_called_once_with('live-id')
    def test_real_state_shape_nested_ip_without_entry_ip(self):
        f,inst=self.selection_fixture();f.state['candidates']={'live-id':f.state['candidates']['live-id']}
        self.assertNotIn('ip',f.state['candidates']['live-id'])
        with patch('builtins.print'):cohort=a.resolve_cohort(f,[{'ip':inst['main_ip']}])
        self.assertEqual(cohort[0][1]['ip'],inst['main_ip'])
    def test_two_real_instances_same_ip_are_rejected(self):
        f,inst=self.selection_fixture();other=dict(inst,id='second-live')
        f.api.list_instances.return_value=[inst,other];f.api.get_instance.side_effect=lambda iid:inst if iid=='live-id' else other
        with self.assertRaisesRegex(RuntimeError,'found 2'):a.resolve_cohort(f,[{'ip':inst['main_ip']}])
    def test_stale_inventory_404_is_ignored(self):
        f,inst=self.selection_fixture();f.api.list_instances.return_value=[inst,dict(inst,id='stale')]
        def get(iid):
            if iid=='stale':raise a.core.APIError(404,'test stale')
            return inst
        f.api.get_instance.side_effect=get
        self.assertEqual(a.current_instance(f.api,inst['main_ip'],f.api.list_instances())['id'],'live-id')
    def test_current_api_region_and_main_ip_required(self):
        for update in ({'region':'fra'},{'main_ip':'192.0.2.99'}):
            f,inst=self.selection_fixture();f.api.get_instance.return_value=dict(inst,**update)
            with self.subTest(update=update),self.assertRaises(RuntimeError):a.current_instance(f.api,inst['main_ip'],[inst])
    def test_inventory_duplicate_same_id_is_not_two_instances(self):
        f,inst=self.selection_fixture();self.assertEqual(a.current_instance(f.api,inst['main_ip'],[inst,dict(inst)])['id'],'live-id')
        f.api.get_instance.assert_called_once()
    def test_read_only_api_allows_inventory_but_no_mutations(self):
        api=Mock();wrapper=a.ReadOnlyAPI(api);wrapper.list_instances();api.list_instances.assert_called_once()
        for name in ('request','create_instance','delete_instance','patch_instance'):
            with self.assertRaises(RuntimeError):getattr(wrapper,name)
    def test_prepare_main_does_not_reset_preexisting_quiet_period(self):
        f,inst=self.selection_fixture();f.direct_gateway='192.168.0.1';f.direct_interface_index=8
        f.preflight=Mock();f.cleanup_stale_route=Mock();cfg={'servers':[{'ip':inst['main_ip'],'domain':'real.example.org'}],'gateway':'192.168.0.1','interface_index':8,'acme_email':'test@example.org','quiet_minutes':120}
        a.core.save_json(a.QUIET,{'schema':2,'activity':'COLD','time':9200,'run_id':'earlier'})
        before=a.QUIET.read_bytes();before_mtime=a.QUIET.stat().st_mtime_ns
        a.GATE.write_text('{}')
        client=Mock();client.open_sftp.return_value=MagicMock()
        with patch.object(a,'load_config',return_value=cfg),patch.object(a,'os',types.SimpleNamespace(name='nt')),patch.object(a.core,'is_admin',return_value=True),patch.object(a.core,'Finder',return_value=f),patch.object(a,'RuntimeLock',return_value=contextlib.nullcontext()),patch.object(a,'Routes'),patch.object(a,'management',return_value=contextlib.nullcontext(client)),patch.object(a.password_ssh,'execute',return_value=(0,'prepared')),patch.object(a.time,'time',return_value=20000),patch('sys.argv',['ab_client.py','--mode','prepare']),patch('builtins.print'):
            self.assertEqual(a.main(),0);a.quiet_check(cfg)
        self.assertEqual(a.QUIET.read_bytes(),before);self.assertEqual(a.QUIET.stat().st_mtime_ns,before_mtime);self.assertFalse(a.GATE.exists())
    def test_legacy_prepare_marker_ignored_but_old_client_log_used(self):
        a.core.save_json(a.QUIET,{'time':19999,'reason':'prepare'})
        log=a.core.LOG_DIR/'hy2-client-007.log';log.write_text('1970-01-01T02:33:20+00:00 INFO client mode\n') # epoch 9200
        os.utime(log,(19999,19999)) # copied recently; event itself was 3h ago
        with patch.object(a.time,'time',return_value=20000),patch('builtins.print'):a.quiet_check({'quiet_minutes':120})
        self.assertEqual(a.last_hy2_activity()[0],9200)
    def test_recent_direct_full_log_blocks_even_with_old_marker(self):
        a.core.save_json(a.QUIET,{'time':100,'reason':'prepare'})
        (a.core.LOG_DIR/'finder.log').write_text('[1970-01-01T05:16:40+00:00] HY2 DIRECT 1/8: FAIL (DIRECT_ROUTE)\n') # epoch19000
        with patch.object(a.time,'time',return_value=20000):
            with self.assertRaises(RuntimeError):a.quiet_check({'quiet_minutes':120})
    def test_vless_ui_rows_do_not_record_hy2_activity(self):
        run=a.Run.__new__(a.Run);run.id='test';run.rows=[];run.starts=0;run.reconnects=0;run.quic=0
        with patch('builtins.print'):run.write({'ip':'192.0.2.1'},8443,'VLESS_CONTROL',1,{'ok':True})
        self.assertFalse(a.QUIET.exists())
    def test_recent_typed_hy2_activity_still_blocks(self):
        with patch.object(a.time,'time',return_value=20000):
            a.record_hy2_activity('HOT_RECONNECT','test')
        with patch.object(a.time,'time',return_value=20100):
            with self.assertRaises(RuntimeError):a.quiet_check({'quiet_minutes':120})
    def test_json_client_timestamps_override_copy_mtime(self):
        folder=a.core.LOG_DIR/'hy2_ab_test';folder.mkdir()
        log=folder/'hot-test.log';log.write_text(json.dumps({'ts':19000,'msg':'connected to server','count':2})+'\n')
        os.utime(log,(100,100))
        with patch.object(a.time,'time',return_value=20000):
            with self.assertRaises(RuntimeError):a.quiet_check({'quiet_minutes':120})
    def test_prepare_cannot_be_recorded_as_client_activity(self):
        with self.assertRaises(ValueError):a.record_hy2_activity('prepare','test')
        self.assertFalse(a.QUIET.exists())
    def test_official_hysteria_millisecond_timestamp(self):
        self.assertAlmostEqual(a.line_time('{"time":1794145258471.2744,"msg":"connected to server"}'),1794145258.4712744,places=5)
    def test_millisecond_logs_do_not_block_quiet_forever(self):
        log=a.core.LOG_DIR/'hy2-client-007.log';log.write_text('{"time":1794145258471.2744,"msg":"connected to server"}\n')
        with patch.object(a.time,'time',return_value=1794145258.4712744+3*3600),patch('builtins.print'):a.quiet_check({'quiet_minutes':120})
        with patch.object(a.time,'time',return_value=1794145258.4712744+3600):
            with self.assertRaises(RuntimeError):a.quiet_check({'quiet_minutes':120})
    def test_server_diagnosis_no_hy2_start_or_activity_marker(self):
        import ab_diagnose
        f,inst=self.selection_fixture();root=Path(self.scratch.name)
        manager=lambda *args:contextlib.nullcontext(Mock())
        with patch.object(a.core,'BASE',root),patch.object(a.password_ssh,'execute',return_value=(0,'{"service":{"exit":0}}')),patch.object(a.subprocess,'Popen') as start,patch('builtins.print'):
            report=ab_diagnose.collect(f,[({'ip':inst['main_ip']},{'instance_id':inst['id']})],manager)
        start.assert_not_called();self.assertFalse(a.QUIET.exists());self.assertTrue((root/'HY2_AB_SERVER_DIAG.zip').exists());self.assertEqual(report['hy2_clients_started'],0)

if __name__=='__main__':unittest.main()

class ControlOnlyChecks(unittest.TestCase):
    def test_six_clients_are_loopback_only_and_quiet_is_untouched(self):
        import ab_control_only as ctl
        with tempfile.TemporaryDirectory() as d:
            root=Path(d);logs=root/'logs';logs.mkdir();quiet=root/'activity.json';quiet.write_text('{"schema":2,"activity":"COLD","time":100}')
            before=quiet.read_bytes();mtime=quiet.stat().st_mtime_ns;configs=[]
            f=types.SimpleNamespace(cfg={'test_urls':['https://old.example/']},hy_exe=Path('hysteria.exe'),
                free_port=lambda:12345,wait_client=Mock(return_value=True),stop_client=Mock(),
                curl_proxy_tests=Mock(return_value={'results':[{'ok':True,'code':204,'ms':20}]}))
            observer=Mock();observer.proxy_peer=ctl.EXPECTED_PEER
            observer.after.side_effect=lambda cursor:[{'event':'client connected','actor':configs[-1]['auth'].split(':')[0],'peer':ctl.EXPECTED_PEER}]
            relay=lambda *args:contextlib.nullcontext(types.SimpleNamespace(port=5555,sent=20,received=10))
            def popen(args,**kw):
                configs.append(json.loads(Path(args[-1]).read_text()));kw['stdout'].write(b'{"time":1794145258471,"msg":"connected to server","count":1}\n');kw['stdout'].flush()
                return types.SimpleNamespace(pid=len(configs))
            cohort=[({'ip':ip,'domain':'real.example.org'},{'hy_auth':'test-only'}) for ip in ['192.0.2.1','192.0.2.2','192.0.2.3']]
            with patch.object(a.core,'BASE',root),patch.object(a.core,'LOG_DIR',logs),patch.object(a,'QUIET',quiet),patch.object(a,'Observer',return_value=observer),patch.object(ctl,'SocksUDPRelay',side_effect=relay) as relays,patch.object(ctl.subprocess,'Popen',side_effect=popen),patch.object(a.core,'run') as native,patch('builtins.print'):
                report=ctl.collect(f,cohort,lambda *args:contextlib.nullcontext(None))
                self.assertEqual(a.last_hy2_activity()[0],100)
            self.assertTrue(report['all_six_passed']);self.assertEqual(len(configs),6);self.assertEqual(report['direct_hy2_attempts'],0)
            self.assertTrue(all(c['server']=='127.0.0.1:5555' and c['tls']['insecure']==False for c in configs))
            self.assertEqual([call.args[2] for call in relays.call_args_list],[443,8443]*3)
            self.assertTrue(all(call.args[0]==10808 for call in relays.call_args_list));native.assert_not_called()
            self.assertEqual(quiet.read_bytes(),before);self.assertEqual(quiet.stat().st_mtime_ns,mtime)
            self.assertEqual(f.cfg['test_urls'],['https://old.example/'])
    def test_udp_relay_failure_cannot_fallback_to_direct(self):
        import ab_control_only as ctl
        with tempfile.TemporaryDirectory() as d,patch.object(ctl,'SocksUDPRelay',side_effect=ConnectionError('UDP unavailable')),patch.object(ctl.subprocess,'Popen') as start,patch('builtins.print'):
            r=ctl.one(Mock(),{'ip':'192.0.2.1'},{},443,Mock(),Path(d))
            start.assert_not_called();self.assertFalse(r['handshake_auth']);self.assertFalse(r['process_started'])
    def test_main_control_mode_skips_direct_routes_quiet_and_baseline(self):
        import ab_control_only
        cfg={'servers':[{'ip':'192.0.2.1'}],'gateway':'192.168.0.1','interface_index':8}
        f=types.SimpleNamespace(api=Mock(),direct_gateway='192.168.0.1',direct_interface_index=8,preflight=Mock(),cleanup_stale_route=Mock())
        with tempfile.TemporaryDirectory() as d,patch.object(a,'STOP_PATH',Path(d)/'stop'),patch.object(a,'load_config',return_value=cfg),patch.object(a,'os',types.SimpleNamespace(name='nt')),patch.object(a.core,'is_admin',return_value=True),patch.object(a.core,'Finder',return_value=f),patch.object(a,'RuntimeLock',return_value=contextlib.nullcontext()),patch.object(a,'Routes') as routes,patch.object(a,'resolve_cohort',return_value=[(cfg['servers'][0],{})]),patch.object(a,'quiet_check') as quiet,patch.object(ab_control_only,'collect') as collect,patch('sys.argv',['ab_client.py','--mode','control_only']):
            self.assertEqual(a.main(),0);collect.assert_called_once();quiet.assert_not_called();f.cleanup_stale_route.assert_not_called();routes.return_value.add.assert_not_called();routes.return_value.cleanup.assert_not_called()
