"""Only for an empty, newly created control VPS; never touches Xray/VLESS."""
import json,os,shutil,socket,subprocess,sys,time,urllib.request,hashlib
from pathlib import Path
import ab_server as common
ROOT=common.ROOT
BACKUP=Path('/var/lib/hy2-fresh-backup')

def rollback():
    if not (BACKUP/'metadata.json').exists():raise RuntimeError('No fresh-control backup')
    subprocess.run(['systemctl','disable','--now','hy2-ab.service'],capture_output=True)
    if shutil.which('nft'):subprocess.run(['nft','delete','table','ip','hy2_ab'],capture_output=True)
    meta=json.loads((BACKUP/'metadata.json').read_text())
    for rule in meta['ufw_added']:common.run(['ufw','--force','delete','allow',rule])
    hook=Path('/etc/letsencrypt/renewal-hooks/deploy/hy2-fresh');hook.unlink(missing_ok=True)
    if (Path('/etc/letsencrypt/renewal')/(meta['domain']+'.conf')).exists():
        common.run(['certbot','delete','--non-interactive','--cert-name',meta['domain']])
    common.UNIT.unlink(missing_ok=True);common.run(['systemctl','daemon-reload'])
    print(json.dumps({'rolled_back':True,'vps_deleted':False,'backup':str(BACKUP)}))

def prepare(data):
    if os.geteuid()!=0:raise RuntimeError('Root required')
    if Path('/etc/vpnfinder/xray.json').exists() or common.UNIT.exists():raise RuntimeError('Not an empty clean-control VPS; refuse')
    if BACKUP.exists():raise RuntimeError('Backup exists; inspect previous setup before retry')
    domain=data['domain']
    if set(socket.gethostbyname_ex(domain)[2])!={data['ip']}:raise RuntimeError('DNS A mismatch')
    try:
        if socket.getaddrinfo(domain,None,socket.AF_INET6):raise RuntimeError('Remove AAAA record')
    except socket.gaierror:pass
    if (Path('/etc/letsencrypt/renewal')/(domain+'.conf')).exists():raise RuntimeError('Certificate already exists')
    BACKUP.mkdir(mode=0o700);ROOT.mkdir(mode=0o700,exist_ok=True)
    meta={'domain':domain,'ufw_added':[]};(BACKUP/'metadata.json').write_text(json.dumps(meta))
    (BACKUP/'listeners.txt').write_bytes(common.run(['ss','-lnut']))
    if shutil.which('nft'):
        if subprocess.run(['nft','list','table','ip','hy2_ab'],capture_output=True).returncode==0:raise RuntimeError('nft table already exists')
        (BACKUP/'nft.txt').write_bytes(common.run(['nft','list','ruleset']))
    try:
        common.run(['apt-get','update'],timeout=180)
        common.run(['apt-get','install','-y','certbot','nftables'],timeout=300)
        if shutil.which('ufw'):
            status=common.run(['ufw','status']).decode()
            if 'Status: active' in status:
                for rule in ('80/tcp','443/tcp','443/udp','8443/udp'):
                    if not any(line.startswith(rule+' ') and 'ALLOW' in line and '(v6)' not in line for line in status.splitlines()):
                        common.run(['ufw','allow',rule,'comment','hy2-fresh']);meta['ufw_added'].append(rule)
                        (BACKUP/'metadata.json').write_text(json.dumps(meta))
        common.BINARY.parent.mkdir(parents=True,exist_ok=True)
        with urllib.request.urlopen('https://github.com/apernet/hysteria/releases/download/app/v2.13.0/hysteria-linux-amd64',timeout=45) as r:binary=r.read(100_000_000)
        if hashlib.sha256(binary).hexdigest()!=common.DIGEST:raise RuntimeError('Binary SHA256 mismatch')
        common.BINARY.write_bytes(binary);common.BINARY.chmod(0o755)
        common.run(['certbot','certonly','--standalone','--non-interactive','--agree-tos','--email',data['email'],'-d',domain,'--cert-name',domain],timeout=240)
        www=ROOT/'www';www.mkdir();(www/'index.html').write_text('<!doctype html><title>Network status</title><h1>Network status</h1><p>Service is available.</p>')
        (ROOT/'server.json').write_text(json.dumps(common.server_config(domain,data['password'])));(ROOT/'server.json').chmod(0o600)
        fw=ROOT/'firewall.sh';fw.write_text(common.firewall_script());fw.chmod(0o700)
        common.UNIT.write_text('[Unit]\nAfter=network-online.target\n[Service]\nType=simple\nUMask=0077\nExecStartPre=/var/lib/hy2-ab/firewall.sh up\nExecStart=/usr/local/lib/hy2-ab/hysteria --disable-update-check --log-format json server -c /var/lib/hy2-ab/server.json\nExecStopPost=/var/lib/hy2-ab/firewall.sh down\nRestart=no\n[Install]\nWantedBy=multi-user.target\n')
        common.run(['systemctl','daemon-reload']);common.run(['systemctl','enable','--now','hy2-ab.service']);time.sleep(2)
        common.run(['systemctl','is-active','--quiet','hy2-ab.service'])
        # Validate UDP listener and NAT without requiring a VLESS TCP8443 socket.
        udp=common.run(['ss','-H','-4','-lnu']).decode()
        nft=json.loads(common.run(['nft','-j','list','table','ip','hy2_ab']))
        common.validate_network(udp,'',nft,require_vless=False)
        renewal=Path('/etc/letsencrypt/renewal')/(domain+'.conf');text=renewal.read_text().replace('authenticator = standalone','authenticator = webroot')
        renewal.write_text(text+'\n[[webroot_map]]\n'+domain+' = '+str(www)+'\n')
        hook=Path('/etc/letsencrypt/renewal-hooks/deploy/hy2-fresh');hook.parent.mkdir(parents=True,exist_ok=True)
        hook.write_text('#!/bin/sh\nsystemctl try-restart hy2-ab.service\n');hook.chmod(0o755)
        print(json.dumps({'prepared':True,'udp443_listener':True,'udp8443_redirect':True,'vless':'NOT_INSTALLED','backup':str(BACKUP)}))
    except BaseException:
        rollback();raise

if __name__=='__main__':
    try:
        if sys.argv[1]=='rollback':rollback()
        else:prepare(json.load(open(sys.argv[1])))
    except Exception as e:
        print(json.dumps({'error':type(e).__name__,'detail':str(e) if isinstance(e,RuntimeError) else 'Inspect root-only installer.log'}));sys.exit(1)
