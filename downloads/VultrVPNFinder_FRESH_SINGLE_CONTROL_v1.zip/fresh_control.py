"""One paid instance, independent of Finder state; no deletion and no search loop."""
import argparse,base64,contextlib,copy,json,os,secrets,time,uuid,zipfile
from pathlib import Path
import finder as core
import password_ssh
from password_vault import PasswordVault
from runtime_support import RuntimeLock,STOP_PATH,pause,cleanup_mode
import ab_client as ab
import ab_control_only as control

ROOT=core.BASE/'fresh-control'
RECORD=ROOT/'control-candidate.json'
CONFIG=core.BASE/'fresh_control_config.json'

def save(record):
    ROOT.mkdir(parents=True,exist_ok=True)
    temp=RECORD.with_suffix('.tmp')
    with temp.open('w',encoding='utf-8') as out:
        json.dump(record,out,indent=2);out.flush();os.fsync(out.fileno())
    temp.replace(RECORD)

def recover_intent(f,record,vault):
    matches=[i for i in f.api.list_instances() if i.get('label')==record['label']]
    if len(matches)!=1:raise RuntimeError('Previous POST is unresolved. No repeat POST allowed; inspect this label in Vultr: '+record['label'])
    inst=matches[0];record.update(instance_id=inst['id'],ip=inst.get('main_ip'),phase='created_recovered');save(record)
    if inst.get('default_password'):vault.save(inst['id'],inst['default_password'])
    return record

def create_once(f,cfg,vault):
    record=core.load_json(RECORD,None)
    if record:
        if record.get('kind')!='fresh-clean-control-v1':raise RuntimeError('Unknown local control record')
        if record.get('instance_id'):return record
        if record.get('post_armed'):
            return recover_intent(f,record,vault)
    else:
        inventory=f.api.list_instances()
        nonce=str(uuid.uuid4());vault.save(nonce,secrets.token_urlsafe(32))
        record={'kind':'fresh-clean-control-v1','secret_id':nonce,'label':'hy2-clean-control-'+nonce[:12],
                'original_instance_ids':[i['id'] for i in inventory],'plan_id':cfg['plan_id'],'os_id':f.os_id,
                'ssh_key_id':f.ssh_key_id,'phase':'planned','post_armed':False,'created_at':core.now_iso()}
        save(record)
    payload={'region':'ams','plan':record['plan_id'],'os_id':record['os_id'],'label':record['label'],
             'hostname':record['label'],'sshkey_id':[record['ssh_key_id']],'enable_ipv6':False,
             'backups':'disabled','activation_email':False,'user_scheme':'root',
             'user_data':base64.b64encode(('#cloud-config\n'+json.dumps({'package_update':False,'package_upgrade':False,'package_reboot_if_required':False,'ssh_pwauth':True,'disable_root':False})).encode()).decode()}
    record.update(post_armed=True,phase='post_intent');save(record)
    # Exactly one POST call. Even 429/5xx/timeout leaves a durable no-repeat intent.
    result=f.api.request('POST','/instances',payload,retries=1)
    inst=result['instance'];iid=inst['id']
    if iid in record['original_instance_ids']:raise RuntimeError('API returned a pre-existing instance; refuse')
    record.update(instance_id=iid,ip=inst.get('main_ip'),phase='created');save(record)
    if inst.get('default_password'):vault.save(iid,inst['default_password'])
    return record

def owned_instance(f,record,allow_pending=False):
    if record.get('kind')!='fresh-clean-control-v1':raise RuntimeError('Unknown record')
    iid=record['instance_id']
    if iid in record['original_instance_ids']:raise RuntimeError('Refuse to touch an original VPS')
    inst=f.api.get_instance(iid)
    if inst.get('id')!=iid or inst.get('label')!=record['label'] or inst.get('region')!='ams':raise RuntimeError('Fresh-control identity mismatch')
    if inst.get('plan') not in (None,record['plan_id']):raise RuntimeError('Fresh-control plan mismatch')
    if (not inst.get('main_ip') or inst['main_ip']=='0.0.0.0') and not allow_pending:raise RuntimeError('Fresh VPS IP not ready; use -Status later, do not create another')
    return inst

def setup(f,record,cfg,candidate,server,rollback=False):
    with ab.management(f,server,candidate) as ssh:
        rc,_=password_ssh.execute(ssh,'install -d -m 700 /root/hy2-fresh-stage')
        if rc:raise RuntimeError('Could not create root-only staging directory')
        with ssh.open_sftp() as ftp:
            for name in ('fresh_server.py','ab_server.py'):
                ftp.put(str(core.BASE/name),'/root/hy2-fresh-stage/'+name);ftp.chmod('/root/hy2-fresh-stage/'+name,0o700)
            with ftp.open('/root/hy2-fresh-stage/payload.json','w') as out:
                out.write(json.dumps({'ip':server['ip'],'domain':server['domain'],'email':cfg['acme_email'],'password':candidate['hy_auth']}))
            ftp.chmod('/root/hy2-fresh-stage/payload.json',0o600)
        try:
            mode='rollback' if rollback else '/root/hy2-fresh-stage/payload.json'
            rc,out=password_ssh.execute(ssh,'python3 /root/hy2-fresh-stage/fresh_server.py '+mode,timeout=900)
            print(out.strip(),flush=True)
            if rc:raise RuntimeError('Fresh setup/rollback failed. VPS retained; inspect root-only installer log')
        finally:
            with cleanup_mode():password_ssh.execute(ssh,'rm -f /root/hy2-fresh-stage/payload.json')
    record['phase']='rolled_back' if rollback else 'prepared';record['prepared_at']=core.now_iso();save(record)

def four_checks(f,record,cfg,candidate,server):
    if record.get('test_armed'):raise RuntimeError('Test already attempted/interrupted. No automatic second test; analyze logs')
    if record.get('phase')!='prepared':raise RuntimeError('Fresh control is not prepared')
    ab.quiet_check(cfg)
    ROOT.mkdir(parents=True,exist_ok=True);ab.ROUTES=ROOT/'routes.json'
    routes=ab.Routes(f);routes.cleanup()
    run=ab.Run(f,dict(cfg,max_fresh_hy2=4),True);rows=[]
    record.update(test_armed=True,phase='test_intent',test_run=run.id);save(record)
    probe=copy.copy(f);probe.cfg=dict(f.cfg,test_urls=[control.URL]);probe.discover_v2rayn_socks=lambda:10808
    try:
        routes.add(server['ip'])
        with ab.management(probe,server,candidate) as ssh:
            observer=ab.Observer(ssh)
            if observer.proxy_peer!=control.EXPECTED_PEER:raise RuntimeError('Unexpected control egress; abort before HY2')
            for port in (443,8443):
                cursor=observer.cursor()
                session=ab.Session(probe,server,candidate,port,'cold'+str(port),run)
                try:
                    result=session.request();count=session.count();evidence=observer.after(cursor)
                    peers=sorted({e['peer'] for e in evidence if e['event']=='client connected' and e['actor']=='cold'+str(port)})
                    rows.append({'path':'DIRECT','ip':server['ip'],'port':port,'handshake_auth':count>=1,
                                 'connection_count':count,'proxy_http_success':bool(result.get('ok')),'http':result,
                                 'direct_route_verified':True,'server_peers':peers,'server_peer_verified':peers==[server['expected_direct_peer']],
                                 'server_evidence':evidence})
                finally:session.close()
                core.save_json(run.dir/'fresh_results.json',{'results':rows})
            # DIRECT phase is completely finished before either CONTROL starts.
            routes.cleanup()
            for port in (443,8443):
                row=control.one(probe,server,candidate,port,observer,run.dir);row['path']='CONTROL';rows.append(row)
                core.save_json(run.dir/'fresh_results.json',{'results':rows})
        record['phase']='tested_retained';save(record)
    finally:
        routes.cleanup()
        report={'instance_id':record['instance_id'],'ip':server['ip'],'time':core.now_iso(),
                'classification':'UNCLASSIFIED_CLEAN_CONTROL','vps_deleted':False,'results':rows,
                'direct_starts':run.starts,'control_starts':sum(bool(r.get('process_started')) for r in rows if r['path']=='CONTROL')}
        core.save_json(run.dir/'fresh_results.json',report)
        with zipfile.ZipFile(core.BASE/'FRESH_CONTROL_RESULTS.zip','w',zipfile.ZIP_DEFLATED) as z:
            for path in run.dir.iterdir():z.write(path,path.name)
        print('Saved FRESH_CONTROL_RESULTS.zip; VPS retained, no GOOD/BAD classification',flush=True)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--mode',choices=['create','status','setup','test','rollback'],required=True);args=parser.parse_args()
    cfg=core.load_json(CONFIG,{})
    if os.name!='nt' or not core.is_admin():raise RuntimeError('Windows administrator required')
    with RuntimeLock():
        STOP_PATH.unlink(missing_ok=True)
        f=core.Finder();f.retest_saved_mode=True;f.preflight(check_only=True)
        if not f.ssh_key_id:raise RuntimeError('Finder SSH key must already exist in Vultr; no new key will be uploaded')
        if cfg['plan_id'] not in {p['id'] for p in f.plans} or f.os_id!=cfg['os_id']:raise RuntimeError('Plan/Ubuntu mismatch; refusing paid create')
        vault=PasswordVault(ROOT/'vault');f.password_vault=vault
        record=core.load_json(RECORD,None)
        if args.mode=='create':record=create_once(f,cfg,vault)
        if not record:raise RuntimeError('No separate control-candidate; use -Create exactly once')
        f.api=ab.ReadOnlyAPI(f.api)
        if not record.get('instance_id'):
            if record.get('post_armed'):record=recover_intent(f,record,vault)
            else:raise RuntimeError('No POST submitted yet; only -Create may submit it')
        inst=owned_instance(f,record,allow_pending=args.mode in ('create','status'));record['ip']=inst.get('main_ip');save(record)
        print(f"CLEAN CONTROL id={inst['id']} IP={inst.get('main_ip') or 'WAIT'} label={record['label']} phase={record['phase']}",flush=True)
        if args.mode in ('create','status'):
            if not inst.get('main_ip') or inst['main_ip']=='0.0.0.0':
                print('Vultr provisioning; use -Status later. The single create was saved; no additional VPS will be created.');return 0
            print('Point '+cfg['domain']+' A record to '+inst['main_ip']+'; then run -Setup. This command started no HY2 clients.');return 0
        if not cfg.get('acme_email'):cfg['acme_email']=core.load_json(core.BASE/'hy2_ab_config.json',{}).get('acme_email','')
        if '@' not in cfg.get('acme_email','') or not cfg.get('domain','').endswith('.duckdns.org'):raise RuntimeError('Fill domain/acme_email before setup/test')
        server={'ip':inst['main_ip'],'domain':cfg['domain'],'expected_direct_peer':cfg.get('expected_direct_peer','auto')}
        candidate={'instance_id':inst['id'],'ip':inst['main_ip'],'region':'ams','attempt':0,'hy_auth':vault.load(record['secret_id'])}
        if not candidate['hy_auth']:raise RuntimeError('Missing DPAPI HY2 credentials; never generate replacements automatically')
        if args.mode in ('setup','rollback'):setup(f,record,cfg,candidate,server,rollback=args.mode=='rollback')
        else:
            if server['expected_direct_peer']=='auto':server['expected_direct_peer']=ab.trusted_baseline(f.good)
            four_checks(f,record,cfg,candidate,server)
        return 0

if __name__=='__main__':raise SystemExit(main())
