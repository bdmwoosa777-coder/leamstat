"""Password SSH fallback. Credentials stay in memory and never enter command lines."""
from __future__ import annotations

import time
from runtime_support import check_stop, pause


def get_paramiko():
    import paramiko
    return paramiko


def connect(host, port, password, timeout=10):
    paramiko = get_paramiko()
    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(hostname=host, port=int(port), username="root", password=password,
                       look_for_keys=False, allow_agent=False, timeout=timeout,
                       banner_timeout=timeout, auth_timeout=timeout)
        return client
    except BaseException:
        client.close()
        raise


def execute(client, command, timeout=75):
    channel = client.get_transport().open_session(timeout=min(timeout, 10))
    output = bytearray()
    try:
        channel.settimeout(min(timeout, 10))
        channel.set_combine_stderr(True)
        channel.exec_command(command)
        deadline = time.monotonic() + timeout
        while True:
            check_stop()
            while channel.recv_ready():
                output.extend(channel.recv(8192))
                if len(output) > 32768:
                    del output[:-32768]
            if channel.exit_status_ready() and not channel.recv_ready():
                return channel.recv_exit_status(), output.decode("utf-8", errors="replace")
            if time.monotonic() >= deadline:
                raise TimeoutError("Remote SSH command timed out")
            pause(0.05)
    finally:
        channel.close()
