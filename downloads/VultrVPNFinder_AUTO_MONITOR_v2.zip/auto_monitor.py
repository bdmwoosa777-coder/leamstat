"""Saved VPS observer. No provisioning, classification writes, or VPS deletion."""
from __future__ import annotations
import argparse
import csv
import datetime as dt
import ipaddress
import json
import math
import random
import time
from pathlib import Path
import finder as core
from runtime_support import RuntimeLock, STOP_PATH, check_stop, pause, cleanup_mode

BASE = Path(__file__).resolve().parent
LOG = core.LOG_DIR / 'auto_monitor.jsonl'
CSV = core.LOG_DIR / 'auto_monitor.csv'
FIELDS = ['time', 'cycle', 'ip', 'hy2_ok', 'hy2_total', 'direct_verified',
          'vless_ok', 'vless_total', 'full_reason', 'full_direct_ok',
          'full_control_ok', 'full_control_verified', 'verdict', 'error']
DEFAULTS = dict(interval_minutes=30, jitter_minutes=3, duration_hours=24,
                hy2_attempts=4, attempt_gap_seconds=3, vless_attempts=2,
                server_gap_seconds=5, full_every_hours=6,
                full_on_failure=True, full_cooldown_minutes=90)

class RouteError(RuntimeError):
    pass

class ReadOnlyAPI:
    """Permit only GETs, including requests made internally by Finder helpers."""
    def __init__(self, api):
        self.api = api
    def __getattr__(self, name):
        if name not in ('get_instance', 'get_instance_user_data'):
            raise RuntimeError('Monitor API operation forbidden: ' + name)
        return getattr(self.api, name)


def config(path):
    cfg = dict(DEFAULTS)
    raw = core.load_json(path, {})
    if not isinstance(raw, dict) or set(raw) - set(cfg):
        raise ValueError('Unknown config key or invalid config object')
    cfg.update(raw)
    for k, default in DEFAULTS.items():
        value = cfg[k]
        if isinstance(default, bool):
            if type(value) is not bool:
                raise ValueError(k + ' must be boolean')
        elif isinstance(value, bool) or not isinstance(value, (float, int)) or not math.isfinite(value):
            raise ValueError(k + ' must be a finite number')
        elif value < 0:
            raise ValueError(k + ' cannot be negative')
    for k in ('interval_minutes', 'duration_hours', 'full_every_hours', 'full_cooldown_minutes'):
        if cfg[k] <= 0:
            raise ValueError(k + ' must be positive')
    for k in ('hy2_attempts', 'vless_attempts'):
        if int(cfg[k]) != cfg[k] or not (1 <= cfg[k] <= 8):
            raise ValueError(k + ' must be integer 1..8')
    if cfg['jitter_minutes'] >= cfg['interval_minutes']:
        raise ValueError('jitter must be smaller than interval')
    return cfg


def verify_route(f, ip):
    """Inspect the effective Windows route, not just Finder's current_ip flag."""
    ip = str(ipaddress.IPv4Address(ip))
    script = ("$ErrorActionPreference='Stop'; $r=Find-NetRoute -RemoteIPAddress '" + ip + "'; "
              "$a=@($r | Where-Object {$null -ne $_.NextHop -and $null -ne $_.DestinationPrefix}); "
              "if ($a.Count -ne 1) {throw 'Ambiguous effective route'}; "
              "$a[0] | Select-Object InterfaceIndex,NextHop,DestinationPrefix | ConvertTo-Json -Compress")
    cp = core.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script], timeout=15)
    if cp.returncode:
        raise RouteError('Cannot determine effective Windows route')
    try:
        r = json.loads(core.decode_output(cp.stdout).strip())
        valid = (int(r['InterfaceIndex']) == int(f.direct_interface_index)
                 and r['NextHop'] == f.direct_gateway and r['DestinationPrefix'] == ip + '/32')
    except (ValueError, TypeError, KeyError):
        raise RouteError('Invalid effective route response') from None
    if not valid:
        raise RouteError('Effective route differs from configured direct /32 route')
    return dict(interface_index=int(r['InterfaceIndex']), gateway=r['NextHop'], prefix=r['DestinationPrefix'])


def install_route_guard(f):
    # Also applies inside full direct/control tests; loopback control is exempt.
    original = f.test_hy2
    def guarded(c, ip, *args, **kwargs):
        direct = not ipaddress.ip_address(ip).is_loopback
        if direct:
            verify_route(f, ip)
        result = original(c, ip, *args, **kwargs)
        if direct:
            verify_route(f, ip)
        return result
    f.test_hy2 = guarded


def observed_peers(watcher, cursor):
    if watcher is None or cursor is None:
        return []
    try:
        return watcher.peers_after(cursor)
    except Exception:
        return []


def checkpoint(watcher):
    try:
        return watcher.checkpoint() if watcher is not None else None
    except Exception:
        return None


def light(f, c, ip, cfg, expected_peer):
    results = []
    port = f.discover_v2rayn_socks()
    with f.safe_paired_observer(c, ip, port) as watcher:
        proxy_peer = getattr(watcher, 'proxy_egress', None)
        f.route_add_direct(ip)  # Never assign current_ip here.
        for index in range(int(cfg['hy2_attempts'])):
            check_stop()
            route = verify_route(f, ip)
            cursor = checkpoint(watcher)
            test = f.test_hy2(c, ip, tests_override=1, url_offset=index)
            row = dict((test.get('results') or [{'ok': False}])[0])
            row['route'] = route
            row['server_peers'] = observed_peers(watcher, cursor)
            row['time'] = core.now_iso()
            row['direct_verified'] = bool(expected_peer and proxy_peer and expected_peer != proxy_peer
                                           and row['server_peers'] == [expected_peer])
            results.append(row)
            if index + 1 < cfg['hy2_attempts']:
                pause(cfg['attempt_gap_seconds'])
        verify_route(f, ip)
        vless = f.test_vless(c, ip, tests_override=int(cfg['vless_attempts']))
        verify_route(f, ip)
    good_rows = [r for r in results if r.get('ok')]
    # Need at least one observed successful session; a failed handshake has no peer evidence.
    verified = bool(good_rows and all(r['direct_verified'] for r in good_rows))
    return dict(results=results, ok=len(good_rows), total=len(results), direct_verified=verified,
                expected_peer=expected_peer, proxy_peer=proxy_peer, vless=vless)


def saved_baseline(rec):
    for r in (rec.get('latest_retest') or {}, rec):
        a = (r.get('paired_hy2') or {}).get('assessment') or {}
        if a.get('control_verified'):
            peers = a.get('direct_peers') or []
            value = a.get('direct_baseline') or (peers[0] if len(peers) == 1 else None)
            if value:
                return str(ipaddress.IPv4Address(value))
    return None


def persist(record):
    core.LOG_DIR.mkdir(parents=True, exist_ok=True)
    with LOG.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(record, ensure_ascii=False) + '\n')
    exists = CSV.exists() and CSV.stat().st_size > 0
    with CSV.open('a', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS, extrasaction='ignore')
        if not exists:
            writer.writeheader()
        writer.writerow(record)
    print(f"{record['time']} {record['ip']} HY2={record.get('hy2_ok')}/{record.get('hy2_total')} "
          f"verified={record.get('direct_verified')} {record['verdict']} {record.get('error', '')}", flush=True)


def inspect_one(f, rec, entry, cfg, cycle, clock, baselines):
    iid = rec['instance_id']
    ip = str(ipaddress.IPv4Address(rec.get('ip') or entry['ip']))
    row = dict(time=core.now_iso(), cycle=cycle, ip=ip, error='', verdict='MONITOR_ERROR')
    try:
        c = dict(entry['candidate'], instance_id=iid)
        inst = f.api.get_instance(iid)
        if inst.get('main_ip') != ip:
            raise RuntimeError('Saved VPS IP changed or instance unavailable; refusing old credentials')
        detail = light(f, c, ip, cfg, baselines.get(iid))
        row.update(light=detail, hy2_ok=detail['ok'], hy2_total=detail['total'],
                   direct_verified=detail['direct_verified'],
                   vless_ok=detail['vless']['ok'], vless_total=detail['vless']['total'])
        now = time.monotonic()
        previous = clock.get(iid)
        scheduled = previous is None or now - previous >= cfg['full_every_hours'] * 3600
        miss = detail['ok'] != detail['total'] or not detail['direct_verified']
        cooled = previous is None or now - previous >= cfg['full_cooldown_minutes'] * 60
        full = scheduled or (cfg['full_on_failure'] and miss and cooled)
        row['verdict'] = ('LIGHT_GOOD' if detail['direct_verified'] else 'DIRECT_UNVERIFIED') if not miss else (
            'LIGHT_DEGRADED' if detail['ok'] < detail['total'] else 'DIRECT_UNVERIFIED')
        if full:
            row['full_reason'] = 'scheduled' if scheduled else 'light_failure_or_unverified'
            clock[iid] = now  # Cool down even if full fails, preventing repeat storms.
            result = f.run_paired_hy2(c, ip)
            a = result['assessment']
            row.update(full=result, full_direct_ok=a['direct_ok'], full_control_ok=a['control_ok'],
                       full_control_verified=a['control_verified'])
            row['verdict'] = a['verdict'] if a['control_verified'] else 'FULL_PATH_UNVERIFIED'
            if a['control_verified']:
                peer = a.get('direct_baseline')
                peers = a.get('direct_peers') or []
                baselines[iid] = peer or (peers[0] if len(peers) == 1 else None)
            row['direct_verified'] = bool(a['control_verified'])
    except RouteError as exc:
        row.update(verdict='ROUTE_UNVERIFIED', error=str(exc))
    except Exception as exc:
        # Do not log exception messages that may contain credentials.
        row.update(verdict='MONITOR_ERROR', error=type(exc).__name__)
    finally:
        try:
            with cleanup_mode():
                f.route_delete(ip)
                if f.current_ip:
                    raise RouteError('Route ownership state not cleared')
        except Exception:
            row.update(verdict='CLEANUP_FAILED_STOPPED', error='Temporary route cleanup failed; monitor stopped')
            persist(row)
            raise RouteError(row['error']) from None
    persist(row)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--once', action='store_true', help='one complete cycle')
    parser.add_argument('--config', type=Path, default=BASE / 'auto_monitor_config.json')
    args = parser.parse_args()
    cfg = config(args.config)
    if core.os.name != 'nt':
        raise RuntimeError('Windows 11 administrator terminal required')
    with RuntimeLock():
        STOP_PATH.unlink(missing_ok=True)
        f = core.Finder()
        try:
            f.retest_saved_mode = True
            f.preflight(check_only=True)
            f.api = ReadOnlyAPI(f.api)
            f.cleanup_stale_route()
            install_route_guard(f)
            cohort = []
            for rec in f.good:
                iid = rec.get('instance_id')
                entry = f.state.get('candidates', {}).get(iid, {})
                if iid and entry.get('phase') != 'deleted' and entry.get('candidate'):
                    cohort.append((rec, entry))
            cohort = list({r['instance_id']: (r, e) for r, e in cohort}.values())
            if not cohort:
                raise RuntimeError('No saved VPS with candidate credentials')
            baselines = {r['instance_id']: saved_baseline(r) for r, _ in cohort}
            clock = {}  # Full baseline on first cycle, then every configured 6h.
            deadline = time.monotonic() + cfg['duration_hours'] * 3600
            cycle = 0
            while time.monotonic() < deadline:
                cycle += 1
                start = time.monotonic()
                random.shuffle(cohort)
                for rec, entry in cohort:
                    check_stop()
                    if time.monotonic() >= deadline:
                        break
                    inspect_one(f, rec, entry, cfg, cycle, clock, baselines)
                    pause(cfg['server_gap_seconds'])
                if args.once:
                    break
                # No catch-up bursts after an unusually long cycle.
                due = max(time.monotonic() + 60, start + 60 * (
                    cfg['interval_minutes'] + random.uniform(-cfg['jitter_minutes'], cfg['jitter_minutes'])))
                pause(max(0, min(due, deadline) - time.monotonic()))
            return 0
        except KeyboardInterrupt:
            print('Monitor stopped. VPS unchanged.', flush=True)
            return 130
        finally:
            with cleanup_mode():
                if f.current_ip:
                    f.route_delete(f.current_ip)
            STOP_PATH.unlink(missing_ok=True)

if __name__ == '__main__':
    raise SystemExit(main())
