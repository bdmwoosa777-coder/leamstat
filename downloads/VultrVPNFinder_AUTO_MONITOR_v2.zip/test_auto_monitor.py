import contextlib
import json
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import Mock, patch
import auto_monitor as m

class Checks(unittest.TestCase):
    def setUp(self):
        self.cfg = dict(m.DEFAULTS, attempt_gap_seconds=0)
    def test_config_rejects_zero_nan_and_bool(self):
        for value in (0, float('nan'), True):
            with self.subTest(value=value), patch.object(m.core,'load_json',return_value={'interval_minutes':value}):
                with self.assertRaises(ValueError): m.config(Path('unused'))
    def test_route_mismatch_fails(self):
        f=types.SimpleNamespace(direct_interface_index=8,direct_gateway='192.168.0.1')
        for index in (8, 40):
            out=json.dumps(dict(InterfaceIndex=index,NextHop='192.168.0.1',DestinationPrefix='203.0.113.1/32'))
            with patch.object(m.core,'run',return_value=types.SimpleNamespace(returncode=0,stdout=out.encode())):
                if index==8: self.assertEqual(m.verify_route(f,'203.0.113.1')['interface_index'],8)
                else:
                    with self.assertRaises(m.RouteError): m.verify_route(f,'203.0.113.1')
    def test_real_route_add_not_skipped(self):
        # Actual Finder route ownership code, mocking only Windows subprocess/lookup.
        f=m.core.Finder.__new__(m.core.Finder)
        f.current_ip=None; f.direct_gateway='192.168.0.1'; f.direct_interface_index=8; f.cfg={}
        f.query_host_routes=Mock(return_value=[])
        with tempfile.TemporaryDirectory() as d, patch.object(m.core,'ROUTE_PATH',Path(d)/'route.json'), patch.object(m.core,'CURRENT_IP_PATH',Path(d)/'ip.txt'), patch.object(m.core,'log'), patch.object(m.core,'run',return_value=types.SimpleNamespace(returncode=0)) as run:
            f.route_add_direct('203.0.113.1')
            self.assertEqual(run.call_args.args[0][1],'ADD')
            f.route_delete('203.0.113.1')
            self.assertIsNone(f.current_ip)
    def test_guard_covers_direct_not_loopback(self):
        f=types.SimpleNamespace(test_hy2=Mock(return_value={'ok':1}))
        m.install_route_guard(f)
        with patch.object(m,'verify_route') as verify:
            f.test_hy2({},'203.0.113.1'); self.assertEqual(verify.call_count,2)
            f.test_hy2({},'127.0.0.1'); self.assertEqual(verify.call_count,2)
    def test_api_does_not_allow_mutation(self):
        api=Mock(); wrapper=m.ReadOnlyAPI(api)
        wrapper.get_instance('a'); api.get_instance.assert_called_once_with('a')
        for method in ('create_instance','delete_instance','patch_instance','request'):
            with self.assertRaises(RuntimeError): getattr(wrapper,method)
    def test_light_peer_evidence_required(self):
        watcher=types.SimpleNamespace(proxy_egress='198.51.100.2', checkpoint=lambda:'cursor', peers_after=lambda c:['198.51.100.1'])
        f=Mock();f.safe_paired_observer.side_effect=lambda *a:contextlib.nullcontext(watcher)
        f.test_hy2.return_value={'results':[{'ok':True}]};f.test_vless.return_value={'ok':2,'total':2}
        with patch.object(m,'verify_route',return_value={}), patch.object(m,'pause'):
            r=m.light(f,{},'203.0.113.1',self.cfg,'198.51.100.1');self.assertTrue(r['direct_verified']);self.assertEqual(r['ok'],4)
            r=m.light(f,{},'203.0.113.1',self.cfg,None);self.assertFalse(r['direct_verified'])
            r=m.light(f,{},'203.0.113.1',self.cfg,'198.51.100.2');self.assertFalse(r['direct_verified'])
    def run_case(self, ok=4, verified=True, previous=None, cleanup_failure=False, stop=False):
        f=Mock();f.current_ip=None;f.api.get_instance.return_value={'main_ip':'203.0.113.1'}
        a=dict(direct_ok=7,control_ok=8,control_verified=True,verdict='GOOD_DIRECT',direct_baseline='198.51.100.1')
        f.run_paired_hy2.return_value={'assessment':a}
        if cleanup_failure: f.route_delete.side_effect=RuntimeError('failure')
        detail=dict(ok=ok,total=4,direct_verified=verified,vless=dict(ok=2,total=2))
        clock={} if previous is None else {'a':previous}
        saved=[]
        with patch.object(m,'light',side_effect=KeyboardInterrupt if stop else None,return_value=detail), patch.object(m.time,'monotonic',return_value=10000),patch.object(m,'persist',side_effect=lambda r:saved.append(dict(r))):
            fn=lambda:m.inspect_one(f,{'instance_id':'a','ip':'203.0.113.1'},{'candidate':{}},self.cfg,1,clock,{})
            if cleanup_failure:
                with self.assertRaises(m.RouteError):fn()
            elif stop:
                with self.assertRaises(KeyboardInterrupt):fn()
            else:fn()
        return f,saved
    def test_first_cycle_full_baseline(self):
        f,rows=self.run_case();f.run_paired_hy2.assert_called_once();self.assertEqual(rows[0]['full_reason'],'scheduled')
    def test_miss_cooldown_does_not_claim_good(self):
        f,rows=self.run_case(ok=0,previous=9990);f.run_paired_hy2.assert_not_called();self.assertEqual(rows[0]['verdict'],'LIGHT_DEGRADED')
    def test_unverified_never_good(self):
        f,rows=self.run_case(verified=False,previous=9990);self.assertEqual(rows[0]['verdict'],'DIRECT_UNVERIFIED')
    def test_failure_after_cooldown_full(self):
        f,rows=self.run_case(ok=3,previous=4000);f.run_paired_hy2.assert_called_once();self.assertEqual(rows[0]['full_reason'],'light_failure_or_unverified')
    def test_cleanup_failure_aborts(self):
        _,rows=self.run_case(cleanup_failure=True);self.assertEqual(rows[0]['verdict'],'CLEANUP_FAILED_STOPPED')
    def test_ctrl_c_cleans_route(self):
        f,_=self.run_case(stop=True);f.route_delete.assert_called_once_with('203.0.113.1')

if __name__=='__main__':unittest.main()
