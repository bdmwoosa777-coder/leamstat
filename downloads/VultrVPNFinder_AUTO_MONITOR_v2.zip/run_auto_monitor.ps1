param([switch]$Once)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-FinderAdmin
Assert-FinderKey
$pythonPath = Get-FinderPython
Write-Host 'Saved VPS only. 30m light tests; full baseline now, then every 6h or after misses (90m cooldown).'
Write-Host 'No VPS creation/deletion. Stop: Ctrl+C or the existing stop.ps1.'
$monitorArgs = @((Join-Path $PSScriptRoot 'auto_monitor.py'))
if ($Once) { $monitorArgs += '--once' }
& $pythonPath @monitorArgs
exit $LASTEXITCODE
