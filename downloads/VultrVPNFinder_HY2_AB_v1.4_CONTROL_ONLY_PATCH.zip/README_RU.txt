PATCH v1.4 — CONTROL ONLY, поверх установленного v1.2/v1.3
Распакуйте с заменой файлов; config/state/credentials не входят.
Не запускайте -Prepare, -Once, -Run или старые мониторы ради этого контроля.
Единственная нужная сейчас команда:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_hy2_experiment.ps1 -ControlOnly

Ровно один official HY2 client process на каждый из UDP443 и UDP8443 каждого
из трех настроенных VPS: максимум шесть стартов, без программных retries.
Все HY2 endpoints локальные 127.0.0.1:<relay>, SOCKS5 UDP только через
127.0.0.1:10808. Если UDP ASSOCIATE не работает, никакого DIRECT fallback.
TLS проверяет настоящий configured SNI/domain, insecure=false. Один URL:
https://www.gstatic.com/generate_204. Серверная конфигурация не меняется.

HANDSHAKE_AUTH, PROXY_HTTP_SUCCESS и SERVER_PEER_VERIFIED разделены в JSON.
Ожидаемый server-side CONTROL source: 82.47.60.219. SSH management тоже
строго через порт10808. Иной management egress останавливает попытки для
этого VPS; иной UDP peer не выдается за VERIFIED, даже если HTTP прошел.
Один PID может внутренне переподключиться: connection_count/reconnect_observed
покажут это отдельно, это не называется гарантией ровно одного QUIC flow.

У режима нет проверки quiet period, нет записи activity marker, нет добавления
или cleanup DIRECT routes. Логи в logs/hy2_control_<id>/ намеренно исключены
из DIRECT/mixed quiet scanner. Existing HY2 marker и local state не меняются.
Другие режимы по-прежнему требуют HY2 quiet period. Ошибка разбора
миллисекунд официального Hysteria исправлена и в этом патче.
API читает только current inventory и GET instances; credentials используются
локально для тех же подтвержденных IID. Новые VPS не создаются/не удаляются.
Предварительная штатная проверка Finder может обновить локальные бинарники
и DPAPI cache; к DIRECT HY2 она не подключается.

Результат: HY2_AB_CONTROL_ONLY.zip в папке Finder. Пришлите его целиком.
JSON и отдельные client logs разделяют handshake, запрос через proxy, source
peer и UDP счетчики. Ошибка SSH/UDP/клиента записывается без повторных попыток.
При ограничениях сети возможны менее шести стартов — это честно отмечается.

PASS: 45 regression tests. Тестируются все шесть loopback-only endpoints,
запрет fallback, фиксация обоих портов на всех трех IP, отсутствие изменений
quiet bytes/mtime, исключение control logs из scanner, main() без direct route
operations/quiet/baseline и правильный разбор миллисекунд. Живые VPS из этой
среды не тестировались. Запуск остается вручную на вашем ПК.

Изменены ab_client.py, run_hy2_experiment.ps1, test_ab.py и README_RU.txt;
добавлен ab_control_only.py. ab_route.py и ab_diagnose.py включены для
совместимости с v1.2/v1.3. Дальше — предыдущие инструкции; сейчас используйте
только -ControlOnly, чтобы не создавать DIRECT попыток.

PATCH v1.3 ПОВЕРХ v1.2 — НЕ ЗАПУСКАТЬ -Prepare ПОВТОРНО
Распакуйте с заменой файлов. Конфиг/state/credentials не включены.
Новая read-only команда:
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_hy2_experiment.ps1 -Diagnose
Она читает текущий inventory Vultr и использует SSH через SOCKS-контроль,
не запускает HY2, не меняет server config/state и не пишет quiet marker.
С VPS выполняются getent, ip route, ss, systemctl show, чтение журнала HY2
и curl -4/-6 к gstatic/example.com. HTTP-запросы идут от VPS, а не через
домашний HY2 DIRECT. После выполнения пришлите HY2_AB_SERVER_DIAG.zip.
В папке пользователя для этой команды нужен VULTR_API_KEY, как раньше.
Сам -Once/-Run пока не повторять: сначала диагностируем текущий отказ.

Исправлено время официальных Hysteria JSON logs: поле time содержит Unix
миллисекунды, а не секунды. Без исправления v1.2 мог принять дату за далекое
будущее и ошибочно запрещать тест бесконечно. Исправление не удаляет историю
и не уменьшает настоящую 120-минутную паузу; клиенты за последний час по-прежнему
блокируют запуск, а 3-часовая пауза по тем же logs принимается корректно.
Всего PASS: 42 regression tests, включая реальные миллисекундные значения
из присланных логов и отсутствие HY2 process starts при -Diagnose.

Разбор Once: HOT handshakes 2/3, COLD443 1/3, COLD8443 3/3.
HTTP-запросы через туннель не прошли. HTTP/3 web прошел 5/6.
На UDP8443 сервер подтвердил peer прямого пути, значит NAT/handshake там
работали. Изначальный direct_verified требует также успешный HTTP, поэтому
его false в старом выводе не отрицает отдельно записанные route/source proofs.
HOT_SESSION_BROKEN после первого HTTP failure — консервативная остановка
наблюдения, а не всегда доказанный QUIC disconnect. Один клиент явно сообщил
QUIC timeout; причину остальных HTTP timeout без серверных данных не установить.
Трафик направления VPS->сайт и передачи по HY2 нужно диагностировать отдельно.

Изменены: ab_client.py, run_hy2_experiment.ps1, test_ab.py, README_RU.txt.
Добавлен ab_diagnose.py. ab_route.py включен для совместимости с v1.2.
Далее — базовая инструкция предыдущих версий; диагностический запуск
выше не требует повторного -Prepare или нового preflight.

PATCH v1.2 ПОВЕРХ УСТАНОВЛЕННОГО v1.1
Распакуйте с заменой файлов в ту же папку Finder. Конфига в PATCH нет:
заполненный acme_email/domains сохранятся. state.json, credentials и
серверные файлы в PATCH не включены. Не удаляйте state или старые записи.
В архиве только ab_client.py, ab_route.py, test_ab.py, README_RU.txt, AUDIT_RU.txt.

HY2 A/B HOT/COLD v1.2 — отдельный эксперимент для существующего Finder 2.13/2.13.1

Никакие подключения к вашим VPS при подготовке этого архива не выполнялись.
В архиве новые файлы; finder.py, VLESS credentials и config.json не заменяются.
Для этого опыта нужны THREE отдельных доменных имени и один контактный email.

1. ОСТАНОВИТЕ старый Finder/monitor во всех копиях папки на этом ПК.
   Отключите автозапуски старых мониторов. Не подключайте обычные HY2-клиенты
   к выбранным VPS. VPN, который предоставляет SOCKS-контроль, оставьте работающим.
   Одна папка защищена общим RuntimeLock; процессы из разных копий папок
   и другие устройства этим замком не контролируются.

2. Распакуйте дополнение рядом с finder.py, common.ps1, state.json, credentials
   и logs/good_servers.json. Нужны Windows 11, PowerShell администратора,
   VULTR_API_KEY в этом окне и существующий SOCKS5 (например 127.0.0.1:10808).
   Никакой fallback через системный TUN для control-management не используется.

3. В DuckDNS создайте три имени. Вручную установите IPv4 каждого имени:
      первый домен  -> 95.179.141.211
      второй домен  -> 95.179.131.185
      третий домен  -> 140.82.57.112
   Не публикуйте DuckDNS token. Скрипту он не нужен. Уберите AAAA-записи для
   этих имён. Нужны DNS-only записи, без CDN. Дождитесь распространения DNS.
   В hy2_ab_config.json заполните acme_email (три domain уже заполнены). Пример формата
   имени: ваше-имя.duckdns.org. Используются три имени из вашего скриншота; проверьте их перед запуском.
   expected_direct_peer="auto" берется из вашей локальной подтвержденной
   FULL-истории. Если IP вашего провайдера изменился, тест не назовет путь
   GOOD: потребуется указать текущий direct source после независимой проверки.

4. Для настоящей HTTP/3-проверки нужен aioquic 1.3.0 в том же Python:
      . .\common.ps1
      $pythonPath = Get-FinderPython
      & $pythonPath -m pip install aioquic==1.3.0
   Основные HTTP-запросы HOT/COLD используют официальный Hysteria 2.13.0
   из штатного Finder, с обязательной TLS-проверкой домена; insecure=false.

5. ПОДГОТОВКА СЕРВЕРОВ — отдельная ручная команда (меняет HY2-конфигурацию):
      powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_hy2_experiment.ps1 -Prepare
   До изменений создается root-only backup /var/lib/hy2-ab/backup: Xray JSON,
   состояние diagnostic-сервиса, listeners и nft ruleset, если nft установлен.
   При обнаружении существующего backup/service/certificate настройка останавливается.
   Используется официальный Linux Hysteria 2.13.0 с закрепленным SHA256;
   apt устанавливает certbot/nftables; Let's Encrypt выпускает сертификат через
   TCP/80. Имя должно указывать на VPS. Внешний Vultr firewall тоже должен
   разрешать UDP443, UDP8443, TCP80 и TCP443; API firewall скрипт не изменяет.
   При активном UFW добавляются только недостающие разрешения TCP80/TCP443/UDP443.

   В Xray удаляется только inbound с tag=hy2-in. Остальные поля и полный
   VLESS inbound TCP/8443 сохраняются. Xray при этом ПЕРЕЗАПУСКАЕТСЯ:
   уже открытые VLESS-соединения кратко оборвутся, новые должны работать.
   Старый self-signed HY2 после настройки не работает — используется новый
   официальный backend. Старые массовые мониторы к нему запускать нельзя.
   Штатный diagnostic HTTP временно освобождает TCP80; его заменяет сайт.
   Новый сервис hy2-ab.service слушает UDP443, HTTP TCP80 и HTTPS TCP443.
   Статический сайт обслуживается также по настоящему HTTP/3 без HY2 auth.
   Отдельная nft table ip hy2_ab перенаправляет UDP8443 на ТОТ ЖЕ UDP443.
   TCP8443 это правило не затрагивает. NAT source peer сохраняется.
   Salamander/Gecko/obfs и port hopping отсутствуют.
   Сертификат обновляется Certbot через webroot, deploy hook перезапускает
   новый HY2-сервис после фактического renewal. За четырехчасовой опыт
   новый 90-дневный сертификат обычно не требует обновления.

6. Нужны минимум ДВА ЧАСА с последней реальной клиентской HY2 активности.
   Сам -Prepare НЕ сбрасывает quiet period. Если до него уже прошло >=120
   минут и логи это подтверждают, -Once можно выполнить сразу после -Prepare.
   Это пауза для
   наблюдения, а не гарантия сброса неизвестного состояния фильтра.
   Скрипт проверяет локальные маркеры и клиентские логи, но не может доказать
   отсутствие чужих подключений/устройств. Отсчет quiet period нельзя обойти
   параметром запуска; не удаляйте маркеры ради обхода.

7. КОРОТКИЙ PREFLIGHT — только вручную:
      powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_hy2_experiment.ps1 -Once
   В нем по одному HOT process и по одной новой COLD HY2-сессии на порт каждого
   VPS: всего 9 HY2-стартов для трех серверов. Дополнительно 6 unauthenticated
   QUIC HTTP/3-запросов проверяют camouflage и валидный TLS. Это отдельные
   QUIC-подключения, они не считаются HY2-клиентами и логируются отдельно.
   Порты разделены паузой 90 секунд; HOT-проверки идут в том же процессе.
   Один VLESS fresh test на VPS. После preflight все клиенты завершаются,
   маршруты снимаются, печатается сводка. Смотрите logs/hy2_ab_<run_id>/summary.json.

   PREFLIGHT PASS требует для КАЖДОГО VPS хотя бы одного подтвержденного
   COLD успеха, подтвержденного HOT443 ALIVE и хотя бы одного успешного
   HTTP/3 camouflage-порта с проверенным TLS. Отказ другого порта остается
   виден отдельно, а не маскируется. Если HOT443 не может установиться,
   строгий preflight не разрешает делать вид, что опыт с ранее живой HOT443
   сессией возможен. При продолжающемся DIRECT 0/8 дождитесь восстановления.
   Не запущенный/неподтвержденный тест не считается успешным.

8. ПРОСМОТРИТЕ отчет. Если preflight PASS, после еще ДВУХ ЧАСОВ без HY2
   запустите основной опыт самостоятельно (gate действителен 12 часов):
      powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_hy2_experiment.ps1 -Run
   Автоматического перехода от preflight к длинному тесту НЕТ. Отдельная
   команда -Run после чтения отчета — ваше решение запускать эксперимент.
   Изменение конфига требует нового preflight. Не меняйте конфиг между ними.

   По умолчанию основной опыт 4 часа, 3 VPS:
   - по одной HOT443 сессии на VPS;
   - небольшие HOT HTTP-запросы каждые ~120 секунд и после COLD для корреляции;
   - одна НОВАЯ COLD HY2-сессия на UDP443 и одна на UDP8443 раз в ~20 минут;
   - порядок 443->8443, затем 8443->443, пауза 90 секунд;
   - один fresh VLESS TCP8443 запрос раз в час;
   - никаких HY2 8+8 и никаких дополнительных COLD попыток после FAIL.
   Это около 72 COLD + 3 HOT стартов (75). Предельный бюджет starts +
   наблюдаемых успешных reconnect = 100; при его достижении опыт завершается.
   Уже выполненный preflight — еще 9 HY2 стартов, плюс 6 QUIC web probes.
   Другие duration/interval можно задать в конфиге в ограниченных пределах;
   для 6 часов на трех VPS понадобится около 111 стартов, поэтому текущий
   бюджет остановит такой запуск раньше. Не повышайте его без причины.
   Компьютер должен оставаться включенным без сна.

HOT И DIRECT — КАК ЧИТАТЬ РЕЗУЛЬТАТЫ
- /32 для всех трех IP установлены одновременно через gateway192.168.0.1/IF8.
  Новый менеджер маршрутов не удаляет маршрут первого HOT при тесте второго.
  Effective route проверяется до/после HTTP и перед стартом клиента.
- Успешная HY2-сессия подтверждается серверным source peer, который должен
  совпадать с ранее доверенным direct peer и отличаться от SSH/SOCKS egress.
  Ошибки route дают остановку; отсутствие peer proof не превращается в GOOD.
- HOT Session создается ОДИН РАЗ. PID/process_start/session_identifier
  сохраняются, HTTP-запросы не вызывают Popen. Официальный JSON client log
  содержит connection count; count>1 = HOT_RECONNECTED, continuity закончена.
- HOT_SESSION_ALIVE: успешный HTTP, процесс жив, count=1, нет серверного
  disconnect. HOT_SESSION_BROKEN: HTTP не прошел/процесс умер/disconnect.
  При первом HOT interruption или reconnect клиент закрывается и никогда
  не перезапускается в этом run. Это исключает серию автоматических новых
  попыток на последующих HOT ticks. Ошибка целевого сайта тоже может оборвать
  HOT-наблюдение, даже если QUIC технически был жив — смотрите client_error.
- PID/session_identifier — идентификатор поколения клиента, НЕ криптографически
  наблюдаемый QUIC Connection ID. Один PID сам по себе не доказывает одну QUIC
  сессию; используются count и серверные события. Неуспешные внутренние
  reconnect могут не оставить count>1: точное число сетевых попыток без pcap
  неизвестно. Счетчики честно именуются process starts/reconnects observed.
- HOT-запросы/QUIC keepalive — продолжающийся трафик, опыт не является полной
  тишиной после старта. Он проверяет, помогает ли уже установленная сессия.
- VLESS проходит проверенный effective route, но его source peer отдельно
  этим addon не аттестуется: явно SOURCE_NOT_ATTESTED, а не VERIFIED VPN control.

ЛОГИ (отдельные от старого монитора, каждый run имеет run_id)
logs/hy2_ab_hotcold.jsonl
logs/hy2_ab_hotcold.csv
logs/hy2_ab_hotcold.log
logs/hy2_ab_<run_id>/ — отдельные официальные client logs и summary.json.
CSV содержит основные поля; JSONL также server-side evidence и TLS/H3 признаки.
Сводка по VPS: COLD443/8443 success/total и verified_success; sampled HOT uptime,
interruptions; VLESS; максимальная серия failed samples; совпадение двух портов
по циклу; COLD FAIL с последующим VERIFIED HOT OK в ближайшие 180 секунд.
Длительности между пробами — оценка по выборке, не доказательство непрерывного
отказа/успеха. Порты проверяются последовательно, а не одновременно.

ОСТАНОВКА И ОТКАТ
Ctrl+C или штатный stop.ps1. Завершаются только созданные этим запуском
Hysteria процессы и принадлежащие ему /32 routes. При ошибке удаления
метаданные hy2_ab_routes.json сохраняются; следующий запуск сначала делает
cleanup и не начинает опыт при неустраненной ошибке. Резервная копия Xray
и сервер остаются после завершения: обычный stop не откатывает сервер.
Вернуть старый серверный HY2 вручную:
 powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\run_hy2_experiment.ps1 -Rollback
Откат восстанавливает Xray JSON, запускает прежний diagnostic если он работал,
убирает собственную NAT table/service, добавленные UFW разрешения и созданный
для опыта сертификат. Backup остается; повторная настройка не перетирает его.
При ошибке -Prepare на одном VPS этот VPS автоматически откатывается. Другие
уже подготовленные VPS остаются настроенными; используйте -Rollback для всей
группы, если не продолжаете. Установленные apt-пакеты не удаляются откатом.
Не запускайте старый Finder одновременно: он может счесть новый HY2 setup
неисправным и пытаться установить прежний стек.

МЕТОДОЛОГИЧЕСКОЕ ОГРАНИЧЕНИЕ
443 и 8443 в НОВОМ стеке — один backend/config, меняется внешний UDP порт.
Но старый self-signed Xray HY2 против нового official Hysteria + LE + сайта —
это несколько изменений одновременно. Такой опыт не доказывает отдельно
пользу сертификата/маскировки. Для этого нужен последующий отдельный A/B.
Тишина 2 часа и малое число flow не гарантируют отсутствие влияния на ТСПУ.
Источник path-specific проблемы по этим данным нельзя назвать на 100%.

ПРОВЕРКИ ПЕРЕД ВЫДАЧЕЙ
- 77 штатных регрессионных тестов доступной версии Finder 2.13 — PASS.
- 17 регрессионных тестов AUTO MONITOR v3 — PASS.
- 39 новых тестов — PASS: routes/cleanup, источник, read-only helpers,
  HOT process reuse, счетчик reconnect, budget, VLESS config preservation.
- Штатные local protocol, key SSH и password SSH/SFTP smoke checks — PASS.
- Новый loopback smoke: настоящий official Hysteria server, HTTPS/H3 со строгой
  проверкой доверенного локального сертификата, 3 HTTP-запроса через один
  client process, connection count=1, server peer verified — PASS.
  Тестовый CA использован только в локальном smoke, в production insecure=false.
- На Windows и на ваших VPS этот новый опыт/installer НЕ запускались.
  Реальный Let's Encrypt/DNS/systemd/nft/UFW доказываются вашим -Prepare/-Once.
  Доступная здесь исходная база 2.13; отчет пользователя сообщает 2.13.1.
  Файлы 2.13.1 из работающего ПК в этот архив не включены; полную идентичность
  окружений утверждать нельзя. При несовместимости код прекращает выполнение.

СОСТАВ БАЗОВОГО ДОПОЛНЕНИЯ (PATCH включает только измененные файлы)
ab_client.py — scheduler, HOT/COLD lifecycle, gate, quiet period, multi-/32, logging.
ab_route.py — effective-route verification и ограничение API до чтения.
ab_server.py — backup/install/LE/camouflage/UDP redirect и rollback.
ab_h3_probe.py — unauthenticated HTTP/3 с проверкой TLS/SNI.
ab_report.py — сводка результатов с ограничениями выборки.
hy2_ab_config.json — три IP, заполненные домены DuckDNS и пустой email, интервалы и бюджет.
run_hy2_experiment.ps1 — явные -Prepare/-Rollback/-Once/-Run, без автозапуска.
test_ab.py — 39 новых regression tests.
local_backend_smoke.py — воспроизводимый loopback dev test (пути Linux test-tools).
AUDIT_RU.txt — выводы по присланной истории и выбор трех VPS.
README_RU.txt — эта инструкция.

Подробности команд установки сохраняются только на VPS в root-only
/var/lib/hy2-ab/installer.log; не публикуйте его без проверки на credentials.
Не прерывайте -Prepare во время установки пакетов/выдачи сертификата.
При ошибке read-only диагностический вывод покажет тип ошибки и путь к логу.

ИСПРАВЛЕНИЕ v1.1 ПЕРЕД -Prepare
Внесены реальные имена:
nordedgefr26.duckdns.org -> 95.179.141.211
nordhy2b26.duckdns.org   -> 95.179.131.185
nordhy2c26.duckdns.org   -> 140.82.57.112
A/AAAA проверены через публичный DNS при подготовке v1.1; во время -Prepare
DNS проверяется заново с самого VPS. Заполните только acme_email.

Было: общий ss -lnut + поиск подстрок :443/:8443. Это могло пройти за счет
существующего VLESS TCP8443 без работающего UDP8443 redirect.
Стало: отдельные ss -H -4 -lnu и ss -H -lnt, точное сравнение порта/адреса,
а затем nft -j list table ip hy2_ab. Требуется единственная NAT PREROUTING
chain с priority -100 и одно правило udp dport 8443 redirect to :443.
Отсутствующая/неправильная chain, protocol, port или лишнее правило дают
ошибку установки и штатный rollback. UDP8443 socket не требуется.
Результаты сохраняются root-only в /var/lib/hy2-ab/prepared_checks.json.
-Once по-прежнему отдельно проверяет фактическую HTTP/3/HY2 доступность портов.
Изменены только ab_server.py, test_ab.py, hy2_ab_config.json и этот README.
В v1.1 интервалы, HOT/COLD, gate, quiet period, сайт и существующие исходники
Finder оставались прежними. В v1.2 выбор instance и quiet period исправлены ниже. Нативный nft/systemd на VPS пока не проверялся.

ИСПРАВЛЕНИЕ v1.2: CURRENT INSTANCE + QUIET PERIOD
В присланном реальном state.json 101 candidate entry. Для каждого из трех IP
нашлась одна запись. Ошибка возникала не из-за дублей: IP находится внутри
entry["candidate"]["ip"], тогда как прежний фильтр проверял entry["ip"].
Реальный state проверен локально с имитацией текущего API inventory; файл
и его содержимое не менялись. Реальный API аккаунта из этой среды не вызывался.

Теперь -Prepare/-Once/-Run/-Rollback получают текущую paginated inventory
через GET /instances, затем подтверждают каждый совпавший main_ip отдельным
GET /instances/{id}. API404 игнорируется как stale inventory; другие ошибки
не скрываются. Требуется ровно один существующий instance с этим main_ip
и region=ams. Повторы одного ID в inventory дедуплицируются. Исторический
state не определяет количество живых VPS. Credentials ищутся только для
текущего instance ID, а не у другого VPS с тем же историческим IP.
Если credentials отсутствуют, выдается отдельная понятная ошибка без записи
в state и без попытки использовать секреты другого instance. ReadOnlyAPI
разрешает list_instances/get_instance/get_instance_user_data, операции записи
через него запрещены. Сам -Prepare по-прежнему меняет HY2 на выбранных VPS
по прежнему плану: исправление выбора не добавляет новых серверных изменений.

-Prepare/-Rollback больше не пишут hy2_ab_last_activity.json. Старые маркеры
reason=prepare/rollback также игнорируются; удалять их вручную не требуется.
Новые маркеры schema=2 записываются для COLD, HOT_START, HOT_TRAFFIC и
HOT_RECONNECT (попытка HTTP внутри живой HOT — тоже реальный HY2 traffic).
Служебные UI-записи/VLESS_CONTROL/H3_CAMOUFLAGE и повторные отчеты о уже
закрытой HOT не сбрасывают HY2 quiet period. Дополнительно читаются реальные
клиентские hy2-client-*.log, HOT/COLD client logs и HY2 DIRECT/CONTROL события
в finder.log. FULL/DIRECT не теряются даже при отсутствии нового маркера.
Время события в логе важнее времени копирования/распаковки файла; при
неизвестном формате непустого client log используется консервативно mtime.
Пустой touched log не является HY2 activity. Отсутствие любых логов не
доказывает отсутствие трафика с других устройств. Quiet period не гарантирует
сброс состояния фильтра, а лишь фиксирует наблюдаемую локальную паузу.

После успешного -Prepare теперь можно сразу -Once, ЕСЛИ уже выдержаны >=120
минут с последнего HY2. После -Once остается нужна новая пауза: он действительно
создает клиентские HY2-сессии. Gate/config, интервалы и бюджет прежние.

Проверки v1.2: 39 regression tests, включая actual-state-shape, несколько
historical entries/один текущий API instance, два текущих instance, stale404,
region/IP mismatch, read-only запрет mutations, реальный main()-путь -Prepare
с mocked SSH/API и неизменными bytes/mtime quiet marker; recent FULL и HOT
reconnect по-прежнему блокируют ранний запуск. В нативной Windows/API учетной
записи пользователя эти изменения еще не запускались.
