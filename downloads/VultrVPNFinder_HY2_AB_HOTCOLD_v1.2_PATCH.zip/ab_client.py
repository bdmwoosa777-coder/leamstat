"""Low-rate experiment; all remote actions require a user-invoked mode."""
from __future__ import annotations
import argparse
import contextlib
import csv
import datetime as dt
import hashlib
import ipaddress
import json
import math
import os
from pathlib import Path
import re
import subprocess
import tempfile
import time
import uuid
import finder as core
import password_ssh
from socks_relay import SocksRelay
from runtime_support import RuntimeLock, STOP_PATH, check_stop, pause, cleanup_mode
from ab_route import verify_route, RouteError, ReadOnlyAPI

BASE=Path(__file__).resolve().parent
CFG=BASE/'hy2_ab_config.json'
ROUTES=BASE/'hy2_ab_routes.json'
GATE=BASE/'hy2_ab_preflight.json'
QUIET=BASE/'hy2_ab_last_activity.json'
FIELDS=['timestamp','run_id','ip','port','test_type','cycle','direct_route_verified','direct_verified','source_peer','fresh_client','pid','process_start','session_identifier','connection_count','state','ok','http_code','latency_ms','client_error','fresh_hy2_processes','reconnects_observed','fresh_quic_probe_count']

def load_config(mode=None):
    cfg=core.load_json(CFG,{})
    if not 1<=len(cfg['servers'])<=3:raise ValueError('Select 1..3 existing VPS')
    if cfg.get('gateway')!='192.168.0.1' or cfg.get('interface_index')!=8:raise ValueError('Expected Ethernet IF8 via 192.168.0.1')
    for key,lo,hi in [('cold_interval_minutes',20,120),('port_gap_seconds',60,120),('hot_interval_seconds',120,600),('duration_hours',.1,12),('quiet_minutes',60,240),('max_fresh_hy2',2,100)]:
        value=cfg[key]
        if isinstance(value,bool) or not isinstance(value,(float,int)) or not lo<=value<=hi:raise ValueError('Invalid '+key)
    ips=set();domains=set()
    for s in cfg['servers']:
        ipaddress.IPv4Address(s['ip'])
        if s.get('expected_direct_peer')!='auto':ipaddress.IPv4Address(s['expected_direct_peer'])
        if mode!='rollback' and (not re.fullmatch(r'(?=.{4,253}$)[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?',s.get('domain','')) or '.' not in s['domain']):raise ValueError('Fill real domain for '+s['ip'])
        if s['ip'] in ips or (mode!='rollback' and s['domain'] in domains):raise ValueError('Duplicate IP/domain')
        ips.add(s['ip']);domains.add(s['domain'])
    if mode!='rollback' and '@' not in cfg.get('acme_email',''):raise ValueError('Fill acme_email')
    return cfg

def fingerprint(cfg):return hashlib.sha256(json.dumps(cfg,sort_keys=True).encode()).hexdigest()

def trusted_baseline(records):
    for rec in records:
        for row in (rec.get('latest_retest') or {}, rec):
            assessment=(row.get('paired_hy2') or {}).get('assessment') or {}
            if not assessment.get('control_verified'):continue
            peers=assessment.get('direct_peers') or []
            peer=assessment.get('direct_baseline') or (peers[0] if len(peers)==1 else None)
            if peer and peer!=assessment.get('proxy_egress'):return str(ipaddress.IPv4Address(peer))
    raise RuntimeError('No trusted saved direct baseline; fill expected_direct_peer explicitly')

def current_instance(api, ip, inventory):
    """Membership comes only from the current paginated inventory and GET, not state."""
    ids={item['id'] for item in inventory if item.get('main_ip')==ip and item.get('id')}
    live=[]
    for iid in sorted(ids):
        try:
            inst=api.get_instance(iid)
        except core.APIError as exc:
            if exc.status==404:continue
            raise
        if not inst or inst.get('main_ip')!=ip or inst.get('status') in ('deleted','destroyed'):continue
        if inst.get('id')!=iid:raise RuntimeError('Vultr inventory/GET instance ID mismatch')
        live.append(inst)
    if len(live)!=1:
        raise RuntimeError(f'Expected exactly one current Vultr instance for {ip}; found {len(live)}')
    if live[0].get('region')!='ams':raise RuntimeError('Current Vultr instance is not in ams: '+ip)
    return live[0]

def saved_candidate(state, inst):
    """Only associate local credentials by current instance ID; never by IP alone."""
    iid=inst['id'];matches=[]
    for key,entry in state.get('candidates',{}).items():
        candidate=entry.get('candidate')
        if not isinstance(candidate,dict) or entry.get('phase')=='deleted':continue
        declared=candidate.get('instance_id') or entry.get('instance_id')
        if declared and declared!=iid:continue
        if key!=iid and declared!=iid:continue
        if not candidate.get('hy_auth'):continue
        matches.append((key==iid,entry.get('updated') or candidate.get('created_at') or '',str(key),candidate))
    if not matches:raise RuntimeError('No saved credentials for current Vultr instance '+iid+'; state was not changed')
    # Canonical IID-keyed entry first, then newest alias if only historical aliases exist.
    candidate=sorted(matches,key=lambda item:item[:3],reverse=True)[0][3]
    return dict(candidate,instance_id=iid,ip=inst['main_ip'],region=inst['region'])

def resolve_cohort(f, servers):
    inventory=f.api.list_instances() # Finder paginates this read-only collection.
    cohort=[]
    for server in servers:
        inst=current_instance(f.api,server['ip'],inventory)
        candidate=saved_candidate(f.state,inst)
        print(f"Selected current Vultr instance {inst['id']} ip={inst['main_ip']} region=ams",flush=True)
        cohort.append((server,candidate))
    return cohort

class Routes:
    def __init__(self,f):self.f=f
    def save(self,rows):core.save_json(ROUTES,rows)
    def cleanup(self):
        errors=[]
        with cleanup_mode():
            rows=core.load_json(ROUTES,[])
            for r in list(rows):
                ip=str(ipaddress.IPv4Address(r['ip']));gateway=str(ipaddress.IPv4Address(r['gateway']));index=int(r['index'])
                try:
                    cp=core.run(['route.exe','DELETE',ip,'MASK','255.255.255.255',gateway,'IF',str(index)],timeout=10)
                    if any(x['gateway']==gateway and int(x['index'])==index for x in self.f.query_host_routes(ip)):raise RouteError('Owned route still exists')
                    rows.remove(r);self.save(rows)
                except Exception:errors.append(ip)
            if errors:raise RouteError('Could not remove experiment routes: '+', '.join(errors))
            ROUTES.unlink(missing_ok=True)
    def add(self,ip):
        if self.f.query_host_routes(ip):raise RouteError('Existing /32; refusing to replace '+ip)
        rows=core.load_json(ROUTES,[]);rows.append({'ip':ip,'gateway':self.f.direct_gateway,'index':self.f.direct_interface_index});self.save(rows)
        cp=core.run(['route.exe','ADD',ip,'MASK','255.255.255.255',self.f.direct_gateway,'METRIC','5','IF',str(self.f.direct_interface_index)],timeout=10)
        if cp.returncode:raise RouteError('Could not add '+ip)
        verify_route(self.f,ip)

def events(text):
    rows=[]
    for line in text.splitlines():
        try:
            r=json.loads(line)
            if r.get('msg') not in ('client connected','client disconnected'):continue
            addr=r.get('addr','');peer=addr.rsplit(':',1)[0].strip('[]');ipaddress.ip_address(peer)
            rows.append({'event':r['msg'],'actor':r.get('id'),'peer':peer,'remote_addr':addr})
        except (ValueError,TypeError):pass
    return rows

class Observer:
    def __init__(self,client):
        self.client=client
        rc,out=password_ssh.execute(client,'printf "%s" "$SSH_CONNECTION"',timeout=10)
        self.proxy_peer=out.split()[0] if rc==0 and out.split() else None
    def cursor(self):
        rc,out=password_ssh.execute(self.client,'journalctl -u hy2-ab.service -n 0 --show-cursor --no-pager -o cat',timeout=10)
        match=re.search(r'-- cursor: ([A-Za-z0-9=;:_-]+)',out)
        if rc or not match:raise RuntimeError('Cannot observe server journal')
        return match[1]
    def after(self,cursor):
        if not re.fullmatch(r'[A-Za-z0-9=;:_-]+',cursor):raise ValueError('Bad journal cursor')
        rc,out=password_ssh.execute(self.client,"journalctl -u hy2-ab.service --after-cursor='"+cursor+"' --no-pager -o cat",timeout=10)
        if rc:raise RuntimeError('Server journal unavailable')
        return events(out)

@contextlib.contextmanager
def management(f,s,c):
    port=f.discover_v2rayn_socks()
    if not port:raise RuntimeError('SOCKS5 control required; no system fallback')
    f.ensure_password_backend()
    with SocksRelay(port,s['ip'],22) as relay:
        client=f.paired_management_client('127.0.0.1',relay.port,f.instance_password(c['instance_id']),timeout=10)
        try:yield client
        finally:client.close()

def log_connection_count(text):
    counts=[]
    for line in text.splitlines():
        try:
            r=json.loads(line)
            if r.get('msg')=='connected to server':counts.append(int(r['count']))
        except (ValueError,TypeError,KeyError):pass
    return max(counts,default=0)

class Session:
    def __init__(self,f,s,c,port,actor,run):
        self.f=f;self.s=s;self.port=port;self.actor=actor;self.run=run;self.proc=None
        self.identifier=uuid.uuid4().hex;self.started=core.now_iso();self.started_mono=time.monotonic();self.last_count=0;self.closed=False
        self.temp=tempfile.TemporaryDirectory(prefix='hy2ab-');self.log_path=run.dir/(actor+'-'+s['ip']+'-'+self.identifier+'.log')
        cfg={'server':f"{s['ip']}:{port}",'auth':actor+':'+c['hy_auth'],'tls':{'sni':s['domain'],'insecure':False},'lazy':False,'socks5':{'listen':'127.0.0.1:'+str(f.free_port())}}
        self.socks=int(cfg['socks5']['listen'].split(':')[-1]);path=Path(self.temp.name)/'client.json';path.write_text(json.dumps(cfg));os.chmod(path,0o600)
        try:
            verify_route(f,s['ip']);run.spend()
            self.stream=self.log_path.open('ab')
            self.proc=subprocess.Popen([str(f.hy_exe),'--disable-update-check','--log-format','json','client','-c',str(path)],stdout=self.stream,stderr=subprocess.STDOUT,creationflags=core.CREATE_NO_WINDOW)
            record_hy2_activity('HOT_START' if actor=='hot' else 'COLD',run.id)
            self.ready=f.wait_client(self.proc,self.socks)
            if not self.ready:self.close()
        except BaseException:self.close();raise
    def count(self):
        count=log_connection_count(self.log_path.read_text(encoding='utf-8',errors='replace'))
        if count>max(1,self.last_count):record_hy2_activity('HOT_RECONNECT' if self.actor=='hot' else 'COLD',self.run.id)
        self.run.reconnects+=max(0,count-max(1,self.last_count));self.last_count=max(self.last_count,count)
        return count
    def request(self):
        verify_route(self.f,self.s['ip'])
        if self.closed or not self.proc or self.proc.poll() is not None or not self.ready:
            return {'ok':False,'code':0,'ms':None,'error':'client not available'}
        # Always reuse this process and local SOCKS listener.
        record_hy2_activity('HOT_TRAFFIC' if self.actor=='hot' else 'COLD',self.run.id)
        result=self.f.curl_proxy_tests(self.socks,tests_override=1)['results'][0]
        verify_route(self.f,self.s['ip']);return result
    def close(self):
        if self.closed:return
        self.closed=True
        try:
            if self.proc:self.f.stop_client(self.proc)
        finally:
            if hasattr(self,'stream'):self.stream.close()
            self.temp.cleanup()

def hot_state(count, ok, process_alive, disconnected=False):
    if count>1:return 'HOT_RECONNECTED'
    if not process_alive or not ok or count!=1 or disconnected:return 'HOT_SESSION_BROKEN'
    return 'HOT_SESSION_ALIVE'

class Run:
    def __init__(self,f,cfg,once):
        self.f=f;self.cfg=cfg;self.once=once;self.id=uuid.uuid4().hex;self.starts=0;self.reconnects=0;self.quic=0
        self.dir=core.LOG_DIR/('hy2_ab_'+self.id);self.dir.mkdir(parents=True);self.rows=[]
    def spend(self):
        if self.starts+self.reconnects>=self.cfg['max_fresh_hy2']:raise RuntimeError('Fresh HY2 budget reached; stop')
        self.starts+=1
    def write(self,s,port,kind,cycle,result,**extra):
        row=dict(timestamp=core.now_iso(),run_id=self.id,ip=s['ip'],port=port,test_type=kind,cycle=cycle,
                 ok=bool(result.get('ok')),http_code=result.get('code',0),latency_ms=result.get('ms'),client_error=result.get('error',''),
                 fresh_hy2_processes=self.starts,reconnects_observed=self.reconnects,fresh_quic_probe_count=self.quic,**extra)
        self.rows.append(row)
        for name in ('hy2_ab_hotcold.jsonl',):
            with (core.LOG_DIR/name).open('a',encoding='utf-8') as out:out.write(json.dumps(row,ensure_ascii=False)+'\n')
        p=core.LOG_DIR/'hy2_ab_hotcold.csv';exists=p.exists() and p.stat().st_size>0
        with p.open('a',newline='',encoding='utf-8') as out:
            w=csv.DictWriter(out,fieldnames=FIELDS,extrasaction='ignore')
            if not exists:w.writeheader()
            w.writerow(row)
        text=f"{row['timestamp']} run={self.id} {s['ip']} {kind} {port}: {'OK' if row['ok'] else 'FAIL'} DIRECT={'VERIFIED' if row.get('direct_verified') else 'UNVERIFIED'} {row.get('state','')} starts={self.starts} reconnects={self.reconnects}"
        with (core.LOG_DIR/'hy2_ab_hotcold.log').open('a',encoding='utf-8') as out:out.write(text+'\n')
        print(text,flush=True)

    def sample(self,s,c,observer,port,kind,cycle,hot=None):
        verify_route(self.f,s['ip']);cursor=observer.cursor();owned=None
        try:
            session=hot
            if session is None:
                owned=session=Session(self.f,s,c,port,'cold'+str(port),self)
            result=session.request();count=session.count()
            evidence=observer.after(cursor);actor=session.actor
            connected=[e for e in evidence if e['actor']==actor and e['event']=='client connected']
            if hot is not None:
                hot.evidence+=evidence
                connected=[e for e in hot.evidence if e['actor']==actor and e['event']=='client connected']
            peers={e['peer'] for e in connected}
            verified=bool(result.get('ok') and peers=={s['expected_direct_peer']} and observer.proxy_peer and observer.proxy_peer!=s['expected_direct_peer'])
            disconnected=any(e['event']=='client disconnected' and e['actor']==actor for e in (hot.evidence if hot else evidence))
            state=hot_state(count,result.get('ok'),session.proc.poll() is None,disconnected) if hot else 'COLD'
            self.write(s,port,kind,cycle,result,direct_route_verified=True,direct_verified=verified,source_peer=','.join(sorted(peers)),
                       fresh_client=hot is None,pid=session.proc.pid,process_start=session.started,session_identifier=session.identifier,
                       connection_count=count,state=state,server_evidence=evidence)
            if count>1 or (hot is not None and state!='HOT_SESSION_ALIVE'):
                # Stop on first HOT interruption instead of issuing future requests
                # that could make the reconnectable client create more fresh flows.
                session.close() # Never restart it, even if the path later recovers.
            if self.starts+self.reconnects>=self.cfg['max_fresh_hy2']:raise RuntimeError('Fresh HY2 budget reached')
            return verified
        finally:
            if owned:owned.close()

    def execute(self,cohort):
        with contextlib.ExitStack() as stack:
            watchers={};hots={};next_hot={};next_cold={};next_vless={};cycles={};pending={}
            for s,c in cohort:
                client=stack.enter_context(management(self.f,s,c));obs=Observer(client);watchers[s['ip']]=obs
                cursor=obs.cursor();hot=Session(self.f,s,c,443,'hot',self);stack.callback(hot.close)
                hot.evidence=obs.after(cursor);hots[s['ip']]=hot
                next_hot[s['ip']]=0;next_cold[s['ip']]=time.monotonic();next_vless[s['ip']]=0;cycles[s['ip']]=0
                if self.once:
                    from ab_h3_probe import check
                    for port in (443,8443):
                        verify_route(self.f,s['ip']);self.quic+=1
                        try:
                            r=check(s['ip'],port,s['domain']);verify_route(self.f,s['ip']);ok=r['http_code']==200 and r['body_bytes']>0
                            result=dict(ok=ok,code=r['http_code'])
                        except RouteError:raise
                        except Exception as e:result=dict(ok=False,error=type(e).__name__)
                        self.write(s,port,'H3_CAMOUFLAGE',0,result,direct_route_verified=True,direct_verified=False,fresh_client=True,tls_verified=bool(result['ok']))
            deadline=time.monotonic()+(self.cfg['duration_hours']*3600 if not self.once else 900)
            while time.monotonic()<deadline:
                check_stop();now=time.monotonic()
                for s,c in cohort:
                    ip=s['ip'];obs=watchers[ip];hot=hots[ip]
                    if now>=next_hot[ip]:
                        self.sample(s,c,obs,443,'HOT',cycles[ip],hot);next_hot[ip]=time.monotonic()+self.cfg['hot_interval_seconds']
                    if now>=next_vless[ip]:
                        verify_route(self.f,ip);r=self.f.test_vless(c,ip,tests_override=1)['results'][0];verify_route(self.f,ip)
                        self.write(s,8443,'VLESS_CONTROL',cycles[ip],r,direct_route_verified=True,direct_verified=False,fresh_client=True,state='TCP_CONTROL_SOURCE_NOT_ATTESTED')
                        next_vless[ip]=time.monotonic()+3600
                    if ip in pending and now>=pending[ip][0]:
                        port=pending.pop(ip)[1];self.sample(s,c,obs,port,'COLD',cycles[ip]);next_hot[ip]=0
                    elif now>=next_cold[ip] and ip not in pending:
                        if self.once and cycles[ip]>=1:continue
                        cycles[ip]+=1;ports=(443,8443) if cycles[ip]%2 else (8443,443)
                        self.sample(s,c,obs,ports[0],'COLD',cycles[ip]);next_hot[ip]=0;pending[ip]=(time.monotonic()+self.cfg['port_gap_seconds'],ports[1])
                        next_cold[ip]=time.monotonic()+self.cfg['cold_interval_minutes']*60
                if self.once and all(cycles[s['ip']]>=1 for s,_ in cohort) and not pending:
                    for s,c in cohort:self.sample(s,c,watchers[s['ip']],443,'HOT',cycles[s['ip']],hots[s['ip']])
                    break
                pause(1)
        return self.rows


ACTIVITY_KINDS={'COLD','HOT_START','HOT_TRAFFIC','HOT_RECONNECT','FULL_DIRECT'}

def record_hy2_activity(kind,run_id):
    if kind not in ACTIVITY_KINDS:raise ValueError('Not client HY2 activity: '+kind)
    core.save_json(QUIET,{'schema':2,'activity':kind,'time':time.time(),'run_id':str(run_id)})

def activity_time(value):
    try:
        if isinstance(value,bool):return None
        result=float(value) if isinstance(value,(float,int)) else dt.datetime.fromisoformat(value.replace('Z','+00:00')).timestamp()
        return result if math.isfinite(result) and result>=0 else None
    except (ValueError,TypeError,AttributeError,OverflowError):return None

def line_time(line):
    try:
        row=json.loads(line)
        if isinstance(row,dict):
            for key in ('ts','timestamp','time'):
                parsed=activity_time(row.get(key))
                if parsed is not None:return parsed
    except ValueError:pass
    line=re.sub(r'\x1b\[[0-9;]*m','',line)
    stamp=re.match(r'^\s*\[?(\d{4}-\d\d-\d\d[T ]\d\d:\d\d:\d\d(?:\.\d+)?(?:Z|[+-]\d\d:\d\d)?)',line)
    return activity_time(stamp[1]) if stamp else None

def client_log_time(path,full_only=False):
    latest=None;has_activity=False
    with path.open(encoding='utf-8-sig',errors='replace') as stream:
        for line in stream:
            if not line.strip():continue
            if full_only and not re.search(r'\bHY2 (?:DIRECT|CONTROL)\s+\d+/\d+:',line):continue
            has_activity=True;parsed=line_time(line)
            if parsed is not None:latest=max(latest or 0,parsed)
    # Trust event timestamps over archive/copy mtimes. Unknown-format client logs
    # use mtime conservatively; an empty touched file is not a client attempt.
    return latest if latest is not None else (path.stat().st_mtime if has_activity else 0)

def last_hy2_activity():
    previous=core.load_json(QUIET,{})
    latest=0;source='none'
    if previous.get('reason') not in ('prepare','rollback') and (
        previous.get('schema')!=2 or previous.get('activity') in ACTIVITY_KINDS):
        stamp=activity_time(previous.get('time'))
        if stamp is not None:latest=stamp;source='client activity marker'
    paths=set(core.LOG_DIR.rglob('hy2-client-*.log'))|set(core.LOG_DIR.glob('hy2_ab_*/*.log'))
    finder_log=core.LOG_DIR/'finder.log'
    if finder_log.exists():paths.add(finder_log)
    for path in paths:
        stamp=client_log_time(path,full_only=path==finder_log)
        if stamp>latest:latest=stamp;source=str(path.name)
    return latest,source

def quiet_check(cfg):
    latest,source=last_hy2_activity()
    elapsed=time.time()-latest
    required=cfg['quiet_minutes']*60
    if latest and elapsed<required:
        raise RuntimeError(f'HY2 quiet period not completed: {max(0,elapsed)/60:.1f}/{cfg["quiet_minutes"]} min; source={source}')
    if latest:
        print(f'HY2 quiet period satisfied: {elapsed/60:.1f} min, required {cfg["quiet_minutes"]}; source={source}',flush=True)
    else:
        print('No local HY2 activity evidence found; this does not prove absence of other clients',flush=True)

def finish_server_operation():
    # Preparation invalidates the test gate, but must not write client activity.
    GATE.unlink(missing_ok=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--mode',choices=['prepare','rollback','once','run'],required=True);args=p.parse_args()
    cfg=load_config(args.mode)
    config_hash=fingerprint(cfg)
    if os.name!='nt' or not core.is_admin():raise RuntimeError('Windows administrator required')
    with RuntimeLock():
        STOP_PATH.unlink(missing_ok=True);f=core.Finder();routes=Routes(f)
        try:
            if args.mode=='once':GATE.unlink(missing_ok=True)
            f.retest_saved_mode=True;f.preflight(check_only=True);f.api=ReadOnlyAPI(f.api);f.cleanup_stale_route();routes.cleanup()
            if f.direct_gateway!=cfg['gateway'] or int(f.direct_interface_index)!=cfg['interface_index']:raise RouteError('Finder selected another physical gateway/interface')
            cohort=resolve_cohort(f,cfg['servers'])
            for s,c in cohort:
                if args.mode in ('once','run') and s['expected_direct_peer']=='auto':
                    s['expected_direct_peer']=trusted_baseline([r for r in f.good if r.get('instance_id')==c['instance_id']])
            if args.mode in ('prepare','rollback'):
                for s,c in cohort:
                    with management(f,s,c) as client:
                        with client.open_sftp() as ftp:
                            root='/root/hy2-ab-stage';password_ssh.execute(client,'install -d -m 700 '+root)
                            ftp.put(str(BASE/'ab_server.py'),root+'/ab_server.py');ftp.chmod(root+'/ab_server.py',0o700)
                            payload=dict(ip=s['ip'],domain=s['domain'],email=cfg['acme_email'],password=c['hy_auth'])
                            with ftp.open(root+'/payload.json','w') as out:out.write(json.dumps(payload))
                            ftp.chmod(root+'/payload.json',0o600)
                        try:
                            cmd='python3 '+root+'/ab_server.py '+('rollback' if args.mode=='rollback' else root+'/payload.json')
                            rc,out=password_ssh.execute(client,cmd,timeout=900)
                            print(s['ip'],out.strip())
                            if rc:raise RuntimeError('Server preparation/rollback failed; inspect root-only backup')
                        finally:
                            with cleanup_mode():password_ssh.execute(client,'rm -f '+root+'/payload.json',timeout=10)
                finish_server_operation();return 0
            quiet_check(cfg)
            if args.mode=='run':
                gate=core.load_json(GATE,{})
                if not gate.get('ok') or gate.get('config_sha256')!=config_hash or time.time()-gate.get('time',0)>12*3600:
                    raise RuntimeError('Run -Once, inspect its report, then wait quiet period before -Run (gate valid 12h)')
            for s,_ in cohort:routes.add(s['ip'])
            run=Run(f,cfg,args.mode=='once')
            try:rows=run.execute(cohort)
            finally:
                from ab_report import summarize
                report=summarize(run.rows);core.save_json(run.dir/'summary.json',report)
                print(json.dumps(report,ensure_ascii=False,indent=2))
            if args.mode=='once':
                ok=all(any(r['ip']==s['ip'] and r['test_type']=='COLD' and r.get('direct_verified') for r in rows)
                       and any(r['ip']==s['ip'] and r['test_type']=='HOT' and r.get('direct_verified') and r.get('state')=='HOT_SESSION_ALIVE' for r in rows)
                       and any(r['ip']==s['ip'] and r['test_type']=='H3_CAMOUFLAGE' and r['ok'] for r in rows) for s,_ in cohort)
                core.save_json(GATE,dict(time=time.time(),ok=ok,config_sha256=config_hash,report=str(run.dir/'summary.json')))
                print('PREFLIGHT '+('PASS: review report; -Run is a separate manual action after quiet period' if ok else 'FAILED: no long run allowed'))
                return 0 if ok else 1
            return 0
        except KeyboardInterrupt:
            print('Stopped; HOT clients will not be restarted.');return 130
        finally:
            routes.cleanup();STOP_PATH.unlink(missing_ok=True)

if __name__=='__main__':raise SystemExit(main())
