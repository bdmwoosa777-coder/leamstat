param([switch]$Prepare,[switch]$Rollback,[switch]$Once,[switch]$Run,[switch]$Diagnose)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
. (Join-Path $PSScriptRoot 'common.ps1')
Assert-FinderAdmin
Assert-FinderKey
$selected = @($Prepare,$Rollback,$Once,$Run,$Diagnose | Where-Object { $_ })
if ($selected.Count -ne 1) { throw 'Choose exactly one: -Prepare, -Rollback, -Once, -Run, -Diagnose. Nothing starts by default.' }
$pythonPath = Get-FinderPython
$mode = if ($Prepare) { 'prepare' } elseif ($Rollback) { 'rollback' } elseif ($Once) { 'once' } elseif ($Diagnose) { 'diagnose' } else { 'run' }
if ($Once) {
    & $pythonPath -c 'import aioquic'
    if ($LASTEXITCODE -ne 0) { throw 'Install the H3 preflight dependency: python -m pip install aioquic==1.3.0 (use the same Python as Finder).' }
}
& $pythonPath (Join-Path $PSScriptRoot 'ab_client.py') --mode $mode
exit $LASTEXITCODE
