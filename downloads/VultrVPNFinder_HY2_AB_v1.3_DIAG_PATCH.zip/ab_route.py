"""Effective route checks shared with AUTO MONITOR v3; no bypass fallback."""
import ipaddress
import json
import finder as core

class RouteError(RuntimeError):
    pass

class ReadOnlyAPI:
    """Permit only GETs, including requests made internally by Finder helpers."""
    def __init__(self, api):
        self.api = api
    def __getattr__(self, name):
        if name not in ('list_instances', 'get_instance', 'get_instance_user_data'):
            raise RuntimeError('Monitor API operation forbidden: ' + name)
        return getattr(self.api, name)


def verify_route(f, ip):
    """Inspect the effective Windows route, not just Finder's current_ip flag."""
    ip = str(ipaddress.IPv4Address(ip))
    script = ("$ErrorActionPreference='Stop'; $r=Find-NetRoute -RemoteIPAddress '" + ip + "'; "
              "$a=@($r | Where-Object {$null -ne $_.NextHop -and $null -ne $_.DestinationPrefix}); "
              "if ($a.Count -ne 1) {throw 'Ambiguous effective route'}; "
              "$a[0] | Select-Object InterfaceIndex,NextHop,DestinationPrefix | ConvertTo-Json -Compress")
    cp = core.run(['powershell.exe', '-NoProfile', '-NonInteractive', '-Command', script], timeout=15)
    if cp.returncode:
        raise RouteError('Cannot determine effective Windows route')
    try:
        r = json.loads(core.decode_output(cp.stdout).strip())
        valid = (int(r['InterfaceIndex']) == int(f.direct_interface_index)
                 and r['NextHop'] == f.direct_gateway and r['DestinationPrefix'] == ip + '/32')
    except (ValueError, TypeError, KeyError):
        raise RouteError('Invalid effective route response') from None
    if not valid:
        raise RouteError('Effective route differs from configured direct /32 route')
    return dict(interface_index=int(r['InterfaceIndex']), gateway=r['NextHop'], prefix=r['DestinationPrefix'])


