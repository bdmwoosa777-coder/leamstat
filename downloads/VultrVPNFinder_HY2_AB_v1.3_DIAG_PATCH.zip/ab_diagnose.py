"""Read-only server checks over explicit SSH/SOCKS; no HY2 client or server changes."""
import json
from pathlib import Path
import zipfile
import finder as core
import password_ssh

REMOTE = r'''
import json,subprocess

def run(args,timeout=10):
    try:
        r=subprocess.run(args,capture_output=True,timeout=timeout)
        return {'exit':r.returncode,'stdout':r.stdout.decode(errors='replace')[-9000:],
                'stderr':r.stderr.decode(errors='replace')[-1500:]}
    except Exception as e:return {'error':type(e).__name__}
checks={
 'service':run(['systemctl','show','hy2-ab.service','-p','ActiveState','-p','SubState','-p','ExecMainPID']),
 'ipv4_routes':run(['ip','-4','route']),
 'ipv6_routes':run(['ip','-6','route']),
 'dns_gstatic':run(['getent','ahosts','www.gstatic.com'],6),
 'dns_example':run(['getent','ahosts','example.com'],6),
 'listeners':run(['ss','-lnut']),
}
for label,url in [('gstatic','https://www.gstatic.com/generate_204'),('example','https://example.com/')]:
    for family in ('4','6'):
        checks[label+'_ipv'+family]=run(['curl','--disable','--noproxy','*','-'+family,
            '--connect-timeout','3','--max-time','6','-sS','-o','/dev/null','-w',
            '%{http_code}|%{time_total}|%{remote_ip}',url],8)
raw=run(['journalctl','-u','hy2-ab.service','-n','150','--no-pager','-o','cat'])
events=[]
for line in raw.get('stdout','').splitlines():
    try:
        r=json.loads(line)
        events.append({k:(v if k!='id' or v in ('hot','cold443','cold8443') else '[other actor]')
                       for k,v in r.items() if k in ('level','time','msg','addr','id','error','reqAddr')})
    except ValueError:pass
checks['server_events']=events
checks['journal_exit']=raw.get('exit')
print(json.dumps(checks))
'''

def collect(f,cohort,management):
    reports=[]
    for server,candidate in cohort:
        print('Read-only server diagnosis via SSH control: '+server['ip'],flush=True)
        try:
            with management(f,server,candidate) as client:
                rc,out=password_ssh.execute(client,core.remote_python_command(REMOTE),timeout=110)
                if rc:raise RuntimeError('Remote diagnosis did not finish')
                result=json.loads(out)
            reports.append({'ip':server['ip'],'checks':result})
        except Exception as e:
            reports.append({'ip':server['ip'],'error':type(e).__name__})
    report={'time':core.now_iso(),'read_only':True,'hy2_clients_started':0,'servers':reports}
    target=core.BASE/'HY2_AB_SERVER_DIAG.zip'
    with zipfile.ZipFile(target,'w',zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('server_diagnosis.json',json.dumps(report,ensure_ascii=False,indent=2))
    print('Saved '+str(target)+'; HY2 quiet period was not reset',flush=True)
    return report
