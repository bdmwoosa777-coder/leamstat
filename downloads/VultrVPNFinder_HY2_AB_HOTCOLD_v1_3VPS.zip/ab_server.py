"""Run on the selected Linux VPS only when user invokes -Prepare. Root required."""
import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
import urllib.request
ROOT=Path('/var/lib/hy2-ab')
XRAY=Path('/etc/vpnfinder/xray.json')
UNIT=Path('/etc/systemd/system/hy2-ab.service')
BINARY=Path('/usr/local/lib/hy2-ab/hysteria')
DIGEST='907ba8c9693edb104b20582681fb7dc15639d5b64a9cbb616a7b539190a86691'

def run(args, **kw):
    try:
        cp=subprocess.run(args,check=False,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=kw.pop('timeout',60),**kw)
        if ROOT.exists():
            log=ROOT/'installer.log'
            with log.open('ab') as out:out.write(('COMMAND '+Path(args[0]).name+'\n').encode()+cp.stdout+b'\n')
            log.chmod(0o600)
        cp.check_returncode()
        return cp.stdout
    except subprocess.TimeoutExpired:
        raise RuntimeError('Installer command timed out; inspect root-only installer.log') from None

def xray_without_hy2(config):
    new=copy.deepcopy(config)
    removed=[i for i in new['inbounds'] if i.get('tag')=='hy2-in']
    if len(removed)!=1 or int(removed[0]['port'])!=443:
        raise RuntimeError('Unknown Xray HY2 inbound; refusing to modify')
    new['inbounds']=[i for i in new['inbounds'] if i.get('tag')!='hy2-in']
    if not any(i.get('protocol')=='vless' and int(i['port'])==8443 for i in new['inbounds']):
        raise RuntimeError('Expected existing VLESS TCP/8443')
    return new

def firewall_script():
    return '''#!/bin/sh
set -eu
case "$1" in
up)
 nft -f - <<'RULES'
add table ip hy2_ab
add chain ip hy2_ab prerouting { type nat hook prerouting priority dstnat; policy accept; }
add rule ip hy2_ab prerouting udp dport 8443 redirect to :443
RULES
 ;;
down) nft delete table ip hy2_ab 2>/dev/null || true ;;
esac
'''

def server_config(domain, password):
    cert='/etc/letsencrypt/live/'+domain
    return {'listen':'0.0.0.0:443','tls':{'cert':cert+'/fullchain.pem','key':cert+'/privkey.pem'},
            'auth':{'type':'userpass','userpass':{u:password for u in ('hot','cold443','cold8443')}},
            'masquerade':{'type':'file','file':{'dir':str(ROOT/'www')},
                          'listenHTTP':':80','listenHTTPS':':443'}}

def rollback():
    backup=ROOT/'backup'
    if not (backup/'xray.json').exists():raise RuntimeError('No backup')
    subprocess.run(['systemctl','disable','--now','hy2-ab.service'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    subprocess.run(['nft','delete','table','ip','hy2_ab'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    shutil.copy2(backup/'xray.json',XRAY)
    run(['systemctl','restart','vpnfinder-xray.service'])
    metadata=json.loads((backup/'metadata.json').read_text())
    if metadata['diag_active']:run(['systemctl','start','vpnfinder-diag.service'])
    # Remove only explicitly added firewall rules.
    for rule in metadata.get('ufw_added',[]):
        run(['ufw','--force','delete','allow',rule])
    hook=Path('/etc/letsencrypt/renewal-hooks/deploy/hy2-ab')
    hook.unlink(missing_ok=True)
    marker=backup/'new_certificate_domain.txt'
    if marker.exists() and shutil.which('certbot'):
        domain=marker.read_text().strip()
        if (Path('/etc/letsencrypt/renewal')/(domain+'.conf')).exists():
            run(['certbot','delete','--non-interactive','--cert-name',domain])
        marker.unlink()
    UNIT.unlink(missing_ok=True);run(['systemctl','daemon-reload'])
    print(json.dumps({'rollback':True,'backup':str(backup)}))

def prepare(data):
    domain=data['domain']; ip=data['ip']; email=data['email']; password=data['password']
    if os.geteuid()!=0:raise RuntimeError('Root required')
    if (ROOT/'backup').exists():raise RuntimeError('Backup already exists; inspect/rollback before preparing again')
    if set(socket.gethostbyname_ex(domain)[2])!={ip}:raise RuntimeError('DNS A must point only to this VPS')
    if shutil.which('nft') and subprocess.run(['nft','list','table','ip','hy2_ab'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:raise RuntimeError('Existing hy2_ab table')
    try:
        if socket.getaddrinfo(domain,None,socket.AF_INET6):raise RuntimeError('Remove AAAA record for this IPv4-only experiment')
    except socket.gaierror:pass
    if (Path('/etc/letsencrypt/renewal')/(domain+'.conf')).exists():raise RuntimeError('Existing certificate: refuse to alter its renewal settings')
    if UNIT.exists() or Path('/etc/letsencrypt/renewal-hooks/deploy/hy2-ab').exists():raise RuntimeError('Existing experiment service/hook')
    old=json.loads(XRAY.read_text());new=xray_without_hy2(old)
    backup=ROOT/'backup';backup.mkdir(parents=True,mode=0o700);os.chmod(ROOT,0o700)
    shutil.copy2(XRAY,backup/'xray.json')
    (backup/'listeners.txt').write_bytes(run(['ss','-lnut']))
    if shutil.which('nft'):(backup/'nft.txt').write_bytes(run(['nft','list','ruleset']))
    meta={'diag_active':subprocess.run(['systemctl','is-active','--quiet','vpnfinder-diag.service']).returncode==0,'ufw_added':[]}
    (backup/'metadata.json').write_text(json.dumps(meta))
    try:
        run(['apt-get','update'],timeout=180)
        run(['apt-get','install','-y','certbot','nftables'],timeout=300)
        if shutil.which('ufw'):
            status=run(['ufw','status']).decode()
            if 'Status: active' in status:
                for rule in ('80/tcp','443/tcp','443/udp'):
                    if not any(line.startswith(rule+' ') and 'ALLOW' in line and '(v6)' not in line for line in status.splitlines()):
                        run(['ufw','allow',rule,'comment','hy2-ab-experiment'])
                        meta['ufw_added'].append(rule)
                        (backup/'metadata.json').write_text(json.dumps(meta))
        BINARY.parent.mkdir(parents=True,exist_ok=True)
        content=None
        for attempt in range(3):
            try:
                with urllib.request.urlopen('https://github.com/apernet/hysteria/releases/download/app/v2.13.0/hysteria-linux-amd64',timeout=45) as r:content=r.read(100_000_000)
                if hashlib.sha256(content).hexdigest()!=DIGEST:raise RuntimeError('Official binary digest mismatch')
                break
            except Exception:
                if attempt==2:raise
                time.sleep(2)
        BINARY.write_bytes(content);BINARY.chmod(0o755)
        if meta['diag_active']:run(['systemctl','stop','vpnfinder-diag.service'])
        # IPv4-only DNS is required; remove stale AAAA records before running.
        (backup/'new_certificate_domain.txt').write_text(domain)
        run(['certbot','certonly','--standalone','--non-interactive','--agree-tos','--email',email,'-d',domain,'--cert-name',domain],timeout=240)
        www=ROOT/'www';www.mkdir(exist_ok=True)
        (www/'index.html').write_text('<!doctype html><html><head><title>Network status</title></head><body><h1>Network status</h1><p>Service is available.</p></body></html>')
        (ROOT/'server.json').write_text(json.dumps(server_config(domain,password)));(ROOT/'server.json').chmod(0o600)
        fw=ROOT/'firewall.sh';fw.write_text(firewall_script());fw.chmod(0o700)
        UNIT.write_text('[Unit]\nAfter=network-online.target\n[Service]\nType=simple\nUMask=0077\n'
            'ExecStartPre=/var/lib/hy2-ab/firewall.sh up\n'
            'ExecStart=/usr/local/lib/hy2-ab/hysteria --disable-update-check --log-format json server -c /var/lib/hy2-ab/server.json\n'
            'ExecStopPost=/var/lib/hy2-ab/firewall.sh down\nRestart=no\n[Install]\nWantedBy=multi-user.target\n')
        # Xray retains every field of each VLESS inbound and every other configuration field.
        XRAY.write_text(json.dumps(new));run(['/usr/local/lib/vpnfinder-xray/xray','run','-test','-config',str(XRAY)])
        run(['systemctl','restart','vpnfinder-xray.service']);run(['systemctl','is-active','--quiet','vpnfinder-xray.service'])
        run(['systemctl','daemon-reload']);run(['systemctl','enable','--now','hy2-ab.service'])
        time.sleep(2);run(['systemctl','is-active','--quiet','hy2-ab.service'])
        # Check listener presence without creating any HY2 flow.
        sockets=run(['ss','-lnut']).decode()
        for port in (':443',':8443'):
            if port not in sockets:raise RuntimeError('Missing expected listener')
        # Certbot future renewal must use webroot served by HY2, avoiding a port-80 conflict.
        renewal=Path('/etc/letsencrypt/renewal')/(domain+'.conf')
        text=renewal.read_text().replace('authenticator = standalone','authenticator = webroot')
        text+='\n[[webroot_map]]\n'+domain+' = '+str(www)+'\n'
        renewal.write_text(text)
        (backup/'new_certificate_domain.txt').write_text(domain)
        hook=Path('/etc/letsencrypt/renewal-hooks/deploy/hy2-ab')
        hook.parent.mkdir(parents=True,exist_ok=True);hook.write_text('#!/bin/sh\nsystemctl try-restart hy2-ab.service\n');hook.chmod(0o755)
        print(json.dumps({'prepared':True,'backup':str(backup),'xray_vless_unchanged':True,'backend_sha256':DIGEST}))
    except BaseException:
        rollback()
        raise

if __name__=='__main__':
    try:
        if len(sys.argv)>1 and sys.argv[1]=='rollback':rollback()
        else:prepare(json.load(open(sys.argv[1])))
    except Exception as e:
        # Never emit payloads / secrets in error messages.
        detail=str(e) if isinstance(e,RuntimeError) else 'Inspect /var/lib/hy2-ab/installer.log on the VPS'
        print(json.dumps({'error':type(e).__name__,'detail':detail}),flush=True);sys.exit(1)
