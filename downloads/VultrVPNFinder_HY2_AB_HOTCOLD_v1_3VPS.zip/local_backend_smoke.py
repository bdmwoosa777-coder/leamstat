"""Loopback only: official HY2 backend, verified local TLS, H3 and one reused client."""
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time
from unittest.mock import patch
import ab_server
import ab_h3_probe
import ab_client

def port():
    with socket.socket() as s:s.bind(('127.0.0.1',0));return s.getsockname()[1]

def main():
    binary='/workspace/work/test-tools/hysteria';processes=[]
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp);cert=root/'cert.pem';key=root/'key.pem'
        subprocess.run(['openssl','req','-x509','-newkey','rsa:2048','-nodes','-keyout',str(key),'-out',str(cert),'-days','1','-subj','/CN=localhost','-addext','subjectAltName=DNS:localhost'],check=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        mainport=port();httpport=port();socks=port();www=root/'www';www.mkdir();(www/'index.html').write_text('<html><body>Local test</body></html>')
        cfg=ab_server.server_config('localhost','local-test-only')
        cfg['listen']='127.0.0.1:'+str(mainport);cfg['tls']={'cert':str(cert),'key':str(key)}
        cfg['masquerade'].update(file={'dir':str(www)},listenHTTP='127.0.0.1:'+str(httpport),listenHTTPS='127.0.0.1:'+str(mainport))
        path=root/'server.json';path.write_text(json.dumps(cfg))
        with (root/'server.log').open('wb') as serverlog,(root/'client.log').open('wb') as clientlog:
            try:
                server=subprocess.Popen([binary,'--disable-update-check','--log-format','json','server','-c',str(path)],stdout=serverlog,stderr=subprocess.STDOUT);processes.append(server);time.sleep(.5)
                from aioquic.quic.configuration import QuicConfiguration
                def trusted_local_config(*args,**kwargs):
                    config=QuicConfiguration(*args,**kwargs);config.load_verify_locations(cafile=str(cert));return config
                with patch('aioquic.quic.configuration.QuicConfiguration',side_effect=trusted_local_config):
                    h3=ab_h3_probe.check('127.0.0.1',mainport,'localhost')
                assert h3['http_code']==200 and h3['body_bytes']>0,h3
                cc={'server':'127.0.0.1:'+str(mainport),'auth':'hot:local-test-only','tls':{'sni':'localhost','insecure':False,'ca':str(cert)},'socks5':{'listen':'127.0.0.1:'+str(socks)}}
                cp=root/'client.json';cp.write_text(json.dumps(cc))
                client=subprocess.Popen([binary,'--disable-update-check','--log-format','json','client','-c',str(cp)],stdout=clientlog,stderr=subprocess.STDOUT);processes.append(client)
                time.sleep(.5)
                for _ in range(3):
                    r=subprocess.run(['curl','--disable','--noproxy','','--socks5-hostname','127.0.0.1:'+str(socks),'--max-time','5','-fsS','http://127.0.0.1:'+str(httpport)+'/'],capture_output=True)
                    assert r.returncode==0 and b'Local test' in r.stdout,r.stderr
                count=ab_client.log_connection_count((root/'client.log').read_text())
                ev=ab_client.events((root/'server.log').read_text())
                assert count==1,count
                assert any(e['actor']=='hot' and e['peer']=='127.0.0.1' for e in ev),ev
                print(json.dumps({'loopback_only':True,'http3_camouflage':h3,'hot_http_requests':3,'same_process_pid':client.pid,'client_connection_count':count,'server_peer_verified':True}))
            finally:
                for p in reversed(processes):
                    p.terminate()
                    try:p.wait(3)
                    except subprocess.TimeoutExpired:p.kill();p.wait(3)

if __name__=='__main__':main()
