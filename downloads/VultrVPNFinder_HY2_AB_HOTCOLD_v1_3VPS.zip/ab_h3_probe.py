"""Unauthenticated real HTTP/3 request; TLS verifies the configured domain."""
import asyncio
import ssl
async def probe(ip, port, domain):
    from aioquic.asyncio import connect, QuicConnectionProtocol
    from aioquic.h3.connection import H3Connection, H3_ALPN
    from aioquic.h3.events import HeadersReceived, DataReceived
    from aioquic.quic.configuration import QuicConfiguration
    class Client(QuicConnectionProtocol):
        def __init__(self,*a,**kw):
            super().__init__(*a,**kw);self.h3=H3Connection(self._quic);self.done=asyncio.get_running_loop().create_future();self.code=0;self.size=0
        def quic_event_received(self,event):
            for e in self.h3.handle_event(event):
                if isinstance(e,HeadersReceived):
                    self.code=int(dict(e.headers).get(b':status',b'0'))
                if isinstance(e,DataReceived):self.size+=len(e.data)
                if getattr(e,'stream_ended',False) and not self.done.done():self.done.set_result({'http_code':self.code,'body_bytes':self.size})
        def request(self):
            stream=self._quic.get_next_available_stream_id()
            self.h3.send_headers(stream,[(b':method',b'GET'),(b':scheme',b'https'),(b':authority',domain.encode()),(b':path',b'/')],end_stream=True);self.transmit()
    cfg=QuicConfiguration(is_client=True,alpn_protocols=H3_ALPN,server_name=domain,verify_mode=ssl.CERT_REQUIRED)
    async with connect(ip,port,configuration=cfg,create_protocol=Client) as client:
        client.request();return await asyncio.wait_for(client.done,10)

def check(ip,port,domain):
    async def bounded():return await asyncio.wait_for(probe(ip,port,domain),15)
    return asyncio.run(bounded())
