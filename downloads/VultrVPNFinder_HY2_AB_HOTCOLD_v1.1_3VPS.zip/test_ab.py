import copy
import contextlib
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest.mock import Mock,patch
import ab_client as a
import ab_server as s
from ab_report import summarize

class Checks(unittest.TestCase):
    def test_two_owned_routes_can_coexist(self):
        f=Mock(direct_gateway='192.168.0.1',direct_interface_index=8);f.query_host_routes.return_value=[]
        with tempfile.TemporaryDirectory() as d,patch.object(a,'ROUTES',Path(d)/'r.json'),patch.object(a,'verify_route'),patch.object(a.core,'run',return_value=types.SimpleNamespace(returncode=0)) as run:
            r=a.Routes(f);r.add('192.0.2.1');r.add('192.0.2.2')
            self.assertEqual(len(json.loads(a.ROUTES.read_text())),2)
            self.assertTrue(all(c.args[0][1]=='ADD' for c in run.call_args_list))
            r.cleanup();self.assertFalse(a.ROUTES.exists())
    def test_existing_route_never_replaced(self):
        f=Mock();f.query_host_routes.return_value=[{'index':8,'gateway':'192.168.0.1'}]
        with patch.object(a.core,'run') as run:
            with self.assertRaises(a.RouteError):a.Routes(f).add('192.0.2.1')
            run.assert_not_called()
    def test_cleanup_failure_preserves_metadata(self):
        f=Mock();f.query_host_routes.return_value=[{'index':8,'gateway':'192.168.0.1'}]
        with tempfile.TemporaryDirectory() as d,patch.object(a,'ROUTES',Path(d)/'r.json'),patch.object(a.core,'run'):
            a.core.save_json(a.ROUTES,[{'ip':'192.0.2.1','index':8,'gateway':'192.168.0.1'}])
            with self.assertRaises(a.RouteError):a.Routes(f).cleanup()
            self.assertTrue(a.ROUTES.exists())
    def test_wrong_effective_interface_rejected(self):
        f=types.SimpleNamespace(direct_gateway='192.168.0.1',direct_interface_index=8)
        out=b'{"InterfaceIndex":40,"NextHop":"192.168.0.1","DestinationPrefix":"192.0.2.1/32"}'
        with patch.object(a.core,'run',return_value=types.SimpleNamespace(returncode=0,stdout=out)):
            with self.assertRaises(a.RouteError):a.verify_route(f,'192.0.2.1')
    def test_vless_configuration_unchanged(self):
        cfg={'inbounds':[{'tag':'hy2-in','port':443,'protocol':'hysteria'},{'tag':'vless-in','protocol':'vless','port':8443,'settings':{'x':'y'}}],'outbounds':[{'protocol':'freedom'}]}
        before=copy.deepcopy(cfg);after=s.xray_without_hy2(cfg)
        self.assertEqual(cfg,before);self.assertEqual(after['inbounds'],[before['inbounds'][1]])
        self.assertEqual(after['outbounds'],before['outbounds'])
    def test_unknown_xray_shape_rejected(self):
        with self.assertRaises(RuntimeError):s.xray_without_hy2({'inbounds':[]})
    def test_both_ports_share_one_backend(self):
        cfg=s.server_config('real.example.org','secret')
        self.assertEqual(cfg['listen'],'0.0.0.0:443')
        fw=s.firewall_script();self.assertIn('udp dport 8443 redirect to :443',fw);self.assertNotIn('tcp dport 8443',fw)
        self.assertNotIn('obfs',cfg);self.assertNotIn('acme',cfg)
        self.assertEqual(cfg['masquerade']['type'],'file')
    def test_server_evidence_omits_secret_fields(self):
        raw=json.dumps({'msg':'client connected','addr':'192.0.2.1:12345','id':'hot','password':'secret'})
        row=a.events(raw)[0];self.assertEqual(row['peer'],'192.0.2.1');self.assertNotIn('password',row)
    def test_hot_reconnect_not_continuity(self):
        self.assertEqual(a.hot_state(1,True,True),'HOT_SESSION_ALIVE')
        self.assertEqual(a.hot_state(2,True,True),'HOT_RECONNECTED')
        self.assertEqual(a.hot_state(1,False,True),'HOT_SESSION_BROKEN')
        self.assertEqual(a.hot_state(1,True,True,True),'HOT_SESSION_BROKEN')
    def test_counter_uses_reconnect_count(self):
        text='\n'.join(json.dumps({'msg':'connected to server','count':i}) for i in (1,2))
        self.assertEqual(a.log_connection_count(text),2)
    def test_hot_http_requests_never_start_process(self):
        obj=a.Session.__new__(a.Session);obj.f=Mock();obj.s={'ip':'192.0.2.1'};obj.closed=False;obj.ready=True;obj.proc=Mock();obj.proc.poll.return_value=None;obj.socks=123
        obj.f.curl_proxy_tests.return_value={'results':[{'ok':True,'code':204}]}
        with patch.object(a,'verify_route'),patch.object(a.subprocess,'Popen') as popen:
            obj.request();obj.request();popen.assert_not_called();self.assertEqual(obj.f.curl_proxy_tests.call_count,2)
    def test_closed_hot_is_never_restarted(self):
        obj=a.Session.__new__(a.Session);obj.f=Mock();obj.s={'ip':'192.0.2.1'};obj.closed=True
        with patch.object(a,'verify_route'),patch.object(a.subprocess,'Popen') as popen:
            self.assertFalse(obj.request()['ok']);popen.assert_not_called()
    def test_budget_blocks_new_process(self):
        obj=a.Run.__new__(a.Run);obj.cfg={'max_fresh_hy2':2};obj.starts=2;obj.reconnects=0
        with self.assertRaises(RuntimeError):obj.spend()
    def test_report_cold_fail_hot_still_ok(self):
        base={'ip':'192.0.2.1','cycle':1,'port':443,'direct_verified':True,'pid':1,'session_identifier':'original'}
        cold=dict(base,timestamp='2026-11-08T12:00:00+03:00',test_type='COLD',ok=False)
        hot=dict(base,timestamp='2026-11-08T12:00:30+03:00',test_type='HOT',ok=True,state='HOT_SESSION_ALIVE')
        report=summarize([cold,hot])['servers']['192.0.2.1'];self.assertEqual(len(report['cold_fail_then_verified_hot_ok']),1)
        hot['state']='HOT_RECONNECTED';report=summarize([cold,hot])['servers']['192.0.2.1'];self.assertFalse(report['cold_fail_then_verified_hot_ok'])
    def test_local_quiet_period_enforced(self):
        with patch.object(a.core,'load_json',return_value={'time':100}),patch.object(a.time,'time',return_value=200):
            with self.assertRaises(RuntimeError):a.quiet_check({'quiet_minutes':120})
    def test_blank_domains_prevent_run_but_allow_rollback(self):
        cfg=json.loads((Path(a.__file__).parent/'hy2_ab_config.json').read_text())
        cfg['acme_email']='test@example.org'
        for server in cfg['servers']:server['domain']=''
        with patch.object(a.core,'load_json',return_value=cfg):
            with self.assertRaises(ValueError):a.load_config('run')
            a.load_config('rollback')
    def test_baseline_requires_trusted_distinct_source(self):
        rec={'paired_hy2':{'assessment':{'control_verified':True,'direct_baseline':'192.0.2.1','proxy_egress':'198.51.100.1'}}}
        self.assertEqual(a.trusted_baseline([rec]),'192.0.2.1')
        rec['paired_hy2']['assessment']['control_verified']=False
        with self.assertRaises(RuntimeError):a.trusted_baseline([rec])
    def test_constructor_starts_exactly_one_process_and_cleans(self):
        f=Mock();f.free_port.return_value=12345;f.wait_client.return_value=True;f.hy_exe=Path('hysteria.exe')
        s={'ip':'192.0.2.1','domain':'real.example.org'}
        with tempfile.TemporaryDirectory() as d,patch.object(a,'verify_route'),patch.object(a.subprocess,'Popen') as popen:
            run=Mock();run.dir=Path(d)
            obj=a.Session(f,s,{'hy_auth':'test-only'},443,'hot',run)
            text=json.loads((Path(obj.temp.name)/'client.json').read_text())
            self.assertFalse(text['tls']['insecure']);self.assertEqual(text['tls']['sni'],'real.example.org')
            obj.close();obj.close();popen.assert_called_once();f.stop_client.assert_called_once();self.assertFalse(Path(obj.temp.name).exists())
    def test_failed_client_start_is_closed_not_retried(self):
        f=Mock();f.free_port.return_value=12345;f.wait_client.return_value=False;f.hy_exe=Path('hysteria.exe')
        with tempfile.TemporaryDirectory() as d,patch.object(a,'verify_route'),patch.object(a.subprocess,'Popen') as popen:
            run=Mock();run.dir=Path(d)
            obj=a.Session(f,{'ip':'192.0.2.1','domain':'real.example.org'},{'hy_auth':'test-only'},443,'hot',run)
            self.assertTrue(obj.closed);popen.assert_called_once();f.stop_client.assert_called_once()
    def nft_fixture(self):
        return {'nftables':[
            {'chain':{'family':'ip','table':'hy2_ab','name':'prerouting','type':'nat','hook':'prerouting','prio':-100,'policy':'accept'}},
            {'rule':{'family':'ip','table':'hy2_ab','chain':'prerouting','expr':[
                {'match':{'op':'==','left':{'payload':{'protocol':'udp','field':'dport'}},'right':8443}},
                {'redirect':{'port':443}}]}}]}
    def test_prepare_rejects_missing_redirect_despite_vless_tcp8443(self):
        udp=b'UNCONN 0 0 0.0.0.0:443 0.0.0.0:*\n'
        tcp=b'LISTEN 0 4096 *:8443 *:*\n'
        nft=self.nft_fixture();nft['nftables'].pop()
        with patch.object(s,'run',side_effect=[udp,tcp,json.dumps(nft).encode()]):
            with self.assertRaises(RuntimeError):s.check_prepared_network()
    def test_correct_redirect_passes_without_udp8443_socket(self):
        result=s.validate_network('UNCONN 0 0 0.0.0.0:443 0.0.0.0:*','LISTEN 0 4096 *:8443 *:*',self.nft_fixture())
        self.assertTrue(result['udp8443_redirect_to_443'])
    def test_tcp443_does_not_substitute_udp_listener(self):
        with self.assertRaises(RuntimeError):s.validate_network('', 'LISTEN 0 4096 *:443 *:*\nLISTEN 0 4096 *:8443 *:*', self.nft_fixture())
    def test_redirect_wrong_protocol_or_port_rejected(self):
        for what in ('protocol','source_port','target_port','hook'):
            nft=self.nft_fixture();rule=nft['nftables'][1]['rule'];chain=nft['nftables'][0]['chain']
            if what=='protocol':rule['expr'][0]['match']['left']['payload']['protocol']='tcp'
            if what=='source_port':rule['expr'][0]['match']['right']=8444
            if what=='target_port':rule['expr'][1]['redirect']['port']=444
            if what=='hook':chain['hook']='output'
            with self.subTest(what=what),self.assertRaises(RuntimeError):s.validate_network('UNCONN 0 0 0.0.0.0:443 0.0.0.0:*','LISTEN 0 4096 *:8443 *:*',nft)
    def test_other_rule_cannot_hide_in_experiment_table(self):
        nft=self.nft_fixture();nft['nftables'].append(copy.deepcopy(nft['nftables'][1]))
        with self.assertRaises(RuntimeError):s.validate_network('UNCONN 0 0 0.0.0.0:443 0.0.0.0:*','LISTEN 0 4096 *:8443 *:*',nft)
    def test_port_substring_is_not_listener_evidence(self):
        with self.assertRaises(RuntimeError):s.validate_network('UNCONN 0 0 0.0.0.0:4430 0.0.0.0:*','LISTEN 0 4096 *:8443 *:*',self.nft_fixture())

if __name__=='__main__':unittest.main()
