from __future__ import annotations

import base64
import argparse
import contextlib
import csv
import ctypes
import datetime as dt
import json
import hashlib
import os
import re
import secrets
import shlex
import shutil
import socket
import subprocess
import sys
import tempfile
import time
import tarfile
import io
import ipaddress
import urllib.error
import urllib.parse
import urllib.request
import uuid
import zipfile
from pathlib import Path

from runtime_support import RuntimeLock, STOP_PATH, check_stop, pause
from socks_relay import SocksRelay, socks_connect
import password_ssh

BASE = Path(__file__).resolve().parent
CONFIG_PATH = BASE / "config.json"
LOG_DIR = BASE / "logs"
BIN_DIR = BASE / "bin"
STATE_PATH = BASE / "state.json"
CURRENT_IP_PATH = BASE / "current_ip.txt"
ROUTE_PATH = BASE / "direct_route.json"
PID_PATH = BASE / "finder.pid"
GOOD_PATH = LOG_DIR / "good_servers.json"
BAD_PATH = LOG_DIR / "bad_servers.json"
CSV_PATH = LOG_DIR / "all_candidates_v211.csv"
LOG_PATH = LOG_DIR / "finder.log"
API_BASE = "https://api.vultr.com/v2"
LABEL_PREFIX = "vpnfinder-"
CREATE_NO_WINDOW = 0x08000000 if os.name == "nt" else 0
VERSION = "2.11"


def remote_python_command(source):
    encoded = base64.b64encode(source.encode("utf-8")).decode("ascii")
    return "python3 -c " + shlex.quote("import base64;exec(base64.b64decode(" + repr(encoded) + "))")


def file_sha256(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def now_iso() -> str:
    return dt.datetime.now().astimezone().isoformat(timespec="seconds")


def log(msg: str) -> None:
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    line = f"[{now_iso()}] {msg}"
    with LOG_PATH.open("a", encoding="utf-8") as f:
        f.write(line + "\n")
    print(line, flush=True)


def download_file(urls, dest: Path, min_bytes: int = 1024 * 1024, expected_sha256=None) -> None:
    """Download from the first working URL, with a browser-like UA and basic size validation."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    last_error = None
    for url in urls:
        check_stop()
        tmp = dest.with_suffix(dest.suffix + ".part")
        try:
            try:
                tmp.unlink()
            except FileNotFoundError:
                pass
            log(f"Downloading: {url}")
            req = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) VPNFinder/2.11",
                    "Accept": "*/*",
                },
            )
            with urllib.request.urlopen(req, timeout=90) as r, tmp.open("wb") as f:
                shutil.copyfileobj(r, f)
            size = tmp.stat().st_size
            if size < min_bytes:
                raise RuntimeError(f"downloaded file is unexpectedly small: {size} bytes")
            if expected_sha256 and file_sha256(tmp) != expected_sha256:
                raise RuntimeError(f"SHA256 mismatch for {dest.name}")
            tmp.replace(dest)
            log(f"Downloaded {dest.name}: {size / 1024 / 1024:.1f} MiB")
            return
        except Exception as e:
            last_error = e
            log(f"Download failed from {url}: {type(e).__name__}: {e}")
            try:
                tmp.unlink()
            except FileNotFoundError:
                pass
    raise RuntimeError(f"All download sources failed for {dest.name}: {last_error}")


def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8-sig"))
    except FileNotFoundError:
        return default


def save_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def is_admin() -> bool:
    if os.name != "nt":
        return os.geteuid() == 0
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def run(cmd, timeout=None, cwd=None, capture=True):
    kwargs = {
        "cwd": cwd,
        "timeout": timeout,
        "creationflags": CREATE_NO_WINDOW,
    }
    if capture:
        kwargs.update(stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return subprocess.run(cmd, **kwargs)


def decode_output(data: bytes) -> str:
    if not data:
        return ""
    for enc in ("utf-8", "cp866", "cp1251", "latin1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            pass
    return data.decode("utf-8", errors="replace")


class APIError(RuntimeError):
    def __init__(self, status, detail):
        self.status = status
        super().__init__(f"Vultr API HTTP {status}: {detail[:1000]}")


class AmbiguousCreateError(RuntimeError):
    """A POST might have reached Vultr; repeating it could create a second VPS."""


class VultrAPI:
    def __init__(self, key: str):
        self.key = key

    def request(self, method: str, path: str, payload=None, retries: int = 6):
        url = API_BASE + path
        body = None
        headers = {
            "Authorization": f"Bearer {self.key}",
            "Accept": "application/json",
            "User-Agent": "VultrVPNFinder/2.11",
        }
        if payload is not None:
            body = json.dumps(payload).encode("utf-8")
            headers["Content-Type"] = "application/json"
        delay = 2
        for attempt in range(retries):
            check_stop()
            req = urllib.request.Request(url, data=body, headers=headers, method=method)
            try:
                with urllib.request.urlopen(req, timeout=30) as r:
                    raw = r.read()
                    if not raw:
                        return None
                    return json.loads(raw.decode("utf-8"))
            except urllib.error.HTTPError as e:
                raw = e.read().decode("utf-8", errors="replace")
                retryable = e.code == 429 or (method in ("GET", "DELETE", "PATCH") and e.code in (500, 502, 503, 504))
                if retryable and attempt < retries - 1:
                    log(f"API {e.code}; retry in {delay}s")
                    pause(delay)
                    delay = min(delay * 2, 60)
                    continue
                if method == "POST" and e.code >= 500:
                    raise AmbiguousCreateError("Vultr returned a server error for POST; request will not be repeated") from None
                raise APIError(e.code, raw)
            except (urllib.error.URLError, TimeoutError, ConnectionError, OSError) as e:
                if method == "POST":
                    raise AmbiguousCreateError("Network failed during POST; request will not be repeated") from e
                if attempt < retries - 1:
                    log(f"API network error {e}; retry in {delay}s")
                    pause(delay)
                    delay = min(delay * 2, 60)
                    continue
                raise
        raise RuntimeError("API request failed")

    def list_collection(self, path, key):
        result = []
        seen = set()
        while path:
            if path in seen:
                raise RuntimeError("Vultr API pagination loop")
            seen.add(path)
            data = self.request("GET", path)
            result.extend(data[key])
            next_url = data.get("meta", {}).get("links", {}).get("next")
            if not next_url:
                break
            if next_url.startswith(API_BASE + "/"):
                path = next_url[len(API_BASE):]
            elif next_url.startswith("/v2/"):
                path = next_url[3:]
            else:
                raise RuntimeError("Unexpected Vultr pagination URL")
        return result

    def list_regions(self):
        return self.list_collection("/regions?per_page=500", "regions")

    def list_plans(self):
        return self.list_collection("/plans?per_page=500", "plans")

    def list_os(self):
        return self.list_collection("/os?per_page=500", "os")

    def list_ssh_keys(self):
        return self.list_collection("/ssh-keys?per_page=500", "ssh_keys")

    def list_instances(self):
        return self.list_collection("/instances?per_page=500", "instances")

    def create_ssh_key(self, payload):
        return self.request("POST", "/ssh-keys", payload)["ssh_key"]

    def create_instance(self, payload):
        return self.request("POST", "/instances", payload)["instance"]

    def get_instance(self, instance_id: str):
        return self.request("GET", f"/instances/{instance_id}")["instance"]

    def get_instance_user_data(self, instance_id: str):
        data = self.request("GET", f"/instances/{instance_id}/user-data")
        if not data:
            return None
        ud = data.get("user_data") or {}
        return ud.get("data")

    def patch_instance(self, instance_id: str, payload):
        return self.request("PATCH", f"/instances/{instance_id}", payload)

    def delete_instance(self, instance_id: str):
        return self.request("DELETE", f"/instances/{instance_id}")


class Finder:
    def __init__(self):
        self.cfg = load_json(CONFIG_PATH, {})
        key = os.environ.get("VULTR_API_KEY", "").strip()
        if not key:
            raise RuntimeError("VULTR_API_KEY is not set")
        self.api = VultrAPI(key)
        self.state = load_json(STATE_PATH, {"created_ids": [], "good_ids": [], "attempt": 0})
        self.state.setdefault("created_ids", [])
        self.state.setdefault("good_ids", [])
        self.state.setdefault("candidates", {})
        self.state.setdefault("pending_creates", {})
        self.good = load_json(GOOD_PATH, [])
        self.bad = load_json(BAD_PATH, [])
        for iid in self.state["good_ids"]:
            entry = self.state["candidates"].get(iid, {})
            if entry.get("result") and not any(r.get("instance_id") == iid for r in self.good):
                self.good.append(entry["result"])
        self.start_monotonic = time.monotonic()
        self.current_ip = None
        self.xray_exe = None
        self.hy_exe = None
        self.xray_linux_zip = None
        self.xray_linux_bin = None
        self.xray_linux_sha256 = None
        self.ssh_private_key = None
        self.ssh_public_key = None
        self.ssh_key_id = None
        self.os_id = None
        self.plan = None
        self.plans = []
        self.regions = {}
        self.socks_port = None
        self.management_relay = None
        self.last_ssh_auth_denied = False
        self.direct_gateway = None
        self.direct_interface_index = None
        self._socks_scan_time = 0.0

    def persist_state(self):
        save_json(STATE_PATH, self.state)
        save_json(GOOD_PATH, self.good)
        save_json(BAD_PATH, self.bad)


    def validate_config(self):
        if not self.cfg.get("regions") or not self.cfg.get("test_urls"):
            raise RuntimeError("config.json: regions and test_urls must be nonempty lists")
        positive = ("max_total_attempts", "good_target", "max_runtime_hours", "provision_timeout_sec",
                    "provision_poll_sec", "http_tests_per_protocol_per_round", "http_max_time_sec",
                    "min_http_passes_per_round", "http_connect_timeout_sec")
        for key in positive:
            if float(self.cfg.get(key, 0)) <= 0:
                raise RuntimeError(f"config.json: {key} must be positive")
        if int(self.cfg["http_tests_per_protocol_per_round"]) != 2:
            raise RuntimeError("Staged HY2 selection requires exactly two HTTP attempts per initial round")
        if int(self.cfg["min_http_passes_per_round"]) > int(self.cfg["http_tests_per_protocol_per_round"]):
            raise RuntimeError("min_http_passes_per_round exceeds the number of HTTP tests")
        if self.cfg.get("replacement", {}).get("enabled"):
            raise RuntimeError("replacement.enabled=true is blocked: GOOD servers are protected")
        if not re.fullmatch(r"[A-Za-z0-9.-]+", self.cfg.get("reality_server_name", "")):
            raise RuntimeError("Invalid reality_server_name")
        for key in ("xray_windows", "xray_linux", "hysteria_windows"):
            digest = self.cfg.get("artifact_sha256", {}).get(key, "")
            if not re.fullmatch(r"[0-9a-f]{64}", digest):
                raise RuntimeError(f"config.json: missing/invalid artifact_sha256.{key}")
        port = int(self.cfg.get("diagnostic_http_port", 80))
        if not 1 <= port <= 65535 or port in (443, 8443):
            raise RuntimeError("Invalid diagnostic_http_port")

    def preflight(self, check_only=False):
        self.validate_config()
        if os.name != "nt":
            raise RuntimeError("Run the finder on Windows 11; --self-test also works on Linux")
        if not check_only and not is_admin():
            raise RuntimeError("Run from an elevated Administrator PowerShell")
        for exe in ("route.exe", "ping.exe", "ssh.exe", "scp.exe", "ssh-keygen.exe", "curl.exe", "powershell.exe"):
            if not shutil.which(exe):
                raise RuntimeError(f"Required executable not found: {exe}. Enable the Windows OpenSSH Client if needed.")
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        BIN_DIR.mkdir(parents=True, exist_ok=True)
        self.resolve_direct_interface()
        if self.discover_v2rayn_socks() is None:
            log("No local SOCKS5 listener detected; the VPN SSH fallback will use system routing")
        self.resolve_catalog()
        self.ensure_binaries()
        self.ensure_ssh_key(upload=not check_only)
        if not check_only:
            self.cleanup_stale_route()
            self.recover_create_intents()
            self.reconcile_deleted_candidates()
        self.ensure_csv_header()

    def resolve_direct_interface(self):
        script = r"""$ErrorActionPreference='Stop'; $rows=@(Get-NetIPConfiguration | ForEach-Object {
          $c=$_; if ($c.IPv4DefaultGateway -and $c.NetAdapter.Status -eq 'Up') {
            foreach ($g in $c.IPv4DefaultGateway) {
              [pscustomobject]@{gateway=$g.NextHop; index=$c.InterfaceIndex; alias=$c.InterfaceAlias;
                hardware=[bool]$c.NetAdapter.HardwareInterface; metric=[int]$c.NetIPv4Interface.InterfaceMetric}
            }
          }
        }); ConvertTo-Json -InputObject $rows -Compress"""
        cp = run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script], timeout=20)
        if cp.returncode:
            raise RuntimeError("Cannot read Windows IPv4 gateways: " + decode_output(cp.stdout)[-1000:])
        rows = json.loads(decode_output(cp.stdout).strip() or "[]")
        if isinstance(rows, dict):
            rows = [rows]
        gateway = str(self.cfg.get("gateway", "auto"))
        index = self.cfg.get("direct_interface_index")
        matches = [r for r in rows if (gateway == "auto" or r["gateway"] == gateway)
                   and (int(r["index"]) == int(index) if index is not None else r["hardware"])]
        if not matches:
            raise RuntimeError(f"No active physical IPv4 gateway matches gateway={gateway}, direct_interface_index={index}. "
                               "Set gateway=auto or specify the physical router/interface in config.json.")
        selected = min(matches, key=lambda r: int(r["metric"]))
        self.direct_gateway = str(ipaddress.IPv4Address(selected["gateway"]))
        self.direct_interface_index = int(selected["index"])
        log(f"Direct interface: {selected['alias']} (IF {self.direct_interface_index}), gateway={self.direct_gateway}")


    def ensure_binaries(self):
        version = self.cfg["xray_version"]
        hashes = self.cfg["artifact_sha256"]
        def cached(path, urls, digest):
            if path.exists() and file_sha256(path) != digest:
                log(f"Cached {path.name} failed SHA256 verification; downloading again")
                path.unlink()
            if not path.exists():
                download_file(urls, path, expected_sha256=digest)
        release = f"https://github.com/XTLS/Xray-core/releases/download/v{version}"
        xzip = BIN_DIR / f"Xray-windows-64-{version}.zip"
        cached(xzip, [release + "/Xray-windows-64.zip"], hashes["xray_windows"])
        xdir = BIN_DIR / f"xray-{version}"
        xdir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(xzip) as z:
            data = z.read("xray.exe")
        self.xray_exe = xdir / "xray.exe"
        if not self.xray_exe.exists() or hashlib.sha256(data).hexdigest() != file_sha256(self.xray_exe):
            self.xray_exe.write_bytes(data)
        hy_version = self.cfg["hysteria_version"]
        self.hy_exe = BIN_DIR / f"hysteria-{hy_version}-windows-amd64.exe"
        cached(self.hy_exe, [f"https://github.com/apernet/hysteria/releases/download/app/v{hy_version}/hysteria-windows-amd64.exe"], hashes["hysteria_windows"])
        self.xray_linux_zip = BIN_DIR / f"Xray-linux-64-{version}.zip"
        cached(self.xray_linux_zip, [release + "/Xray-linux-64.zip"], hashes["xray_linux"])
        self.xray_linux_sha256 = hashes["xray_linux"]
        linux_dir = BIN_DIR / f"xray-linux-{version}"
        linux_dir.mkdir(parents=True, exist_ok=True)
        self.xray_linux_bin = linux_dir / "xray"
        with zipfile.ZipFile(self.xray_linux_zip) as z:
            data = z.read("xray")
        if not self.xray_linux_bin.exists() or hashlib.sha256(data).hexdigest() != file_sha256(self.xray_linux_bin):
            self.xray_linux_bin.write_bytes(data)
        for exe, args in ((self.xray_exe, ["version"]), (self.hy_exe, ["version"])):
            cp = run([str(exe)] + args, timeout=15)
            if cp.returncode:
                raise RuntimeError(f"Cannot start {exe.name}: " + decode_output(cp.stdout)[-1000:])
            log(decode_output(cp.stdout).splitlines()[0])
        for name in ("vpnfinder-test-cert.pem", "vpnfinder-test-key.pem"):
            if not (BASE / "templates" / name).exists():
                raise RuntimeError(f"Missing templates/{name}")
        log("All Xray/Hysteria downloads verified by pinned SHA256")


    def ensure_ssh_key(self, upload=True):
        configured = self.cfg.get("ssh_private_key")
        priv = Path(os.path.expanduser(configured)) if configured else BASE / "keys" / "id_ed25519"
        pub = Path(os.path.expanduser(self.cfg["ssh_public_key"])) if self.cfg.get("ssh_public_key") else Path(str(priv) + ".pub")
        if not priv.is_absolute():
            priv = BASE / priv
        if not pub.is_absolute():
            pub = BASE / pub
        if not priv.exists():
            if configured:
                raise RuntimeError(f"Configured SSH private key not found: {priv}")
            priv.parent.mkdir(parents=True, exist_ok=True)
            cp = run(["ssh-keygen.exe", "-q", "-t", "ed25519", "-N", "", "-f", str(priv), "-C", "VPNFinder-Auto"], timeout=20)
            if cp.returncode:
                raise RuntimeError("Could not generate the application SSH key: " + decode_output(cp.stdout)[-1000:])
            log("Generated application SSH key in keys/id_ed25519")
        cp = run(["ssh-keygen.exe", "-y", "-P", "", "-f", str(priv)], timeout=15)
        if cp.returncode:
            raise RuntimeError("The application needs an unencrypted SSH key for unattended BatchMode authentication")
        derived = decode_output(cp.stdout).strip().split()
        if len(derived) < 2:
            raise RuntimeError("ssh-keygen did not return an OpenSSH public key")
        material = " ".join(derived[:2])
        if not pub.exists():
            pub.parent.mkdir(parents=True, exist_ok=True)
            pub.write_text(material + " VPNFinder-Auto\n", encoding="utf-8")
        parts = pub.read_text(encoding="utf-8-sig").strip().split()
        if " ".join(parts[:2]) != material:
            raise RuntimeError("Configured SSH private/public keys do not match")
        found = next((k for k in self.api.list_ssh_keys() if " ".join(str(k.get("ssh_key", "")).split()[:2]) == material), None)
        if found:
            self.ssh_key_id = found["id"]
            log(f"Using existing Vultr SSH key id={self.ssh_key_id}")
        elif upload:
            created = self.api.create_ssh_key({"name": "VPNFinder-Auto", "ssh_key": material})
            self.ssh_key_id = created["id"]
            log(f"Uploaded application public key to Vultr id={self.ssh_key_id}")
        else:
            log("Application public key will be uploaded on a normal run; --check does not change Vultr")
        self.ssh_private_key, self.ssh_public_key = priv, pub

    def resolve_catalog(self):
        regions = {r["id"]: r for r in self.api.list_regions()}
        requested = self.cfg["regions"]
        missing = [r for r in requested if r not in regions]
        if missing:
            raise RuntimeError(f"Unknown/unavailable Vultr region IDs: {missing}. Available: {sorted(regions)}")
        self.regions = regions

        plans = self.api.list_plans()
        allowed_ids = self.cfg.get("plan_ids") or ([self.cfg["plan_id"]] if self.cfg.get("plan_id") else [])
        if not allowed_ids:
            raise RuntimeError("No plan_ids configured")
        by_id = {p.get("id"): p for p in plans}
        missing_ids = [pid for pid in allowed_ids if pid not in by_id]
        if missing_ids:
            log(f"Plan IDs not present in current Vultr catalog: {missing_ids}")
        candidates = [by_id[pid] for pid in allowed_ids if pid in by_id]
        if not candidates:
            raise RuntimeError(f"None of the allowed plans exist in the current Vultr catalog: {allowed_ids}")

        cap = float(self.cfg["expected_monthly_cost_max"])
        min_bw_gb = float(self.cfg.get("expected_bandwidth_min_gb", 0))
        exp_vcpu = int(self.cfg.get("expected_vcpu", 1))
        exp_ram = int(self.cfg.get("expected_ram_mb", 1024))
        min_disk = float(self.cfg.get("expected_disk_min_gb", 0))
        verified = []
        reject_reasons = []
        for plan in candidates:
            pid = plan.get("id")
            monthly = float(plan.get("monthly_cost", 9999))
            bw_gb = float(plan.get("bandwidth", 0))
            vcpu = int(plan.get("vcpu_count", -1))
            ram = int(plan.get("ram", -1))
            disk = float(plan.get("disk", 0))
            reasons = []
            if monthly > cap:
                reasons.append(f"${monthly}/mo > ${cap}")
            if bw_gb < min_bw_gb:
                reasons.append(f"bandwidth {bw_gb}GB < {min_bw_gb}GB")
            if vcpu != exp_vcpu:
                reasons.append(f"vcpu {vcpu} != {exp_vcpu}")
            if ram != exp_ram:
                reasons.append(f"ram {ram}MB != {exp_ram}MB")
            if disk < min_disk:
                reasons.append(f"disk {disk}GB < {min_disk}GB")
            if reasons:
                reject_reasons.append(f"{pid}: " + "; ".join(reasons))
                continue
            verified.append(plan)
            log(f"Plan verified: {pid}, ${monthly}/mo, {vcpu} vCPU, {ram}MB RAM, {disk:g}GB NVMe, bandwidth={bw_gb/1000:.1f}TB")
        if not verified:
            raise RuntimeError("No allowed $6/2TB plan passed safety checks: " + " | ".join(reject_reasons))
        self.plans = verified
        self.plan = verified[0]

        needle = self.cfg["os_name_contains"].lower()
        oses = self.api.list_os()
        candidates = [o for o in oses if needle in str(o.get("name", "")).lower()]
        x64 = [o for o in candidates if str(o.get("arch", "x64")).lower() in ("x64", "amd64", "x86_64", "")]
        candidates = x64
        if not candidates:
            raise RuntimeError(f"No OS matching {self.cfg['os_name_contains']}")
        self.os_id = int(candidates[0]["id"])
        log(f"OS selected: {candidates[0].get('name')} id={self.os_id}")

    def ensure_csv_header(self):
        if CSV_PATH.exists():
            return
        with CSV_PATH.open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            w.writerow([
                "time", "attempt", "region", "plan_id", "ip", "instance_id", "ping_avg_ms", "ping_loss_pct",
                "ssh_round1", "ssh_round2", "hy2_round1_ms", "hy2_round2_ms",
                "vless_round1_ms", "vless_round2_ms", "via_vpn_hy2", "via_vpn_vless",
                "classification", "kept", "hy2_passed_final", "hy2_total_final"
            ])

    def x25519(self):
        cp = run([str(self.xray_exe), "x25519"], timeout=15)
        text = decode_output(cp.stdout)
        priv = None
        pub = None
        for line in text.splitlines():
            low = line.lower()
            val = line.split(":", 1)[1].strip() if ":" in line else ""
            if "private" in low and "key" in low:
                priv = val
            elif ("public" in low and "key" in low) or low.startswith("password:"):
                pub = val
        if cp.returncode or not priv or not pub:
            raise RuntimeError("Could not parse xray x25519 output; check the pinned Xray version")
        return priv, pub

    def build_candidate(self, attempt: int, region: str, plan_id: str):
        hy_auth = secrets.token_urlsafe(24)
        vless_uuid = str(uuid.uuid4())
        short_id = secrets.token_hex(8)
        reality_private, reality_public = self.x25519()
        return {
            "attempt": attempt,
            "region": region,
            "plan_id": plan_id,
            "hy_auth": hy_auth,
            "vless_uuid": vless_uuid,
            "short_id": short_id,
            "reality_private": reality_private,
            "reality_public": reality_public,
            "reality_sni": self.cfg["reality_server_name"],
            "fingerprint": self.cfg["reality_fingerprint"],
        }

    @staticmethod
    def _b64_text(text: str) -> str:
        return base64.b64encode(text.encode("utf-8")).decode("ascii")

    def xray_server_config(self, c):
        sni = c["reality_sni"]
        return {
            "log": {"loglevel": "warning"},
            "inbounds": [
                {
                    "tag": "hy2-in",
                    "listen": "0.0.0.0",
                    "port": 443,
                    "protocol": "hysteria",
                    "settings": {
                        "version": 2,
                        "users": [{"auth": c["hy_auth"], "email": "vpnfinder@test"}],
                    },
                    "streamSettings": {
                        "network": "hysteria",
                        "security": "tls",
                        "tlsSettings": {
                            "alpn": ["h3"],
                            "minVersion": "1.3",
                            "maxVersion": "1.3",
                            "certificates": [{
                                "certificateFile": "/etc/vpnfinder/hy.crt",
                                "keyFile": "/etc/vpnfinder/hy.key",
                            }],
                        },
                        "hysteriaSettings": {"version": 2, "udpIdleTimeout": 60},
                    },
                },
                {
                    "tag": "vless-reality-in",
                    "listen": "0.0.0.0",
                    "port": 8443,
                    "protocol": "vless",
                    "settings": {
                        "clients": [{"id": c["vless_uuid"], "flow": "xtls-rprx-vision"}],
                        "decryption": "none",
                    },
                    "streamSettings": {
                        "network": "tcp",
                        "security": "reality",
                        "realitySettings": {
                            "show": False,
                            "dest": f"{sni}:443",
                            "xver": 0,
                            "serverNames": [sni],
                            "privateKey": c["reality_private"],
                            "shortIds": [c["short_id"]],
                        },
                    },
                },
            ],
            "outbounds": [{"protocol": "freedom", "tag": "direct"}],
        }

    def validate_server_config_local(self, c):
        """Validate the exact server-side protocol config before spending money on a VPS.

        The only platform-specific parts are certificate file paths, so rewrite those
        to the local template paths and ask the same Xray version to parse/test it.
        """
        cfg = self.xray_server_config(c)
        cert = str((BASE / "templates" / "vpnfinder-test-cert.pem").resolve())
        key = str((BASE / "templates" / "vpnfinder-test-key.pem").resolve())
        for inbound in cfg.get("inbounds", []):
            tls = inbound.get("streamSettings", {}).get("tlsSettings", {})
            certs = tls.get("certificates", [])
            for item in certs:
                item["certificateFile"] = cert
                item["keyFile"] = key
        with tempfile.TemporaryDirectory(prefix="vpnfinder-server-preflight-") as td:
            fp = Path(td) / "server.json"
            fp.write_text(json.dumps(cfg, ensure_ascii=False), encoding="utf-8")
            cp = run([str(self.xray_exe), "run", "-test", "-config", str(fp)], timeout=20)
            out = decode_output(cp.stdout)
            if cp.returncode != 0:
                raise RuntimeError("Local Xray server-config preflight FAILED before VPS creation: " + out[-2000:])
        log(f"Local Xray server-config preflight OK for candidate #{c['attempt']}")


    def startup_script_body(self, c):
        stage = f"/var/lib/vpnfinder-stage-{c['short_id']}"
        installer = (BASE / "server_bootstrap.py").read_text(encoding="utf-8")
        compile(installer, "server_bootstrap.py", "exec")
        files = [("server_bootstrap.py", "0700", installer),
                 ("xray.json", "0600", json.dumps(self.xray_server_config(c), ensure_ascii=False))]
        cloud = {
            "package_update": False, "package_upgrade": False, "package_reboot_if_required": False,
            "write_files": [{"path": stage + "/" + name, "owner": "root:root", "permissions": mode,
                             "encoding": "b64", "content": self._b64_text(content)} for name, mode, content in files],
            "runcmd": [["systemd-run", "--unit=vpnfinder-bootstrap", "--collect", "/usr/bin/python3",
                        stage + "/server_bootstrap.py", "--stage", stage,
                        "--download-url", f"https://github.com/XTLS/Xray-core/releases/download/v{self.cfg['xray_version']}/Xray-linux-64.zip",
                        "--sha256", self.xray_linux_sha256,
                        "--diagnostic-port", str(int(self.cfg.get("diagnostic_http_port", 80)))]]
        }
        # JSON is a YAML subset; this keeps the Windows application stdlib-only.
        body = "#cloud-config\n" + json.dumps(cloud, ensure_ascii=False, indent=2) + "\n"
        json.loads(body.split("\n", 1)[1])
        log(f"Generated Linux cloud-config preflight OK #{c['attempt']}: {len(body.encode('utf-8'))} bytes; vendor package updates disabled")
        return body

    def remember_candidate(self, c, iid, phase="created"):
        if not isinstance(iid, str):
            raise RuntimeError("Vultr returned an invalid instance ID type")
        uuid.UUID(iid)
        c["instance_id"] = iid
        if iid not in self.state["created_ids"]:
            self.state["created_ids"].append(iid)
        self.state["candidates"][iid] = {"candidate": dict(c), "phase": phase, "updated": now_iso()}

    def mark_phase(self, iid, phase):
        entry = self.state["candidates"].get(iid)
        if entry:
            entry["phase"], entry["updated"] = phase, now_iso()
        self.persist_state()

    def recover_create_intents(self):
        if not self.state["pending_creates"]:
            return
        instances = self.api.list_instances()
        for label, c in list(self.state["pending_creates"].items()):
            found = [i for i in instances if i.get("label") == label]
            if len(found) != 1:
                raise RuntimeError(f"Cannot reconcile interrupted create '{label}'. Check this label in Vultr before another run; no new VPS will be created.")
            self.remember_candidate(c, found[0]["id"])
            del self.state["pending_creates"][label]
            self.persist_state()
            log(f"Recovered interrupted create {found[0]['id']}")

    def reconcile_deleted_candidates(self):
        for iid, entry in list(self.state["candidates"].items()):
            if entry.get("phase") not in ("created", "testing", "setup_failed", "error_retained", "protocol_failed", "good", "near_good_retained"):
                continue
            try:
                self.api.get_instance(iid)
            except APIError as exc:
                if exc.status != 404:
                    raise
                self.mark_phase(iid, "deleted")
                log(f"Previously saved VPS {iid} was deleted; a new candidate may be created")

    def create(self, c):
        region = c["region"]
        label = f"{LABEL_PREFIX}test-{c['attempt']:03d}-{region}-{c['short_id'][:8]}"
        self.validate_server_config_local(c)
        user_body = self.startup_script_body(c)
        user_b64 = self._b64_text(user_body)
        payload = {"region": region, "plan": c["plan_id"], "os_id": self.os_id, "label": label,
                   "hostname": label[:63], "sshkey_id": [self.ssh_key_id], "enable_ipv6": False,
                   "backups": "disabled", "activation_email": False, "user_scheme": "root", "user_data": user_b64}
        c["label"], c["created_at"] = label, now_iso()
        # Save credentials and the unique label BEFORE the paid POST, including its uncertain-outcome case.
        self.state["pending_creates"][label] = dict(c)
        self.persist_state()
        try:
            inst = self.api.create_instance(payload)
        except APIError as exc:
            if exc.status < 500:
                self.state["pending_creates"].pop(label, None)
                self.persist_state()
            raise
        self.remember_candidate(c, inst["id"])
        self.state["pending_creates"].pop(label, None)
        self.persist_state()
        iid = c["instance_id"]
        try:
            remote_ud = self.api.get_instance_user_data(iid)
            if remote_ud == user_b64:
                log(f"User-data verified via Vultr API for {iid}: {len(user_body.encode('utf-8'))} bytes")
            else:
                log(f"User-data verification pending/mismatch for {iid}; bootstrap will be checked on the server")
        except Exception as exc:
            log(f"Could not verify user-data for {iid}: {type(exc).__name__}")
        log(f"Created {iid} region={region} plan={c['plan_id']} label={label} autonomous_user_data=cloud-config")
        return inst



    def query_host_routes(self, ip):
        ip = str(ipaddress.IPv4Address(ip))
        script = ("$ErrorActionPreference='Stop'; $r=@(Get-NetRoute -AddressFamily IPv4 "
                  f"| Where-Object {{$_.DestinationPrefix -eq '{ip}/32'}} "
                  "| Select-Object @{n='gateway';e={$_.NextHop}},@{n='index';e={$_.InterfaceIndex}}); "
                  "ConvertTo-Json -InputObject $r -Compress")
        cp = run(["powershell.exe", "-NoProfile", "-NonInteractive", "-Command", script], timeout=15)
        if cp.returncode:
            raise RuntimeError("Cannot inspect Windows host routes: " + decode_output(cp.stdout)[-500:])
        rows = json.loads(decode_output(cp.stdout).strip() or "[]")
        return [rows] if isinstance(rows, dict) else rows

    def cleanup_stale_route(self):
        record = load_json(ROUTE_PATH, None)
        if record:
            self.current_ip = str(ipaddress.IPv4Address(record["ip"]))
            self.route_delete(self.current_ip)
        elif CURRENT_IP_PATH.exists():
            log("Legacy current_ip.txt found without route metadata; check/remove that old route manually if needed")

    def route_delete(self, ip: str):
        ip = str(ipaddress.IPv4Address(ip))
        record = load_json(ROUTE_PATH, None)
        if not record or record.get("ip") != ip:
            return
        gateway = str(ipaddress.IPv4Address(record["gateway"]))
        index = int(record["index"])
        cp = run(["route.exe", "DELETE", ip, "MASK", "255.255.255.255", gateway, "IF", str(index)], timeout=10)
        if cp.returncode and any(r["gateway"] == gateway and int(r["index"]) == index for r in self.query_host_routes(ip)):
            raise RuntimeError("Could not remove the temporary direct route: " + decode_output(cp.stdout)[-500:])
        if self.current_ip == ip:
            self.current_ip = None
        ROUTE_PATH.unlink(missing_ok=True)
        CURRENT_IP_PATH.unlink(missing_ok=True)

    def route_add_direct(self, ip: str):
        ip = str(ipaddress.IPv4Address(ip))
        if self.current_ip == ip:
            return
        if self.current_ip:
            self.route_delete(self.current_ip)
        if self.query_host_routes(ip):
            raise RuntimeError(f"An existing /32 route for {ip} is present; VPNFinder will not replace it")
        record = {"ip": ip, "gateway": self.direct_gateway, "index": self.direct_interface_index, "pid": os.getpid()}
        save_json(ROUTE_PATH, record)
        cp = run(["route.exe", "ADD", ip, "MASK", "255.255.255.255", self.direct_gateway,
                  "METRIC", str(int(self.cfg.get("direct_route_metric", 5))), "IF", str(self.direct_interface_index)], timeout=10)
        if cp.returncode:
            ROUTE_PATH.unlink(missing_ok=True)
            raise RuntimeError("route ADD failed: " + decode_output(cp.stdout)[-1000:])
        self.current_ip = ip
        CURRENT_IP_PATH.write_text(ip, encoding="ascii")
        log(f"Direct /32 route added for {ip} via {self.direct_gateway}, IF {self.direct_interface_index}")

    def diag_http_text(self, ip: str, name: str, timeout=3):
        url = f"http://{ip}:{int(self.cfg.get('diagnostic_http_port', 80))}/{name}"
        try:
            # Ignore a system HTTP proxy: these probes must follow the selected host route.
            cp = run(["curl.exe", "--disable", "--noproxy", "*", "-fsS", "--connect-timeout", str(timeout),
                      "--max-time", str(timeout), "--max-filesize", "16384", url], timeout=timeout+1)
            if cp.returncode == 0:
                return decode_output(cp.stdout).strip()
        except (OSError, subprocess.TimeoutExpired):
            pass
        return None

    def ready_http_once(self, ip: str, timeout=3):
        return self.diag_http_text(ip, "READY", timeout=timeout) == "READY"

    def lightweight_protocol_probe(self, c, ip: str):
        old_http, old_start = self.cfg["http_max_time_sec"], self.cfg.get("client_start_timeout_sec", 10)
        try:
            self.cfg["http_max_time_sec"] = min(3, float(old_http))
            self.cfg["client_start_timeout_sec"] = 3
            return self.test_hy2(c, ip, tests_override=1), self.test_vless(c, ip, tests_override=1)
        finally:
            self.cfg["http_max_time_sec"], self.cfg["client_start_timeout_sec"] = old_http, old_start


    def _probe_socks5_port(self, port: int, target_host: str | None = None, target_port: int = 22) -> bool:
        try:
            with socks_connect(port, target_host, target_port, timeout=1.2):
                return True
        except (OSError, ValueError, ConnectionError):
            return False


    def discover_v2rayn_socks(self, target_ip: str | None = None, target_port: int = 22):
        configured = int(self.cfg.get("management_socks_port") or 0)
        candidates = [configured] if configured else [self.socks_port, 10808, 1080, 10809, 2080, 7890, 7891, 20170]
        if not configured and time.monotonic() - self._socks_scan_time > 10:
            try:
                cp = run(["netstat.exe", "-ano", "-p", "tcp"], timeout=5)
                for raw in (cp.stdout or b"").splitlines():
                    parts = raw.decode(errors="ignore").split()
                    if len(parts) >= 4 and "LISTENING" in parts[3].upper():
                        m = re.search(r":(\d+)$", parts[1])
                        if m and parts[1].startswith(("127.0.0.1:", "0.0.0.0:", "[::]:")):
                            candidates.append(int(m.group(1)))
            except OSError:
                pass
            self._socks_scan_time = time.monotonic()
        deadline = time.monotonic() + float(self.cfg.get("socks_discovery_timeout_sec", 4))
        for port in dict.fromkeys(candidates):
            check_stop()
            if port and self._probe_socks5_port(port, target_ip, target_port):
                if self.socks_port != port:
                    log(f"Detected local SOCKS5 on 127.0.0.1:{port}" + (f"; TCP to {target_ip}:{target_port} OK" if target_ip else ""))
                self.socks_port = port
                return port
            if time.monotonic() >= deadline:
                break
        return None

    def diag_http_text_socks(self, ip: str, name: str, timeout=3):
        # Discovery does not require SSH/22; diagnostics on HTTP/80 can work independently.
        port = self.discover_v2rayn_socks()
        if not port:
            return None
        url = f"http://{ip}:{int(self.cfg.get('diagnostic_http_port', 80))}/{name}"
        try:
            cp = run(["curl.exe", "--disable", "--socks5-hostname", f"127.0.0.1:{port}", "--noproxy", "",
                      "-fsS", "--connect-timeout", str(timeout), "--max-time", str(timeout),
                      "--max-filesize", "16384", url], timeout=timeout+1)
            if cp.returncode == 0:
                return decode_output(cp.stdout).strip()
        except (OSError, subprocess.TimeoutExpired):
            pass
        return None


    def _management_ssh_args(self, ip: str, explicit_socks: bool = False):
        args = ["ssh.exe", "-F", "NUL", "-i", str(self.ssh_private_key), "-o", "BatchMode=yes",
                "-o", "IdentitiesOnly=yes", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=NUL",
                "-o", f"ConnectTimeout={int(self.cfg.get('management_ssh_connect_timeout_sec', 4))}"]
        if explicit_socks:
            if self.management_relay is None:
                raise RuntimeError("Explicit SOCKS management requested without an active relay")
            args += ["-p", str(self.management_relay.port), "-o", f"HostKeyAlias=vpnfinder-{ip}", "root@127.0.0.1"]
        else:
            args += [f"root@{ip}"]
        return args


    def _management_scp_args(self, ip: str, explicit_socks: bool = False):
        args = ["scp.exe", "-F", "NUL", "-q", "-i", str(self.ssh_private_key), "-o", "BatchMode=yes",
                "-o", "IdentitiesOnly=yes", "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=NUL",
                "-o", f"ConnectTimeout={int(self.cfg.get('management_ssh_connect_timeout_sec', 4))}"]
        if explicit_socks:
            if self.management_relay is None:
                raise RuntimeError("Explicit SOCKS management requested without an active relay")
            args += ["-P", str(self.management_relay.port), "-o", f"HostKeyAlias=vpnfinder-{ip}"]
        return args


    def _build_local_bootstrap_bundle(self, c):
        if not self.xray_linux_bin or not self.xray_linux_bin.exists():
            raise RuntimeError("Local Linux xray binary cache is missing")
        out = BIN_DIR / f"vpnfinder-bundle-{c['attempt']:03d}.tgz"
        entries = [("xray", self.xray_linux_bin.read_bytes(), 0o755),
                   ("xray.json", json.dumps(self.xray_server_config(c)).encode("utf-8"), 0o600),
                   ("server_bootstrap.py", (BASE / "server_bootstrap.py").read_bytes(), 0o700)]
        with tarfile.open(out, "w:gz") as tf:
            for name, data, mode in entries:
                ti = tarfile.TarInfo(name=name)
                ti.size, ti.mode, ti.mtime = len(data), mode, int(time.time())
                tf.addfile(ti, io.BytesIO(data))
        return out


    def _management_ssh_ready(self, ip: str, explicit_socks: bool = False):
        self.last_ssh_auth_denied = False
        seconds = int(self.cfg.get("management_ssh_wait_vpn_sec" if explicit_socks else "management_ssh_wait_direct_sec", 60 if explicit_socks else 25))
        deadline = time.monotonic() + seconds
        last_error = "no reply"
        while time.monotonic() < deadline:
            check_stop()
            cmd = self._management_ssh_args(ip, explicit_socks=explicit_socks) + ["printf VPNFINDER_SSH_OK"]
            try:
                cp = run(cmd, timeout=min(max(1, deadline-time.monotonic()), int(self.cfg.get("management_ssh_connect_timeout_sec", 4)) + 5))
                text = decode_output(cp.stdout)
                if cp.returncode == 0 and "VPNFINDER_SSH_OK" in text:
                    return True
                last_error = text.strip().splitlines()[-1] if text.strip() else f"exit {cp.returncode}"
                if "permission denied" in last_error.lower():
                    self.last_ssh_auth_denied = True
                    break
            except subprocess.TimeoutExpired:
                last_error = "SSH connection timed out"
            pause(min(2, max(0, deadline-time.monotonic())))
        log(f"SSH unavailable for {ip}: {last_error[:400]}")
        if self.management_relay and self.management_relay.errors:
            log("SOCKS relay: " + self.management_relay.errors[-1])
        return False


    def remote_bootstrap_command(self, c):
        remote_bundle = f"/tmp/vpnfinder-{c['short_id']}.tgz"
        port = int(self.cfg.get("diagnostic_http_port", 80))
        return f"""set -eu
stage=$(mktemp -d /var/lib/vpnfinder-scp-XXXXXX)
trap 'rm -rf "$stage" {remote_bundle}' EXIT
tar -xzf {remote_bundle} -C "$stage"
/usr/bin/python3 "$stage/server_bootstrap.py" --stage "$stage" --diagnostic-port {port}
printf VPNFINDER_LOCAL_BOOTSTRAP_OK
"""

    def ensure_password_backend(self):
        try:
            return password_ssh.get_paramiko()
        except ImportError:
            log("Installing Paramiko 4.0.0 for password SSH fallback (once)")
            cp = run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "paramiko==4.0.0"], timeout=180)
            if cp.returncode:
                raise RuntimeError("Password SSH dependency installation failed; run: python -m pip install paramiko==4.0.0")
            import importlib
            importlib.invalidate_caches()
            return password_ssh.get_paramiko()

    def try_password_bootstrap(self, c, ip, explicit_socks, route_desc):
        password = ""
        client, bundle = None, None
        try:
            inst = self.api.get_instance(c["instance_id"])
            password = str(inst.get("default_password") or os.environ.get("VULTR_ROOT_PASSWORD", ""))
            if not password:
                log("No root password returned by Vultr API; password fallback unavailable")
                return False
            self.ensure_password_backend()
            host = "127.0.0.1" if explicit_socks else ip
            port = self.management_relay.port if explicit_socks else 22
            log(f"SSH key authentication rejected; trying Vultr root password via {route_desc}")
            client = password_ssh.connect(host, port, password, timeout=10)
            log(f"Password SSH authenticated via {route_desc} for {ip}")
            # Diagnose the actual cloud-init/service outcome without dumping user-data or secrets.
            try:
                _, diagnostic = password_ssh.execute(client,
                    "cloud-init status --long 2>&1; systemctl is-active vpnfinder-xray.service 2>&1; "
                    "journalctl -u vpnfinder-bootstrap.service -n 20 --no-pager 2>&1", timeout=15)
                for secret in (password, c.get("hy_auth"), c.get("reality_private"), c.get("vless_uuid")):
                    if secret:
                        diagnostic = diagnostic.replace(secret, "<redacted>")
                log(f"Remote bootstrap diagnostic {ip}: {diagnostic[-3000:]}")
            except (OSError, TimeoutError):
                log("Remote diagnostic timed out; proceeding with local installation")
            # Repair root key access without replacing existing authorized keys.
            rc, _ = password_ssh.execute(client, "install -d -m 700 /root/.ssh", timeout=10)
            if rc:
                raise RuntimeError("Cannot prepare the root SSH key directory")
            with client.open_sftp() as sftp:
                sftp.get_channel().settimeout(int(self.cfg.get("management_scp_timeout_sec", 90)))
                pub = self.ssh_public_key.read_text(encoding="utf-8-sig").strip()
                material = " ".join(pub.split()[:2])
                if len(material.split()) != 2:
                    raise RuntimeError("Invalid local SSH public key")
                path = "/root/.ssh/authorized_keys"
                try:
                    with sftp.open(path, "rb") as f:
                        existing = f.read().decode("utf-8", errors="replace")
                except FileNotFoundError:
                    existing = ""
                if not any(" ".join(line.split()[:2]) == material for line in existing.splitlines()):
                    with sftp.open(path, "ab") as f:
                        f.write(("\n" if existing and not existing.endswith("\n") else "") + pub + "\n")
                sftp.chmod(path, 0o600)
                bundle = self._build_local_bootstrap_bundle(c)
                sftp.put(str(bundle), f"/tmp/vpnfinder-{c['short_id']}.tgz")
            rc, result = password_ssh.execute(client, self.remote_bootstrap_command(c),
                                              timeout=int(self.cfg.get("management_remote_setup_timeout_sec", 75)))
            if rc == 0 and "VPNFINDER_LOCAL_BOOTSTRAP_OK" in result:
                log(f"Local-PC bootstrap SUCCESS via PASSWORD/{route_desc} for {ip}; root key installed")
                return True
            # Password is kept out of exceptions, log files, state.json and diagnostic archives.
            for secret in (password, c.get("hy_auth"), c.get("reality_private"), c.get("vless_uuid")):
                if secret:
                    result = result.replace(secret, "<redacted>")
            log(f"Password SSH installation failed: exit={rc}, {result[-1500:]}")
            return False
        except Exception as exc:
            log(f"Password SSH fallback failed ({type(exc).__name__}); no credentials logged")
            return False
        finally:
            if client:
                client.close()
            if bundle:
                bundle.unlink(missing_ok=True)
            password = ""

    def collect_remote_diagnostics(self, c, ip, phase):
        client = None
        try:
            self.route_delete(ip)
            self.ensure_password_backend()
            instance = self.api.get_instance(c["instance_id"])
            password = str(instance.get("default_password") or os.environ.get("VULTR_ROOT_PASSWORD", ""))
            if not password:
                log("Server diagnostic unavailable: API returned no password")
                return
            port = self.discover_v2rayn_socks()
            relay = SocksRelay(port, ip, 22) if port else contextlib.nullcontext(None)
            with relay as transport:
                client = password_ssh.connect("127.0.0.1" if transport else ip, transport.port if transport else 22, password, timeout=10)
                source = (BASE / "server_diagnostics.py").read_text(encoding="utf-8")
                source += "\nprint(json.dumps(collect(" + repr(c["reality_sni"]) + ", " + repr(self.cfg["test_urls"]) + ")))\n"
                remote = remote_python_command(source)
                rc, output = password_ssh.execute(client, remote, timeout=65)
                for secret in (password, c.get("hy_auth"), c.get("reality_private"), c.get("vless_uuid")):
                    if secret:
                        output = output.replace(secret, "<redacted>")
                data = json.loads(output) if rc == 0 else {"error": "diagnostic command failed", "exit": rc}
                data["provider_firewall_group_id"] = instance.get("firewall_group_id")
                path = LOG_DIR / f"server-diagnostic-{c['attempt']:03d}-{phase}.json"
                save_json(path, data)
                log(f"Saved server listeners/firewall/TLS/internet diagnostic: {path.name}")
        except Exception as exc:
            log(f"Server diagnostic unavailable ({type(exc).__name__}); VPS will be retained if protocols are unconfirmed")
        finally:
            if client:
                client.close()

    def try_local_scp_bootstrap(self, c, ip: str, path_mode: str):
        mode = path_mode.upper()
        proxy_port = None
        if mode == "VPN":
            self.route_delete(ip)
            proxy_port = self.discover_v2rayn_socks()
        elif mode == "DIRECT":
            self.route_add_direct(ip)
        else:
            raise ValueError(f"Unknown management path {path_mode}")
        relay = SocksRelay(proxy_port, ip, 22) if proxy_port else contextlib.nullcontext(None)
        try:
            with relay as active_relay:
                self.management_relay = active_relay
                explicit = active_relay is not None
                route_desc = "VPN/SOCKS-RELAY" if explicit else ("SYSTEM_ROUTING" if mode == "VPN" else "DIRECT")
                if explicit:
                    log(f"SOCKS relay 127.0.0.1:{active_relay.port} -> v2rayN 127.0.0.1:{proxy_port} -> {ip}:22")
                log(f"Local-PC bootstrap: trying SSH via {route_desc} for {ip}")
                if not self._management_ssh_ready(ip, explicit_socks=explicit):
                    if self.last_ssh_auth_denied:
                        return self.try_password_bootstrap(c, ip, explicit, route_desc)
                    return False
                bundle = self._build_local_bootstrap_bundle(c)
                remote_bundle = f"/tmp/vpnfinder-{c['short_id']}.tgz"
                host = "127.0.0.1" if explicit else ip
                scp_cmd = self._management_scp_args(ip, explicit_socks=explicit) + [bundle.name, f"root@{host}:{remote_bundle}"]
                try:
                    cp = run(scp_cmd, cwd=str(bundle.parent), timeout=int(self.cfg.get("management_scp_timeout_sec", 90)))
                    if cp.returncode:
                        log(f"SCP via {route_desc} failed: " + decode_output(cp.stdout)[-800:])
                        return False
                    remote = self.remote_bootstrap_command(c)
                    cp = run(self._management_ssh_args(ip, explicit_socks=explicit) + [remote], timeout=int(self.cfg.get("management_remote_setup_timeout_sec", 75)))
                    text = decode_output(cp.stdout)
                    if cp.returncode == 0 and "VPNFINDER_LOCAL_BOOTSTRAP_OK" in text:
                        log(f"Local-PC bootstrap SUCCESS via {route_desc} for {ip}")
                        return True
                    log(f"Remote setup via {route_desc} failed: " + text[-1200:])
                    return False
                finally:
                    bundle.unlink(missing_ok=True)
        except (OSError, subprocess.TimeoutExpired) as exc:
            log(f"Local-PC bootstrap via {mode} failed: {type(exc).__name__}: {exc}")
            return False
        finally:
            self.management_relay = None

    def ensure_candidate_bootstrap(self, c, ip: str):
        auto = self.wait_autonomous_bootstrap(c, ip)
        if auto.get("ok"):
            return auto
        log(f"Autonomous bootstrap unconfirmed for {ip}; trying the local cached binary")
        if self.try_local_scp_bootstrap(c, ip, "VPN"):
            return {"ok": True, "via": "LOCAL_SCP_VPN"}
        if self.try_local_scp_bootstrap(c, ip, "DIRECT"):
            return {"ok": True, "via": "LOCAL_SCP_DIRECT"}
        # A firewall may block the diagnostic port even when the actual protocols work.
        self.route_add_direct(ip)
        hy, vl = self.lightweight_protocol_probe(c, ip)
        if hy.get("ok", 0) >= 1 or vl.get("ok", 0) >= 1:
            return {"ok": True, "via": "DIRECT_PROTOCOL"}
        grace = int(self.cfg.get("final_autonomous_grace_sec", 30))
        log(f"SSH paths unavailable; final cloud-init grace {grace}s for {ip}")
        return self.wait_autonomous_bootstrap(c, ip, timeout_override=grace)

    def bootstrap_state(self, c, ip, via_socks, timeout):
        reader = self.diag_http_text_socks if via_socks else self.diag_http_text
        text = reader(ip, "HEALTH.json", timeout=timeout)
        if not text:
            return None
        try:
            data = json.loads(text)
        except (ValueError, TypeError):
            return None
        expected = hashlib.sha256(json.dumps(self.xray_server_config(c), sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        if data.get("ready") and data.get("config_sha256") == expected:
            return {"ok": True, "via": "VPN_SOCKS_HTTP" if via_socks else "DIRECT_HTTP"}
        if data.get("error"):
            log(f"Remote bootstrap error on {ip}: {str(data['error'])[-1500:]}")
            return {"ok": False, "via": "REMOTE_FAILED"}
        return {"ok": False, "via": "IN_PROGRESS", "status": data.get("status")}

    def wait_autonomous_bootstrap(self, c, ip: str, timeout_override=None):
        total = float(timeout_override if timeout_override is not None else self.cfg.get("autonomous_bootstrap_timeout_sec", 35))
        deadline, last = time.monotonic() + total, None
        try:
            while time.monotonic() < deadline:
                check_stop()
                for via_socks in (False, True):
                    remaining = deadline-time.monotonic()
                    if remaining <= 0:
                        break
                    if via_socks:
                        self.route_delete(ip)
                    else:
                        self.route_add_direct(ip)
                    state = self.bootstrap_state(c, ip, via_socks, min(2, max(0.2, remaining)))
                    if state:
                        if state.get("ok"):
                            log(f"Bootstrap READY confirmed via {state['via']} for {ip}")
                            return state
                        if state.get("via") == "REMOTE_FAILED":
                            return state
                        status = state.get("status")
                        if status and status != last:
                            log(f"Bootstrap {ip}: {status}")
                            last = status
                pause(min(float(self.cfg.get("bootstrap_poll_sec", 2)), max(0, deadline-time.monotonic())))
            return {"ok": False, "via": "UNCONFIRMED"}
        finally:
            self.route_delete(ip)

    def ping_test(self, ip: str, count=10):
        cp = run(["ping.exe", "-n", str(count), "-w", "1200", ip], timeout=count * 2 + 5)
        data = cp.stdout or b""
        replies = 0
        times = []
        for line in data.splitlines():
            if b"TTL=" in line.upper():
                replies += 1
                if b"<1" in line:
                    times.append(1)
                else:
                    vals = re.findall(rb"=([0-9]+)", line)
                    if len(vals) >= 3:
                        times.append(int(vals[-2]))
        loss = 100.0 * (count - replies) / count
        avg = round(sum(times) / len(times), 1) if times else None
        return {"sent": count, "received": replies, "loss_pct": loss, "avg_ms": avg}

    def ssh_test(self, ip: str):
        total = int(self.cfg["ssh_attempts_per_round"])
        ok = 0
        details = []
        for _ in range(total):
            cmd = [
                "ssh.exe", "-F", "NUL", "-o", "BatchMode=yes", "-o", "PreferredAuthentications=none",
                "-o", "StrictHostKeyChecking=no", "-o", "UserKnownHostsFile=NUL",
                "-o", f"ConnectTimeout={self.cfg['ssh_connect_timeout_sec']}",
                f"root@{ip}", "exit"
            ]
            try:
                cp = run(cmd, timeout=int(self.cfg["ssh_connect_timeout_sec"]) + 8)
                text = decode_output(cp.stdout)
            except subprocess.TimeoutExpired:
                text = "LOCAL_TIMEOUT"
            passed = "permission denied" in text.lower()
            if passed:
                ok += 1
            else:
                details.append(text.strip().splitlines()[-1] if text.strip() else "NO_OUTPUT")
            pause(1)
        return {"ok": ok, "total": total, "errors": details[:5]}

    def free_port(self):
        with socket.socket() as s:
            s.bind(("127.0.0.1", 0))
            return s.getsockname()[1]

    def curl_proxy_tests(self, socks_port: int, tests_override=None, url_offset=0):
        urls = self.cfg["test_urls"]
        n = int(tests_override if tests_override is not None else self.cfg["http_tests_per_protocol_per_round"])
        results = []
        for i in range(n):
            check_stop()
            url = urls[(i+url_offset) % len(urls)]
            cmd = ["curl.exe", "--disable", "--socks5-hostname", f"127.0.0.1:{socks_port}", "--noproxy", "",
                   "-sS", "-o", "NUL", "-w", "%{http_code}|%{time_total}",
                   "--connect-timeout", str(self.cfg["http_connect_timeout_sec"]),
                   "--max-time", str(self.cfg["http_max_time_sec"]), url]
            rc, error = 1, ""
            try:
                cp = run(cmd, timeout=float(self.cfg["http_max_time_sec"]) + 3)
                rc, text = cp.returncode, decode_output(cp.stdout).strip()
            except subprocess.TimeoutExpired:
                text, error = "000|0", "timeout"
            m = re.search(r"(\d{3})\|([0-9.]+)\s*$", text)
            code, ms = (int(m[1]), round(float(m[2])*1000, 1)) if m else (0, None)
            success = rc == 0 and 200 <= code < 400
            if not success:
                log(f"HTTP test failed: url={url}, curl_exit={rc}, status={code}, detail={(error or text)[-500:]}")
            results.append({"url": url, "code": code, "ms": ms, "ok": success, "curl_exit": rc,
                            "error": error or (text[-500:] if not success else "")})
        passed = [r for r in results if r["ok"]]
        avg = round(sum(r["ms"] for r in passed)/len(passed), 1) if passed else None
        return {"ok": len(passed), "total": n, "avg_ms": avg, "results": results}

    def wait_client(self, process, port):
        deadline = time.monotonic() + float(self.cfg.get("client_start_timeout_sec", 10))
        while time.monotonic() < deadline:
            check_stop()
            if process.poll() is not None:
                return False
            try:
                with socket.create_connection(("127.0.0.1", port), timeout=0.15):
                    return True
            except OSError:
                pause(0.1)
        return False

    def stop_client(self, process):
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(3)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait(3)

    def _test_hy2_session(self, c, ip: str, tests_override=None, server_port=443, url_offset=0):
        port = self.free_port()
        with tempfile.TemporaryDirectory(prefix="vpnfinder-hy2-") as td:
            cfg = Path(td) / "client.yaml"
            cfg.write_text(json.dumps({"server": f"{ip}:{server_port}", "auth": c["hy_auth"], "tls": {"insecure": True},
                                       "socks5": {"listen": f"127.0.0.1:{port}"}}), encoding="utf-8")
            logfile = LOG_DIR / f"hy2-client-{c['attempt']:03d}.log"
            with logfile.open("ab") as lf:
                p = subprocess.Popen([str(self.hy_exe), "--disable-update-check", "client", "-c", str(cfg)], stdout=lf, stderr=subprocess.STDOUT, creationflags=CREATE_NO_WINDOW)
                try:
                    if not self.wait_client(p, port):
                        return {"ok": 0, "total": int(tests_override if tests_override is not None else self.cfg["http_tests_per_protocol_per_round"]),
                                "avg_ms": None, "error": "Hysteria client unavailable; see " + logfile.name}
                    return self.curl_proxy_tests(port, tests_override=1, url_offset=url_offset)
                finally:
                    self.stop_client(p)

    def test_hy2(self, c, ip: str, tests_override=None, server_port=443, url_offset=0):
        count = int(tests_override if tests_override is not None else self.cfg["http_tests_per_protocol_per_round"])
        attempts = []
        for index in range(count):
            check_stop()
            attempt = self._test_hy2_session(c, ip, tests_override=1, server_port=server_port, url_offset=index+url_offset)
            attempts.extend(attempt.get("results") or [{"ok": False, "ms": None, "error": attempt.get("error", "client failed")}])
        passed = [r for r in attempts if r.get("ok")]
        times = [r["ms"] for r in passed if r.get("ms") is not None]
        return {"ok": len(passed), "total": count, "avg_ms": round(sum(times)/len(times), 1) if times else None,
                "results": attempts, "fresh_hy2_sessions": count}

    def xray_client_config(self, c, ip, port):
        return {
            "log": {"loglevel": "info"},
            "inbounds": [{
                "listen": "127.0.0.1", "port": port, "protocol": "socks",
                "settings": {"udp": True}
            }],
            "outbounds": [{
                "protocol": "vless",
                "settings": {"vnext": [{
                    "address": ip, "port": 8443,
                    "users": [{"id": c["vless_uuid"], "flow": "xtls-rprx-vision", "encryption": "none"}]
                }]},
                "streamSettings": {
                    "network": "tcp", "security": "reality",
                    "realitySettings": {
                        "fingerprint": c["fingerprint"], "serverName": c["reality_sni"],
                        "publicKey": c["reality_public"], "shortId": c["short_id"], "spiderX": "/"
                    }
                }
            }]
        }

    def test_vless(self, c, ip: str, tests_override=None, upstream_socks_port=None, server_port=8443):
        port = self.free_port()
        relay = SocksRelay(upstream_socks_port, ip, server_port) if upstream_socks_port else contextlib.nullcontext(None)
        with relay as transport, tempfile.TemporaryDirectory(prefix="vpnfinder-xray-") as td:
            config = self.xray_client_config(c, ip, port)
            config["outbounds"][0]["settings"]["vnext"][0]["port"] = server_port
            if transport:
                endpoint = config["outbounds"][0]["settings"]["vnext"][0]
                endpoint["address"], endpoint["port"] = "127.0.0.1", transport.port
            cfg = Path(td) / "client.json"
            cfg.write_text(json.dumps(config, ensure_ascii=False), encoding="utf-8")
            logfile = LOG_DIR / f"xray-client-{c['attempt']:03d}.log"
            with logfile.open("ab") as lf:
                p = subprocess.Popen([str(self.xray_exe), "run", "-config", str(cfg)], stdout=lf, stderr=subprocess.STDOUT, creationflags=CREATE_NO_WINDOW)
                try:
                    if not self.wait_client(p, port):
                        return {"ok": 0, "total": int(tests_override if tests_override is not None else self.cfg["http_tests_per_protocol_per_round"]),
                                "avg_ms": None, "error": "Xray client unavailable; see " + logfile.name}
                    result = self.curl_proxy_tests(port, tests_override=tests_override)
                    result["path"] = "EXPLICIT_SOCKS" if transport else "SYSTEM_ROUTING"
                    return result
                finally:
                    self.stop_client(p)

    def pass_round(self, r):
        return r.get("ok", 0) >= int(self.cfg["min_http_passes_per_round"])

    def good_count(self):
        return sum(1 for record in self.good if self.is_direct_good(record) and
                   self.state["candidates"].get(record.get("instance_id"), {}).get("phase") != "deleted")

    def strict_protocol_round(self, result):
        n = int(self.cfg["http_tests_per_protocol_per_round"])
        return n >= 2 and result.get("ok", 0) == n and result.get("total", 0) == n

    def hy2_assessment(self, r1, r2, extra=None):
        initial = (r1.get("hy2", {}), r2.get("hy2", {}))
        if any(r.get("total") != 2 or not 0 <= r.get("ok", -1) <= 2 for r in initial):
            return {"status": "NOT_GOOD", "passed": 0, "total": 0, "reason": "incomplete initial rounds"}
        ordered = []
        for result in initial:
            rows = result.get("results", [])
            if len(rows) == 2:
                ordered.extend(bool(row.get("ok")) for row in rows)
            elif result["ok"] in (0, 2):
                ordered.extend([bool(result["ok"])]*2)
            else:
                ordered.extend([None, None])
        initial_passes = sum(r["ok"] for r in initial)
        passed, total = initial_passes, 4
        if extra is not None:
            if len(extra) != 4 or any(not isinstance(row.get("ok"), bool) for row in extra):
                return {"status": "NOT_GOOD", "passed": passed, "total": total, "reason": "incomplete retest"}
            passed += sum(row["ok"] for row in extra)
            total += len(extra)
            ordered.extend(row["ok"] for row in extra)
        consecutive = any(a is False and b is False for a, b in zip(ordered, ordered[1:]))
        if consecutive:
            status = "NOT_GOOD"
        elif extra is not None:
            status = "GOOD" if passed >= 7 else "NOT_GOOD"
        else:
            status = "GOOD" if initial_passes == 4 else "RETEST" if initial_passes == 3 else "NOT_GOOD"
        return {"status": status, "passed": passed, "total": total, "consecutive_failures": consecutive}

    def direct_grade(self, r1, r2, extra=None):
        hy_good = self.hy2_assessment(r1, r2, extra)["status"] == "GOOD"
        vl_good = all(self.strict_protocol_round(r.get("vless", {})) for r in (r1, r2))
        return ("GOOD_BOTH" if vl_good else "GOOD_HY2") if hy_good else None

    def is_direct_good(self, record):
        current = record.get("latest_retest", record)
        return (current.get("classification") in ("GOOD_DIRECT", "GOOD_HY2", "GOOD_BOTH") and
                self.direct_grade(current.get("round1", {}), current.get("round2", {}), current.get("hy2_retest")) is not None)

    def run_hy2_retest(self, c, ip):
        results = []
        for index in range(4):
            check_stop()
            attempt = self.test_hy2(c, ip, tests_override=1, url_offset=index)
            row = (attempt.get("results") or [{"ok": False, "error": attempt.get("error", "missing result")}])[0]
            results.append(dict(row, ok=bool(row.get("ok")), time=now_iso()))
            log(f"HY2 direct RETEST {index+1}/4: {'OK' if results[-1]['ok'] else 'FAIL'}")
            if index < 3:
                pause(float(self.cfg.get("hy2_retest_interval_sec", 3)))
        return results

    def direct_round(self, c, ip):
        ssh = self.ssh_test(ip)
        hy = self.test_hy2(c, ip)
        vl = self.test_vless(c, ip)
        log(f"{ip} round: SSH {ssh['ok']}/{ssh['total']}; HY2 {hy.get('ok')}/{hy.get('total')} {hy.get('avg_ms')}ms; VLESS {vl.get('ok')}/{vl.get('total')} {vl.get('avg_ms')}ms")
        return {"ssh": ssh, "hy2": hy, "vless": vl}

    def via_vpn_control(self, c, ip):
        self.route_delete(ip)
        port = self.discover_v2rayn_socks()
        vl = self.test_vless(c, ip, upstream_socks_port=port)
        hy = self.test_hy2(c, ip)
        # A TCP-only SOCKS relay cannot carry HY2's UDP transport. Be explicit about this result.
        hy["path"] = "SYSTEM_TUN" if self.cfg.get("existing_vpn_uses_tun", False) else "SYSTEM_ROUTING_UNVERIFIED"
        log(f"{ip} control: VLESS {vl.get('ok')}/{vl.get('total')} ({vl.get('path', 'SYSTEM_ROUTING')}); "
            f"HY2 {hy.get('ok')}/{hy.get('total')} ({hy['path']})")
        return {"hy2": hy, "vless": vl}

    def share_links(self, c, ip, label):
        tag = urllib.parse.quote(label)
        hy_auth = urllib.parse.quote(c["hy_auth"], safe="")
        hy = f"hysteria2://{hy_auth}@{ip}:443/?insecure=1#{tag}-HY2"
        q = urllib.parse.urlencode({
            "encryption": "none", "flow": "xtls-rprx-vision", "security": "reality",
            "sni": c["reality_sni"], "fp": c["fingerprint"], "pbk": c["reality_public"],
            "sid": c["short_id"], "type": "tcp", "headerType": "none"
        })
        vl = f"vless://{c['vless_uuid']}@{ip}:8443?{q}#{tag}-VLESS"
        return {"hy2": hy, "vless": vl}

    def safe_delete(self, iid: str):
        if iid in self.state.get("good_ids", []) or any(r.get("instance_id") == iid for r in self.good):
            raise RuntimeError(f"Refusing to delete GOOD instance {iid}")
        if iid not in self.state.get("created_ids", []):
            raise RuntimeError(f"Instance {iid} was not created by this state")
        try:
            inst = self.api.get_instance(iid)
        except APIError as exc:
            if exc.status == 404:
                self.mark_phase(iid, "deleted")
                return
            raise
        label = str(inst.get("label", ""))
        if not label.startswith(LABEL_PREFIX) or label.lower().startswith(LABEL_PREFIX + "good"):
            raise RuntimeError(f"Refusing to delete instance with protected/unexpected label: {iid}")
        self.api.delete_instance(iid)
        self.mark_phase(iid, "deleted")
        log(f"Deleted BAD instance {iid} {inst.get('main_ip')}")

    def append_csv(self, c, ip, iid, ping, r1, r2, control, classification, kept, assessment=None):
        def fmt_proxy(r):
            if not r:
                return ""
            return f"{r.get('ok',0)}/{r.get('total',0)}@{r.get('avg_ms')}ms"
        with CSV_PATH.open("a", newline="", encoding="utf-8-sig") as f:
            csv.writer(f).writerow([
                now_iso(), c["attempt"], c["region"], c.get("plan_id"), ip, iid, ping.get("avg_ms"), ping.get("loss_pct"),
                f"{r1['ssh']['ok']}/{r1['ssh']['total']}", f"{r2['ssh']['ok']}/{r2['ssh']['total']}",
                fmt_proxy(r1["hy2"]), fmt_proxy(r2["hy2"]), fmt_proxy(r1["vless"]), fmt_proxy(r2["vless"]),
                fmt_proxy(control.get("hy2")) if control else "", fmt_proxy(control.get("vless")) if control else "",
                classification, kept, (assessment or {}).get("passed"), (assessment or {}).get("total")
            ])

    def process_created_candidate(self, c, iid: str, inst):
        attempt, region, ip = c["attempt"], c["region"], None
        committed_good = False
        try:
            ip = str(ipaddress.IPv4Address(inst["main_ip"]))
            c["ip"], c["instance_id"] = ip, iid
            self.remember_candidate(c, iid, "testing")
            self.persist_state()
            log(f"Waiting for Linux cloud-init/GitHub bootstrap on {ip}")
            setup = self.ensure_candidate_bootstrap(c, ip)
            if not setup.get("ok"):
                raise RuntimeError("SETUP_UNCONFIRMED: autonomous install and both SSH paths failed")
            c["setup_ready_via"] = setup.get("via")
            self.collect_remote_diagnostics(c, ip, "before_tests")
            self.route_add_direct(ip)
            historical = next((r.get("latest_retest", r) for r in self.good if r.get("instance_id") == iid), None)
            if historical is None:
                historical = next((r for r in reversed(self.bad) if r.get("instance_id") == iid and "round1" in r), None)
            reuse = (getattr(self, "retest_saved_mode", False) and historical is not None and historical.get("ip") == ip and
                     self.hy2_assessment(historical.get("round1", {}), historical.get("round2", {}))["status"] == "RETEST" and
                     historical.get("hy2_retest") is None)
            if reuse:
                r1, r2 = historical["round1"], historical["round2"]
                ping = historical.get("ping", {})
                log(f"Saved HY2 3/4 for {ip}: retaining initial measurements and testing four additional fresh sessions")
            else:
                ping = self.ping_test(ip, 10)
                log(f"{ip} ping direct: avg={ping['avg_ms']}ms loss={ping['loss_pct']}%")
                r1 = self.direct_round(c, ip)
                pause(float(self.cfg["round_delay_sec"]))
                r2 = self.direct_round(c, ip)
            initial = self.hy2_assessment(r1, r2)
            extra = self.run_hy2_retest(c, ip) if initial["status"] == "RETEST" else None
            assessment = self.hy2_assessment(r1, r2, extra)
            log(f"HY2 direct assessment {ip}: {assessment['passed']}/{assessment['total']} {assessment['status']}")
            classification = self.direct_grade(r1, r2, extra)
            control = None
            kept = classification is not None
            if not kept:
                control = self.via_vpn_control(c, ip)
                control_ok = ((control["vless"].get("path") == "EXPLICIT_SOCKS" and self.pass_round(control["vless"])) or
                              (control["hy2"].get("path") == "SYSTEM_TUN" and self.pass_round(control["hy2"])))
                near_hy2 = any(r["hy2"].get("ok", 0) > 0 for r in (r1, r2))
                classification = "NEAR_GOOD_HY2" if near_hy2 else ("FILTERED_DIRECT" if control_ok else "PROTOCOL_UNCONFIRMED")
            record = {"time": now_iso(), "attempt": attempt, "region": region, "plan_id": c["plan_id"],
                      "region_city": self.regions[region].get("city"), "ip": ip, "instance_id": iid,
                      "ping": ping, "round1": r1, "round2": r2, "hy2_retest": extra, "hy2_assessment": assessment,
                      "initial_rounds_reused": reuse, "initial_rounds_time": historical.get("time") if reuse else None,
                      "control_via_existing_vpn": control,
                      "classification": classification, "setup_ready_via": c.get("setup_ready_via"),
                      "direct_route": {"gateway": self.direct_gateway, "interface_index": self.direct_interface_index}}
            previous = next((r for r in self.good if r.get("instance_id") == iid), None)
            if kept:
                good_no = len(self.good) + 1
                label = f"{LABEL_PREFIX}GOOD-{good_no:02d}-{region}"
                record["label"], record["links"] = label, self.share_links(c, ip, label)
                record["credentials"] = {"hy2_auth": c["hy_auth"], "vless_uuid": c["vless_uuid"],
                                         "reality_public_key": c["reality_public"], "reality_short_id": c["short_id"],
                                         "reality_sni": c["reality_sni"], "reality_fingerprint": c["fingerprint"]}
                self.good[:] = [r for r in self.good if r.get("instance_id") != iid]
                self.good.append(record)
                if iid not in self.state["good_ids"]:
                    self.state["good_ids"].append(iid)
                committed_good = True
                self.state["candidates"][iid]["result"] = record
                self.mark_phase(iid, "good")
                try:
                    self.api.patch_instance(iid, {"label": label})
                except Exception as exc:
                    log(f"Could not relabel GOOD {iid}: {type(exc).__name__}")
                log(f"GOOD #{good_no} [{classification}]: {ip} {region}; HY2 passed staged direct selection; kept alive")
            else:
                if previous:
                    previous["latest_retest"] = record
                self.bad.append(record)
                self.mark_phase(iid, "near_good_retained" if classification == "NEAR_GOOD_HY2" else ("protocol_failed" if classification == "PROTOCOL_UNCONFIRMED" else "bad_retained"))
                self.collect_remote_diagnostics(c, ip, "after_failed_tests")
                delete_allowed = classification not in ("PROTOCOL_UNCONFIRMED", "NEAR_GOOD_HY2") or self.cfg.get("delete_unconfirmed_protocols", False)
                if self.cfg.get("delete_bad", True) and delete_allowed and iid not in self.state["good_ids"]:
                    self.route_delete(ip)
                    self.safe_delete(iid)
                    pause(float(self.cfg["pause_after_delete_sec"]))
                else:
                    log(f"BAD retained: {ip}")
            self.append_csv(c, ip, iid, ping, r1, r2, control or {}, classification, kept, assessment=assessment)
            self.persist_state()
            return kept
        except Exception as exc:
            if committed_good:
                log(f"GOOD {iid} retained; a later reporting/cleanup step failed: {type(exc).__name__}: {exc}")
                self.persist_state()
                return True
            error = f"{type(exc).__name__}: {exc}"
            classification = "SETUP_UNCONFIRMED" if "SETUP_UNCONFIRMED" in error else "ERROR"
            log(f"Candidate #{attempt}: {error}")
            self.bad.append({"time": now_iso(), "attempt": attempt, "region": region, "plan_id": c.get("plan_id"),
                             "ip": ip, "instance_id": iid, "classification": classification, "error": error})
            self.mark_phase(iid, "setup_failed" if classification.startswith("SETUP") else "error_retained")
            if classification.startswith("SETUP") and self.cfg.get("delete_setup_failed", False) and self.cfg.get("delete_bad", True):
                self.safe_delete(iid)
            else:
                log(f"Retained for diagnostics/resume: {iid} {ip or ''}")
            return False
        finally:
            if ip:
                self.route_delete(ip)

    def create_pending_candidate(self, attempt: int, region: str, plan_id: str):
        c = self.build_candidate(attempt, region, plan_id)
        inst = self.create(c)
        iid = inst["id"]
        if not isinstance(iid, str) or not iid:
            raise RuntimeError(f"Vultr create_instance returned invalid instance id: {type(iid).__name__}")
        return {
            "c": c,
            "iid": iid,
            "created_monotonic": time.monotonic(),
            "last_state": None,
        }

    def record_provision_failure(self, entry, error_text: str):
        c, iid = entry["c"], entry["iid"]
        self.bad.append({"time": now_iso(), "attempt": c["attempt"], "region": c["region"], "plan_id": c.get("plan_id"),
                         "ip": None, "instance_id": iid, "classification": "PROVISION_FAILED", "error": error_text})
        self.mark_phase(iid, "setup_failed")
        if self.cfg.get("delete_bad", True) and self.cfg.get("delete_setup_failed", False):
            self.safe_delete(iid)
        else:
            log(f"Provisioning failure retained for diagnostics: {iid}")

    def wait_any_ready(self, pending):
        poll, timeout = float(self.cfg.get("provision_poll_sec", 6)), float(self.cfg.get("provision_timeout_sec", 300))
        while pending:
            check_stop()
            if time.monotonic()-self.start_monotonic >= float(self.cfg["max_runtime_hours"])*3600:
                raise TimeoutError("max_runtime_hours reached while provisioning; instances retained for resume")
            for entry in list(pending):
                check_stop()
                iid, c = entry["iid"], entry["c"]
                if time.monotonic()-entry["created_monotonic"] >= timeout:
                    self.record_provision_failure(entry, f"Provisioning timed out after {timeout:g}s")
                    pending.remove(entry)
                    continue
                try:
                    inst = self.api.get_instance(iid)
                except APIError as exc:
                    if exc.status == 404:
                        self.mark_phase(iid, "deleted")
                        pending.remove(entry)
                        continue
                    raise
                except (OSError, urllib.error.URLError) as exc:
                    log(f"Provision poll network error {iid}: {type(exc).__name__}")
                    continue
                ip = inst.get("main_ip")
                state = (inst.get("status"), inst.get("power_status"), inst.get("server_status"), ip)
                if state != entry.get("last_state"):
                    log(f"Provisioning #{c['attempt']} {c['region']}: ip={ip}, status={state[0]}, power={state[1]}, server_status={state[2]}")
                    entry["last_state"] = state
                if state[:3] == ("active", "running", "ok") and ip and ip != "0.0.0.0":
                    log(f"Instance READY #{c['attempt']}: {ip}, region={c['region']}")
                    return entry, inst
            if pending:
                pause(poll)
        return None, None

    def cleanup_pending(self, pending, reason: str):
        for entry in list(pending):
            iid = entry["iid"]
            if self.cfg.get("delete_bad", True):
                try:
                    self.safe_delete(iid)
                except Exception as exc:
                    log(f"Pending cleanup failed for {iid}; saved for resume: {exc}")
            else:
                self.mark_phase(iid, "created")
            pending.remove(entry)
        self.persist_state()

    def plan_for_region(self, region: str):
        # Prefer AMD, then Intel, but only among the exact $6/2TB plans verified above.
        for plan in self.plans:
            locations = plan.get("locations") or []
            if not locations or region in locations:
                return plan
        return None

    def main_loop(self, retest_saved=False):
        self.retest_saved_mode = retest_saved
        self.preflight()
        if retest_saved:
            for iid, entry in self.state["candidates"].items():
                if entry.get("phase") in ("good", "near_good_retained"):
                    entry["phase"] = "created"
            self.persist_state()
        for saved in self.good:
            if not self.is_direct_good(saved):
                log(f"Saved candidate {saved.get('ip', saved.get('instance_id'))} retained, but excluded from strict HY2 target")
        target_good = int(self.cfg["good_target"])
        if self.good_count() >= target_good and not retest_saved:
            log("Good target already reached")
            return True
        pending = [{"c": dict(e["candidate"]), "iid": iid, "created_monotonic": time.monotonic(), "last_state": None}
                   for iid, e in self.state["candidates"].items()
                   if e["phase"] in ("created", "testing", "setup_failed", "error_retained", "protocol_failed")]
        max_attempts = 0 if (pending or retest_saved) else int(self.cfg["max_total_attempts"])
        if pending:
            log(f"Resuming {len(pending)} saved candidate(s); no new paid VPS will be created in this run")
        pipeline = max(1, min(int(self.cfg.get("provision_pipeline_size", 1)), 5))
        lifetime_attempt, run_created = int(self.state.get("attempt", 0)), 0
        regions = self.cfg["regions"]
        max_runtime = float(self.cfg["max_runtime_hours"]) * 3600
        def expired():
            return time.monotonic()-self.start_monotonic >= max_runtime
        def top_up():
            nonlocal lifetime_attempt, run_created
            while len(pending) < pipeline and run_created < max_attempts and self.good_count() < target_good and not expired():
                check_stop()
                lifetime_attempt += 1
                run_created += 1
                self.state["attempt"] = lifetime_attempt
                self.persist_state()
                region = regions[(lifetime_attempt-1) % len(regions)]
                plan = self.plan_for_region(region)
                if plan is None:
                    log(f"No approved plan available in {region}; skipping")
                    continue
                log(f"=== Create {run_created}/{max_attempts}, lifetime={lifetime_attempt}, region={region}, plan={plan['id']} ===")
                pending.append(self.create_pending_candidate(lifetime_attempt, region, plan["id"]))
                if len(pending) < pipeline and run_created < max_attempts:
                    pause(float(self.cfg.get("create_spacing_sec", 3)))
        log(f"START v{VERSION}: target_good={target_good}, existing_good={self.good_count()}, pipeline={pipeline}")
        try:
            top_up()
            while self.good_count() < target_good or (retest_saved and pending):
                check_stop()
                if expired():
                    log("STOP: max_runtime_hours reached; pending candidates saved for resume")
                    break
                if not pending:
                    top_up()
                    if not pending:
                        break
                entry, inst = self.wait_any_ready(pending)
                if entry is None:
                    continue
                pending.remove(entry)
                log(f"=== TESTING #{entry['c']['attempt']} {inst.get('main_ip')} ===")
                self.process_created_candidate(entry["c"], entry["iid"], inst)
                if self.good_count() >= target_good and not retest_saved:
                    self.cleanup_pending(pending, "good_target reached")
                    break
                top_up()
        finally:
            # Credentials and phase changes are already on disk, including on Ctrl+C.
            self.persist_state()
            if pending:
                log(f"Saved {len(pending)} pending candidate(s) for the next run")
        log(f"FINISHED: good={self.good_count()}, bad_events={len(self.bad)}, created_this_run={run_created}")
        return self.good_count() >= target_good


def write_diagnostics():
    state = load_json(STATE_PATH, {})
    secrets_to_hide = [os.environ.get("VULTR_API_KEY", "")]
    def collect(value):
        if isinstance(value, dict):
            for key, item in value.items():
                if any(word in key.lower() for word in ("auth", "private", "password", "uuid", "token")) and isinstance(item, str):
                    secrets_to_hide.append(item)
                else:
                    collect(item)
        elif isinstance(value, list):
            for item in value:
                collect(item)
    collect(state)
    collect(load_json(GOOD_PATH, []))
    summary = {"version": VERSION, "platform": sys.platform, "python": sys.version.split()[0],
               "attempt": state.get("attempt"), "good_ids": state.get("good_ids", []),
               "candidates": [{"id": iid, "phase": entry.get("phase"), "updated": entry.get("updated")}
                              for iid, entry in state.get("candidates", {}).items()]}
    dest = BASE / "diagnostics.zip"
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("summary.json", json.dumps(summary, ensure_ascii=False, indent=2))
        for path in [LOG_PATH] + sorted(LOG_DIR.glob("*-client-*.log"))[-10:] + sorted(LOG_DIR.glob("server-diagnostic-*.json"))[-4:] + [BAD_PATH]:
            if not path.exists():
                continue
            with path.open("rb") as f:
                f.seek(max(0, path.stat().st_size - 1024 * 1024))
                content = f.read().decode("utf-8", errors="replace")
            for secret in secrets_to_hide:
                if secret:
                    content = content.replace(secret, "<redacted>")
            content = re.sub(r"(?i)(Bearer\s+)[A-Za-z0-9._~+/-]+", r"\1<redacted>", content)
            z.writestr("logs/" + path.name, content)
    print(f"Diagnostics saved: {dest}")
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(description=f"VultrVPNFinder {VERSION} for Windows 11")
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--retest-saved", action="store_true", help="Retest saved GOOD/near-good candidates; never create a new VPS")
    modes.add_argument("--check", action="store_true", help="Check dependencies/catalog/config without creating a VPS")
    modes.add_argument("--self-test", action="store_true", help="Run regression tests locally, without Vultr")
    modes.add_argument("--stop", action="store_true", help="Request a graceful stop of this folder's running finder")
    modes.add_argument("--diagnostics", action="store_true", help="Save logs and a credential-free state summary")
    args = parser.parse_args(argv)
    if args.self_test:
        import unittest
        suite = unittest.defaultTestLoader.discover(str(BASE / "tests"), pattern="test_*.py")
        if not suite.countTestCases():
            print("No regression tests found; extract the complete archive")
            return 1
        return 0 if unittest.TextTestRunner(verbosity=2).run(suite).wasSuccessful() else 1
    if args.diagnostics:
        return write_diagnostics()
    if args.stop:
        try:
            with RuntimeLock():
                print("VPNFinder is not running in this folder")
        except RuntimeError:
            STOP_PATH.write_text(now_iso(), encoding="utf-8")
            print("Stop requested; the finder will finish the current bounded operation and remove its temporary route")
        return 0
    finder = None
    try:
        with RuntimeLock():
            STOP_PATH.unlink(missing_ok=True)
            PID_PATH.write_text(str(os.getpid()), encoding="ascii")
            try:
                finder = Finder()
                if args.check:
                    finder.preflight(check_only=True)
                    candidate = finder.build_candidate(0, finder.cfg["regions"][0], finder.plan["id"])
                    finder.validate_server_config_local(candidate)
                    finder.startup_script_body(candidate)
                    log("CHECK PASSED: no VPS was created or deleted")
                    return 0
                return 0 if finder.main_loop(retest_saved=args.retest_saved) else 2
            except KeyboardInterrupt:
                log("STOPPED: candidates/credentials saved; run again to resume")
                return 130
            finally:
                try:
                    if finder and finder.current_ip:
                        finder.route_delete(finder.current_ip)
                except Exception as exc:
                    log(f"Temporary route cleanup failed; metadata preserved for next run: {exc}")
                PID_PATH.unlink(missing_ok=True)
                STOP_PATH.unlink(missing_ok=True)
    except Exception as exc:
        log(f"FATAL: {type(exc).__name__}: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
