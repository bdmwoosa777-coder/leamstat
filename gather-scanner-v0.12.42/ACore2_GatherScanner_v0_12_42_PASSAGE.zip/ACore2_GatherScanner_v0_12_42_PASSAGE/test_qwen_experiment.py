import base64,json,threading,time,tempfile,unittest
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
from http.server import HTTPServer,BaseHTTPRequestHandler
import cv2,numpy as np
from qwen_experiment import TemporalAdvisor,TemporalClient,Proposal,View,MODEL,validate,network_context
from test_hybrid import FRAME,route,scene
import test_hybrid as fixtures
from test_navigation import GatherFixture
from test_network_control import Source
from hybrid_engine import HybridGatherEngine
from flight import FlightReading
from navigation import Drive
from test_navigation import radar
from ground_routes import GroundMap

CTX={'mode':'resources','kind':'aether','goal_epoch':7,'camp_leg':None,'goal_bearing':90}
ANSWER={'bearing_offset':-29,'scene':'passage','obstacle':'rock','confidence':.9,'reason':'Open ground left of the rock'}

def host(answer=None):
 h=TemporalAdvisor({'ollama_autostart':False},lambda _:None)
 h.latest=Proposal(100,90,0,dict(CTX),dict(ANSWER if answer is None else answer),2000)
 return h

class Protocol(unittest.TestCase):
 def test_rejects_inputs_infinite_bearings_and_unbounded_text(self):
  for answer in ({**ANSWER,'buttons':['Y']},{**ANSWER,'confidence':True},{**ANSWER,'bearing_offset':float('nan')},
                 {**ANSWER,'bearing_offset':90},{**ANSWER,'confidence':-1},{**ANSWER,'scene':'fly'},
                 {**ANSWER,'obstacle':'teleport'},{**ANSWER,'reason':'a'*161},[]):
   with self.subTest(answer=answer),self.assertRaises(ValueError):validate(answer)
 def test_local_loopback_restriction_survives_experiment(self):
  for url in ('https://127.0.0.1:11434','http://example.org','http://127.0.0.1/x','http://user@127.0.0.1'):
   with self.assertRaises(ValueError):TemporalClient(url,MODEL)
 def test_real_http_stream_receives_history_minimap_and_disabled_thinking(self):
  captured={}
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*a):pass
   def do_POST(self):
    captured.update(json.loads(self.rfile.read(int(self.headers['Content-Length']))));captured['path']=self.path
    text=json.dumps(ANSWER);records=[{'message':{'content':text[:30]},'done':False},
     {'message':{'content':text[30:]},'done':True,'eval_count':45}]
    raw=b'\n'.join(json.dumps(r).encode() for r in records)+b'\n'
    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   c=TemporalClient('http://127.0.0.1:'+str(server.server_port),MODEL)
   frames=[View(t,90,0,CTX,FRAME.copy(),np.full((224,224,3),70,np.uint8)) for t in (100,101.5)]
   self.assertEqual(c.analyze_views(frames),ANSWER)
   self.assertEqual(captured['path'],'/api/chat');self.assertFalse(captured['think']);self.assertTrue(captured['stream'])
   images=captured['messages'][0]['images'];self.assertEqual(len(images),3)
   self.assertEqual(cv2.imdecode(np.frombuffer(base64.b64decode(images[-1]),np.uint8),1).shape,(224,224,3))
   self.assertIn('goal_epoch',captured['messages'][0]['content']);self.assertEqual(captured['keep_alive'],'30s')
   self.assertEqual(captured['options']['num_ctx'],4096)
  finally:server.shutdown();server.server_close();thread.join()
 def test_empty_thinking_only_reply_is_an_error_not_an_action(self):
  c=TemporalClient(model=MODEL);c.call=lambda *a,**kw:{'message':{'thinking':'some text'},'done_reason':'length'}
  with self.assertRaisesRegex(ValueError,'Empty Qwen'):c.analyze_views([View(100,90,0,CTX,FRAME,None)])
 def test_incomplete_schema_is_never_interpreted_as_a_default_move(self):
  c=TemporalClient(model=MODEL);c.call=lambda *a,**kw:{'message':{'content':'{"scene":"open"}'}}
  with self.assertRaises(ValueError):c.analyze_views([View(100,90,0,CTX,FRAME,None)])

class FreshDetours(unittest.TestCase):
 def test_delayed_world_bearing_maps_onto_new_route_id(self):
  h=host();ground=GroundMap((route(90,.2),route(91,.8)),100)
  self.assertEqual(h.recommend(ground,FRAME,103,90,0,CTX),90)
  # After a small camera turn, project onto a different connected route.
  self.assertEqual(h.recommend(GroundMap((route(32,.4),),100),FRAME,104,70,0,CTX),32)
 def test_changed_resource_of_same_kind_revokes_reply(self):
  self.assertIsNone(host().recommend(scene().ground,FRAME,103,90,0,{**CTX,'goal_epoch':8}))
 def test_camp_replan_revokes_prior_exit(self):
  h=host();h.latest=replace(h.latest,context={**CTX,'mode':'camp_exit','camp_leg':1})
  self.assertIsNone(h.recommend(scene().ground,FRAME,103,90,0,{**CTX,'mode':'camp_exit','camp_leg':2}))
 def test_unknown_heading_and_major_camera_change_revoke_reply(self):
  for heading,pitch in ((None,0),(140,0),(90,.05)):
   with self.subTest(heading=heading):self.assertIsNone(host().recommend(scene().ground,FRAME,103,heading,pitch,CTX))
 def test_reply_older_than_eight_seconds_is_never_executed(self):
  self.assertIsNone(host().recommend(scene().ground,FRAME,108.01,90,0,CTX))
 def test_ground_wall_drop_and_removed_route_revoke_old_advice(self):
  for ground in (None,GroundMap(),replace(scene().ground,drop_support=.04),GroundMap((route(1,.8),),100)):
   self.assertIsNone(host().recommend(ground,FRAME,103,90,0,CTX))
 def test_low_confidence_and_negative_model_scene_do_not_override_navigation(self):
  for answer in ({**ANSWER,'confidence':.4},{**ANSWER,'scene':'unknown'},{**ANSWER,'scene':'possible_drop'},{**ANSWER,'obstacle':'drop'}):
   self.assertIsNone(host(answer).recommend(scene().ground,FRAME,103,90,0,CTX))
 def test_previously_failed_bearing_is_not_reintroduced(self):
  self.assertIsNone(host().recommend(scene().ground,FRAME,103,90,0,{**CTX,'failed_bearings':[61]}))
 def test_large_observed_translation_invalidates_old_viewpoint(self):
  h=host();h.latest=replace(h.latest,context={**CTX,'position':[0,0]});h.position=[13,0]
  self.assertIsNone(h.recommend(scene().ground,FRAME,103,90,0,CTX))
 def test_goal_rotation_revokes_route_to_old_target_position(self):
  self.assertIsNone(host().recommend(scene().ground,FRAME,103,90,0,{**CTX,'goal_bearing':150}))
 def test_advice_cannot_run_for_more_than_three_seconds(self):
  h=host();self.assertEqual(h.recommend(scene().ground,FRAME,103,90,0,CTX),0)
  h.executed(0,103,90,CTX)
  self.assertIsNone(h.recommend(scene().ground,FRAME,106.01,90,0,CTX))
 def test_model_warning_never_creates_global_stop(self):
  h=host({**ANSWER,'scene':'possible_drop'})
  self.assertIsNone(h.warning(103,90,0,CTX))
 def test_no_feedback_claim_until_local_planner_selects_the_route(self):
  h=host();h.recommend(scene().ground,FRAME,103,90,0,CTX)
  self.assertIsNone(h.active_trial)
  h.executed(99,103,90,CTX);self.assertIsNone(h.active_trial)
  h.executed(0,103,90,CTX);self.assertIsNotNone(h.active_trial)
 def test_measured_stall_is_returned_as_feedback_and_revokes_proposal(self):
  h=host();h.recommend(scene().ground,FRAME,103,90,0,CTX);h.executed(0,103,90,CTX)
  r=radar();r.motion_valid=True;r.displacement=(0,0)
  for t in (103,103.7,104.4,105.1,105.8,106.1):h.feedback(r,t,CTX)
  self.assertEqual(h.trials[-1]['outcome'],'no_progress');self.assertIs(h.rejected,h.latest)
  self.assertIsNone(h.recommend(scene().ground,FRAME,106.1,90,0,CTX))
 def test_measured_translation_is_success_not_a_fake_gather_result(self):
  h=host();h.recommend(scene().ground,FRAME,103,90,0,CTX);h.executed(0,103,90,CTX)
  r=radar();r.motion_valid=True;r.displacement=(1,0)
  for t in (103,103.7,104.4,105.1,105.8,106.1):h.feedback(r,t,CTX)
  self.assertEqual(h.trials[-1]['outcome'],'progress');self.assertNotIn('gather',h.trials[-1])
 def test_unmeasured_gaps_are_not_falsely_counted_as_stuck(self):
  h=host();h.recommend(scene().ground,FRAME,103,90,0,CTX);h.executed(0,103,90,CTX)
  r=radar();r.motion_valid=True;r.displacement=(0,0);h.feedback(r,107,CTX)
  self.assertEqual(h.trials[-1]['outcome'],'unmeasured')

class BoundedHost(unittest.TestCase):
 def test_sampler_has_only_two_small_world_frames_and_resets_for_new_goal(self):
  h=host()
  for i in range(20):h.observe(FRAME,100+i,90,0,CTX,(500,0,640,140))
  self.assertEqual(len(h.history),2);self.assertLessEqual(h.history[-1].world.shape[1],768)
  self.assertEqual(h.history[-1].minimap.shape,(224,224,3))
  self.assertEqual(int(h.history[-1].world[10,10,0]),int(FRAME[10,10,0]))
  h.observe(FRAME,120,90,0,{**CTX,'goal_epoch':8},(500,0,640,140))
  self.assertEqual(len(h.history),1)
 def test_out_of_bounds_minimap_does_not_crash_capture(self):
  h=host();h.observe(FRAME,100,90,0,CTX,(-10,-20,9999,9999));self.assertIsNotNone(h.history[-1].minimap)
  h.observe(FRAME,101,90,0,CTX,(1000,1000,2000,2000));self.assertIsNone(h.history[-1].minimap)
 def test_busy_model_does_not_block_caller_or_queue_new_threads(self):
  h=host();began=threading.Event();release=threading.Event()
  class Client:
   model=MODEL
   def __init__(self,*a):pass
   def probe(self):pass
   def analyze_views(self,views):began.set();release.wait(2);raise TimeoutError('test slow inference')
  h.client_factory=Client;h.observe(FRAME,time.monotonic(),90,0,CTX,(500,0,640,140))
  try:
   t=time.monotonic();self.assertTrue(h.offer(FRAME,None,t,90,0,CTX));self.assertLess(time.monotonic()-t,.2)
   self.assertTrue(began.wait(1));worker=h.worker
   self.assertFalse(h.offer(FRAME,None,time.monotonic()+6,90,0,CTX));self.assertIs(h.worker,worker)
  finally:release.set();h.worker.join(2)
  self.assertFalse(h.busy);self.assertIsNotNone(h.error)
 def test_late_reply_is_reported_and_not_mistaken_for_ready_ai(self):
  h=host();clock=[100.]
  class Client:
   model=MODEL
   def __init__(self,*a):pass
   def probe(self):pass
   def analyze_views(self,v):clock[0]+=9;return dict(ANSWER)
  h.client_factory=Client
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   h.observe(FRAME,100,90,0,CTX,(500,0,640,140));h.offer(FRAME,None,100,90,0,CTX);h.worker.join(2)
  self.assertFalse(h.ready);self.assertIsNone(h.latest);self.assertIn('8',h.error);self.assertEqual(h.late_replies,1)
 def test_three_late_responses_unload_and_back_off_instead_of_wasting_gpu(self):
  h=host();clock=[100.];unloaded=[]
  class Client:
   model=MODEL
   def __init__(self,*a):pass
   def probe(self):pass
   def analyze_views(self,v):clock[0]+=9;return dict(ANSWER)
   def unload(self):unloaded.append(True)
  h.client_factory=Client
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   for _ in range(3):
    h.observe(FRAME,clock[0],90,0,CTX,(500,0,640,140));h.offer(FRAME,None,clock[0],90,0,CTX);h.worker.join(2);clock[0]+=1
  self.assertEqual(unloaded,[True]);self.assertGreater(h.retry_at,clock[0]+50);self.assertFalse(h.busy)
 def test_failed_request_preserves_local_controller_and_backs_off(self):
  h=host();h.client_factory=lambda *a:(_ for _ in ()).throw(RuntimeError('model absent'))
  now=time.monotonic();h.observe(FRAME,now,90,0,CTX,(500,0,640,140));h.offer(FRAME,None,now,90,0,CTX);h.worker.join(2)
  self.assertFalse(h.busy);self.assertIn('model absent',h.error);self.assertGreater(h.retry_at,now)
  self.assertFalse(h.offer(FRAME,None,now,90,0,CTX))
 def test_close_with_inflight_request_discards_answer_and_unloads_after_completion(self):
  h=host();began=threading.Event();release=threading.Event();unloaded=threading.Event()
  class Client:
   model=MODEL
   def __init__(self,*a):pass
   def probe(self):pass
   def analyze_views(self,v):began.set();release.wait(2);return dict(ANSWER)
   def unload(self):unloaded.set()
  h.client_factory=Client;now=time.monotonic();h.observe(FRAME,now,90,0,CTX,(500,0,640,140))
  with patch.object(Path,'write_text'):
   h.offer(FRAME,None,now,90,0,CTX);self.assertTrue(began.wait(1));h.close();release.set();h.worker.join(2)
  self.assertTrue(unloaded.is_set());self.assertIsNone(h.latest)
 def test_recent_feedback_is_bounded(self):
  h=host()
  for i in range(40):h.trials.append({'outcome':'progress','bearing':i})
  self.assertEqual(len(h.trials),12)

class OwnNetworkFacts(unittest.TestCase):
 def test_no_identity_means_no_assumed_own_events(self):
  self.assertEqual(network_context({'ready':True,'identity_ready':False}),{'ready':False})
 def test_context_includes_only_current_own_facts_without_actor_ids(self):
  state=SimpleNamespace(last_packet=10000,attacks={999:9500,888:1000},last_own_result=(123,9000),collecting=None,
    attempt_active=False,hp=80,maximum=100)
  data=network_context({'ready':True,'identity_ready':True,'state':state})
  self.assertEqual(data['recent_attackers'],1);self.assertEqual(data['hp_fraction'],.8)
  self.assertEqual(data['last_gather_result_age_s'],1);self.assertNotIn('999',json.dumps(data));self.assertNotIn('123',json.dumps(data))

class UserSideCheck(unittest.TestCase):
 def test_checker_uses_real_client_protocol_then_unloads_and_reports_limits(self):
  from check_qwen_experiment import check
  class Client:
   model=MODEL;unloaded=False
   def probe(self):return {'capabilities':['vision']}
   def analyze_views(self,views,timeout):self.views=views;return dict(ANSWER)
   def call(self,path,**kw):return {'models':[{'name':MODEL,'size_vram':8000000000}]} if path=='/api/ps' else {'version':'0.12.7'}
   def unload(self):self.unloaded=True
  c=Client()
  with tempfile.TemporaryDirectory() as tmp,patch('builtins.print'):
   data=check({},Path(tmp),c)
   self.assertTrue(data['valid_answer']);self.assertTrue(data['gpu_resident']);self.assertTrue(c.unloaded)
   self.assertFalse(data['navigation_quality_tested']);self.assertEqual(len(c.views),2)
   self.assertEqual(len(list(Path(tmp).iterdir())),1)
 def test_checker_unloads_even_after_inference_error(self):
  from check_qwen_experiment import check
  class Client:
   model=MODEL;unloaded=False
   def probe(self):return {'capabilities':['vision']}
   def call(self,*a,**kw):return {}
   def analyze_views(self,*a,**kw):raise RuntimeError('GPU out of memory')
   def unload(self):self.unloaded=True
  c=Client()
  with tempfile.TemporaryDirectory() as tmp,patch('builtins.print'):data=check({},Path(tmp),c)
  self.assertFalse(data['valid_answer']);self.assertTrue(c.unloaded);self.assertIn('memory',data['error'])

class Integration(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();bridge=self.e.bridge;screen=self.e.screen
  self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e=HybridGatherEngine({**self.e.cfg,'scene_navigation_enabled':True,'analyzer_enabled':True,'qwen_temporal_enabled':True},self.log.append,self.input,network=self.source)
  self.e.bridge=bridge;self.e.screen=screen;self.e.mode='SEARCH'
  self.e.scene_host=SimpleNamespace(offer=lambda *a:None,current=lambda *a:None,error=None,close=lambda:None)
  self.e.analyzer=TemporalAdvisor({'ollama_autostart':False},self.log.append)
  self.e.analyzer.offer=lambda *a:False
 def plan(self,reading=None,now=100):
  if reading is not None:self.e.scene_host.current=lambda *a:reading
  with patch('hybrid_engine.time.monotonic',return_value=now):return self.e._scene_plan(self.frame,radar(),FlightReading(None,False),Drive(.78),now)
 def test_model_context_reaches_camp_even_while_local_scene_is_missing(self):
  from camp_departure import CampDeparture
  self.e.camp_exit_until=130;self.e.camp_route=CampDeparture((100,100),(100,100),200,100)
  self.plan(now=100)
  self.assertEqual(len(self.e.analyzer.history),1)
  self.assertEqual(self.e.analyzer.history[-1].context['mode'],'camp_exit')
 def test_temporal_model_advice_causes_real_engine_strafe_without_replacing_goal(self):
  h=self.e.analyzer
  ctx={**CTX,'kind':None,'goal_epoch':self.e.nav.goal_epoch,'goal_bearing':None}
  h.latest=replace(h.latest,context=ctx) if h.latest else Proposal(100,90,0,ctx,dict(ANSWER),2000)
  # Fixture heading is 0; use a matching proposal, otherwise reject correctly.
  from test_navigation import radar
  heading=radar().heading;h.latest=replace(h.latest,heading=heading)
  drive=self.plan(scene(free=.95),100)
  self.assertLess(drive.strafe,-.2);self.assertIsNotNone(h.active_trial)
  self.assertTrue(any('QWEN_APPLY' in x for x in self.log))
 def test_valid_adviser_reply_is_not_used_during_own_gathering(self):
  self.e.resource_hold=True;self.e.mode='GATHER'
  self.e.analyzer.observe=lambda *a:(_ for _ in ()).throw(AssertionError('VLM during gather'))
  self.assertEqual(self.plan(scene(),100).forward,.78)
 def test_experiment_error_does_not_suppress_normal_minimap_movement(self):
  self.e.analyzer.error='GPU out of memory';self.e.analyzer.busy=True
  self.assertGreater(self.plan(now=100).forward,.5)
 def test_stale_reply_does_not_override_fresh_direct_ground_course(self):
  ctx={**CTX,'kind':None,'goal_epoch':self.e.nav.goal_epoch,'goal_bearing':None}
  self.e.analyzer.latest=Proposal(90,radar().heading,0,ctx,dict(ANSWER),9000)
  drive=self.plan(scene(free=.95),100)
  self.assertGreater(drive.forward,.5);self.assertEqual(drive.strafe,0)
  self.assertIsNone(self.e.analyzer.active_trial)
 def test_pending_advice_keeps_immediate_network_defense_available(self):
  self.e.analyzer.busy=True
  self.source.state.attacks[55]=1000;self.source.state.npcs[55]={'time':900,'born_at':900}
  with patch('gather_engine.time.time',return_value=1.1),patch.object(self.e.screen,'frame',side_effect=AssertionError('capture before urgent hit')):
   self.assertTrue(self.e._priority_network_defense(100))
  self.assertEqual(self.e.mode,'DEFENSE');self.assertIsNotNone(self.e.network_defense)

class ExperimentSetup(unittest.TestCase):
 def run_setup(self,report):
  import setup_analyzer as setup
  from contextlib import ExitStack
  cfg={'analyzer_enabled':False,'qwen_temporal_enabled':True,'qwen_model':MODEL}
  class Client:
   def __init__(self,*a,**kw):pass
   def call(self,*a,**kw):return {'version':'0.12.7'}
  with tempfile.TemporaryDirectory() as tmp,ExitStack() as stack:
   path=Path(tmp)/'settings_gather.json';path.write_text(json.dumps(cfg))
   for owner,name,value in ((setup,'ROOT',Path(tmp)),(setup,'CFG',cfg),(setup,'TEMPORAL',True),(setup,'MODEL',MODEL)):
    stack.enter_context(patch.object(owner,name,value))
   stack.enter_context(patch.object(setup,'find_ollama',return_value='ollama.exe'))
   run=stack.enter_context(patch.object(setup.subprocess,'run'))
   stack.enter_context(patch('hybrid_navigation.RouteClient',Client))
   stack.enter_context(patch('check_qwen_experiment.check',return_value=report))
   stack.enter_context(patch('builtins.print'))
   status=setup.main();saved=json.loads(path.read_text())
   self.assertEqual(run.call_args.args[0],['ollama.exe','pull',MODEL])
   return status,saved
 def test_setup_enables_experiment_only_after_warm_gpu_check(self):
  status,cfg=self.run_setup({'valid_answer':True,'warm_reply_within_use_window':True,'gpu_resident':True})
  self.assertEqual(status,0);self.assertTrue(cfg['analyzer_enabled'])
 def test_setup_does_not_enable_slow_model(self):
  status,cfg=self.run_setup({'valid_answer':True,'warm_reply_within_use_window':False,'gpu_resident':True})
  self.assertEqual(status,1);self.assertFalse(cfg['analyzer_enabled'])
 def test_setup_does_not_enable_cpu_only_response(self):
  status,cfg=self.run_setup({'valid_answer':True,'warm_reply_within_use_window':True,'gpu_resident':False})
  self.assertEqual(status,1);self.assertFalse(cfg['analyzer_enabled'])

class DiagnosticDispatch(unittest.TestCase):
 def test_route_checker_uses_the_experiment_instead_of_silently_checking_old_qwen(self):
  import check_hybrid
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);(root/'settings_gather.json').write_text(json.dumps({'qwen_temporal_enabled':True}))
   with patch.object(check_hybrid,'__file__',str(root/'check_hybrid.py')),patch('check_qwen_experiment.main',return_value=0) as check:
    self.assertEqual(check_hybrid.main(),0);check.assert_called_once_with()
 def test_user_check_matches_runtime_image_count_including_minimap(self):
  from check_qwen_experiment import synthetic_views
  views=synthetic_views();self.assertEqual(len(views),2)
  self.assertIsNotNone(views[-1].minimap);self.assertEqual(views[-1].minimap.shape,(224,224,3))
