"""Session time, ended attempts and actual inventory gains are distinct counters."""
from collections import Counter,OrderedDict
import threading,time
from inventory_stats import InventoryTracker,catalogue
from spatial import resource_names

class GatherStats:
 def __init__(self):
  self.lock=threading.RLock();self.elapsed=0.;self.running=None;self.wall_from=0
  self.counts=Counter();self.finished=Counter();self.items=Counter();self.families=Counter()
  self.seen=OrderedDict();self.trackers={};self.results=[];self.pending=[]
  self.incomplete=False;self.current_flow=None
 def start(self,now=None,wall=None):
  now=time.monotonic() if now is None else now;wall=int(time.time()*1000) if wall is None else wall
  with self.lock:
   if self.running is None:self.running=now;self.wall_from=wall;self.results.clear();self.pending.clear()
 def pause(self,now=None):
  now=time.monotonic() if now is None else now
  with self.lock:
   if self.running is not None:self.elapsed+=max(0,now-self.running);self.running=None
   self.results.clear();self.pending.clear()
 def capture_gap(self):
  with self.lock:
   self.trackers.clear();self.results.clear();self.pending.clear();self.current_flow=None
   if self.running is not None:self.incomplete=True
 def reset(self,now=None,wall=None):
  with self.lock:
   active=self.running is not None;self.running=None;self.elapsed=0.
   # UI reset clears totals, not protocol duplicate protection.
   self.counts.clear();self.finished.clear();self.items.clear();self.families.clear()
   self.results.clear();self.pending.clear();self.incomplete=False
   if active:self.start(now,wall)
 def _consume(self,events,state):
  if not events or state is None or state.own is None or self.running is None:return
  names=resource_names();_,_,templates=catalogue()
  for e in events:
   if e.get('kind')!='own_attempt_ended' or e.get('t',0)<self.wall_from or e.get('used') not in (1,2,3):continue
   actor=e['actor'];node=state.nodes.get(actor)
   if node is None or actor in state.npcs or actor in state.players:continue
   key=(e.get('flow'),state.own,state.map_id,actor,node.generation,node.gather_time,e['used'])
   if key in self.seen:continue
   self.seen[key]=None
   if len(self.seen)>8192:self.seen.popitem(last=False)
   label=names.get(node.template) or 'Неопределённый ресурс';self.counts[label]+=1
   if e['used']==3:self.finished[label]+=1
   family=templates.get(node.template)
   if family:self.results.append((e.get('flow'),family,e['t']))
 def consume(self,events,state):
  with self.lock:self._consume(events,state)
 def feed_frame(self,flow,op,body,stamp,events,state):
  with self.lock:
   self.current_flow=flow
   tracker=self.trackers.get(flow)
   if tracker is None:
    tracker=self.trackers[flow]=InventoryTracker()
    if len(self.trackers)>8:self.trackers.pop(next(iter(self.trackers)))
   owner=getattr(state,'own',None)
   if ((tracker.state is not None and tracker.state is not state)
       or tracker.owner is not None and owner is not None and tracker.owner!=owner):
    self.results=[r for r in self.results if r[0]!=flow]
    self.pending=[p for p in self.pending if p[0]!=flow]
    if self.running is not None:self.incomplete=True
   gains,unknown,baseline=tracker.feed(op.lower(),body,stamp,state)
   self._consume(events,state)
   if self.running is None or stamp<self.wall_from:return
   if unknown:self.incomplete=True
   self.results=[r for r in self.results if stamp-r[2]<=2000][-64:]
   self.pending=[p for p in self.pending if stamp-p[3]<=2000][-256:]
   self.pending.extend((flow,item,amount,t) for item,amount,t in gains)
   _,materials,_=catalogue();keep=[]
   for f,item,amount,t in self.pending:
    family=materials[item]['family']
    if any(f==r[0] and family==r[1] and abs(t-r[2])<=2000 for r in self.results):
     self.items[materials[item]['name']]+=amount;self.families[family]+=amount
    else:keep.append((f,item,amount,t))
   self.pending=keep[-256:]
 def snapshot(self,now=None):
  now=time.monotonic() if now is None else now
  with self.lock:
   seconds=self.elapsed+(max(0,now-self.running) if self.running is not None else 0)
   total=sum(self.items.values());tracker=self.trackers.get(self.current_flow)
   return {'seconds':seconds,'running':self.running is not None,'counts':dict(self.counts),
           'finished':dict(self.finished),'attempts':sum(self.counts.values()),'nodes':sum(self.finished.values()),
           'items':dict(self.items),'families':dict(self.families),'quantity':total,
           'baseline':bool(tracker and tracker.listed),'incomplete':self.incomplete,
           'per_minute':total*60/seconds if seconds>0 else 0}
 def describe(self,now=None):
  s=self.snapshot(now);seconds=int(s['seconds']);h=seconds//3600;m=seconds//60%60;sec=seconds%60
  items='; '.join(name+' — '+str(value) for name,value in sorted(s['items'].items())) or 'пока нет'
  status=('неполный итог: исходные количества/пакеты были пропущены' if s['incomplete'] else
          'исходный инвентарь получен' if s['baseline'] else 'ожидаю исходный инвентарь; показан подтверждённый минимум')
  return (f'Время бота: {h:02}:{m:02}:{sec:02} | Предметов: {s["quantity"]} | '
          f'{s["per_minute"]:.2f}/мин | Завершённых попыток: {s["attempts"]}\n'+items+'\nСчётчик: '+status)
