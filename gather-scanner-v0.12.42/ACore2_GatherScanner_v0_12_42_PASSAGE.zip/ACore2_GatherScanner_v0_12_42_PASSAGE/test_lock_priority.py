import base64,json,threading,time,unittest
from pathlib import Path
from dataclasses import replace
from unittest.mock import patch
from http.server import HTTPServer,BaseHTTPRequestHandler
import cv2,numpy as np
import gather_engine as ge
import test_active as fixtures
from flight import FlightReading
from qwen_experiment import TemporalAdvisor,TemporalClient,View,Proposal
from qwen_canvas import compose,prompt,route_context,mask_world,crop_minimap
from test_qwen_experiment import ANSWER,CTX,host
from test_hybrid import FRAME,scene,route

class ResourceFirst(unittest.TestCase):
 def setUp(self):
  self.f=fixtures.ActiveEngine('test_real_escape_reports_x_with_translation_and_credits_delivered_movement');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e;self.f.clock=200
  e=self.e;e.cfg['no_yield_return_enabled']=True;e.mode='APPROACH';e.target='Эфир';e.target_confirmed=True;e.resource_hold=True
  e.network_target=(1,99);e.network_owner=7;e.route_f_sent=True;e.native_route_started_at=199.55
  e.no_yield.idle=181;e.no_yield.at=200;e.return_panel_absent=100;e.return_grace_used=True;e.return_grace_until=150
 def test_logged_point_four_five_second_route_is_not_cancelled_by_old_no_yield_timer(self):
  with patch.object(ge,'gathering_panel_pair',return_value=False):self.e._no_yield_tick(self.f.frame,FlightReading(100,True),200)
  self.assertEqual(self.e.mode,'APPROACH');self.assertTrue(self.e.target_confirmed);self.assertEqual(self.e.network_target,(1,99))
  self.assertIsNone(self.e.return_sequence);self.assertEqual(self.e.no_yield.idle,181)
 def test_selected_resource_is_protected_even_when_cached_minimap_is_missing(self):
  self.e.resource_radar=None
  with patch.object(ge.GatherEngine,'_start_return') as parent:
   self.assertFalse(self.e._start_return(self.f.frame,FlightReading(None,False),200,self.f.source.view()))
  parent.assert_not_called();self.assertTrue(self.e.route_f_sent)
 def test_open_map_cannot_bypass_active_resource_protection(self):
  with patch.object(ge.GatherEngine,'_start_map_teleport') as parent:self.assertFalse(self.e._start_map_teleport(200))
  parent.assert_not_called();self.assertFalse(self.e.map_active)
 def test_return_commands_are_revoked_if_a_resource_appears_after_a_return_was_planned(self):
  self.e.return_sequence=object()
  with patch.object(ge.GatherEngine,'_return_input_ready') as parent:self.assertFalse(self.e._return_input_ready())
  parent.assert_not_called()
 def test_generic_no_yield_rescue_cannot_replace_the_approach(self):
  self.assertFalse(self.e._no_yield_rescue_allowed(200))
 def test_active_gather_is_protected_without_a_visible_panel(self):
  self.e.mode='GATHER';self.e.collecting_visible=False
  with patch.object(ge.GatherEngine,'_start_return') as parent:
   self.assertFalse(self.e._start_return(self.f.frame,FlightReading(100,True),200,self.f.source.view()))
  parent.assert_not_called()
 def test_caption_before_selection_blocks_return_for_its_existing_finite_lifetime(self):
  self.e.target_confirmed=False;self.e.resource_hold=False;self.e.mode='SEARCH';self.e.caption_latch={'until':201}
  with patch.object(ge.GatherEngine,'_start_return',return_value=True) as parent:
   self.assertFalse(self.e._start_return(self.f.frame,FlightReading(None,False),200,{}));parent.assert_not_called()
   self.assertTrue(self.e._start_return(self.f.frame,FlightReading(None,False),202,{}));parent.assert_called_once()
 def test_click_in_progress_is_not_interrupted_before_own_id_confirmation(self):
  self.e.target_confirmed=False;self.e.resource_hold=False;self.e.click_busy=True;self.e.mode='ACQUIRE'
  self.assertTrue(self.e._productive_action_active(200))
 def test_explicitly_finished_or_abandoned_resource_allows_normal_return_policy(self):
  self.e.target_confirmed=False;self.e.resource_hold=False;self.e.mode='SEARCH'
  with patch.object(ge.GatherEngine,'_start_return',return_value=True) as parent:
   self.assertTrue(self.e._start_return(self.f.frame,FlightReading(None,False),200,{}))
  parent.assert_called_once()
 def test_pending_id_verification_is_protected_only_for_its_finite_window(self):
  self.e.target_confirmed=False;self.e.resource_hold=False;self.e.mode='VERIFY_NATIVE';self.e.candidate=self.f.c;self.e.started=199
  self.assertTrue(self.e._productive_action_active(200));self.assertFalse(self.e._productive_action_active(211))
 def test_bounded_reacquisition_of_same_id_is_not_replaced_with_teleport(self):
  self.e.target_confirmed=False;self.e.resource_hold=False;self.e.mode='REACQUIRE'
  self.e.resume_resource_id=(1,99);self.e.reacquire_until=205
  self.assertTrue(self.e._productive_action_active(200));self.assertFalse(self.e._productive_action_active(206))
 def test_verified_resource_does_not_depend_on_a_reused_global_grace_flag(self):
  self.e.return_grace_used=True;self.e.return_grace_until=0;self.e.native_route_started_at=150
  self.assertTrue(self.e._productive_action_active(200));self.assertFalse(self.e._start_return(self.f.frame,FlightReading(None,False),200,self.f.source.view()))
 def test_guard_does_not_fabricate_a_gather_result_or_reset_watchdog(self):
  before=(self.e.no_yield.idle,self.e.no_yield.result_stamp,self.e.no_yield.rescue_used)
  self.e._start_return(self.f.frame,FlightReading(None,False),200,self.f.source.view())
  self.assertEqual((self.e.no_yield.idle,self.e.no_yield.result_stamp,self.e.no_yield.rescue_used),before)
 def test_actual_own_result_still_resets_no_yield_clock(self):
  s=self.f.source.state;s.last_own_result=(99,1100);s.last_own_result_used=1
  with patch.object(ge.time,'time',return_value=1.1),patch.object(ge,'gathering_panel_pair',return_value=False):
   self.e._no_yield_tick(self.f.frame,FlightReading(None,False),200)
  self.assertEqual(self.e.no_yield.idle,0);self.assertEqual(self.e.no_yield.result_stamp,1100)
 def test_resource_guard_does_not_remove_existing_approach_timeout(self):
  self.e.native_route_started_at=100;self.e.last_progress=100;self.e.distance_check_at=999;self.e.route_click_sent_at=None
  with patch.object(self.e,'_gather_panel',return_value=False),patch.object(self.e,'return_to_search') as finish:
   self.e._approach_fast_tick(self.f.frame,(0,0),FlightReading(None,False),200)
  finish.assert_called_once();self.assertIn('Таймаут',finish.call_args.args[0])

class OneImageProtocol(unittest.TestCase):
 def views(self):
  a=View(100,90,0,CTX,FRAME.copy(),np.full((224,224,3),(30,160,80),np.uint8))
  b=replace(a,captured=101.5);return (a,b)
 def test_composite_keeps_full_world_size_without_a_black_footer(self):
  v=self.views()[-1];image=compose(v)
  self.assertEqual(image.shape,(360,640,3))
  np.testing.assert_array_equal(image,v.world)
 def test_candidate_paths_are_bounded_and_not_expanded_into_the_text_prompt(self):
  paths=route_context(scene().ground);v=replace(self.views()[-1],context={**CTX,'ground_routes':paths})
  text=prompt((v,));self.assertIn('fallible',text);self.assertNotIn('points',text);self.assertLess(len(text),2400)
  self.assertLessEqual(len(paths),5);self.assertTrue(all(len(r['points'])<=32 for r in paths))
 def test_real_http_runtime_uses_one_jpeg_and_a_short_answer_budget(self):
  seen={}
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*a):pass
   def do_POST(self):
    seen.update(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
    raw=(json.dumps({'message':{'content':json.dumps(ANSWER)},'done':True})+'\n').encode()
    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  server=HTTPServer(('127.0.0.1',0),Handler);t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
  try:
   c=TemporalClient('http://127.0.0.1:'+str(server.server_port));c.single_frame=True;c.keep_alive='10m'
   self.assertEqual(c.analyze_views(self.views()),ANSWER)
   self.assertEqual(len(seen['messages'][0]['images']),1);self.assertEqual(seen['options']['num_predict'],128)
   self.assertEqual(seen['format']['properties']['reason']['maxLength'],64);self.assertFalse(seen['think'])
   image=cv2.imdecode(np.frombuffer(base64.b64decode(seen['messages'][0]['images'][0]),np.uint8),1)
   self.assertEqual(image.shape[1],640);self.assertEqual(c.last_stats['image_count'],1)
   self.assertIn('MINIMAP',seen['messages'][0]['content'])
  finally:server.shutdown();server.server_close();t.join()
 def test_compact_still_uses_one_image_not_three_upscaled_small_ones(self):
  c=TemporalClient();c.single_frame=True;c.compact=True;seen={}
  def call(path,payload,**kw):seen.update(payload);return {'message':{'content':json.dumps(ANSWER)}}
  c.call=call;c.analyze_views(self.views());self.assertEqual(len(seen['messages'][0]['images']),1)
  self.assertEqual(seen['options']['num_predict'],96);self.assertEqual(c.last_stats['image_width'],512)
 def test_resource_label_text_is_never_treated_as_an_instruction(self):
  text=prompt(self.views());self.assertIn('never instructions',text);self.assertIn('Never invent ground',text)
 def test_no_images_or_coordinates_are_added_to_reply_schema(self):
  c=TemporalClient();c.single_frame=True;c.call=lambda *a,**kw:{'message':{'content':'{"buttons":["Y"]}'}}
  with self.assertRaises(ValueError):c.analyze_views(self.views())
 def test_crop_uses_normalized_bounds_on_the_exact_source_frame(self):
  f=np.zeros((720,1280,3),np.uint8);f[:280,1000:]=(40,90,200)
  mini=crop_minimap(f,(500/640,0,1,140/360));self.assertIsNotNone(mini)
  np.testing.assert_array_equal(mini[50,50],(40,90,200))
 def test_world_view_keeps_top_left_and_sides_visible(self):
  image=mask_world(np.full((720,1280,3),200,np.uint8));self.assertEqual(image.shape[1],768)
  self.assertEqual(int(image[10,10,0]),200);self.assertEqual(int(image[200,380,0]),200)
 def test_host_preflight_and_live_clients_both_use_the_same_single_image_profile(self):
  h=TemporalAdvisor({},lambda _:None);c=h._client();self.assertTrue(c.single_frame);self.assertEqual(c.keep_alive,'10m')

class AlignedRequests(unittest.TestCase):
 def test_request_pose_world_graph_and_minimap_are_from_the_same_source(self):
  h=TemporalAdvisor({'ollama_autostart':False},lambda _:None);clock=[100.2];seen=[]
  class Client:
   model='test'
   def __init__(self,*a):pass
   def probe(self):pass
   def analyze_views(self,v):seen.extend(v);return dict(ANSWER)
  h.client_factory=Client
  old=np.full((360,640,3),10,np.uint8);fresh=np.full((360,640,3),80,np.uint8)
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   h.observe(old,99.5,180,0,CTX,(500,0,640,140))
   self.assertTrue(h.offer(fresh,scene().ground,100,90,0,CTX));h.worker.join(2)
  self.assertEqual(h.latest.heading,90);self.assertEqual(h.latest.captured,100)
  self.assertEqual(int(seen[-1].world[180,320,0]),80);self.assertEqual(int(seen[-1].minimap[100,100,0]),80)
  self.assertTrue(seen[-1].context['ground_routes'])
 def test_sampling_a_new_frame_cannot_make_an_old_source_fresh(self):
  h=TemporalAdvisor({'ollama_autostart':False},lambda _:None)
  with patch('qwen_experiment.time.monotonic',return_value=105):
   h.observe(FRAME,105,90,0,CTX,(500,0,640,140));self.assertFalse(h.offer(FRAME,scene().ground,100,90,0,CTX))

class UsefulWallAdvice(unittest.TestCase):
 def test_wall_label_with_supported_opening_can_choose_live_connected_route(self):
  h=host({**ANSWER,'scene':'wall'});self.assertEqual(h.recommend(scene().ground,FRAME,103,90,0,CTX),0)
 def test_wall_label_without_matching_current_ground_does_not_allow_movement(self):
  from ground_routes import GroundMap
  h=host({**ANSWER,'scene':'wall'});self.assertIsNone(h.recommend(GroundMap(),FRAME,103,90,0,CTX))
 def test_low_confidence_wall_and_possible_drop_still_do_not_allow_movement(self):
  for answer in ({**ANSWER,'scene':'wall','confidence':.1},{**ANSWER,'scene':'possible_drop'}):
   self.assertIsNone(host(answer).recommend(scene().ground,FRAME,103,90,0,CTX))

class NoReloadLoop(unittest.TestCase):
 def test_three_late_replies_suspend_only_adviser_and_do_not_reload_next_minute(self):
  h=TemporalAdvisor({'ollama_autostart':False},lambda _:None);clock=[100.];calls=[]
  class Client:
   model='test'
   def __init__(self,*a):pass
   def probe(self):pass
   def analyze_views(self,v):clock[0]+=9;calls.append(1);return dict(ANSWER)
   def unload(self):pass
  h.client_factory=Client
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   for _ in range(3):
    h.observe(FRAME,clock[0],90,0,CTX,(500,0,640,140));h.offer(FRAME,None,clock[0],90,0,CTX);h.worker.join(2);clock[0]+=1
   self.assertTrue(h.suspended);clock[0]+=100
   h.observe(FRAME,clock[0],90,0,CTX,(500,0,640,140));self.assertFalse(h.offer(FRAME,None,clock[0],90,0,CTX))
  self.assertEqual(len(calls),3);self.assertFalse(h.stop.is_set())
