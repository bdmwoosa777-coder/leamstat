"""Regressions from the 08:39–08:41 camp run. No live model/game claims."""
import json,threading,time,tempfile,unittest
from pathlib import Path
from dataclasses import replace
from unittest.mock import patch
from http.server import HTTPServer,BaseHTTPRequestHandler
import cv2,numpy as np
from camp_departure import CampDeparture
from scene_recheck import recheck
from qwen_experiment import TemporalAdvisor,TemporalClient,MODEL
from test_hybrid import scene
from test_qwen_experiment import ANSWER,CTX
import test_camp_departure as camp_fixture
import hybrid_engine as he
from navigation import Drive
from test_navigation import radar
from test_patrol import GROUND

def textured():
 y,x=np.indices((360,640));gray=(50+((x//32+y//24)%2)*90).astype(np.uint8)
 return np.stack((gray,gray,gray),axis=2)
FRAME=textured()

class TurnResponse(unittest.TestCase):
 def simulate(self,gain=466,sign=1):
  c=CampDeparture((90,100),(100,100),313,100);c.bearing=256;c.turning=True
  heading=282.;values=[]
  for i in range(10):
   d=c.view_plan(heading,True,100+i*.58,sign)
   if d is None:continue
   values.append(d.yaw);heading=(heading+d.yaw*(d.yaw_lifetime or d.lifetime)*gain*sign)%360
  return values,abs((heading-256+180)%360-180)
 def test_recorded_high_sensitivity_no_longer_oscillates_230_to_280(self):
  turns,error=self.simulate();self.assertLessEqual(len(turns),2);self.assertLess(error,15)
 def test_slow_sensitivity_is_learned_without_repeated_overshoot(self):
  turns,error=self.simulate(180);self.assertLessEqual(len(turns),5);self.assertLess(error,22)
 def test_reverse_yaw_setting_still_converges(self):
  turns,error=self.simulate(sign=-1);self.assertGreater(turns[0],0);self.assertLess(error,15)
 def test_new_feedback_cannot_be_reused_as_many_gain_measurements(self):
  c=CampDeparture((90,100),(100,100),313,100);c.bearing=256;c.turning=True
  d=c.view_plan(282,False,100);c._turn_feedback(270,100.6);first=c.yaw_gain
  for t in (100.7,100.8,101):c._turn_feedback(270,t)
  self.assertEqual(c.yaw_gain,first)
 def test_delayed_heading_from_another_action_does_not_calibrate_gain(self):
  c=CampDeparture((90,100),(100,100),313,100);c.bearing=256;c.turning=True
  c.view_plan(282,False,100);c._turn_feedback(200,103)
  self.assertEqual(c.yaw_gain,480)
 def test_wait_for_pending_scene_has_no_survey_before_six_seconds(self):
  c=CampDeparture((90,100),(100,100),313,100);c.bearing=90
  for i in range(12):
   self.assertEqual(c.view_plan(90,False,100+i*.5,wait_seconds=6).yaw,0)
  self.assertNotEqual(c.view_plan(90,False,106.1,wait_seconds=6).yaw,0)

class CurrentImageProof(unittest.TestCase):
 def reading(self):return replace(scene(t=100,free=.95),source=FRAME.copy(),revision=7,heading=90,pitch=0)
 def verify(self,r=None,frame=None,**kw):
  args={'now':102,'heading':90,'pitch':0,'revision':7,'settled_after':99,'stationary':True};args.update(kw)
  return recheck(self.reading() if r is None else r,FRAME if frame is None else frame,**args)
 def test_static_textured_view_revalidates_two_second_analysis_without_rewriting_timestamp(self):
  r=self.reading();self.assertIs(self.verify(r),r);self.assertEqual(r.captured,100)
 def test_original_scene_host_age_limit_stays_point_nine(self):
  from scene_navigation import SceneHost
  h=SceneHost({});h.latest=self.reading();self.assertIsNone(h.current(102,90,0,7))
 def test_camera_revision_turn_tilt_or_stale_source_cannot_be_resurrected(self):
  for changes in ({'revision':8},{'heading':93},{'pitch':.01},{'now':104},{'settled_after':100.1},{'stationary':False}):
   with self.subTest(changes=changes):self.assertIsNone(self.verify(**changes))
 def test_new_rock_in_the_near_world_invalidates_old_open_ground(self):
  f=FRAME.copy();f[190:235,240:260]=0
  self.assertIsNone(self.verify(frame=f))
 def test_small_local_obstacle_change_cannot_hide_in_global_average(self):
  f=FRAME.copy();f[220:235,220:235]=255
  self.assertIsNone(self.verify(frame=f))
 def test_camera_panned_frame_is_rejected_even_if_heading_is_incorrectly_unchanged(self):
  self.assertIsNone(self.verify(frame=np.roll(FRAME,20,axis=1)))
 def test_uniform_color_is_not_a_geometry_proof(self):
  f=np.full_like(FRAME,(250,25,50));self.assertIsNone(self.verify(replace(self.reading(),source=f),f))
 def test_small_lighting_noise_does_not_require_another_camera_survey(self):
  f=np.clip(FRAME.astype(np.int16)+1,0,255).astype(np.uint8)
  self.assertIsNotNone(self.verify(frame=f))
 def test_verified_old_drop_remains_a_drop_not_a_new_clear_route(self):
  r=self.reading();r=replace(r,ground=replace(r.ground,drop_support=.15))
  self.assertGreater(self.verify(r).ground.drop_support,.04)
 def test_hud_changes_are_not_mistaken_for_world_motion(self):
  f=FRAME.copy();f[:70,:200]=0;f[280:,:200]=255;f[:,550:]=255
  self.assertIsNotNone(self.verify(frame=f))
 def test_old_current_frame_cannot_certify_another_old_frame(self):
  self.assertIsNone(self.verify(frame_age=.36));self.assertIsNone(self.verify(frame_age=-1))
  self.assertIsNotNone(self.verify(frame_age=.1))
 def test_missing_source_or_heading_never_revalidates(self):
  self.assertIsNone(self.verify(replace(self.reading(),source=None)))
  self.assertIsNone(self.verify(heading=None))

class LoadingProtocol(unittest.TestCase):
 def test_real_http_warmup_sends_no_frame_prompt_or_controller_action(self):
  seen={}
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*a):pass
   def do_POST(self):
    seen.update(json.loads(self.rfile.read(int(self.headers['Content-Length']))));seen['path']=self.path
    raw=b'{"done":true,"done_reason":"load"}'
    self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  server=HTTPServer(('127.0.0.1',0),Handler);t=threading.Thread(target=server.serve_forever,daemon=True);t.start()
  try:
   c=TemporalClient('http://127.0.0.1:'+str(server.server_port),MODEL);self.assertTrue(c.warmup()['done'])
   self.assertEqual(seen['path'],'/api/generate');self.assertNotIn('images',seen);self.assertNotIn('prompt',seen)
   self.assertEqual(seen['keep_alive'],'30s')
  finally:server.shutdown();server.server_close();t.join()
 def test_warmup_requires_actual_completion_not_an_error_json(self):
  for reply in ({'error':'runner failed'},{'done':False},{}):
   c=TemporalClient(model=MODEL);c.call=lambda *a,**kw:reply
   with self.assertRaises(RuntimeError):c.warmup()
 def test_compact_profile_keeps_history_and_reduces_three_image_sizes(self):
  from check_qwen_experiment import synthetic_views
  c=TemporalClient(model=MODEL);c.compact=True;seen={}
  def call(path,payload,**kw):seen.update(payload);return {'message':{'content':json.dumps(ANSWER)}}
  c.call=call;c.analyze_views(synthetic_views())
  import base64
  frames=[cv2.imdecode(np.frombuffer(base64.b64decode(s),np.uint8),1) for s in seen['messages'][0]['images']]
  self.assertEqual([f.shape[1] for f in frames],[512,512,160]);self.assertEqual(seen['options']['num_predict'],128)
  self.assertFalse(seen['think'])

class WarmHost(unittest.TestCase):
 def host(self):return TemporalAdvisor({'ollama_autostart':False},lambda _:None)
 def sample(self,h,now):h.observe(FRAME,now,90,0,CTX,(500,0,640,140))
 def test_loading_never_applies_the_pre_load_frame_and_requires_a_new_observation(self):
  h=self.host();clock=[100.];calls=[]
  class Client:
   model=MODEL
   def __init__(self,*a):pass
   def probe(self):pass
   def warmup(self,timeout):calls.append('warm');clock[0]=104
   def analyze_views(self,views):calls.append(('analyze',views[-1].captured));return dict(ANSWER)
  h.client_factory=Client
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   self.sample(h,100);h.offer(FRAME,None,100,90,0,CTX);h.worker.join(2)
   self.assertIsNone(h.latest);self.assertTrue(h.warmed);self.assertEqual(calls,['warm'])
   self.assertFalse(h.offer(FRAME,None,104,90,0,CTX))
   clock[0]=104.1;self.sample(h,104.1);self.assertTrue(h.offer(FRAME,None,104.1,90,0,CTX));h.worker.join(2)
  self.assertEqual(calls,['warm',('analyze',104.1)]);self.assertIsNotNone(h.latest)
 def test_slow_warmup_does_not_hold_the_control_caller(self):
  h=self.host();began=threading.Event();release=threading.Event()
  class Client:
   model=MODEL
   def __init__(self,*a):pass
   def probe(self):pass
   def warmup(self,timeout):began.set();release.wait(2)
   def unload(self):pass
  h.client_factory=Client;now=time.monotonic();self.sample(h,now)
  with patch.object(Path,'write_text'):
   started=time.monotonic();self.assertTrue(h.offer(FRAME,None,now,90,0,CTX));self.assertLess(time.monotonic()-started,.2)
   self.assertTrue(began.wait(1));self.assertEqual(h.phase,'прогрев');h.close();release.set();h.worker.join(2)
  self.assertIsNone(h.latest)
 def test_inference_timeout_retries_compact_while_still_warm_not_after_thirty_seconds(self):
  h=self.host();clock=[100.];profiles=[]
  class Client:
   model=MODEL
   def __init__(self,*a):pass
   def probe(self):pass
   def analyze_views(self,v):profiles.append(self.compact);clock[0]+=12;raise TimeoutError('timed out')
  h.client_factory=Client
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   self.sample(h,100);h.offer(FRAME,None,100,90,0,CTX);h.worker.join(2)
   self.assertTrue(h.compact);self.assertLessEqual(h.retry_at-clock[0],5.1)
   clock[0]=117.1;self.sample(h,117.1);h.offer(FRAME,None,117.1,90,0,CTX);h.worker.join(2)
  self.assertEqual(profiles,[False,True])
 def test_three_hard_timeouts_also_unload_instead_of_keeping_gpu_occupied(self):
  h=self.host();clock=[100.];unloaded=[]
  class Client:
   model=MODEL
   def __init__(self,*a):pass
   def probe(self):pass
   def analyze_views(self,v):clock[0]+=12;raise TimeoutError('timed out')
   def unload(self):unloaded.append(True)
  h.client_factory=Client
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   for _ in range(3):
    self.sample(h,clock[0]);h.offer(FRAME,None,clock[0],90,0,CTX);h.worker.join(2);clock[0]+=6
  self.assertEqual(unloaded,[True]);self.assertGreater(h.retry_at,clock[0]+50)
 def test_runtime_report_captures_gpu_residency_without_frames_or_packets(self):
  h=self.host()
  class Client:
   def call(self,*a,**kw):return {'models':[{'name':MODEL,'size':6000,'size_vram':2000,'unwanted':'raw'}]}
  with patch.object(Path,'write_text') as write:
   h._runtime_report(Client(),'inference','timed out',time.monotonic())
  data=json.loads(write.call_args.args[0]);self.assertEqual(data['models'][0]['size_vram'],2000)
  self.assertNotIn('unwanted',data['models'][0]);self.assertNotIn('images',data)

class CampIntegration(unittest.TestCase):
 def setUp(self):
  self.f=camp_fixture.DepartureControl('test_existing_map_ether_does_not_prevent_initial_departure');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.f.start();self.e=self.f.e
  self.e.camp_route.bearing=90;self.e.gamepad.reset()
  self.e.scene_host.current=lambda *a:None
  self.e.scene_host.latest=replace(scene(t=100,free=.95),source=FRAME.copy(),revision=self.e.scene_camera_epoch)
 def plan(self,frame=FRAME,now=102):
  with patch.object(he.time,'monotonic',return_value=now):return self.e._scene_plan(frame,radar(heading=90),GROUND,Drive(.78),now)
 def test_still_current_camp_image_releases_wait_despite_delayed_inference(self):
  d=self.plan();self.assertGreater(d.forward,.4);self.assertEqual(d.yaw,0)
  self.assertTrue(any('SCENE_RECHECK' in s for s in self.f.log))
 def test_currently_changed_view_keeps_old_result_out_of_the_controller(self):
  d=self.plan(np.roll(FRAME,20,axis=1));self.assertEqual(d.forward,0)
 def test_existing_walk_lease_prevents_using_stationary_recheck(self):
  self.e.gamepad.translation=(.6,0);self.e.gamepad.translation_deadline=103
  d=self.plan();self.assertEqual(d.forward,0)
 def test_revalidated_drop_never_authorizes_walking(self):
  self.e.scene_host.latest=replace(self.e.scene_host.latest,ground=replace(self.e.scene_host.latest.ground,drop_support=.15))
  d=self.plan();self.assertEqual(d.forward,0);self.assertEqual(d.strafe,0)
