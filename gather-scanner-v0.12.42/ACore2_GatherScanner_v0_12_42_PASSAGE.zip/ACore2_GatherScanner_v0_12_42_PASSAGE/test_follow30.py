"""Reproduce the weak-stick stops and rejected return in the 14:21–14:30 log."""
import math,threading,unittest
from types import SimpleNamespace
from unittest.mock import Mock,patch
from camp_memory import ExitFollower,SavedExit
import test_route_memory as mem
import test_ready_experiment as ready

class ActualMovementThreshold(unittest.TestCase):
 def test_quantized_minimap_and_game_deadzone_do_not_stall_at_close_waypoints(self):
  for threshold in (.5,.7):
   player=[18.,0.];heading=170.;f=ExitFollower(mem.route(),mem.anchor(player),mem.CENTER,mem.BOUNDS,100)
   done=False
   for i in range(400):
    measured=tuple(round(v) for v in player)
    a=f.step(mem.anchor(measured),mem.CENTER,mem.BOUNDS,heading,100+i*.3)
    self.assertIsNone(a.error,a.error)
    if a.done:done=True;break
    d=a.drive;h=math.radians(heading);moving=math.hypot(d.forward,d.strafe)>threshold
    if moving:
     player[0]+=(d.forward*math.sin(h)+d.strafe*math.cos(h))*5*.3
     player[1]+=(-d.forward*math.cos(h)+d.strafe*math.sin(h))*5*.3
    heading=(heading+d.yaw*(d.yaw_lifetime or 0)*500)%360
   self.assertTrue(done,(threshold,player));self.assertLess(math.dist(player,mem.route().points[-1]),2.5)
 def test_near_waypoint_uses_effective_stick_not_point_four_five(self):
  f=ExitFollower(mem.route(),mem.anchor((18,0)),mem.CENTER,mem.BOUNDS,100)
  d=f.step(mem.anchor((18,-1)),mem.CENTER,mem.BOUNDS,0,100.3).drive
  self.assertGreaterEqual(math.hypot(d.forward,d.strafe),.8)
 def test_stall_boosts_stick_before_finite_failure_instead_of_waiting_at_weak_input(self):
  f=ExitFollower(mem.route(),mem.anchor((18,0)),mem.CENTER,mem.BOUNDS,0)
  f.step(mem.anchor((18,0)),mem.CENTER,mem.BOUNDS,0,0)
  for t in (.3,.6,.9,1.2,1.5):d=f.step(mem.anchor((18,0)),mem.CENTER,mem.BOUNDS,0,t).drive
  self.assertAlmostEqual(math.hypot(d.forward,d.strafe),1)
  for t in (1.8,2.1,2.4,2.7,3.,3.3,3.6,3.9,4.2):last=f.step(mem.anchor((18,0)),mem.CENTER,mem.BOUNDS,0,t)
  self.assertIsNotNone(last.error)
 def test_passed_point_with_small_cross_error_does_not_request_a_reverse_turn(self):
  r=SavedExit(mem.TITLE,313/207,((18.,0.),(18.,-3.),(18.,-10.),(18.,-17.),(18.,-24.),(18.,-31.),(18.,-38.),(18.,-45.)))
  f=ExitFollower(r,mem.anchor((18,0)),mem.CENTER,mem.BOUNDS,100)
  d=f.step(mem.anchor((18,-5.5)),mem.CENTER,mem.BOUNDS,0,100.3).drive
  self.assertEqual(f.index,2);self.assertGreater(d.forward,.7);self.assertEqual(d.yaw,0)

class ReturnToCorridor(unittest.TestCase):
 def test_start_several_points_along_shown_path_rejoins_without_returning_to_first_point(self):
  f=ExitFollower(mem.route(),mem.anchor((18,-12)),mem.CENTER,mem.BOUNDS,100)
  d=f.step(mem.anchor((18,-12)),mem.CENTER,mem.BOUNDS,0,100).drive
  self.assertGreaterEqual(f.index,5);self.assertGreater(d.forward,.7);self.assertEqual(d.yaw,0)
 def test_wrong_side_far_from_the_entire_corridor_is_still_rejected(self):
  with self.assertRaises(ValueError):ExitFollower(mem.route(),mem.anchor((30,-12)),mem.CENTER,mem.BOUNDS,100)
 def test_parallel_path_does_not_count_as_passing_a_waypoint(self):
  f=ExitFollower(mem.route(),mem.anchor((18,0)),mem.CENTER,mem.BOUNDS,100)
  f.step(mem.anchor((23,-5)),mem.CENTER,mem.BOUNDS,0,100.3)
  self.assertEqual(f.index,1)

class ModelPreparationOwnership(unittest.TestCase):
 def fixture(self):
  u=ready.StartGate().ui();u._start_pending=False;u._qwen_route_defer_until=90
  h=SimpleNamespace(stop=threading.Event());camp=object()
  u.engine=SimpleNamespace(analyzer=h,camp_route=camp,recorded_rejected=camp,hybrid_camp_pending=True)
  u._prepare_qwen_background=Mock();return u,h
 def test_failed_replay_does_not_start_model_load_while_camp_exit_still_active(self):
  u,h=self.fixture()
  with patch('app.time.monotonic',return_value=100):u._qwen_after_recorded_exit(5,h)
  u._prepare_qwen_background.assert_not_called();self.assertEqual(u.root.calls[-1][0],250)
 def test_confirmed_end_of_camp_departure_releases_model_preparation(self):
  u,h=self.fixture();u.engine.camp_route=None;u.engine.hybrid_camp_pending=False
  with patch('app.time.monotonic',return_value=100):u._qwen_after_recorded_exit(5,h)
  u._prepare_qwen_background.assert_called_once_with(5,h)
 def test_cancelled_deferred_request_cannot_restart_model(self):
  u,h=self.fixture();h.stop.set();u._qwen_after_recorded_exit(5,h)
  u._prepare_qwen_background.assert_not_called();self.assertFalse(u.root.calls)

if __name__=='__main__':unittest.main()
