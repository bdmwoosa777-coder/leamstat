"""Swimming HUD, verified open pursuit and ground-resource identity."""
import unittest,math
from dataclasses import replace
from unittest.mock import patch
import cv2,numpy as np
from flight import read_flight,FlightReading,FlightBudget
from hybrid_navigation import HybridPlanner
from navigation import Drive,Navigator
from minimap import Marker
from test_hybrid import scene
from test_navigation import radar
import test_hybrid as fx

def gauge(colour,curve=True):
 f=np.full((1152,2048,3),(55,65,60),np.uint8)
 yy=np.arange(476,727,dtype=float);xx=1047+46*((yy-597)/123)**2 if curve else np.full_like(yy,1047)
 pts=np.column_stack((np.rint(xx*.8),np.rint((yy+180)*.8))).astype('int32')
 cv2.polylines(f,[pts],False,(10,10,10),9);cv2.polylines(f,[pts],False,colour,4)
 return f

class SwimmingHUD(unittest.TestCase):
 def test_purple_curved_gauge_is_swimming_without_flight_confirmation(self):
  r=read_flight(gauge((235,55,220)));self.assertTrue(r.swimming);self.assertFalse(r.confirmed);self.assertIsNone(r.energy)
 def test_cyan_curved_gauge_is_flight_without_swimming(self):
  r=read_flight(gauge((240,255,50)));self.assertTrue(r.confirmed);self.assertFalse(r.swimming)
 def test_purple_rectangles_elsewhere_are_not_a_swimming_gauge(self):
  f=np.full((1152,2048,3),(150,80,130),np.uint8);cv2.rectangle(f,(600,700),(900,740),(235,55,220),-1)
  self.assertFalse(read_flight(f).swimming)
 def test_visible_blue_water_without_hud_is_not_proof_of_swimming(self):
  self.assertFalse(read_flight(np.full((1152,2048,3),(160,80,35),np.uint8)).swimming)
 def test_swimming_stops_new_takeoff_but_does_not_mark_airborne(self):
  b=FlightBudget();b.airborne=True;b.energy=70;b.update(FlightReading(None,False,150,True),100)
  self.assertFalse(b.airborne);self.assertTrue(b.swimming);self.assertFalse(b.can_start());self.assertFalse(b.can_probe())
 def test_swim_flicker_has_short_hold_and_does_not_fake_ground_regeneration(self):
  b=FlightBudget();b.energy=70;b.update(FlightReading(None,False,150,True),100)
  b.update(FlightReading(None,False),101);self.assertTrue(b.swimming);self.assertEqual(b.energy,70)
  b.update(FlightReading(None,False),102);self.assertFalse(b.swimming);self.assertTrue(b.can_start())
 def test_real_cyan_flight_immediately_replaces_purple_state(self):
  b=FlightBudget();b.update(FlightReading(None,False,150,True),100);b.update(FlightReading(80,True),100.3)
  self.assertFalse(b.swimming);self.assertTrue(b.airborne)

class ClearPursuit(unittest.TestCase):
 def test_two_fresh_open_views_finish_detour_and_restore_direct_resource_course(self):
  p=HybridPlanner();p.choose(Drive(.9),scene(t=100),radar(),100,hint=0)
  a=p.choose(Drive(.9),scene(t=100.3,free=.65),radar(),100.3);self.assertLess(a.drive.strafe,0)
  b=p.choose(Drive(.9),scene(t=100.6,free=.65),radar(),100.6)
  self.assertEqual(b.drive.strafe,0);self.assertGreaterEqual(b.drive.forward,.9);self.assertFalse(b.detour)
 def test_same_frame_twice_does_not_confirm_opening(self):
  p=HybridPlanner();p.choose(Drive(.9),scene(t=100),radar(),100,hint=0)
  s=scene(t=100.3,free=.65);p.choose(Drive(.9),s,radar(),100.3)
  self.assertLess(p.choose(Drive(.9),s,radar(),100.6).drive.strafe,0)
 def test_new_cliff_revokes_open_pursuit_before_second_confirmation(self):
  p=HybridPlanner();p.choose(Drive(.9),scene(t=100,free=.65),radar(),100)
  s=scene(t=100.3,free=.65);s=replace(s,ground=replace(s.ground,routes=(),drop_support=.2))
  d=p.choose(Drive(.9),s,radar(),100.3).drive;self.assertEqual((d.forward,d.strafe),(0,0))
 def test_missing_scene_breaks_open_confirmation(self):
  p=HybridPlanner();p.choose(Drive(.9),scene(t=100),radar(),100,hint=0)
  p.choose(Drive(.9),scene(t=100.3,free=.65),radar(),100.3);p.choose(Drive(.9),None,radar(),100.4)
  a=p.choose(Drive(.9),scene(t=100.6,free=.65),radar(),100.6);self.assertTrue(a.detour)

class ClickIdentityAndWings(unittest.TestCase):
 def setUp(self):
  self.f=fx.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
 def test_generic_badge_does_not_replace_failed_resource_specific_glyph(self):
  c=replace(self.f.c,emblem=(10,10,30,30),glyph=((4,4),bytes(range(16))))
  with patch('gather_engine.find_resource_near',return_value=None),patch('gather_engine.locate_resource_emblem',side_effect=AssertionError('shared badge cannot establish resource name')):
   self.assertIsNone(self.e._refresh_bound_candidate(self.f.frame,c))
 def test_unselected_badge_without_name_cannot_authorize_repeat(self):
  c=replace(self.f.c,glyph=None,emblem=(10,10,30,30));self.e.network_target=(1,123)
  self.f.source.state.selected=0
  with patch.object(self.e,'_net_gather_proof',return_value=True):self.assertIsNone(self.e._refresh_bound_candidate(self.f.frame,c))
 def test_ground_resource_waits_for_closed_wings_before_new_selection(self):
  self.e.budget.airborne=True;self.e.camp_exit_until=0;self.e.mode='SEARCH'
  self.assertFalse(self.e._allowed(replace(self.f.c,name='Алмаз'),100))
 def test_existing_own_ground_attempt_is_not_cancelled_by_wing_selection_rule(self):
  self.e.mode='GATHER';self.e.budget.airborne=True;self.e.camp_exit_until=0
  self.e.cfg['target_names']=['Алмаз'];self.e.policy.priority=False
  self.assertTrue(self.e._allowed(replace(self.f.c,name='Алмаз'),100))

class OverheadEther(unittest.TestCase):
 def make(self,ms=940):
  n=Navigator({'ether_quick_search':True,'air_search_wide':True,'camera_working_view_ms':ms})
  r=radar([Marker('Эфир',105,100,.9,5,'aether')]);return n,r
 def test_close_scan_reaches_up_homing_range_and_returns_same_amount(self):
  n,r=self.make(1200);now=100;d=n.update(r,now);up=down=0
  for i in range(13):
   if d.pitch>0:up+=d.lifetime
   if d.pitch<0:down+=d.lifetime
   now=n.scan_next_at+.001;d=n.update(r,now)
  self.assertGreaterEqual(up,1.2);self.assertAlmostEqual(up,down);self.assertTrue(d.restore_pitch)
 def test_scan_range_is_frozen_despite_marker_distance_jitter(self):
  n,r=self.make();n.update(r,100);planned=n.scan_quick_total;r.markers[0].distance=11
  n.update(r,n.scan_next_at+.001);self.assertEqual(n.scan_quick_total,planned)
 def test_near_resource_at_cone_edge_is_centered_before_looking_up(self):
  n,r=self.make();r=replace(r,heading=0,cone_half_angle=56,markers=[Marker('Эфир',103,95,.9,5.83,'aether')])
  d=n.update(r,100);self.assertEqual(d.pitch,0);self.assertIsNone(n.air_since);self.assertGreater(d.strafe,0)
 def test_disappeared_close_marker_is_not_silently_rebound_to_neighbor(self):
  n,r=self.make();n.update(r,100);epoch=n.goal_epoch;n.lookup_failures=2
  other=Marker('Эфир',117,103,.9,17.3,'aether');n.update(replace(radar([other]),motion_valid=True),101.5)
  self.assertIs(n.goal,other);self.assertGreater(n.goal_epoch,epoch);self.assertEqual(n.lookup_failures,0)
 def test_disappearance_after_up_scan_resumes_search_instead_of_eleven_second_wait(self):
  n,r=self.make();n.update(r,100);n.scan_last_pulse=6
  d=n.update(radar(),101.5);self.assertIsNone(n.goal);self.assertTrue(d.restore_pitch)


import test_collection_cycle as cyclefx
class FinishOwnedGround(unittest.TestCase):
 def setUp(self):
  self.f=cyclefx.CycleEngine('test_defaults_are_event_driven_and_940ms_in_app_and_file');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.e.target='Алмаз';self.e.cfg['target_names']=['Эфир','Алмаз'];self.e.policy.priority=True
  self.e.policy.ground_fallback=False;self.e.policy.recovering=False;self.e.policy.air_ready=True;self.e.policy.air_on_map=True
  self.c=replace(self.e.candidate,name='Алмаз',glyph=((4,4),bytes(range(16))))
  self.e.candidate=self.c
  p=patch('gather_engine.find_resource_near',side_effect=lambda frame,c:c);p.start();self.addCleanup(p.stop)
 def resume(self):
  self.e.f_enable();self.f.f.selected=0;self.f.absent();self.e.f_enable();self.f.clock+=2.1
  self.e.f_enable()
 def test_ether_priority_does_not_reject_already_owned_ground_name(self):
  self.assertFalse(self.e.policy.allows('Алмаз'));self.assertEqual(self.e._vision_names(),('Алмаз',))
 def test_cancelled_named_ground_attempt_gets_one_resume_not_a_gem_to_ether_switch(self):
  self.resume();self.assertEqual(self.f.pad.presses,1)
  self.assertEqual(self.e.target,'Алмаз');self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.e.mode,'GATHER')
  self.f.clock+=1;self.e.f_enable();self.assertEqual(self.f.pad.presses,1)
 def test_partial_progress_still_blocks_ground_resume(self):
  self.e.f_enable();self.f.f.selected=0;self.f.clock+=3;self.e.f_enable()
  self.assertEqual(self.f.pad.presses,0);self.assertEqual(self.e.target,'Алмаз')
 def test_shared_emblem_without_ground_name_cannot_resume(self):
  self.e.candidate=replace(self.c,glyph=None);self.resume();self.assertEqual(self.f.pad.presses,0)
 def test_ether_emblem_keeps_single_request_rule(self):
  self.e.target='Эфир';self.e.candidate=replace(self.c,name='Эфир');self.resume()
  self.assertEqual(self.f.pad.presses,0)
 def test_new_ether_does_not_cancel_last_ground_attempt_after_own_result(self):
  self.e.f_enable();self.f.ended(2);self.f.f.selected=0;self.f.absent();self.e.f_enable()
  self.assertEqual(self.f.pad.presses,1);self.assertEqual(self.e.target,'Алмаз');self.assertEqual(self.e.network_target,(1,99))
 def test_cleared_selection_and_stale_active_recover_bound_ground_name_in_worker(self):
  self.f.f.selected=0;self.f.f.attempt_active=True
  with patch.object(self.e,'_refresh_bound_candidate',return_value=replace(self.c,glyph=None)),patch.object(self.e,'_world_resource',return_value=self.c) as world:
   obs=self.e._network_world_observation(self.f.frame)
  world.assert_called_once();self.assertEqual(world.call_args.args[1],('Алмаз',));self.assertEqual(obs.candidate,self.c)
 def test_selected_ground_with_fresh_glyph_needs_no_full_worker_ocr(self):
  self.f.f.selected=99
  with patch.object(self.e,'_refresh_bound_candidate',return_value=self.c),patch.object(self.e,'_world_resource',side_effect=AssertionError('unnecessary OCR')):
   self.assertEqual(self.e._network_world_observation(self.f.frame).candidate,self.c)

from network_defense import NetworkDefense
class NavigationAfterDefense(unittest.TestCase):
 def setUp(self):
  self.f=fx.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.goal=Marker('Эфир',130,100,.9,30,'aether');self.e.nav.goal=self.goal;self.e.nav.goal_started=55
  self.e.hybrid.goal_avoid=[(90,120)]
  self.e.network_defense=NetworkDefense(55,1,7,90);self.e.mode='DEFENSE'
 def test_successful_search_defense_restores_full_goal_budget_and_discards_pre_fight_detour(self):
  with patch('hybrid_engine.time.monotonic',return_value=100):self.e._finish_network_defense(True)
  self.assertIs(self.e.nav.goal,self.goal);self.assertEqual(self.e.nav.goal_started,100)
  self.assertEqual(self.e.nav.progress_at,100);self.assertEqual(self.e.hybrid.goal_avoid,[])
 def test_failed_defense_does_not_rearm_the_resource_deadline(self):
  with patch('hybrid_engine.time.monotonic',return_value=100):self.e._finish_network_defense(False,'missing target')
  self.assertEqual(self.e.nav.goal_started,55)

class ResumedCollectionCooldown(unittest.TestCase):
 def setUp(self):
  self.f=cyclefx.CycleEngine('test_defaults_are_event_driven_and_940ms_in_app_and_file');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
 def test_real_resumed_own_attempt_clears_old_skip_before_its_next_end(self):
  self.e.resource_retry_after[(1,99)]=145;self.e.abandoned_lease=(1,99,1000)
  self.e._adopt_network_collection()
  self.assertNotIn((1,99),self.e.resource_retry_after);self.assertIsNone(self.e.abandoned_lease)
  self.e.f_enable();self.f.ended(2);self.f.absent();self.f.f.selected=99
  self.e.f_enable();self.assertEqual(self.f.pad.presses,1)
 def test_stale_inactive_lease_cannot_clear_its_own_skip(self):
  self.e.resource_retry_after[(1,99)]=145;self.e.abandoned_lease=(1,99,1000);self.f.f.attempt_active=False
  self.e._adopt_network_collection();self.assertIn((1,99),self.e.resource_retry_after)

if __name__=='__main__':unittest.main()
