"""Packets -> passive feed -> session counts, including 1, x2, failure and rare yield."""
import struct,unittest,time,threading
from types import SimpleNamespace
from unittest.mock import patch,Mock
from network_feed import NetworkFeed
from gather_stats import GatherStats
from inventory_stats import records,InventoryTracker,catalogue
from test_network_state import v,profile,gauge
from test_integrated_network import mini

ETHER=610610013;RARE=610610014;DIAMOND=610660026

def record(item=ETHER,quantity=50,kind=1,slot=3,container=1):
 # Ten bytes between the kind byte and the item anchor (UID/record fields).
 return bytes((kind,))+bytes(9)+struct.pack('<IQBB',item,quantity,container,slot)+bytes(10)
def listing(quantity=50):
 return b''.join(record(item=ETHER if i==3 else 110120003,quantity=quantity if i==3 else 1,slot=i) for i in range(8))

class ActualGatherYield(unittest.TestCase):
 def setUp(self):
  self.logs=[];self.f=NetworkFeed(logger=self.logs.append);self.stats=GatherStats();self.f.gather_stats=self.stats
  self.clock=100;self.stats.start(now=0,wall=100)
  self.send('008d',gauge())
 def send(self,op,b,flow=1,at=None):
  self.clock=self.clock+10 if at is None else at
  self.f.ingest(dict(type='frame',flow=flow,t=self.clock,op=op,hex=b.hex()))
 def baseline(self,quantity=50):self.send('1b56',listing(quantity))
 def start(self,template=1500000,actor=99):
  self.send('3436',profile(actor=actor,kind=template));self.send('3438',bytes(3)+v(actor))
  self.send('3836',v(actor)+v(7)+b'\1');self.send('318d',mini(actor))
 def end(self,used=1,actor=99,source=7):self.send('3a36',v(actor)+v(source)+struct.pack('<II',used,0))
 def snap(self):return self.stats.snapshot(now=60)
 def test_passive_double_yield_counts_two_items_not_two_attempts(self):
  self.baseline(50);self.start();self.end();self.send('1b56',record(quantity=52))
  self.assertEqual((self.snap()['attempts'],self.snap()['quantity']),(1,2));self.assertEqual(self.snap()['items'],{'Эфир':2})
 def test_three_bars_one_double_one_failed_are_three_items(self):
  self.baseline();self.start();self.end(1);self.send('1b56',record(quantity=51))
  self.end(2);self.send('1b56',record(quantity=53));self.end(3)
  self.assertEqual((self.snap()['attempts'],self.snap()['quantity'],self.snap()['nodes']),(3,3,1))
 def test_failed_attempt_never_invents_an_item(self):
  self.baseline();self.start();self.end();self.assertEqual((self.snap()['attempts'],self.snap()['quantity']),(1,0))
 def test_high_purity_is_separate_from_plain_ether(self):
  self.baseline();self.start();self.end();self.send('1b56',record(item=RARE,quantity=1,kind=0,slot=8))
  self.end(2);self.send('1b56',record(quantity=52))
  self.assertEqual(self.snap()['items'],{'Эфир высокой чистоты':1,'Эфир':2});self.assertEqual(self.snap()['families'],{'Эфир':3})
 def test_bound_rare_material_keeps_its_exact_name(self):
  self.baseline();self.start();self.end();self.send('1b56',record(item=630610002,quantity=2,kind=0,slot=9))
  self.assertEqual(self.snap()['items'],{'Эфир высокой чистоты (привяз.)':2})
 def test_inventory_can_precede_the_own_result(self):
  self.baseline();self.start();self.send('1b56',record(quantity=52));self.assertEqual(self.snap()['quantity'],0)
  self.end();self.assertEqual(self.snap()['quantity'],2)
 def test_retransmitted_result_and_stack_are_not_counted_twice(self):
  self.baseline();self.start();self.end();self.send('1b56',record(quantity=52));self.end();self.send('1b56',record(quantity=52))
  self.assertEqual((self.snap()['attempts'],self.snap()['quantity']),(1,2))
 def test_initial_stack_is_never_counted_as_gathered(self):
  self.start();self.end();self.send('1b56',record(quantity=302))
  self.assertEqual(self.snap()['quantity'],0);self.assertTrue(self.snap()['incomplete'])
  self.end(2);self.send('1b56',record(quantity=304));self.assertEqual(self.snap()['quantity'],2)
 def test_sort_repositions_stacks_without_creating_yield(self):
  self.baseline();self.start();self.end();self.send('1b56',listing(300))
  self.assertEqual(self.snap()['quantity'],0);self.assertTrue(self.snap()['baseline'])
 def test_login_inventory_snapshot_is_only_a_baseline(self):
  self.start();self.end();body=listing(300);self.send('1156',body+bytes(5000-len(body)))
  self.assertEqual(self.snap()['quantity'],0);self.assertTrue(self.snap()['baseline'])
 def test_small_1156_is_not_guessed_to_be_inventory(self):
  self.send('1156',record(quantity=300));self.assertFalse(self.snap()['baseline'])
 def test_unknown_resource_update_does_not_block_capture(self):
  self.send('1b56',b'\xff'*100);self.send('008d',gauge(items=((6,1000),)))
  self.assertEqual(self.f.telemetry.flows[1].flight,1000);self.assertIsNone(self.f.error)
 def test_storage_item_and_equipment_gain_are_not_gathering(self):
  self.baseline();self.start();self.end()
  self.send('1b56',record(quantity=52,container=15));self.send('1b56',record(item=110120003,quantity=100,kind=0))
  self.assertEqual(self.snap()['quantity'],0)
 def test_gain_without_an_own_gather_result_is_not_attributed(self):
  self.baseline();self.send('1b56',record(quantity=52));self.assertEqual(self.snap()['quantity'],0)
 def test_neighbour_result_cannot_authorize_a_counter(self):
  self.baseline();self.start();self.end(source=8);self.send('1b56',record(quantity=52))
  self.assertEqual((self.snap()['attempts'],self.snap()['quantity']),(0,0))
 def test_other_material_cannot_match_ether_result(self):
  self.baseline();self.start();self.end();self.send('1b56',record(item=DIAMOND,quantity=2,kind=0,slot=8))
  self.assertEqual(self.snap()['quantity'],0)
 def test_late_unrelated_gain_does_not_match_old_attempt(self):
  self.baseline();self.start();self.end();self.send('1b56',record(quantity=52),at=self.clock+2500)
  self.assertEqual(self.snap()['quantity'],0)
 def test_old_out_of_order_inventory_cannot_rollback_baseline(self):
  self.baseline();self.send('1b56',record(quantity=5),at=self.clock-1)
  self.start();self.end();self.send('1b56',record(quantity=52));self.assertEqual(self.snap()['quantity'],2)
 def test_session_pause_excludes_time_and_paused_yield(self):
  self.baseline();self.start();self.stats.pause(now=60);self.end();self.send('1b56',record(quantity=52))
  self.assertEqual(self.stats.snapshot(now=600)['seconds'],60);self.assertEqual(self.snap()['quantity'],0)
  self.stats.start(now=600,wall=self.clock);self.end(2);self.send('1b56',record(quantity=53))
  self.assertEqual(self.stats.snapshot(now=620)['seconds'],80);self.assertEqual(self.snap()['quantity'],1)
 def test_reset_clears_totals_but_preserves_observed_inventory(self):
  self.baseline();self.start();self.end();self.send('1b56',record(quantity=52))
  self.stats.reset(now=60,wall=self.clock);self.end(2);self.send('1b56',record(quantity=53))
  self.assertEqual((self.snap()['attempts'],self.snap()['quantity']),(1,1));self.assertTrue(self.snap()['baseline'])
 def test_new_capture_does_not_reuse_old_inventory(self):
  self.baseline();self.stats.capture_gap();self.start();self.end();self.send('1b56',record(quantity=52))
  self.assertEqual(self.snap()['quantity'],0);self.assertTrue(self.snap()['incomplete'])
 def test_counter_error_does_not_kill_network_feed(self):
  self.stats.feed_frame=Mock(side_effect=ValueError('test'))
  self.send('008d',gauge(items=((6,1000),)))
  self.assertEqual(self.f.telemetry.flows[1].flight,1000);self.assertIsNone(self.f.gather_stats)
  self.assertTrue(any('STATS_ERROR' in line for line in self.logs))
 def test_prepared_baseline_does_not_start_clock_or_count_old_stock(self):
  self.stats.pause(now=0);self.baseline(300)
  self.assertEqual(self.stats.snapshot(now=500)['seconds'],0);self.assertTrue(self.snap()['baseline'])
  self.stats.start(now=500,wall=self.clock);self.start();self.end();self.send('1b56',record(quantity=302))
  self.assertEqual(self.snap()['quantity'],2)
 def test_display_never_calls_used_bars_successful_items(self):
  self.start();self.end();s=self.stats.describe(now=60)
  self.assertIn('Завершённых попыток: 1',s);self.assertIn('Предметов: 0',s);self.assertNotIn('Успешных',s)
 def test_decrease_then_gain_counts_only_the_positive_delta(self):
  self.baseline();self.send('1b56',record(quantity=40));self.start();self.end();self.send('1b56',record(quantity=42))
  self.assertEqual(self.snap()['quantity'],2)
 def test_item_in_new_slot_counts_exact_received_quantity(self):
  self.start();self.end();self.send('1b56',record(quantity=2,kind=0,slot=8))
  self.assertEqual(self.snap()['quantity'],2);self.assertFalse(self.snap()['baseline'])
 def test_resource_catalogue_does_not_include_crafted_diamond_powder(self):
  _,items,_=catalogue();self.assertNotIn(610740009,items);self.assertIn(DIAMOND,items)
 def test_ui_reset_does_not_recount_a_retransmitted_old_attempt(self):
  self.baseline();self.start();self.end();self.stats.reset(now=60,wall=self.clock)
  self.end();self.assertEqual(self.snap()['attempts'],0)
 def test_new_character_gain_does_not_match_old_characters_recent_result(self):
  self.baseline();self.start();self.end();self.f.telemetry.flows[1].own=8
  self.send('1b56',record(quantity=2,kind=0,slot=8))
  self.assertEqual(self.snap()['quantity'],0);self.assertTrue(self.snap()['incomplete'])
 def test_cross_flow_inventory_cannot_match_own_result(self):
  self.baseline();self.start();self.end();self.send('1b56',record(quantity=2,kind=0),flow=2)
  self.assertEqual(self.snap()['quantity'],0)
 def test_new_character_cannot_use_a_previous_characters_stack(self):
  self.baseline();self.f.telemetry.flows[1].own=8;self.send('1b56',record(quantity=300))
  self.assertFalse(self.snap()['baseline']);self.assertEqual(self.snap()['quantity'],0)
 def test_node_respawn_is_a_new_attempt_even_with_same_actor(self):
  self.baseline();self.start();self.end();self.send('1b56',record(quantity=51))
  self.f.telemetry.flows[1].nodes.pop(99);self.start();self.end();self.send('1b56',record(quantity=52))
  self.assertEqual((self.snap()['attempts'],self.snap()['quantity']),(2,2))

class InventoryFormat(unittest.TestCase):
 def test_truncated_record_cannot_create_quantity(self):
  self.assertEqual(records(record()[:23]),[])
 def test_unknown_item_id_cannot_anchor_an_inventory_record(self):
  self.assertEqual(records(record(item=999999999)),[])
 def test_invalid_container_cannot_anchor_a_record(self):
  self.assertEqual(records(record(container=19)),[])
 def test_huge_quantity_high_bytes_cannot_anchor_a_record(self):
  self.assertEqual(records(record(quantity=2**55)),[])
 def test_multiple_slots_are_read_without_fixed_record_length(self):
  rows=records(record(slot=1)+bytes(17)+record(slot=2,quantity=2))
  self.assertEqual([(r.slot,r.quantity) for r in rows],[(1,50),(2,2)])

class CounterPreparationUI(unittest.TestCase):
 def make(self):
  from test_boot_background import ui
  u=ui();u.cfg.update(network_enabled=True,dry_run=False,click_backend='gamepad')
  u.gather_stats=GatherStats();u.stats_feed=None;u.stats_preparing=False;u.cfg['analyzer_enabled']=False
  u.connect_gamepad=Mock(return_value=True)
  return u
 def test_prepared_capture_is_reused_and_not_started_a_second_time(self):
  from app import UI
  from test_boot_background import engine
  u=self.make();prepared=NetworkFeed();u.stats_feed=prepared
  prepared.process=SimpleNamespace(poll=lambda:None)
  with patch('app.NetworkFeed',side_effect=AssertionError('must reuse capture')),patch('app.GatherEngine',return_value=engine(None)) as make:
   u._launch_if_ready(5)
  self.assertIs(make.call_args.kwargs['network'],prepared);self.assertIsNone(u.stats_feed)
  self.assertIs(prepared.gather_stats,u.gather_stats)
 def test_running_bot_does_not_start_a_second_preparation_capture(self):
  u=self.make();u._start_pending=False;u.worker=SimpleNamespace(is_alive=lambda:True)
  with patch('app.NetworkFeed',side_effect=AssertionError('second capture forbidden')):u.prepare_stats()
 def test_game_start_waits_for_preparation_thread_to_finish(self):
  u=self.make();u.stats_preparing=True
  with patch('app.GatherEngine') as make:u._launch_if_ready(5)
  make.assert_not_called();self.assertEqual(u.root.calls[-1][0],150)
 def test_read_only_preparation_has_no_controller_or_engine_input(self):
  u=self.make();u._start_pending=False;started=threading.Event()
  network=NetworkFeed();network.start=lambda:started.set();network.close=Mock()
  with patch('app.NetworkFeed',return_value=network),patch('app.GatherEngine',side_effect=AssertionError('no controller engine')):
   u.prepare_stats();self.assertTrue(started.wait(1))
  self.assertIs(u.stats_feed,network);self.assertIsNone(u.gather_stats.running)
  u.connect_gamepad.assert_not_called()
 def test_stop_cancels_preparation_and_closes_only_its_capture(self):
  u=self.make();u._start_pending=False;entered=threading.Event();release=threading.Event();closed=threading.Event()
  network=NetworkFeed()
  def start():entered.set();release.wait(2)
  network.start=start;network.close=closed.set
  with patch('app.NetworkFeed',return_value=network):
   u.prepare_stats();self.assertTrue(entered.wait(1));u.stop();release.set();self.assertTrue(closed.wait(1))
  self.assertIsNone(u.stats_feed);self.assertIsNone(u.gather_stats.running)
 def test_disabled_network_does_not_keep_prepared_capture_alive(self):
  u=self.make();u.cfg['network_enabled']=False;network=NetworkFeed();network.close=Mock();u.stats_feed=network
  from test_boot_background import engine
  with patch('app.GatherEngine',return_value=engine(None)) as make:
   u._launch_if_ready(5)
  self.assertIsNone(make.call_args.kwargs['network']);self.assertIsNone(u.stats_feed)
