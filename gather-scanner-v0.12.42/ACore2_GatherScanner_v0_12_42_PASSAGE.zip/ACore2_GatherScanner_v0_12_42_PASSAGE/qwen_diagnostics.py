"""Small read-only snapshot, called only by the adviser worker.

No screen, packets, prompts, process list, file hashing or model downloads.
The bot's environment does not establish the already-running server's path.
"""
import csv,io,os,shutil,subprocess
from datetime import datetime,timezone
from pathlib import Path

GPU_FIELDS=('name','driver_version','memory.total','memory.used','memory.free','utilization.gpu')

def gpu_snapshot():
 exe=shutil.which('nvidia-smi')
 if not exe:return {'available':False,'reason':'nvidia-smi not found'}
 try:
  result=subprocess.run([exe,'--query-gpu='+','.join(GPU_FIELDS),'--format=csv,noheader,nounits'],
   stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,
   timeout=3,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
  if result.returncode:return {'available':False,'returncode':result.returncode}
  rows=[]
  for row in list(csv.reader(io.StringIO(result.stdout)))[:8]:
   if len(row)!=len(GPU_FIELDS):continue
   values=[v.strip()[:120] for v in row]
   item=dict(zip(('name','driver','total_mib','used_mib','free_mib','utilization_percent'),values))
   rows.append(item)
  return {'available':bool(rows),'gpus':rows}
 except (OSError,subprocess.SubprocessError) as exc:return {'available':False,'reason':type(exc).__name__}

def memory_snapshot():
 if os.name!='nt':return {'available':False,'reason':'Windows measurement only'}
 try:
  import ctypes
  class MemoryStatus(ctypes.Structure):
   _fields_=[('length',ctypes.c_uint32),('load',ctypes.c_uint32)]+[(k,ctypes.c_uint64) for k in
    ('total_physical','available_physical','total_page_file','available_page_file','total_virtual','available_virtual','available_extended_virtual')]
  status=MemoryStatus();status.length=ctypes.sizeof(status)
  if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)):raise OSError('GlobalMemoryStatusEx failed')
  return {'available':True,'physical_total_bytes':status.total_physical,'physical_available_bytes':status.available_physical,'load_percent':status.load}
 except (AttributeError,OSError) as exc:return {'available':False,'reason':type(exc).__name__}

def storage_snapshot():
 value=os.environ.get('OLLAMA_MODELS')
 path=Path(value).expanduser() if value else Path.home()/'.ollama/models'
 info={'models_path_in_bot_environment':str(path),'path_source':'OLLAMA_MODELS' if value else 'default',
       'server_models_path_confirmed':False}
 try:
  info['exists']=path.is_dir()
  if info['exists']:info['disk_free_bytes']=shutil.disk_usage(path).free
 except OSError as exc:info['error']=type(exc).__name__
 return info

def snapshot(client=None):
 result={'captured_utc':datetime.now(timezone.utc).isoformat(),'gpu':gpu_snapshot(),
         'ram':memory_snapshot(),'storage':storage_snapshot()}
 if client is not None and hasattr(client,'call'):
  try:
   version=client.call('/api/version',timeout=2)
   result['ollama_version']=str(version.get('version','unknown'))[:80]
  except Exception as exc:result['ollama_version_error']=type(exc).__name__
 return result
