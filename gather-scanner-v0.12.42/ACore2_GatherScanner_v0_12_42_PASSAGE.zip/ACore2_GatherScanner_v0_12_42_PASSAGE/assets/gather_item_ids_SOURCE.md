# Gathering item names and inventory layout

Source: [SkeeveAN/Aion-DPS-Meter](https://github.com/SkeeveAN/Aion-DPS-Meter)
at commit `d9babccbaf037f9dc54c77d24f19198b234cb1f1`, MIT, SkeeveTV.
The license notice is preserved in [atlas/LICENSE-MIT.txt](atlas/LICENSE-MIT.txt).

`gather_item_ids.json` contains known numeric item IDs and raw gathering material
names/families from `Client/assets/aion2/items/item_names.json`.
Source SHA256: `36262f34c9c585fd41cb5157764d958efdef972180e8da9e517b391c2cfa123a`.
Names match English resource names in `atlas/gather.json`; ingots, powder,
crafted items and equipment are excluded.

The independent passive reader in `inventory_stats.py` follows the record layout
documented in `Client/Aion2/Aion2Stock.cs` and
`docs/protocol/inventar-quest-frames.md` at that commit.
It computes deltas from observed quantities and associates gains with a nearby
own gathering result. Login and sort listings are baselines, never loot.
No upstream executable or additional model is included.
