import unittest
from types import SimpleNamespace
from dataclasses import replace
from unittest.mock import patch
from camp_departure import CampDeparture
from hybrid_navigation import HybridPlanner
from navigation import Drive
from ground_routes import GroundMap
from test_hybrid import scene,route,FRAME
from test_navigation import radar
from test_motion import wall
import test_camp_departure as camp_fixture

class VisibleExit(unittest.TestCase):
 def test_landmark_behind_visible_opening_does_not_force_opposite_camera_turn(self):
  camp=CampDeparture((110,100),(100,100),313,100,prefer_visible=True)
  self.assertIsNone(camp.bearing)
  self.assertIsNone(camp.choose(90,None,100))
  self.assertEqual(camp.choose(90,scene().ground,100),90)
  self.assertIsNone(camp.view_plan(90,True,100))
 def test_visible_course_is_retained_after_camera_turn_and_different_route_scores(self):
  camp=CampDeparture((110,100),(100,100),313,100,prefer_visible=True)
  camp.choose(90,scene().ground,100)
  self.assertEqual(camp.choose(140,scene([route(9,.8)]).ground,101),90)
 def test_drop_or_missing_path_never_sets_visible_exit(self):
  c=CampDeparture((110,100),(100,100),313,100,prefer_visible=True)
  for g in (None,GroundMap(),replace(scene().ground,drop_support=.1)):
   self.assertIsNone(c.choose(90,g,100))
 def test_failed_visible_exit_is_excluded_without_falling_back_to_landmark(self):
  c=CampDeparture((110,100),(100,100),313,100,prefer_visible=True)
  c.choose(90,scene().ground,100);c.replan(101)
  self.assertIsNone(c.choose(90,GroundMap((route(2,.5),)),101))

class RecoveredPassage(unittest.TestCase):
 def blocked(self):
  p=HybridPlanner();p.choose(Drive(.78),wall(100),radar(),100);return p
 def test_replay_wall_then_three_visible_paths_does_not_backpedal(self):
  p=self.blocked();a=p.choose(Drive(.78),scene(t=101.1),radar(),101.1,exit_mode=True)
  self.assertFalse(a.escape);self.assertFalse(a.jump);self.assertGreater(a.drive.forward,.1)
 def test_recovered_resource_path_also_is_not_overridden_by_old_survey(self):
  p=self.blocked();a=p.choose(Drive(.78),scene(t=101.1),radar(),101.1)
  self.assertFalse(a.escape);self.assertGreater(a.drive.forward,.1)
 def test_actual_measured_immobility_still_allows_escape_on_visually_open_path(self):
  p=self.blocked();p.tracking=True;p.last_progress=98
  r=radar();r.motion_valid=True;r.displacement=(0,0)
  a=p.choose(Drive(.78),scene(t=101.1),r,101.1)
  self.assertTrue(a.escape)
 def test_drop_after_recovered_path_revokes_translation(self):
  p=self.blocked();p.choose(Drive(.78),scene(t=101.1),radar(),101.1)
  a=p.choose(Drive(.78),wall(101.5,drop=.2),radar(),101.5)
  self.assertFalse(a.escape);self.assertEqual(a.drive.forward,0)
 def test_no_measured_progress_does_not_reset_eight_second_deadline(self):
  p=self.blocked()
  for t in (101.1,102.,103.):p.choose(Drive(.78),scene(t=t),radar(),t)
  self.assertEqual(p.problem_since,100)
  self.assertTrue(p.choose(Drive(.78),scene(t=108),radar(),108).skip)

class ActualDeparture(unittest.TestCase):
 def setUp(self):
  self.f=camp_fixture.DepartureControl('test_existing_map_ether_does_not_prevent_initial_departure')
  self.f.setUp();self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
 def test_engine_selects_forward_visible_passage_instead_of_opposite_landmark(self):
  self.f.start(anchor=(110,100));e=self.f.e
  self.assertIsNone(e.camp_route.bearing)
  with patch('hybrid_engine.time.monotonic',return_value=100):d=e._scene_plan(self.f.frame,radar(),self.f.e.last_flight if hasattr(self.f.e,'last_flight') else camp_fixture.GROUND,Drive(.6),100)
  self.assertGreater(d.forward,.5);self.assertEqual(d.yaw,0)
 def test_unrelated_resource_goal_does_not_change_camp_advice_identity(self):
  self.f.start();e=self.f.e;contexts=[]
  e.analyzer=SimpleNamespace(temporal=True,busy=False,ready=False,error=None,position=(0,0),feedback=lambda *a:None,observe=lambda *a:None,
   offer=lambda *a:contexts.append(a[-1]),recommend=lambda *a:None,warning=lambda *a:None)
  with patch('hybrid_engine.time.monotonic',return_value=100):
   for epoch,kind in ((10,'gem'),(11,'aether')):
    e.nav.goal_epoch=epoch;e.nav.goal=SimpleNamespace(kind=kind,x=130,y=100)
    e._scene_plan(self.f.frame,radar(),camp_fixture.GROUND,Drive(.6),100)
  self.assertTrue(contexts)
  self.assertEqual({(c['mode'],c['kind'],c['goal_epoch']) for c in contexts},{('camp_exit',None,1)})

if __name__=='__main__':unittest.main()
