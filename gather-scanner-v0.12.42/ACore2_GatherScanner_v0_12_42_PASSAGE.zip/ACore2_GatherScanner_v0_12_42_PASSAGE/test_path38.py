"""Replay critical transitions using real controllers, rendered badges and minimaps."""
import json,math,tempfile,time,unittest
from dataclasses import replace
from pathlib import Path
from unittest.mock import patch,Mock
import cv2,numpy as np
from obstacle_follow import ObstacleFollower
from terrain_experience import TerrainExperience,terrain_signature,similarity,ExperienceGuide
from hybrid_navigation import HybridPlanner
from navigation import Drive
from minimap import Marker
from scene_navigation import SceneReading,Lane
from ground_routes import GroundMap,GroundRoute
from test_navigation import radar
import test_hybrid as hybridfx
from test_hybrid import scene,route
import test_continuation as contfx
from test_ether_emblem import scene as badge_frame,ether
from owned_emblem import OwnedEmblem

FREE=Lane(.8,.05,0,.15);WALL=Lane(.05,.75,0,.2)
def view(t=100,seq=1,lanes=(FREE,WALL,FREE),drop=0,routes=()):
 return SceneReading(t,90,0,seq,lanes,ground=GroundMap(routes,100,drop),water=0)

class PersistentBypass(unittest.TestCase):
 def setUp(self):self.f=ObstacleFollower();self.r=radar();self.r.heading=90;self.r.confidence=1;self.f.observe(('zone',1,'aether'),self.r,100)
 def step(self,t,scene=None,delta=(0,0),valid=True):
  self.r=replace(self.r,displacement=delta,motion_valid=valid)
  self.f.observe(('zone',1,'aether'),self.r,t)
  a=self.f.choose(Drive(.9),scene or view(t,round(t*10)),self.r,t,30)
  if a:self.f.delivered(t,t+a.drive.lifetime,math.hypot(a.drive.forward,a.drive.strafe)>.2)
  return a
 def test_visible_side_passage_is_used_immediately_without_survey(self):
  a=self.step(100);self.assertGreater(abs(a.drive.strafe),.7);self.assertEqual(a.drive.yaw,0);self.assertTrue(a.detour)
 def test_same_side_survives_more_than_the_old_three_second_commit(self):
  signs=[]
  for i in range(16):
   a=self.step(100+i*.3,delta=(-.5,0));signs.append(math.copysign(1,a.drive.strafe))
  self.assertEqual(len(set(signs)),1);self.assertTrue(self.f.active)
 def test_saved_side_is_used_only_if_current_edge_allows_it(self):
  a=self.f.choose(Drive(.9),view(lanes=(replace(FREE,edge=.1),WALL,FREE)),self.r,100,30,-1)
  self.assertGreater(a.drive.strafe,0)
 def test_drop_revokes_bypass_even_if_memory_prefers_side(self):
  self.assertIsNone(self.f.choose(Drive(.9),view(drop=.1),self.r,100,30,1));self.assertFalse(self.f.active)
 def test_water_does_not_trigger_ground_wall_following(self):
  self.assertIsNone(self.f.choose(Drive(.9),replace(view(),water=.8),self.r,100,30,1))
 def test_stale_scene_never_authorizes_side_motion(self):self.assertIsNone(self.f.choose(Drive(.9),view(98),self.r,100,30,1))
 def test_open_ground_keeps_direct_navigation(self):
  self.assertIsNone(self.f.choose(Drive(.9),view(lanes=(FREE,)*3,routes=(route(2,.5),)),self.r,100,30,1));self.assertFalse(self.f.active)
 def test_camera_turn_does_not_reverse_world_bypass_direction(self):
  a=self.step(100);bearing=self.f.bypass_bearing
  self.r.heading=bearing
  a=self.f.choose(Drive(.1,-.8),view(100.3,2,lanes=(WALL,FREE,WALL),routes=(route(2,.5),)),self.r,100.3,31)
  self.assertGreater(a.drive.forward,.5);self.assertLess(abs(a.drive.strafe),.25);self.assertEqual(self.f.bypass_bearing,bearing)
 def test_rejoin_needs_movement_and_two_different_clear_frames(self):
  self.step(100);clear=view(100.3,2,lanes=(FREE,)*3,routes=(route(2,.5),))
  self.f.travel=4
  self.f.choose(Drive(.9),clear,self.r,100.3,26);self.assertNotEqual(self.f.phase,'REJOIN')
  self.f.choose(Drive(.9),clear,self.r,100.4,26);self.assertNotEqual(self.f.phase,'REJOIN')
  a=self.f.choose(Drive(.9),replace(clear,captured=100.5,sequence=3),self.r,100.5,26)
  self.assertEqual(self.f.phase,'REJOIN');self.assertGreater(a.drive.forward,.8);self.assertEqual(a.drive.strafe,0)
 def test_rejoin_finishes_and_releases_normal_resource_search(self):
  self.step(100);self.f.travel=4
  for t in (100.3,100.6,101.2,102.8):
   self.f.choose(Drive(.9),view(t,round(t*10),lanes=(FREE,)*3,routes=(route(2,.5),)),self.r,t,25)
  self.assertIsNone(self.f.phase)
 def test_back_and_forth_walk_is_not_net_escape_progress(self):
  self.step(100)
  for i in range(1,9):self.step(100+i*.25,delta=(.5 if i%2 else -.5,0))
  self.assertTrue(self.f.stalled())
 def test_expired_walk_leases_do_not_accumulate_obstacle_effort(self):
  self.step(100);self.f.advance(110);self.assertLessEqual(self.f.walk,.7)
 def test_actual_immobility_escalates_after_side_attempt_not_immediately(self):
  self.step(100)
  for i in range(1,20):
   a=self.step(100+i*.3)
   if a.skip:break
  self.assertTrue(a.skip);self.assertTrue(a.wall_escape);self.assertGreaterEqual(self.f.walk,4)
 def test_unknown_displacement_does_not_pretend_measured_stall(self):
  self.step(100)
  for i in range(1,10):self.step(100+i*.3,valid=False)
  self.assertFalse(self.f.stalled())
 def test_changed_goal_does_not_inherit_side_or_movement(self):
  self.step(100);self.f.observe(('zone',2,'gem'),self.r,101);self.assertFalse(self.f.active);self.assertEqual(self.f.side,0)
 def test_bounded_closed_view_eventually_ends_without_blind_translation(self):
  self.step(100)
  closed=view(119,40,lanes=(WALL,)*3)
  a=self.f.choose(Drive(.9),closed,self.r,119,30);self.assertTrue(a.skip);self.assertEqual(a.drive.forward,0)

class LearnedTerrain(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.path=Path(self.tmp.name)/'navigation_memory.json'
  self.r=radar();self.r.bounds=(0,0,313,313);self.r.center=(156,156)
  self.g=Marker('Эфир',175,140,1,25,'aether')
  rng=np.random.default_rng(91);texture=rng.integers(45,180,(313,313),dtype=np.uint8)
  self.frame=np.repeat(cv2.GaussianBlur(texture,(3,3),0)[:,:,None],3,axis=2)
  self.sig=terrain_signature(self.frame,self.r,self.g);self.assertIsNotNone(self.sig)
 def test_ring_ignores_respawn_icon_and_actor_identity(self):
  f=self.frame.copy();cv2.circle(f,(175,140),10,(255,220,0),-1)
  other=terrain_signature(f,self.r,self.g);self.assertGreater(similarity(self.sig,other),.99)
 def test_success_persists_and_can_be_used_after_restart(self):
  m=TerrainExperience(self.path);self.assertTrue(m.learned('map:1','aether',4,self.sig,-1,spawn={'template':123,'xyz':[1,2,3]}));m.close()
  n=TerrainExperience(self.path);self.assertEqual(n.preference('map:1','aether',4,self.sig),-1)
  self.assertNotIn('actor',self.path.read_text())
 def test_failed_unseen_route_is_not_learned(self):
  m=TerrainExperience(self.path);self.assertFalse(m.learned('map:1','aether',4,self.sig,1,success=False));self.assertFalse(self.path.exists())
 def test_other_zone_kind_or_opposite_approach_cannot_use_preference(self):
  m=TerrainExperience();m.learned('map:1','aether',4,self.sig,1)
  for args in (('map:2','aether',4),('map:1','gem',4),('map:1','aether',10)):self.assertIsNone(m.preference(*args,self.sig))
 def test_different_terrain_cannot_use_previous_route(self):
  m=TerrainExperience();m.learned('map:1','aether',4,self.sig,1)
  other=terrain_signature(np.flip(self.frame,axis=1).copy(),self.r,self.g)
  self.assertIsNone(m.preference('map:1','aether',4,other))
 def test_repeated_failures_disable_old_preference(self):
  for wins in (1,20,100):
   m=TerrainExperience()
   for _ in range(wins):m.learned('map:1','aether',4,self.sig,1)
   for _ in range(3):m.learned('map:1','aether',4,self.sig,1,success=False)
   self.assertIsNone(m.preference('map:1','aether',4,self.sig))
 def test_ambiguous_opposite_successes_are_not_guessed(self):
  m=TerrainExperience();m.learned('map:1','aether',4,self.sig,1)
  other=dict(m.records[0]);other['side']=-1;m.records.append(other)
  self.assertIsNone(m.preference('map:1','aether',4,self.sig))
 def test_flat_or_clipped_minimap_does_not_identify_location(self):
  self.assertIsNone(terrain_signature(np.full_like(self.frame,90),self.r,self.g))
  self.assertIsNone(terrain_signature(self.frame,self.r,replace(self.g,x=4)))
 def test_corrupt_memory_does_not_stop_navigation(self):
  self.path.write_text('{broken');self.assertEqual(TerrainExperience(self.path).records,[])
 def test_writer_coalesces_updates_without_losing_latest_success(self):
  m=TerrainExperience(self.path)
  for _ in range(20):m.learned('map:1','aether',4,self.sig,1)
  m.close();self.assertEqual(TerrainExperience(self.path).records[0]['wins'],20)

class RememberedWaypoints(unittest.TestCase):
 def test_saved_resource_relative_path_advances_without_camera_dependence(self):
  guide=ExperienceGuide([(20,0),(20,-4),(15,-8),(10,-8)])
  self.assertAlmostEqual(guide.bearing((20,0)),0)
  self.assertAlmostEqual(guide.bearing((20,-4)),math.degrees(math.atan2(-5,4))%360)
  self.assertAlmostEqual(guide.bearing((15,-8)),270)
 def test_wrong_start_or_teleport_revokes_saved_path(self):
  guide=ExperienceGuide([(20,0),(20,-4),(15,-8)])
  self.assertIsNone(guide.bearing((-20,0)));self.assertTrue(guide.lost)
  guide=ExperienceGuide([(20,0),(20,-4),(15,-8)]);guide.bearing((20,0))
  self.assertIsNone(guide.bearing((60,10)));self.assertTrue(guide.lost)
 def test_finished_path_stops_proposing_waypoints(self):
  guide=ExperienceGuide([(20,0),(20,-4)]);guide.bearing((20,0));self.assertIsNone(guide.bearing((20,-4)))
 def test_invalid_or_disconnected_path_is_not_replayed(self):
  for points in (None,[(0,0)],[(0,0),(80,0)],[(0,0),(float('nan'),0)]):self.assertIsNone(ExperienceGuide(points).bearing((0,0)))
 def test_route_points_persist_with_success_and_survive_reload(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'memory.json';m=TerrainExperience(path);v=[float(i%9-4) for i in range(256)];sig={'values':v,'mask':[1]*256}
   m.learned('map:1','aether',3,sig,1,points=[(20,0),(20,-4),(15,-8)]);m.close()
   recalled=TerrainExperience(path).recall('map:1','aether',3,sig)
   self.assertEqual(recalled['path'],[[20,0],[20,-4],[15,-8]])
 def test_remembered_waypoint_requires_a_new_connected_route(self):
  f=ObstacleFollower();r=radar();r.heading=90;r.confidence=1;f.observe(1,r,100)
  a=f.choose(Drive(.9),view(100,routes=(route(0,.2),)),r,100,30,-1,30)
  self.assertLess(a.drive.strafe,0)
  self.assertIsNone(f.choose(Drive(.9),view(100.2,drop=.1),r,100.2,30,-1,30))

class BadgeMotion(unittest.TestCase):
 def test_real_badge_motion_beyond_old_roi_keeps_its_identity(self):
  f=badge_frame();c=ether(f);track=OwnedEmblem();key=(1,7,99,0);track.seed(key,c,f,100)
  for i in range(1,4):
   moved=cv2.warpAffine(f,np.float32([[1,0,50*i],[0,1,0]]),(f.shape[1],f.shape[0]),borderValue=(35,35,35))
   found=track.refresh(key,moved,100+i*.2,reacquire=True)
   self.assertIsNotNone(found);self.assertAlmostEqual(found.click_x,c.click_x+50*i,delta=3)
 def test_flow_prediction_outside_screen_cannot_raise_or_click(self):
  f=badge_frame(x=0);c=ether(f);track=OwnedEmblem();key=(1,7,99,0);track.seed(key,c,f,100)
  with patch.object(track,'_flow_shift',return_value=np.array([-200.,-1000.])):
   self.assertIsNone(track.refresh(key,f,100.2,reacquire=True))
 def test_covered_badge_does_not_turn_background_flow_into_click(self):
  f=badge_frame();c=ether(f);track=OwnedEmblem();key=(1,7,99,0);track.seed(key,c,f,100)
  x,y,w,h=c.emblem;f[y-3:y+h+3,x-3:x+w+3]=35
  self.assertIsNone(track.refresh(key,f,100.2,reacquire=True))

class OwnedRecoveryIntegration(unittest.TestCase):
 def setUp(self):
  self.fx=contfx.Continuation('test_fresh_local_point_cancels_deadline');self.fx.setUp()
  self.addCleanup(self.fx.doCleanups);self.addCleanup(self.fx.tearDown);self.e=self.fx.e;self.f=self.fx
  self.e.bridge.controller_native=True;self.e.cfg.update(repeat_owned_clicks=True,auto_view_recovery=True)
 def test_native_own_end_lost_point_searches_after_short_wait_without_camera(self):
  self.f.frame[:]=35;self.e.f_enable()
  with patch.object(self.e,'_fresh_click_candidate',return_value=None),patch('hybrid_engine.gathering_panel_pair',return_value=False),patch.object(self.e,'_view_recovery_tick',return_value=True) as repair:
   self.assertFalse(self.e._completed_point_wait_tick(self.f.frame,100))
   self.assertFalse(self.e._completed_point_wait_tick(self.f.frame,100.3))
   self.assertTrue(self.e._completed_point_wait_tick(self.f.frame,102.6));repair.assert_not_called()
  self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.view_recovery)
  self.assertNotIn((1,99),self.e.resource_retry_after);self.assertIsNotNone(self.e.return_resource)
  self.assertEqual(self.f.pad.presses,0)
 def test_new_active_attempt_does_not_move_camera_or_repeat_click(self):
  self.f.f.attempt_active=True
  with patch.object(self.e,'_view_recovery_tick',side_effect=AssertionError('active gather must be left alone')):
   self.assertFalse(self.e._completed_point_wait_tick(self.f.frame,100))
  self.assertEqual(self.f.pad.presses,0)

class SceneAndEngineIntegration(unittest.TestCase):
 def setUp(self):
  self.fx=hybridfx.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.fx.setUp()
  self.addCleanup(self.fx.doCleanups);self.addCleanup(self.fx.tearDown);self.e=self.fx.e
 def test_turn_pacing_keeps_translation_while_fresh_scene_catches_up(self):
  self.e.nav.goal=Marker('Эфир',220,160,1,30,'aether');self.e.scene_host=Mock();self.e.scene_turn_after=time.monotonic()+10
  with patch.object(self.e.gamepad,'drive') as drive:
   self.e._motion(Drive(.8,.1,.4,lifetime=.5))
  self.assertGreater(drive.call_args.args[0],.7);self.assertEqual(drive.call_args.args[2],0)
 def test_direct_goal_uses_local_side_follower_before_legacy_escape(self):
  r=radar();r.heading=90;r.confidence=1;r.markers=[Marker('Эфир',r.center[0]+35,r.center[1],1,35,'aether')]
  self.e.nav.goal=r.markers[0];self.e.nav.goal_epoch=2;self.e.cfg['terrain_experience_enabled']=False
  self.e.scene_host.latest=view(time.monotonic());self.e.scene_host.current=lambda *a:self.e.scene_host.latest
  from flight import FlightReading
  plan=self.e._scene_plan(self.fx.frame,r,FlightReading(None,False),Drive(.9),time.monotonic())
  self.assertGreater(abs(plan.strafe),.7);self.assertEqual(plan.yaw,0);self.assertTrue(self.e.obstacle_follow.active)
 def test_sky_scan_cannot_interrupt_an_active_ground_bypass(self):
  from flight import FlightReading
  r=radar();r.heading=90;r.confidence=1;r.markers=[Marker('Эфир',r.center[0]+25,r.center[1],1,25,'aether')]
  self.e.nav.goal=r.markers[0];self.e.nav.goal_epoch=2;self.e.cfg['terrain_experience_enabled']=False
  now=time.monotonic();self.e.scene_host.current=lambda *a:view(now)
  self.e._scene_plan(self.fx.frame,r,FlightReading(None,False),Drive(.9),now)
  self.assertTrue(self.e.obstacle_follow.active);self.e.nav.air_since=now
  plan=self.e._scene_plan(self.fx.frame,r,FlightReading(None,False),Drive(pitch=.45),now+.1)
  self.assertEqual(plan.pitch,0);self.assertIsNone(self.e.nav.air_since);self.assertGreater(abs(plan.strafe),.7)
 def test_memory_is_not_written_from_merely_proposed_detour(self):
  self.e.path_episode={'saved':False};self.e._path_collection_reached()
  self.assertFalse(self.e.path_memory.records)
 def test_saved_leg_can_wait_for_distant_approach_to_reach_its_start(self):
  r=radar();r.bounds=(0,0,313,313);r.center=(156,156);r.motion_valid=True
  goal=Marker('Эфир',236,156,1,80,'aether');self.e.nav.goal=goal;self.e.nav.goal_epoch=8
  state=self.fx.source.state
  zone='map:'+str(state.map_id) if state.map_id is not None else 'camp:'+str(self.e.cfg.get('map_return_destination',''))
  guide=ExperienceGuide([(-25,0),(-25,-4),(-20,-8)])
  self.e.path_episode={'key':(zone,8,'aether'),'guide':guide,'leg':None,'points':[],'near_at':-1e9}
  self.e._path_context(self.fx.frame,r,goal,100)
  self.assertFalse(guide.lost);self.assertIsNone(guide.index)
  goal.x=181;goal.distance=25;self.e._path_context(self.fx.frame,r,goal,101)
  self.assertIsNotNone(self.e.path_episode['leg']);self.assertFalse(guide.lost)
 def test_success_is_saved_only_after_own_attempt_near_same_resource(self):
  now=time.monotonic();self.e.path_memory=TerrainExperience()
  from types import SimpleNamespace
  rng=np.random.default_rng(9);values=rng.normal(size=256).tolist();sig={'values':values,'mask':[1]*256}
  self.e.path_episode={'saved':False,'kind':'gem','near_at':now,'at':now-5,'side':1,'travel':6,
    'zone':'map:1','sector':3,'signature':sig}
  self.e.target='Алмаз';self.fx.source.state.attempt_active=True
  with patch.object(self.e,'_net_gather_proof',return_value=True),patch.object(self.e,'_net_node',return_value=SimpleNamespace(template=123,xyz=(1,2,3))):
   self.e._path_collection_reached();self.e._path_collection_reached()
  self.assertEqual(len(self.e.path_memory.records),1);self.assertEqual(self.e.path_memory.records[0]['wins'],1)
 def test_partial_or_far_approach_cannot_create_successful_memory(self):
  now=time.monotonic();self.e.path_memory=TerrainExperience()
  self.e.path_episode={'saved':False,'kind':'gem','near_at':now-30,'at':now-40,'side':1,'travel':6}
  self.e.target='Алмаз';self.fx.source.state.attempt_active=True
  with patch.object(self.e,'_net_gather_proof',return_value=True):self.e._path_collection_reached()
  self.assertFalse(self.e.path_memory.records)
 def test_neutralization_stops_delivered_bypass_time_immediately(self):
  self.e.obstacle_follow.phase='BYPASS';self.e.obstacle_follow.delivered(100,100.7,True)
  with patch('hybrid_engine.time.monotonic',return_value=100.2):self.e._neutral()
  self.e.obstacle_follow.advance(104);self.assertAlmostEqual(self.e.obstacle_follow.walk,.2)
 def test_manual_stop_is_set_before_waiting_for_memory_writer(self):
  def flush():self.assertTrue(self.e.stop_event.is_set())
  self.e.path_memory.close=flush;self.e.stop(manual=True)
  self.assertTrue(self.e.stop_event.is_set())
  if self.e.release_thread:self.e.release_thread.join(1)
 def test_post_teleport_exit_clears_previous_bypass(self):
  from types import SimpleNamespace
  self.e.bridge.controller_native=True;self.e.obstacle_follow.phase='BYPASS';self.e.path_episode={}
  self.e._map_teleport_arrived(SimpleNamespace(used=True,destination='camp'),time.monotonic())
  self.assertFalse(self.e.obstacle_follow.active);self.assertIsNone(self.e.path_episode);self.assertEqual(self.e.mode,'POST_TP_EXIT')

if __name__=='__main__':unittest.main()
