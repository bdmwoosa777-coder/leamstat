"""A real own end must use a fresh near caption, not wait on a shared badge."""
import unittest
from dataclasses import replace
from unittest.mock import patch,Mock
import gather_engine as ge
import test_fresh_owned_click as ownfx
import test_hybrid as hybridfx
from test_ether_emblem import scene,ether
from vision import Observation

class OwnNameRefresh(unittest.TestCase):
 def setUp(self):
  self.fx=ownfx.FreshOwnPoint('test_zero_selection_does_not_prepend_a_second_a');self.fx.setUp()
  self.addCleanup(self.fx.doCleanups);self.addCleanup(self.fx.tearDown);self.e=self.fx.e
  self.old=self.e.candidate;self.fx.frame=scene(y=650);self.near=ether(self.fx.frame)
 def observe(self):return self.e._network_world_observation(self.fx.frame)
 def test_worker_refreshes_live_name_before_first_attempt_ends(self):
  self.fx.f.attempt_active=True
  with patch('gather_engine.find_world_resource',side_effect=AssertionError('general OCR')):
   obs=self.observe()
  self.assertIsNotNone(obs.candidate.glyph);self.assertGreater(obs.candidate.box[1],self.old.box[1]+350)
 def test_real_end_after_prewarmed_caption_delivers_next_click_without_eight_second_wait(self):
  self.fx.f.attempt_active=True;obs=self.observe()
  self.e.snapshot=(obs,self.fx.clock,1,self.fx.clock)
  self.fx.f.attempt_active=False;self.fx.f.selected=0
  self.e.f_enable()
  self.assertEqual(len(self.fx.clicks),1);self.assertLess(self.fx.clock,101)
  self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.e.mode,'GATHER')
 def test_generic_badge_does_not_block_background_named_recovery(self):
  self.fx.f.selected=0;self.fx.f.attempt_active=False
  generic=replace(self.near,glyph=None)
  with patch('gather_engine.find_resource_near',return_value=None),patch('gather_engine.fast_ether_candidates',return_value=[]),patch('gather_engine.find_selected_resource_badge',return_value=generic),patch.object(self.e,'_world_resource',return_value=self.near) as named:
   obs=self.observe()
  self.assertIsNotNone(obs.candidate.glyph);named.assert_called_once_with(self.fx.frame,('Эфир',))
 def test_hidden_letters_still_cannot_authorize_blind_click(self):
  self.fx.frame[:]=35;self.fx.f.selected=0;self.e.snapshot=None;self.e.f_enable()
  self.assertFalse(self.fx.clicks)
 def test_background_mode_change_cannot_publish_none_name_or_old_candidate(self):
  self.fx.f.attempt_active=False
  def change(*a,**kw):self.e.target=None;self.e.target_confirmed=False;return []
  with patch('gather_engine.find_resource_near',return_value=None),patch('gather_engine.fast_ether_candidates',side_effect=change),patch('gather_engine.find_selected_resource_badge',return_value=None),patch('gather_engine.find_owned_resource_emblem',return_value=None),patch.object(self.e,'_world_resource',return_value=self.near) as names:
   obs=self.observe()
  self.assertIsNone(obs.candidate)
  self.assertTrue(all(call.args[1]==('Эфир',) for call in names.call_args_list))
 def test_same_name_new_binding_discards_old_background_answer(self):
  def change(*a,**kw):self.e.network_target=(1,123);return [self.near]
  with patch('gather_engine.find_resource_near',return_value=None),patch('gather_engine.fast_ether_candidates',side_effect=change):obs=self.observe()
  self.assertIsNone(obs.candidate)

class OptionalStartupAndNames(unittest.TestCase):
 def setUp(self):
  self.fx=hybridfx.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.fx.setUp()
  self.addCleanup(self.fx.doCleanups);self.addCleanup(self.fx.tearDown);self.e=self.fx.e
 def test_optional_worker_can_run_before_first_minimap_step(self):
  self.e.cfg['nearby_ground_exception']=True
  self.assertIsNone(self.e.resource_radar)
  self.e._observe_nearby_ground(self.fx.frame)
  self.assertIsNone(self.e.nearby_ground_proof)
 def test_empty_or_none_target_never_goes_to_ocr_process(self):
  self.e.world_process=Mock()
  self.assertIsNone(self.e._world_resource(self.fx.frame,(None,'')))
  self.e.world_process.search.assert_not_called()
 def test_only_real_names_reach_background_process(self):
  self.e.world_process=Mock();self.e._world_resource(self.fx.frame,(None,'Эфир',''))
  self.assertEqual(self.e.world_process.search.call_args.args[1],('Эфир',))

if __name__=='__main__':unittest.main()
