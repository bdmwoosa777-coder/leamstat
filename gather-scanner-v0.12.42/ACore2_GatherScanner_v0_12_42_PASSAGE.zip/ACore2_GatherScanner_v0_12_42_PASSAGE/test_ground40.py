"""Ground hits must not inherit the downward Ether-collection search."""
import unittest
from unittest.mock import patch
import gather_engine as ge
import test_combat39 as fixtures
from flight import FlightReading

class GroundDefenseScope(unittest.TestCase):
 def setUp(self):
  self.f=fixtures.AirCollectionResume('test_kill_defers_homing_until_resource_finishes')
  self.f.setUp();self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
  self.e=self.f.e;self.s=self.f.s;self.drives=[];self.commands=self.f.f.commands
  original=self.e.gamepad.drive
  def drive(*args,**kwargs):self.drives.append(args);return original(*args,**kwargs)
  self.e.gamepad.drive=drive
 def patrol(self):
  e=self.e;e.mode='SEARCH';e.target=None;e.network_target=None
  e.target_confirmed=False;e.resource_hold=False
  self.s.collecting=None;self.s.attempt_active=False;self.s.selected=0
  # This is the faulty log's context: stale generic air indicators, no resource.
  e.budget.airborne=True;e.resource_flight_owned=True;e.last_flight_seen_at=self.f.clock
 def begin(self,resume):self.e._begin_network_defense(resume)
 def assert_keeps_pitch(self):
  self.assertIsNotNone(self.e.network_defense)
  self.assertIsNone(self.e.defense_air_view);self.assertIsNone(self.e.defense_camera_until)
  self.assertFalse(any(len(d)>=4 and d[3]!=0 for d in self.drives))
 def tick(self,seconds=.06):
  self.f.clock+=seconds;self.f.wall+=round(seconds*1000)
  return self.e._network_defense_tick(self.f.clock)
 def test_log_search_with_stale_air_budget_does_not_tilt(self):
  self.patrol();self.begin(False);self.assert_keeps_pitch();self.tick()
  self.assertIn('TAB',self.commands);self.assert_keeps_pitch()
 def test_even_a_visible_arc_outside_ether_collection_does_not_tilt(self):
  self.patrol()
  with patch.object(ge,'read_flight',return_value=FlightReading(70,True,200)):self.begin(False)
  self.assert_keeps_pitch()
 def test_ground_fight_selects_attacks_and_finishes_without_camera_calibration(self):
  self.patrol();before=self.e.pitch.offset(self.f.clock)
  with patch.object(self.e,'_hold_pitch_up',side_effect=AssertionError('ground fight cannot home camera')),patch.object(self.e,'_hold_pitch_down',side_effect=AssertionError('ground fight cannot lower camera')):
   self.begin(False);self.tick();self.s.selected=55;self.s.selection_time=self.f.wall+1
   self.tick(.2);self.tick(.2);self.assertIn('ATTACK_PAIR',self.commands)
   self.s.deaths[55]=self.f.wall;self.tick();self.tick()
  self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.network_defense)
  self.assertIsNone(self.e.defense_restore_view);self.assertAlmostEqual(self.e.pitch.offset(self.f.clock),before)
  self.assertFalse(any(len(d)>=4 and d[3]!=0 for d in self.drives))
 def test_ground_fight_does_not_align_an_upward_offset_before_tab(self):
  self.patrol();self.e.pitch.balance=.4;self.begin(False);self.tick()
  self.assert_keeps_pitch();self.assertIn('TAB',self.commands);self.assertAlmostEqual(self.e.pitch.offset(self.f.clock),.4)
 def test_ground_fight_does_not_align_a_downward_offset_before_tab(self):
  self.patrol();self.e.pitch.balance=-.4;self.begin(False);self.tick()
  self.assert_keeps_pitch();self.assertIn('TAB',self.commands);self.assertAlmostEqual(self.e.pitch.offset(self.f.clock),-.4)
 def test_ground_gem_collection_does_not_tilt_even_with_old_air_flags(self):
  self.e.target='Алмаз';self.s.nodes[99].template=1550020
  self.e.budget.airborne=True;self.e.last_flight_seen_at=self.f.clock
  self.begin(True);self.assert_keeps_pitch()
 def test_named_ether_approach_without_own_collection_does_not_tilt(self):
  self.e.mode='APPROACH';self.s.collecting=None;self.s.attempt_active=False;self.s.nodes[99].gather_time=None
  self.e.budget.airborne=True;self.e.last_flight_seen_at=self.f.clock
  self.begin(True);self.assert_keeps_pitch()
 def test_gather_flags_without_network_own_start_are_not_enough(self):
  self.s.collecting=None;self.s.attempt_active=False;self.s.nodes[99].gather_time=None
  self.assertTrue(self.e.fast_gather_seen);self.assertTrue(self.e.real_gather_panel_seen)
  self.begin(True);self.assert_keeps_pitch()
 def test_fresh_actual_ether_attempt_retains_the_air_down_search(self):
  self.begin(True);self.assertIsNotNone(self.e.defense_air_view)
  self.assertEqual(self.e.defense_air_view.phase,'DOWN');self.assertIsNone(self.e.defense_camera_until)
 def test_own_ether_attempt_still_works_when_arc_is_obscured(self):
  with patch.object(ge,'read_flight',return_value=FlightReading(None,False)):self.begin(True)
  self.assertIsNotNone(self.e.defense_air_view)
 def test_network_start_can_precede_the_gather_mode_transition(self):
  self.e.mode='APPROACH';self.begin(True)
  self.assertIsNotNone(self.e.defense_air_view)
 def test_later_private_attempt_is_fresh_even_if_interaction_started_earlier(self):
  self.f.wall=22000;self.s.started=1000;self.s.nodes[99].gather_time=21900
  self.s.attempt_ordinal=3;self.s.nodes[99].used=2;self.s.attacks[55]=21990
  self.begin(True);self.assertIsNotNone(self.e.defense_air_view)
 def test_paired_private_attempt_may_arrive_before_interaction_broadcast(self):
  self.s.nodes[99].gather_time=1000;self.s.started=1020
  self.begin(True);self.assertIsNotNone(self.e.defense_air_view)
 def test_between_ether_attempts_a_fresh_own_result_preserves_air_context(self):
  self.s.attempt_active=False;self.s.last_own_result=(99,self.f.wall-200);self.s.last_own_result_used=1
  self.begin(True);self.assertIsNotNone(self.e.defense_air_view)
 def test_stale_private_attempt_does_not_use_generic_air_flags(self):
  self.f.wall=20000;self.s.attacks[55]=19990
  self.begin(True);self.assert_keeps_pitch()
 def test_exhausted_ether_cannot_start_a_down_search(self):
  self.s.nodes[99].used=3;self.begin(True);self.assert_keeps_pitch()
 def test_another_collecting_id_does_not_authorize_this_ether(self):
  self.s.collecting=100;self.begin(True);self.assert_keeps_pitch()
 def test_wrong_known_resource_template_cannot_authorize_an_ether_down_search(self):
  self.s.nodes[99].template=1550020;self.begin(True);self.assert_keeps_pitch()
 def test_swimming_cannot_authorize_an_ether_down_search(self):
  with patch.object(ge,'read_flight',return_value=FlightReading(70,True,200,swimming=True)):self.begin(True)
  self.assert_keeps_pitch()
 def test_disabled_air_search_keeps_pitch_for_actual_ether_too(self):
  self.e.cfg['defense_air_search']=False;self.begin(True);self.assert_keeps_pitch()
 def test_changed_owner_cannot_authorize_old_ether_binding(self):
  self.s.own=8;self.begin(True);self.assert_keeps_pitch()
