"""Actual pixels sent to HTTP, request correlation, and camp entry radius."""
import base64,hashlib,json,tempfile,threading,time,unittest
from dataclasses import replace
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from unittest.mock import patch
import cv2,numpy as np
from qwen_canvas import mask_world,compose,prompt,route_context
from qwen_experiment import TemporalAdvisor,TemporalClient,View,MODEL
from test_qwen_experiment import ANSWER,CTX
from test_hybrid import FRAME,scene
from test_navigation import radar
from return_exit import purple_anchor
import test_camp_departure as camp_fixture

class FullViewPixels(unittest.TestCase):
 def test_world_sides_and_top_corners_remain_visible(self):
  frame=np.full((360,640,3),(80,130,190),np.uint8);world=mask_world(frame)
  for x,y in ((.1,.1),(.9,.5),(.1,.8),(.9,.95),(.45,.5)):
   np.testing.assert_array_equal(world[int(y*360),int(x*640)],frame[int(y*360),int(x*640)])
  np.testing.assert_array_equal(world[340,350],(25,25,25))
 def test_only_skill_bar_rectangle_changes_and_never_a_quarter_screen(self):
  frame=np.full((360,640,3),200,np.uint8);world=mask_world(frame)
  changed=np.any(world!=frame,axis=2);expected=np.zeros((360,640),bool)
  expected[round(.85*360):,round(.32*640):round(.74*640)]=True
  np.testing.assert_array_equal(changed,expected);self.assertLess(float(changed.mean()),.07)
 def test_original_minimap_stays_at_same_position_without_added_black_footer(self):
  frame=np.full((360,640,3),90,np.uint8);frame[40:110,540:630]=(20,210,70)
  v=View(100,90,0,CTX,mask_world(frame),np.full((224,224,3),240,np.uint8))
  image=compose(v);self.assertEqual(image.shape,(360,640,3))
  np.testing.assert_array_equal(image[75,585],frame[75,585]);self.assertFalse(np.any(image==240))
 def test_compact_image_retains_aspect_and_all_four_world_edges(self):
  frame=np.full((360,640,3),90,np.uint8);frame[:8]=(10,170,240);frame[-8:]=(240,70,30)
  image=compose(View(100,90,0,CTX,frame,None),compact=True)
  self.assertEqual(image.shape,(288,512,3));np.testing.assert_array_equal(image[0,0],frame[0,0])
  np.testing.assert_array_equal(image[-1,-1],frame[-1,-1])
 def test_paths_do_not_paint_lines_or_labels_over_world(self):
  view=View(100,90,0,{**CTX,'ground_routes':route_context(scene().ground)},FRAME.copy(),None)
  np.testing.assert_array_equal(compose(view),FRAME)
 def test_prompt_does_not_offer_path_confidence_to_copy_as_visual_confidence(self):
  paths=[{'id':2,'bearing_offset':4.7,'confidence':.637129,'points':[[.5,.7],[.54,.45]]}]
  text=prompt((View(100,90,0,{**CTX,'ground_routes':paths},FRAME,None),))
  self.assertNotIn('0.637129',text);self.assertIn('visual judgment',text);self.assertIn('top-right',text)
 def test_real_http_receives_uncovered_left_right_and_top_of_game(self):
  received={}
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_POST(self):
    received.update(json.loads(self.rfile.read(int(self.headers['Content-Length']))))
    body=(json.dumps({'done':True,'message':{'content':json.dumps(ANSWER)}})+'\n').encode()
    self.send_response(200);self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
  server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   frame=np.full((360,640,3),170,np.uint8);c=TemporalClient('http://127.0.0.1:'+str(server.server_port));c.single_frame=True
   c.analyze_views((View(100,90,0,CTX,mask_world(frame),None),))
   images=received['messages'][0]['images'];self.assertEqual(len(images),1)
   decoded=cv2.imdecode(np.frombuffer(base64.b64decode(images[0]),np.uint8),1)
   self.assertEqual(decoded.shape,(360,640,3))
   for y,x in ((10,10),(180,590),(300,50)):self.assertGreater(int(decoded[y,x,0]),160)
   self.assertLess(int(decoded[340,350,0]),30)
  finally:server.shutdown();server.server_close();thread.join()

class CorrelatedReports(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=Path(self.tmp.name)
  self.h=TemporalAdvisor({'ollama_autostart':False},lambda _:None);self.h.report_root=self.root
  self.c=TemporalClient();self.c.single_frame=True;self.c.keep_alive='10m'
  self.h.runtime_client=self.c;self.h.warmed=True;self.h.last_model_use=time.monotonic()
  self.reply=dict(ANSWER)
  def call(path,payload=None,**kw):
   if path=='/api/chat':return {'message':{'content':json.dumps(self.reply)}}
   return {'models':[],'version':'test'}
  self.c.call=call
 def invoke(self):
  now=time.monotonic();self.h.last_offer=-1e9;self.h.last_observe=-1e9
  self.h.observe(FRAME,now,90,0,CTX,(500,0,640,140))
  with patch('qwen_diagnostics.snapshot',return_value={}):
   self.assertTrue(self.h.offer(FRAME,None,now,90,0,CTX));self.h.worker.join(3)
  self.assertFalse(self.h.worker.is_alive())
 def records(self):
  return [json.loads((self.root/name).read_text()) for name in ('qwen_last_advice.json','qwen_last_view.json')]
 def test_successful_advice_and_view_have_same_request_source_and_encoded_hash(self):
  self.invoke();advice,view=self.records();self.assertEqual(advice,view)
  digest=hashlib.sha256((self.root/'qwen_last_view.jpg').read_bytes()).hexdigest()
  self.assertEqual(advice['image_sha256'],digest);self.assertEqual(advice['request'],1)
  self.assertEqual(advice['heading'],90);self.assertEqual(advice['answer'],ANSWER);self.assertEqual(advice['status'],'answered')
 def test_invalid_confidence_keeps_actual_reply_without_turning_it_into_an_action(self):
  self.reply={**ANSWER,'confidence':True};self.invoke();advice,view=self.records()
  self.assertEqual(advice,view);self.assertEqual(advice['status'],'error');self.assertIsNone(advice['answer'])
  self.assertEqual(json.loads(advice['response_content'])['confidence'],True)
  self.assertIn('confidence',advice['error']);self.assertIsNone(self.h.latest)
 def test_failed_next_request_overwrites_previous_advice_instead_of_mixing_frames(self):
  self.invoke();self.reply={**ANSWER,'confidence':-1};self.invoke();advice,view=self.records()
  self.assertEqual(advice,view);self.assertEqual(view['request'],2);self.assertIsNone(advice['answer'])
  self.assertEqual(view['status'],'error');self.assertEqual(json.loads(view['response_content'])['confidence'],-1)
 def test_failure_before_encoding_cannot_relabel_previous_jpeg_as_new_input(self):
  self.invoke();self.assertTrue((self.root/'qwen_last_view.jpg').exists())
  self.h.runtime_client=self.c
  self.c.analyze_views=lambda *args,**kw:(_ for _ in ()).throw(ValueError('encoding failed'))
  self.invoke();advice,view=self.records()
  self.assertEqual(view['request'],2);self.assertFalse(view['image_available']);self.assertIsNone(view['image_sha256'])
  self.assertFalse((self.root/'qwen_last_view.jpg').exists());self.assertEqual(view['stats'],{})
  self.assertEqual(view['image_count'],0)
 def test_error_diagnostics_time_is_not_misreported_as_model_inference_latency(self):
  clock=[100.];original=self.c.call
  self.h.last_model_use=100.;self.reply={**ANSWER,'confidence':-1}
  def call(path,payload=None,**kw):
   if path=='/api/chat':clock[0]=105.
   return original(path,payload,**kw)
  def diagnostics(*args):clock[0]+=20;return {}
  self.c.call=call
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch('qwen_diagnostics.snapshot',side_effect=diagnostics):
   self.h.observe(FRAME,100,90,0,CTX,(500,0,640,140));self.assertTrue(self.h.offer(FRAME,None,100,90,0,CTX));self.h.worker.join(3)
  advice,view=self.records();self.assertEqual(advice['elapsed_ms'],5000)
  self.assertEqual(view['input_layout'],'full_game');self.assertEqual(view['masked_regions'],[[.32,.85,.74,1]])

class CampEntryRange(unittest.TestCase):
 def frame(self):
  frame=np.zeros((207,313,3),np.uint8)
  cv2.rectangle(frame,(202,97),(210,110),(220,70,180),-1)
  return frame
 def test_landmark_fifty_pixels_from_center_needs_explicit_camp_radius(self):
  frame=self.frame();bounds=(0,0,313,207)
  self.assertIsNone(purple_anchor(frame,bounds))
  found=purple_anchor(frame,bounds,search_radius=65);self.assertIsNotNone(found)
  self.assertAlmostEqual(found[0],206,delta=1)
 def test_engine_activates_visible_passage_mode_beyond_old_twenty_six_pixel_gate(self):
  f=camp_fixture.DepartureControl('test_existing_map_ether_does_not_prevent_initial_departure')
  f.setUp();self.addCleanup(f.doCleanups);self.addCleanup(f.tearDown)
  r=replace(radar(),center=(156.5,103.5),bounds=(0,0,313,207))
  f.e._camp_update(self.frame(),r,100)
  self.assertTrue(f.e.hybrid_camp_pending);self.assertIsNone(f.e.camp_route.bearing)
  self.assertGreater(f.e.camp_route.initial,26)
 def test_landmark_outside_camp_radius_does_not_start_departure(self):
  frame=np.zeros((207,313,3),np.uint8);cv2.rectangle(frame,(240,97),(248,110),(220,70,180),-1)
  self.assertIsNone(purple_anchor(frame,(0,0,313,207),search_radius=65))
 def test_exact_bridge_search_keeps_its_existing_default_radius(self):
  self.assertIsNone(purple_anchor(self.frame(),(0,0,313,207)))

if __name__=='__main__':unittest.main()
