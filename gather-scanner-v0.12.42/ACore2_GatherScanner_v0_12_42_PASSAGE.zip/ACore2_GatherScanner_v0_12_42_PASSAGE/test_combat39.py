"""An owned resource survives multiple mobs without repeated camera homing."""
import unittest,time
from unittest.mock import patch
import cv2,numpy as np
import test_hybrid as fx
from test_ether_emblem import scene,ether
from gamepad_input import GamepadInput
from combat_resume import CombatResource,UnownedFlightGate
from flight import FlightReading
from network_defense import AirDefenseView

class AirCollectionResume(unittest.TestCase):
 def setUp(self):
  self.f=fx.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e;self.s=self.f.source.state
  self.clock=100.;self.wall=1100
  def wait(seconds,*args):self.clock+=seconds;return True
  for p in (patch('hybrid_engine.time.monotonic',side_effect=lambda:self.clock),patch('hybrid_engine.time.time',side_effect=lambda:self.wall/1000),patch.object(GamepadInput,'wait',side_effect=wait)):
   p.start();self.addCleanup(p.stop)
  self.e.cfg.update(defense_air_search=True,collection_event_driven=True,resource_click_interaction=True,
   repeat_owned_clicks=True,preserve_owned_resource=True,native_cursor_chord=True,calibrate_during_collection=False)
  self.e.bridge.controller_native=True
  send=self.e.bridge.send
  self.e.bridge.send=lambda c:(send(c),True)[1]
  self.s.nodes[99].template=1500000;self.s.nodes[99].used=1;self.s.nodes[99].gather_time=1000
  self.s.nodes[99].generation=1700000000000
  self.s.collecting=99;self.s.started=1000;self.s.attempt_active=True;self.s.attempt_ordinal=2;self.s.selected=99
  self.s.attacks[55]=1000;self.s.npcs[55]={'time':900,'born_at':900}
  self.e.network_attacker=55;self.e.network_target=(1,99);self.e.network_owner=7;self.e.network_claimed_at=900;self.e.network_bound_at=90
  self.e.target='Эфир';self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER'
  self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True;self.e.resource_flight_owned=True;self.e.budget.airborne=True
  self.f.frame=scene();self.e.candidate=ether(self.f.frame);self.e.current_size=(2480,1395)
  self.assertIsNotNone(self.e._observe_owned_emblem(self.f.frame,self.clock))
 def begin(self):self.e._begin_network_defense(True)
 def finish(self):
  self.e.defense_air_view.phase='READY';self.e.defense_air_view.moved=True;self.e.pitch.balance=-.7
  self.e.network_defense.interrupted_at=self.wall;self.s.collecting=None;self.s.attempt_active=False;self.s.selected=55
  self.s.deaths[55]=self.wall;self.e._finish_network_defense(True)
 def resume_select(self):
  self.begin();self.finish();self.clock+=.2
  self.assertTrue(self.e._combat_resume_tick(self.f.frame,self.clock))
 def test_kill_defers_homing_until_resource_finishes(self):
  self.begin();self.finish()
  self.assertEqual(self.e.mode,'REACQUIRE');self.assertIsNone(self.e.defense_restore_view)
  self.assertIsNotNone(self.e.combat_resource.view)
  with patch.object(self.e,'_hold_pitch_up',side_effect=AssertionError('no homing between mobs')):
   self.e._network_defense_tick(self.clock)
  self.assertEqual(self.e.pitch.offset(self.clock),-.7)
 def test_second_mob_reuses_down_view_without_another_two_second_hold(self):
  self.begin();self.finish();self.e.network_attacker=66;self.s.npcs[66]={'time':900,'born_at':900};self.s.attacks[66]=1100
  self.e._begin_network_defense(True)
  self.assertEqual(self.e.defense_air_view.phase,'READY');self.assertIsNone(self.e.defense_camera_until)
  self.assertAlmostEqual(self.e.pitch.offset(self.clock),-.7)
 def test_current_track_can_select_again_without_requiring_resource_word(self):
  x,y,w,h=self.e.candidate.box;self.f.frame[y:y+h,x:x+w]=(230,220,30)
  self.resume_select()
  self.assertEqual(self.f.pad.presses,1);self.assertIsNotNone(self.e.combat_resource.pending)
  self.assertNotIn('END_AIR',self.f.commands);self.assertNotIn('TAP_F',self.f.commands)
 def test_same_id_confirmation_binds_native_approach_without_a_second_a(self):
  self.resume_select();self.s.selected=99;self.s.selection_time=1101;self.clock+=.3
  self.e._combat_resume_tick(self.f.frame,self.clock)
  self.assertEqual(self.e.mode,'APPROACH');self.assertTrue(self.e.route_f_sent);self.assertEqual(self.e.network_target,(1,99))
  self.assertEqual(self.f.pad.presses,1);self.assertIsNotNone(self.e.combat_resource)
 def test_new_own_start_adopts_collection_without_cancel_or_camera_restore(self):
  self.resume_select();self.s.selected=99;self.s.selection_time=1101;self.clock+=.3
  self.e._combat_resume_tick(self.f.frame,self.clock)
  self.s.collecting=99;self.s.started=1200;self.s.nodes[99].gather_time=1200;self.s.attempt_active=True;self.wall=1200
  self.e._adopt_network_collection();self.e._net_resource(self.f.frame,FlightReading(70,True),self.clock)
  self.assertEqual(self.e.mode,'GATHER');self.assertTrue(self.e.resource_hold);self.assertIsNone(self.e.defense_restore_view)
  self.assertEqual(self.f.pad.presses,1);self.assertNotIn('END_AIR',self.f.commands)
 def test_other_selected_resource_cannot_get_an_activation_click(self):
  self.resume_select();self.s.selected=100;self.s.selection_time=1101;self.clock+=.3
  self.e._combat_resume_tick(self.f.frame,self.clock)
  self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.f.pad.presses,1);self.assertIsNone(self.e.combat_resource.pending)
 def test_missing_marker_never_reuses_old_point(self):
  self.begin();self.finish();self.f.frame[:]=35;self.clock+=.2
  self.assertFalse(self.e._combat_resume_tick(self.f.frame,self.clock));self.assertEqual(self.f.pad.presses,0)
 def test_new_generation_revokes_old_resource_binding(self):
  self.begin();self.finish();self.s.nodes[99].generation+=1
  self.assertIsNone(self.e._combat_current());self.assertFalse(self.e._combat_resume_tick(self.f.frame,self.clock))
 def test_changed_owner_revokes_old_binding(self):
  self.begin();self.finish();self.s.own=8;self.assertIsNone(self.e._combat_current())
 def test_exhaustion_restores_view_once_before_search(self):
  self.begin();self.finish();self.s.nodes[99].used=3;self.e.mode='SEARCH'
  with patch.object(self.e,'_hold_pitch_up',return_value=True) as up,patch.object(self.e,'_hold_pitch_down',return_value=True) as down:
   self.e._network_defense_tick(self.clock);self.e._network_defense_tick(self.clock+.1)
  up.assert_called_once_with(2);down.assert_called_once();self.assertIsNone(self.e.combat_resource);self.assertIsNone(self.e.defense_restore_view)
 def test_real_partial_collection_panel_blocks_reselect(self):
  self.begin();self.finish()
  with patch('hybrid_engine.gathering_panel_pair',return_value=True):self.e._combat_resume_tick(self.f.frame,self.clock)
  self.assertEqual(self.f.pad.presses,0)
 def test_focus_loss_neutralizes_and_pauses_resume_deadline(self):
  self.begin();self.finish();until=self.e.combat_resource.until
  self.e.screen.focused=lambda:False;self.e._combat_resume_tick(self.f.frame,101)
  self.e.screen.focused=lambda:True;self.clock=106
  self.e._combat_resume_tick(self.f.frame,106)
  self.assertEqual(self.e.combat_resource.until,until+5)
 def test_pending_selection_wait_does_not_repeat_a(self):
  self.resume_select()
  for _ in range(5):self.clock+=.1;self.e._combat_resume_tick(self.f.frame,self.clock)
  self.assertEqual(self.f.pad.presses,1)
 def test_working_view_duration_still_uses_user_setting_at_the_end(self):
  self.e.cfg['camera_working_view_ms']=1050;self.begin();self.finish();self.s.nodes[99].used=3;self.e.mode='SEARCH'
  with patch.object(self.e,'_hold_pitch_up',return_value=True),patch.object(self.e,'_hold_pitch_down',return_value=True) as down:self.e._network_defense_tick(self.clock)
  down.assert_called_once_with(1.05)

 def test_temporary_network_gap_preserves_deferred_view_and_binding(self):
  self.begin();self.finish();lease=self.e.combat_resource;view=self.e._net_view()
  with patch.object(self.e,'_net_view',return_value={**view,'ready':False}),patch.object(self.e,'_hold_pitch_up',side_effect=AssertionError('gap is not depletion')):
   self.e._network_defense_tick(self.clock)
  self.assertIs(self.e.combat_resource,lease);self.assertIsNone(self.e.defense_restore_view)
 def test_a_new_actual_own_attempt_defers_old_view_restore(self):
  self.begin();self.finish();self.e.network_target=(1,100)
  from network_state import Node
  self.s.nodes[100]=Node(100,1500000,used=0,gather_time=1101);self.s.collecting=100
  self.s.selected=100;self.s.started=1101;self.s.attempt_active=True;self.wall=1101
  self.e.mode='GATHER';self.e.target_confirmed=True;self.e.resource_hold=True
  with patch.object(self.e,'_hold_pitch_up',side_effect=AssertionError('active attempt owns camera')):self.e._network_defense_tick(self.clock)
  self.assertIsNone(self.e.combat_resource);self.assertIsNone(self.e.defense_restore_view);self.assertIsNotNone(self.e.camera_alignment_due)
 def test_free_toggle_is_revoked_by_fresh_absent_arc(self):
  self.e.mode='SEARCH';self.e.target_confirmed=False;self.e.resource_hold=False
  self.e.network_target=None;self.e.network_exhausted=False;self.e.real_gather_panel_seen=False
  strong=FlightReading(70,True,200)
  for t in (99,99.3,99.7):self.e.unowned_flight.observe(strong,t)
  with patch('hybrid_engine.read_flight',return_value=FlightReading(None,False)):
   self.assertFalse(self.e._wing_action_allowed('END_AIR'))
 def test_own_depletion_close_does_not_wait_for_unowned_arc_gate(self):
  self.e.network_exhausted=True
  with patch('hybrid_engine.read_flight',side_effect=AssertionError('owned exhaustion does not need free arc')):
   self.assertTrue(self.e._wing_action_allowed('END_AIR'))

class FreeFlightConfirmation(unittest.TestCase):
 def setUp(self):self.g=UnownedFlightGate();self.strong=FlightReading(70,True,200)
 def test_one_arc_frame_cannot_toggle_wings(self):self.assertFalse(self.g.observe(self.strong,100))
 def test_several_strong_frames_and_time_are_required(self):
  for t in (100,100.2,100.4):self.assertFalse(self.g.observe(self.strong,t))
  self.assertTrue(self.g.observe(self.strong,100.7))
 def test_gap_or_negative_frame_revokes_confirmation(self):
  for t in (100,100.3,100.7):self.g.observe(self.strong,t)
  self.assertFalse(self.g.observe(FlightReading(None,False),101));self.assertFalse(self.g.observe(self.strong,101.1))
 def test_weak_swimming_or_unknown_energy_is_not_close_authority(self):
  for reading in (FlightReading(80,True,120),FlightReading(None,True,200),FlightReading(None,False,200,True)):
   for t in (100,100.4,100.8):self.assertFalse(self.g.observe(reading,t))
 def test_fast_polling_does_not_prevent_counting_distinct_frames(self):
  for i in range(20):ready=self.g.observe(self.strong,100+i*.05)
  self.assertTrue(ready)
 def test_stale_strong_arc_cannot_keep_permission_forever(self):
  for t in (100,100.3,100.7):self.g.observe(self.strong,t)
  self.assertFalse(self.g.observe(self.strong,104))

if __name__=='__main__':unittest.main()
