"""Occluded airborne Ether, departure camera, loading grace and wall surveys."""
import unittest
from dataclasses import replace
from unittest.mock import patch,Mock
import gather_engine as ge
import hybrid_engine as he
from navigation import Drive
from flight import FlightReading
from minimap import Marker
from post_tp_exit import BackExit
from obstacle_follow import ObstacleFollower
from test_navigation import radar
from test_path38 import view,FREE,WALL
import test_view_recovery as vr
import test_handoff41 as handoff
import test_hybrid as hybrid

AIR=FlightReading(70,True)
GROUND=FlightReading(None,False)

class EtherSideViews(unittest.TestCase):
 def setUp(self):
  self.f=vr.ViewRecoveryTests('test_after_combat_missing_point_gets_camera_only_views');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.e.target='Эфир';self.e.resource_flight_owned=True;self.f.f.nodes[99].template=1500000;self.f.arm()
 def test_airborne_ether_recovery_only_turns_one_horizontal_direction(self):
  for _ in range(8):
   self.f.clock=self.e.view_recovery.next_at+.01
   self.e._view_recovery_tick(self.f.frame,AIR,self.f.clock)
  self.assertEqual(len(self.f.drives),8)
  for f,s,y,p in self.f.drives:self.assertEqual((f,s,p),(0,0,0));self.assertGreater(y,0)
  self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.e.view_recovery.until,112)
 def test_live_attempt_does_not_rotate_the_camera(self):
  self.f.f.collecting=99;self.f.f.attempt_active=True;self.f.f.nodes[99].gather_time=self.f.wall
  self.e.target_confirmed=True;self.e.resource_hold=True;self.e.mode='GATHER';self.f.clock=101.1
  self.e._view_recovery_tick(self.f.frame,AIR,self.f.clock);self.assertEqual(self.f.drives,[])

class FastOcclusionPeek(unittest.TestCase):
 def setUp(self):
  self.f=handoff.FastVisibleContinuation('test_missing_badge_exits_in_two_and_a_half_seconds_without_camera_or_blacklist');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.f.f.f.frame[:]=35;self.e.resource_flight_owned=True;self.drives=[]
  old=self.e.gamepad.drive
  def drive(*args,**kw):self.drives.append(args);return old(*args,**kw)
  self.e.gamepad.drive=drive
 def tick(self,t):
  self.f.f.clock=t
  with patch.object(self.e,'_fresh_click_candidate',return_value=None),patch('hybrid_engine.read_flight',return_value=AIR):
   return self.e._completed_point_wait_tick(self.f.f.f.frame,t)
 def test_three_side_peeks_share_short_deadline_and_do_not_fly_away(self):
  self.tick(100)
  for t in (100.4,101.1,101.8):self.tick(t)
  self.assertEqual(len(self.drives),3)
  for f,s,y,p in self.drives:self.assertEqual((f,s,p),(0,0,0));self.assertGreater(y,0)
  self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.f.f.f.pad.presses,0)
 def test_new_own_start_prevents_occlusion_peek(self):
  self.tick(100);self.f.s.attempt_active=True;self.tick(100.4);self.assertEqual(self.drives,[])
 def test_partial_bar_prevents_occlusion_peek(self):
  self.tick(100)
  with patch('hybrid_engine.gathering_panel_pair',return_value=True):self.tick(100.4)
  self.assertEqual(self.drives,[])
 def test_gem_does_not_get_airborne_ether_peeks(self):
  self.e.target='Алмаз';self.tick(100);self.tick(100.4);self.assertEqual(self.drives,[])
 def test_focus_loss_prevents_peek(self):
  self.tick(100);self.e.screen.focused=lambda:False;self.tick(100.4);self.assertEqual(self.drives,[])

class DepartureView(unittest.TestCase):
 def setUp(self):
  self.f=hybrid.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.e.bridge.controller_native=True;self.e.cfg.update(post_tp_back_exit_enabled=True,camera_auto_calibrate=True)
  self.e.network_target=None;self.e.target=None;self.e.target_confirmed=False;self.e.resource_hold=False
  s=self.f.source.state;s.collecting=None;s.attempt_active=False;s.attacks.clear()
  for p in (patch.object(self.e,'_defer_return_for_resource',return_value=False),patch.object(self.e,'_resource_options',return_value=[]),patch('hybrid_engine.read_flight',return_value=GROUND),patch('hybrid_engine.gathering_panel_pair',return_value=False)):
   p.start();self.addCleanup(p.stop)
 def test_working_view_is_restored_before_opening_map_not_after_arrival(self):
  events=[];self.e.pitch.balance=-1
  def calibrate(reason):events.append('view');self.e.pitch.set_working_baseline(100);return True
  def start(*args):events.append('map');self.assertEqual(self.e.pitch.offset(100),0);return True
  with patch.object(self.e,'_calibrate_camera',side_effect=calibrate),patch.object(ge.GatherEngine,'_start_map_teleport',side_effect=start):self.assertTrue(self.e._start_map_teleport(100))
  self.assertEqual(events,['view','map'])
 def test_interrupted_view_cannot_open_map(self):
  with patch.object(self.e,'_calibrate_camera',return_value=False),patch.object(ge.GatherEngine,'_start_map_teleport') as start:
   self.assertFalse(self.e._start_map_teleport(100));start.assert_not_called()
 def test_failed_departure_preparation_resumes_search_without_orphan_return_state(self):
  self.e.mode='RETURN';self.e.return_sequence=object();self.e.pitch.pause_return(99)
  with patch.object(self.e,'_calibrate_camera',return_value=False),patch.object(ge.GatherEngine,'_start_map_teleport') as start:
   self.assertFalse(self.e._start_map_teleport(100));start.assert_not_called()
  self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.return_sequence);self.assertFalse(self.e.stop_event.is_set())
  self.assertEqual(self.e.pitch.pause_depth,0)
 def test_airborne_departure_waits_for_landing_before_camera_or_map(self):
  with patch('hybrid_engine.read_flight',return_value=AIR),patch.object(self.e,'_calibrate_camera') as c,patch.object(ge.GatherEngine,'_start_map_teleport') as start:
   self.assertFalse(self.e._start_map_teleport(100));c.assert_not_called();start.assert_not_called()
 def test_resource_appearing_during_calibration_defers_map(self):
  with patch.object(self.e,'_resource_options',side_effect=[[],[Marker('Эфир',10,10,1,10,'aether')]]),patch.object(self.e,'_calibrate_camera',return_value=True),patch.object(ge.GatherEngine,'_start_map_teleport') as start:
   self.assertFalse(self.e._start_map_teleport(100));start.assert_not_called()
 def test_already_open_transfer_does_not_calibrate_again(self):
  self.e.map_teleport=object()
  with patch.object(self.e,'_calibrate_camera') as c,patch.object(ge.GatherEngine,'_start_map_teleport',return_value=True):
   self.assertTrue(self.e._start_map_teleport(100));c.assert_not_called()

class LoadingGrace(unittest.TestCase):
 def test_additional_two_and_half_seconds_do_not_count_as_backwards_motion(self):
  b=BackExit(13.5,100);self.assertFalse(b.ready(100,True));self.assertFalse(b.ready(103.4,True))
  self.assertEqual(b.delivered,0);self.assertTrue(b.ready(103.5,True))
 def test_reappearing_loading_restarts_entire_grace(self):
  b=BackExit(13.5,100);b.ready(100,True);b.ready(103,False)
  self.assertFalse(b.ready(104,True));self.assertFalse(b.ready(107,True));self.assertTrue(b.ready(107.5,True))

class WallSurvey(unittest.TestCase):
 def setUp(self):
  self.f=ObstacleFollower();self.r=radar();self.r.heading=90;self.r.confidence=1
  self.f.observe(('map',1),self.r,100)
 def test_facing_bypass_bearing_but_still_full_wall_keeps_turning(self):
  closed=view(100,1,lanes=(WALL,)*3)
  a=self.f.choose(Drive(.9),closed,self.r,100,30)
  self.r.heading=self.f.bypass_bearing
  a=self.f.choose(Drive(.9),replace(closed,captured=100.5,sequence=2),self.r,100.5,30)
  self.assertNotEqual(a.drive.yaw,0);self.assertEqual((a.drive.forward,a.drive.strafe),(0,0))
 def test_full_wall_survey_is_bounded_without_automatic_flight(self):
  self.f.choose(Drive(.9),view(100,1,lanes=(WALL,)*3),self.r,100,30)
  a=self.f.choose(Drive(.9),view(106.1,2,lanes=(WALL,)*3),self.r,106.1,30)
  self.assertTrue(a.skip);self.assertFalse(a.wall_escape);self.assertEqual(a.drive,Drive())
 def test_open_side_after_survey_immediately_produces_translation(self):
  self.f.choose(Drive(.9),view(100,1,lanes=(WALL,)*3),self.r,100,30)
  a=self.f.choose(Drive(.9),view(100.5,2),self.r,100.5,30)
  self.assertGreater(abs(a.drive.strafe),.7);self.assertEqual(a.drive.yaw,0)
 def test_old_scene_cannot_authorize_side_walking(self):
  self.assertIsNone(self.f.choose(Drive(.9),view(98),self.r,100,30))
 def test_edge_blocks_bypass_translation(self):
  a=self.f.choose(Drive(.9),view(100,1,drop=.1),self.r,100,30);self.assertIsNone(a)
 def test_closed_wall_does_not_reverse_survey_at_the_saved_bearing(self):
  self.f.choose(Drive(.9),view(100,1,lanes=(WALL,)*3),self.r,100,30);sign=self.f.side
  for i,offset in enumerate((-25,0,25)):
   self.r.heading=(self.f.bypass_bearing+offset)%360
   a=self.f.choose(Drive(.9),view(100.2+i*.2,2+i,lanes=(WALL,)*3),self.r,100.2+i*.2,30)
   self.assertGreater(a.drive.yaw*sign,0);self.assertEqual(a.drive.forward,0)
 def test_missing_scene_never_authorizes_translation_or_flight(self):
  self.f.choose(Drive(.9),view(100),self.r,100,30)
  for t in (100.1,100.6,100.9,101.5):
   a=self.f.wait_for_scene(t);self.assertEqual((a.drive.forward,a.drive.strafe),(0,0));self.assertFalse(a.wall_escape)
 def test_missing_scene_cannot_freeze_the_goal_forever(self):
  self.f.choose(Drive(.9),view(100),self.r,100,30);self.f.wait_for_scene(100.1)
  a=self.f.wait_for_scene(103.7);self.assertTrue(a.skip);self.assertFalse(a.wall_escape)
 def test_fresh_side_view_resumes_walking_without_waiting_out_missing_timer(self):
  self.f.choose(Drive(.9),view(100),self.r,100,30);self.f.wait_for_scene(100.1)
  a=self.f.choose(Drive(.9),view(100.3,2),self.r,100.3,30)
  self.assertGreater(abs(a.drive.strafe),.7);self.assertIsNone(self.f.missing_since)

class SceneSupply(unittest.TestCase):
 def setUp(self):
  self.f=hybrid.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.e.scene_host=Mock();self.e.scene_host.current.return_value=None
  self.r=radar();self.r.heading=90;self.r.confidence=1
 def test_turn_only_plan_still_supplies_current_scene_frame(self):
  plan=Drive(yaw=.38);result=self.e._scene_plan(self.f.frame,self.r,GROUND,plan,100)
  self.e.scene_host.offer.assert_called_once();self.assertEqual(result,plan)
 def test_stationary_survey_still_supplies_current_scene_frame(self):
  self.e._scene_plan(self.f.frame,self.r,GROUND,Drive(),100);self.e.scene_host.offer.assert_called_once()
 def test_own_collection_never_enters_scene_survey(self):
  self.e.mode='GATHER';self.e.resource_hold=True
  self.e._scene_plan(self.f.frame,self.r,GROUND,Drive(yaw=.38),100);self.e.scene_host.offer.assert_not_called()
 def test_real_engine_missing_scene_does_not_drive_straight_into_known_wall(self):
  self.e.scene_host.latest=None;self.e.cfg['terrain_experience_enabled']=False
  self.e.nav.goal=Marker('Эфир',self.r.center[0]+35,self.r.center[1],1,35,'aether')
  self.r.markers=[self.e.nav.goal]
  self.e._path_context(self.f.frame,self.r,self.e.nav.goal,100)
  self.e.obstacle_follow.choose(Drive(.9),view(100),self.r,100,35)
  with patch('hybrid_engine.time.monotonic',return_value=100.2):
   plan=self.e._scene_plan(self.f.frame,self.r,GROUND,Drive(.9),100.2)
  self.assertEqual((plan.forward,plan.strafe),(0,0));self.assertIsNotNone(self.e.nav.goal)
  self.e.scene_host.current.return_value=view(100.4,2)
  with patch('hybrid_engine.time.monotonic',return_value=100.4):
   plan=self.e._scene_plan(self.f.frame,self.r,GROUND,Drive(.9),100.4)
  self.assertGreater(abs(plan.strafe),.7)

if __name__=='__main__':unittest.main()
