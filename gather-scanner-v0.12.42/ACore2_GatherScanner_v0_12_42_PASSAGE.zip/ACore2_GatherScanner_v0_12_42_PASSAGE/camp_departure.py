"""Persistent landmark-relative departure; minimap resources are not exit proof."""
import math
from minimap import angle_delta
from navigation import Drive

class CampDeparture:
 def __init__(self,anchor,center,width,now,prefer_visible=False):
  self.anchor=anchor;self.width=width;self.scale=max(.5,width/313)
  self.initial=math.dist(anchor,center)/self.scale;self.distance=self.initial
  self.started=now;self.seen=now;self.until=now+35;self.leg=1;self.failed=[]
  self.view_after=-1e9;self.view_wait=None;self.turning=False
  self.bearing=self.away(anchor,center) if self.initial>=6 and not prefer_visible else None
  self.origin='от кибелиска' if self.bearing is not None else ''
  self.yaw_gain=480.;self.last_turn=None
 @staticmethod
 def away(anchor,center):return math.degrees(math.atan2(center[0]-anchor[0],anchor[1]-center[1]))%360
 def observe(self,anchor,center,now):
  if anchor is None:return False
  self.anchor=anchor;self.seen=now;self.distance=math.dist(anchor,center)/self.scale
  return self.distance>=max(45,self.initial+18)
 def replan(self,now):
  if self.bearing is not None:self.failed.append((self.bearing,now+45))
  self.failed=[f for f in self.failed if now<f[1]]
  self.bearing=None;self.origin='';self.until=now+35;self.leg+=1;self.turning=False
 def choose(self,heading,ground,now):
  if self.bearing is not None or heading is None or ground is None or ground.drop_support>=.04:return self.bearing
  from hybrid_navigation import route_angle
  options=[r for r in ground.routes if r.confidence>=.40 and r.clearance>=.5
           and not any(abs(angle_delta(heading+route_angle(r),b))<22 for b,t in self.failed if now<t)]
  if not options:return None
  route=max(options,key=lambda r:r.score+.20*r.clearance-.003*abs(route_angle(r)))
  self.bearing=(heading+route_angle(route))%360;self.origin='по видимому проходу'
  return self.bearing

 def camera_pulse(self,now,yaw,seconds=.18,reason='выход: один поворот, затем проверка неподвижного обзора'):
  self.view_after=now+seconds+.12;self.view_wait=self.view_after
  return Drive(yaw=yaw,lifetime=.35,yaw_lifetime=seconds,reason=reason)
 def _turn_feedback(self,heading,now):
  previous=self.last_turn
  if previous is None:return
  at,before,strength,seconds=previous
  if heading is None or now-at>1.5:self.last_turn=None;return
  if now-at<seconds+.12:return
  self.last_turn=None;change=abs(angle_delta(heading,before))
  if 3<=change<=120:
   measured=change/(abs(strength)*seconds)
   if 120<=measured<=1500:self.yaw_gain=.5*self.yaw_gain+.5*measured
 def view_plan(self,heading,fresh,now,yaw_sign=1,wait_seconds=2.4):
  self._turn_feedback(heading,now)
  # Turning invalidates the scene revision. Do not counter-turn on a missing
  # scene: leave a stable capture window before any further survey pulse.
  if now<self.view_after:return Drive(reason='выход: стабилизирую обзор после поворота')
  if self.bearing is not None and heading is not None:
   error=angle_delta(self.bearing,heading)
   self.turning=abs(error)>40 or self.turning and abs(error)>22
   if self.turning:
    strength=(.62 if error>0 else -.62)*yaw_sign
    seconds=max(.03,min(.18,abs(error)*.65/(self.yaw_gain*.62)))
    self.last_turn=(now,heading,strength,seconds)
    return self.camera_pulse(now,strength,seconds,
                             reason='выход: дозирую поворот по ошибке курса и измеренной чувствительности')
  self.turning=False
  if fresh:self.view_wait=None;return None
  if self.view_wait is None:self.view_wait=now
  if now-self.view_wait>=max(2.4,min(8,wait_seconds)):
   # An unavailable worker never causes endless immediate rotation or an
   # unbounded wait. One small view change starts another stable window.
   return self.camera_pulse(now,.38*yaw_sign,.12,'выход: кадр не пришёл; один новый ракурс, затем стабилизация')
  return Drive(reason='выход: жду свежий кадр при неподвижной камере')
