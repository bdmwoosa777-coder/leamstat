"""Start an already installed loopback Ollama when connection is refused.
No installation, model pull, process killing or changes to other services.
"""
from pathlib import Path
import os,shutil,subprocess,threading,time,urllib.error,errno

def refused(exc):
 reason=exc.reason if isinstance(exc,urllib.error.URLError) else exc
 return isinstance(reason,ConnectionRefusedError) or getattr(reason,'winerror',None)==10061 or getattr(reason,'errno',None)==errno.ECONNREFUSED

def model_directory(value):
 """Accept the models folder or its parent, without moving/downloading files."""
 if not value:return None
 root=Path(value).expanduser()
 for candidate in (root,root/'models'):
  if (candidate/'blobs').is_dir() and (candidate/'manifests').is_dir():return candidate
 raise ValueError('В папке '+str(root)+' нет blobs и manifests; укажите папку моделей Ollama')

class OllamaService:
 def __init__(self,root,emit,models_path=''):self.root=Path(root);self.emit=emit;self.next_start=0;self.process=None;self.windows=os.name=='nt';self.models_path=models_path;self.models_directory=None
 def ensure(self,exc):
  if not self.windows or not refused(exc) or time.monotonic()<self.next_start:return False
  if self.process is not None and self.process.poll() is None:return False
  self.next_start=time.monotonic()+60
  exe=shutil.which('ollama') or next((str(p) for p in (Path(os.environ.get('LOCALAPPDATA',''))/'Programs/Ollama/ollama.exe',Path(os.environ.get('ProgramFiles','C:/Program Files'))/'Ollama/ollama.exe') if p.is_file()),None)
  if exe is None:self.emit('OLLAMA_START: программа не найдена; выполните SETUP_ANALYZER.bat');return False
  env=os.environ.copy();env['OLLAMA_HOST']='127.0.0.1:11434'
  if self.models_path:
   try:self.models_directory=model_directory(self.models_path)
   except ValueError as err:self.emit('OLLAMA_MODELS_ERROR: '+str(err));return False
   env['OLLAMA_MODELS']=str(self.models_directory)
   self.emit('OLLAMA_MODELS: для запуска сервера '+str(self.models_directory))
  try:
   self.process=subprocess.Popen([exe,'serve'],env=env,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
   process=self.process
   def drain():
    tail=b''
    try:
     while True:
      part=process.stderr.read1(4096)
      if not part:break
      tail=(tail+part)[-65536:];(self.root/'ollama_start.log').write_bytes(tail)
    except OSError:pass
   threading.Thread(target=drain,daemon=True).start();self.emit('OLLAMA_START: запускаю установленный локальный сервер; движение не ждёт запуска');return True
  except OSError as err:self.emit('OLLAMA_START: '+str(err));return False
