import json,tempfile,threading,unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
import ollama_service
from ollama_service import model_directory,OllamaService
from qwen_experiment import TemporalAdvisor,MODEL
from test_qwen_experiment import ANSWER

class ModelLocation(unittest.TestCase):
 def test_exact_models_path_and_parent_resolve_to_same_folder(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'models';(p/'blobs').mkdir(parents=True);(p/'manifests').mkdir()
   self.assertEqual(model_directory(tmp),p);self.assertEqual(model_directory(str(p)),p)
 def test_missing_or_incomplete_folder_is_rejected_without_creation(self):
  with tempfile.TemporaryDirectory() as tmp:
   with self.assertRaises(ValueError):model_directory(tmp)
   self.assertEqual(list(Path(tmp).iterdir()),[])
 def test_explicit_ssd_path_overrides_stale_parent_environment_for_spawn_only(self):
  with tempfile.TemporaryDirectory() as tmp:
   p=Path(tmp)/'models';(p/'blobs').mkdir(parents=True);(p/'manifests').mkdir()
   s=OllamaService(tmp,lambda _:None,tmp);s.windows=True
   process=SimpleNamespace(poll=lambda:None,stderr=SimpleNamespace(read1=lambda n:b''))
   with patch.dict('ollama_service.os.environ',{'OLLAMA_MODELS':'H:/old/missing'}),patch('ollama_service.shutil.which',return_value='ollama.exe'),patch('ollama_service.subprocess.Popen',return_value=process) as spawn:
    self.assertTrue(s.ensure(ConnectionRefusedError()))
    self.assertEqual(spawn.call_args.kwargs['env']['OLLAMA_MODELS'],str(p))
    self.assertEqual(ollama_service.os.environ['OLLAMA_MODELS'],'H:/old/missing')
    self.assertEqual(spawn.call_args.args[0],['ollama.exe','serve'])
 def test_invalid_explicit_path_never_launches_with_stale_environment(self):
  with tempfile.TemporaryDirectory() as tmp:
   s=OllamaService(tmp,lambda _:None,tmp);s.windows=True
   with patch('ollama_service.shutil.which',return_value='ollama.exe'),patch('ollama_service.subprocess.Popen') as spawn:
    self.assertFalse(s.ensure(ConnectionRefusedError()))
   spawn.assert_not_called()

class PrepareConnection(unittest.TestCase):
 def run_host(self,errors,autostart=True,ensure=True):
  h=TemporalAdvisor({'ollama_autostart':autostart},lambda _:None)
  c=SimpleNamespace(model=MODEL,probe=Mock(side_effect=errors),warmup=Mock(),analyze_views=Mock(return_value=dict(ANSWER)),unload=Mock())
  h.client_factory=lambda *args:c;h.service.ensure=Mock(return_value=ensure)
  return h,c
 def prepare(self,h):
  with patch('qwen_diagnostics.snapshot',return_value={}),patch.object(Path,'write_text'):
   h.prepare();h.worker.join(3)
  self.assertFalse(h.worker.is_alive())
 def test_refused_initial_probe_launches_server_and_rechecks_before_loading(self):
  h,c=self.run_host([ConnectionRefusedError(),None]);self.prepare(h)
  h.service.ensure.assert_called_once();self.assertEqual(c.probe.call_count,2)
  c.warmup.assert_called_once();self.assertTrue(h.prepared);self.assertFalse(h.suspended)
 def test_already_running_server_is_used_without_spawning_another(self):
  h,c=self.run_host([None]);self.prepare(h)
  h.service.ensure.assert_not_called();self.assertTrue(h.prepared)
 def test_disabled_autostart_does_not_launch_server(self):
  h,c=self.run_host([ConnectionRefusedError()],False);self.prepare(h)
  h.service.ensure.assert_not_called();c.warmup.assert_not_called();self.assertTrue(h.suspended)
 def test_failed_launch_does_not_repeat_loads_or_publish_ready(self):
  h,c=self.run_host([ConnectionRefusedError()],ensure=False);self.prepare(h)
  c.warmup.assert_not_called();self.assertFalse(h.prepared);self.assertTrue(h.suspended)
 def test_cancel_after_server_spawn_does_not_load_weights_or_analyze(self):
  h,c=self.run_host([ConnectionRefusedError()])
  def launch(exc):h.stop.set();return True
  h.service.ensure.side_effect=launch;self.prepare(h)
  c.warmup.assert_not_called();c.analyze_views.assert_not_called();self.assertFalse(h.prepared)
 def test_model_error_after_server_start_is_not_retried_as_connection_failure(self):
  h,c=self.run_host([ConnectionRefusedError(),ValueError('model not found')]);self.prepare(h)
  self.assertEqual(c.probe.call_count,2);c.warmup.assert_not_called();self.assertIn('model not found',h.error)

if __name__=='__main__':unittest.main()
