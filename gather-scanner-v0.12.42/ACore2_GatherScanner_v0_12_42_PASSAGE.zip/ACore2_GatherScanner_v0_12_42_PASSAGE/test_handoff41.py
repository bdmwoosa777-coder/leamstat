"""Delayed network ownership, moving badges, fast neighbour selection and return."""
from dataclasses import replace
from pathlib import Path
import unittest,struct
from unittest.mock import patch
import cv2,numpy as np
import test_combat39 as fx
import gather_engine as ge
import hybrid_engine as he
from acquisition_track import AcquisitionTrack
from resource_return import ResourceReturn
from network_state import Node
from spatial import resource_names
from flight import FlightReading
from minimap import Marker
from navigation import Drive
from test_navigation import radar
from test_ether_emblem import scene,ether

class HandoffLifecycle(unittest.TestCase):
 def setUp(self):
  self.f=fx.AirCollectionResume('test_kill_defers_homing_until_resource_finishes');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
  self.e=self.f.e;self.s=self.f.s;self.s.attacks.clear();self.s.npcs.clear();self.s.deaths.clear()
  self.base=scene();self.f.f.frame=self.base.copy();self.e.current_size=(2480,1395)
  self.s.nodes[99].xyz=(-10000.,0.,2000.);self.c=ether(self.base)
 def arm(self,owner=7):
  self.s.own=owner;self.s.collecting=None;self.s.started=None;self.s.attempt_active=False;self.s.selected=0
  self.s.nodes[99].gather_time=None;self.s.nodes[99].used=0;self.s.last_own_result=None
  self.e.target='Эфир';self.e.target_confirmed=False;self.e.resource_hold=False;self.e.network_target=None;self.e.mode='VERIFY_EMBLEM';self.e.candidate=None
  self.e.acquisition_track=AcquisitionTrack(self.e._net_view(),self.c,self.base,self.f.clock,self.f.wall)
  self.e.emblem_acquisition={'candidate':self.c,'flow':1,'owner':owner,'after':self.f.wall,'clicked':self.f.clock,'until':self.f.clock+12}
 def fly(self,count=1):
  for _ in range(count):
   self.f.clock+=.12;self.f.wall+=120
   self.fly_steps=getattr(self,'fly_steps',0)+1;dx=self.fly_steps*9;dy=self.fly_steps*5
   image=self.base.copy();x,y,w,h=self.c.box;image[y:y+h,x:x+w]=(230,220,30)
   self.f.f.frame=cv2.warpAffine(image,np.float32([[1,0,dx],[0,1,dy]]),(2480,1395),borderValue=(35,35,35))
   self.e._acquisition_marker_tick(self.f.f.frame,self.f.clock)
 def start(self,actor=99):
  self.f.wall+=20;self.s.own=7;self.s.collecting=actor;self.s.started=self.f.wall;self.s.attempt_active=True
  self.s.attempt_ordinal=1;self.s.nodes[actor].gather_time=self.f.wall
  self.e._adopt_network_collection();self.e._net_resource(self.f.f.frame,FlightReading(70,True),self.f.clock)
  self.f.clock+=.12;self.e._acquisition_marker_tick(self.f.f.frame,self.f.clock)
 def partial(self):
  self.clean=self.f.f.frame.copy();p=cv2.imread(str(Path(ge.ROOT)/'testdata/current_gather_panel.png'))
  p=cv2.resize(p,None,fx=2480/2560,fy=1395/1440);h,w=p.shape[:2]
  self.f.f.frame[round(1014*1395/1440):round(1014*1395/1440)+h,round(930*2480/2560):round(930*2480/2560)+w]=p
  self.assertTrue(ge.gathering_panel_pair(self.f.f.frame));self.e.f_enable()
 def end(self,used=1):
  self.f.wall+=200;self.f.clock+=.3;self.s.attempt_active=False;self.s.selected=0;self.s.nodes[99].used=used
  self.s.last_own_result=(99,self.f.wall);self.s.last_own_result_used=used
  if hasattr(self,'clean'):self.f.f.frame=self.clean.copy()
 def test_late_private_start_gets_the_badge_tracked_during_flight(self):
  self.arm();self.fly(20);self.s.selected=99;self.s.selection_time=self.f.wall;self.start()
  self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.e.owned_emblem.key,self.e._owned_emblem_key())
  self.assertGreater(self.e.candidate.click_x,self.c.click_x+150);self.assertIsNone(self.e.acquisition_track)
  self.assertEqual(self.f.f.pad.presses,0)
 def test_private_start_before_selection_echo_is_promoted_in_gather_mode(self):
  self.arm();self.fly(8);self.start()
  self.assertEqual(self.e.owned_emblem.key,self.e._owned_emblem_key());self.assertIsNotNone(self.e.candidate)
 def test_first_own_end_with_hidden_word_gets_one_a_without_camera_recovery(self):
  self.arm();self.fly(12);self.s.selected=99;self.s.selection_time=self.f.wall;self.start();self.partial();self.end()
  with patch.object(self.e,'_arm_view_recovery',side_effect=AssertionError('no camera search')):
   self.e.f_enable();self.e.f_enable()
  self.assertEqual(self.f.f.pad.presses,1);self.assertEqual(self.f.f.pad.axes,(0,0,0,0))
  self.assertFalse({'TAP_F','END_AIR','V','TAB'}&set(self.f.f.commands))
 def test_unknown_owner_at_click_is_filled_by_later_private_start(self):
  self.arm(owner=None);self.fly(8);self.s.selected=99;self.s.selection_time=self.f.wall;self.start()
  self.assertEqual(self.e.owned_emblem.key[1],7);self.assertIsNone(self.e.acquisition_track)
 def test_selected_ack_can_handoff_before_the_attempt_starts(self):
  self.arm();self.fly(5);self.s.selected=99;self.s.selection_time=self.f.wall
  self.e._service_emblem_acquisition(self.f.clock)
  self.assertEqual(self.e.mode,'APPROACH');self.assertEqual(self.e.owned_emblem.key,self.e._owned_emblem_key())
  self.assertEqual(self.f.f.pad.presses,0)
 def test_missing_badge_is_not_promoted_from_an_old_picture(self):
  self.arm();self.f.f.frame[:]=35;self.s.selected=99;self.s.selection_time=self.f.wall;self.start()
  self.assertIsNone(self.e.owned_emblem.key)
 def test_changed_owner_revokes_the_provisional_track(self):
  self.arm();self.s.own=8;self.fly()
  self.assertIsNone(self.e.acquisition_track)
 def test_new_flow_revokes_the_provisional_track(self):
  self.arm();v=self.e._net_view()
  with patch.object(self.e,'_net_view',return_value={**v,'flow':2}):self.e._acquisition_marker_tick(self.base,self.f.clock)
  self.assertIsNone(self.e.acquisition_track)
 def test_expired_track_is_not_renamed_to_a_new_binding(self):
  self.arm();self.f.clock+=13;self.e._acquisition_marker_tick(self.base,self.f.clock)
  self.assertIsNone(self.e.acquisition_track)
 def test_current_npc_selection_cannot_become_a_resource(self):
  self.arm();self.s.selected=55;self.s.selection_time=self.f.wall;self.s.npcs[55]={'time':1000}
  self.e._acquisition_marker_tick(self.base,self.f.clock);self.assertIsNone(self.e.acquisition_track)
 def test_source_generation_change_revokes_an_observed_selection(self):
  self.arm();self.s.selected=99;self.s.selection_time=self.f.wall;self.fly()
  self.s.nodes[99].generation+=1;self.fly();self.assertIsNone(self.e.acquisition_track)
 def test_track_never_sends_input_while_a_partial_attempt_is_active(self):
  self.arm();self.fly(5);self.s.selected=99;self.s.selection_time=self.f.wall;self.start();self.partial()
  for _ in range(5):self.f.clock+=.2;self.e.f_enable()
  self.assertEqual(self.f.f.pad.presses,0)
 def test_actual_initial_badge_click_arms_a_track_without_a_second_press(self):
  self.arm();self.e.emblem_acquisition=None;self.e.acquisition_track=None;self.e.mode='SEARCH'
  with patch.object(self.e,'_acquire_caption_matches',return_value=True):
   self.assertTrue(self.e.click_candidate(self.c,(0,0)))
  self.assertEqual(self.f.f.pad.presses,1);self.assertIsNotNone(self.e.acquisition_track)
  self.assertEqual(self.e.mode,'VERIFY_EMBLEM')
  self.fly(8);self.s.selected=99;self.s.selection_time=self.f.wall;self.start();self.partial();self.end();self.e.f_enable()
  self.assertEqual(self.f.f.pad.presses,2);self.assertEqual(self.e.owned_emblem.key,self.e._owned_emblem_key())

class FastVisibleContinuation(unittest.TestCase):
 def setUp(self):
  self.f=fx.AirCollectionResume('test_kill_defers_homing_until_resource_finishes');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
  self.e=self.f.e;self.s=self.f.s;self.s.attacks.clear();self.s.npcs.clear();self.s.deaths.clear()
  self.e.owned_emblem.clear();self.e.candidate=None;self.e.snapshot=None
  self.s.attempt_active=False;self.s.collecting=99;self.s.selected=0;self.s.last_own_result=(99,self.f.wall)
  self.s.last_own_result_used=1;self.s.nodes[99].used=1;self.s.nodes[99].xyz=(-10000.,0.,2000.)
  self.e.real_gather_panel_seen=True;self.e.fast_gather_seen=True
  self.e.collection_cycle.reset();self.e.view_recovery=None
 def tick(self):return self.e._completed_point_wait_tick(self.f.f.frame,self.f.clock)
 def probe(self):
  self.assertTrue(self.tick());self.assertEqual(self.f.f.pad.presses,1)
 def test_visible_badge_is_clicked_promptly_with_no_camera_or_context_b(self):
  with patch.object(self.e,'_arm_view_recovery',side_effect=AssertionError('no camera')):self.probe()
  self.assertLess(self.f.clock,102);self.assertEqual(self.e.mode,'VERIFY_EMBLEM')
  self.assertFalse({'TAP_F','END_AIR','V','TAB'}&set(self.f.f.commands));self.assertEqual(self.f.f.pad.axes,(0,0,0,0))
 def test_pending_acknowledgement_does_not_press_a_again(self):
  self.probe()
  for _ in range(5):self.f.clock+=.1;self.e._service_emblem_acquisition(self.f.clock)
  self.assertEqual(self.f.f.pad.presses,1)
 def test_old_inactive_collection_is_not_readopted_while_waiting(self):
  self.probe();self.assertFalse(self.e._adopt_network_collection());self.assertEqual(self.e.mode,'VERIFY_EMBLEM')
 def test_neighbour_gem_response_binds_its_actual_name_and_id(self):
  self.probe();template=next(k for k,v in resource_names().items() if v=='Алмаз')
  self.s.nodes[100]=Node(100,template,xyz=(10000.,0.,2000.),used=0,generation=123)
  self.s.selected=100;self.s.selection_time=self.f.wall+1;self.f.clock+=.2
  self.e._service_emblem_acquisition(self.f.clock)
  self.assertEqual((self.e.target,self.e.network_target),('Алмаз',(1,100)))
  self.assertEqual(self.e.owned_emblem.candidate.name,'Алмаз')
  self.assertEqual(self.f.f.pad.presses,1);self.assertEqual(self.e.return_resource.actor,99)
 def test_npc_response_never_becomes_an_activated_resource(self):
  self.probe();self.s.selected=55;self.s.selection_time=self.f.wall+1;self.s.npcs[55]={'time':1100}
  self.f.clock+=.2;self.e._service_emblem_acquisition(self.f.clock)
  self.assertFalse(self.e.target_confirmed);self.assertEqual(self.f.f.pad.presses,1)
 def test_actual_active_attempt_cannot_trigger_a_probe(self):
  self.s.attempt_active=True;self.assertFalse(self.tick());self.assertEqual(self.f.f.pad.presses,0)
 def test_rendered_partial_blocks_a_probe_even_if_end_packet_arrived(self):
  with patch.object(he,'gathering_panel_pair',return_value=True):self.assertFalse(self.tick())
  self.assertEqual(self.f.f.pad.presses,0)
 def test_missing_badge_exits_in_two_and_a_half_seconds_without_camera_or_blacklist(self):
  self.f.f.frame[:]=35
  with patch.object(self.e,'_arm_view_recovery',side_effect=AssertionError('no camera')):
   self.assertFalse(self.tick());self.f.clock+=2.7;self.assertTrue(self.tick())
  self.assertEqual(self.e.mode,'SEARCH');self.assertEqual(self.f.f.pad.presses,0)
  self.assertEqual(self.e.resource_retry_after.get((1,99),0),0);self.assertEqual(self.e.nav.excluded,[])
  self.assertIsNotNone(self.e.return_resource);self.assertFalse(self.e._adopt_network_collection())
 def test_focus_loss_cannot_click_a_visible_badge(self):
  self.e.screen.focused=lambda:False;self.assertFalse(self.tick());self.assertEqual(self.f.f.pad.presses,0)
 def test_marker_disappearing_after_cursor_move_cannot_get_a_stale_click(self):
  cursor=self.e.bridge.cursor
  def move(*args):cursor(*args);self.f.f.frame[:]=35
  self.e.bridge.cursor=move;self.tick();self.assertEqual(self.f.f.pad.presses,0)
 def test_restarted_original_attempt_drops_the_return_ticket(self):
  self.probe();self.f.wall+=100;self.s.selected=99;self.s.selection_time=self.f.wall
  self.s.collecting=99;self.s.started=self.f.wall;self.s.nodes[99].gather_time=self.f.wall;self.s.attempt_active=True
  self.e.return_resource.observe(self.e._net_view(),self.f.clock);self.assertTrue(self.e.return_resource.done)
 def test_new_attempt_at_final_a_guard_cancels_the_fallback_press(self):
  proof=self.e._completed_wait_proof(self.e._net_view());self.e.quick_input_proof=proof
  self.e.bridge_cmd('ALT_DOWN');self.s.attempt_active=True
  self.assertFalse(self.e._a_input_ready());self.assertEqual(self.f.f.pad.presses,0)
 def test_multiple_visible_badges_are_allowed_for_the_explicit_fallback(self):
  image=self.f.f.frame.copy();other=cv2.warpAffine(image,np.float32([[1,0,220],[0,1,0]]),(image.shape[1],image.shape[0]),borderValue=(35,35,35))
  self.f.f.frame=np.maximum(image,other);self.probe();self.assertEqual(self.f.f.pad.presses,1)
 def test_quick_a_guard_preserves_post_teleport_exit_ownership(self):
  self.e.quick_input_proof=self.e._completed_wait_proof(self.e._net_view())
  with patch.object(ge.GatherEngine,'_a_input_ready',return_value=True):
   self.assertTrue(self.e._a_input_ready())
   self.e.post_tp_exit=object();self.assertFalse(self.e._a_input_ready())
  self.assertEqual(self.f.f.pad.presses,0)

class ReturnPreference(unittest.TestCase):
 def setUp(self):
  self.f=fx.AirCollectionResume('test_kill_defers_homing_until_resource_finishes');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
  self.e=self.f.e;self.s=self.f.s;self.s.attacks.clear();self.s.npcs.clear();self.s.deaths.clear()
  self.s.nodes[99].xyz=(-10000.,0.,1000.);self.s.nodes[100]=Node(100,1500000,xyz=(10000.,0.,1000.),used=0,gather_time=1100)
  self.s.collecting=100;self.s.attempt_active=True
  self.t=ResourceReturn(1,7,99,self.s.nodes[99].generation,'Эфир',self.s.nodes[99].xyz,100)
  self.t.observe(self.e._net_view(),100)
  self.west=Marker('Эфир',70,100,.99,30,'aether');self.east=Marker('Эфир',130,100,.99,30,'aether')
  self.r=radar([self.east,self.west],90)
 def finish(self):
  self.s.nodes[100].used=3;self.s.collecting=None;self.s.attempt_active=False
  self.s.last_own_result=(100,1200);self.s.last_own_result_used=3;self.t.observe(self.e._net_view(),101)
 def test_incomplete_neighbour_is_finished_before_return(self):self.assertIsNone(self.t.choose(self.r,100))
 def test_first_and_second_neighbour_results_do_not_return_even_between_attempts(self):
  for used in (1,2):
   with self.subTest(used=used):
    self.s.nodes[100].used=used;self.s.attempt_active=False
    self.s.last_own_result=(100,1100+used);self.s.last_own_result_used=used
    self.t.observe(self.e._net_view(),100+used)
    self.assertIsNone(self.t.ready_at);self.assertIsNone(self.t.choose(self.r,100+used))
  self.finish();self.assertEqual(self.t.choose(self.r,103),self.west)
 def test_another_accidental_resource_is_finished_before_return(self):
  self.s.nodes[101]=Node(101,1500000,xyz=(12000.,0.,1000.),used=0,gather_time=1200)
  self.s.collecting=101;self.s.attempt_active=True;self.t.observe(self.e._net_view(),101)
  self.s.nodes[100].used=3;self.s.last_own_result=(100,1250);self.s.last_own_result_used=3
  self.t.observe(self.e._net_view(),102);self.assertIsNone(self.t.choose(self.r,102))
  for used in (1,2,3):
   self.s.nodes[101].used=used;self.s.attempt_active=False
   self.s.last_own_result=(101,1300+used);self.s.last_own_result_used=used
   self.t.observe(self.e._net_view(),102+used)
   if used<3:self.assertIsNone(self.t.choose(self.r,102+used))
  self.assertEqual(self.t.choose(self.r,105),self.west)
 def test_gem_with_attempts_remaining_cannot_be_abandoned_for_ether(self):
  self.s.nodes[100].template=next(k for k,v in resource_names().items() if v=='Алмаз')
  self.e.target='Алмаз';self.e.network_target=(1,100);self.e.network_claimed_at=900
  self.e.return_resource=self.t;self.e.mode='GATHER';self.e.policy.priority=True
  for used in (1,2):
   self.s.nodes[100].used=used;self.s.attempt_active=False
   self.s.last_own_result=(100,1200+used);self.s.last_own_result_used=used
   self.e.return_to_search('new Ether must wait',self.f.f.frame,reading=FlightReading(None,False),abandon=True)
   self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.e.network_target,(1,100))
   self.assertTrue(self.e.resource_hold);self.assertFalse(self.t.returning)
 def test_completed_neighbour_prefers_the_original_resource_direction(self):
  self.finish();self.assertEqual(self.t.choose(self.r,101),self.west)
 def test_foreign_or_other_result_cannot_mark_neighbour_finished(self):
  self.s.nodes[100].used=3;self.s.last_own_result=(101,1200);self.s.last_own_result_used=3
  self.t.observe(self.e._net_view(),101);self.assertIsNone(self.t.choose(self.r,101))
 def test_exhausted_original_cancels_return(self):
  self.s.nodes[99].used=3;self.finish();self.assertTrue(self.t.done);self.assertIsNone(self.t.choose(self.r,101))
 def test_changed_original_generation_cancels_return(self):
  self.s.nodes[99].generation+=1;self.finish();self.assertTrue(self.t.done)
 def test_missing_coordinates_never_invent_a_position(self):
  self.t.xyz=None;self.finish();self.assertIsNone(self.t.choose(self.r,101))
 def test_return_window_is_finite(self):
  self.finish();self.t.observe(self.e._net_view(),122);self.assertTrue(self.t.done)
 def test_other_flow_cancels_the_ticket(self):
  v=self.e._net_view();self.t.observe({**v,'flow':2},101);self.assertTrue(self.t.done)
 def test_original_actor_reused_as_an_npc_cancels_return(self):
  self.s.npcs[99]={'time':1200};self.finish();self.assertTrue(self.t.done)
 def test_real_scene_planner_receives_the_return_goal(self):
  self.finish();self.e.return_resource=self.t;self.e.mode='SEARCH';self.e.network_target=None
  self.e.target=None;self.e.target_confirmed=False;self.e.resource_hold=False;self.e.budget.energy=80;self.e.budget.airborne=False
  self.e._scene_plan(self.f.f.frame,self.r,FlightReading(None,False),Drive(.8),101)
  self.assertEqual(self.e.nav.goal,self.west)
 def test_scene_planner_does_not_return_mid_collection(self):
  self.finish();self.e.return_resource=self.t;self.e.mode='GATHER'
  self.e._scene_plan(self.f.f.frame,self.r,FlightReading(70,True),Drive(.8),101)
  self.assertFalse(self.t.returning)
