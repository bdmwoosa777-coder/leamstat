"""Regression: a blocked Ollama must not prevent normal controller startup."""
import json,subprocess,tempfile,threading,time,unittest
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
import test_ready_experiment as ready_fixture
from app import DEFAULT,UI
from qwen_experiment import TemporalAdvisor,TemporalClient,MODEL,CONTEXT_LENGTH,COLD_LOAD_TIMEOUT
from qwen_diagnostics import gpu_snapshot,snapshot,storage_snapshot
from check_qwen_experiment import synthetic_views
from test_qwen_experiment import ANSWER,CTX
from test_hybrid import FRAME

def host():return TemporalAdvisor({'ollama_autostart':False},lambda _:None)

def ui(adviser=None):
 u=ready_fixture.StartGate().ui(adviser);u.cfg['qwen_wait_before_start']=False
 return u

def engine(adviser):
 return SimpleNamespace(analyzer=adviser,bridge=SimpleNamespace(controller_native=True),
  stop_event=threading.Event(),run=Mock(),stop=Mock(),silence=Mock())

class BackgroundControl(unittest.TestCase):
 def test_real_start_callback_runs_controller_while_load_is_blocked_then_survives_load_timeout(self):
  h=host();entered=threading.Event();release=threading.Event();running=threading.Event()
  class Client:
   model=MODEL
   def probe(self):pass
   def warmup(self,timeout):entered.set();release.wait(2);raise TimeoutError('timed out')
   def unload(self):pass
  h.client_factory=lambda *a:Client();u=ui();e=engine(h);e.run=running.set
  with patch('app.GatherEngine',return_value=e),patch('qwen_diagnostics.snapshot',return_value={'test':True}),patch.object(Path,'write_text'):
   try:
    u._launch_if_ready(5);self.assertTrue(entered.wait(1));self.assertTrue(h.busy)
    starts=[cb for delay,cb in u.root.calls if delay==3000];self.assertEqual(len(starts),1)
    starts[0]();self.assertTrue(running.wait(1));self.assertTrue(h.busy)
    release.set();h.worker.join(2)
    self.assertFalse(h.worker.is_alive());self.assertTrue(h.suspended);self.assertFalse(e.stop_event.is_set())
    e.stop.assert_not_called();self.assertFalse(u._start_pending);self.assertIs(u.engine,e)
    u._watch_qwen_background(5,h);self.assertIn('продолжает без Qwen',u.log.call_args.args[0])
   finally:release.set();h.worker.join(2)
 def test_default_and_shipped_config_both_use_background_mode(self):
  self.assertFalse(DEFAULT['qwen_wait_before_start'])
  self.assertFalse(json.loads((Path(__file__).parent/'settings_gather.json').read_text())['qwen_wait_before_start'])
 def test_old_model_cleanup_defers_only_new_helper_not_game_start(self):
  old=ready_fixture.StartGate().host();u=ui(old);h=host();e=engine(h)
  with patch('app.GatherEngine',return_value=e):u._launch_if_ready(5)
  self.assertTrue(any(delay==3000 for delay,_ in u.root.calls))
  self.assertTrue(h.preparation_pending);self.assertFalse(h.busy)
  h.observe(FRAME,time.monotonic(),90,0,CTX,(500,0,640,140))
  self.assertFalse(h.offer(FRAME,None,time.monotonic(),90,0,CTX))
  with patch.object(h,'prepare') as prepare:
   old.busy=False;u._start_pending=False;u._prepare_qwen_background(5,h)
  prepare.assert_called_once();self.assertEqual(u._retired_qwen,[])
 def test_rapid_restarts_retain_first_slow_host_even_after_an_intermediate_unused_host(self):
  old=ready_fixture.StartGate().host();u=ui(old);middle=host();latest=host()
  with patch('app.GatherEngine',return_value=engine(middle)):u._launch_if_ready(5)
  u._start_token=6;u._start_pending=True
  with patch('app.GatherEngine',return_value=engine(latest)):u._launch_if_ready(6)
  self.assertTrue(any(h is old for h in u._retired_qwen));self.assertTrue(latest.preparation_pending)
  with patch.object(latest,'prepare') as prepare:u._prepare_qwen_background(6,latest)
  prepare.assert_not_called();self.assertTrue(any(delay==3000 for delay,_ in u.root.calls))
 def test_stale_stop_or_closed_callbacks_cannot_start_loading_a_model(self):
  for changed in ('token','closed','stopped','replaced'):
   h=host();u=ui();u.engine=engine(h)
   if changed=='token':u._start_token+=1
   if changed=='closed':u._closing=True
   if changed=='stopped':h.stop.set()
   if changed=='replaced':u.engine=engine(host())
   with patch.object(h,'prepare') as prepare:u._prepare_qwen_background(5,h)
   prepare.assert_not_called()
 def test_old_controller_worker_still_must_finish_before_new_engine_is_created(self):
  u=ui();u.worker=SimpleNamespace(is_alive=lambda:True)
  with patch('app.GatherEngine') as constructor:u._launch_if_ready(5)
  constructor.assert_not_called();self.assertEqual(u.root.calls[-1][0],150)
 def test_failure_status_never_claims_qwen_is_ready(self):
  h=host();h.suspended=True;h.error='timed out';u=ui(h)
  u.analyzer_status();message=u.log.call_args.args[0]
  self.assertIn('приостановлен',message);self.assertIn('timed out',message);self.assertIn('без Qwen',message)
 def test_background_watcher_remains_usable_after_controller_start_clears_pending(self):
  h=host();h.busy=True;u=ui(h);u._start_pending=False
  u._watch_qwen_background(5,h)
  self.assertEqual(u.root.calls[-1][0],150)
  h.busy=False;h.prepared=True;u._watch_qwen_background(5,h)
  self.assertIn('QWEN_BACKGROUND_READY',u.log.call_args.args[0])
 def test_failed_preflight_is_suspended_and_cannot_schedule_more_loads(self):
  h=host();count=[]
  class Client:
   model=MODEL
   def probe(self):pass
   def warmup(self,timeout):count.append(timeout);raise TimeoutError('timed out')
   def unload(self):pass
  h.client_factory=lambda *a:Client()
  with patch('qwen_diagnostics.snapshot',return_value={}),patch.object(Path,'write_text'):
   h.prepare();h.worker.join(2)
   self.assertTrue(h.suspended);self.assertFalse(h.preparation_pending);self.assertEqual(count,[COLD_LOAD_TIMEOUT])
   for delta in (1,120,600):
    now=time.monotonic()+delta
    h.observe(FRAME,now,90,0,CTX,(500,0,640,140));self.assertFalse(h.offer(FRAME,None,now,90,0,CTX))
  self.assertEqual(len(count),1)
 def test_stopping_during_background_load_never_publishes_prepared_advice(self):
  h=host();entered=threading.Event();release=threading.Event();unloaded=threading.Event()
  class Client:
   model=MODEL
   def probe(self):pass
   def warmup(self,timeout):entered.set();release.wait(2)
   def analyze_views(self,*args,**kw):raise AssertionError('cancelled load must not infer')
   def unload(self):unloaded.set()
  h.client_factory=lambda *a:Client()
  with patch('qwen_diagnostics.snapshot',return_value={}),patch.object(Path,'write_text'):
   try:
    h.prepare();self.assertTrue(entered.wait(1));h.close();release.set();h.worker.join(2)
    self.assertTrue(unloaded.is_set());self.assertFalse(h.prepared);self.assertIsNone(h.latest)
   finally:release.set();h.worker.join(2)

class LoadProtocol(unittest.TestCase):
 def test_actual_http_load_and_visual_request_share_model_context_and_ttl(self):
  seen=[]
  class Handler(BaseHTTPRequestHandler):
   def log_message(self,*args):pass
   def do_POST(self):
    body=json.loads(self.rfile.read(int(self.headers['Content-Length'])));seen.append((self.path,body))
    answer={'done':True,'message':{'content':json.dumps(ANSWER)}}
    raw=json.dumps(answer).encode()+b'\n';self.send_response(200);self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
  server=HTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
  try:
   client=TemporalClient('http://127.0.0.1:'+str(server.server_port),MODEL);client.single_frame=True;client.keep_alive='10m'
   client.warmup();client.analyze_views(synthetic_views());client.unload()
   load,visual,unload=[body for _,body in seen]
   self.assertEqual([p for p,_ in seen],['/api/generate','/api/chat','/api/generate'])
   self.assertEqual(load['options']['num_ctx'],visual['options']['num_ctx']);self.assertEqual(load['options']['num_ctx'],CONTEXT_LENGTH)
   self.assertEqual([p['model'] for _,p in seen],[MODEL]*3)
   self.assertEqual([p['keep_alive'] for _,p in seen],['10m','10m',0]);self.assertNotIn('prompt',load);self.assertNotIn('messages',load)
  finally:server.shutdown();server.server_close();thread.join()
 def test_unload_requires_server_completion_instead_of_reporting_false_success(self):
  for reply in ({'error':'busy'},{'done':False},{},None):
   c=TemporalClient(model=MODEL);c.call=lambda *args,**kw:reply
   with self.assertRaises(RuntimeError):c.unload()

class Diagnostics(unittest.TestCase):
 def test_gpu_query_reads_memory_in_mib_without_any_process_or_write_commands(self):
  reply=SimpleNamespace(returncode=0,stdout='NVIDIA GeForce RTX 4080 SUPER, 565.90, 16376, 12000, 4376, 75\n')
  with patch('qwen_diagnostics.shutil.which',return_value='nvidia-smi'),patch('qwen_diagnostics.subprocess.run',return_value=reply) as run:
   data=gpu_snapshot()
  self.assertTrue(data['available']);self.assertEqual(data['gpus'][0]['free_mib'],'4376')
  argv=run.call_args.args[0];self.assertTrue(any(x.startswith('--query-gpu=') for x in argv));self.assertEqual(len(argv),3)
  self.assertEqual(run.call_args.kwargs['timeout'],3);self.assertNotIn('shell',run.call_args.kwargs)
 def test_missing_or_stuck_gpu_tool_does_not_break_loading_or_require_installation(self):
  with patch('qwen_diagnostics.shutil.which',return_value=None):self.assertFalse(gpu_snapshot()['available'])
  with patch('qwen_diagnostics.shutil.which',return_value='nvidia-smi'),patch('qwen_diagnostics.subprocess.run',side_effect=subprocess.TimeoutExpired('nvidia-smi',3)):
   self.assertFalse(gpu_snapshot()['available'])
 def test_model_location_reports_bot_environment_without_claiming_server_uses_it(self):
  with tempfile.TemporaryDirectory() as folder,patch.dict('qwen_diagnostics.os.environ',{'OLLAMA_MODELS':folder}):
   report=storage_snapshot()
  self.assertEqual(report['models_path_in_bot_environment'],folder);self.assertTrue(report['exists'])
  self.assertFalse(report['server_models_path_confirmed']);self.assertGreaterEqual(report['disk_free_bytes'],0)
 def test_ollama_diagnostics_use_read_only_version_endpoint_only(self):
  client=SimpleNamespace(call=Mock(return_value={'version':'0.40.16','secret':'do not copy'}))
  with patch('qwen_diagnostics.gpu_snapshot',return_value={}),patch('qwen_diagnostics.memory_snapshot',return_value={}),patch('qwen_diagnostics.storage_snapshot',return_value={}):
   report=snapshot(client)
  client.call.assert_called_once_with('/api/version',timeout=2);self.assertEqual(report['ollama_version'],'0.40.16');self.assertNotIn('secret',json.dumps(report))
 def test_failure_report_keeps_phase_context_gpu_and_does_not_serialize_prompts(self):
  h=host();h.load_diagnostics={'gpu':{'free_mib':9000}};h.phase='загрузка модели';h.suspended=True
  with patch('qwen_diagnostics.snapshot',return_value={'gpu':{'free_mib':3000}}),patch.object(Path,'write_text') as write:
   h._runtime_report(None,'preflight','timed out',time.monotonic())
  report=json.loads(write.call_args.args[0]);self.assertEqual(report['context_length'],4096)
  self.assertEqual(report['phase'],'загрузка модели');self.assertEqual(report['error_diagnostics']['gpu']['free_mib'],3000)
  self.assertTrue(report['suspended']);self.assertNotIn('images',report);self.assertNotIn('messages',report)

if __name__=='__main__':unittest.main()
