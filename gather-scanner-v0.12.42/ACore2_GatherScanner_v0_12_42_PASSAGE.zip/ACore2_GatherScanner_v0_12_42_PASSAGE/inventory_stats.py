"""Passive inventory stack deltas; listings are baselines, never loot.

Layout source: assets/gather_item_ids_SOURCE.md. Body input excludes the opcode.
"""
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
import json,struct

@lru_cache(maxsize=1)
def catalogue():
 data=json.loads((Path(__file__).resolve().parent/'assets/gather_item_ids.json').read_text(encoding='utf-8'))
 return set(data['known_ids']),{int(k):v for k,v in data['resources'].items()},{int(k):v for k,v in data['templates'].items()}

@dataclass(frozen=True)
class InventoryRecord:
 kind:int
 container:int
 slot:int
 item:int
 quantity:int

def records(body):
 known,_,_=catalogue();seen=set();result=[];i=10
 while i+14<=len(body):
  item=struct.unpack_from('<I',body,i)[0];container=body[i+12]
  if (item not in known or item<100000000 or body[i-10]>2
      or container not in (1,2,4,11,15,17) or body[i+9:i+12]!=b'\x00\x00\x00'):
   i+=1;continue
  key=(container,body[i+13])
  if key not in seen:
   seen.add(key);result.append(InventoryRecord(body[i-10],container,body[i+13],item,struct.unpack_from('<Q',body,i+4)[0]))
  i+=14
 return result

class InventoryTracker:
 def __init__(self):
  self.slots={};self.listed=False;self.last=None;self.state=None;self.owner=None
 def feed(self,op,body,stamp,state):
  """Return positive known deltas, unknown raw-material update, new baseline."""
  if self.last is not None and stamp<self.last:return [],False,False
  owner=getattr(state,'own',None)
  if ((self.state is not None and state is not self.state)
      or self.owner is not None and owner is not None and owner!=self.owner):
   self.slots.clear();self.listed=False
  self.state=state
  if owner is not None:self.owner=owner
  self.last=stamp
  if op not in ('1156','1b56'):return [],False,False
  if op=='1156' and len(body)<4998:return [],False,False
  rows=[r for r in records(body) if r.container==1]
  if not rows:return [],False,False
  listing=(op=='1156' or len(rows)>=8 and all(r.kind==1 for r in rows)
           and max(r.slot for r in rows)-min(r.slot for r in rows)+1==len(rows))
  if listing:
   self.slots={r.slot:(r.item,r.quantity) for r in rows if r.kind!=2 and r.quantity>0}
   self.listed=True
   return [],False,True
  _,materials,_=catalogue();gains=[];unknown=False
  for r in rows:
   before=self.slots.get(r.slot)
   if r.kind==2 or r.quantity==0:
    self.slots[r.slot]=None;continue
   # Unknown changed stacks establish a baseline. A new slot starts at zero.
   previous=(before[1] if before and before[0]==r.item else 0
             if r.kind==0 and (before is None or self.listed) else None)
   self.slots[r.slot]=(r.item,r.quantity)
   if r.item not in materials:continue
   if previous is None:unknown=True;continue
   delta=r.quantity-previous
   if delta>0:gains.append((r.item,delta,stamp))
  return gains,unknown,False
