"""Small local terrain descriptors and successful approach-side preferences.

A preference is not a route or input authority. It is always checked against
current ground. Actor IDs are session data; a minimap terrain ring identifies
repeat spawns even when the actor changes. No screenshots are stored.
"""
from pathlib import Path
import json,math,threading
import cv2,numpy as np
from minimap import angle_delta


def terrain_signature(frame,radar,goal):
 scale=(radar.bounds[2]-radar.bounds[0])/313
 if scale<.3:return None
 radius=round(28*scale);x,y=round(goal.x),round(goal.y);x0,y0,x1,y1=radar.bounds
 if x-radius<x0+3 or y-radius<y0+3 or x+radius>x1-3 or y+radius>y1-3:return None
 patch=frame[y-radius:y+radius,x-radius:x+radius]
 small=cv2.resize(patch,(16,16),interpolation=cv2.INTER_AREA)
 hsv=cv2.cvtColor(small,cv2.COLOR_BGR2HSV);gray=cv2.cvtColor(small,cv2.COLOR_BGR2GRAY).astype(float)
 yy,xx=np.indices((16,16));mask=((xx-7.5)**2+(yy-7.5)**2>=4.5**2)&(hsv[:,:,1]<160)&(hsv[:,:,2]<225)
 if mask.sum()<110 or gray[mask].std()<6:return None
 mean=gray[mask].mean();std=gray[mask].std();v=np.clip((gray-mean)/std,-3,3);v[~mask]=0
 return {'values':np.round(v,2).ravel().tolist(),'mask':mask.astype(int).ravel().tolist()}


def similarity(a,b):
 try:
  av,bv=np.array(a['values']),np.array(b['values']);mask=np.array(a['mask'],bool)&np.array(b['mask'],bool)
  if av.shape!=(256,) or bv.shape!=(256,) or mask.shape!=(256,) or mask.sum()<100:return -1
  if not np.isfinite(av).all() or not np.isfinite(bv).all():return -1
  av=av[mask];bv=bv[mask];return float(np.dot(av,bv)/max(1e-6,np.linalg.norm(av)*np.linalg.norm(bv)))
 except (ValueError,KeyError,TypeError):return -1


def valid_points(points):
 if not isinstance(points,(tuple,list)) or not 2<=len(points)<=64:return None
 clean=[]
 for p in points:
  if not isinstance(p,(tuple,list)) or len(p)!=2:return None
  if any(type(v) not in (float,int) or not math.isfinite(v) or abs(v)>200 for v in p):return None
  clean.append(tuple(float(v) for v in p))
 if any(math.dist(a,b)>16 for a,b in zip(clean,clean[1:])):return None
 return clean


class ExperienceGuide:
 """Measured resource-relative waypoints. They only suggest a fresh route."""
 def __init__(self,points):self.points=valid_points(points);self.index=None;self.lost=False
 def bearing(self,position):
  if self.points is None or self.lost:return None
  if self.index is None:
   nearest=min(range(len(self.points)),key=lambda i:math.dist(position,self.points[i]))
   if math.dist(position,self.points[nearest])>4:self.lost=True;return None
   self.index=nearest
  while self.index<len(self.points) and math.dist(position,self.points[self.index])<2.5:self.index+=1
  if self.index>=len(self.points):return None
  start=self.points[max(0,self.index-1)];end=self.points[self.index]
  dx,dy=end[0]-start[0],end[1]-start[1];length=dx*dx+dy*dy
  t=max(0,min(1,((position[0]-start[0])*dx+(position[1]-start[1])*dy)/max(1e-6,length)))
  cross=math.dist(position,(start[0]+t*dx,start[1]+t*dy))
  if cross>6:self.lost=True;return None
  return math.degrees(math.atan2(end[0]-position[0],position[1]-end[1]))%360


class TerrainExperience:
 def __init__(self,path=None,emit=lambda _:None):
  self.path=Path(path) if path else None;self.emit=emit;self.lock=threading.RLock();self.records=[];self.dirty=False;self.worker=None
  if self.path and self.path.is_file():
   try:
    if self.path.stat().st_size>2*1024*1024:raise ValueError('memory size')
    obj=json.loads(self.path.read_text(encoding='utf-8'))
    if obj.get('version')!=1:raise ValueError('memory version')
    for r in obj['records'][-128:]:
     if (r['side'] not in (-1,1) or r['kind'] not in ('aether','gem') or type(r['sector']) is not int
         or not 0<=r['sector']<12 or not 1<=r['wins']<=100 or not 0<=r['losses']<=100
         or not isinstance(r['zone'],str) or len(r['zone'])>150 or similarity(r['signature'],r['signature'])<.99):continue
     if 'path' in r and valid_points(r['path']) is None:r.pop('path')
     self.records.append(r)
   except (OSError,ValueError,TypeError,KeyError,AttributeError) as exc:self.records=[];self.emit('PATH_MEMORY: не удалось прочесть память: '+str(exc))
 def _matches(self,zone,kind,sector,signature):
  if signature is None:return []
  return sorted([(similarity(signature,r['signature']),i,r) for i,r in enumerate(self.records)
                 if r['zone']==zone and r['kind']==kind and min((r['sector']-sector)%12,(sector-r['sector'])%12)<=1],reverse=True,key=lambda v:v[0])
 def recall(self,zone,kind,sector,signature):
  with self.lock:
   matches=self._matches(zone,kind,sector,signature)
   if not matches or matches[0][0]<.965:return None
   score,_,r=matches[0]
   if len(matches)>1 and matches[1][0]>=score-.025 and matches[1][2]['side']!=r['side']:return None
   if r['losses']>=3:return None
   return {'side':r['side'],'path':r.get('path')}
 def preference(self,*args):
  recalled=self.recall(*args);return recalled['side'] if recalled is not None else None
 def learned(self,zone,kind,sector,signature,side,success=True,spawn=None,points=None):
  if signature is None or side not in (-1,1):return False
  with self.lock:
   matches=self._matches(zone,kind,sector,signature)
   if matches and matches[0][0]>=.965:
    r=matches[0][2]
    if success:
     r['side']=side;r['wins']=min(100,r['wins']+1);r['losses']=max(0,r['losses']-1)
    elif r['side']==side:r['losses']=min(100,r['losses']+1)
   elif success:
    r={'zone':zone,'kind':kind,'sector':sector,'signature':signature,'side':side,'wins':1,'losses':0}
    self.records.append(r);self.records=self.records[-128:]
   else:return False
   clean=valid_points(points)
   if success and clean is not None:r['path']=clean
   if spawn is not None:r['spawn']=spawn
   self.dirty=True
   if self.path and (self.worker is None or not self.worker.is_alive()):
    self.worker=threading.Thread(target=self._write,daemon=True,name='terrain-memory');self.worker.start()
  return True
 def _write(self):
  while True:
   with self.lock:
    if not self.dirty:self.worker=None;return
    self.dirty=False;data=json.dumps({'version':1,'records':self.records},ensure_ascii=False)
   try:
    self.path.parent.mkdir(parents=True,exist_ok=True);temp=self.path.with_suffix('.tmp');temp.write_text(data,encoding='utf-8');temp.replace(self.path)
   except OSError as exc:
    self.emit('PATH_MEMORY: запись не удалась: '+str(exc));return
 def close(self):
  with self.lock:worker=self.worker
  if worker:worker.join(.5)
