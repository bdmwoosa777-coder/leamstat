"""Optional explicit gem selection; no contextual B and no chained exceptions."""
import unittest
from dataclasses import replace
from unittest.mock import Mock,patch
import cv2,numpy as np
from pathlib import Path
from vision import PromptDetector
from minimap import Marker
from flight import FlightReading
from test_navigation import radar
import test_hybrid as fx

class ActionPrompt(unittest.TestCase):
 def test_collect_word_is_detected_for_both_f_and_b_button(self):
  ref=cv2.imread(str(Path(__file__).parent/'assets/f_prompt_reference.png'))
  detector=PromptDetector()
  for key in ('F','B'):
   crop=ref.copy();cv2.rectangle(crop,(19,9),(46,43),(25,32,30),-1)
   cv2.putText(crop,key,(23,36),cv2.FONT_HERSHEY_SIMPLEX,.8,(225,230,230),2)
   crop=cv2.resize(crop,None,fx=2048/2558,fy=2048/2558)
   f=np.full((1152,2048,3),65,np.uint8);h,w=crop.shape[:2];f[650:650+h,1000:1000+w]=crop
   self.assertTrue(detector.detect_collect(f)[0],key)
 def test_empty_world_does_not_grant_context_action(self):
  self.assertFalse(PromptDetector().detect_collect(np.full((1152,2048,3),65,np.uint8))[0])

class NearbyGem(unittest.TestCase):
 def setUp(self):
  self.f=fx.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.e.cfg['nearby_ground_exception']=True;self.e.policy.priority=True;self.e.bridge.controller_native=True
  self.e.camera_alignment_due=None;self.e.budget.airborne=False;self.e.budget.swimming=False
  self.e.resource_radar=(radar([Marker('Самоцвет',104,100,.9,4,'gem')]),100)
  self.e.gamepad.motion_worker=object();self.e._urgent_damage_pending=lambda:False
  self.c=replace(self.f.c,glyph=((4,4),bytes(range(16))))
  self.e._world_resource=Mock(return_value=self.c);self.e.vision.prompt.detect_collect=Mock(return_value=(True,.9))
  self.buttons=[];old=self.f.pad.press_button
  self.f.pad.press_button=lambda button:(self.buttons.append(button),old(button))[-1]
  self.clicks=[]
  def click(c,origin):
   self.assertTrue(self.e.rescue_selecting);self.clicks.append((c,origin));return True
  self.e.click_candidate=Mock(side_effect=click)
  self.timer=patch('hybrid_engine.time.monotonic',return_value=100);self.timer.start();self.addCleanup(self.timer.stop)
 def observe(self):self.e._observe_nearby_ground(self.f.frame)
 def act(self):
  with patch('hybrid_engine.find_resource_near',return_value=self.c),patch.object(self.e.gamepad,'wait',return_value=True):
   return self.e._nearby_ground_tick(self.f.frame,FlightReading(None,False),100)
 def test_fresh_prompt_and_near_named_gem_use_normal_explicit_selection_without_b(self):
  self.observe();self.assertTrue(self.act());self.assertEqual(self.buttons,[]);self.assertEqual(len(self.clicks),1)
  self.assertFalse(self.e.target_confirmed);self.assertIsNone(self.e.network_target);self.assertTrue(self.e.nearby_ground_used)
 def test_missing_prompt_does_not_offer_exception(self):
  self.e.vision.prompt.detect_collect.return_value=(False,.1);self.observe();self.assertFalse(self.act());self.assertFalse(self.buttons)
 def test_prompt_disappearing_before_press_cancels_exception(self):
  self.observe();self.e.vision.prompt.detect_collect.return_value=(False,.1);self.assertFalse(self.act());self.assertFalse(self.buttons)
 def test_named_resource_without_near_minimap_gem_is_not_enough(self):
  self.e.resource_radar=(radar(),100);self.observe();self.assertIsNone(self.e.nearby_ground_proof)
 def test_active_ether_approach_is_not_interrupted(self):
  self.e.target_confirmed=True;self.e.mode='APPROACH';self.observe();self.assertFalse(self.act());self.assertFalse(self.buttons)
 def test_swimming_or_open_wings_forbid_exception(self):
  for kind in ('swimming','airborne'):
   setattr(self.e.budget,kind,True);self.observe();self.assertFalse(self.act());setattr(self.e.budget,kind,False)
  self.assertFalse(self.buttons)
 def test_exception_is_off_when_checkbox_is_disabled(self):
  self.e.cfg['nearby_ground_exception']=False;self.observe();self.assertFalse(self.act());self.assertFalse(self.buttons)
 def test_observation_only_or_disabled_actions_never_send_b(self):
  self.e.cfg['dry_run']=True;self.observe();self.assertFalse(self.act());self.assertFalse(self.buttons)
  self.e.cfg['dry_run']=False;self.e.cfg['allow_click']=False
  self.observe();self.assertFalse(self.act());self.assertFalse(self.buttons)
 def test_used_exception_cannot_start_a_second_gem_chain(self):
  self.observe();self.act();self.e.nearby_ground_proof={'candidate':self.c,'at':100,'score':.9}
  self.e.nearby_ground_pending=0;self.assertFalse(self.act());self.assertEqual(self.buttons,[]);self.assertEqual(len(self.clicks),1)

if __name__=='__main__':unittest.main()
