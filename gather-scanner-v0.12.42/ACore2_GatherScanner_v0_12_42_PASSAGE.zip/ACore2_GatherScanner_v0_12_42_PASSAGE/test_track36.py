"""Continuous acquisition tracking and fresh canonical recovery at an own end."""
import unittest,struct
from pathlib import Path
import cv2,numpy as np
from owned_emblem import OwnedEmblem
from test_ether_emblem import scene,ether
from network_state import Telemetry
from test_network_state import profile,gauge,v
import test_owned35 as nativefx

class StableMarker(unittest.TestCase):
 def setUp(self):
  self.frame=scene();self.c=ether(self.frame);self.t=OwnedEmblem();self.key=(1,7,99,0)
  self.assertTrue(self.t.seed(self.key,self.c,self.frame,100))
 def test_first_image_stays_immutable_when_background_changes(self):
  first=self.t.template.copy();rng=np.random.default_rng(8)
  changed=np.clip(self.frame.astype(float)+rng.normal(0,2,self.frame.shape),0,255).astype('uint8')
  self.assertIsNotNone(self.t.refresh(self.key,changed,100.2,reacquire=True))
  np.testing.assert_array_equal(first,self.t.template)
 def test_fresh_canonical_icon_can_recover_after_snapshot_age(self):
  self.assertIsNone(self.t.refresh(self.key,self.frame,103))
  self.assertIsNotNone(self.t.refresh(self.key,self.frame,103,reacquire=True))
 def test_old_anchor_with_no_current_icon_is_not_a_click_point(self):
  self.assertIsNone(self.t.refresh(self.key,np.full_like(self.frame,35),103,reacquire=True))
 def test_canonical_recovery_does_not_need_hidden_word(self):
  x,y,w,h=self.c.box;self.frame[y:y+h,x:x+w]=(230,230,30)
  self.assertIsNotNone(self.t.refresh(self.key,self.frame,104,reacquire=True))
 def test_canonical_recovery_cannot_inherit_different_identity(self):
  self.assertIsNone(self.t.refresh((1,7,100,0),self.frame,104,reacquire=True))
 def test_large_camera_jump_does_not_attach_to_another_icon(self):
  other=cv2.warpAffine(self.frame,np.float32([[1,0,100],[0,1,0]]),(self.frame.shape[1],self.frame.shape[0]),borderValue=(35,35,35))
  self.assertIsNone(self.t.refresh(self.key,other,103,reacquire=True))
 def test_many_noisy_subpixel_frames_do_not_compound_scale_or_crop(self):
  x,y,w,h=self.c.emblem;base=self.frame[y-60:y+h+60,x-60:x+w+60].copy()
  from dataclasses import replace
  bx,by,bw,bh=self.c.box;c=replace(self.c,box=(bx-x+60,by-y+60,bw,bh),emblem=(60,60,w,h),click_x=60+w//2,click_y=60+h//2)
  t=OwnedEmblem();t.seed(self.key,c,base,100);rng=np.random.default_rng(8);widths=[]
  for i in range(1,81):
   f=cv2.warpAffine(base,np.float32([[1,0,np.sin(i*.14)*2.3],[0,1,np.cos(i*.17)*2]]),(base.shape[1],base.shape[0]),borderValue=(35,35,35))
   f=np.clip(f.astype(float)+rng.normal(0,3,f.shape),0,255).astype('uint8')
   found=t.refresh(self.key,f,100+i*.1,reacquire=True);self.assertIsNotNone(found);widths.append(found.emblem[2])
  self.assertLessEqual(max(widths)-min(widths),4)

class ActualTelemetryTimeline(unittest.TestCase):
 def setUp(self):
  wrapper=nativefx.NativeOwnedContinuation('test_hidden_letters_allow_one_emblem_a_after_own_end_without_b');wrapper.setUp()
  self.addCleanup(wrapper.doCleanups);self.addCleanup(wrapper.tearDown);self.e=wrapper.e;self.f=wrapper.f;self.all_buttons=wrapper.all_buttons
  self.e.owned_emblem.clear();self.e.mode='APPROACH';self.e.network_bound_at=90
  self.t=Telemetry({1500000});self.t.feed(1,'008d',gauge(),900)
  self.t.feed(1,'3436',profile(kind=1500000),910);self.t.feed(1,'3438',bytes(3)+v(99),920)
  self.f.f=self.t.flows[1];self.f.source.state=self.f.f
 def feed(self,op,data,at):self.t.feed(1,op,data,at);self.f.f=self.t.flows[1];self.f.source.state=self.f.f
 def start(self,at=1000,ordinal=1):
  self.feed('3836',v(99)+v(7)+b'\1',at);self.feed('318d',bytes(2)+v(99)+struct.pack('<I',ordinal)+bytes(25),at+20)
  self.e.mode='GATHER';self.f.partial();self.e.f_enable()
 def end(self,used=1,at=1100):
  self.feed('3a36',v(99)+v(7)+struct.pack('<II',used,0),at)
  self.feed('3438',bytes(3)+v(0),at+10);self.f.absent()
  x,y,w,h=self.e.candidate.box;self.f.frame[y:y+h,x:x+w]=(230,230,30)
 def seed(self):return self.e._observe_owned_emblem(self.f.frame,self.f.clock)
 def test_tracking_starts_during_confirmed_approach_before_own_attempt(self):
  self.assertIsNone(self.f.f.collecting);self.assertIsNotNone(self.seed());self.assertEqual(self.f.pad.presses,0)
 def test_real_start_timestamp_does_not_discard_prearrival_track(self):
  self.seed();key=self.e._owned_emblem_key();self.start();self.assertEqual(key,self.e._owned_emblem_key())
  self.assertEqual(self.e.owned_emblem.key,key)
 def test_real_own_end_with_hidden_word_and_three_second_worker_gap_sends_one_a(self):
  self.seed();self.start();self.f.clock+=3;self.end();self.e.f_enable()
  self.assertEqual(self.f.pad.presses,1);self.assertNotIn(0x2000,self.all_buttons);self.assertLess(self.f.clock,104)
 def test_second_real_attempt_keeps_same_track_and_gets_its_own_single_a(self):
  self.seed();self.start();self.end();self.e.f_enable();key=self.e._owned_emblem_key()
  self.f.clock+=1;self.start(1200,2);self.assertEqual(key,self.e._owned_emblem_key())
  self.end(2,1300);self.e.f_enable();self.assertEqual(self.f.pad.presses,2);self.assertNotIn(0x2000,self.all_buttons)
 def test_new_acquisition_even_of_same_actor_revokes_old_track(self):
  self.seed();self.start();self.end();self.e.network_bound_at=95
  self.assertIsNone(self.e._tracked_owned_candidate(self.f.frame))
 def test_selected_approach_without_own_end_cannot_authorize_repeat(self):
  self.seed();self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_real_end_without_live_icon_never_sends_stale_click(self):
  self.seed();self.start();self.end();self.f.frame[:]=35;self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_foreign_result_cannot_authorize_native_continuation(self):
  self.seed();self.start();self.feed('3a36',v(99)+v(8)+struct.pack('<II',1,0),1100);self.f.absent()
  self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_new_active_packet_revokes_previous_end_token(self):
  self.seed();self.start();self.end();self.start(1200,2);self.e.f_enable();self.assertEqual(self.f.pad.presses,0)

if __name__=='__main__':unittest.main()
