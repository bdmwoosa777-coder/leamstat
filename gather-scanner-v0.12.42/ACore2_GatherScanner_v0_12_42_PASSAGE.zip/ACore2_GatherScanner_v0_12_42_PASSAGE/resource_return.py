"""A short-lived return preference after a permitted neighbouring-resource click."""
from dataclasses import dataclass
import math
from minimap import angle_delta

@dataclass
class ResourceReturn:
 flow:int
 owner:int
 actor:int
 generation:int
 name:str
 xyz:tuple|None
 created:float
 via:int|None=None
 origin:tuple|None=None
 ready_at:float|None=None
 returning:bool=False
 done:bool=False
 def observe(self,view,now):
  if self.done:return
  if not view or not view['ready']:return
  s=view['state'];n=s.nodes.get(self.actor)
  if (view['flow']!=self.flow or s.own!=self.owner or now-self.created>90
      or self.actor in s.npcs or self.actor in s.players or self.actor in s.deaths
      or n is None or n.used==3 or n.removed_reason==4
      or self.generation and n.generation and n.generation!=self.generation):self.done=True;return
  current=s.nodes.get(s.collecting)
  if current is not None and s.attempt_active and current.gather_time is not None:
   if current.actor==self.actor:self.done=True;return
   self.via=current.actor
   if current.xyz is not None:self.origin=current.xyz
  if self.via is not None:
   other=s.nodes.get(self.via);result=s.last_own_result
   if (other is not None and other.used==3 and result and result[0]==self.via
       and s.last_own_result_used==3 and self.ready_at is None):
    self.ready_at=now
    if other.xyz is not None:self.origin=other.xyz
  if self.ready_at is not None and now-self.ready_at>20:self.done=True
 def choose(self,radar,now):
  if self.done or self.returning or self.ready_at is None or self.xyz is None or self.origin is None:return None
  if len(self.xyz)!=3 or len(self.origin)!=3 or not all(math.isfinite(x) for x in (*self.xyz,*self.origin)):return None
  dx,dy=self.xyz[0]-self.origin[0],self.xyz[1]-self.origin[1]
  if math.hypot(dx,dy)<100:return None
  bearing=math.degrees(math.atan2(dx,-dy))%360
  kind='aether' if 'эфир' in self.name.lower() else 'gem';choices=[]
  for m in radar.markers:
   if m.kind!=kind or m.distance<2:continue
   a=math.degrees(math.atan2(m.x-radar.center[0],radar.center[1]-m.y))%360
   error=abs(angle_delta(a,bearing))
   if error<=60:choices.append((error,m.distance,m))
  if not choices:return None
  self.returning=True
  return min(choices,key=lambda c:(c[0],c[1]))[2]
