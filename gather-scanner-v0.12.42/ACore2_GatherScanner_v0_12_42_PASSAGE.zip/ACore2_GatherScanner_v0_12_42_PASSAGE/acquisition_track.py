"""Passive badge tracking across a delayed selection/own-start acknowledgement.

This object never sends input. Matching pixels do not grant a network identity;
promotion additionally requires the selected or privately collected resource ID.
"""
from owned_emblem import OwnedEmblem
from spatial import resource_names

class AcquisitionTrack:
 def __init__(self,view,candidate,frame,now,after,allow_any=False):
  self.flow=view['flow'];self.owner=view['state'].own;self.name=candidate.name
  self.after=after;self.started=now;self.until=now+12;self.actor=None;self.generation=0;self.revoked=False;self.fallback_tried=False
  self.key=(self.flow,self.owner,after,now);self.marker=OwnedEmblem()
  self.seeded=self.marker.seed(self.key,candidate,frame,now)
  self.allow_any=allow_any
 def valid(self,view,now):
  if self.revoked or not self.seeded or not 0<=now-self.started<=12:return False
  if not view or not view['ready']:return False
  s=view['state']
  if view['flow']!=self.flow or self.owner is not None and s.own!=self.owner:
   self.revoked=True;return False
  if self.owner is None and s.own is not None:self.owner=s.own
  return True
 def _node(self,state,actor):
  if actor in state.players or actor in state.npcs or actor in state.deaths:return None
  n=state.nodes.get(actor)
  if n is None or not n.visible or n.used==3 or n.removed_reason==4:return None
  if n.template is not None and resource_names().get(n.template)!=self.name:return None
  if self.generation and n.generation and n.generation!=self.generation:return None
  return n
 def observe(self,view,frame,now):
  if not self.valid(view,now):return None
  s=view['state']
  if s.selected and s.selection_time>=self.after:
   if self.actor is not None and s.selected!=self.actor:self.revoked=True;return None
   n=s.nodes.get(s.selected)
   label=resource_names().get(n.template) if n is not None else None
   if self.allow_any and label:self.name=label
   if s.selected in s.players or s.selected in s.npcs or (n is not None and self._node(s,s.selected) is None):
    self.revoked=True;return None
   self.actor=s.selected
   if n is not None and n.generation:self.generation=n.generation
  if self.actor is not None:
   n=s.nodes.get(self.actor)
   if n is not None and self._node(s,self.actor) is None:self.revoked=True;return None
  return self.marker.refresh(self.key,frame,now,reacquire=True)
 def matches(self,view,binding,now):
  if not self.valid(view,now) or binding is None or binding[0]!=self.flow:return False
  s=view['state'];actor=binding[1];n=self._node(s,actor)
  raw=s.nodes.get(actor);label=resource_names().get(raw.template) if raw is not None else None
  if self.allow_any and label:
   self.name=label;n=self._node(s,actor)
  if n is None or s.own is None or resource_names().get(n.template)!=self.name:return False
  own=(s.collecting==actor and n.gather_time is not None and n.gather_time>=self.after
       and s.selected in (0,actor))
  selected=s.selected==actor and s.selection_time>=self.after
  if not own and not selected:return False
  if self.actor is not None and self.actor!=actor:return False
  self.actor=actor
  if n.generation:self.generation=n.generation
  return True
