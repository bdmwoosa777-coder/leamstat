"""Delayed planning, delivered camera timing and stateless sampling reuse."""
import math,unittest
from unittest.mock import patch
from types import SimpleNamespace
import cv2,numpy as np
from camera_pitch import PitchLedger
from navigation import Navigator,Drive
from minimap import MinimapVision,cone_sampling,angle_delta
from map_reference import ArrowLocator
from test_navigation import radar
import test_hybrid as fixture
from flight import FlightReading

class DeliveredCamera(unittest.TestCase):
 def test_old_frame_read_cannot_double_count_delivered_pitch(self):
  p=PitchLedger();p.report(.45,100,.1);p.report(0,100.1)
  self.assertAlmostEqual(p.offset(99),.045);self.assertAlmostEqual(p.offset(101),.045)
 def test_old_read_between_watchdog_reports_does_not_move_integration_clock_back(self):
  p=PitchLedger();p.report(.45,100,.1);p.report(.45,100.05,.1);p.offset(99)
  p.report(0,100.1);self.assertAlmostEqual(p.offset(101),.045)
 def test_settle_starts_at_delivered_yaw_not_at_old_planning_time(self):
  n=Navigator({});n._yaw(90,100);n.camera_delivered(102,.12)
  self.assertEqual(n._yaw(90,102.1),0);self.assertEqual(n._yaw(90,102.5),0)
  self.assertGreater(n._yaw(90,102.8),0)
 def test_heading_before_real_turn_is_not_in_post_turn_median(self):
  n=Navigator({})
  for t in (100,100.1,100.2):n._heading(radar(heading=90),t)
  n.camera_delivered(100.3,.1)
  self.assertEqual(n._heading(radar(heading=125),100.6),125)
 def test_without_delivered_turn_large_unexplained_heading_still_requires_confirmation(self):
  n=Navigator({});n._heading(radar(heading=90),100)
  self.assertEqual(n._heading(radar(heading=170),100.2),90)

class SamplingReuse(unittest.TestCase):
 def test_all_cone_rays_use_two_remaps_and_keep_north_east_geometry(self):
  for heading in (0,45,90,135,180,225,270,315):
   f=np.full((200,200,3),(70,100,120),np.uint8)
   for edge in (heading-45,heading+45):
    a=math.radians(edge);cv2.line(f,(100,100),(round(100+90*math.sin(a)),round(100-90*math.cos(a))),(255,255,255),2)
   with patch('minimap.cv2.remap',wraps=cv2.remap) as remap:
    got,confidence,half=MinimapVision.cone_geometry(f,(100,100))
   self.assertIsNotNone(got);self.assertLess(abs(angle_delta(got,heading)),8);self.assertEqual(remap.call_count,2)
 def test_sampling_cache_never_caches_image_pixels(self):
  cone_sampling.cache_clear();a=cone_sampling(200,200,100.,100.);b=cone_sampling(200,200,100.,100.)
  self.assertIs(a,b);self.assertEqual(cone_sampling.cache_info().maxsize,4)
  z=np.zeros((200,200,3),np.uint8);self.assertIsNone(MinimapVision.cone_geometry(z,(100,100))[0])
 def test_arrow_resizes_are_reused_without_reusing_detection_result(self):
  template=np.zeros((35,35),np.uint8);cv2.fillConvexPoly(template,np.array([[17,1],[27,30],[17,24],[7,30]]),255)
  a=ArrowLocator(template);image=np.zeros((100,100,3),np.uint8)
  with patch('map_reference.cv2.resize',wraps=cv2.resize) as resize:
   a.locate(image,20,near=(50,50));first=resize.call_count
   a.locate(image,20,near=(50,50));second=resize.call_count-first
  self.assertGreater(first,0);self.assertEqual(second,0)

class ActualEngineTimestamps(unittest.TestCase):
 def setUp(self):
  self.f=fixture.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
 def test_scene_receives_original_capture_time_even_after_slow_minimap(self):
  e=self.f.e;offers=[];e.scene_host.offer=lambda *a:offers.append(a)
  with patch('hybrid_engine.time.monotonic',return_value=102.6):
   e._scene_plan(self.f.frame,radar(),FlightReading(None,False),Drive(.78),100)
  self.assertEqual(offers[0][1],100)
 def test_real_pad_report_invalidates_old_heading_and_sets_real_settle_deadline(self):
  e=self.f.e;e.nav._heading(radar(heading=90),100)
  with patch('gather_engine.time.monotonic',return_value=102):e.gamepad.drive(.8,0,.42,lifetime=.35,yaw_lifetime=.1)
  self.assertIsNone(e.nav.last_heading);self.assertAlmostEqual(e.nav.next_pulse,102.65)

if __name__=='__main__':unittest.main()
