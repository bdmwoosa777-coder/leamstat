"""User-demonstrated, north-up landmark-relative exit paths.

Recording is read-only. Playback emits bounded Drive proposals; the engine's
focus, own gathering, death and CAPTCHA guards still own actual game input.
"""
from dataclasses import dataclass
from pathlib import Path
import json,math,os,threading,time
from camp_departure import CampDeparture
from navigation import Drive
from minimap import angle_delta
from vision import norm

MAX_BYTES=131072

def store_path(cfg=None):
 cfg=cfg or {}
 if cfg.get('camp_route_store'):return Path(cfg['camp_route_store'])
 if os.name=='nt':return Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'AppData/Local')))/'ACore2GatherScanner'/'camp_routes.json'
 return Path(__file__).resolve().parent/'camp_routes.json'

@dataclass(frozen=True)
class SavedExit:
 place:str
 aspect:float
 points:tuple

def validate_route(data):
 if not isinstance(data,dict) or set(data)!={'place','aspect','points'}:raise ValueError('Неверный формат записанного выхода')
 title=data['place'];aspect=data['aspect'];points=data['points']
 if not isinstance(title,str) or not 12<=len(norm(title))<=100:raise ValueError('Название места не распознано; запись не сохранена')
 if type(aspect) not in (int,float) or not math.isfinite(aspect) or not .7<=aspect<=2.5:raise ValueError('Неверные пропорции миникарты')
 if not isinstance(points,(tuple,list)) or not 2<=len(points)<=160:raise ValueError('Нужно от 2 до 160 точек выхода')
 clean=[]
 for point in points:
  if not isinstance(point,(tuple,list)) or len(point)!=2 or any(type(v) not in (int,float) or not math.isfinite(v) or abs(v)>200 for v in point):raise ValueError('Неверная точка выхода')
  clean.append(tuple(float(v) for v in point))
 if any(math.dist(a,b)>8 for a,b in zip(clean,clean[1:])):raise ValueError('Разрыв записи: точки слишком далеко друг от друга')
 if sum(math.dist(a,b) for a,b in zip(clean,clean[1:]))<15:raise ValueError('Путь слишком короткий: пройди через выход наружу')
 if math.hypot(*clean[-1])<max(45,math.hypot(*clean[0])+12):raise ValueError('Конец записи слишком близко к кибелиску: закончи за выходом из лагеря')
 return SavedExit(title,float(aspect),tuple(clean))

def load_routes(path):
 path=Path(path)
 if not path.exists():return ()
 if path.stat().st_size>MAX_BYTES:raise ValueError('Файл записанных выходов слишком большой')
 data=json.loads(path.read_text(encoding='utf-8'))
 if not isinstance(data,dict) or set(data)!={'version','routes'} or data['version']!=1 or not isinstance(data['routes'],list) or len(data['routes'])>16:raise ValueError('Неверный файл записанных выходов')
 return tuple(validate_route(x) for x in data['routes'])

def save_route(path,route,cancel=None):
 # Validate before touching the existing file; an aborted run cannot erase it.
 route=validate_route({'place':route.place,'aspect':route.aspect,'points':route.points})
 path=Path(path);routes=list(load_routes(path))
 routes=[r for r in routes if norm(r.place)!=norm(route.place)]+[route]
 if len(routes)>16:raise ValueError('Уже записано 16 мест; файл не изменён')
 data={'version':1,'routes':[{'place':r.place,'aspect':r.aspect,'points':r.points} for r in routes]}
 encoded=json.dumps(data,ensure_ascii=False,indent=2)
 if len(encoded.encode('utf-8'))>MAX_BYTES:raise ValueError('Слишком много точек выхода')
 if cancel is not None and cancel.is_set():raise ValueError('Запись отменена')
 path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_suffix('.tmp')
 try:
  tmp.write_text(encoded,encoding='utf-8')
  if cancel is not None and cancel.is_set():raise ValueError('Запись отменена')
  tmp.replace(path)
 finally:
  if tmp.exists():tmp.unlink()

def matching_route(routes,title):
 key=norm(title)
 return next((r for r in routes if len(key)>=12 and norm(r.place)==key),None)

def position(anchor,center,width):
 return ((center[0]-anchor[0])*313/width,(center[1]-anchor[1])*313/width)

def segment_position(point,a,b):
 vx,vy=b[0]-a[0],b[1]-a[1];den=vx*vx+vy*vy
 u=((point[0]-a[0])*vx+(point[1]-a[1])*vy)/den if den else 0.
 clamped=max(0,min(1,u));cross=math.dist(point,(a[0]+clamped*vx,a[1]+clamped*vy))
 return u,cross

class ExitRecorder:
 def __init__(self,title,center,bounds,anchor,now):
  self.title=title;self.bounds=bounds;self.width=bounds[2]-bounds[0];self.height=bounds[3]-bounds[1]
  self.started=now;self.seen=now;self.last_anchor=anchor;self.tail=position(anchor,center,self.width)
  self.points=[self.tail]
 def sample(self,center,bounds,anchor,now):
  if bounds!=self.bounds:raise ValueError('Размер/позиция миникарты изменились; запись отменена')
  if now-self.started>60:raise ValueError('Запись дольше 60 с; пройди короткий выход и заверши Ctrl+F8')
  if anchor is None:
   if now-self.seen>.8:raise ValueError('Кибелиск потерян на миникарте; запись не сохранена')
   return
  point=position(anchor,center,self.width)
  if math.dist(point,self.tail)>8 or now-self.seen>1:raise ValueError('Разрыв наблюдения/телепорт: запись не сохранена')
  self.seen=now;self.last_anchor=anchor;self.tail=point
  if math.dist(point,self.points[-1])>=2.5:self.points.append(point)
  if len(self.points)>159:raise ValueError('Слишком длинная запись')
 def finish(self,now):
  if now-self.seen>.5:raise ValueError('Нет свежего положения для конца записи')
  points=self.points[:]
  if math.dist(points[-1],self.tail)>.2:points.append(self.tail)
  return validate_route({'place':self.title,'aspect':self.width/self.height,'points':points})

@dataclass
class FollowAction:
 drive:Drive
 done:bool=False
 error:str|None=None

class ExitFollower:
 def __init__(self,route,anchor,center,bounds,now,yaw_sign=1):
  self.route=route;self.width=bounds[2]-bounds[0];self.aspect=self.width/(bounds[3]-bounds[1])
  if abs(self.aspect/route.aspect-1)>.03:raise ValueError('Пропорции миникарты не совпадают с записью')
  self.current=position(anchor,center,self.width)
  # Rejoin the demonstrated corridor, not an arbitrary straight shortcut to
  # its first point. Teleport/manual return can land farther along that path.
  distance,index=min((segment_position(self.current,a,b)[1],i) for i,(a,b) in enumerate(zip(route.points,route.points[1:]),1))
  if distance>6:raise ValueError('До записанного коридора больше 6 пикселей; подход к нему вслепую запрещён')
  self.index=index;self.join_distance=distance;self.best=None;self.progress=now;self.seen=now;self.started=now;self.last=now
  self.last_anchor=anchor;self.servo=CampDeparture(anchor,center,self.width,now,prefer_visible=True);self.turn_started=None;self.yaw_sign=yaw_sign
 def step(self,anchor,center,bounds,heading,now):
  def abort(message):return FollowAction(Drive(),error=message)
  width=bounds[2]-bounds[0];height=bounds[3]-bounds[1]
  if abs(width/self.width-1)>.02 or abs((width/height)/self.aspect-1)>.02:return abort('Размер миникарты изменился')
  if now-self.started>90:return abort('Записанный выход не завершён за 90 с')
  if now-self.last>1.2:self.progress=now # input was paused, never count it as delivered walking
  self.last=now
  if anchor is None:
   if now-self.seen>.8:return abort('Потерян кибелиск при повторе выхода')
   return FollowAction(Drive(reason='записанный выход: жду ориентир'))
  current=position(anchor,center,width)
  if math.dist(current,self.current)>8:return abort('Положение скачком изменилось: записанный путь отозван')
  self.current=current;self.last_anchor=anchor;self.seen=now
  while self.index<len(self.route.points):
   a,b=self.route.points[self.index-1],self.route.points[self.index]
   passed,cross=segment_position(current,a,b)
   if math.dist(current,b)>1.8 and not (passed>=1 and cross<=2.5):break
   self.index+=1;self.best=None;self.progress=now
  if self.index>=len(self.route.points):return FollowAction(Drive(),done=True)
  a,b=self.route.points[self.index-1],self.route.points[self.index]
  vx,vy=b[0]-a[0],b[1]-a[1];den=vx*vx+vy*vy
  u=max(0,min(1,((current[0]-a[0])*vx+(current[1]-a[1])*vy)/den)) if den else 0
  if math.dist(current,(a[0]+u*vx,a[1]+u*vy))>8:return abort('Отклонение от показанного пути больше 8 пикселей')
  distance=math.dist(current,b)
  if self.best is None or distance<self.best-.35:self.best=distance;self.progress=now
  if now-self.progress>4:return abort('Нет продвижения к следующей записанной точке 4 с')
  if heading is None:
   return FollowAction(Drive(reason='записанный выход: направление камеры не прочитано'))
  desired=math.degrees(math.atan2(b[0]-current[0],current[1]-b[1]))%360
  self.servo.bearing=desired;gate=self.servo.view_plan(heading,True,now,self.yaw_sign)
  if gate is not None:
   if self.turn_started is None:self.turn_started=now
   if now-self.turn_started>6:return abort('Не удалось выровнять камеру по записанному пути за 6 с')
   self.progress=now # a bounded facing turn is not a walking attempt
   return FollowAction(gate)
  self.turn_started=None
  # Small stick magnitudes can fall below the game's movement threshold.
  # Geometric waypoint acceptance handles arrival; never creep at .45.
  speed=1. if now-self.progress>1.2 else .8;angle=math.radians(angle_delta(desired,heading))
  return FollowAction(Drive(speed*math.cos(angle),speed*math.sin(angle),lifetime=.45,
   reason='записанный выход: точка '+str(self.index+1)+'/'+str(len(self.route.points))+'; dist='+str(round(distance,2))+'; pos='+str(tuple(round(v,2) for v in current))+'; target='+str(b)+'; stick='+str(speed)))

class RecordingSession:
 """Screen/minimap observations only; deliberately has no gamepad parameter."""
 def __init__(self,cfg,emit):
  self.cfg=dict(cfg);self.emit=emit;self.cancel=threading.Event();self.finish_request=threading.Event();self.done=threading.Event()
  self.saved=None;self.error=None;self.worker=None
 def start(self):
  self.worker=threading.Thread(target=self._run,daemon=True);self.worker.start()
 def _run(self):
  try:
   from screen_capture import ScreenCapture
   from minimap import MinimapVision
   from return_exit import purple_anchor,place_title
   screen=ScreenCapture();vision=MinimapVision(self.cfg)
   if not screen.pick():raise ValueError('Окно AION2 не найдено')
   deadline=time.monotonic()+10
   while not screen.focused():
    if self.cancel.wait(.1):return
    if time.monotonic()>deadline:raise ValueError('Переключись в AION2 перед записью')
   frame,_=screen.frame();bounds=vision.bounds(frame);center=vision.player(frame)
   scale=max(.5,(bounds[2]-bounds[0])/313)
   anchor=purple_anchor(frame,bounds,search_radius=65*scale)
   if anchor is None:raise ValueError('Подойди к кибелиску: его фиолетовая иконка должна быть рядом на миникарте')
   title=place_title(frame,bounds)
   if len(norm(title))<12:raise ValueError('Не удалось прочитать название места над миникартой')
   recorder=ExitRecorder(title,center,bounds,anchor,time.monotonic())
   self.emit('ROUTE_RECORD: запись началась: '+title+'. Пройди наружу и нажми Ctrl+F8; Ctrl+F9 — отмена. Бот не нажимает кнопки.')
   if os.name=='nt':
    import winsound
    try:winsound.Beep(900,120)
    except (OSError,RuntimeError):self.emit('ROUTE_RECORD: запись уже идёт; звуковой сигнал недоступен')
   note=-1e9
   while not self.cancel.wait(.12):
    if self.finish_request.is_set():break
    if not screen.focused():raise ValueError('Фокус игры потерян; запись отменена')
    frame,_=screen.frame();now=time.monotonic();bounds=vision.bounds(frame);center=vision.player(frame)
    anchor=purple_anchor(frame,bounds,near=recorder.last_anchor)
    recorder.sample(center,bounds,anchor,now)
    if now-note>=3:
     note=now;self.emit('ROUTE_RECORD: '+str(len(recorder.points))+' точек; расстояние от кибелиска '+str(round(math.hypot(*recorder.tail),1)))
   if self.cancel.is_set():return
   route=recorder.finish(time.monotonic());save_route(store_path(self.cfg),route,self.cancel);self.saved=route
  except Exception as exc:self.error=str(exc)
  finally:self.done.set()
