"""Supported ground selection and cleanup that survives interpreter shutdown."""
from pathlib import Path
from dataclasses import replace
import math,os,subprocess,sys,tempfile,unittest
from hybrid_navigation import HybridPlanner,near_route_vector
from test_hybrid import scene,route
from test_detour_memory import obstructed,bent
from test_navigation import radar
from navigation import Drive

class GroundChoices(unittest.TestCase):
 def test_supported_path_keeps_its_angle_with_effective_stick_magnitude(self):
  r=bent(1,.65);s=obstructed([r]);f,x=near_route_vector(r,s)
  self.assertGreaterEqual(math.hypot(f,x),.8)
  self.assertAlmostEqual(x/f,(.65-.5)*1.8/.55)
 def test_low_confidence_geometric_shortcut_cannot_override_supported_path(self):
  weak=replace(route(1,.5),confidence=.25,score=10)
  good=replace(route(2,.8),confidence=.8,score=1)
  a=HybridPlanner().choose(Drive(.8),obstructed([weak,good]),radar(),100)
  self.assertGreater(a.drive.strafe,0);self.assertGreaterEqual(math.hypot(a.drive.forward,a.drive.strafe),.8)
 def test_narrow_geometric_shortcut_is_not_a_walkable_passage(self):
  narrow=replace(route(1,.5),clearance=.2,score=10)
  a=HybridPlanner().choose(Drive(.8),obstructed([narrow,route(2,.2)]),radar(),100)
  self.assertLess(a.drive.strafe,0)
 def test_confidence_and_clearance_break_equal_geometry_ties(self):
  weak=replace(route(1,.2),confidence=.42,clearance=.5)
  good=replace(route(2,.8),confidence=.8,clearance=2)
  a=HybridPlanner().choose(Drive(.8),obstructed([weak,good]),radar(),100)
  self.assertGreater(a.drive.strafe,0)
 def test_fresh_loss_of_supported_passage_revokes_short_missing_frame_continuation(self):
  p=HybridPlanner();p.choose(Drive(.8),obstructed([route(1,.2)]),radar(),100,hint=1)
  weak=replace(route(2,.2),confidence=.2)
  p.choose(Drive(.8),obstructed([weak],100.2),radar(),100.2)
  d=p.choose(Drive(.8),None,radar(),100.4).drive
  self.assertEqual((d.forward,d.strafe),(0,0));self.assertIsNone(p.commit)
 def test_drop_is_not_made_walkable_by_stronger_stick(self):
  s=replace(obstructed([route(1,.5)]),ground=replace(scene().ground,routes=(route(1,.5),),drop_support=.2))
  d=HybridPlanner().choose(Drive(.8),s,radar(),100).drive
  self.assertEqual((d.forward,d.strafe),(0,0))

class ProcessShutdown(unittest.TestCase):
 def run_child(self,busy):
  with tempfile.TemporaryDirectory() as tmp:
   marker=Path(tmp)/'unloaded';root=Path(__file__).resolve().parent
   script='''import sys,time,threading
from pathlib import Path
from qwen_experiment import TemporalAdvisor,MODEL
import qwen_diagnostics
qwen_diagnostics.snapshot=lambda *a:{}
marker=Path(sys.argv[1]);entered=threading.Event()
class Client:
 model=MODEL
 compact=False
 def probe(self):pass
 def warmup(self,timeout=180):entered.set();time.sleep(.2)
 def unload(self):time.sleep(.15);marker.write_text('keep_alive=0')
h=TemporalAdvisor({'ollama_autostart':False},lambda _:None)
h.report_root=marker.parent;h.client_factory=lambda *a:Client()
if sys.argv[2]=='busy':
 h.prepare();assert entered.wait(3)
else:h.touched_model=True
h.close()
# No join here: exercise Python exiting immediately after the window closes.
'''
   env=dict(os.environ,PYTHONPATH=str(root))
   result=subprocess.run([sys.executable,'-c',script,str(marker),'busy' if busy else 'idle'],env=env,capture_output=True,text=True,timeout=10)
   self.assertEqual(result.returncode,0,result.stderr);self.assertTrue(marker.exists(),result.stderr)
 def test_idle_model_unload_survives_main_thread_exit(self):self.run_child(False)
 def test_closing_during_load_still_finishes_request_and_unloads(self):self.run_child(True)

if __name__=='__main__':unittest.main()
