"""Hidden resource words must not interrupt a tracked own resource; never B."""
import unittest
from dataclasses import replace
from unittest.mock import patch
import cv2,numpy as np
from owned_emblem import OwnedEmblem
from test_ether_emblem import scene,ether
import test_collection_cycle as cyclefx
import test_continuation as contfx

class MarkerTrack(unittest.TestCase):
 def setUp(self):
  self.frame=scene();self.c=ether(self.frame);self.key=(1,7,99,1000);self.t=OwnedEmblem()
  self.assertTrue(self.t.seed(self.key,self.c,self.frame,100))
 def hide(self):
  x,y,w,h=self.c.box;cv2.rectangle(self.frame,(x,y),(x+w,y+h),(230,220,30),-1)
 def test_player_name_over_word_does_not_hide_marker(self):
  self.hide();self.assertIsNotNone(self.t.refresh(self.key,self.frame,100.2))
 def test_small_camera_translation_reanchors_live_point(self):
  f=cv2.warpAffine(self.frame,np.float32([[1,0,10],[0,1,6]]),(self.frame.shape[1],self.frame.shape[0]),borderValue=(35,35,35))
  c=self.t.refresh(self.key,f,100.2);self.assertIsNotNone(c)
  self.assertAlmostEqual(c.click_x,self.c.click_x+10,delta=2);self.assertAlmostEqual(c.click_y,self.c.click_y+6,delta=2)
 def test_missing_marker_does_not_reuse_stale_coordinates(self):
  self.assertIsNone(self.t.refresh(self.key,np.full_like(self.frame,35),100.2))
 def test_new_id_or_owner_cannot_inherit_marker(self):
  for key in ((1,7,100,1000),(1,8,99,1000),(2,7,99,1000)):
   self.assertIsNone(self.t.refresh(key,self.frame,100.2))
 def test_stale_track_is_not_refreshed_without_active_id_seed(self):
  self.assertIsNone(self.t.refresh(self.key,self.frame,102.6))
 def test_older_frame_does_not_rewind_track(self):
  self.assertIsNotNone(self.t.refresh(self.key,self.frame,100.3));self.assertIsNone(self.t.refresh(self.key,self.frame,100.1));self.assertEqual(self.t.at,100.3)
 def test_nearby_other_marker_cannot_replace_disappeared_one(self):
  shifted=cv2.warpAffine(self.frame,np.float32([[1,0,80],[0,1,0]]),(self.frame.shape[1],self.frame.shape[0]),borderValue=(35,35,35))
  self.assertIsNone(self.t.refresh(self.key,shifted,100.2))

class NativeOwnedContinuation(unittest.TestCase):
 def setUp(self):
  self.f=cyclefx.CycleEngine('test_defaults_are_event_driven_and_940ms_in_app_and_file');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown);self.e=self.f.e
  self.e.bridge.controller_native=True
  self.all_buttons=[];press=self.f.pad.press_button
  self.f.pad.press_button=lambda button:(self.all_buttons.append(button),press(button))[-1]
  self.assertIsNotNone(self.e._observe_owned_emblem(self.f.frame,self.f.clock))
  self.e.f_enable()
 def ended(self):
  self.f.ended();self.f.f.selected=0;self.f.absent()
  x,y,w,h=self.e.candidate.box;self.f.frame[y:y+h,x:x+w]=(230,230,30)
 def test_hidden_letters_allow_one_emblem_a_after_own_end_without_b(self):
  self.ended()
  with patch('gather_engine.find_resource_near',side_effect=AssertionError('word not required')):self.e.f_enable()
  self.assertEqual(self.f.pad.presses,1);self.assertNotIn(0x2000,self.all_buttons)
  self.assertEqual(self.e.network_target,(1,99));self.assertEqual(self.e.mode,'GATHER')
 def test_duplicate_own_result_cannot_send_another_click(self):
  self.ended();self.e.f_enable();self.f.clock+=1;self.e.f_enable();self.assertEqual(self.f.pad.presses,1)
 def test_current_partial_panel_blocks_click_even_if_result_arrived(self):
  self.f.ended();self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_foreign_result_cannot_authorize_click(self):
  self.ended();self.f.f.last_own_result=(123,1100);self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_new_active_attempt_cancels_old_end_permission(self):
  self.ended();self.f.f.attempt_active=True;self.f.f.started=1200;self.f.f.attempt_ordinal=2
  self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_foreign_selection_cannot_be_clicked(self):
  self.ended();self.f.f.selected=123;self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_removed_or_exhausted_resource_cannot_be_clicked(self):
  self.ended();self.f.f.nodes[99].used=3;self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_focus_loss_prevents_emblem_click(self):
  self.ended();self.e.screen.focused=lambda:False;self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_actual_marker_disappearance_never_uses_old_point(self):
  self.ended();self.f.frame[:]=35;self.e.snapshot=None;self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_marker_disappearing_after_cursor_move_aborts_input(self):
  self.ended();move=self.e.bridge.cursor
  def moved(x,y):move(x,y);self.f.frame[:]=35
  self.e.bridge.cursor=moved;self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_no_general_ocr_for_native_owned_marker_observation(self):
  with patch('gather_engine.find_world_resource',side_effect=AssertionError('OCR')),patch('gather_engine.find_resource_near',side_effect=AssertionError('words')):
   self.assertIsNotNone(self.e._network_world_observation(self.f.frame).candidate)
 def test_completed_unselected_resource_cannot_seed_an_untracked_badge(self):
  self.ended();self.e.owned_emblem.clear()
  self.assertIsNone(self.e._observe_owned_emblem(self.f.frame,self.f.clock));self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_manually_selected_resource_without_own_gather_cannot_seed(self):
  self.e.owned_emblem.clear();self.f.f.collecting=None
  self.assertIsNone(self.e._observe_owned_emblem(self.f.frame,self.f.clock))
 def test_own_end_with_changed_owner_does_not_reuse_track(self):
  self.ended();self.f.f.own=8;self.e.f_enable();self.assertEqual(self.f.pad.presses,0)
 def test_hidden_word_does_not_trigger_a_new_camera_search(self):
  self.ended();self.e.f_enable();self.assertEqual(self.f.pad.axes,(0,0,0,0))
  self.assertFalse({'V','END_AIR','TAB','TAP_F','F_ON'}&set(self.f.commands))

class HiddenWordWait(unittest.TestCase):
 def test_live_marker_prevents_the_eight_second_missing_word_release(self):
  f=contfx.Continuation('test_fresh_local_point_cancels_deadline');f.setUp()
  try:
   e=f.e;e.bridge.controller_native=True;e.target='Эфир';e.cfg['repeat_owned_clicks']=True
   f.frame=scene();c=ether(f.frame);e.candidate=c;key=e._owned_emblem_key();self.assertIsNotNone(key)
   self.assertTrue(e.owned_emblem.seed(key,c,f.frame,100))
   x,y,w,h=c.box;f.frame[y:y+h,x:x+w]=(220,220,40)
   for i in range(11):
    f.clock=100+i;self.assertIsNotNone(e.owned_emblem.refresh(key,f.frame,f.clock))
    self.assertFalse(e._completed_point_wait_tick(f.frame,f.clock))
   self.assertEqual(e.mode,'GATHER');self.assertIsNone(e.continuation_watch)
  finally:f.tearDown();f.doCleanups()


import test_nearby_gem as gemfx
class ExplicitGemSelection(unittest.TestCase):
 def setUp(self):
  self.f=gemfx.NearbyGem('test_missing_prompt_does_not_offer_exception');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
 def test_one_candidate_exception_restores_priority_after_normal_selection(self):
  self.f.observe();self.assertTrue(self.f.act());self.assertFalse(self.f.e.rescue_selecting)
  self.assertTrue(self.f.e.policy.priority);self.assertEqual(len(self.f.clicks),1);self.assertNotIn(0x2000,self.f.buttons)
 def test_failed_explicit_selection_recovers_search_without_leaking_exception(self):
  self.f.observe()
  def fail(*args):self.f.e.mode='ACQUIRE';return False
  self.f.e.click_candidate.side_effect=fail;self.assertTrue(self.f.act())
  self.assertEqual(self.f.e.mode,'SEARCH');self.assertFalse(self.f.e.rescue_selecting);self.assertNotIn(0x2000,self.f.buttons)

if __name__=='__main__':unittest.main()
