"""Readiness, resident weights and fast interruptible escape from the 09:10 run."""
import json,threading,time,unittest,tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import Mock,patch
from qwen_preflight import prepare,PreflightFailure
from qwen_experiment import TemporalAdvisor,TemporalClient,MODEL
from test_qwen_experiment import ANSWER,CTX
from test_hybrid import FRAME
import test_active as escape_fixture
from app import UI

class ClockClient:
 model=MODEL
 def __init__(self,clock,delays=(2,),answers=None,stop=None):
  self.clock=clock;self.delays=list(delays);self.answers=answers;self.stop=stop;self.calls=[];self.compact=False;self.keep_alive='10m'
 def warmup(self,timeout=90):self.calls.append('warm');self.clock[0]+=76
 def analyze_views(self,views,timeout=12):
  self.calls.append(('visual',self.compact,len(views),views[-1].minimap.shape))
  value=self.delays.pop(0);self.clock[0]+=abs(value)
  if value<0:raise TimeoutError('timed out')
  return dict(ANSWER) if self.answers is None else self.answers

class RealResponseBeforeStart(unittest.TestCase):
 def run_case(self,delays=(2,),answers=None,stop=None):
  clock=[100.];stop=stop or threading.Event();c=ClockClient(clock,delays,answers,stop)
  report=prepare(c,stop,lambda _:None,clock=lambda:clock[0]);return c,report
 def test_cold_76_second_load_is_separate_from_a_two_second_visual_response(self):
  c,r=self.run_case();self.assertEqual(r['load_seconds'],76);self.assertEqual(r['visual_seconds'],2)
  self.assertEqual(r['seconds'],78);self.assertFalse(r['game_frames_analyzed']);self.assertEqual(c.calls[0],'warm')
 def test_preflight_uses_runtime_image_budget_not_smaller_test_pictures(self):
  clock=[100.];c=ClockClient(clock,(1,));original=c.analyze_views;seen=[]
  def analyze(v,timeout):seen.extend([x.world.shape[1] for x in v]+[v[-1].minimap.shape[1]]);return original(v,timeout)
  c.analyze_views=analyze;prepare(c,threading.Event(),lambda _:None,clock=lambda:clock[0])
  self.assertEqual(seen,[768,768,224])
 def test_balanced_profile_must_be_fast_enough_for_live_age_budget(self):
  c,r=self.run_case((7,2));self.assertEqual(r['profile'],'compact');self.assertEqual(len(r['attempts']),2)
  self.assertEqual([x[1] for x in c.calls if isinstance(x,tuple)],[False,True])
 def test_timeout_can_fall_back_to_a_valid_compact_response(self):
  c,r=self.run_case((-12,3));self.assertEqual(r['profile'],'compact');self.assertIn('error',r['attempts'][0])
 def test_two_slow_responses_do_not_pretend_experiment_is_usable(self):
  with self.assertRaises(PreflightFailure):self.run_case((8,8))
 def test_invalid_schema_is_not_a_prepared_model(self):
  with self.assertRaises(PreflightFailure):self.run_case((1,1),{'buttons':['Y']})
 def test_cancellation_during_loading_cannot_start_a_visual_test(self):
  clock=[100.];stop=threading.Event();c=ClockClient(clock,(1,));original=c.warmup
  def load(timeout):original(timeout);stop.set()
  c.warmup=load;self.assertIsNone(prepare(c,stop,lambda _:None,clock=lambda:clock[0]));self.assertEqual(c.calls,['warm'])
 def test_cancellation_during_visual_test_cannot_mark_it_ready(self):
  clock=[100.];stop=threading.Event();c=ClockClient(clock,(1,));original=c.analyze_views
  def analyze(v,timeout):a=original(v,timeout);stop.set();return a
  c.analyze_views=analyze;self.assertIsNone(prepare(c,stop,lambda _:None,clock=lambda:clock[0]))

class ResidentHost(unittest.TestCase):
 def host(self):return TemporalAdvisor({'ollama_autostart':False},lambda _:None)
 def fake(self,h,clock,delays=(2,1)):
  c=ClockClient(clock,delays);c.probe=lambda:None;c.unload=Mock()
  h.client_factory=lambda *a:c;return c
 def test_prepare_keeps_model_ten_minutes_and_does_not_publish_a_synthetic_game_advice(self):
  h=self.host();clock=[100.];c=self.fake(h,clock)
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   self.assertTrue(h.prepare());h.worker.join(2)
  self.assertTrue(h.prepared);self.assertFalse(h.busy);self.assertEqual(c.keep_alive,'10m');self.assertIsNone(h.latest)
  self.assertEqual(h.prepare_info['visual_seconds'],2)
 def test_live_request_60_seconds_after_preparation_does_not_load_weights_again(self):
  h=self.host();clock=[100.];c=self.fake(h,clock)
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   h.prepare();h.worker.join(2);clock[0]+=60
   h.observe(FRAME,clock[0],90,0,CTX,(500,0,640,140))
   self.assertTrue(h.offer(FRAME,None,clock[0],90,0,CTX));h.worker.join(2)
  self.assertEqual(c.calls.count('warm'),1);self.assertIsNotNone(h.latest)
 def test_preparation_failure_is_reported_and_unloads_model(self):
  h=self.host();clock=[100.];c=self.fake(h,clock,(8,8))
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   h.prepare();h.worker.join(2)
  self.assertFalse(h.prepared);self.assertIsNotNone(h.error);c.unload.assert_called_once()
 def test_preparation_is_asynchronous_and_close_waits_for_its_cleanup(self):
  h=self.host();clock=[100.];c=self.fake(h,clock);entered=threading.Event();release=threading.Event()
  def warm(timeout):entered.set();release.wait(2)
  c.warmup=warm
  with patch.object(Path,'write_text'):
   began=time.monotonic();self.assertTrue(h.prepare());self.assertLess(time.monotonic()-began,.2)
   self.assertTrue(entered.wait(1));h.close();release.set();h.worker.join(2)
  self.assertFalse(h.prepared);self.assertIsNone(h.latest);c.unload.assert_called_once()
 def test_preparation_does_not_start_a_second_worker(self):
  h=self.host();h.busy=True;self.assertFalse(h.prepare());self.assertIsNone(h.worker)
 def test_prepared_flag_does_not_require_another_synthetic_test(self):
  h=self.host();h.prepared=True;self.assertTrue(h.prepare());self.assertIsNone(h.worker)
 def test_stopping_a_resident_model_still_unloads_it(self):
  h=self.host();clock=[100.];c=self.fake(h,clock)
  with patch('qwen_experiment.time.monotonic',side_effect=lambda:clock[0]),patch.object(Path,'write_text'):
   h.prepare();h.worker.join(2);h.close()
  # close unloads in a separate daemon, so wait on the observed call, not a sleep.
  deadline=time.monotonic()+1
  while not c.unload.called and time.monotonic()<deadline:threading.Event().wait(.01)
  c.unload.assert_called_once()
 def test_runtime_ttl_affects_both_load_and_visual_calls_without_changing_unload(self):
  c=TemporalClient(model=MODEL);c.keep_alive='10m';payloads=[]
  def call(path,payload,**kw):
   payloads.append((path,payload));return {'done':True,'message':{'content':json.dumps(ANSWER)}}
  c.call=call;c.warmup()
  from check_qwen_experiment import synthetic_views
  c.analyze_views(synthetic_views());c.unload()
  self.assertEqual([p['keep_alive'] for _,p in payloads],['10m','10m',0])

class FakeRoot:
 def __init__(self):self.calls=[]
 def after(self,delay,callback):self.calls.append((delay,callback))

class StartGate(unittest.TestCase):
 def ui(self,host=None):
  u=object.__new__(UI);u._closing=False;u._start_pending=True;u._start_token=5;u.worker=None
  u.root=FakeRoot();u.cfg={'dry_run':False,'allow_click':True,'network_enabled':False,'click_backend':'gamepad','analyzer_enabled':True,'qwen_wait_before_start':True}
  u.engine=SimpleNamespace(analyzer=host,bridge=SimpleNamespace(controller_native=True),silence=Mock()) if host else None
  u.gamepad=object();u.save=Mock(return_value=True);u.connect_gamepad=lambda:True;u.log=Mock()
  u._qwen_preflight_started=time.monotonic();u._qwen_wait_note=-1e9
  return u
 def host(self,**kw):return SimpleNamespace(temporal=True,busy=True,unloading=False,prepared=False,phase='загрузка модели',error=None,prepare=Mock(),close=Mock(),**kw)
 def test_prepared_status_is_distinct_from_game_scene_analysis(self):
  h=self.host();h.busy=False;h.prepared=True;h.ready=False;u=self.ui(h)
  u.analyzer_status();self.assertIn('модель подготовлена',u.log.call_args.args[0]);self.assertIn('игровой',u.log.call_args.args[0])
 def test_no_game_start_or_controls_are_scheduled_while_model_is_loading(self):
  h=self.host();u=self.ui(h);u._schedule_game_start=Mock();u._await_qwen(5,h)
  u._schedule_game_start.assert_not_called();self.assertEqual(u.root.calls[0][0],150)
 def test_verified_visual_response_releases_the_start_gate(self):
  h=self.host();h.busy=False;h.prepared=True;u=self.ui(h);u._schedule_game_start=Mock()
  u._await_qwen(5,h);u._schedule_game_start.assert_called_once_with(5)
 def test_failed_check_explicitly_reports_fallback_and_starts_ordinary_control(self):
  h=self.host();h.busy=False;h.error='both profiles too slow';u=self.ui(h);u._schedule_game_start=Mock()
  u._await_qwen(5,h);u._schedule_game_start.assert_called_once_with(5);self.assertTrue(u._start_pending);h.close.assert_called_once()
  self.assertIn('без помощника',u.log.call_args.args[0])
 def test_cancelled_or_stale_callbacks_cannot_launch_the_game(self):
  h=self.host();h.busy=False;h.prepared=True
  for attr,value in (('_closing',True),('_start_pending',False),('_start_token',6)):
   u=self.ui(h);setattr(u,attr,value);u._schedule_game_start=Mock();u._await_qwen(5,h);u._schedule_game_start.assert_not_called()
 def test_real_launch_path_prepares_adviser_before_scheduling_game_start(self):
  h=self.host();u=self.ui();engine=SimpleNamespace(analyzer=h)
  u._schedule_game_start=Mock()
  with patch('app.GatherEngine',return_value=engine):u._launch_if_ready(5)
  h.prepare.assert_called_once();u._schedule_game_start.assert_not_called();self.assertTrue(u._start_pending)
 def test_ordinary_mode_does_not_acquire_a_model_or_wait_for_preflight(self):
  u=self.ui();engine=SimpleNamespace(analyzer=None);u._schedule_game_start=Mock()
  with patch('app.GatherEngine',return_value=engine):u._launch_if_ready(5)
  u._schedule_game_start.assert_called_once_with(5)
 def test_new_start_waits_for_old_model_cleanup_before_saving_or_creating_another_engine(self):
  h=self.host();u=self.ui(h)
  with patch('app.GatherEngine') as engine:u._launch_if_ready(5)
  u.save.assert_not_called();engine.assert_not_called();self.assertEqual(u.root.calls[-1][0],150)
 def test_local_mode_can_start_while_old_model_cleanup_finishes(self):
  h=self.host();u=self.ui(h);u.cfg['analyzer_enabled']=False;u._schedule_game_start=Mock()
  with patch('app.GatherEngine',return_value=SimpleNamespace(analyzer=None)):u._launch_if_ready(5)
  u._schedule_game_start.assert_called_once_with(5)

class EscapeGuard(unittest.TestCase):
 def setUp(self):
  self.f=escape_fixture.ActiveEngine('test_real_escape_reports_x_with_translation_and_credits_delivered_movement')
  self.f.setUp();self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
  self.e=self.f.e;self.d=self.f.escape()
 def test_jump_wait_does_not_repeat_screen_capture_or_panel_detection(self):
  screen=self.e.screen.frame;captures=[]
  def grab():captures.append(1);return screen()
  self.e.screen.frame=grab
  def wait(seconds,stop,allowed):
   self.assertLessEqual(seconds,.1)
   for _ in range(8):self.assertTrue(allowed())
   return True
  with patch.object(self.f.input,'wait',side_effect=wait),patch('hybrid_engine.gathering_panel_pair',return_value=False) as panel:
   self.e._motion(self.d)
  self.assertEqual(len(captures),1);self.assertEqual(panel.call_count,1);self.assertIsNotNone(self.e.hybrid.escape_walk_at)
 def test_own_collection_interrupts_fast_checks_and_releases_x_and_stick(self):
  def wait(seconds,stop,allowed):
   self.assertTrue(allowed());self.f.source.state.attempt_active=True
   self.assertFalse(allowed());return False
  with patch.object(self.f.input,'wait',side_effect=wait):self.e._motion(self.d)
  self.assertEqual(self.f.pad.buttons,0);self.assertEqual(self.f.pad.axes,(0,0,0,0))
 def test_lost_focus_during_jump_releases_the_input(self):
  def wait(seconds,stop,allowed):self.e.screen.focused=lambda:False;return allowed()
  with patch.object(self.f.input,'wait',side_effect=wait):self.e._motion(self.d)
  self.assertEqual(self.f.pad.buttons,0);self.assertEqual(self.f.pad.axes,(0,0,0,0))
 def test_visible_gather_panel_prevents_jump_and_cancels_translation(self):
  with patch('hybrid_engine.gathering_panel_pair',return_value=True),patch.object(self.f.input,'tap_moving_jump') as jump:
   self.e._motion(self.d);jump.assert_not_called()
  self.assertEqual(self.f.pad.axes,(0,0,0,0))
