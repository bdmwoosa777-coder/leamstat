"""Reuse delayed inference only after a new, stationary image verifies the view.

No timestamp is rewritten and SceneHost.current's .9 s contract is unchanged.
This is camp-only: same camera revision/pose, no live translation, an original
post-settling source, and a tightly matching textured world in the current frame.
"""
import math
import cv2,numpy as np
from minimap import angle_delta

def recheck(reading,frame,now,heading,pitch,revision,settled_after,stationary,frame_age=0):
 if (not 0<=frame_age<=.35 or not stationary or reading is None or reading.source is None
     or not .9<now-reading.captured<=3.2 or reading.captured<settled_after
     or reading.revision!=revision or heading is None or reading.heading is None
     or abs(angle_delta(heading,reading.heading))>2 or abs(pitch-reading.pitch)>.005):return None
 old=reading.source
 if old.ndim!=3 or frame.ndim!=3 or old.shape[2]!=3 or frame.shape[2]!=3:return None
 def view(image):return cv2.resize(image,(96,54),interpolation=cv2.INTER_AREA).astype(np.float32)
 a,b=view(old),view(frame)
 mask=np.zeros((54,96),bool);mask[15:43,17:76]=True;mask[24:44,41:56]=False;mask[38:43,17:33]=False
 if min(float(a[mask].std(axis=0).mean()),float(b[mask].std(axis=0).mean()))<6:return None
 diff=np.max(np.abs(a-b),axis=2);values=diff[mask]
 if float(values.mean())>1.8 or float(np.percentile(values,99))>8 or float(np.mean(values>20))>.002:return None
 # A small, local change must not disappear in a whole-image average.
 for y in range(15,43,4):
  for x in range(17,76,4):
   selected=mask[y:y+4,x:x+4]
   if selected.any() and float(diff[y:y+4,x:x+4][selected].mean())>5:return None
 return reading
