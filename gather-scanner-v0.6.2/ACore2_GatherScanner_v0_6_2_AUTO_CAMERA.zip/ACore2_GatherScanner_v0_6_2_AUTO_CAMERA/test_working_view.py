import time,unittest
from unittest.mock import patch
from contextlib import ExitStack
from camera_working_view import working_view_ms
from flight import FlightReading
from gamepad_input import GamepadInput
from test_navigation import GatherFixture,obs
import gather_engine as ge


class WorkingViewTests(GatherFixture,unittest.TestCase):
    def setUp(self):
        super().setUp();self.patches=ExitStack();self.addCleanup(self.patches.close)
        self.patches.enter_context(patch.object(ge,'gathering_panel',return_value=False))
        self.patches.enter_context(patch.object(ge,'read_flight',return_value=FlightReading(None,False)))
        self.patches.enter_context(patch.object(ge,'selected_target',return_value=(None,None)))
        self.patches.enter_context(patch.object(self.e.cap,'check',return_value=(False,0)))
        self.patches.enter_context(patch.object(self.e.death,'check',return_value=(False,0)))

    def gather(self):
        self.e.mode='GATHER';self.e.target='Эфир';self.e.target_confirmed=True
        self.e.resource_hold=True;self.e.f_on=True;self.e.started=99
        self.e.last_progress=100;self.e.camera_scheduler_active=True

    def test_upward_homing_then_one_full_670ms_down_during_gather_keeps_f_and_zero_movement(self):
        self.gather();reports=[];axes=[];listener=self.input.motion_listener
        def record(pitch,now,lease):
            reports.append((pitch,now));axes.append(self.pad.axes);listener(pitch,now,lease)
        self.input.motion_listener=record
        with patch.object(ge,'gathering_panel',return_value=True):
            self.assertTrue(self.e._prepare_working_view())
        positive=sum(reports[i+1][1]-t for i,(p,t) in enumerate(reports[:-1]) if p>0)
        negative=sum(reports[i+1][1]-t for i,(p,t) in enumerate(reports[:-1]) if p<0)
        self.assertAlmostEqual(positive,2.0,delta=.04)
        self.assertAlmostEqual(negative,.670,delta=.025)
        self.assertEqual(len([p for p,t in reports if p<0]),1)
        self.assertTrue(all(a[:3]==(0,0,0) for a in axes))
        self.assertTrue(self.e.f_on);self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.commands,[])
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertEqual(self.pad.presses,0)
        self.assertLess(abs(self.e.pitch.offset(time.monotonic())),.006)
        self.assertGreater(self.e.identity_valid_after,0)

    def test_old_600ms_transport_limit_cannot_be_accepted_as_a_valid_working_view(self):
        drive=self.input.drive
        def old_limit(*args,**kwargs):kwargs['lifetime']=.6;return drive(*args,**kwargs)
        with patch.object(self.e,'_hold_pitch_up',return_value=True),patch.object(self.input,'drive',side_effect=old_limit),patch.object(self.e.pitch,'set_working_baseline') as baseline:
            self.assertFalse(self.e._prepare_working_view())
        baseline.assert_not_called();self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_stop_during_upward_homing_does_not_run_the_down_pulse_or_accept_a_partial_view(self):
        with patch.object(GamepadInput,'wait',return_value=False),patch.object(self.e.pitch,'set_working_baseline') as baseline,patch.object(self.input,'drive',wraps=self.input.drive) as drive:
            self.assertFalse(self.e._prepare_working_view())
        self.assertTrue(all(call.args[3]>0 for call in drive.call_args_list))
        baseline.assert_not_called();self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_current_autopath_or_noncollecting_flight_defers_alignment(self):
        for kind in ('flight','target'):
            with ExitStack() as stack:
                if kind=='flight':stack.enter_context(patch.object(ge,'read_flight',return_value=FlightReading(50,True)))
                if kind=='target':stack.enter_context(patch.object(ge,'selected_target',return_value=('Эфир',20)))
                drive=stack.enter_context(patch.object(self.input,'drive'))
                self.assertTrue(self.e._prepare_working_view());drive.assert_not_called()
                self.assertIsNotNone(self.e.camera_alignment_due)
                if kind=='target':
                    self.assertEqual(self.e.mode,'APPROACH');self.assertTrue(self.e.resource_hold)
                    self.assertIn('TAP_F',self.commands)

    def test_no_focus_never_sends_an_alignment_pulse(self):
        self.e.screen.focused=lambda:False
        with patch.object(self.input,'drive') as drive:self.assertFalse(self.e._prepare_working_view())
        drive.assert_not_called()

    def test_observation_mode_or_disabled_alignment_never_changes_view(self):
        for option in ('dry_run','camera_auto_calibrate','camera_scan'):
            cfg=dict(self.e.cfg);self.e.cfg[option]=(option=='dry_run')
            with patch.object(self.input,'drive') as drive:self.assertTrue(self.e._prepare_working_view())
            drive.assert_not_called();self.e.cfg=cfg

    def test_dialog_blocks_initial_alignment(self):
        with patch.object(self.e.cap,'check',return_value=(True,1)),patch.object(self.e,'trigger_alarm') as alarm,patch.object(self.input,'drive') as drive:
            self.assertFalse(self.e._prepare_working_view())
        self.assertEqual(alarm.call_args.args[0],'CAPTCHA');drive.assert_not_called()

    def test_selected_working_views_are_allowed_but_bad_settings_do_not_send_long_pulses(self):
        for value in (660,670,680):self.assertEqual(working_view_ms({'camera_working_view_ms':value}),value)
        for value in (0,70000,float('nan'),None,'bad'):
            self.assertEqual(working_view_ms({'camera_working_view_ms':value}),670)

    def test_periodic_gather_alignment_is_a_specific_exception_to_normal_stick_lock(self):
        self.gather()
        with patch.object(self.e,'_calibrate_camera',return_value=True) as calibrate:
            self.step(obs('Эфир',distance=1),100,plate=3,panel=True)
        calibrate.assert_called_once_with('во время сбора',allow_gather=True)
        self.assertTrue(self.e.f_on);self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_last_attempt_and_recent_calibration_are_not_interrupted_by_another_calibration(self):
        self.gather()
        with patch.object(self.e,'_calibrate_camera') as calibrate:
            self.step(obs('Эфир',distance=1),100,plate=1,panel=True)
            self.e.camera_last_calibrated=99
            self.step(obs('Эфир',distance=1),100,plate=3,panel=True)
        calibrate.assert_not_called()

    def test_damage_defense_wins_over_periodic_camera_alignment(self):
        self.gather();self.e.health.numeric(self.frame,ge.read_hp(self.frame),99)
        from health import HPReading
        self.e.health.numeric(self.frame,HPReading(19999,20000),99.8)
        with patch.object(self.e,'_calibrate_camera') as calibrate,patch.object(self.e,'_defend_and_resume') as defend:
            self.step(obs('Эфир',distance=1),100,plate=3,panel=True)
        calibrate.assert_not_called();defend.assert_called_once_with(resume=True)

    def test_completed_aether_requests_alignment_before_the_next_patrol(self):
        self.gather();self.e.collecting_visible=False
        self.e.return_to_search('закончено',exhausted=True,reading=FlightReading(None,False))
        self.e.post_gather_until=0
        with patch.object(self.e,'_calibrate_camera',return_value=True) as calibrate:
            self.step(obs(),time.monotonic()+1,plate=None,panel=False)
        calibrate.assert_called_once_with('после сбора эфира')

    def test_starting_during_collection_adopts_the_resource_even_with_old_far_distance(self):
        self.step(obs('Эфир',distance=30),100,plate=3,panel=True)
        self.assertEqual(self.e.mode,'GATHER');self.assertEqual(self.e.target,'Эфир')
        self.assertTrue(self.e.target_confirmed);self.assertTrue(self.e.resource_hold);self.assertTrue(self.e.f_on)
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_unknown_collection_identity_remains_stationary_without_adoption(self):
        self.step(obs(),100,plate=3,panel=True)
        self.assertEqual(self.e.mode,'SEARCH');self.assertIsNone(self.e.target)
        self.assertEqual(self.pad.axes,(0,0,0,0));self.assertNotIn('F_ON',self.commands)


if __name__=='__main__':unittest.main()
