"""Calibrated world XY -> map pixels; map arrows are CHARACTER headings."""
from dataclasses import dataclass
from pathlib import Path
import math,json,time
import cv2,numpy as np
from map_reference import TerrainMatcher,ArrowLocator,arrow_mask,transform
from spatial import Atlas,resource_names
from vision import DEFAULT_NAMES
from functools import lru_cache
from atlas_registration import AtlasRegistration

ROOT=Path(__file__).resolve().parent

@lru_cache(maxsize=1)
def full_catalogue():
 data=json.loads((ROOT/'assets/atlas/gather_full.json').read_text(encoding='utf-8'))
 if data.get('version')!=1:raise ValueError('Неизвестный формат каталога ресурсов')
 resources={r['id']:r for r in data['resources']};maps={}
 for layer in data['maps']:
  table={}
  for group in layer['groups']:
   if len(group['env_object_ids'])!=1:raise ValueError('Неоднозначный тип спавна')
   template=group['env_object_ids'][0]
   if template not in resources:raise ValueError('Нет описания типа ресурса')
   points=table.setdefault(str(template),[])
   for xyz in group['points']:
    if len(xyz)!=3 or not all(math.isfinite(v) and abs(v)<1e6 for v in xyz):raise ValueError('Некорректная позиция спавна')
    points.append(tuple(xyz))
  maps[layer['map_id']]=table
 return maps

def fit_world(points):
 if len(points)<3:raise ValueError('Нужны три разных ориентира')
 world=np.float64([p['world'][:2] for p in points]);pixels=np.float64([p['pixel'] for p in points])
 if not np.isfinite(world).all() or not np.isfinite(pixels).all():raise ValueError('Некорректные точки')
 if abs(cv2.contourArea(world.astype(np.float32)))<1e6 or abs(cv2.contourArea(pixels.astype(np.float32)))<500:raise ValueError('Выберите три разнесённых ориентира, не на одной линии')
 # North-up similarity: positive isotropic scale and translation only.
 center=world.mean(axis=0);pc=pixels.mean(axis=0);v=world-center;u=pixels-pc
 scale=float(np.sum(v*u)/np.sum(v*v))
 if not 1e-5<scale<.1:raise ValueError('Масштаб/направление карты не совпали; север должен быть сверху')
 offset=pc-scale*center;error=np.linalg.norm(world*scale+offset-pixels,axis=1)
 if error.max()>min(8,scale*100*10):raise ValueError('Ориентиры не совпали с базой или карта слишком мелкая: ошибка '+str(round(float(error.max()),1))+' пикселей')
 return [[scale,0,float(offset[0])],[0,scale,float(offset[1])],[0,0,1]]

@dataclass(frozen=True)
class MapGoal:
 key:object
 name:str
 reference:tuple
 xyz:tuple|None=None
 live:bool=False
 air:bool=False

class MapCoordinates:
 def __init__(self,cfg):
  self.spec=cfg.get('map_mousekeys',{});self.ready=False;self.atlas=Atlas();self.allowed=set(cfg.get('target_names',DEFAULT_NAMES));self.full=full_catalogue();self.cooldown={};self.location_cooldown={}
  spec=self.spec
  if cfg.get('map_use_builtin',False) or not spec.get('reference'):
   self.builtin(cfg);return
  try:
   path=(ROOT/spec['reference']).resolve()
   if not path.is_relative_to(ROOT):return
   self.image=cv2.imread(str(path));self.matrix=np.array(spec['world_matrix'],np.float64);self.inverse=np.linalg.inv(self.matrix)
   self.zone=np.array(spec['zone'],np.float32);self.layer=spec['layer'];self.meta=self.atlas.maps[self.layer]
   if self.image is None or self.matrix.shape!=(3,3) or not np.isfinite(self.matrix).all() or len(self.zone)<3:return
   self.matcher=TerrainMatcher(self.image);self.roi=spec['roi'];self.frame_width=spec['frame_width']
   arrow=np.array(spec['arrow'],np.uint8)
   if arrow.ndim!=2 or min(arrow.shape)<10 or np.count_nonzero(arrow)<20:return
   self.arrow=ArrowLocator(arrow);self.arrow_size=spec['arrow_size'];self.ready=True
  except (KeyError,TypeError,ValueError,cv2.error,np.linalg.LinAlgError):return
 def builtin(self,cfg):
  self.layer='altgard';self.meta=self.atlas.maps[self.layer]
  self.image=cv2.imread(str(ROOT/'assets/atlas/altgard_reference.jpg'))
  if self.image is None:return
  k=self.meta['scale']*.5
  self.matrix=np.array([[k,0,self.meta['offsetX']*.5],[0,k,self.meta['offsetY']*.5],[0,0,1]],float);self.inverse=np.linalg.inv(self.matrix)
  self.native=AtlasRegistration(self.image);self.automatic=True;self.ready=True;self.zone=None
  self.farm_center=None;self.farm_radius=max(150,min(1000,float(cfg.get('map_farm_radius_m',450))))
  self.spec={'air_points':[],'builtin':True}
 def valid_layer(self,state):return self.ready and (state.map_id in self.meta.get('openZones',[]) or getattr(self,'automatic',False) and state.map_id is None)
 def inside(self,point):
  if getattr(self,'automatic',False):return self.farm_center is not None and math.dist(point,self.farm_center)<=self.farm_radius*100*self.matrix[0,0]
  return cv2.pointPolygonTest(self.zone,tuple(map(float,point)),False)>=0
 def register(self,frame):
  if getattr(self,'automatic',False):
   fix=self.native.register(frame)
   if fix is None:return None
   fix['world']=transform(fix['position'],self.inverse) if fix.get('position') is not None else None
   if self.farm_center is None and fix.get('position') is not None:self.farm_center=fix['position']
   return fix
  h,w=frame.shape[:2];x0,y0,x1,y1=[round(v*s) for v,s in zip(self.roi,(w,h,w,h))]
  crop=frame[y0:y1,x0:x1]
  if crop.size==0:return None
  reg=self.matcher.register(crop)
  if reg is None:return None
  # A game map pans/zooms; a rotated or heavily projective match is wrong.
  m=reg.matrix/mat_scale(reg.matrix)
  if abs(m[0,1])+abs(m[1,0])>max(abs(m[0,0]),abs(m[1,1]))*.12 or abs(m[2,0])+abs(m[2,1])>1e-4:return None
  m=np.array([[1,0,x0],[0,1,y0],[0,0,1]],float)@reg.matrix
  found=self.arrow.locate(crop,self.arrow_size*w/self.frame_width,threshold=.65)
  if found is None:return None
  _,px,py,rotation=found
  position=transform((px+x0,py+y0),np.linalg.inv(m))
  return dict(matrix=m,position=position,world=transform(position,self.inverse),viewport=(x0,y0,x1,y1),arrow_rotation=rotation,inliers=reg.inliers)
 def prepare(self,fix,state):
  if not getattr(self,'automatic',False):return fix
  if fix.get('position') is None and state.own is not None and getattr(state,'xyz',None) is not None and getattr(state,'position_at',None) is not None:
   age=(time.time()*1000-state.position_at)/1000
   xyz=state.xyz
   if -.1<=age<=.8 and all(math.isfinite(v) and abs(v)<1e6 for v in xyz):
    fix['world']=tuple(xyz[:2]);fix['position']=transform(xyz[:2],self.matrix);fix['position_source']='fresh_own_network'
  if fix.get('position') is not None:
   anchor=fix['position'];source=fix.get('position_source','player_arrow')
  else:
   # Nearby live resources identify a useful search area, not the player's XYZ.
   points=[];names=resource_names()
   for n in state.nodes.values():
    if n.xyz is None or not n.visible or n.used==3 or n.removed_reason==4 or names.get(n.template) not in self.allowed or n.actor in state.players or n.actor in state.npcs or n.actor in state.deaths:continue
    p=transform(n.xyz[:2],self.matrix)
    if self.pixel(MapGoal(n.actor,'',p),fix) is not None:points.append(p)
   if points:anchor=tuple(np.median(np.array(points),axis=0));source='nearby_resource_area'
   else:
    x0,y0,x1,y1=fix['viewport'];anchor=transform(((x0+x1)/2,(y0+y1)/2),np.linalg.inv(fix['matrix']));source='visible_map_area'
  fix['search_position']=anchor;fix['search_source']=source
  if self.farm_center is None:self.farm_center=anchor
  return fix
 def pixel(self,goal,fix):
  p=transform(goal.reference,fix['matrix']);x0,y0,x1,y1=fix['viewport']
  return tuple(round(v) for v in p) if x0+12<p[0]<x1-12 and y0+12<p[1]<y1-12 else None
 def goals(self,state,fix,now,allow_air=True,prefer_ether=True,camp=False,escape=False):
  if not self.valid_layer(state):return []
  self.prepare(fix,state)
  goals=[]
  if camp and not getattr(self,'automatic',False):
   p=self.spec.get('exit')
   if p:goals=[MapGoal(('exit',self.layer),'выход из лагеря',tuple(p))]
  elif escape:
   goals=[MapGoal(('air',i),'точка облёта',tuple(p),air=True) for i,p in enumerate(self.spec.get('air_points',[]))] if allow_air else []
  else:
   names={k:v for k,v in resource_names().items() if v in getattr(self,'allowed',DEFAULT_NAMES) and v in getattr(self,'active_names',getattr(self,'allowed',DEFAULT_NAMES))}
   for n in state.nodes.values():
    name=names.get(n.template)
    if (not name or not n.visible or n.used==3 or n.removed_reason==4 or n.xyz is None
        or n.actor in state.players or n.actor in state.npcs or n.actor in state.deaths):continue
    p=transform(n.xyz[:2],self.matrix)
    goal=MapGoal(('node',state.map_id,n.actor,n.generation),name,p,tuple(n.xyz),True)
    if self.inside(p) and self.cooldown.get(goal.key,0)<=now and (allow_air or 'эфир' not in name.lower()):goals.append(goal)
   if not goals:
    table=getattr(self,'full',{}).get(self.meta['table']) or self.atlas.points.get(self.meta['table'],{})
    for template,points in table.items():
     label=names.get(int(template)) if str(template).isdigit() else None
     if not label or not allow_air and 'эфир' in label.lower():continue
     for xyz in points:
      if any(n.template==int(template) and n.xyz is not None and (n.used==3 or not n.visible and n.removed_reason==4)
             and math.dist(n.xyz,xyz)<200 for n in state.nodes.values()):continue
      p=transform(xyz[:2],self.matrix)
      if self.inside(p):goals.append(MapGoal(('spawn',template,*xyz[:2]),label,p,tuple(xyz),False))
  goals=[g for g in goals if self.cooldown.get(g.key,0)<=now and not any(t>now and math.dist(g.reference,p)<max(4,abs(self.matrix[0,0])*300) for p,t in getattr(self,'location_cooldown',{}).items()) and self.pixel(g,fix) is not None]
  def score(g):
   preferred=0 if not prefer_ether or 'эфир' in g.name.lower() else 1
   return (preferred,math.dist(g.reference,fix.get('search_position') or fix['position']))
  return sorted(goals,key=score)
 def defer(self,goal,now,seconds=60):
  if goal:
   self.cooldown[goal.key]=now+seconds
   if not hasattr(self,'location_cooldown'):self.location_cooldown={}
   self.location_cooldown[tuple(goal.reference)]=now+seconds
  self.location_cooldown={p:t for p,t in getattr(self,'location_cooldown',{}).items() if t>now}
  self.cooldown={k:t for k,t in self.cooldown.items() if t>now}

def mat_scale(matrix):
 value=float(matrix[2,2]);return value if abs(value)>1e-9 else 1.
