"""Regression for the user's MAP_SETUP_REQUIRED -> old sideways patrol log."""
from pathlib import Path
from types import SimpleNamespace
from dataclasses import replace
from unittest.mock import patch
import json,unittest,hashlib,math
import cv2,numpy as np
from autopath_profile import effective,REQUIRED,RECOMMENDED
from map_coordinates import MapCoordinates
from atlas_registration import AtlasRegistration
from navigation import Drive
from flight import FlightReading
from map_mousekeys import Dispatch
import test_map_autopath44 as oldmap
import test_hybrid as fx

ROOT=Path(__file__).resolve().parent

class Settings(unittest.TestCase):
 def test_old_checked_patrol_and_directml_are_disabled_when_map_mode_is_selected(self):
  cfg=effective(dict(map_mousekeys_enabled=True,map_autopath_required=True,scene_navigation_enabled=True,analyzer_enabled=True,ground_walk=True,patrol_sprint=True,post_tp_back_exit_enabled=True))
  for k,v in REQUIRED.items():self.assertEqual(cfg[k],v,k)
 def test_default_archive_is_ready_for_map_mode_without_manual_reference(self):
  cfg=json.loads((ROOT/'settings_gather.json').read_text());self.assertTrue(cfg['map_mousekeys_enabled']);self.assertTrue(cfg['only_aether'])
  for k,v in REQUIRED.items():self.assertEqual(cfg[k],v,k)
  c=MapCoordinates(cfg);self.assertTrue(c.ready);self.assertTrue(c.automatic)
 def test_ui_normalizes_old_settings_before_starting_an_engine(self):
  import app,tempfile
  with tempfile.TemporaryDirectory() as directory:
   config=Path(directory)/'settings_gather.json';config.write_text(json.dumps({'map_mousekeys_enabled':True,'ground_walk':True,'scene_navigation_enabled':True,'patrol_sprint':True,'map_mousekeys':{}}))
   with patch.object(app,'CONF',config):cfg=app.read_config()
   self.assertFalse(cfg['ground_walk']);self.assertFalse(cfg['scene_navigation_enabled']);self.assertFalse(cfg['patrol_sprint']);self.assertTrue(cfg['map_use_builtin'])
 def test_live_gem_cannot_hide_static_ether_when_gem_gathering_is_not_allowed(self):
  import test_map_coordinates44 as geometry
  from network_state import Node
  f=geometry.ResourceChoice('test_static_spawn_is_explicitly_not_proof_of_liveness');f.setUp()
  try:
   f.c.active_names={'Эфир'};f.s.nodes[8]=Node(8,2,xyz=(0,10000,0),used=0,generation=1)
   goals=f.c.goals(f.s,f.fix,100);self.assertTrue(goals);self.assertTrue(all(g.name=='Эфир' for g in goals))
  finally:f.doCleanups()
 def test_old_mode_is_still_explicitly_available(self):
  cfg=effective(dict(map_mousekeys_enabled=False,ground_walk=True,scene_navigation_enabled=True));self.assertTrue(cfg['ground_walk']);self.assertTrue(cfg['scene_navigation_enabled'])
 def test_effective_engine_does_not_load_models_for_map_navigation(self):
  f=fx.HybridEngineCases('test_busy_broken_or_disabled_advisor_does_not_gate_actual_stick_motion');f.setUp()
  try:
   from hybrid_engine import HybridGatherEngine
   cfg={**f.e.cfg,**RECOMMENDED,'isolate_vision_processes':False,'responsive_control':False}
   e=HybridGatherEngine(cfg,lambda s:None,None,network=f.source)
   self.assertIsNone(e.scene_host);self.assertIsNone(e.analyzer);self.assertTrue(e.map_autopath.enabled)
  finally:f.doCleanups();f.tearDown()

class StrictTravel(unittest.TestCase):
 def setUp(self):
  self.f=oldmap.Travel('test_full_map_click_close_travel_and_two_near_samples');self.f.setUp();self.addCleanup(self.f.doCleanups)
  self.e=self.f.e;self.p=self.f.path;self.e.cfg['map_autopath_required']=True;self.e.bridge.controller_native=True
 def test_recorded_missing_setup_case_cannot_fall_back_to_sideways_patrol(self):
  self.p.coordinates.ready=False
  self.assertTrue(self.f.tick());self.assertIsNone(self.p.run);self.assertEqual(self.f.f.pad.axes,(0,0,0,0))
  self.assertTrue(any('MAP_WAIT' in s for s in self.f.f.log))
 def test_missing_lua_cannot_start_old_patrol(self):
  self.p.transport.ready=False;self.p.transport.ack=False
  self.assertTrue(self.f.tick());self.assertIsNone(self.p.run);self.assertEqual(self.f.f.pad.axes,(0,0,0,0))
 def test_retry_delay_cannot_start_old_patrol(self):
  self.p.next_at=110;self.assertTrue(self.f.tick(100));self.assertIsNone(self.p.run)
 def test_visual_handoff_uses_gathering_search_but_blocks_navigation_drive(self):
  self.p.visual_until=108;self.p.next_at=108;self.assertFalse(self.f.tick(101))
  self.assertFalse(self.e._motion(Drive(.8,.5,.4)));self.assertEqual(self.f.f.pad.axes,(0,0,0,0))
 def test_old_scene_planner_cannot_propose_a_wall_detour_in_map_mode(self):
  from test_navigation import radar
  d=self.e._scene_plan(self.f.picture,radar(),FlightReading(None,False),Drive(.8,.5,.4),100)
  self.assertEqual((d.forward,d.strafe,d.yaw),(0,0,0))
 def test_latched_resource_is_not_starved_when_visual_window_expires(self):
  self.p.visual_until=90;self.e.caption_latch={'candidate':'Эфир'}
  self.assertFalse(self.f.tick(100));self.assertIsNone(self.p.run)
 def test_pitch_restore_can_finish_before_a_new_map_route(self):
  with patch.object(self.e.pitch,'returning',True):self.assertFalse(self.f.tick(100))
  self.assertIsNone(self.p.run)
 def test_direct_old_stick_report_is_blocked_during_visual_handoff(self):
  self.e.gamepad.drive(.8,.5,0,0,lifetime=.1);self.assertEqual(self.f.f.pad.axes,(0,0,0,0))
 def test_explicit_stop_still_cancels_game_path_under_strict_translation_gate(self):
  self.f.activate();self.p.stop(self.e);self.assertIsNone(self.p.run)
  self.assertTrue(any(y<0 for x,y in self.f.axes))
 def test_map_candidates_follow_ether_priority_with_unknown_energy(self):
  self.e.policy.priority=True;self.e.budget.energy=None
  self.f.tick(100);self.f.tick(101);self.assertEqual(self.p.coordinates.active_names,{'Эфир'})
 def test_low_energy_switches_map_candidates_to_collectible_ground_resources(self):
  self.e.policy.priority=True;self.e.budget.energy=10
  self.f.tick(100);self.f.tick(101);self.assertNotIn('Эфир',self.p.coordinates.active_names);self.assertIn('Алмаз',self.p.coordinates.active_names)
 def test_resource_hold_prevents_new_map_click_without_losing_collection(self):
  self.e.resource_hold=True;self.assertFalse(self.f.tick());self.assertTrue(self.e.resource_hold);self.assertEqual(self.p.transport.maps,0)
 def test_unknown_own_id_does_not_require_an_old_self_coordinate_for_map_click(self):
  self.f.f.source.state.own=None;self.assertTrue(self.f.tick());self.assertIsNotNone(self.p.run)
  self.f.f.source.state.own=7;self.f.tick();self.assertEqual(self.p.run.owner,7)
 def test_unknown_flight_energy_does_not_exclude_ether_as_a_destination(self):
  self.e.budget.energy=None;self.p.coordinates.goal=replace(self.p.coordinates.goal,name='Эфир')
  seen=[];old=self.p.coordinates.goals
  self.p.coordinates.goals=lambda *a:(seen.append(a[3]),old(*a))[1]
  self.f.tick(100);self.f.tick(101);self.assertEqual(seen,[True]);self.assertEqual(self.p.run.goal.name,'Эфир');self.assertFalse(self.p.run.pending_air)
 def test_post_teleport_uses_map_after_loading_without_backward_macro(self):
  self.e._map_teleport_arrived(SimpleNamespace(used=True,destination='Рабочий лагерь стального молота'),100)
  self.assertTrue(self.p.force_camp);self.assertEqual(self.p.next_at,103.5);self.assertIsNone(self.e.post_tp_exit)
  self.assertEqual(self.f.f.pad.axes,(0,0,0,0));self.assertTrue(self.f.tick(102));self.assertIsNone(self.p.run)
 def test_preflight_requires_new_lua_ack(self):
  self.p.transport.ack=False
  with patch.object(self.e,'_focus_ok',return_value=True):self.assertFalse(self.e._preflight_receiver())
 def test_confirmed_arrival_provides_eight_seconds_for_visual_collection(self):
  run=self.f.activate('CLOSE');run.finishing=True;run.pending_air=False
  self.f.tick(101);self.assertEqual(self.p.visual_until,109);self.assertEqual(self.p.next_at,109)
  self.assertFalse(self.f.tick(102));self.assertIsNone(self.p.run)

class BuiltinMap(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cv2.setNumThreads(1);cls.c=MapCoordinates({});cls.image=cls.c.image
 def setUp(self):self.c.native.arrow_after=0
 def picture(self,scale=1.6,shift=(0,0),arrow=True):
  frame=np.full((1152,2048,3),50,np.uint8);x0,y0,x1,y1=461,132,1976,1048;w,h=x1-x0,y1-y0
  m=np.float32([[scale,0,w/2-2680*scale+shift[0]],[0,scale,h/2-2260*scale+shift[1]]])
  crop=cv2.warpAffine(self.image,m,(w,h))
  if arrow:
   tpl=self.c.native.arrow.template;crop[h//2-32:h//2+32,w//2-32:w//2+32][tpl>128]=250
  frame[y0:y1,x0:x1]=crop;return frame
 def test_built_in_image_and_precomputed_features_have_matching_provenance(self):
  with np.load(ROOT/'assets/atlas/altgard_features.npz',allow_pickle=False) as f:
   self.assertEqual(str(f['image_sha256']),hashlib.sha256((ROOT/'assets/atlas/altgard_reference.jpg').read_bytes()).hexdigest());self.assertEqual(f['descriptors'].shape[1],128)
 def test_real_altgard_terrain_locates_player_without_three_manual_anchors(self):
  fix=self.c.register(self.picture());self.assertIsNotNone(fix);self.assertGreater(fix['inliers'],100)
  self.assertLess(math.dist(fix['position'],(2680,2260)),2)
 def test_zoom_and_pan_recompute_map_projection(self):
  fix=self.c.register(self.picture(1.15,(50,-40)));self.assertIsNotNone(fix)
  expected=(2680-50/1.15,2260+40/1.15);self.assertLess(math.dist(fix['position'],expected),2)
 def test_late_pan_cannot_reuse_old_transform(self):
  a=self.c.register(self.picture());b=self.c.register(self.picture(1.6,(30,0)))
  self.assertGreater(math.dist(a['position'],b['position']),17)
 def test_missing_arrow_keeps_terrain_projection_without_inventing_own_position(self):
  fix=self.c.register(self.picture(arrow=False));self.assertIsNotNone(fix);self.assertIsNone(fix['position']);self.assertIsNone(fix['world'])
 def test_unknown_zone_is_allowed_only_with_built_in_image_proof(self):
  self.assertTrue(self.c.valid_layer(SimpleNamespace(map_id=None)));self.assertFalse(self.c.valid_layer(SimpleNamespace(map_id=1010)))
 def test_visited_farm_center_does_not_drift_with_each_target(self):
  self.c.register(self.picture());center=self.c.farm_center;self.c.register(self.picture(1.6,(30,0)))
  self.assertEqual(center,self.c.farm_center);self.assertFalse(self.c.inside((center[0]+1000,center[1])))
 def test_blank_or_wrong_map_has_no_coordinate_fix(self):self.assertIsNone(self.c.register(np.full((1152,2048,3),50,np.uint8)))

if __name__=='__main__':unittest.main()
