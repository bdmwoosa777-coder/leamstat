"""Map Lua wire v2: Caps data / Scroll clock. Num Lock is never transmitted.

Num Lock can be the game's autorun key. Windows Mouse Keys must be enabled
and Num Lock already ON; neither Python nor Lua may change it during a route.
"""
import time
from bridge import GHubBridge

COMMANDS={'PING':0,'RIGHT_STEP':1,'MAP':2,'JUMP':3}

def map_codes(name):
 value=COMMANDS[name];hi=value>>1;lo=value&1
 return [0,1,0,hi,lo,hi^lo]

class MapKeyWire(GHubBridge):
 protocol='map-caps-scroll-v2'
 def send(self,command,authorize=None):
  bits=map_codes(command)
  with self.lock:
   def permitted():
    try:return authorize is None or bool(authorize())
    except Exception:return False
   if not permitted():return False
   if self.dry_run:
    self.sent.append((time.monotonic(),command,bits));return True
   if not self.win.GetKeyState(144)&1:return False
   cancelled=False;last_edge=None
   for index,bit in enumerate(bits):
    # Abort before the last bit by sending an invalid parity. A stalled
    # partial frame times out in Lua; it must not become a different command.
    if index==len(bits)-1 and (not permitted() or last_edge is not None and time.monotonic()-last_edge>.5):
     bit^=1;cancelled=True
    self._toggle(145,False);self._toggle(20,bool(bit));time.sleep(.018)
    if index==len(bits)-1 and not cancelled and (not permitted() or last_edge is not None and time.monotonic()-last_edge>.7):
     bit^=1;cancelled=True;self._toggle(20,bool(bit))
    self._toggle(145,True);last_edge=time.monotonic();time.sleep(.078)
    self._toggle(145,False);time.sleep(.040)
   self.last_sent_at=time.monotonic()
   self.log('MAP_WIRE_V2: '+command+('; отменено до исполнения' if cancelled else '; передан кадр; Num Lock не изменялся'))
   return not cancelled
 def restore_locks(self):
  if self.dry_run:return
  with self.lock:
   self._toggle(145,False)
   if self._saved is not None:self._toggle(20,self._saved[20])
   # Keep clock low. Do not restore Num Lock by pressing an in-game hotkey.
