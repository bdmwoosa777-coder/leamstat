"""Actual terrain + live XYZ must reach cursor/RMB without a player arrow."""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import math,unittest
import cv2,numpy as np
from map_coordinates import MapCoordinates,MapGoal
from map_reference import transform
from network_state import Flow,Node
from auto_route_hud import AutoRouteHUD
import test_map_autopath44 as legacy

ROOT=Path(__file__).resolve().parent

def picture(c):
 frame=np.full((1152,2048,3),50,np.uint8);x0,y0,x1,y1=461,132,1976,1048;w,h=x1-x0,y1-y0
 matrix=np.float32([[1.6,0,w/2-2680*1.6],[0,1.6,h/2-2260*1.6]])
 frame[y0:y1,x0:x1]=cv2.warpAffine(c.image,matrix,(w,h))
 for a,b,x,y in ((.01,.06,.025,.24),(.067,.105,.35,.44)):frame[round(1152*a):round(1152*b),round(2048*x):round(2048*y)]=210
 return frame

def state():return Flow(own=7,map_id=1110)

class WithoutArrow(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cv2.setNumThreads(1);cls.c=MapCoordinates({});cls.frame=picture(cls.c)
 def setUp(self):
  self.c.native.arrow_after=0;self.c.farm_center=None;self.s=state()
 def test_real_terrain_remains_valid_when_arrow_detector_fails(self):
  with patch.object(self.c.native,'player',return_value=None):fix=self.c.register(self.frame)
  self.assertIsNotNone(fix);self.assertIsNone(fix['position']);self.assertIsNone(fix['world']);self.assertGreater(fix['inliers'],100)
 def test_live_xyz_can_be_projected_without_own_coordinates(self):
  with patch.object(self.c.native,'player',return_value=None):fix=self.c.register(self.frame)
  world=transform((2700,2270),self.c.inverse);self.s.nodes[99]=Node(99,1550000,xyz=(*world,12000),used=0,generation=1)
  goals=self.c.goals(self.s,fix,100);self.assertTrue(goals);self.assertTrue(goals[0].live)
  pixel=self.c.pixel(goals[0],fix);self.assertLess(math.dist(pixel,(1250,606)),3)
  self.assertIsNone(fix['world']);self.assertEqual(fix['search_source'],'nearby_resource_area')
 def test_static_visible_area_works_without_any_live_nodes_or_arrow(self):
  with patch.object(self.c.native,'player',return_value=None):fix=self.c.register(self.frame)
  goals=self.c.goals(self.s,fix,100);self.assertTrue(goals);self.assertTrue(all(not g.live for g in goals))
  self.assertEqual(fix['search_source'],'visible_map_area');self.assertIsNone(fix['world'])
 def test_fresh_own_network_position_can_replace_arrow_but_is_labeled(self):
  with patch.object(self.c.native,'player',return_value=None):fix=self.c.register(self.frame)
  self.s.xyz=(124592,47767,0);self.s.position_at=1000000
  with patch('map_coordinates.time.time',return_value=1000.3):self.c.prepare(fix,self.s)
  self.assertEqual(fix['world'],(124592,47767));self.assertEqual(fix['position_source'],'fresh_own_network')
 def test_stale_network_position_is_never_used_as_current_own_position(self):
  with patch.object(self.c.native,'player',return_value=None):fix=self.c.register(self.frame)
  self.s.xyz=(1,2,3);self.s.position_at=1000000
  with patch('map_coordinates.time.time',return_value=1001):self.c.prepare(fix,self.s)
  self.assertIsNone(fix['position']);self.assertIsNone(fix['world'])
 def test_position_without_own_identity_remains_unknown(self):
  with patch.object(self.c.native,'player',return_value=None):fix=self.c.register(self.frame)
  self.s.own=None;self.s.xyz=(1,2,3);self.s.position_at=1000000
  with patch('map_coordinates.time.time',return_value=1000.3):self.c.prepare(fix,self.s)
  self.assertIsNone(fix['world'])
 def test_resource_area_is_not_reported_as_character_position(self):
  with patch.object(self.c.native,'player',return_value=None):fix=self.c.register(self.frame)
  world=transform((2700,2270),self.c.inverse);self.s.nodes[99]=Node(99,1550000,xyz=(*world,12000),used=0)
  self.c.prepare(fix,self.s);self.assertIsNotNone(fix['search_position']);self.assertIsNone(fix['position']);self.assertIsNone(fix['world'])
 def test_unknown_arrow_does_not_bypass_missing_terrain(self):
  with patch.object(self.c.native,'terrain',return_value=None):self.assertIsNone(self.c.register(self.frame))
 def test_invisible_or_depleted_live_node_is_not_a_live_destination(self):
  with patch.object(self.c.native,'player',return_value=None):fix=self.c.register(self.frame)
  world=transform((2700,2270),self.c.inverse);self.s.nodes[99]=Node(99,1550000,xyz=(*world,12000),used=3)
  self.assertTrue(all(not g.live for g in self.c.goals(self.s,fix,100)))
 def test_wrong_zone_cannot_use_altgard_projection(self):
  with patch.object(self.c.native,'player',return_value=None):fix=self.c.register(self.frame)
  self.s.map_id=1010;self.assertEqual(self.c.goals(self.s,fix,100),[])
 def test_optional_arrow_failure_is_not_repeated_for_each_preclick_frame(self):
  with patch.object(self.c.native,'player',return_value=None) as player:
   self.c.register(self.frame);self.c.register(self.frame);self.c.register(self.frame)
   self.assertEqual(player.call_count,1)

class Controller(unittest.TestCase):
 def setUp(self):
  self.f=legacy.Travel('test_full_map_click_close_travel_and_two_near_samples');self.f.setUp();self.addCleanup(self.f.doCleanups)
  self.p=self.f.path;self.e=self.f.e;self.e.cfg['map_autopath_required']=True
 def test_missing_arrow_does_not_prevent_cursor_and_single_rmb_to_live_resource(self):
  c=MapCoordinates({});self.p.coordinates=c;self.f.picture=picture(c);self.f.f.source.state.map_id=1110
  xyz=transform((2700,2270),c.inverse);self.f.f.source.state.nodes={99:Node(99,1550000,xyz=(*xyz,12000),used=0,generation=1)}
  with patch.object(c.native,'player',return_value=None):
   self.f.tick(100);self.f.tick(101);self.assertEqual(self.p.run.phase,'CLICK');self.assertTrue(self.p.run.goal.live)
   self.f.tick(102);self.assertEqual(self.p.transport.clicks,1);self.assertTrue(self.f.f.positions)
   self.assertLess(math.dist(self.f.f.positions[-1],(1250,606)),3);self.assertIsNone(self.p.run.fix['world'])
   self.f.tick(103);self.f.tick(104);self.assertEqual(self.p.run.phase,'TRAVEL')
   self.f.hud=AutoRouteHUD(True,2);self.f.tick(105);self.f.tick(106);self.f.tick(107)
  self.assertIsNone(self.p.run);self.assertEqual(self.p.transport.clicks,1)
 def test_periodic_map_check_does_not_require_own_position(self):
  run=self.f.activate('CHECK_MAP');self.f.opened=True;run.map_open=True
  self.p.coordinates.fix['world']=None;self.p.coordinates.fix['position']=None
  self.f.tick(101);self.assertEqual(run.phase,'CLOSE');self.assertFalse(run.finishing)
 def test_banner_disappeared_without_own_position_hands_off_to_visual_search(self):
  run=self.f.activate('CHECK_MAP');self.f.opened=True;run.map_open=True;run.hud_seen=True;run.missing=3
  self.p.coordinates.fix['world']=None;self.p.coordinates.fix['position']=None
  self.f.tick(101);self.assertTrue(run.finishing);self.assertFalse(run.failed);self.assertIn('позицию не измеряю',run.result)
 def test_unknown_own_position_uses_game_measured_distance_for_one_flight_upgrade(self):
  run=self.f.activate();run.straight=0;self.f.hud=AutoRouteHUD(True,140)
  self.f.tick(101);self.assertEqual(run.phase,'WINGS');self.assertEqual(run.switches,1)
 def test_short_game_measured_distance_does_not_open_wings(self):
  run=self.f.activate();run.straight=0;self.f.hud=AutoRouteHUD(True,25)
  self.f.tick(101);self.assertEqual(run.phase,'TRAVEL');self.assertEqual(run.switches,0)
 def test_flight_upgrade_can_be_disabled_for_unknown_position(self):
  run=self.f.activate();run.straight=0;self.e.cfg['map_mousekeys_fly_long']=False;self.f.hud=AutoRouteHUD(True,140)
  self.f.tick(101);self.assertEqual(run.phase,'TRAVEL')
 def test_no_live_or_own_position_can_still_click_a_static_spawn_from_real_terrain(self):
  c=MapCoordinates({});self.p.coordinates=c;self.f.picture=picture(c);self.f.f.source.state.map_id=1110;self.f.f.source.state.nodes={}
  with patch.object(c.native,'player',return_value=None):self.f.tick(100);self.f.tick(101);self.f.tick(102)
  self.assertEqual(self.p.transport.clicks,1);self.assertFalse(self.p.run.goal.live);self.assertIsNone(self.p.run.fix['world'])

if __name__=='__main__':unittest.main()
