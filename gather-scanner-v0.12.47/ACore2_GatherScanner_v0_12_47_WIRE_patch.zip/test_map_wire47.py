"""Actual Python sender + actual Lua, joined by a simulated Windows keyboard.

Unlike a canned ACK, Caps acknowledgements here originate in the real Lua.
The simulated game binds Num Lock to autorun to reproduce the interference.
"""
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import threading,unittest
from lupa import LuaRuntime
from map_key_wire import MapKeyWire,map_codes
from bridge import GHubBridge
from map_mousekeys import MapMouseKeys
import test_map_autopath44 as fx
from auto_route_hud import AutoRouteHUD

ROOT=Path(__file__).parent
class Link:
 def __init__(self,legacy=False):
  self.now=0.;self.flags={20:False,144:True,145:False};self.held=set();self.events=[];self.autorun=False;self.route=False;self.map=False;self.right=False;self.lua_logs=[]
  self.lua=LuaRuntime();g=self.lua.globals()
  g.GetRunningTime=lambda:self.now*1000
  g.IsKeyLockOn=lambda k:self.flags[{'capslock':20,'numlock':144,'scrolllock':145}[k]]
  g.PressKey=self.lua_press;g.ReleaseKey=lambda k:self.release(k)
  g.OutputLogMessage=lambda *a:self.lua_logs.append(a)
  g.Sleep=self.lua.eval('function(ms) coroutine.yield(ms) end')
  path=ROOT/'GHUB_MAP_MOUSEKEYS.lua' if not legacy else ROOT/'HISTORY_v0_12_46_GHUB_MAP_MOUSEKEYS.lua'
  self.lua.execute(path.read_text())
  self.co=self.lua.eval('function() OnEvent("MOUSE_BUTTON_PRESSED",9) end').coroutine()
  self.due=0.;self.advance(.025)
  wire=MapKeyWire.__new__(MapKeyWire);wire.dry_run=False;wire.lock=threading.RLock();wire.log=lambda _:None;wire.sent=[];wire._saved=dict(self.flags)
  wire.win=SimpleNamespace(GetKeyState=lambda k:int(self.flags[k]),keybd_event=self.keyboard)
  self.wire=wire;self.tr=MapMouseKeys(wire=wire,enabled=lambda:True)
 def press(self,k):
  self.events.append((self.now,'down',k));self.held.add(k)
  key={'capslock':20,'numlock':144,'scrolllock':145}.get(k,k)
  if key in self.flags:self.flags[key]=not self.flags[key]
  if key==144:self.autorun=not self.autorun;self.route=False
  if k=='m':self.map=not self.map
  if k=='numminus':self.right=True
  if k=='num5' and self.flags[144] and self.right and self.map:self.route=True;self.autorun=False
 def release(self,k):self.held.discard(k);self.events.append((self.now,'up',k))
 def lua_press(self,k):self.press(k)
 def keyboard(self,key,scan,flags,extra):self.release(key) if flags&2 else self.press(key)
 def advance(self,seconds):
  target=self.now+seconds
  while self.due<=target:
   self.now=self.due
   delay=next(self.co);self.due=self.now+delay/1000
  self.now=target
 def clock(self):return self.now
 def patch(self):
  return patch.multiple('time',monotonic=self.clock,sleep=self.advance)

class WireRoundTrip(unittest.TestCase):
 def test_real_sender_receiver_click_close_keeps_game_route_and_numlock(self):
  link=Link()
  with link.patch():
   self.assertTrue(link.tr.ping(lambda:True).acknowledged)
   self.assertTrue(link.tr.map_toggle(lambda:True).acknowledged);self.assertTrue(link.map)
   self.assertTrue(link.tr.click(lambda:link.map).acknowledged);self.assertTrue(link.route)
   self.assertTrue(link.tr.map_toggle(lambda:True).acknowledged);self.assertFalse(link.map)
   link.tr.close()
  self.assertTrue(link.route);self.assertFalse(link.autorun);self.assertTrue(link.flags[144])
  self.assertFalse(any(k in (144,'numlock') for _,_,k in link.events));self.assertFalse(link.held)
  self.assertEqual(sum(a=='down' and k=='num5' for _,a,k in link.events),1)
 def test_previous_sender_reproduces_numlock_autorun_interference(self):
  link=Link(legacy=True)
  with link.patch():GHubBridge.send(link.wire,'PING')
  self.assertTrue(any(a=='down' and k==144 for _,a,k in link.events))
 def test_numlock_off_is_rejected_without_turning_it_on(self):
  link=Link();link.flags[144]=False
  with link.patch():r=link.tr.ping(lambda:True)
  self.assertFalse(r.attempted);self.assertFalse(link.flags[144]);self.assertEqual(link.events,[])
 def test_old_lua_cannot_pass_new_preflight(self):
  link=Link(legacy=True)
  with link.patch():r=link.tr.ping(lambda:True)
  self.assertFalse(r.acknowledged);self.assertFalse(link.tr.ready)
  self.assertFalse(any(k in ('num5','m','f') for _,a,k in link.events if a=='down'))
 def test_repeat_commands_do_not_leave_a_partial_frame(self):
  link=Link()
  with link.patch():
   for _ in range(3):
    self.assertTrue(link.tr.ping(lambda:True).acknowledged)
    self.assertTrue(link.tr.map_toggle(lambda:True).acknowledged)
  self.assertTrue(link.map);self.assertFalse(link.held);self.assertFalse(link.autorun)
 def test_revoked_checksum_does_not_dispatch_or_ack(self):
  link=Link()
  with link.patch():
   self.assertTrue(link.tr.ping(lambda:True).acknowledged)
   start=link.now
   r=link.tr.map_toggle(lambda:link.now-start<.8)
   link.advance(.4)
  self.assertFalse(r.attempted);self.assertFalse(link.map)
 def test_revoked_click_during_numeric_delay_never_presses_num5(self):
  link=Link()
  with link.patch():
   self.assertTrue(link.tr.ping(lambda:True).acknowledged)
   self.assertTrue(link.tr.map_toggle(lambda:True).acknowledged)
   # Revoke after final checksum, while Lua waits between Num- and Num5.
   r=link.tr.click(lambda:not any(k=='numminus' for _,a,k in link.events if a=='down'))
   link.advance(.2)
  self.assertTrue(r.attempted);self.assertFalse(r.acknowledged);self.assertFalse(link.route)
  self.assertFalse(any(k=='num5' for _,a,k in link.events if a=='down'))
 def test_wire_has_four_distinct_valid_frames_and_no_legacy_commands(self):
  self.assertEqual(len({tuple(map_codes(n)) for n in ('PING','RIGHT_STEP','MAP','JUMP')}),4)
  for n in ('W_STEP','F_ON','V','ATTACK_PAIR','STOP'):
   with self.assertRaises(KeyError):map_codes(n)
 def test_ack_occurs_only_after_numeric_key_release(self):
  link=Link()
  with link.patch():
   link.tr.ping(lambda:True);link.tr.map_toggle(lambda:True);link.tr.click(lambda:True)
  released=next(t for t,a,k in link.events if a=='up' and k=='num5')
  ack=next(t for t,a,k in link.events if t>=released and a=='down' and k=='capslock')
  self.assertGreaterEqual(ack,released)

class FailureMotion(unittest.TestCase):
 def setUp(self):
  self.f=fx.Travel('test_full_map_click_close_travel_and_two_near_samples');self.f.setUp()
  self.addCleanup(self.f.doCleanups);self.addCleanup(self.f.tearDown)
 def test_unconfirmed_click_failure_never_twitches_left_stick(self):
  run=self.f.activate();run.failed=True;run.result='нет игрового подтверждения';run.hud_seen=False
  self.f.path.finish(self.f.e,101)
  self.assertFalse(any(a!=(0,0) for a in self.f.axes))
 def test_confirmed_stalled_route_is_cancelled_with_short_motion(self):
  run=self.f.activate();run.failed=True;run.hud_seen=True
  self.f.path.finish(self.f.e,101)
  self.assertTrue(any(y<0 for x,y in self.f.axes))

if __name__=='__main__':unittest.main()
