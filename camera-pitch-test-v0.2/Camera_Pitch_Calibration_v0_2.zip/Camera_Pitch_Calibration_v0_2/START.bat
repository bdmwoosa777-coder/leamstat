@echo off
setlocal
cd /d "%~dp0"
python camera_calibration.py
if errorlevel 1 pause
