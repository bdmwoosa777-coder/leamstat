import threading,time,unittest
from gamepad_input import GamepadInput
from pulse_test import CASES,PulseTester


class Pad:
    def __init__(self):self.axes=(0,0,0,0);self.reports=[]
    def reset(self):self.axes=(0,0,0,0)
    def update(self):self.reports.append(self.axes)
    def left_joystick_float(self,x_value_float,y_value_float):self.axes=(x_value_float,y_value_float,*self.axes[2:])
    def right_joystick_float(self,x_value_float,y_value_float):self.axes=(*self.axes[:2],x_value_float,y_value_float)
    def press_button(self,button):raise AssertionError('Calibration must never press buttons')


class PulseTests(unittest.TestCase):
    def setUp(self):
        self.pad=Pad();self.input=GamepadInput(factory=lambda:self.pad,a_button=1);self.test=PulseTester(self.input)
    def tearDown(self):self.test.close()

    def test_each_case_is_one_stationary_camera_pulse_and_releases(self):
        for name,strength,seconds in CASES:
            result=self.test.pulse(-strength,seconds,lambda:True)
            self.assertTrue(result.completed);self.assertIsNotNone(result.delivered_ms)
            self.assertGreater(result.delivered_ms,seconds*1000-15)
            self.assertLess(result.delivered_ms,seconds*1000+80)
            self.assertEqual(self.pad.axes,(0,0,0,0))
        self.assertTrue(all(report[:3]==(0,0,0) for report in self.pad.reports))

    def test_unfocused_game_gets_no_nonzero_input(self):
        result=self.test.pulse(-.45,.1,lambda:False)
        self.assertFalse(result.completed);self.assertIsNone(result.delivered_ms)
        self.assertTrue(all(r==(0,0,0,0) for r in self.pad.reports))

    def test_focus_loss_releases_a_running_pulse(self):
        until=time.monotonic()+.04
        result=self.test.pulse(-.45,.3,lambda:time.monotonic()<until)
        self.assertFalse(result.completed);self.assertLess(result.delivered_ms,150)
        self.assertEqual(self.pad.axes,(0,0,0,0))

    def test_stop_cancels_and_next_manual_test_can_run(self):
        results=[];worker=threading.Thread(target=lambda:results.append(self.test.pulse(-.45,.4,lambda:True)))
        worker.start();time.sleep(.04);self.test.cancel();worker.join(1)
        self.assertFalse(worker.is_alive());self.assertFalse(results[0].completed)
        self.assertEqual(self.pad.axes,(0,0,0,0))
        self.assertTrue(self.test.pulse(.35,.05,lambda:True).completed)

    def test_unsafe_duration_or_strength_is_rejected_before_delivery(self):
        for strength,seconds in ((.45,2),(.9,.1),(.45,-1),(0,.1)):
            with self.assertRaises(ValueError):self.test.pulse(strength,seconds,lambda:True)
        self.assertTrue(all(r==(0,0,0,0) for r in self.pad.reports))


if __name__=='__main__':unittest.main()
