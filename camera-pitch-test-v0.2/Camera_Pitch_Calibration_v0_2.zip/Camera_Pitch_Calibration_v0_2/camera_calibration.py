# -*- coding: utf-8 -*-
"""Manual camera calibration from the upper/lower mechanical view limit."""
import csv,json,os,queue,threading,time
from dataclasses import asdict
from pathlib import Path
import tkinter as tk
from tkinter import ttk,messagebox
from pulse_test import CASES,PulseTester
from screen_capture import ScreenCapture
from win_hotkeys import SystemHotkeys

ROOT=Path(__file__).resolve().parent


class UI:
    def __init__(self):
        self.root=tk.Tk();self.root.title('Camera Pitch Calibration v0.2 — от верхнего предела вниз')
        self.root.geometry('1020x850');self.q=queue.Queue();self.stop_event=threading.Event()
        self.tester=None;self.worker=None;self.closing=False;self.last=None;self.rows=[]
        self.screen=ScreenCapture();self.sessions=ROOT/'results';self.sessions.mkdir(exist_ok=True)
        self.session=time.strftime('%Y%m%d_%H%M%S');self.csv_path=self.sessions/(self.session+'.csv')
        ttk.Label(self.root,text='Перед КАЖДЫМ тестом: стойте на земле, вручную поднимите камеру до самого верха.',
                  font=('',12,'bold'),wraplength=980).pack(anchor='w',padx=12,pady=8)
        ttk.Label(self.root,text='Затем Ctrl+F8: один импульс вниз. Посмотрите, взгляд выше горизонта, примерно на нём или ниже.\n'
                  'Другие сканеры закройте; чувствительность, режим камеры и масштаб между тестами не меняйте.',
                  wraplength=980).pack(anchor='w',padx=12)
        bar=ttk.Frame(self.root,padding=10);bar.pack(fill='x')
        ttk.Button(bar,text='Подключить виртуальный Xbox',command=self.connect).pack(side='left',padx=3)
        ttk.Label(bar,text='Исходное положение:').pack(side='left',padx=8)
        self.baseline=tk.StringVar(value='Верхний предел → вниз')
        ttk.Combobox(bar,textvariable=self.baseline,values=['Верхний предел → вниз','Нижний предел → вверх'],
                     width=27,state='readonly').pack(side='left')
        self.invert=tk.BooleanVar(value=False)
        ttk.Checkbutton(bar,text='Инвертировать Y',variable=self.invert).pack(side='left',padx=8)
        self.tree=ttk.Treeview(self.root,columns=('n','strength','duration'),show='headings',height=8,selectmode='browse')
        for col,title in [('n','Тест'),('strength','Сила правого стика'),('duration','Длительность')]:
            self.tree.heading(col,text=title);self.tree.column(col,width=220,anchor='center')
        for name,strength,seconds in CASES:self.tree.insert('',tk.END,iid=name,values=(name,strength,f'{seconds*1000:.0f} мс'))
        self.tree.pack(fill='x',padx=12,pady=8);self.tree.selection_set('10')
        buttons=ttk.Frame(self.root,padding=8);buttons.pack(fill='x')
        ttk.Button(buttons,text='Один тест через 3 секунды',command=lambda:self.start(3)).pack(side='left',padx=3)
        ttk.Button(buttons,text='Ctrl+F9 СТОП',command=self.cancel).pack(side='left',padx=3)
        ttk.Button(buttons,text='Следующий тест',command=self.next_case).pack(side='left',padx=3)
        self.capture=tk.BooleanVar(value=False)
        ttk.Checkbutton(buttons,text='Сохранять кадры до/после локально',variable=self.capture).pack(side='left',padx=8)
        ttk.Label(self.root,text='Ctrl+F8 запускает выбранную строку сразу, только когда окно игры активно. '
                  'Ctrl+F10 — следующий номер; он ничего не нажимает в игре.',wraplength=980).pack(anchor='w',padx=12)
        note=ttk.Frame(self.root,padding=8);note.pack(fill='x')
        ttk.Label(note,text='Результат последнего теста:').pack(side='left')
        self.note=tk.StringVar()
        ttk.Entry(note,textvariable=self.note,width=70).pack(side='left',padx=5,fill='x',expand=True)
        ttk.Button(note,text='Записать',command=self.annotate).pack(side='left')
        ttk.Label(self.root,text='Например: «взгляд ещё выше горизонта», «примерно горизонт» или «уже ниже». '
                  'Для нового номера снова вручную верните камеру к пределу.',wraplength=980).pack(anchor='w',padx=12)
        ttk.Button(self.root,text='Скопировать результаты',command=self.copy).pack(anchor='w',padx=12,pady=6)
        self.status=ttk.Label(self.root,text='Не подключено');self.status.pack(anchor='w',padx=12)
        self.logbox=tk.Text(self.root,height=13,wrap='word');self.logbox.pack(fill='both',expand=True,padx=12,pady=8)
        self.hotkeys=SystemHotkeys(self.q);self.root.after(40,self.pump)
        self.root.protocol('WM_DELETE_WINDOW',self.close)

    def log(self,message):
        self.logbox.insert(tk.END,str(message)+'\n');self.logbox.see(tk.END)

    def connect(self):
        if self.tester:return True
        try:self.tester=PulseTester(logger=lambda m:self.q.put(m));self.status.configure(text='Xbox подключён');return True
        except Exception as exc:messagebox.showerror('Xbox',str(exc));return False

    def start(self,delay=0):
        if self.closing:return
        if self.worker and self.worker.is_alive():self.log('Дождитесь завершения текущего теста');return
        if not self.connect():return
        picked=self.tree.selection()
        if not picked:return
        name,strength,seconds=next(c for c in CASES if c[0]==picked[0])
        sign=-1 if self.baseline.get().startswith('Верхний') else 1
        if self.invert.get():sign=-sign
        baseline=self.baseline.get();capture=self.capture.get();self.stop_event.clear()
        self.log(f'Тест {name}: Y={sign*strength:+.2f}, {seconds*1000:.0f} мс. '
                 f'Исходное положение: {baseline}. Запуск через {delay} с.')
        self.status.configure(text='Ожидание / тест');self.note.set('')
        self.worker=threading.Thread(target=self.run_case,args=(name,sign*strength,seconds,baseline,capture,delay),daemon=True)
        self.worker.start()

    def save_frame(self,tag,index):
        try:
            from PIL import Image
            frame,_=self.screen.frame();Image.fromarray(frame[:,:,::-1]).save(self.sessions/f'{self.session}_{index:03d}_{tag}.png')
        except Exception as exc:self.q.put('Кадр не сохранён: '+str(exc))

    def run_case(self,name,pitch,seconds,baseline,capture,delay):
        try:
            if self.stop_event.wait(delay):return
            if self.screen.pick() is None or not self.screen.focused():
                self.q.put('Тест отменён: активно должно быть окно AION2');return
            index=len(self.rows)+1
            if capture:self.save_frame('before',index)
            if self.stop_event.is_set():return
            result=self.tester.pulse(pitch,seconds,lambda:not self.stop_event.is_set() and self.screen.focused())
            row={'run':index,'case':name,'baseline':baseline,**asdict(result),'note':''}
            if capture and result.completed and not self.stop_event.wait(.6) and self.screen.focused():self.save_frame('after',index)
            self.q.put(('result',row))
        except Exception as exc:self.q.put('Ошибка: '+str(exc))
        finally:
            if self.tester:self.tester.cancel()
            self.q.put(('finished',))

    def cancel(self):
        self.stop_event.set()
        if self.tester:self.tester.cancel()
        self.log('СТОП: правый стик отпущен');self.status.configure(text='Остановлено')

    def next_case(self):
        if self.worker and self.worker.is_alive():return
        current=self.tree.selection();index=next((i for i,c in enumerate(CASES) if current and c[0]==current[0]),-1)
        name=CASES[min(index+1,len(CASES)-1)][0];self.tree.selection_set(name);self.tree.see(name)
        self.log('Выбран тест '+name+'. Перед запуском вручную верните камеру к исходному пределу.')

    def persist(self):
        fields=['run','case','baseline','pitch','requested_ms','delivered_ms','completed','note']
        with self.csv_path.open('w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=fields);writer.writeheader();writer.writerows(self.rows)
        self.csv_path.with_suffix('.json').write_text(json.dumps(self.rows,ensure_ascii=False,indent=2),encoding='utf-8')

    def annotate(self):
        if self.last is None:self.log('Сначала выполните тест');return
        self.last['note']=self.note.get().strip();self.persist();self.log('Записано: '+self.last['note'])

    def copy(self):
        self.root.clipboard_clear();self.root.clipboard_append(json.dumps(self.rows,ensure_ascii=False,indent=2))
        self.log('Результаты скопированы; также сохранены в '+str(self.csv_path))

    def pump(self):
        if self.closing:return
        while True:
            try:item=self.q.get_nowait()
            except queue.Empty:break
            if isinstance(item,tuple):
                if item[0]=='hotkey':
                    {'toggle':lambda:self.start(0),'stop':self.cancel,'silence':self.next_case}[item[1]]()
                elif item[0]=='result':
                    self.last=item[1];self.rows.append(self.last);self.persist()
                    duration=self.last['delivered_ms']
                    self.log(f"Тест {self.last['case']}: Y={self.last['pitch']:+.2f}, задано {self.last['requested_ms']:.0f} мс, "
                             +('передано %.1f мс'%duration if duration is not None else 'импульс не передан')
                             +('; завершён' if self.last['completed'] else '; ПРЕРВАН'))
                elif item[0]=='finished':self.status.configure(text='Готово. Оцените угол; перед новым тестом верните камеру к пределу.')
            else:self.log(item)
        self.root.after(40,self.pump)

    def close(self):
        self.closing=True;self.stop_event.set()
        if self.tester:self.tester.close()
        self.hotkeys.stop();self.root.destroy()


if __name__=='__main__':
    if os.name=='nt':
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(2)
        except Exception:pass
    UI().root.mainloop()
