"""Bounded ascent/inspection cycles. No folding wings on a cruise timer."""
from navigation import Drive
from terrain_recovery import TerrainRecovery,RecoveryAction
from camera_control import PITCH_STRENGTH

class AreaRecovery(TerrainRecovery):
 def __init__(self,*args,**kwargs):
  super().__init__(*args,**kwargs);self.started=args[0];self.cycles=0;self.scan_pulse=-1
  self.descent_start=None;self.descent_absent=None
 def step(self,now,reading,balance,heading=None,bearing=None,height_gap=None):
  elapsed=now-self.since
  if self.phase=='RISE' and height_gap is not None and height_gap<=2:
   self.to('LEVEL',now)
  if self.phase=='CRUISE' and (not reading.confirmed or reading.energy is not None and reading.energy<=20 or elapsed>=4):
   self.to('SCAN',now);self.scan_pulse=-1;elapsed=0
  if self.phase=='SCAN':
   if not reading.confirmed:
    if self.absent is None:self.absent=now
    if now-self.absent>=.8:self.fly=False;self.to('GROUND',now)
    else:return RecoveryAction(reason='проверяю исчезновение дуги без переключения V')
   elif elapsed<6 and (reading.energy is None or reading.energy>20):
    slot=int(elapsed/1.5)
    if slot!=self.scan_pulse:
     self.scan_pulse=slot
     return RecoveryAction(drive=Drive(yaw=.30*self.side,lifetime=.12),reason='осмотр после перелёта: ищу ресурс, крылья сохраняю')
    return RecoveryAction(reason='жду свежую подпись ресурса после короткого осмотра')
   elif (self.cycles<3 and now-self.started<60 and reading.energy is not None and reading.energy>=50):
    if height_gap is not None and height_gap<=2:
     self.cycles+=1;self.to('CRUISE',now)
     return RecoveryAction(drive=self.travel(heading,bearing),reason='свежая Z близка к рабочему уровню: ищу ресурс в стороне, без нового подъёма')
    self.homed=False;self.pitch_start=None;self.level_start=None;self.to('DOWN',now)
   else:
    self.descent_start=None;self.to('DESC_DOWN',now)
  if self.phase=='DESC_DOWN':
   if self.descent_start is None:self.descent_start=balance
   left=2-(self.descent_start-balance)/PITCH_STRENGTH
   if left>.005:
    if now-self.since>=6:
     self.to('SCAN',now);self.cycles=3;self.scan_pulse=-1
     return RecoveryAction(reason='опускание камеры не подтверждено: повторяю осмотр, без слепого складывания крыльев')
    return RecoveryAction(drive=Drive(pitch=-PITCH_STRENGTH,lifetime=min(.15,left)),reason='выход не найден: готовлю управляемый спуск, V не нажимаю')
   self.to('DESCEND',now);self.descent_absent=None
  if self.phase=='DESCEND':
   if not reading.confirmed:
    if self.descent_absent is None:self.descent_absent=now
    if now-self.descent_absent>=.8:
     self.fly=False;self.homed=True;self.level_start=None;self.to('LEVEL',now)
    else:return RecoveryAction(reason='дуга исчезла; прекращаю полётный ввод и проверяю состояние')
   elif now-self.since>=8:
    self.to('DRIFT',now)
   else:
    self.descent_absent=None
    return RecoveryAction(drive=Drive(.45,.18*self.side,0,0,lifetime=.18,tilted_motion=True),reason='управляемый спуск при взгляде вниз; без END_AIR')
  if self.phase=='DRIFT':
   if now-self.since>=2:
    self.to('DESCEND',now);self.descent_absent=None
   else:
    # Camera still looks down: lateral input avoids reversing vertical motion.
    return RecoveryAction(drive=Drive(0,.4*self.side,0,0,lifetime=.18,tilted_motion=True),reason='спуск упёрся: коротко смещаюсь вбок, затем продолжаю')
  prior=self.phase
  result=super().step(now,reading,balance,heading,bearing)
  if prior in ('DOWN','WAIT') and self.phase=='RISE':self.cycles+=1
  if self.phase in ('CLOSE','WAIT_CLOSE','AIR_EXIT') or result.command=='END_AIR':
   self.to('DESC_DOWN' if reading.confirmed else 'GROUND',now);self.descent_start=None
   return RecoveryAction(levelled=result.levelled,reason='таймер перелёта не доказывает посадку; END_AIR отменён')
  return result
