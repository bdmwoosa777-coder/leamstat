import unittest,threading,time
from unittest.mock import patch
from types import SimpleNamespace
import numpy as np
from scene_navigation import Lane,SceneReading,ScenePilot,SceneHost,assess
from navigation import Drive
from area_recovery import AreaRecovery
from working_area import WorkingAreaMemory
from flight import FlightReading
from test_navigation import GatherFixture,radar
from test_network_control import Source
import gather_engine as ge

AIR=FlightReading(80,True);GROUND=FlightReading(None,False)
FREE=Lane(.8,.02,0,.1);WALL=Lane(.01,.8,0,.05);EDGE=Lane(.5,.01,.03,.2);UNKNOWN=Lane(0,0,0,1)
def reading(lanes,seq=1):return SceneReading(100,0,0,seq,tuple(lanes))

class PilotTests(unittest.TestCase):
 def test_clear_front_preserves_progress_with_speed_limit(self):
  a=ScenePilot().decide(Drive(.78,.1),reading([FREE,FREE,FREE]),100)
  self.assertGreater(a.drive.forward,.5);self.assertLessEqual(a.drive.forward,.65)
 def test_wall_left_exit_selects_left_without_wings(self):
  a=ScenePilot().decide(Drive(.7),reading([FREE,WALL,WALL]),100,90)
  self.assertLess(a.drive.strafe,0);self.assertFalse(a.fly)
 def test_wall_right_exit_selects_right(self):
  a=ScenePilot().decide(Drive(.7),reading([WALL,WALL,FREE]),100,90)
  self.assertGreater(a.drive.strafe,0)
 def test_front_edge_never_triggers_flight_over_unknown_drop(self):
  p=ScenePilot();a=p.decide(Drive(.7),reading([EDGE,EDGE,EDGE]),100,100)
  self.assertEqual(a.drive.forward,0);self.assertFalse(a.fly)
  a=p.decide(Drive(.7),reading([EDGE,EDGE,EDGE],2),107,100)
  self.assertFalse(a.fly)
 def test_wall_without_visible_detour_flies_only_after_confirmed_delay_and_energy(self):
  p=ScenePilot();r=reading([WALL,WALL,WALL]);p.decide(Drive(.7),r,100,80)
  self.assertFalse(p.decide(Drive(.7),r,106,80).fly)
  self.assertTrue(p.decide(Drive(.7),reading([WALL,WALL,WALL],2),106.1,80).fly)
 def test_low_or_unknown_energy_never_starts_flight(self):
  for energy in (None,20,49):
   p=ScenePilot();p.decide(Drive(.7),reading([WALL]*3),100,energy)
   self.assertFalse(p.decide(Drive(.7),reading([WALL]*3,2),107,energy).fly)
 def test_unknown_scene_does_not_invent_free_ground_or_flight(self):
  p=ScenePilot();a=p.decide(Drive(.7),reading([UNKNOWN]*3),100,80)
  self.assertEqual(a.drive.forward,0);self.assertFalse(a.fly)
  self.assertTrue(p.decide(Drive(.7),reading([UNKNOWN]*3,2),109,80).abandon)
 def test_confident_sky_does_not_count_as_a_walkable_surface(self):
  sky=Lane(0,0,0,0)
  a=ScenePilot().decide(Drive(.7),reading([sky]*3),100,80)
  self.assertEqual(a.drive.forward,0);self.assertFalse(a.fly)
 def test_missing_model_does_not_wait_forever(self):
  p=ScenePilot();self.assertEqual(p.decide(Drive(.7),None,100).drive.forward,0)
  self.assertEqual(p.decide(Drive(.7),None,103).drive.forward,.7)
 def test_reversing_plan_turns_camera_before_backwards_step(self):
  a=ScenePilot().decide(Drive(-.7),reading([FREE]*3),100)
  self.assertEqual(a.drive.forward,0);self.assertNotEqual(a.drive.yaw,0)
 def test_side_goal_does_not_walk_into_side_edge_when_center_is_clear(self):
  a=ScenePilot().decide(Drive(.6,.4),reading([FREE,FREE,EDGE]),100)
  self.assertEqual(a.drive.strafe,0);self.assertGreater(a.drive.forward,0)
 def test_partially_blocked_target_is_not_reused_as_its_own_detour(self):
  mixed=Lane(.4,.45,0,.1)
  a=ScenePilot().decide(Drive(.7),reading([FREE,mixed,WALL]),100)
  self.assertLess(a.drive.strafe,0)
 def test_clear_view_does_not_keep_rotating_away_from_its_own_observation(self):
  a=ScenePilot().decide(Drive(.7,.1,.42),reading([FREE]*3),100)
  self.assertEqual(a.drive.yaw,0)
 def test_failed_detour_abandons_goal_instead_of_oscillating_forever(self):
  p=ScenePilot();p.decide(Drive(.7),reading([FREE,WALL,FREE]),100)
  self.assertTrue(p.decide(Drive(.7),reading([FREE,WALL,FREE],2),113).abandon)
 def test_level_water_is_permitted(self):
  groups=np.full((100,200),3,np.uint8);depth=np.tile(np.linspace(1,2,100,dtype=np.float32)[:,None],(1,200))
  lanes=assess(groups,depth);self.assertGreater(lanes[1].free,.9);self.assertLess(lanes[1].edge,.012)
 def test_lateral_depth_step_is_not_missed(self):
  groups=np.ones((100,200),np.uint8);depth=np.ones((100,200),np.float32);depth[:,145:]=10
  lanes=assess(groups,depth);self.assertGreater(lanes[2].edge,.01)
 def test_nan_scene_is_rejected(self):
  with self.assertRaises(ValueError):assess(np.ones((20,30),np.uint8),np.full((20,30),np.nan))

class HostTests(unittest.TestCase):
 def test_stale_rotated_or_tilted_reading_not_used(self):
  host=SceneHost({});host.latest=reading([FREE]*3)
  self.assertIsNotNone(host.current(100.1,0,0));self.assertIsNone(host.current(102,0,0))
  self.assertIsNone(host.current(100.1,30,0));self.assertIsNone(host.current(100.1,0,.1))
 def test_unknown_heading_can_use_unchanged_controller_camera_epoch(self):
  host=SceneHost({});host.latest=SceneReading(100,None,0,1,(FREE,FREE,FREE),revision=7)
  self.assertIsNotNone(host.current(100.1,None,0,7));self.assertIsNone(host.current(100.1,None,0,8))
 def test_close_invalidates_result_and_prevents_new_worker(self):
  host=SceneHost({});host.latest=reading([FREE]*3);host.close()
  host.offer(np.zeros((100,200,3),np.uint8),100,0,0)
  self.assertIsNone(host.worker);self.assertIsNone(host.latest)

class AreaPolicyTests(unittest.TestCase):
 def scan(self):
  e=AreaRecovery(0,80);e.phase='CRUISE';e.since=0;e.cycles=1;return e
 def test_cruise_timer_starts_inspection_not_fold(self):
  e=self.scan();a=e.step(10,AIR,0);self.assertEqual(e.phase,'SCAN');self.assertIsNone(a.command)
  self.assertEqual(e.since,10)
 def test_scan_can_repeat_ascent_with_known_reserve(self):
  e=self.scan();e.step(4.1,AIR,0);a=e.step(10.2,AIR,0)
  self.assertEqual(e.phase,'DOWN');self.assertLess(a.drive.pitch,0);self.assertIsNone(a.command)
 def test_no_more_than_three_ascent_cycles(self):
  e=self.scan();e.phase='SCAN';e.since=0;e.cycles=3
  a=e.step(7,AIR,0);self.assertEqual(e.phase,'DESC_DOWN');self.assertLess(a.drive.pitch,0)
 def test_unknown_energy_never_repeats_ascent(self):
  e=self.scan();e.phase='SCAN';e.since=0
  a=e.step(7,FlightReading(None,True),0);self.assertEqual(e.phase,'DESC_DOWN')
 def test_descent_does_not_fold_wings(self):
  e=self.scan();e.phase='DESC_DOWN';e.since=0;e.descent_start=0
  a=e.step(2.1,AIR,-.9);self.assertEqual(e.phase,'DESCEND');self.assertGreater(a.drive.forward,0);self.assertIsNone(a.command)
  a=e.step(11,AIR,-.9);self.assertEqual(e.phase,'DRIFT');self.assertEqual(a.drive.forward,0)
 def test_disappearing_arc_stops_descent_and_restores_camera(self):
  e=self.scan();e.phase='DESCEND';e.since=0
  self.assertIsNone(e.step(1,GROUND,-.9).drive)
  a=e.step(2,GROUND,-.9);self.assertEqual(e.phase,'LEVEL');self.assertGreater(a.drive.pitch,0)
 def test_fresh_height_gap_stops_ascent_without_folding(self):
  e=self.scan();e.phase='RISE';e.since=0;e.homed=True
  a=e.step(1,AIR,-.9,height_gap=1.5)
  self.assertEqual(e.phase,'LEVEL');self.assertGreater(a.drive.pitch,0);self.assertIsNone(a.command)
 def test_known_working_level_searches_sideways_instead_of_repeating_ascent(self):
  e=self.scan();e.phase='SCAN';e.since=0
  a=e.step(7,AIR,0,height_gap=0,heading=0,bearing=90)
  self.assertEqual(e.phase,'CRUISE');self.assertGreater(a.drive.strafe,.5)
 def test_legacy_close_request_cannot_fold_in_area_policy(self):
  e=self.scan();e.phase='CLOSE';a=e.step(1,AIR,0)
  self.assertIsNone(a.command);self.assertEqual(e.phase,'DESC_DOWN')

class MemoryTests(unittest.TestCase):
 def setUp(self):
  self.source=Source();s=self.source.state;s.map_id=10;s.xyz=(0,0,1000);s.position_at=1000;s.last_own_result=(99,1000)
  self.memory=WorkingAreaMemory()
 def test_resource_and_fresh_ground_motion_confirm_working_area(self):
  self.memory.update(self.source.view(),GROUND,1000,True)
  for i in range(1,4):
   self.source.state.xyz=(i*100,0,1000);self.source.state.position_at=1000+i*100
   ok=self.memory.update(self.source.view(),GROUND,1000+i*100,False)
  self.assertTrue(ok);self.assertIsNotNone(self.memory.area)
 def test_stale_position_does_not_confirm_area(self):
  self.assertFalse(self.memory.update(self.source.view(),GROUND,3000,True));self.assertIsNone(self.memory.area)
 def test_airborne_or_changed_height_never_proves_walkable_level(self):
  self.memory.update(self.source.view(),GROUND,1000,True);s=self.source.state;s.xyz=(300,0,1400);s.position_at=1100
  self.assertFalse(self.memory.update(self.source.view(),GROUND,1100));self.assertIsNone(self.memory.area)
  self.memory.update(self.source.view(),AIR,1100,True);self.assertIsNone(self.memory.candidate)
 def test_fresh_rapid_z_loss_is_detected_without_claiming_ground_depth(self):
  self.memory.update(self.source.view(),GROUND,1000)
  self.source.state.xyz=(0,0,100);self.source.state.position_at=1500
  self.memory.update(self.source.view(),GROUND,1500)
  self.assertTrue(self.memory.rapid_drop(1500));self.assertFalse(self.memory.rapid_drop(3000))
 def test_intentional_flight_clears_drop_history(self):
  self.memory.update(self.source.view(),GROUND,1000)
  self.source.state.xyz=(0,0,100);self.source.state.position_at=1500
  self.memory.update(self.source.view(),AIR,1500)
  self.assertFalse(self.memory.rapid_drop(1500))
 def test_changed_flow_invalidates_old_anchor(self):
  self.memory.area=((0,0,1000),1000);self.memory.key=(99,7,10)
  self.memory.update(self.source.view(),GROUND,1100);self.assertIsNone(self.memory.area)

class SceneEngineTests(GatherFixture,unittest.TestCase):
 def setUp(self):
  super().setUp();self.source=Source();self.source.state.collecting=None;self.source.state.attempt_active=False
  self.e.network=self.source;self.e.mode='SEARCH';self.e.current_size=(1280,720)
  self.host=SimpleNamespace(offer=lambda *a:None,current=lambda *a:reading([FREE,WALL,WALL]),error=None,close=lambda:None)
  self.e.scene_host=self.host
 def plan(self):return self.e._scene_plan(self.frame,radar(heading=0),GROUND,Drive(.7),100)
 def test_real_plan_is_modified_before_controller_delivery(self):self.assertLess(self.plan().strafe,0)
 def test_active_collection_is_never_rerouted(self):
  self.e.target_confirmed=True;self.e.resource_hold=True
  self.assertEqual(self.plan().forward,.7);self.assertEqual(self.commands,[])
 def test_actual_panel_and_network_owner_prevent_scene_control(self):
  with patch.object(ge,'gathering_panel_pair',return_value=True):self.assertEqual(self.plan().forward,.7)
  s=self.source.state;s.collecting=99;s.nodes[99].gather_time=1000;s.attempt_active=True
  self.assertEqual(self.plan().forward,.7)
 def test_unsafe_edge_does_not_send_v(self):
  self.host.current=lambda *a:reading([EDGE]*3)
  self.assertEqual(self.plan().forward,0);self.assertNotIn('V',self.commands)
 def test_bridge_exit_is_not_replaced_by_scene_detour(self):
  self.e.return_exit_guard=True;self.assertEqual(self.plan().forward,.7)
 def test_rescue_hands_fresh_resource_to_existing_click_without_v(self):
  self.e.cfg['area_search_rescue']=True;self.e.terrain_recovery=AreaRecovery(0,80);self.e.terrain_recovery.phase='SCAN'
  self.e.mode='RESCUE';self.e.snapshot=(SimpleNamespace(candidate=self.c),100,1,100)
  with patch.object(ge,'find_resource_near',return_value=self.c),patch.object(self.e,'click_candidate',return_value=True):
   self.assertTrue(self.e._rescue_resource(self.frame,100))
  self.assertIsNone(self.e.terrain_recovery);self.assertEqual(self.commands,[])
 def test_resource_start_during_scene_decision_blocks_wing_rescue(self):
  self.e.scene_pilot.blocked=100;self.e.scene_pilot.confirmations=1;self.e.scene_pilot.last_seq=1
  self.e.budget.energy=80
  def current(*args):
   s=self.source.state;s.collecting=99;s.attempt_active=True;s.nodes[99].gather_time=1000
   return reading([WALL]*3,2)
  self.host.current=current
  with patch.object(ge.time,'monotonic',return_value=107):self.plan()
  self.assertIsNone(self.e.terrain_recovery);self.assertNotIn('V',self.commands)
 def test_fresh_drop_starts_rescue_without_ninety_second_delay(self):
  self.e.cfg.update(area_search_rescue=True,terrain_rescue_enabled=True);self.e.budget.energy=80
  s=self.source.state;s.map_id=10;s.xyz=(0,0,1000);s.position_at=1000
  with patch.object(ge.time,'time',return_value=1),patch.object(ge.time,'monotonic',return_value=100):self.e._track_working_area(GROUND)
  s.xyz=(0,0,100);s.position_at=1500
  with patch.object(ge.time,'time',return_value=1.5),patch.object(ge.time,'monotonic',return_value=100.5):self.e._track_working_area(GROUND)
  self.assertIsInstance(self.e.terrain_recovery,AreaRecovery);self.assertEqual(self.commands,[])
 def test_stale_resource_snapshot_does_not_click(self):
  self.e.snapshot=(SimpleNamespace(candidate=self.c),90,1,90)
  with patch.object(self.e,'click_candidate') as click:self.assertFalse(self.e._rescue_resource(self.frame,100));click.assert_not_called()

if __name__=='__main__':unittest.main()
