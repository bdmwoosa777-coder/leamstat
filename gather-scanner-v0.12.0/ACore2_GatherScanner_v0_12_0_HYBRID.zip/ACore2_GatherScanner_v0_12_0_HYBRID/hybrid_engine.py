"""Classic resource state machine + fast minimap driver + asynchronous detours."""
from dataclasses import replace
import math,time
import cv2
from gather_engine import GatherEngine
from hybrid_navigation import RouteAdvisor,HybridPlanner
from navigation import Drive
from vision import gathering_panel_pair
from return_exit import purple_anchor

class HybridGatherEngine(GatherEngine):
 def __init__(self,cfg,*args,**kwargs):
  enabled=cfg.get('analyzer_enabled',True)
  super().__init__({**cfg,'analyzer_enabled':False},*args,**kwargs)
  self.cfg['analyzer_enabled']=enabled
  self.analyzer=RouteAdvisor(self.cfg,self.say) if enabled and self.scene_host is not None else None
  self.hybrid=HybridPlanner(cfg.get('camera_yaw_sign',1));self.hybrid_note=-1e9;self.hybrid_camp_check=-1e9;self.hybrid_identity_note=-1e9;self.hybrid_camp_pending=False
  # One progress watchdog owns detours. The legacy one stores screen-band IDs,
  # which are unsuitable for avoidance across camera changes.
  self.scene_pilot.follower.observe_progress=lambda *a:False
  self.say('HYBRID 0.12.0: миникарта и сбор без ожидания модели; Qwen выбирает обход, текущая карта проходов проверяет его')
 def save_debug(self,frame,label):
  if not self.cfg.get('debug_screenshots'):return
  try:
   self.screenshot_path.mkdir(exist_ok=True)
   safe=''.join(c for c in label if c.isalnum() or c=='_')[:80]
   file=self.screenshot_path/('hybrid_'+str(time.time_ns())+'_'+safe+'.jpg')
   if not cv2.imwrite(str(file),frame,[cv2.IMWRITE_JPEG_QUALITY,90]):return
   files=sorted(self.screenshot_path.glob('hybrid_*.jpg'),key=lambda p:p.name);total=sum(p.stat().st_size for p in files)
   while files and (len(files)>60 or total>64*1024*1024):
    old=files.pop(0);total-=old.stat().st_size;old.unlink()
  except (OSError,cv2.error) as exc:self.say('DEBUG_SAVE: '+str(exc)+'; управление продолжается')

 def _needs_visual_hp(self):
  if self.network is None:return True
  if not hasattr(self.network,'confirm_own_hp'):return False
  view=self._net_view();return bool(view and view['ready'] and view['state'].own is None)
 def _health_identity_sample(self,value,captured,verified):
  if self.network is None or not hasattr(self.network,'confirm_own_hp') or not verified or value is None or value.current>=value.maximum or not self._focus_ok() or not self._needs_visual_hp():return
  self.network.confirm_own_hp(value.current,value.maximum,int((time.time()-time.monotonic()+captured)*1000))
 def _camp_update(self,frame,radar,now):
  if not self.cfg.get('hybrid_camp_exit',True):return
  if now-self.hybrid_camp_check>=.5:
   self.hybrid_camp_check=now;anchor=purple_anchor(frame,radar.bounds)
   if anchor is not None:
    self.camp_last_seen=now
    if now>=self.camp_exit_retry_after:
     self.camp_exit_until=now+35;self.camp_exit_retry_after=now+65;self.camp_motion=0;self.hybrid_camp_pending=True
     self.say('HYBRID_CAMP_EXIT: сначала наземный выход из области кибелиска, затем ресурсы')
  if self.hybrid_camp_pending:
   self.camp_exit_until=max(self.camp_exit_until,now+.3)
   if radar.motion_valid:self.camp_motion+=math.hypot(*radar.displacement)
   if now-self.camp_last_seen>1.5 and self.camp_motion>8:
    self.camp_exit_until=0;self.hybrid_camp_pending=False;self.say('HYBRID_CAMP_EXIT: удалился по миникарте; возвращаю поиск ресурсов')
 def step(self,frame,origin,obs,radar,reading,now,sequence=0):
  if self.stop_event.is_set():return
  if self.mode=='SEARCH' and not self.target_confirmed and not self.resource_hold and not reading.confirmed and not self.map_active:
   self._camp_update(frame,radar,now)
   if now<self.camp_exit_until:
    obs=replace(obs,candidate=None);radar=replace(radar,markers=[])
   if self.hybrid.active:
    # The local detour, not progress directly toward a wall-hidden goal,
    # owns the short stall timer. Keep the actual resource goal intact.
    self.nav.progress_at=now;self.nav.motion_since=now;self.nav.motion_sum=0;self.nav.motion_samples=0
  return super().step(frame,origin,obs,radar,reading,now,sequence)
 def _scene_plan(self,frame,radar,reading,plan,now):
  if (self.scene_host is None or self.cfg.get('dry_run') or self.mode!='SEARCH' or self.target_confirmed
      or self.resource_hold or self.collecting_visible or self.map_active or reading.confirmed or self.budget.airborne
      or self.camera_alignment_due or self.pitch.returning or abs(self.pitch.offset(now))>.015
      or not self._focus_ok() or abs(plan.pitch)>.001 or plan.restore_pitch or plan.flight_probe):return plan
  if gathering_panel_pair(frame):return plan
  view=self._net_view() if self.network is not None else None
  if self.network is not None and (not view or not view['ready'] or self._own_collection(view) is not None):return plan
  heading=radar.heading if radar.confidence>=.30 else None;pitch=self.pitch.offset(now)
  captured=time.monotonic()
  self.scene_host.offer(frame,captured,heading,pitch,self.scene_camera_epoch)
  result=self.scene_host.current(captured,heading,pitch,self.scene_camera_epoch)
  exit_mode=now<self.camp_exit_until
  if exit_mode:plan=Drive(.6,reason='ищу наземный выход из области кибелиска')
  goal=self.nav.goal
  goal_bearing=math.degrees(math.atan2(goal.x-radar.center[0],radar.center[1]-goal.y))%360 if goal else None
  context={'mode':'camp_exit' if exit_mode else 'resources','kind':goal.kind if goal else None,
           'goal_bearing':round(goal_bearing) if goal_bearing is not None else None,
           'goal_relative':round((goal_bearing-heading+180)%360-180) if goal_bearing is not None and heading is not None else None,
           'failed_bearings':[round(b) for b,t in self.hybrid.avoid if now<t]}
  hint=None;warning=None
  if self.analyzer is not None and result is not None and result.ground is not None:
   self.analyzer.offer(result.source if result.source is not None else frame,result.ground,result.captured,result.heading,result.pitch,context)
   hint=self.analyzer.recommend(result.ground,frame,captured,heading,pitch,context)
   warning=self.analyzer.warning(captured,heading,pitch,context)
  action=self.hybrid.choose(plan,result,radar,now,hint,exit_mode,warning)
  if action.recalibrate:
   if now>=self.scene_view_retry_after:
    self.scene_view_retry_after=now+3;self.scene_view_repair=True;self.nav.air_since=None;self.nav.scan_kind=None;self.view_guard.force(now)
   return Drive()
  if action.skip:
   self.nav.exclude_goal(now,25);self.nav.air_since=None;self.nav.scan_kind=None
   self.say('HYBRID_REPLAN: недоступная цель отложена; выбираю другой ресурс/наземный выход')
  if now-self.hybrid_note>=1.5:
   self.hybrid_note=now
   state='нет' if self.analyzer is None else 'занят' if self.analyzer.busy else 'ошибка' if self.analyzer.error else 'готов' if self.analyzer.ready else 'ожидание'
   self.say('HYBRID_NAV: '+action.reason+'; Qwen='+state+'; локальному кадру '+(str(round(captured-result.captured,2))+' с' if result else 'нет данных'))
  return action.drive
