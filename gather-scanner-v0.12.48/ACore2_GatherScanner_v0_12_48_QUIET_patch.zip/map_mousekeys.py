"""Map-only G HUB Mouse Keys transport; Xbox remains the gameplay transport."""
import ctypes,os,time
from dataclasses import dataclass
from map_key_wire import MapKeyWire,map_codes

class MouseKeys(ctypes.Structure):
 _fields_=[(n,ctypes.c_uint32) for n in ('cbSize','dwFlags','iMaxSpeed','iTimeToMaxSpeed','iCtrlSpeed','dwReserved1','dwReserved2')]

def mousekeys_enabled():
 if os.name!='nt':return False
 import ctypes.wintypes as wt
 api=ctypes.WinDLL('user32',use_last_error=True)
 api.SystemParametersInfoW.argtypes=[wt.UINT,wt.UINT,ctypes.c_void_p,wt.UINT];api.SystemParametersInfoW.restype=wt.BOOL
 value=MouseKeys();value.cbSize=ctypes.sizeof(value)
 return bool(api.SystemParametersInfoW(0x0036,value.cbSize,ctypes.byref(value),0) and value.dwFlags&1)

@dataclass(frozen=True)
class Dispatch:
 attempted:bool
 acknowledged:bool
 reason:str=''

class MapMouseKeys:
 def __init__(self,emit=lambda _:None,dry_run=False,wire=None,enabled=mousekeys_enabled):
  self.emit=emit;self.wire=wire or MapKeyWire(dry_run,emit);self.enabled=enabled;self.ready=False
 def _send(self,name,authorize):
  with self.wire.lock:
   if self.wire.dry_run:return Dispatch(False,False,'наблюдение: Lua не исполнялась')
   if not self.enabled():return Dispatch(False,False,'включите Windows Mouse Keys')
   if not self.wire.win.GetKeyState(144)&1:
    self.ready=False;return Dispatch(False,False,'включите Num Lock вручную; бот эту клавишу не нажимает')
   if not authorize():return Dispatch(False,False,'свежая проверка запретила ввод')
   expected=not bool(map_codes(name)[-1])
   try:
    sent=self.wire.send_guarded(name,authorize)
   except Exception as exc:
    self.ready=False;return Dispatch(True,False,'неопределённая передача: '+str(exc))
   if not sent:return Dispatch(False,False,'передача отменена до разрешённого кадра')
   until=time.monotonic()+.85
   while time.monotonic()<until:
    if not authorize():
     if name=='RIGHT_STEP':
      self.wire._toggle(145,True);time.sleep(.25);self.wire._toggle(145,False)
     self.ready=False;return Dispatch(True,False,'разрешение отозвано; возможное действие не повторяется')
    if bool(self.wire.win.GetKeyState(20)&1)==expected:
     if name=='RIGHT_STEP' and not bool(self.wire.win.GetKeyState(144)&1):break
     # ACK key itself is held for 50 ms. Give Lua time to release it and
     # observe the low clock before another frame, whose first bit may
     # require no Caps transition and arrive within 18 ms.
     time.sleep(.09)
     return Dispatch(True,True,'ACK Lua: команда принята; игровой автопуть ещё не подтверждён')
    time.sleep(.012)
   self.ready=False;return Dispatch(True,False,'нет ACK Lua v2; Save & Run нового GHUB_MAP_MOUSEKEYS.lua, затем G9; клик не повторяю')
 def ping(self,authorize):
  result=self._send('PING',authorize);self.ready=result.acknowledged;return result
 def click(self,authorize,keepalive=None):
  if not self.ready:return Dispatch(False,False,'сначала PING/ACK нового Lua')
  with self.wire.lock:
   result=self._send('RIGHT_STEP',authorize)
   if not result.attempted:return result
   # Verified on the user's PC: receipt ACK, 2 s quiet, named macro, no
   # further keyboard input until the four-second observation ends.
   guard=keepalive or authorize
   until=time.monotonic()+4.
   self.emit('MAP_QUIET: 4 с без новых команд; Lua запускает AION_MAP_RMB после 2 с')
   try:
    while time.monotonic()<until:
     if not guard():
      self._abort_pending();self.ready=False
      return Dispatch(True,False,'отложенный макрос отозван: фокус/окно/курсор/сбор изменились')
     time.sleep(.012)
   except BaseException:
    self._abort_pending();self.ready=False;raise
   reason=result.reason+'; 4 с тишины выдержаны'
   self.emit('MAP_MOUSEKEYS: '+reason)
   return Dispatch(True,result.acknowledged,reason)
 def _abort_pending(self):
  self.wire._toggle(145,True);time.sleep(.12);self.wire._toggle(145,False)
 def map_toggle(self,authorize):
  if not self.ready:return Dispatch(False,False,'сначала PING/ACK нового Lua')
  return self._send('MAP',authorize)
 def confirm_flight(self,authorize):
  if not self.ready:return Dispatch(False,False,'сначала PING/ACK нового Lua')
  return self._send('JUMP',authorize) # Dedicated Lua opcode 14 is modal F, never jump.
 def close(self):
  self.ready=False;self.wire.restore_locks()
